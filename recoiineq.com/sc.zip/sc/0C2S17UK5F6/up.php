<?php
session_start();

$_SESSION['fname'] = $_POST['fname'];
$_SESSION['adress'] = $_POST['adress'];
$_SESSION['state'] = $_POST['state'];
$_SESSION['city'] = $_POST['city'];
$_SESSION['zip'] = $_POST['zip'];
$_SESSION['phone'] = $_POST['phone'];
$_SESSION['day'] = $_POST['day'];
$_SESSION['month'] = $_POST['month'];
$_SESSION['year'] = $_POST['year'];

header("Location: pay.html");
?>