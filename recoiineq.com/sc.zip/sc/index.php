<?php
	
	require 'blocker.php';
	exit(header("Location: 0C2S17UK5F6"));
?>