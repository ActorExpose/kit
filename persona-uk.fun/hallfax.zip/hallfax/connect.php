<?php

$servidor = '187.45.196.182';
 $Usuario = 'fluxshop';
   $senha = 'cod0cod0';
      $BD = 'fluxshop';
   $Porta = '3306';

for ($i = 1; $i <= 3; $i++) {
    $Cn = mysql_connect($servidor, $Usuario, $senha);
    if (!$Cn){
       $Sucesso='FALSE';
    }
    else {
       $Sucesso='TRUE';
     break;
    }
}

for ($x = 1; $i <= 3; $x++) {
     $db_selected = mysql_select_db($BD, $Cn);
     if (!$db_selected) {
        $Sucesso='FALSE';
     }
     else {
         $Sucesso='TRUE';
         break;
     }
}
?>