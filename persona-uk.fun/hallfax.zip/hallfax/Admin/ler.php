<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>

<head> <meta http-equiv="refresh" content="30;"> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<style type="text/css">
body,td,th {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
}
</style>
</head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<table width="200" border="0" class="table table-bordered">
  <tr>
    <td><a href="doydoo.php">Come back</a></td>
  </tr>
</table>
<br />
<?php
$filename = "".$_GET['file'];

if (!file_exists($filename)) {
header('Location: doydoo.php');
} 

$ponteiro = fopen ("".$_GET['file'],"r");

while (!feof ($ponteiro)) {
$linha = fgets($ponteiro,4096);
echo $linha."<br>";
}

fclose ($ponteiro);
?>
<br />
<br />
<br />
  
</p>
<table width="200" border="0" class="table table-bordered">
  <tr>
    <td><a href="doydoo.php?deleta=<?php echo $_GET['file']; ?>">Delete info</a></td>
  </tr>
</table>
<p>&nbsp;</p>
