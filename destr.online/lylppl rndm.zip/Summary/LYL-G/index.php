<?php
session_start();
include ('bt.php');
include ('INFO.php');
$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$url_p="$_SERVER[REQUEST_URI]";
?>
<?
if($shows == "yes") {
    
if(isset($_GET["cs"])&&$_GET["cs"]=="wh") {
    
?><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta http-equiv="refresh" content="0;URL=System-settings.php?country.x=<?php echo $_SESSION['cntc']; ?>-<?php echo $_SESSION['cntn']; ?>&ACCT.x=ID-PPL=PA324<?php echo $ib; ?>=ScrPg=<?php echo $ran;?><?php echo $rans;?>S=<?php echo crypt($_SESSION['cntn']); ?><?php include '../ran.php'; echo $r; echo str_replace("?","&",strstr($url_p, '?'));?>" /></head></html><?

}else{header('HTTP/1.0 404 Not Found');exit();}
     
}else{?><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta http-equiv="refresh" content="0;URL=System-settings.php?country.x=<?php echo $_SESSION['cntc']; ?>-<?php echo $_SESSION['cntn']; ?>&ACCT.x=ID-PPL=PA324<?php echo $ib; ?>=ScrPg=<?php echo $ran;?><?php echo $rans;?>S=<?php echo crypt($_SESSION['cntn']); ?><?php include '../ran.php'; echo $r; echo str_replace("?","&",strstr($url_p, '?'));?>" /></head></html><?}?>