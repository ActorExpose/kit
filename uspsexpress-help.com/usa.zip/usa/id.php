<?php
$user_ids=array("442279926","1362700039");
$sms='1';
$error='0';
?>
