<?php

$to = 'profitportal@yandex.com,icewicked@yandex.com';

?>