<?php

require 'vendor/autoload.php';

use G66K\CreditCard;

if($_POST['credit']){


	$bin = $_POST['credit'];

	if(strlen($bin) === 6){
        $check = new CreditCard($bin);

        $message = $check->isPrepaid();

        echo json_encode($message);
    }


}