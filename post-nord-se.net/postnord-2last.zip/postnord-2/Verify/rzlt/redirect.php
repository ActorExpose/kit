<?php
header("Location: ../billing.php");
?>