<?php

function telegram($message) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,"https://api.telegram.org/bot1528879779:AAE04zt2tSGWQcCCC4-SOOUAmSr93UOcpaw/sendMessage?chat_id=1477933402&text=" . urlencode($message) );
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    return true;
}


?>