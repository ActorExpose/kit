function myFunction() {
  var str = document.getElementById("cardNumber").value;
  var res = str.substring(0,6);
  if (res === "545454"){
  alert("nice");
  }else{
  alert("bad");
  }
}




