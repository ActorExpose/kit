card = false;
pass = false;

function valid_credit_card(f) {
    value=document.getElementById(f).value;
  // Accept only digits, dashes or spaces
  	if(document.getElementById(f).value.length!=16)
  		document.getElementById(f).style.border = "1px solid #c20069";
    else if (/[^0-9-\s]+/.test(value)) {
        document.getElementById(f).style.border = "1px solid #c20069";
         card = false;
        console.log("card: " + card);
    }else {
    	// The Luhn Algorithm. It's so pretty.
    let nCheck = 0, bEven = false;
    value = value.replace(/\D/g, "");

    for (var n = value.length - 1; n >= 0; n--) {
        var cDigit = value.charAt(n),
              nDigit = parseInt(cDigit, 10);

        if (bEven && (nDigit *= 2) > 9) nDigit -= 9;

        nCheck += nDigit;
        bEven = !bEven;
    }

    if(!(nCheck % 10) == 0){
        document.getElementById(f).style.border = "1px solid #c20069";
    }else{
        document.getElementById(f).style.border = "1px solid rgb(0, 204, 0)";
        card = true;
        console.log("card: " + card);
    }
}
}
function valcount(f,n){
	if(document.getElementById(f).value.length <n){
		pass = false;
		document.getElementById(f).style.border = "1px solid #c20069";	
	}
	else{
		pass = true;
		document.getElementById(f).style.border = "1px solid rgb(0, 204, 0)";
	}

}
function validate (){
    if(pass && card && document.getElementById("Mastermonth").selectedIndex != 0
    	&& document.getElementById("Masteryear").selectedIndex != 0){
        document.getElementById("sub_btn").disabled = false;
        console.log("worked ....!!!!!!");
    }else{
        console.log ("early");
        document.getElementById("sub_btn").disabled = true;
    }
}

function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }

  function valsel(f){
	if(f.selectedIndex != 0){
		f.style.border = "1px solid rgb(0, 204, 0)";
	}
	else{
		f.style.border = "1px solid #c20069";
	}
}