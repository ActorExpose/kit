<?php
include('../../blockers.php');
include('../../detects.php');
include('../../random.php');
include('../../assets/header.php');
?>
<style type="text/css">
    .axp-authorize-action__module__module___1n4eK html {
        scroll-behavior: smooth;
    }
    .axp-authorize-action__module__module___1n4eK button,
    .axp-authorize-action__module__module___1n4eK input,
    .axp-authorize-action__module__module___1n4eK select,
    .axp-authorize-action__module__module___1n4eK textarea {
        color: inherit;
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
    }
    .axp-authorize-action__module__module___1n4eK [type="number"]::-webkit-inner-spin-button,
    .axp-authorize-action__module__module___1n4eK [type="number"]::-webkit-outer-spin-button {
        -webkit-appearance: none;
    }
    .axp-authorize-action__module__module___1n4eK [tabindex="-1"]:focus {
        outline: none !important;
    }
    .axp-authorize-action__module__module___1n4eK ul {
        padding-left: 1.3em;
    }
    .axp-authorize-action__module__module___1n4eK ol {
        padding-left: 1.5em;
    }
    .axp-authorize-action__module__module___1n4eK ol,
    .axp-authorize-action__module__module___1n4eK ul {
        margin-top: 0;
        margin-bottom: 0;
    }
    .axp-authorize-action__module__module___1n4eK ol ol,
    .axp-authorize-action__module__module___1n4eK ul ul,
    .axp-authorize-action__module__module___1n4eK ol ul,
    .axp-authorize-action__module__module___1n4eK ul ol {
        margin-bottom: 0;
    }
    .axp-authorize-action__module__module___1n4eK sup {
        top: 0;
        font-size: 0.55em;
        line-height: 1;
        vertical-align: super;
    }
    .axp-authorize-action__module__module___1n4eK a {
        background-color: transparent;
        color: #006fcf;
        text-decoration: none;
        cursor: pointer;
        transition: color 0.25s ease-out, background-color 0.25s ease-out;
    }
    .axp-authorize-action__module__module___1n4eK a:hover {
        text-decoration: underline;
    }
    .axp-authorize-action__module__module___1n4eK a:focus {
        outline: dotted 1px rgba(0, 0, 0, 0.3);
        outline-offset: 3px;
    }
    .axp-authorize-action__module__module___1n4eK img {
        max-width: 100%;
        width: auto;
        height: auto;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK [role="button"] {
        cursor: pointer;
    }
    .axp-authorize-action__module__module___1n4eK a,
    .axp-authorize-action__module__module___1n4eK area,
    .axp-authorize-action__module__module___1n4eK button,
    .axp-authorize-action__module__module___1n4eK [role="button"],
    .axp-authorize-action__module__module___1n4eK input,
    .axp-authorize-action__module__module___1n4eK label,
    .axp-authorize-action__module__module___1n4eK select,
    .axp-authorize-action__module__module___1n4eK summary,
    .axp-authorize-action__module__module___1n4eK textarea {
        -ms-touch-action: manipulation;
        touch-action: manipulation;
    }
    .axp-authorize-action__module__module___1n4eK table,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        padding: 0.625rem;
        background-color: transparent;
    }
    .axp-authorize-action__module__module___1n4eK table th,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th {
        text-align: left;
    }
    .axp-authorize-action__module__module___1n4eK table th,
    .axp-authorize-action__module__module___1n4eK table td,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
        padding: 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK label {
        display: inline-block;
        margin-bottom: 0.3125rem;
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK button:focus {
        outline: dotted 1px rgba(0, 0, 0, 0.3);
        outline-offset: 3px;
    }
    .axp-authorize-action__module__module___1n4eK input,
    .axp-authorize-action__module__module___1n4eK button,
    .axp-authorize-action__module__module___1n4eK select,
    .axp-authorize-action__module__module___1n4eK textarea {
        margin: 0;
        line-height: inherit;
        border-radius: 0;
    }
    .axp-authorize-action__module__module___1n4eK textarea {
        resize: vertical;
    }
    .axp-authorize-action__module__module___1n4eK fieldset {
        min-width: 0;
        padding: 0;
        margin: 0;
        border: 0;
    }
    .axp-authorize-action__module__module___1n4eK legend {
        display: block;
        width: 100%;
        padding: 0;
        margin-bottom: 0.5rem;
        font-size: 1.5rem;
        line-height: inherit;
    }
    .axp-authorize-action__module__module___1n4eK input[type="search"] {
        box-sizing: inherit;
        -webkit-appearance: none;
    }
    .axp-authorize-action__module__module___1n4eK input[type="search"]::-webkit-search-cancel-button {
        display: none;
    }
    .axp-authorize-action__module__module___1n4eK [hidden] {
        display: none !important;
    }
    .axp-authorize-action__module__module___1n4eK dt {
        font-weight: bold;
    }
    .axp-authorize-action__module__module___1n4eK hr {
        border: 0;
        border-top: 1px solid #ecedee;
        margin-top: 0;
        margin-bottom: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__disabled___Sy-go,
    .axp-authorize-action__module__module___1n4eK :disabled {
        cursor: not-allowed !important;
        color: #97999b !important;
        text-decoration: none !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__disabled___Sy-go label,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__disabled___Sy-go input,
    .axp-authorize-action__module__module___1n4eK :disabled label,
    .axp-authorize-action__module__module___1n4eK :disabled input {
        cursor: not-allowed !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__alert___1KJ5T {
        border: 1px solid transparent;
        border-radius: 0;
        display: -ms-flexbox;
        display: flex;
        margin-bottom: 1.25rem;
        min-width: 120px;
        padding-left: 1.25rem;
        padding-right: 1.25rem;
        position: relative;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__alertForm___1FKPS {
        color: #b42c01;
        background-color: #fff;
        border-color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__alertForm___1FKPS {
        border-width: 0;
        margin-bottom: 0;
        padding: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__alertForm___1FKPS {
        font-size: 0.9375rem;
        line-height: 1.375rem;
        padding-top: 0.3125rem;
        padding-bottom: 0;
        padding-left: 0;
        padding-right: 0;
        display: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__alertForm___1FKPS,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__alertForm___1FKPS.axp-authorize-action__module__active___2HXZt {
        display: block;
    }
    @keyframes axp-authorize-action__module__bar-indeterminate___WGAay {
        0% {
            left: -35%;
            right: 100%;
        }
        60% {
            left: 100%;
            right: -90%;
        }
        100% {
            left: 100%;
            right: -90%;
        }
    }
    @keyframes axp-authorize-action__module__bar-indeterminate-short___3raYa {
        0% {
            left: -200%;
            right: 100%;
        }
        60% {
            left: 107%;
            right: -8%;
        }
        100% {
            left: 107%;
            right: -8%;
        }
    }
    @keyframes axp-authorize-action__module__fadein___12bNw {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
    @keyframes axp-authorize-action__module__fadeout___3cm-E {
        0% {
            opacity: 1;
        }
        100% {
            opacity: 0;
        }
    }
    @keyframes axp-authorize-action__module__slideup___2R4li {
        0% {
            opacity: 0;
            transform: translateY(50px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
    @keyframes axp-authorize-action__module__slidedown___daCia {
        0% {
            opacity: 0;
            transform: translateY(-50px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
    @keyframes axp-authorize-action__module__slidefromleft___oc2V3 {
        0% {
            opacity: 0;
            transform: translateX(-50px);
        }
        100% {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes axp-authorize-action__module__slidefromright___qN-U_ {
        0% {
            opacity: 0;
            transform: translateX(50px);
        }
        100% {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes axp-authorize-action__module__spinner-indeterminate___26ZME {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    @keyframes axp-authorize-action__module__spinner-indeterminate___26ZME {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    @keyframes axp-authorize-action__module__bar-indeterminate___WGAay {
        0% {
            left: -35%;
            right: 100%;
        }
        60% {
            left: 100%;
            right: -90%;
        }
        100% {
            left: 100%;
            right: -90%;
        }
    }
    @keyframes axp-authorize-action__module__bar-indeterminate-short___3raYa {
        0% {
            left: -200%;
            right: 100%;
        }
        60% {
            left: 107%;
            right: -8%;
        }
        100% {
            left: 107%;
            right: -8%;
        }
    }
    @keyframes axp-authorize-action__module__slideup___2R4li {
        0% {
            opacity: 0;
            transform: translateY(50px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
    @keyframes axp-authorize-action__module__slidedown___daCia {
        0% {
            opacity: 0;
            transform: translateY(-50px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
    @keyframes axp-authorize-action__module__slidefromleft___oc2V3 {
        0% {
            opacity: 0;
            transform: translateX(-50px);
        }
        100% {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes axp-authorize-action__module__slidefromright___qN-U_ {
        0% {
            opacity: 0;
            transform: translateX(50px);
        }
        100% {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes axp-authorize-action__module__fadein___12bNw {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
    @keyframes axp-authorize-action__module__fadeout___3cm-E {
        0% {
            opacity: 1;
        }
        100% {
            opacity: 0;
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__badge___2aRiK {
        -ms-flex-align: center;
        align-items: center;
        border: solid transparent;
        border-radius: 1.25rem;
        display: -ms-inline-flexbox;
        display: inline-flex;
        -ms-flex-pack: center;
        justify-content: center;
        position: relative;
        text-align: center;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        vertical-align: middle;
        word-wrap: break-word;
    }
    .axp-authorize-action__module__module___1n4eK div > .axp-authorize-action__module__badge___2aRiK:not(:last-of-type) {
        margin-right: 0.3125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__badge___2aRiK {
        background-color: #006fcf;
        color: #fff;
        font-size: 0.9375rem;
        font-weight: normal;
        height: 1.5625rem;
        min-width: 1.5625rem;
        padding: 0 0.375rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__pill___32SBt {
        border-radius: 20px;
        min-width: 40px;
        padding: 0 7px;
        width: initial;
    }
    .axp-authorize-action__module__module___1n4eK _:-ms-fullscreen .axp-authorize-action__module__badge___2aRiK,
    .axp-authorize-action__module__module___1n4eK :root .axp-authorize-action__module__badge___2aRiK {
        display: inline-block;
        line-height: 1.125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__breadcrumb___2c-S- {
        color: #000;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-flow: row;
        flex-flow: row;
        list-style: none;
        margin: 0;
        padding: 0;
        overflow-x: auto;
        -ms-overflow-style: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__breadcrumb___2c-S-::-webkit-scrollbar {
        display: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__breadcrumb___2c-S- > li {
        position: relative;
        display: -ms-inline-flexbox;
        display: inline-flex;
        -ms-flex-align: center;
        align-items: center;
        white-space: nowrap;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__breadcrumb___2c-S- > li > * {
        margin: auto;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__breadcrumb___2c-S- > li:not(:last-of-type)::after {
        font-family: "dls-icons";
        content: "";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        font-size: 0.75rem;
        color: #53565a;
        margin: auto 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__breadcrumb___2c-S- > li:last-of-type {
        cursor: default;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__breadcrumb___2c-S- > li:last-of-type a[href] {
        cursor: pointer;
    }
    .axp-authorize-action__module__module___1n4eK _:-ms-fullscreen .axp-authorize-action__module__breadcrumb___2c-S- > li,
    .axp-authorize-action__module__module___1n4eK :root .axp-authorize-action__module__breadcrumb___2c-S- > li {
        display: inline-block;
    }
    @keyframes axp-authorize-action__module__floatin___b41UX {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 0.8;
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnLoading___2xrYY::before {
        will-change: transform;
        animation: axp-authorize-action__module__spinner-indeterminate___26ZME 0.8s linear infinite;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnLoading___2xrYY {
        overflow: hidden;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnLoading___2xrYY::before {
        border-style: solid;
        border-width: 2px;
        border-radius: 50%;
        bottom: 0;
        content: "";
        display: block;
        height: 22px;
        left: 0;
        margin: auto;
        position: absolute;
        right: 0;
        top: 0;
        transform: translateZ(0);
        width: 22px;
    }
    @keyframes axp-authorize-action__module__spinner-indeterminate___26ZME {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC,
    .axp-authorize-action__module__module___1n4eK button {
        border: 1px solid transparent;
        cursor: pointer;
        display: inline-block;
        font-weight: normal;
        max-width: 17.5rem;
        min-width: 11.25rem;
        overflow: hidden;
        position: relative;
        text-align: center;
        text-overflow: ellipsis;
        transition: all 0.2s ease-in-out;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        vertical-align: middle;
        white-space: nowrap;
        padding: 0.8125rem 1.875rem;
        font-size: 1rem;
        line-height: 1.375rem;
        border-radius: 0.25rem;
    }
    .axp-authorize-action__module__module___1n4eK div > .axp-authorize-action__module__btn___2FBnC:first-of-type:not(:last-of-type):not(.axp-authorize-action__module__btnBlock___2zdf9),
    .axp-authorize-action__module__module___1n4eK div > button:first-of-type:not(:last-of-type):not(.axp-authorize-action__module__btnBlock___2zdf9) {
        margin-right: 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK div > .axp-authorize-action__module__btn___2FBnC:not(:first-of-type):not(:last-of-type):not(.axp-authorize-action__module__btnBlock___2zdf9),
    .axp-authorize-action__module__module___1n4eK div > button:not(:first-of-type):not(:last-of-type):not(.axp-authorize-action__module__btnBlock___2zdf9) {
        margin-right: 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:last-of-type:not(:first-of-type),
    .axp-authorize-action__module__module___1n4eK button:last-of-type:not(:first-of-type) {
        margin-right: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:focus,
    .axp-authorize-action__module__module___1n4eK button:focus,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:hover,
    .axp-authorize-action__module__module___1n4eK button:hover {
        text-decoration: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:disabled,
    .axp-authorize-action__module__module___1n4eK button:disabled {
        box-shadow: none;
        cursor: not-allowed;
        background: #f7f8f9 !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:disabled::after,
    .axp-authorize-action__module__module___1n4eK button:disabled::after {
        border-color: #c8c9c7;
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnBlock___2zdf9 {
        display: block;
        width: 100%;
    }
    .axp-authorize-action__module__module___1n4eK a.axp-authorize-action__module__btn___2FBnC.axp-authorize-action__module__disabled___Sy-go,
    .axp-authorize-action__module__module___1n4eK fieldset[disabled] a.axp-authorize-action__module__btn___2FBnC {
        pointer-events: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnPrimary___12_Y9,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC,
    .axp-authorize-action__module__module___1n4eK button {
        color: #fff;
        background: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnPrimary___12_Y9:hover,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:hover,
    .axp-authorize-action__module__module___1n4eK button:hover {
        background: #1068a5;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnPrimary___12_Y9:active,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:active,
    .axp-authorize-action__module__module___1n4eK button:active {
        background: #0f6099;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnPrimary___12_Y9:disabled,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:disabled,
    .axp-authorize-action__module__module___1n4eK button:disabled,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnPrimary___12_Y9:disabled:focus,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btn___2FBnC:disabled:focus,
    .axp-authorize-action__module__module___1n4eK button:disabled:focus {
        border-color: #c8c9c7;
        background: #f7f8f9;
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnPrimary___12_Y9.axp-authorize-action__module__btnLoading___2xrYY::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnLoading___2xrYY.axp-authorize-action__module__btn___2FBnC::before,
    .axp-authorize-action__module__module___1n4eK button.axp-authorize-action__module__btnLoading___2xrYY::before {
        border-color: rgba(200, 201, 199, 0.25);
        border-left-color: #fff;
        border-style: solid;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnSecondary___3uTXK {
        color: #006fcf;
        background: #fff;
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnSecondary___3uTXK:hover {
        color: #006fcf;
        background: #e5e5e5;
        border-color: #3ea8e5;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnSecondary___3uTXK:active {
        color: #004683;
        background: #d4d4d4;
        border-color: #0061b6;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnSecondary___3uTXK.axp-authorize-action__module__btnLoading___2xrYY::before {
        border-color: rgba(200, 201, 199, 0.25);
        border-left-color: #006fcf;
        border-style: solid;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnTertiary___3EZW5 {
        color: #006fcf;
        background: transparent;
        border-color: transparent;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnTertiary___3EZW5:hover {
        color: #006fcf;
        background: rgba(0, 0, 0, 0.1);
        border-color: transparent;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnTertiary___3EZW5:active {
        color: #004683;
        background: rgba(0, 0, 0, 0.17);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__btnTertiary___3EZW5.axp-authorize-action__module__btnLoading___2xrYY::before {
        border-color: rgba(200, 201, 199, 0.25);
        border-left-color: #006fcf;
        border-style: solid;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__card___3_nqH {
        background: #fff;
        box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.1);
        height: 100%;
        position: relative;
        width: 100%;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__cardRounded___3wiBf {
        border: 1px solid #ecedee;
        border-radius: 4px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__caret___3eoDD {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__caret___3eoDD::before {
        font-family: "dls-icons";
        content: "";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        display: inline-block;
        position: relative;
        transform: rotate(0deg);
        transition: color 0.25s ease-out, transform 0.25s ease-out;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__carousel___2FEoy {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-flow: column nowrap;
        flex-flow: column nowrap;
        overflow: hidden;
        position: relative;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__carousel___2FEoy:focus {
        outline: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b {
        display: block;
        font-size: 0.9375rem;
        line-height: 1.375rem;
        padding-left: 1.375rem;
        position: relative;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b:not(:last-child) {
        margin-bottom: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"] {
        min-height: 0;
        opacity: 0;
        position: absolute;
        width: 0;
        z-index: 1;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:focus + label::before {
        outline: dotted 1px rgba(0, 0, 0, 0.3);
        outline-offset: 3px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:hover + label::before {
        background-color: #fff;
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:hover + label::after {
        color: #fff;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:checked + label:hover::before {
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:checked + label::before {
        background-color: #006fcf;
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:checked + label::after {
        color: #fff;
        visibility: visible;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:disabled + label {
        color: #97999b;
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:disabled + label::before {
        background-color: #f7f8f9;
        border-color: #c8c9c7;
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:disabled + label::after {
        color: #fff;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:disabled:checked + label a {
        text-decoration: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[type="checkbox"]:disabled:checked + label::before {
        background-color: rgba(0, 0, 0, 0.25);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b label {
        cursor: pointer;
        display: inline-block;
        font-weight: normal;
        line-height: 1.375rem;
        margin-bottom: 0;
        min-height: 1.375rem;
        padding-left: 0.625rem;
        position: relative;
        text-transform: inherit;
        vertical-align: middle;
        padding-left: 0.625rem;
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-size: 0.9375rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b label input:only-child {
        position: static;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b label::before {
        background-color: #fff;
        border: 1px solid #c8c9c7;
        border-radius: 0.25rem;
        content: "";
        display: inline-block;
        height: 1.375rem;
        left: 0;
        margin-left: -1.375rem;
        position: absolute;
        transition: border 0.25s ease-out, background-color 0.25s ease-out;
        width: 1.375rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b label::after {
        font-family: "dls-icons";
        content: "";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        -ms-flex-align: center;
        align-items: center;
        display: -ms-flexbox;
        display: flex;
        font-size: 0.84375rem;
        height: 1.375rem;
        -ms-flex-pack: center;
        justify-content: center;
        left: 0;
        line-height: 1.375rem;
        margin-left: -1.375rem;
        position: absolute;
        top: 0;
        width: 1.375rem;
        visibility: hidden;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"] + label,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"] + label a {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"] + label::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"] + label a::before {
        background-color: #fff;
        border-color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"] + label a {
        text-decoration: underline;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"]:checked + label {
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"]:checked + label a {
        color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"]:checked + label a:not(:hover) {
        text-decoration: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__checkbox___3F-9b input[aria-invalid="true"]:hover + label::before {
        border-color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__collapsible___3PIJ2 {
        color: #000;
        cursor: pointer;
        padding: 15px 20px;
        transition: background-color 0.25s ease-in-out;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__collapsible___3PIJ2:hover:not(.axp-authorize-action__module__expandableLink___32HAt) {
        background-color: rgba(151, 153, 155, 0.08);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__collapsible___3PIJ2:focus {
        outline: dotted 1px rgba(0, 0, 0, 0.3);
        outline-offset: 3px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsAccentWhite01Bg___20ZPZ {
        background-color: #fff !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsAccentGray04___19bVn {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsAccentGreen01___1lHnm {
        color: #008767;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsAccentRed01___s7Z-0 {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="copyfield"].axp-authorize-action__module__success___3rH9L .axp-authorize-action__module__alert___1KJ5T.axp-authorize-action__module__success___3rH9L {
        display: block;
        color: #008767;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="copyfield"].axp-authorize-action__module__warning___2YmUh label {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="copyfield"].axp-authorize-action__module__warning___2YmUh .axp-authorize-action__module__alert___1KJ5T.axp-authorize-action__module__warning___2YmUh {
        display: block;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY .axp-authorize-action__module__currencyField___3zMl-::before,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY .axp-authorize-action__module__currencyField___3zMl-::after,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY.axp-authorize-action__module__currencyField___3zMl-::before,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY.axp-authorize-action__module__currencyField___3zMl-::after {
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY.axp-authorize-action__module__currencyField___3zMl- input {
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY .axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formUnit___3mhhV,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__focus___3z4AY.axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formUnit___3mhhV {
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__currencyField___3zMl-::before,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__currencyField___3zMl-::after,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9.axp-authorize-action__module__currencyField___3zMl-::before,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9.axp-authorize-action__module__currencyField___3zMl-::after {
        border-color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9.axp-authorize-action__module__currencyField___3zMl- input {
        border-color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formUnit___3mhhV,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__hasWarning___1A4e9.axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formUnit___3mhhV {
        border-color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go .axp-authorize-action__module__currencyField___3zMl-::before,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go .axp-authorize-action__module__currencyField___3zMl-::after,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go.axp-authorize-action__module__currencyField___3zMl-::before,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go.axp-authorize-action__module__currencyField___3zMl-::after,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"]:disabled::before,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"]:disabled::after {
        border-color: #c8c9c7;
        color: #97999b;
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go.axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"]:disabled input {
        border-color: #c8c9c7;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go .axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formUnit___3mhhV,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"].axp-authorize-action__module__disabled___Sy-go.axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formUnit___3mhhV,
    .axp-authorize-action__module__module___1n4eK [data-toggle="currencyfield"]:disabled .axp-authorize-action__module__formUnit___3mhhV {
        border-color: #c8c9c7;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl- {
        display: -ms-flexbox;
        display: flex;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formControl___YgWbK {
        text-align: right;
        border-width: 1px;
        border-style: solid;
        border-radius: 0.25rem;
        border-color: #c8c9c7;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        -ms-flex: 1;
        flex: 1;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl- .axp-authorize-action__module__formUnit___3mhhV {
        color: #000;
        background-color: #fff;
        padding: 0 0.9375rem;
        margin: 0;
        vertical-align: middle;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        font-size: 1rem;
        font-weight: normal;
        border-width: 1px;
        border-style: solid;
        border-radius: 0.25rem;
        border-color: #c8c9c7;
        display: inherit;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex: none;
        flex: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyFieldLeft___2dk1s .axp-authorize-action__module__formControl___YgWbK {
        border-bottom-left-radius: 0;
        border-top-left-radius: 0;
        border-left: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyFieldLeft___2dk1s .axp-authorize-action__module__formUnit___3mhhV {
        border-bottom-right-radius: 0;
        border-top-right-radius: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyFieldRight___1WwKF {
        -ms-flex-direction: row-reverse;
        flex-direction: row-reverse;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyFieldRight___1WwKF .axp-authorize-action__module__formControl___YgWbK {
        border-bottom-right-radius: 0;
        border-top-right-radius: 0;
        border-right: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyFieldRight___1WwKF .axp-authorize-action__module__formUnit___3mhhV {
        border-bottom-left-radius: 0;
        border-top-left-radius: 0;
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="en-US"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-US"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="en-EI"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-EI"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="en-CA"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-CA"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="en-AR"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-AR"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="en-AU"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-AU"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="en-NZ"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-NZ"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="es-MX"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="es-MX"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "$";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="zh-HK"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="zh-HK"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="en-HK"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-HK"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "HK$";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="en-IN"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-IN"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "₹";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="ja-JP"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="ja-JP"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "¥";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="ms-MY"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="ms-MY"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "RM";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="en-PH"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-PH"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "Php";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="pt-BR"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="pt-BR"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "R$";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="en-GB"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-GB"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "£";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="en-SG"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-SG"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "SGD";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="de-DE"] .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="de-DE"] input,
    .axp-authorize-action__module__module___1n4eK [data-currency="sv-SE"] .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="sv-SE"] input,
    .axp-authorize-action__module__module___1n4eK [data-currency="fr-CA"] .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="fr-CA"] input,
    .axp-authorize-action__module__module___1n4eK [data-currency="sv-FI"] .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="sv-FI"] input,
    .axp-authorize-action__module__module___1n4eK [data-currency="fi-FI"] .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="fi-FI"] input,
    .axp-authorize-action__module__module___1n4eK [data-currency="es-ES"] .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="es-ES"] input,
    .axp-authorize-action__module__module___1n4eK [data-currency="da-DK"] .axp-authorize-action__module__currencyField___3zMl- input,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="da-DK"] input {
        border-radius: 0.25rem 0 0 0.25rem;
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="sv-SE"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="sv-SE"]:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK [data-currency="da-DK"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="da-DK"]:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after {
        content: "kr";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="en-EU"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="en-EU"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="de-AT"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="de-AT"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK [data-currency="nl-NL"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="nl-NL"]:not(.axp-authorize-action__module__currencyFieldLeft___2dk1s)::before {
        content: "€";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="de-DE"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="de-DE"]:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK [data-currency="es-ES"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="es-ES"]:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK [data-currency="fi-FI"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="fi-FI"]:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK [data-currency="sv-FI"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="sv-FI"]:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after {
        content: "€";
    }
    .axp-authorize-action__module__module___1n4eK [data-currency="fr-CA"] .axp-authorize-action__module__currencyField___3zMl-:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__currencyField___3zMl-[data-currency="fr-CA"]:not(.axp-authorize-action__module__currencyFieldRight___1WwKF)::after {
        content: "$";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK {
        -webkit-appearance: none;
        background-color: #f7f8f9;
        border: 1px solid #c8c9c7;
        border-radius: 0.25rem;
        color: #000;
        display: block;
        font-size: 1rem;
        line-height: 1.375rem;
        min-height: 3.125rem;
        padding: 0 0.625rem;
        transition: border-color 0.25s ease-out;
        width: 100%;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-ms-expand {
        background-color: transparent;
        border: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-webkit-input-placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:-ms-input-placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:-ms-input-placeholder {
        color: #97999b !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-ms-clear {
        display: none;
        width: 0;
        height: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:focus {
        border-color: #006fcf;
        outline: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK.axp-authorize-action__module__disabled___Sy-go,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:disabled {
        background-color: #f7f8f9;
        border-color: #c8c9c7;
        opacity: 1;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlSuccess___2zdHp,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-position: center right 0.78125rem;
        background-repeat: no-repeat;
        background-size: 1.71875rem;
        padding-right: 3.125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlSuccess___2zdHp {
        background-image: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../img/svg/icon/green/dls-icon-success.svg);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__formControl___YgWbK,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-color: #fbefec;
        border-color: #b42c01;
        color: inherit;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-image: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../img/svg/icon/red/dls-icon-warning-filled.svg);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 + .axp-authorize-action__module__alertForm___1FKPS {
        display: block;
    }
    .axp-authorize-action__module__module___1n4eK textarea.axp-authorize-action__module__formControl___YgWbK {
        font-size: 0.9375rem;
        padding: 0.9375rem 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK label {
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-weight: 500;
        font-size: 0.8125rem;
        line-height: 1.125rem;
        text-transform: uppercase;
        color: #000;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 label {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK legend {
        margin-bottom: 0.5rem;
        font-size: 0.875rem;
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 legend {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK fieldset > input:not(:last-child) {
        margin-bottom: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK *,
    .axp-authorize-action__module__module___1n4eK *::before,
    .axp-authorize-action__module__module___1n4eK *::after {
        box-sizing: inherit;
    }
    .axp-authorize-action__module__module___1n4eK html {
        box-sizing: border-box;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
        margin-left: auto;
        margin-right: auto;
        padding-left: 10px;
        padding-right: 10px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        margin-left: -5px;
        margin-right: -5px;
    }
    .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
    .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
        position: relative;
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
        min-height: 1px;
    }
    .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
    .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
        padding-left: 5px;
        padding-right: 5px;
    }
    @media (min-width: 375px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 12px;
            padding-right: 12px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 576px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -6px;
            margin-right: -6px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 6px;
            padding-right: 6px;
        }
    }
    @media (min-width: 768px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 18px;
            padding-right: 18px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 720px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -9px;
            margin-right: -9px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 9px;
            padding-right: 9px;
        }
    }
    @media (min-width: 1024px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 20px;
            padding-right: 20px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 940px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -10px;
            margin-right: -10px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 10px;
            padding-right: 10px;
        }
    }
    @media (min-width: 1280px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 20px;
            padding-right: 20px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 1240px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -10px;
            margin-right: -10px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 10px;
            padding-right: 10px;
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__glyph___2mozS,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__icon___gz_vG {
        display: inline-block;
        line-height: 1;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__glyph___2mozS::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__icon___gz_vG::before {
        -webkit-font-smoothing: antialiased;
        -webkit-text-stroke: 0;
        -moz-osx-font-smoothing: grayscale;
        -webkit-backface-visibility: hidden;
        backface-visibility: hidden;
        display: block;
        font-family: "dls-icons";
        font-style: normal;
        font-weight: normal;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        letter-spacing: 0;
        position: relative;
        speak: none;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__glyph___2mozS:hover,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__icon___gz_vG:hover {
        text-decoration: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__glyph___2mozS::before {
        font-size: 1rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__icon___gz_vG::before {
        font-size: 1.75rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__iconXl___2iasb::before {
        font-size: 3.875rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__iconHover___3yRSd:hover {
        cursor: pointer;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconInfo___2fYfZ::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconInfo___2fYfZ.axp-authorize-action__module__iconHover___3yRSd:hover::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconSuccess___29f51::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconSuccess___29f51.axp-authorize-action__module__iconHover___3yRSd:hover::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconWarning___3e4-t::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconWarning___3e4-t.axp-authorize-action__module__iconHover___3yRSd:hover::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconHide___3OI23::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconHide___3OI23.axp-authorize-action__module__iconHover___3yRSd:hover::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconShow___1v-IS::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__dlsIconShow___1v-IS.axp-authorize-action__module__iconHover___3yRSd:hover::before {
        content: "";
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__flex___2K-F0 {
        display: -ms-flexbox !important;
        display: flex !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__flexAlignCenter___gRPvt {
        -ms-flex-align: center !important;
        align-items: center !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__flexJustifyCenter___2_igi {
        -ms-flex-pack: center !important;
        justify-content: center !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__flexColumn___1F-os {
        -ms-flex-direction: column !important;
        flex-direction: column !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__displayBlock___2bXUm {
        display: block !important;
        speak: normal;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hidden___2QhvF {
        display: none !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__visible___3M5Tv {
        opacity: 1;
        visibility: visible !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__fluid___2qVuO {
        width: 100% !important;
        max-width: none !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__individual___2P8uX {
        speak: spell-out;
        word-spacing: -0.25em;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__list___19Mtz {
        padding: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__marginT___2lS5e {
        margin-top: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__marginB___PIapF {
        margin-bottom: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__marginAutoLr___1TUFz {
        margin-left: auto !important;
        margin-right: auto !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__margin0___1GSEf {
        margin: 0 !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__margin0B___3oEba {
        margin-bottom: 0 !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__margin0Lr___2fbcb {
        margin-left: 0 !important;
        margin-right: 0 !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__margin0Tb___vdnFW {
        margin-top: 0 !important;
        margin-bottom: 0 !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__margin1T___3sIu4 {
        margin-top: 0.625rem !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__margin1B___1kMH2 {
        margin-bottom: 0.625rem !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__modal___namlL {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 201;
        overflow: hidden;
        outline: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__modalContent___18rbc {
        background-color: #fff;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__nav___32IWG {
        z-index: 99;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__nav___32IWG {
        list-style: none;
        padding-left: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__nav___32IWG ul,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__nav___32IWG li {
        padding: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__nav___32IWG[aria-current="vertical"] .axp-authorize-action__module__accordion___3B336 {
        position: relative;
    }
    .axp-authorize-action__module__module___1n4eK _:-ms-fullscreen {
        opacity: 0.99 !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__pad___2j3B3 {
        padding: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__pad1R___2ZwUT {
        padding-right: 0.625rem !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progress___2ZGZk {
        display: block;
        position: relative;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="0"] {
        counter-reset: count 0;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="1"] {
        counter-reset: count 1;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="2"] {
        counter-reset: count 2;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="3"] {
        counter-reset: count 3;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="4"] {
        counter-reset: count 4;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="5"] {
        counter-reset: count 5;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="6"] {
        counter-reset: count 6;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="7"] {
        counter-reset: count 7;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="8"] {
        counter-reset: count 8;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="9"] {
        counter-reset: count 9;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="10"] {
        counter-reset: count 10;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="11"] {
        counter-reset: count 11;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="12"] {
        counter-reset: count 12;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="13"] {
        counter-reset: count 13;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="14"] {
        counter-reset: count 14;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="15"] {
        counter-reset: count 15;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="16"] {
        counter-reset: count 16;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="17"] {
        counter-reset: count 17;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="18"] {
        counter-reset: count 18;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="19"] {
        counter-reset: count 19;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="20"] {
        counter-reset: count 20;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="21"] {
        counter-reset: count 21;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="22"] {
        counter-reset: count 22;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="23"] {
        counter-reset: count 23;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="24"] {
        counter-reset: count 24;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="25"] {
        counter-reset: count 25;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="26"] {
        counter-reset: count 26;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="27"] {
        counter-reset: count 27;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="28"] {
        counter-reset: count 28;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="29"] {
        counter-reset: count 29;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="30"] {
        counter-reset: count 30;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="31"] {
        counter-reset: count 31;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="32"] {
        counter-reset: count 32;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="33"] {
        counter-reset: count 33;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="34"] {
        counter-reset: count 34;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="35"] {
        counter-reset: count 35;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="36"] {
        counter-reset: count 36;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="37"] {
        counter-reset: count 37;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="38"] {
        counter-reset: count 38;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="39"] {
        counter-reset: count 39;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="40"] {
        counter-reset: count 40;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="41"] {
        counter-reset: count 41;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="42"] {
        counter-reset: count 42;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="43"] {
        counter-reset: count 43;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="44"] {
        counter-reset: count 44;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="45"] {
        counter-reset: count 45;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="46"] {
        counter-reset: count 46;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="47"] {
        counter-reset: count 47;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="48"] {
        counter-reset: count 48;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="49"] {
        counter-reset: count 49;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="50"] {
        counter-reset: count 50;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="51"] {
        counter-reset: count 51;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="52"] {
        counter-reset: count 52;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="53"] {
        counter-reset: count 53;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="54"] {
        counter-reset: count 54;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="55"] {
        counter-reset: count 55;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="56"] {
        counter-reset: count 56;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="57"] {
        counter-reset: count 57;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="58"] {
        counter-reset: count 58;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="59"] {
        counter-reset: count 59;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="60"] {
        counter-reset: count 60;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="61"] {
        counter-reset: count 61;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="62"] {
        counter-reset: count 62;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="63"] {
        counter-reset: count 63;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="64"] {
        counter-reset: count 64;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="65"] {
        counter-reset: count 65;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="66"] {
        counter-reset: count 66;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="67"] {
        counter-reset: count 67;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="68"] {
        counter-reset: count 68;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="69"] {
        counter-reset: count 69;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="70"] {
        counter-reset: count 70;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="71"] {
        counter-reset: count 71;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="72"] {
        counter-reset: count 72;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="73"] {
        counter-reset: count 73;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="74"] {
        counter-reset: count 74;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="75"] {
        counter-reset: count 75;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="76"] {
        counter-reset: count 76;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="77"] {
        counter-reset: count 77;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="78"] {
        counter-reset: count 78;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="79"] {
        counter-reset: count 79;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="80"] {
        counter-reset: count 80;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="81"] {
        counter-reset: count 81;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="82"] {
        counter-reset: count 82;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="83"] {
        counter-reset: count 83;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="84"] {
        counter-reset: count 84;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="85"] {
        counter-reset: count 85;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="86"] {
        counter-reset: count 86;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="87"] {
        counter-reset: count 87;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="88"] {
        counter-reset: count 88;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="89"] {
        counter-reset: count 89;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="90"] {
        counter-reset: count 90;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="91"] {
        counter-reset: count 91;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="92"] {
        counter-reset: count 92;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="93"] {
        counter-reset: count 93;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="94"] {
        counter-reset: count 94;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="95"] {
        counter-reset: count 95;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="96"] {
        counter-reset: count 96;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="97"] {
        counter-reset: count 97;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="98"] {
        counter-reset: count 98;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="99"] {
        counter-reset: count 99;
    }
    .axp-authorize-action__module__module___1n4eK [data-count="100"] {
        counter-reset: count 100;
    }
    @keyframes axp-authorize-action__module__bar-indeterminate___WGAay {
        0% {
            left: -35%;
            right: 100%;
        }
        60% {
            left: 100%;
            right: -90%;
        }
        100% {
            left: 100%;
            right: -90%;
        }
    }
    @keyframes axp-authorize-action__module__bar-indeterminate-short___3raYa {
        0% {
            left: -200%;
            right: 100%;
        }
        60% {
            left: 107%;
            right: -8%;
        }
        100% {
            left: 107%;
            right: -8%;
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O::before {
        will-change: transform;
        animation: axp-authorize-action__module__spinner-indeterminate___26ZME 0.8s linear infinite;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf {
        display: block;
        position: relative;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O {
        -ms-flex-align: center;
        align-items: center;
        display: -ms-inline-flexbox;
        display: inline-flex;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O::before {
        content: "";
        border-style: solid;
        border-color: rgba(200, 201, 199, 0.25);
        border-left-color: #006fcf;
        border-radius: 50%;
        display: block;
        position: relative;
        transform: translateZ(0);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O::before {
        border-width: 4px;
        height: 50px;
        width: 50px;
    }
    @keyframes axp-authorize-action__module__spinner-indeterminate___26ZME {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ {
        display: block;
        font-size: 0.9375rem;
        line-height: 1.375rem;
        padding-left: 1.375rem;
        position: relative;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ:not(:last-child) {
        margin-bottom: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"] {
        min-height: 0;
        margin-left: -1.25rem;
        margin-top: 0.25rem;
        position: absolute;
        opacity: 0;
        width: 0;
        z-index: 1;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:hover + label {
        color: inherit;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:hover + label::before {
        background-color: #fff;
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:hover + label::after {
        background-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:focus + label::before {
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:checked + label {
        color: inherit;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:checked + label::before {
        background-color: #fff;
        border-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:checked + label::after {
        background-color: #006fcf;
        opacity: 1 !important;
        transform: scale(1) !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:disabled + label {
        color: #97999b;
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:disabled + label::before {
        background-color: rgba(0, 0, 0, 0.05);
        border-color: #c8c9c7;
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"]:disabled + label::after {
        background-color: rgba(0, 0, 0, 0.3);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"][aria-invalid="true"]:checked + label {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"][aria-invalid="true"]:checked + label::before {
        background-color: #fff;
        border-color: #b42c01;
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ input[type="radio"][aria-invalid="true"]:checked + label::after {
        background-color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ label {
        padding-left: 0.375rem;
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-size: 0.9375rem;
        color: inherit;
        cursor: pointer;
        display: inline-block;
        font-weight: normal;
        line-height: 1.375rem;
        margin-bottom: 0;
        min-height: 1.375rem;
        padding-left: 0.625rem;
        position: relative;
        text-transform: inherit;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ label::before {
        background-color: #fff;
        border: 1px solid #97999b;
        border-radius: 50%;
        content: "";
        display: inline-block;
        height: 1.375rem;
        left: 0;
        margin-left: -1.375rem;
        position: absolute;
        transition: border 0.25s ease-out;
        width: 1.375rem;
        will-change: border;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__radio___2EfEQ label::after {
        background-color: #006fcf;
        border-radius: 50%;
        content: "";
        display: inline-block;
        height: 0.875rem;
        left: 0.25rem;
        margin-left: -1.375rem;
        position: absolute;
        top: 0.25rem;
        transform: scale(0);
        transition: transform 0.25s ease-out, opacity 0.25s ease-out;
        width: 0.875rem;
        will-change: transform, opacity;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__required___BjG8c::after {
        color: #b42c01;
        content: "*";
        font-family: "verdana";
        font-size: 20px;
        font-weight: 600;
        padding: 3px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__required___BjG8c::after,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__required___BjG8c.axp-authorize-action__module__hasWarning___1A4e9::after {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK {
        -webkit-appearance: none;
        background-color: #f7f8f9;
        border: 1px solid #c8c9c7;
        border-radius: 0.25rem;
        color: #000;
        display: block;
        font-size: 1rem;
        line-height: 1.375rem;
        min-height: 3.125rem;
        padding: 0 0.625rem;
        transition: border-color 0.25s ease-out;
        width: 100%;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-ms-expand {
        background-color: transparent;
        border: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-webkit-input-placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:-ms-input-placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:-ms-input-placeholder {
        color: #97999b !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-ms-clear {
        display: none;
        width: 0;
        height: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:focus {
        border-color: #006fcf;
        outline: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK.axp-authorize-action__module__disabled___Sy-go,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:disabled {
        background-color: #f7f8f9;
        border-color: #c8c9c7;
        opacity: 1;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlSuccess___2zdHp,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-position: center right 0.78125rem;
        background-repeat: no-repeat;
        background-size: 1.71875rem;
        padding-right: 3.125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlSuccess___2zdHp {
        background-image: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../img/svg/icon/green/dls-icon-success.svg);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__formControl___YgWbK,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-color: #fbefec;
        border-color: #b42c01;
        color: inherit;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-image: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../img/svg/icon/red/dls-icon-warning-filled.svg);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 + .axp-authorize-action__module__alertForm___1FKPS {
        display: block;
    }
    .axp-authorize-action__module__module___1n4eK textarea.axp-authorize-action__module__formControl___YgWbK {
        font-size: 0.9375rem;
        padding: 0.9375rem 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK label {
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-weight: 500;
        font-size: 0.8125rem;
        line-height: 1.125rem;
        text-transform: uppercase;
        color: #000;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 label {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK legend {
        margin-bottom: 0.5rem;
        font-size: 0.875rem;
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 legend {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK fieldset > input:not(:last-child) {
        margin-bottom: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O::before {
        will-change: transform;
        animation: axp-authorize-action__module__spinner-indeterminate___26ZME 0.8s linear infinite;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf {
        display: block;
        position: relative;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O {
        -ms-flex-align: center;
        align-items: center;
        display: -ms-inline-flexbox;
        display: inline-flex;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O::before {
        content: "";
        border-style: solid;
        border-color: rgba(200, 201, 199, 0.25);
        border-left-color: #006fcf;
        border-radius: 50%;
        display: block;
        position: relative;
        transform: translateZ(0);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__progressCircle___1gYYf.axp-authorize-action__module__progressIndeterminate___on09O::before {
        border-width: 4px;
        height: 50px;
        width: 50px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC {
        position: relative;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > input {
        padding-right: 2.8125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > input:focus + button {
        color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > input::-ms-clear {
        display: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > input .axp-authorize-action__module__disabled___Sy-go + button {
        color: #c8c9c7 !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > button {
        min-width: 0;
        max-width: none;
        padding: 0;
        margin: 0;
        border-radius: 0;
        border: 0;
        color: inherit;
        background-color: transparent;
        font-size: inherit;
        text-align: inherit;
        -ms-flex-align: center;
        align-items: center;
        bottom: 0;
        color: #53565a;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-pack: center;
        justify-content: center;
        position: absolute;
        right: 0;
        text-align: center;
        top: 0;
        max-height: 50px;
        width: 2.8125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > button:hover {
        background-color: transparent;
        color: inherit;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > button:active {
        background-color: transparent;
        color: inherit;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC > button::before {
        display: block;
        font-family: "dls-icons";
        content: "";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        font-size: 1.375rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC[data-state="default"] > button:focus::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC[data-state="default"] > button:active::before {
        font-family: "dls-icons";
        content: "";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        font-size: 1.375rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC[data-state="searching"] > button {
        cursor: default;
        position: absolute;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC[data-state="active"] > button {
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__search___1LKoC[data-state="active"][data-clearFieldButton="true"] > button::before {
        font-family: "dls-icons";
        content: "";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        font-size: 0.875rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__searchResults___2nM8f {
        position: absolute;
        background-color: #fff;
        border: 1px solid #ecedee;
        border-radius: 0.25rem;
        z-index: 98;
        width: 100%;
        padding: 0;
        margin: 0.1875rem 0 0;
        font-size: 0.9375rem;
        color: #000;
        text-align: left;
        list-style: none;
        background-clip: padding-box;
        visibility: hidden;
        transition: opacity 0.25s ease-out, visibility 0.25s ease-out;
        will-change: opacity, visibilty;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__searchResults___2nM8f:not(:empty) {
        visibility: visible;
    }
    @keyframes axp-authorize-action__module__spinner-indeterminate___26ZME {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D {
        display: -ms-flexbox;
        display: flex;
        max-width: 18.75rem;
        overflow: hidden;
        position: relative;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D[data-text]::before {
        content: attr(data-text);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D[data-text]:not([data-value])::before {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D::before {
        display: block;
        content: attr(data-value);
        top: 0;
        left: 0;
        margin: 0.75rem 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        width: calc(100% - 2rem);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D::after {
        font-family: "dls-icons";
        content: "";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        color: #53565a;
        position: absolute;
        top: 0;
        right: 0;
        margin: 1rem 0.5rem;
        padding: 0 !important;
        transition: color 0.25s ease-out;
        font-size: 1.0625rem;
        font-weight: normal !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__focus___3z4AY {
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__focus___3z4AY::before {
        outline: dotted 1px rgba(0, 0, 0, 0.3);
        outline-offset: 3px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D[disabled] {
        cursor: not-allowed;
        color: #97999b;
        border-color: #c8c9c7;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D[disabled]::after {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D[disabled] * {
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControl___YgWbK {
        display: -ms-flexbox;
        display: flex;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControlSuccess___2zdHp,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControlWarning___2uEr0 {
        padding-right: 0.625rem;
        background-color: #f7f8f9;
        background-image: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControlWarning___2uEr0 {
        background-color: #f7f8f9;
        background-image: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControlWarning___2uEr0::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControlWarning___2uEr0::after {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__select___3-j5D select {
        appearance: none;
        -moz-appearance: none;
        -webkit-appearance: none;
        background: transparent;
        border: 0;
        cursor: pointer;
        font-size: 1rem;
        height: 100%;
        opacity: 0;
        width: 100%;
        z-index: 1;
        position: absolute;
        top: 0;
        bottom: 0;
        right: 0;
        left: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControl___YgWbK {
        background-color: #f7f8f9;
        background-image: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControl___YgWbK::before,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__select___3-j5D.axp-authorize-action__module__formControl___YgWbK::after {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK _:-ms-fullscreen,
    .axp-authorize-action__module__module___1n4eK :root .axp-authorize-action__module__select___3-j5D {
        height: 3.125rem;
        -ms-flex-align: center;
        align-items: center;
        overflow: visible;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__slider___266gX {
        display: block;
        position: relative;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK {
        -webkit-appearance: none;
        background-color: #f7f8f9;
        border: 1px solid #c8c9c7;
        border-radius: 0.25rem;
        color: #000;
        display: block;
        font-size: 1rem;
        line-height: 1.375rem;
        min-height: 3.125rem;
        padding: 0 0.625rem;
        transition: border-color 0.25s ease-out;
        width: 100%;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-ms-expand {
        background-color: transparent;
        border: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-webkit-input-placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:-ms-input-placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::placeholder {
        color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:-ms-input-placeholder {
        color: #97999b !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK::-ms-clear {
        display: none;
        width: 0;
        height: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:focus {
        border-color: #006fcf;
        outline: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK.axp-authorize-action__module__disabled___Sy-go,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControl___YgWbK:disabled {
        background-color: #f7f8f9;
        border-color: #c8c9c7;
        opacity: 1;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlSuccess___2zdHp,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-position: center right 0.78125rem;
        background-repeat: no-repeat;
        background-size: 1.71875rem;
        padding-right: 3.125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlSuccess___2zdHp {
        background-image: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../img/svg/icon/green/dls-icon-success.svg);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 .axp-authorize-action__module__formControl___YgWbK,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-color: #fbefec;
        border-color: #b42c01;
        color: inherit;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 {
        background-image: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../img/svg/icon/red/dls-icon-warning-filled.svg);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formControlWarning___2uEr0 + .axp-authorize-action__module__alertForm___1FKPS {
        display: block;
    }
    .axp-authorize-action__module__module___1n4eK textarea.axp-authorize-action__module__formControl___YgWbK {
        font-size: 0.9375rem;
        padding: 0.9375rem 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK label {
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-weight: 500;
        font-size: 0.8125rem;
        line-height: 1.125rem;
        text-transform: uppercase;
        color: #000;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 label {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK legend {
        margin-bottom: 0.5rem;
        font-size: 0.875rem;
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__hasWarning___1A4e9 legend {
        color: #b42c01;
    }
    .axp-authorize-action__module__module___1n4eK fieldset > input:not(:last-child) {
        margin-bottom: 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK [data-toggle="smsfield"].axp-authorize-action__module__required___BjG8c::after {
        content: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__stepper___2ApBi {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-flow: row nowrap;
        flex-flow: row nowrap;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__switch___hwH0Q {
        background-color: #97999b;
        border-radius: 0.9375rem;
        cursor: pointer;
        padding: 0.125rem;
        height: 1.625rem;
        position: relative;
        transition: background-color 0.15s ease-in-out;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        width: 2.875rem;
        box-sizing: content-box;
        outline: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__switch___hwH0Q::before {
        content: "";
        position: absolute;
        top: -0.125rem;
        bottom: -0.125rem;
        left: -0.125rem;
        right: -0.125rem;
        border-width: 0.0625rem;
        border-style: dotted;
        border-radius: 1.0625rem;
        border-color: transparent;
        transition: border-color 0.15s ease-in-out;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        pointer-events: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__switch___hwH0Q:focus::before {
        border-color: #97999b;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__switch___hwH0Q[aria-checked="true"],
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__switch___hwH0Q.axp-authorize-action__module__active___2HXZt {
        background-color: #006fcf;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__switch___hwH0Q[aria-disabled="true"],
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__switch___hwH0Q.axp-authorize-action__module__disabled___Sy-go {
        background-color: #c8c9c7;
        cursor: not-allowed;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR {
        background-color: #fff;
        max-width: 100%;
        padding: 0;
        width: 100%;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
        line-height: 1.375rem;
        vertical-align: top;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th[data-title]::before {
        content: attr(data-title);
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
        vertical-align: middle;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR .axp-authorize-action__module__icon___gz_vG {
        font-size: 0.9375rem;
        line-height: 0.5;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR tr {
        border-bottom: 1px solid #ecedee;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR thead {
        background-color: #f7f8f9;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR thead th {
        vertical-align: bottom;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR thead th {
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-weight: 500;
        font-size: 0.8125rem;
        line-height: 1.125rem;
        text-transform: uppercase;
        color: #53565a;
        margin-bottom: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
        padding: 0.625rem 0.3125rem 0.625rem 0.3125rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:first-child,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:first-child {
        padding-left: 0.625rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:last-child,
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:last-child {
        padding-right: 0.625rem;
    }
    @media (min-width: 375px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
            padding: 0.625rem 0.375rem 0.625rem 0.375rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:first-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:first-child {
            padding-left: 0.75rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:last-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:last-child {
            padding-right: 0.75rem;
        }
    }
    @media (min-width: 768px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
            padding: 0.9375rem 0.5625rem 0.9375rem 0.5625rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:first-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:first-child {
            padding-left: 1.125rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:last-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:last-child {
            padding-right: 1.125rem;
        }
    }
    @media (min-width: 1024px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
            padding: 0.9375rem 0.625rem 0.9375rem 0.625rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:first-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:first-child {
            padding-left: 1.25rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:last-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:last-child {
            padding-right: 1.25rem;
        }
    }
    @media (min-width: 1280px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td {
            padding: 0.9375rem 0.625rem 0.9375rem 0.625rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:first-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:first-child {
            padding-left: 1.25rem;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR th:last-child,
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__table___1bvxR td:last-child {
            padding-right: 1.25rem;
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tabs___2kQ-1 {
        border: 0;
        display: block;
        position: relative;
        width: 100%;
        max-width: 1024px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tabs___2kQ-1[aria-current="mobile"] select {
        -moz-appearance: none;
        height: 3rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tabs___2kQ-1[aria-current="mobile"] select:focus::-ms-value {
        background-color: transparent;
        color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tabs___2kQ-1[aria-current="mobile"] select::-ms-expand {
        display: none;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tags___2VxvE {
        list-style: none;
        margin-bottom: 0;
        padding-left: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__textUppercase___1Y-k9 {
        text-transform: uppercase !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__textAlignCenter___3pwed {
        text-align: center !important;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tooltip___i8Qk8 {
        box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.25);
        border: transparent;
        color: #fff;
        display: block;
        visibility: hidden;
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-size: 0.9375rem;
        font-weight: 400;
        line-height: 1.375rem;
        line-height: 1.2;
        letter-spacing: normal;
        line-break: auto;
        min-width: 130px;
        max-width: 200px;
        opacity: 0;
        transition: opacity 0.15s;
        will-change: opacity;
        padding: 0.6875rem;
        text-align: center;
        text-decoration: none;
        text-shadow: none;
        text-transform: none;
        position: absolute;
        top: 0;
        left: 0;
        white-space: normal;
        word-break: normal;
        word-spacing: normal;
        word-wrap: normal;
        z-index: 99;
    }
    .axp-authorize-action__module__module___1n4eK
        .axp-authorize-action__module__tooltip___i8Qk8:not(.axp-authorize-action__module__tooltipTrend___1uW_9):not(.axp-authorize-action__module__tooltipWhite___3Cxqh):not(.axp-authorize-action__module__tooltipInfo___25vE_):not(.axp-authorize-action__module__tooltipLight___1PXeS):not(.axp-authorize-action__module__tooltipPrimary___1xu0Y) {
        background-color: #53565a;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tooltip___i8Qk8:not(.axp-authorize-action__module__tooltipInfo___25vE_) .axp-authorize-action__module__tooltipInner___1CT9M {
        padding: 0.9375rem 1.25rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tooltip___i8Qk8[tooltip-placement="right"] {
        margin-right: -0.4375rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tooltip___i8Qk8[tooltip-placement="left"] {
        margin-left: -0.4375rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tooltipInner___1CT9M {
        border-radius: 0.25rem;
        visibility: visible;
        white-space: normal;
        word-wrap: break-word;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tooltipInner___1CT9M {
        background-color: inherit;
        border: 1px solid transparent;
        border-color: inherit;
        box-shadow: inherit;
    }
    @media (max-width: 374px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__tooltip___i8Qk8 {
            max-width: 100%;
        }
    }
    .axp-authorize-action__module__module___1n4eK html {
        font-size: 100%;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    .axp-authorize-action__module__module___1n4eK body {
        color: #000;
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-size: 0.9375rem;
        font-weight: 400;
        line-height: 1.375rem;
    }
    .axp-authorize-action__module__module___1n4eK strong,
    .axp-authorize-action__module__module___1n4eK b {
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-weight: 500;
    }
    .axp-authorize-action__module__module___1n4eK h1,
    .axp-authorize-action__module__module___1n4eK h2,
    .axp-authorize-action__module__module___1n4eK h3,
    .axp-authorize-action__module__module___1n4eK h4,
    .axp-authorize-action__module__module___1n4eK h5,
    .axp-authorize-action__module__module___1n4eK h6 {
        font-weight: 500;
    }
    .axp-authorize-action__module__module___1n4eK h1,
    .axp-authorize-action__module__module___1n4eK h2,
    .axp-authorize-action__module__module___1n4eK h3,
    .axp-authorize-action__module__module___1n4eK h4,
    .axp-authorize-action__module__module___1n4eK h5,
    .axp-authorize-action__module__module___1n4eK h6,
    .axp-authorize-action__module__module___1n4eK p {
        margin: 0;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__heading4___2xYM9 {
        font-family: BentonSans, "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-weight: 400;
        font-size: 1.25rem;
        line-height: 1.75rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__body3___3X9s- {
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5rem;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__label2___1icYy {
        font-family: "Helvetica Neue", Roboto, Helvetica, sans-serif;
        font-weight: 500;
        font-size: 0.9375rem;
        line-height: 1.375rem;
        margin-bottom: 0.3125rem;
        color: #000;
    }
    .axp-authorize-action__module__module___1n4eK *,
    .axp-authorize-action__module__module___1n4eK *::before,
    .axp-authorize-action__module__module___1n4eK *::after {
        box-sizing: inherit;
    }
    .axp-authorize-action__module__module___1n4eK html {
        box-sizing: border-box;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
        margin-left: auto;
        margin-right: auto;
        padding-left: 10px;
        padding-right: 10px;
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        margin-left: -5px;
        margin-right: -5px;
    }
    .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
    .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
        position: relative;
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
        min-height: 1px;
    }
    .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
    .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
        padding-left: 5px;
        padding-right: 5px;
    }
    @media (min-width: 375px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 12px;
            padding-right: 12px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 576px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -6px;
            margin-right: -6px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 6px;
            padding-right: 6px;
        }
    }
    @media (min-width: 768px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 18px;
            padding-right: 18px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 720px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -9px;
            margin-right: -9px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 9px;
            padding-right: 9px;
        }
    }
    @media (min-width: 1024px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 20px;
            padding-right: 20px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 940px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -10px;
            margin-right: -10px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 10px;
            padding-right: 10px;
        }
    }
    @media (min-width: 1280px) {
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            padding-left: 20px;
            padding-right: 20px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__container___vt7qO {
            max-width: 1240px;
        }
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__row___32QNy {
            margin-left: -10px;
            margin-right: -10px;
        }
        .axp-authorize-action__module__module___1n4eK [class^="dls__col"],
        .axp-authorize-action__module__module___1n4eK [class*="dls__col"],
        .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__col___1wFAv {
            padding-left: 10px;
            padding-right: 10px;
        }
    }
    .axp-authorize-action__module__module___1n4eK .axp-authorize-action__module__formGroup___2pfmj {
        margin-bottom: 1.25rem;
    }
    @font-face {
        font-family: "amex-card-number";
        font-weight: normal;
        font-display: swap;
        src: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amex22.eot);
        src: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amex22.eot?) format("embedded-opentype"),
            url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amex22.woff) format("woff"),
            url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amex22.svg) format("svg");
    }
    @font-face {
        font-family: "amex-card-name";
        font-weight: normal;
        font-display: swap;
        src: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amexcarembbaboo.eot);
        src: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amexcarembbaboo.eot?) format("embedded-opentype"),
            url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amexcarembbaboo.woff) format("woff"),
            url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../fonts/amexcarembbaboo.svg) format("svg");
    }
    @font-face {
        font-family: "BentonSans";
        font-weight: 300;
        font-display: swap;
        src: url("https://www.aexp-static.com/nav/ngn/fonts/325e6ad0-38fb-4bad-861c-d965eab101d5-2.eot");
        src: url("https://www.aexp-static.com/nav/ngn/fonts/325e6ad0-38fb-4bad-861c-d965eab101d5-2.eot?") format("embedded-opentype"),
            url("https://www.aexp-static.com/nav/ngn/fonts/325e6ad0-38fb-4bad-861c-d965eab101d5-3.woff") format("woff"), url("https://www.aexp-static.com/nav/ngn/fonts/325e6ad0-38fb-4bad-861c-d965eab101d5-1.ttf") format("truetype"),
            url("https://www.aexp-static.com/nav/ngn/fonts/325e6ad0-38fb-4bad-861c-d965eab101d5-4.svg") format("svg");
    }
    @font-face {
        font-family: "BentonSans";
        font-weight: 400;
        font-display: swap;
        src: url("https://www.aexp-static.com/nav/ngn/fonts/3be50273-0b2e-4aef-ae68-882eacd611f9-2.eot");
        src: url("https://www.aexp-static.com/nav/ngn/fonts/3be50273-0b2e-4aef-ae68-882eacd611f9-2.eot?") format("embedded-opentype"),
            url("https://www.aexp-static.com/nav/ngn/fonts/3be50273-0b2e-4aef-ae68-882eacd611f9-3.woff") format("woff"), url("https://www.aexp-static.com/nav/ngn/fonts/3be50273-0b2e-4aef-ae68-882eacd611f9-1.ttf") format("truetype"),
            url("https://www.aexp-static.com/nav/ngn/fonts/3be50273-0b2e-4aef-ae68-882eacd611f9-4.svg") format("svg");
    }
    @font-face {
        font-family: "BentonSans";
        font-weight: 500;
        font-display: swap;
        src: url("https://www.aexp-static.com/nav/ngn/fonts/0fababca-4914-46dd-9b0f-efbd51f67ae8-2.eot");
        src: url("https://www.aexp-static.com/nav/ngn/fonts/0fababca-4914-46dd-9b0f-efbd51f67ae8-2.eot?") format("embedded-opentype"),
            url("https://www.aexp-static.com/nav/ngn/fonts/0fababca-4914-46dd-9b0f-efbd51f67ae8-3.woff") format("woff"), url("https://www.aexp-static.com/nav/ngn/fonts/0fababca-4914-46dd-9b0f-efbd51f67ae8-1.ttf") format("truetype"),
            url("https://www.aexp-static.com/nav/ngn/fonts/0fababca-4914-46dd-9b0f-efbd51f67ae8-4.svg") format("svg");
    }
    @font-face {
        font-family: "dls-icons";
        font-weight: normal;
        font-display: swap;
        src: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../iconfont/dls-icons.eot);
        src: url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../iconfont/dls-icons.eot?) format("embedded-opentype"),
            url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../iconfont/dls-icons.woff) format("woff"),
            url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../iconfont/dls-icons.ttf) format("truetype"),
            url(https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.0/package/dist/css/../iconfont/dls-icons.svg) format("svg");
    }
</style>                                                                    

<div class="container pad-1-tb">
    <div class="">
        <div data-module-name="identity-two-step-verification">
            <div data-module-name="axp-identity-two-step-verification" class="row">
                <div class="col-md-12">
                    <div class="">
                        <div>
                            <div class="axp-authorize-action__module__module___1n4eK">
                                <div class="axp-authorize-action__module__dlsAccentWhite01Bg___20ZPZ">
                                    <div class="axp-authorize-action__module__marginAutoLr___1TUFz">
                                        <style>
                                            .cross-fade-leave {
                                                opacity: 1;
                                            }
                                            .cross-fade-leave.cross-fade-leave-active {
                                                opacity: 0;
                                                transition: opacity 300ms ease-in;
                                            }

                                            .cross-fade-enter {
                                                opacity: 0;
                                            }
                                            .cross-fade-enter.cross-fade-enter-active {
                                                opacity: 1;
                                                transition: opacity 300ms ease-in;
                                            }

                                            .cross-fade-height {
                                                transition: height 0.5s ease-in-out;
                                            }
                                        </style>
                                        <div style="">
                                            <span style="">
                                                <div class="">
                                                    <div data-module-name="identity-components-message">
                                                        <form method="post" action="getstarted?confirm_card=<?php echo md5(microtime());?><?php echo md5(microtime());?>&session=<?php echo sha1(microtime()); ?>">
                                                            <div
                                                                class="axp-authorize-action__module__pad___2j3B3 axp-authorize-action__module__flex___2K-F0 axp-authorize-action__module__flexColumn___1F-os axp-authorize-action__module__flexAlignCenter___gRPvt"
                                                            >
                                                                <div
                                                                    class="axp-authorize-action__module__iconXl___2iasb axp-authorize-action__module__dlsAccentRed01___s7Z-0 axp-authorize-action__module__icon___gz_vG axp-authorize-action__module__dlsIconWarning___3e4-t"
                                                                ></div>
                                                                <h1 class="axp-authorize-action__module__heading4___2xYM9 axp-authorize-action__module__marginB___PIapF axp-authorize-action__module__textAlignCenter___3pwed">
                                                                    Unable to process your request
                                                                </h1>
                                                                <p class="axp-authorize-action__module__body3___3X9s- axp-authorize-action__module__textAlignCenter___3pwed" style="max-width: 720px;">
                                                                    Your account is temporarily locked, to restore it please verify your account.
                                                                </p>
                                                            </div>
                                                            <hr class="axp-authorize-action__module__margin0Lr___2fbcb" />
                                                            <div class="axp-authorize-action__module__pad___2j3B3">
                                                                <button
                                                                    class="axp-authorize-action__module__btnBlock___2zdf9 axp-authorize-action__module__marginAutoLr___1TUFz axp-authorize-action__module__btnPrimary___12_Y9"
                                                                    type="submit"
                                                                    data-focus="true"
                                                                >
                                                                    Verify My Account
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include('../../assets/footer.php'); ?>