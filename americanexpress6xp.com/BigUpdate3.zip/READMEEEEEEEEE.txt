index sengaja di matikan 
jadi jika panggil domain scam.com akan mati 
arahkan link ke scam.com/secure?