  /* set s.account dynamically */
  //var s = new AppMeasurement();

  var s = s_gi(_satellite.getVar("reportsuiteid"));

  s_account = s.account;
  //Create the omn object for setting the context data
  if (typeof omn == "undefined"){
    window.omn = new Object();
  }
  function a_digitalDatavars() {
    window.a_digitalData = null;
    window.isddl = false;
    window.adobeDataQueue = [];
    window.metaKeyOmn = []; 
    window.loggedCampaigns = [];
  }
  var isProcessing = false;
  var isDoPluginRequired = false;
  a_digitalDatavars();

  // Handler code

  // Initiate the First Tracking call once the digitalData object is pushed to adobe queue
  function adobeHandler(digitalData) {
     _satellite.notify('Framework Generated Digital Data -- ' + JSON.stringify(digitalData));
    adobeDataQueue.push(digitalData); 
    if(!isProcessing){
      isProcessing = true;
      trackQueue();
    }
  }
  // This function will be invoked when there is no adobe tracking call which need to be invoked
  // for the digitalData object pushed into the adobe queue 
  var trackQueue = function(){
      if(adobeDataQueue.length > 0){
        var digitalObject = adobeDataQueue.shift();
        if (digitalObject) {
          adobeTrackingHandler(digitalObject);
        }
      }else if(adobeDataQueue.length == 0){
        isProcessing = false;
      }
  };

  function adobeTrackingHandler(digitalDataObject){ 
     _satellite.notify('Digita Data Object from Queue -- ' + JSON.stringify(digitalDataObject));
    var invokerFunc = "";
    if(typeof(digitalDataObject.view) !== 'undefined' && digitalDataObject.diff.includes('view')){
      _satellite.notify('Page View Fired');   
      invokerFunc = 'code';
    } else if (typeof(digitalDataObject.events) != 'undefined' && digitalDataObject.diff.includes('events') && typeof(digitalDataObject.events[0]) != 'undefined' && typeof(digitalDataObject.events[0].type) != 'undefined' && digitalDataObject.events[0].type == 'journey') {
      _satellite.notify('Event type is journey hence page load rule fired ...');
      invokerFunc = 'code';		
    } else if (digitalDataObject.diff && digitalDataObject.diff[0] && digitalDataObject.diff[0].includes('campaign')) {
        _satellite.notify('campaign rule fired ...');
      invokerFunc = 'campaign';
      } else if (digitalDataObject.diff.includes('events') && typeof(digitalDataObject.events) !== 'undefined' && digitalDataObject.events && typeof(digitalDataObject.events[0]) !== 'undefined' && digitalDataObject.events[0]) {
        _satellite.notify('Event Fired from Diff');
      invokerFunc = 'event';
        //_satellite.notify('fire event rule, current view id is ' + digitalDataObject.view.viewId + ' event array lenght = ' + digitalDataObject.events.length + ' and event type = ' + digitalDataObject.events[0].type);
      } else if (digitalDataObject.diff.includes('components')) {
        //invokerFunc = 'components';
        _satellite.notify('Diff includes component hence call supressed.');
      } 
    if(invokerFunc){
      _satellite.notify('Before call type =' + invokerFunc);
      window.a_digitalData = digitalDataObject;
      if(invokerFunc === 'code'){
        if (_satellite.getVar('Full PageName')) {
          s.pageName = _satellite.getVar('Full PageName');
        }
      }
      if(invokerFunc !== 'campaign'){
        invokerFunc = getTrackcall(invokerFunc);
      }
      //Setting the omn context data to empty so that the same variables will not be set in
      // every image beacon. 
      while(metaKeyOmn.length > 0){
        var omnKey = metaKeyOmn.shift();
        if (omnKey) {
          omn[omnKey] = "";
        }
      }    
      if(invokerFunc){
        isDoPluginRequired = true;
        _satellite.track(invokerFunc);
      }
      _satellite.notify('After call type =' + invokerFunc);
    } 
    if(!isddl && (_satellite.getVar("businessunit") === "acq" || _satellite.getVar("businessunit") === "frm" || _satellite.getVar("businessunit") === "mer")){
      isddl = true;
      setTimeout(trackQueue, 1000);
    }else if(!isddl && _satellite.getVar("businessunit") !== "acq"){
      isddl = true;
      trackQueue();
    }else{
      trackQueue();
    }
  }

  function getTrackcall(invokerBUFunc){
    var buRule = "";
    var  ebu = _satellite.getVar("businessunit");
    switch (ebu) {
      case "ser":
        buRule = "myca " + invokerBUFunc;
        break;
      case "mr":
        buRule = "myca " + invokerBUFunc;
        break;
      case "acq":
        buRule = "myca " + invokerBUFunc;
        break;
      case "trl":
        buRule = "myca " + invokerBUFunc;
        break;
      case "trlintl":
        buRule = "myca " + invokerBUFunc;
        break;      
      case "frm":
        buRule = "myca " + invokerBUFunc;
        break;
      case "mer":
        buRule = "myca " + invokerBUFunc;
        break;      
      case "int":
        buRule = "myca " + invokerBUFunc;
        break;
      default:
        buRule = "default page";
        break;
    }
    return buRule;
  }

  // temporarly added below clearvars code to clear acquisition set variables.
  function ClearVars() {
    for (var i = 0; i < 75; i++) {
      s['prop' + i] = '';
      s['eVar' + i] = '';
    }
  }
  //Function to flatten the meta data from digitalData and set in omn
  // isMetaMerge will determine whether we need to merge the properties only or methods as well.
  function mergeObjects(srcObj, mergeObj, isMetaMerge) {
      Object.keys(mergeObj).forEach(function(key) {
      if(typeof mergeObj[key] !== 'undefined' && mergeObj[key] 
         && ((typeof mergeObj[key] !== 'function' && (typeof mergeObj[key] !== 'object' || (typeof mergeObj[key] === 'object' && Array.isArray(mergeObj[key]) && (key === "keywords" || key === "topics" || key === "projects" || key === "contributors" || key === "productcontacts" || key === "productContacts" || key === "functionTypes" || key === "businessCapabilities" || key === "functiontypes" || key === "businesscapabilities" || key === "seNumber" || key === "senumber"))))|| !isMetaMerge)){
            srcObj[key.toLowerCase()] = mergeObj[key];
      }
    });
      return srcObj;
  }
  /************************** CONFIG SECTION **************************/
  // Check with app team on source entry points for OneAmex sites
  s.linkInternalFilters = "javascript:,mailto:,tel:,americanexpress.,.americanexpress,americanexpress-,amex,american-express,aexp.com,membershiprewards.,experiandirect.com,openforum.com,davidjones,aetclocator.com,deltaskymilescard.com,yourcarrentalclaim.com,as00.estara.com,axpbillpay.com,ebm.cheetahmail.com,magroup-online.com,co-store.com,searchmanager.com,amextravel.com,fhrdigitaldirectory.com,hcdigitaldirectory.com,thecenturionlounge.com,amexcards.com.tw";
  s.linkInternalFilters += "," + window.location.hostname;
  s.trackExternalLinks = true;
  s.linkLeaveQueryString = false;
  s.trackInlineStats=false;
  var omn_temp = 1;
  s.trackGCT = 1;
  /*ChannelManagerList*/
  s.cmQlist = "extlink,affid,eaid,psctn,psccsg,psopen,psboth,om_mid,et_cid,s_email,emaillink,campaignid,vanity,extlink,mrexc";
  s.cmQGCTlist = "cpid,itu_id,pid,psku";
  s.omn_getFromQueryParamVars = ['cpid', 'extlink', 'inav', 'intlink', 'linknav', 'omnlogin', 'dynamicsearch','searchresult', 'ltype']
  s.omn_getValOnceVars = ['cpid', 'extlink', 'inav', 'intlink', 'linknav', 'omnlogin','ltype'];
  s.omn_toLowerCase = ['intlink'];
  // doPlugins code
  s.usePlugins = true;
  function s_doPlugins() {
    _satellite.notify("do plugins start...");

  /* set s.account dynamically */
  if (_satellite.getVar("reportsuiteid") != '' && _satellite.getVar("reportsuiteid") != "undefined") {
    s.account = _satellite.getVar("reportsuiteid"); 
  }
  s.server = window.location.hostname.toLowerCase();
  //Visitor ID coverage measurement
  s.contextData.visitorCheck = (typeof(Visitor) != "undefined" ? "VisitorAPI Present" : "VisitorAPI Missing");
  //  _satellite.notify("reportsuiteid: "+s.account);
  //s = s_gi(s_account);
  if (_satellite.getVar('Page URL')) {
    s.pageURL = _satellite.getVar('Page URL');
  }
  s.prop49 = "DTM-OneAmex" + ":v2.0-AM:" + s_c_il[1].version + "-VISID:" + ((typeof visitor != "undefined") ? visitor.version : (_satellite.getVisitorId() != null) ? _satellite.getVisitorId().version : "NA") + "-DIL:" + ((typeof DIL != "undefined") ? DIL.version : "NA") + "-Mbox:" + ((typeof mboxVersion != "undefined") ? mboxVersion : "NA") + "-msuite:true-PD:" + _satellite.getVar("publishdate");



  //set line of business for enterprise report suite
    omn.lob = _satellite.getVar("businessunit");

  if (_satellite.getVar('Language'))
    s.prop3 = _satellite.getVar('Language');
  if (_satellite.getVar('Country')) {
    s.prop4 = _satellite.getVar('Country').toUpperCase();
    // convert the prop4 to upper case.
    if (!s.prop4) {
      s.prop4 = "UnknownMarket"; // set default local market  
    }
  }
  if (s.prop4) {
    s.eVar27 = s.prop4;
  }
  if (_satellite.getVar('Hierarchy')) {
    s.hier1 = _satellite.getVar('Hierarchy');
  }
  if (!s.eVar1 && _satellite.getVar('intlink')) {
    s.eVar1 = _satellite.getVar('intlink');
  }
  if (_satellite.getVar('iNav Link')) {
    s.eVar8 = _satellite.getVar('iNav Link');
  }
  //The below value is set to help tracking the overall count  
  s.prop46="DLS Navigation" ;
  //The below logic will capture the user consent provided  
  if (_satellite.getVar('userconsent')) {
    s.eVar126 = _satellite.getVar('userconsent');
  }    
  s.prop56 = "oneamex";
  if (_satellite.getVar('device')){
    s.prop56 = s.prop56 + ":" + _satellite.getVar('device');
  }
  if (_satellite.getVar('Amex Guid')) {
    s.eVar13 = s.prop34 = _satellite.getVar('Amex Guid');
  }
  if (_satellite.getVar('ZipCode')) {
    s.eVar39 = s.prop4 + ":" + _satellite.getVar('ZipCode');
  }
  if (_satellite.getVar('Login Status')) {
    s.prop50 = _satellite.getVar('Login Status');
  }
  if (_satellite.getVar('CharSet')) {
    s.charSet = _satellite.getVar('CharSet');
  }  
  //Percent of Page Viewed
  var ppvArray = s.getPercentPageViewed(s.pageName);
  omn.ppvpage = s._ppvPreviousPage; //contains the previous page nam
  omn.ppvtotal = s._ppvHighestPercentViewed; //contains the total percent viewed
  omn.ppvinitial = s._ppvInitialPercentViewed; //contains the percent viewed on initial load
  //Exit Links
  var dd_exitURL = (s.linkObject && s.linkType == 'e') ? s.linkURL : 0;
  if (dd_exitURL) {
    s.linkTrackVars = s.apl(s.linkTrackVars, 'prop27,contextData.omn.ppvpage,contextData.omn.ppvtotal,contextData.omn.ppvinitial', ',', ',', 2);
    omn.ppvpage = s.prop27 = s.pageName ? s.pageName : "not available because pageName/hierarchy not set on page";
  }
  s.eVar41 = s.getPreviousValue(s.pageName, 'gpv_v41', '');
  //s.prop56=s.eVar78="OneAmex"; /* why not use data element application? */
  s.linkTrackVars = s.apl(s.linkTrackVars, 'prop4,prop49,eVar27,prop56,eVar78,contextData.omn.lob', ',', ',', 2);
  //Customer vs Prospect
  if (s.prop34) {
    s.prop10 = s.eVar45 = 'customer';
  } else {
    s.prop10 = s.eVar45 = 'prospect';
  }
  //agent-id
   s.eVar94 = "D=agent-id";

  if (_satellite.getVar('Device Width') && _satellite.getVar('Device Height')) {
    var etratio = _satellite.getVar('Device Height') / _satellite.getVar('Device Width');
    if (etratio >= 1) {
      etorientation = "portrait";
    } else {
      etorientation = "landscape";
    }
    s.eVar61 = etorientation;
    s.eVar60 = _satellite.getVar('Device Width');
  }
    // International GCT cookie
    var gctcookie = s.c_r("gctrac")
    if (gctcookie) {
      s.prop48 = s.eVar22 = gctcookie;
    }
    if (s.pageName)
      s.eVar74 = s.pageName;
    if (typeof(Visitor) != "undefined") {
      s.visitor = Visitor.getInstance("5C36123F5245AF470A490D45@AdobeOrg");
      s.eVar75 = s.visitor.getMarketingCloudVisitorID();
    } else {
      s.eVar75 = "MCMID not available";
    }
    //_satellite.notify("Before context data ...");
    if(isDoPluginRequired){
      if (typeof omn != "undefined") {
        if (_satellite.getVar('Language')) {
          omn.language = _satellite.getVar('Language');
        }
        // Duplicate campaign issue exists , once framework fix applied need to change the logic.
        omn.abtest = _satellite.getVar("newCampaigns");
        s.list2 = omn.abtest;
        if (_satellite.getVar('DDL View Id')) {
          if (a_digitalData.view.viewId == "/search") {
            omn.intsearchterm = s.getQueryParam('term');
          } else {
            omn.intsearchterm = "";
          }
        }
        //Setting the MYCA Demo data to omn object for all adobe beacons
        if (_satellite.getVar("mycademodata")) {
          var mycaDemoData =  _satellite.getVar("mycademodata");
          omn = mergeObjects(omn, mycaDemoData, true);
          _satellite.notify(Object.keys(mycaDemoData));
        } 
         _satellite.notify('Digita Data Object after copy -- ' + JSON.stringify(a_digitalData));
        //Setting the Meta data from events array to omn object for Journey Tracking
        if (_satellite.getVar("metadata")) {
          var metaData =  _satellite.getVar("metadata");
          //Setting the product varaible for all Journeys
          if(metaData.productData){
            s.products = metaData.productData;
          }
           //Setting the product varaible for MR EDR Journey
          if(metaData.price && metaData.quantity && metaData.points){
            s.events=s.apl(s.events, "purchase,event98", ",", ",", 2);
            s.products = metaData.productData +";" + metaData.quantity + ";" + metaData.price + ";event98=" + metaData.points;
          }
          if(typeof metaData.journey !== "undefined" && metaData.journey
          && typeof metaData.element !== "undefined" && metaData.element
          && typeof metaData.conversionstep === "undefined"){
            var eventValue = _satellite.getVar('serializedeventmap')(metaData.journey + "_" + metaData.element);
            if (eventValue) {
              s.events=s.apl(s.events,eventValue,",", ",", 2);
            }
          }
                  
          if(typeof metaData.journey !== "undefined" && metaData.journey){
            if(typeof metaData.suppadded !== "undefined" && metaData.suppadded){
              s.events=s.apl(s.events,_satellite.getVar('serializedeventmap')(metaData.journey + "_suppadded"),",", ",", 2);
            }
            if(typeof metaData.suppoffered !== "undefined" && metaData.suppoffered){
              s.events=s.apl(s.events,_satellite.getVar('serializedeventmap')(metaData.journey + "_suppoffered"),",", ",", 2);
            }
            if(typeof metaData.appdecision !== "undefined" && metaData.appdecision 
               && (typeof metaData.applicationtype === "undefined" || 
                   (typeof metaData.applicationtype !== "undefined"  && metaData.applicationtype !== "supp"))){
              s.events=s.apl(s.events,_satellite.getVar('serializedeventmap')(metaData.journey + "_" + metaData.appdecision.toLowerCase()),",", ",", 2);
            }
            if(metaData.conversionstep){
              var serializeKey = metaData.journey + "_" + metaData.conversionstep.toLowerCase();
              if (typeof(_satellite.getVar('serializedeventmap')(serializeKey)) !== 'undefined' && _satellite.getVar('serializedeventmap')(serializeKey)) {
                s.events=s.apl(s.events,_satellite.getVar('serializedeventmap')(serializeKey),",", ",", 2);
              }
            }        
          }      
          omn = mergeObjects(omn, metaData, true);
          _satellite.notify(Object.keys(metaData));
          metaKeyOmn = Object.keys(metaData);
        }
        //Intranet Filter specific tracking
        if(_satellite.getVar("businessunit") === "int"){
          if(_satellite.getVar("intranetcontentimpression")()){
            omn.filterimpression = _satellite.getVar("intranetcontentimpression")();
            metaKeyOmn.push("filterimpression");
          }
          if(_satellite.getVar("internalreferrer")){
            omn.internalreferrer = _satellite.getVar("internalreferrer");
            metaKeyOmn.push("internalreferrer");
          }
         	if (_satellite.getVar('explorerinfo')) {
          	s.eVar19 = _satellite.getVar('explorerinfo');
            try{
              var exploreAttributes= JSON.parse(_satellite.getVar('explorerinfo'));
              s.eVar21=exploreAttributes.st;
              s.eVar22=exploreAttributes.c;
              //s.eVar23=exploreAttributes.axppguid;
              s.eVar24=exploreAttributes.axppband;
              s.eVar25=exploreAttributes.axpJobCode;
              s.eVar26=exploreAttributes.l;
              s.eVar28=exploreAttributes.department;
              s.eVar29=exploreAttributes.title;
            } catch(e){
              _satellite.notify("Supress the errors if any during JSON Parsing" + e);
            }
        	}          
        }
      }
      if(!omn.eep && _satellite.getVar("externalentrypoint")){
        omn.eep = _satellite.getVar("externalentrypoint");
      }
    if(_satellite.getVar("businessunit") === "mr"){
      //MR:Set to 1 if first page of visit (currently used with intlink processing rules)
      if(omn_temp == 1) {
        if(omn)
          omn.gvs = s.getVisitStart("s_visit")
      }

      /*Days Since Last Visit*/
      s.prop43 = s.getDaysSinceLastVisit('s_lv');

      /* MR cross visit participation for intlink */
      if(s.contextData["omn.intlink"]){
        s.contextData["omn.mrintlinkcvp"]=s.crossVisitParticipation(s.contextData["omn.intlink"],'omn_mrintlinkcvp','30','5','>');
      }
    }  
       _satellite.notify('After setting the required context data');
    //_satellite.notify("after context data ...");
    //! inc:common:DP_ChannelManager
      /*eInclude start DP_ChannelManager.txt*/
      /* destPage query paramet campaign capture */
      if (s.getQueryParam('destpage') && !s.getQueryParam('extlink')) {
        var destpage_override = decodeURIComponent(s.getQueryParam('destpage'))
      }
      if (omn_temp == 1 && s.pageURL) {
        if (omn.extlink) s.pageURL = s.insQP(s.pageURL, "extlink", omn.extlink)
        /*Remove Email address from URL*/
        if (s.pageURL.search(/(@|%40)\w+([\.-]?\w+)*(\.\w{2,3})+/g) > 0) {
          base_url = s.pageURL.split('?');
          s.pageURL = base_url[0] + "#URLTruncated";
        }

        /*ChannelManagerStart*/
        if (destpage_override) {
          var pre_destPage_override = s.pageURL;
          s.pageURL = destpage_override;
        }
        //Manual doubleclick fix
        s._cmevt = s.events + ","
        if (s._cmevt.indexOf('event5,') > -1 || s._cmevt.indexOf('event5:') > -1 || s._cmevt.indexOf('event24') > -1) {} else { // These are references to events not used by servicing
          if (typeof(omn.referrer) != 'undefined') { // use spoofed referrer for testing
            s.referrer = omn.referrer
          } else {
            s.referrer = document.referrer
          }
          s.tnt = s.trackTNT(); //Test and Target analytics data      
          if (s.account.substring(s.account.length - 3) == "dev") {
            s.testRef = s.getQueryParam('omnref') //another way to set the spoofed referrer (set in query string)
            if (s.testRef) {
              s.referrer = s.testRef
            };
          }
          s.referrer = s.rmvQP(s.referrer, s.rmvParams) // Set referrer in situations where an automatic redirect was used
          if (s.referrer.indexOf('americanexpress.com/myca/') > -1) {
            s._SSOPage = s.getQueryParam('DestPage', '', s.referrer)
          } else if (s.referrer.indexOf('americanexpress.com/occ/occwelcome.jsp') > -1 || s.referrer.indexOf('sso.americanexpress.com/sso/request') > -1) {
            s._SSOPage = s.getQueryParam('TARGET', '', s.referrer)
          } else if (s.referrer.indexOf('sso.americanexpress.com/sso') > -1) {
            s._SSOPage = s.getQueryParam('SSOURL', '', s.referrer)
          } else if (s.referrer.indexOf('icenturion.americanexpress.com') > -1) {
            s._SSOPage = s.getQueryParam('target', '', s.referrer)
          } else {
            s._SSOPage = false
          }
          if (s._SSOPage) {
            s.tempRef = s.referrer;
            s.referrer = "//SSORedirect";
          }
          s.channelManager(s.cmQlist + ',' + s.cmQGCTlist,365,false);
          /*
           Channel Manager Parameters:
             1-qsp Comma delemited list of querystring parameter
             2-tbl The number of days to not record the typed/bookmarked channel after the vistor comes to the site from a different channel
             3-con Set to true when tracking code value contains a specific pattern, defaults to false
          */
          if (s._SSOPage != false) { // sets referrer using the logic above in cases where there was a redirect
            s.referrer = s.tempRef;
          }

          if (s._referringDomain != undefined) { //strips www. and query string params from referring domain
            if (s._referringDomain.substring(0, 4) == 'www.') s._referringDomain = s._referringDomain.substring(4);
            if (s._referringDomain.indexOf('?') > -1) s._referringDomain = s._referringDomain.substring(0, s._referringDomain.indexOf('?'));
            //trim down the email referring domains
            s.mailRef = s._referringDomain.indexOf('.mail.')
            if (s.mailRef > -1) {
              s._referringDomain = s._referringDomain.substring(s.mailRef + 1);
            }
          }
          s._paidEffort = 0;
          s._refID = "";
          s._cmlid = "";
          if (s._keywords != undefined) s._keywords = s.repl(s._keywords, '+', ' ') //s._keywords is returned by channel manager
          if (s._channel == "Paid Search") { //s._channel is returned by channel manager
            s._paidEffort = 1;
            if (s._keywords == "n/a") {
              s._keywords = "keyword unavailable"
            }
            s._keywords = "p|" + s._keywords;
          } else if (s._channel == "Unknown Paid Channel") {
            s._paidEffort = 1;
          } else if (s._channel == "Natural Search") {
            if (s._keywords == "n/a") {
              s._keywords = "keyword unavailable"
            }
            s._keywords = "n|" + s._keywords;
            if (s.prop4.length == 2) {
              s._campaign = s._refID = "n|" + s.prop4 + ":" + s._referringDomain;
            } else {
              s._campaign = s._refID = "n|" + s._referringDomain;
            }
            s._cmlid = "n/a"
          } else if (s._channel == "Other Natural Referrers") {
            s._cmlid = "n/a"
            if (s._SSOPage || omn.iframe) {
              s._refID = s._referrer = s._referringDomain = s._partner = s._campaignID = s._campaign = s._keywords = s._channel = s._cmlid = "";
            } else if (s.prop4.length == 2) {
              s._campaign = s._refID = "r|" + s.prop4 + ":" + s._referringDomain;
            } else {
              s._campaign = s._refID = "r|" + s._referringDomain;
            }
          }
          if (s._paidEffort == 1) {
            s._cpid = s.getQueryParam('cpid');
            if (!s._cpid) s._cpid = s.getQueryParam('itu_id');
            s._affid = s.getQueryParam('affid', '', window.location);
            if (!s._affid) {
              s._affid = s.getQueryParam('eaid', '', window.location);
              if (s._affid) {
                s._splitAffid = s.split(s._affid, '-');
                s._affid = s._splitAffid[0];
              }
            }
            if (s._cpid) {
              s._refID = s._affid ? s._cpid + '|' + s._affid : s._cpid
            } else if (s._channel == "Paid Search") {
              if (s.prop4.length == 2) {
                s._refID = s.prop4 + ':Legacy Paid Search'
              } else {
                s._refID = 'Legacy Paid Search'
              }
            } else if (s._channel == "Unknown Paid Channel") {
              if (s.prop4.length == 2) {
                s._refID = s.prop4 + ':Legacy Non-Search'
              } else {
                s._refID = 'Legacy Non-Search'
              }
            }
            s._campaign = "";
            s._cmlid = "n/a";
            s.cmQlistA = s.split(s.cmQlist, ',')
            s.cmQ = 0
            while (s.cmQ < s.cmQlistA.length) {
              if (!s._campaign) {
                s._campaign = s.getQueryParam(s.cmQlistA[s.cmQ]);
                if (s._campaign) {
                  if (s.cmQlistA[s.cmQ] == "om_mid") {
                    s._campaign = s.getQueryParam('om_mid');
                    s._cmlid = s.getQueryParam('om_lid');
                    if (!s._cmlid) s._cmlid = "n/a";
                  } else if (s.cmQlistA[s.cmQ] == "et_cid") {
                    s._campaign = s.getQueryParam('et_cid');
                    s._cmlid = s.getQueryParam('et_rid');
                    if (!s._cmlid) s._cmlid = "n/a";
                  } else if (s.cmQlistA[s.cmQ] == "affid") {
                    s.tcamp1 = s.getQueryParam('buid','', ("" +window.location).toLowerCase());
                    s.tcamp2 = s.getQueryParam('affid','', ("" +window.location).toLowerCase());
                    s.tcamp3 = s.getQueryParam('pid','', ("" +window.location).toLowerCase());
                    s.tcamp4 = s.getQueryParam('crtv','', ("" +window.location).toLowerCase());
                    s.tcamp1 = s.tcamp1 ? s.tcamp1 : 'null';
                    s.tcamp2 = s.tcamp2 ? s.tcamp2 : 'null';
                    s.tcamp3 = s.tcamp3 ? s.tcamp3 : 'null';
                    s.tcamp4 = s.tcamp4 ? s.tcamp4 : 'null';
                    s._campaign = "Affiliate|buid=" + s.tcamp1 + ":affid=" + s.tcamp2 + ":pid=" + s.tcamp3 + ":crtv=" + s.tcamp4;
                  } else if (s.cmQlistA[s.cmQ] == "eaid") {
                    s.tcamp5 = s.getQueryParam('eaid','', ("" +window.location).toLowerCase());
                    s.tcamp6 = s.getQueryParam('buid','', ("" +window.location).toLowerCase());
                    s.tcamp7 = s.getQueryParam('pid','',  ("" +window.location).toLowerCase());
                    s.tcamp5 = s.tcamp5 ? s.tcamp5 : 'null';
                    s.tcamp6 = s.tcamp6 ? s.tcamp6 : 'null';
                    s.tcamp7 = s.tcamp7 ? s.tcamp7 : 'null';
                    s._campaign = "Affiliate|eaid=" + s.tcamp5 + ":buid=" + s.tcamp6 + ":pid=" + s.tcamp7;
                  } else {
                    if (s._campaign) s._campaign = s.cmQlistA[s.cmQ] + "=" + s._campaign;
                  }
                }
              }
              s.cmQ++
            }
            if (!s._campaign) {
              s.cmQGCTlistA = s.split(s.cmQGCTlist, ',')
              for (var q in s.cmQGCTlistA) {
                if (s.cmQGCTlistA.hasOwnProperty(q)) {
                  var qv = s.cmQGCTlistA[q];
                  var qspVars = s.getQueryParam(qv);
                  if (qspVars) {
                    s._campaign = "GCT CPID";
                  }
                }
              }
            }
          }

          // Custom deduping: rather than relying on channel manager deduping, the following
          // code is used to only set values on site entrance.
          if (s._campaign) {
            if (s.dedupeCM) {
              s.dedupeCM = s.dedupeCM + s._campaign;
            } else {
              s.dedupeCM = s._campaign;
            }
          }
          if (s._refID) {
            if (s.dedupeCM) {
              s.dedupeCM = s.dedupeCM + s._refID;
            } else {
              s.dedupeCM = s._refID;
            }
          }
          if (s._referringDomain) {
            if (s.dedupeCM) {
              s.dedupeCM = s.dedupeCM + s._referringDomain;
            } else {
              s.dedupeCM = s._referringDomain;
            }
          }
          if (s._keywords) {
            if (s.dedupeCM) {
              s.dedupeCM = s.dedupeCM + s._keywords;
            } else {
              s.dedupeCM = s._keywords;
            }
          }
          if (s._cmlid) {
            if (s.dedupeCM) {
              s.dedupeCM = s.dedupeCM + s._cmlid;
            } else {
              s.dedupeCM = s._cmlid;
            }
          }
          s.dedupeCM = s.getValOnce(s.dedupeCM, 's_dedupeCM', 0)
          if (s.dedupeCM) {
            s.campaign = s._campaign;
            s.eVar21 = s._refID;
            s.eVar70 = s._keywords;
            s.eVar71 = s.pageName;
            s.eVar72 = s._cmlid;
          }
          s.dedupeCM = '';
        }
      } else {
        s.campaign = s.eVar21 = s.eVar70 = s.eVar71 = s.eVar72 = ""
      }
      s.events = s.removeEvent('event45')
      s.events = s.removeEvent('event46')
      s.clickPast(s.campaign, 'event45', 'event46');

      if (pre_destPage_override) {
        s.pageURL = pre_destPage_override;
      }
     /*eInclude end DP_ChannelManager.txt*/
      /*eInclude start DP_ContextDataMapping.txt*/
      //Map all variables to contextData
      //Map query string params to omn. variables
      //if (!s.isRM){
      for (var q in s.omn_getFromQueryParamVars) { // get variables from query params
        if (s.omn_getFromQueryParamVars.hasOwnProperty(q)) { // check that item is a property of omn
          qv = s.omn_getFromQueryParamVars[q];
          omn[qv] = (omn.hasOwnProperty(qv)) ? ((omn[qv] != "") ? omn[qv] : s.getQueryParam(qv)) : s.getQueryParam(qv);
        }
      }
      //toLowerCase variables
      for (var ucase in s.omn_toLowerCase) {
        uc = s.omn_toLowerCase[ucase];
        if (omn.hasOwnProperty(uc)) {
          omn[uc] = omn[uc].toLowerCase();
        }
      }
      // copy first product ID to contextData variable for event mapping
      if (s.products && s.products.indexOf(';') > -1) {
        pl = s.split(s.products, ',');
        pll = pl.length;
        for (var n = 0; n < pll; n++) {
          pla = s.split(pl[n], ';');
          pid = pla[1];
          if (!s.contextData['omn.productID']) {
            s.contextData['omn.productID'] = pid;
          }
        }
      }

      // map omn. to context variables
      for (var ovar in omn) {
        if (omn.hasOwnProperty(ovar)) { // check that item is a property of omn				
          if (s.inArr(s.omn_getValOnceVars, ovar)) { // getValOnce if flagged
            s.contextData['omn.' + ovar] = s.getValOnce(omn[ovar], 'omn_' + ovar, 0);
          } else {
            s.contextData['omn.' + ovar] = omn[ovar];
          }
        }
      }
      omn_temp = 0;
      s.prop75 = "DTM";
      // AAM Audience Management Config
      // Use the syncs setting from the Visitor API file, set to true by default
      try{
        if(typeof s!=="undefined" && typeof s.visitor!=="undefined" && !_satellite.getVar("disableidsync")){
          s.AudienceManagement.setup({
               "partner":"aexp",
               "visitorService":{"namespace": "5C36123F5245AF470A490D45@AdobeOrg"},
               "containerNSID":15,
               "disableIDSyncs":(typeof s!=="undefined" && typeof s.visitor!=="undefined")?s.visitor.disableIdSyncs:false,
               "uuidCookie": {
                    "name":"aam_id",
                    "days":30
               }
          });
        }
      }catch(e){
        _satellite.notify("Supress the errors if any during audience management setup" + e);
      }
      //  window.a_digitalData=null;
      isDoPluginRequired = false;
    }
   };
   s.doPlugins = s_doPlugins;

    /************************** PLUGINS SECTION *************************/
  /* Adobe Consulting Plugin: channelManager v4.1 (Requires AppMeasurement and the CONSULTING-BUILT getQueryParam v3.2/pt v2.0 plugins) */
  s.channelManager=function(K,E,u){var H=this,D=false,L=false,z=new Date();z.setTime(z.getTime()+1800000);if(!!H._channel){return""}else{var A="n/a",r="n/a",a="n/a",w="n/a",c="n/a",m="n/a"}if(H.c_r("s_tbm")){D=false}if(!!E&&H.c_r("s_tbm"+E.toString())){D=false}H.c_w("s_tbm",true,z);var R=H.referrer?H.referrer:document.referrer;if(R==="Typed/Bookmarked"){R=""}R=decodeURIComponent(R.toLowerCase());if(!R){L=true}var t=false;if(!!R){t=true;var N=R.split("/")[2].split("?")[0].toLowerCase();var e=H.linkInternalFilters.toLowerCase().split(","),l=e.length;for(P=0;P<l;P++){if(N.indexOf(e[P])>-1){t=false;break}}}if(!!t){w=R;c=N;A="Other Natural Referrers";r=A+": "+N;if(!!H._channelSEList){var y=H._channelSEList.split(">"),C=y.length,n="",F=[],g=[],G;for(var P=0;P<C;P++){n=y[P];F=n.split("|");g=F[1].split(",");G=g.length;for(var M=0;M<G;M++){if(N.indexOf(g[M].toLowerCase())>-1){m=F[0];break}}if(m!=="n/a"){break}}}}var I="";if(!!K){var k=K.split(","),B=k.length;for(var P=0;P<B;P++){I=H.getQueryParam(k[P]);if(!!I){break}}if(!!I&&(!!t||!!L)){a=r=I;if(m!=="n/a"){A="Paid Search"}else{A="Unknown Paid Channel"}}}if(!I&&m!=="n/a"){A="Natural Search";r=A+": "+m}if(!!D&&!R&&!I){w=c=r=A="Typed/Bookmarked"}var h=[],d=0,O=[],f=false;if(!!H._channelDomain&&!!t){var Q=[],b=0,q="";f=false;h=H._channelDomain.split(">"),d=h.length;for(var P=0;P<d;P++){O=h[P]?h[P].split("|"):"";Q=O[1]?O[1].split(","):"",b=Q.length;for(var M=0;M<b;M++){q=Q[M].toLowerCase();if(("/"+N).indexOf(q)>-1){A=O[0];r=I?r:A+": "+N;f=true;break}}if(!!f){break}}}if(!!H._channelParameter){var o=[];f=false;h=H._channelParameter.split(">"),d=h.length;for(var P=0;P<d;P++){O=h[P]?h[P].split("|"):"";o=O[1]?O[1].split(","):"";for(var M=0,J=o.length;M<J;M++){if(!!H.getQueryParam(o[M])){A=O[0];r=I?r:A+": "+N;f=true;break}}if(!!f){break}}}if(!!H._channelPattern&&!!I){var p=[];f=false;h=H._channelPattern.split(">"),d=h.length;for(var P=0;P<d;P++){O=h[P]?h[P].split("|"):"";p=O[1]?O[1].split(","):"";for(var M=0,J=p.length;M<J;M++){if((!u&&I.toLowerCase().indexOf(p[M].toLowerCase())==0)||(!!u&&I.toLowerCase().indexOf(p[M].toLowerCase())>-1)){A=O[0];a=r=I;f=true;break}}if(!!f){break}}}if(A!=="n/a"){H._channel=A;H._campaign=r;H._campaignID=a;H._referrer=w;H._referringDomain=c;H._searchEngine=m;if(H._channel!=="Typed/Bookmarked"&&E){z.setTime(z.getTime()+Number(E)*86400000);H.c_w("s_tbm"+E.toString(),true,z)}}else{H._channel=H._campaign=H._campaignID=H._referrer=H._referringDomain=H._searchEngine=""}};

  /* Top 130 - Grouped */
  s._channelSEList="Google|.google.,googlesyndication.com,.googleadservices.com>Google Search App|googlequicksearchbox>Bing|bing.com>Yahoo!|yahoo.com,yahoo.co.jp>Naver|naver.com,search.naver.com>Yandex.ru|yandex>DuckDuckGo|duckduckgo.com>Daum|daum.net,search.daum.net>Baidu|baidu.com>MyWay.com|myway.com>Ecosia|ecosia.org>Ask|ask.jp,ask.co>DogPile|dogpile.com>sm.cn|sm.cn>sogou.com|sogou.com>Haosou|so.com>Seznam.cz|Seznam.cz>AOL|search.aol.,suche.aolsvc.de>AltaVista|altavista.co,altavista.de>MyWebSearch|.mywebsearch.com>WebCrawler|webcrawler.com>Wow|wow.com>InfoSpace|infospace.com>Blekko|blekko.com>Docomo|docomo.ne.jp>alhea.com|Alhea>info.com|Info.com>contenko.com|Contenko>icqit.com|icq>myway.com|MyWay.com>naver.com,search.naver.com|Naver>netscape.com|Netscape Search>reference.com|Reference.com>seznam|Seznam.cz>abcsok.no|Startsiden>tiscali.it,www.tiscali.co.uk|Tiscali>virgilio.it|Virgilio>optimum.net|Optimum Search>search.earthlink.net|Earthlink>search.comcast.net|Comcast>libero.it|libero.it>excite.co|Excite>mail.ru|Mail.ru>isearch.avg.com|AVG>msn.com|MSN>seznam.cz|seznam.cz>so.com|so.com>ixquick.com|ixquick.com>sogou.com|sogou.com>360.cn|360.cn";

  /*Adobe Consulting Plugin: Replace v1.0*/
  s.repl=function(x,o,n){var i=x.indexOf(o),l=n.length;while(x&&i>=0){x=x.substring(0,i)+n+x.substring(i+o.length);i=x.indexOf(o,i+l)}return x};

  /*Adobe Consulting Plugin: Remove QSP v1.0*/
  s.rmvQP=function(u,p){var s=this,i,j,k,pa=s.split(p,",");u=""+u;for(i in pa){p=pa[i];j=0;while(j!=-1){j=u.indexOf("?"+p+"=");if(j==-1)j=u.indexOf("&"+p+"=");if(j!=-1){k=u.indexOf("&",j+1);if(k==-1)k=u.length;u=u.substring(0,j+1)+u.substring(k+1,u.length)}}}return u};

  /* Adobe Consulting Plugin: remove event v1.0*/
  s.removeEvent=function(e){var s=this;var el,a,b,c,a1,b1,c1,d;if(s.events){el=s.split(s.events,",");a=e+",";b=e+":";c=e+"=";x=0;while(x<el.length){a1=el[x]+",";b1=el[x]+":";c1=el[x]+"=";if(a1.indexOf(a)>-1||b1.indexOf(b)>-1||c1.indexOf(c)>-1);else d?d=d+","+el[x]:d=el[x];x++}}d?d=d:d="";return d};

  /* Adobe Consulting Plugin: click past v1.0*/
  s.clickPast=function(scp,ct_ev,cp_ev,cpc){var s=this,scp,ct_ev,cp_ev,cpc,ev,tct;if(s.p_fo(ct_ev)==1){if(!cpc)cpc="s_cpc";ev=s.events?s.events+",":"";if(scp){s.events=ev+ct_ev;s.c_w(cpc,1,0)}else if(s.c_r(cpc)>=1){s.events=ev+cp_ev;s.c_w(cpc,0,0)}}};

  /* Adobe Consulting Plugin: page first only v2.0 (minified) */
  s.p_fo=function(on){var s=this;s.__fo||(s.__fo={});if(s.__fo[on])return!1;s.__fo[on]={};return!0};

  /* Adobe Consulting Plugin: apl (appendToList) v3.1 (requires AppMeasurement and inList v2.0) */
  s.apl=function(lv,vta,d1,d2,cc){d1=d1?d1:",";d2=d2?d2:d1;if("undefined"===typeof this.inList)return console.log("Adobe Analytics: Problem with apl plugin - inList helper function not available"),lv;if("undefined"!==typeof lv&&"string"!==typeof lv)return console.log("Adobe Analytics: Problem with apl plugin - first passed-in argument is not lv string object"),"";if("string"!==typeof vta)return lv;vta=vta.split(",");for(var g=vta.length,d=0;d<g;d++)this.inList(lv,vta[d],d1,cc)||(lv=lv?lv+d2+vta[d]:vta[d]);return lv};

  /* Adobe Consulting Plugin: inList v2.0 (requires AppMeasurement) */
  s.inList=function(lv,vtc,d,cc){if("string"!==typeof vtc)return!1;if("string"===typeof lv)lv=lv.split(d?d:",");else if("object"!==typeof lv)return!1;d=0;for(var e=lv.length;d<e;d++)if(cc&&vtc===lv[d]||!cc&&vtc.toLowerCase()===lv[d].toLowerCase())return!0;return!1};

  /*eInclude start Plugin_inArray.txt. Adobe Consulting Plugin: in Array v1.0*/
  s.inArr = function(hs,n){for (var i=0; i<hs.length; i++)if (hs[i] == n) return true;return false;};

  /* Adobe Consulting Plugin: getPercentPageViewed v3.01 w/handlePPVevents helper function (Requires AppMeasurement and the p_fo plugin) */
  s.getPercentPageViewed=function(pid,ch){var s=this,a=s.c_r("s_ppv");a=-1<a.indexOf(",")?a.split(","):[];a[0]=s.unescape(a[0]);pid=pid?pid:s.pageName?s.pageName:document.location.href;s.ppvChange=ch?ch:!0;if("undefined"===typeof s.linkType||"o"!==s.linkType)s.ppvID&&s.ppvID===pid||(s.ppvID=pid,s.c_w("s_ppv",""),s.handlePPVevents()),s.p_fo("s_gppvLoad")&&window.addEventListener&&(window.addEventListener("load",s.handlePPVevents,!1),window.addEventListener("click",s.handlePPVevents,
      !1),window.addEventListener("scroll",s.handlePPVevents,!1),window.addEventListener("resize",s.handlePPVevents,!1)),s._ppvPreviousPage=a[0]?a[0]:"",s._ppvHighestPercentViewed=a[1]?a[1]:"",s._ppvInitialPercentViewed=a[2]?a[2]:"",s._ppvHighestPixelsSeen=a[3]?a[3]:""};

  /* Adobe Consulting Plugin: handlePPVevents helper function (for getPercentPageViewed v3.01 Plugin) */
  s.handlePPVevents=function(){if("undefined"!==typeof s_c_il){for(var c=0,d=s_c_il.length;c<d;c++)if(s_c_il[c]&&s_c_il[c].getPercentPageViewed){var a=s_c_il[c];break}if(a&&a.ppvID){var f=Math.max(Math.max(document.body.scrollHeight,document.documentElement.scrollHeight),Math.max(document.body.offsetHeight,document.documentElement.offsetHeight),Math.max(document.body.clientHeight,document.documentElement.clientHeight));c=(window.pageYOffset||window.document.documentElement.scrollTop||window.document.body.scrollTop)+
      (window.innerHeight||document.documentElement.clientHeight||document.body.clientHeight);d=Math.min(Math.round(c/f*100),100);var e="";!a.c_r("s_tp")||a.unescape(a.c_r("s_ppv").split(",")[0])!==a.ppvID||1==a.ppvChange&&a.c_r("s_tp")&&f!=a.c_r("s_tp")?(a.c_w("s_tp",f),a.c_w("s_ppv","")):e=a.c_r("s_ppv");var b=e&&-1<e.indexOf(",")?e.split(",",4):[];f=0<b.length?b[0]:escape(a.ppvID);var g=1<b.length?parseInt(b[1]):d,h=2<b.length?parseInt(b[2]):d;b=3<b.length?parseInt(b[3]):c;0<d&&(e=f+","+(d>g?d:g)+","+
      h+","+(c>b?c:b));a.c_w("s_ppv",e)}}};

  /* Adobe Consulting Plugin: getPreviousValue v2.0 (Requires AppMeasurement) */
  s.getPreviousValue=function(vtc,cn,el){var s=this,g="",a=!0;cn=cn?cn:"s_gpv";if(el){a=!1;el=el.split(",");for(var h=s.events?s.events.split(","):"",e=0,k=el.length;e<k;e++){for(var f=0,l=h.length;f<l;f++)if(el[e]===h[f]){a=!0;break}if(!0===a)break}}!0===a&&(a=new Date,a.setTime(a.getTime()+18E5),s.c_r(cn)&&(g=s.c_r(cn)),vtc?s.c_w(cn,vtc,a):s.c_w(cn,"no previous value",a));return g};

  /* Adobe Consulting Plugin: join v2.0 (requires AppMeasurement) */
  s.join = function(ar,fr,ba,de,wr){var f="";fr=fr?fr:"";ba=ba?ba:"";de=de?de:"";wr=wr?wr:"";for(var b=0,h=ar.length;b<h;b++)f="object"==typeof ar[b]?f+this.join(ar[b],fr,ba,de,wr):f+(wr+ar[b]+wr),b<ar.length-1&&(f+=de);return fr+f+ba};

  /* Adobe Consulting Plugin: Cookie Combining Utility v2.0, requires AppMeasurement */
  if("undefined"===typeof cookieCombiningUtility){var cookieCombiningUtility=!0,removeExpiredCookies=function(){var b=this.c_rr("s_pers"),d=(new Date).getTime(),a="";if(!b)return"";var c=b.split(";");for(var e=0,h=c.length;e<h;e++)(b=c[e].match(/\|([0-9]+)$/))&&parseInt(b[1])>=d&&(a+=c[e]+";");return a},cookieRead=function(b){var d=this.c_rr(b),a=this.removeExpiredCookies();if(d)return d;b=this.escape(b);d=a.indexOf(" "+b+"=");a=0>d?this.c_rr("s_sess"):a;d=a.indexOf(" "+b+"=");if(0>d)return"";var c=
      a.indexOf("|",d);var e=a.indexOf(";",d);c=0<c?c:e;return this.unescape(a.substring(d+2+b.length,0>c?a.length:c))},cookieWrite=function(b,d,a){var c=new Date(0),e=0,h=!1,k=0;if("s_sq"===b)this.c_wr(b,d);else{this.c_wr(b,"",c);b=this.escape(b);var f=this.removeExpiredCookies();c=f.indexOf(" "+b+"=");-1<c&&(f=f.substring(0,c)+f.substring(f.indexOf(";",c)+1),h=!0);var g=this.c_rr("s_sess");c=g.indexOf(" "+b+"=");-1<c&&(g=g.substring(0,c)+g.substring(g.indexOf(";",c)+1),k=!0);c=new Date;if(a){if(1===a){a=
      new Date;var l=a.getYear();a.setYear(l+5+(1900>l?1900:0))}a.getTime()>c.getTime()&&(f+=" "+b+"="+this.escape(d)+"|"+a.getTime()+";",h=!0)}else g+=" "+b+"="+this.escape(d)+";",k=!0;g=g.replace(/%00/g,"");f=f.replace(/%00/g,"");k&&this.c_wr("s_sess",g,0);if(h){for(a=f;a&&-1<a.indexOf(";");)h=parseInt(a.substring(a.indexOf("|")+1,a.indexOf(";"))),a=a.substring(a.indexOf(";")+1),e=e<h?h:e;c.setTime(e);this.c_wr("s_pers",f,c)}return d===this.c_r(this.unescape(b))}},cookieDelete=function(b){this.c_w(b,
      "",new Date(0))};
      s.ccuSetup=function(){var s=this;s.c_wr||(s.c_wr=s.c_w);s.c_rr||(s.c_rr=s.c_r);s.removeExpiredCookies=removeExpiredCookies;s.c_r=s.cookieRead=cookieRead;s.c_w=s.cookieWrite=cookieWrite;s.c_d=s.cookieDelete=cookieDelete};
      s.ccuSetup()};

  /*Adobe Consulting Plugin: Split version:1.5*/
  s.split=function(l,d){var i,x=0,a=new Array;while(l){i=l.indexOf(d);i=i>-1?i:l.length;a[x++]=l.substring(0,i);l=l.substring(i+d.length)}return a};

/*Plugin_TNT*/

s.trackTNT=function(v,p,b){var s=this,n="s_tnt",q="s_tntref",p=p?p:n,v=v?v:n,r="",pm=false,b=b?b:true;if(s.getQueryParam(q)!="")s.referrer=s.getQueryParam(q);else if(s.c_r(q)!=""){s.referrer=s.c_r(q);document.cookie=q+"=;path=/;expires=Thu, 01-Jan-1970 00:00:01 GMT;"}else if(document.cookie.indexOf(q)!=-1&&s.c_r(q)==""||location.search.indexOf(q+"=")!=-1&&s.getQueryParam(q)==""){s.referrer="Typed/Bookmarked";document.cookie=q+"=;path=/;expires=Thu, 01-Jan-1970 00:00:01 GMT;"}if(s.getQueryParam(p)!=
"")pm=s.getQueryParam(p);else if(s.c_r(p)){pm=s.c_r(p);document.cookie=p+"=;path=/;expires=Thu, 01-Jan-1970 00:00:01 GMT;"}else if(s.c_r(p)==""&&s.getQueryParam(p)=="")pm="";if(pm)r+=pm+",";if(window[v]!=undefined)r+=window[v];if(b)window[v]="";return r};


  /* Adobe Consulting Plugin: getQueryParam v3.2 (Requires AppMeasurement and pt plugin) */
  s.getQueryParam=function(qsp,de,url){var s=this,e="",l=function(b,c){-1<c.indexOf("#")&&(-1<c.indexOf("?")?c.indexOf("?")>c.indexOf("#")?(c=c.split("?").join("&"),c=c.split("#").join("?")):c=c.split("#").join("&"):c=c.split("#").join("?"));var h=c.indexOf("?"),de="";b&&(-1<h||-1<c.indexOf("="))&&(h=c.substring(h+1),de=s.pt(h,"&","gpval",b));return de};qsp=qsp.split(",");var m=qsp.length;s.gpval=function(b,c){if(b){var de=b.split("="),url=de[0];de=("string"===typeof de[1])?de[1]:"";if(c.toLowerCase()==url.toLowerCase())return"boolean"===
  typeof de?de:this.unescape(de)}return""};de=de?de:"";url=(url?url:s.pageURL?s.pageURL:location.href)+"";if((4<de.length||-1<de.indexOf("="))&&url&&4>url.length){var b=de;de=url;url=b}for(var k=0;k<m;k++)b=l(qsp[k],url),"string"===typeof b?(b=-1<b.indexOf("#")?b.substring(0,b.indexOf("#")):b,e+=e?de+b:b):e=""===e?b:e+(de+b);return e};

  /* pt - utility function. Adobe Consulting Plugin: pt v2.0 (Requires AppMeasurement) */
  s.pt=function(lv,de,cf,fa){if(!lv||!de||!this[cf])return"";lv=lv.split(de?de:",");de=lv.length;for(var e="",c=0;c<de&&!(e=this[cf](lv[c],fa));c++);return e};

  /*Adobe Consulting Plugin: get value once v2.0*/
  s.getValOnce=function(vtc,cn,et,ep){cn=cn?cn:"s_gvo";et=et?et:0;ep="m"===ep?6E4:864E5;if(vtc&&vtc!==this.c_r(cn)){var e=new Date;e.setTime(e.getTime()+et*ep);this.c_w(cn,vtc,0===et?0:e);return vtc}return""};

  /*Adobe Consulting Plugin: AMEX Visit Num version: 1.0*/
  s.AMEXVisNum=function(){var s=this,e=new Date,cvisit,ct=e.getTime(),c="s_vnum",c2="s_invisit";e.setTime(ct+5*365*24*60*60*1E3);str=s.c_r(c);cvisit=s.c_r(c2);if(cvisit)if(str){e.setTime(ct+30*60*1E3);s.c_w(c2,"true",e);return str}else return"1";else if(str){str++;s.c_w(c,str,e);e.setTime(ct+30*60*1E3);s.c_w(c2,"true",e);return str}else{s.c_w(c,1,e);e.setTime(ct+30*60*1E3);s.c_w(c2,"true",e);return 1}};

  /* Adobe Consulting Plugin: CrossVisitParticipation*/
  s.crossVisitParticipation=function(vts,cn,ed,ns,de,ce,sd){var s=this,n,b=[],q=[],r=[],p=0,d=0,m=new Date;vts="undefined"===typeof vts?"":vts;cn="undefined"===typeof cn?"s_cvp":cn;ed="undefined"===typeof ed?90:ed;ns="undefined"===typeof ns?5:ns;de="undefined"===typeof de?" > ":de;sd="undefined"===typeof sd?!1:sd;s.events&&s.inList(s.events,"undefined"===typeof ce?"":ce)&&(n=!0);if(""===vts)return n&&s.c_w(cn,""),"";vts=s.escape(vts);if((ce=s.c_r(cn))&&""!==ce)for(b=ce.split("],["),d=b.length,ce=0;ce<d;ce++){var f=b[ce];f=s.replace(f,
  "[","");f=s.replace(f,"]","");f=s.replace(f,'"',"");b[ce]=f.split(",")}!1===sd&&0<d&&b[d-1][0]===vts?b[d-1]=[vts,(new Date).getTime()]:b[d]=[vts,(new Date).getTime()];d=b.length;for(ce=0>d-ns?0:d-ns;ce<d;ce++)vts=Math.round((m.getTime()-b[ce][1])/864E5),vts<ed&&(r[p]=s.unescape(b[ce][0]),q[p]=[b[ce][0],b[ce][1]],p++);n?s.c_w(cn,""):(m.setTime(864E5*ed+m.getTime()),s.c_w(cn,s.join(q,"[","]",",",'"'),m));return r.join(de)};

  /*eInclude start Plugin_GetVisitStart.txt version:1.0*/
  s.getVisitStart=function(c){var s=this,n,t=new Date;if(typeof s.callType=="function"&&s.callType()=="+")return 0;if(!c)c="s_visit";t.setTime(t.getTime()+18E5);n=s.c_r(c)?0:1;if(!s.c_w(c,1,t))s.c_w(c,1,0);if(!s.c_r(c))n=0;return n};

  /*eInclude start Plugin_GetDaysSinceLastVisit.txt*/
  s.getDaysSinceLastVisit=function(){var a=new Date,b=a.getTime(),c=this.c_r("s_dslv");a.setTime(b+94608E6);this.c_w("s_dslv",b,a);if(c){a=b-c;if(18E5<a){if(31536E6<a)return"More than a year";if(2592E6<a)return"More than 30 days";if(a<2592E6+1&&6048E5<a)return"More than 7 days";if(a<6048E5+1&&864E5<a)return"Less than 7 days";if(a<864E5+1)return"Less than 1 day"}return""}return"New Visitor"};

  //Audience Management Module v.2.17.0 - Packaged with appMeasurement
  //Replaces DIL, used for Audience Manager, uses DIL 9.3
  function AppMeasurement_Module_AudienceManagement(d){var a=this;a.s=d;var b=window;b.s_c_in||(b.s_c_il=[],b.s_c_in=0);a._il=b.s_c_il;a._in=b.s_c_in;a._il[a._in]=a;b.s_c_in++;a._c="s_m";a.setup=function(c){b.DIL&&c&&(c.disableDefaultRequest=!0,c.disableScriptAttachment=!0,c.disableCORS=!0,c.secureDataCollection=!1,a.instance=b.DIL.create(c),a.tools=b.DIL.tools)};a.isReady=function(){return a.instance?!0:!1};a.getEventCallConfigParams=function(){return a.instance&&a.instance.api&&a.instance.api.getEventCallConfigParams?
  a.instance.api.getEventCallConfigParams():{}};a.passData=function(b){a.instance&&a.instance.api&&a.instance.api.passData&&a.instance.api.passData(b)}}
  !function(){"use strict";var r,o,a;"function"!=typeof window.DIL&&(window.DIL=function(n){var c,e,I,r,u,h,t,o,s,i,a,d,y,l,f,g,p,m,b,v,D,O=[],C={};function S(e){return void 0===e||!0===e}n!==Object(n)&&(n={}),I=n.partner,r=n.containerNSID,u=n.mappings,h=n.uuidCookie,t=!0===n.enableErrorReporting,o=n.visitorService,s=n.declaredId,i=!0===n.delayAllUntilWindowLoad,a=S(n.secureDataCollection),d="boolean"==typeof n.isCoopSafe?n.isCoopSafe:null,y=S(n.enableHrefererParam),l=S(n.enableLogging),f=S(n.enableUrlDestinations),g=S(n.enableCookieDestinations),p=!0===n.disableDefaultRequest,m=n.afterResultForDefaultRequest,b=n.visitorConstructor,v=!0===n.disableCORS,D=!0===n.ignoreHardDependencyOnVisitorAPI,t&&DIL.errorModule.activate(),D&&O.push("Warning: this instance is configured to ignore the hard dependency on the VisitorAPI service. This means that no URL destinations will be fired if the instance has no connection to VisitorAPI. If the VisitorAPI service is not instantiated, ID syncs will not be fired either.");var w=!0===window._dil_unit_tests;if((c=arguments[1])&&O.push(c+""),!I||"string"!=typeof I){var _={name:"error",message:c="DIL partner is invalid or not specified in initConfig",filename:"dil.js"};return DIL.errorModule.handleError(_),new Error(c)}if(c="DIL containerNSID is invalid or not specified in initConfig, setting to default of 0",(r||"number"==typeof r)&&(r=parseInt(r,10),!isNaN(r)&&0<=r&&(c="")),c&&(r=0,O.push(c),c=""),(e=DIL.getDil(I,r))instanceof DIL&&e.api.getPartner()===I&&e.api.getContainerNSID()===r)return e;if(!(this instanceof DIL))return new DIL(n,"DIL was not instantiated with the 'new' operator, returning a valid instance with partner = "+I+" and containerNSID = "+r);DIL.registerDil(this,I,r);var R={doesConsoleLogExist:window.console===Object(window.console)&&"function"==typeof window.console.log,logMemo:{},log:function(e){(O.push(e),l&&this.doesConsoleLogExist)&&Function.prototype.bind.call(window.console.log,window.console).apply(window.console,arguments)},logOnce:function(e){this.logMemo[e]||(this.logMemo[e]=!0,R.log(e))}},E={IS_HTTPS:a||"https:"===document.location.protocol,SIX_MONTHS_IN_MINUTES:259200,IE_VERSION:function(){if(document.documentMode)return document.documentMode;for(var e=7;4<e;e--){var t=document.createElement("div");if(t.innerHTML="\x3c!--[if IE "+e+"]><span></span><![endif]--\x3e",t.getElementsByTagName("span").length)return t=null,e}return null}()};E.IS_IE_LESS_THAN_10="number"==typeof E.IE_VERSION&&E.IE_VERSION<10;var P={stuffed:{}},L={},A={firingQueue:[],fired:[],firing:!1,sent:[],errored:[],reservedKeys:{sids:!0,pdata:!0,logdata:!0,callback:!0,postCallbackFn:!0,useImageRequest:!0},firstRequestHasFired:!1,abortRequests:!1,num_of_cors_responses:0,num_of_cors_errors:0,corsErrorSources:[],num_of_img_responses:0,num_of_img_errors:0,platformParams:{d_nsid:r+"",d_rtbd:"json",d_jsonv:DIL.jsonVersion+"",d_dst:"1"},nonModStatsParams:{d_rtbd:!0,d_dst:!0,d_cts:!0,d_rs:!0},modStatsParams:null,adms:{TIME_TO_CATCH_ALL_REQUESTS_RELEASE:3e4,calledBack:!1,mid:null,noVisitorAPI:null,VisitorAPI:null,instance:null,releaseType:"no VisitorAPI",isOptedOut:!0,isOptedOutCallbackCalled:!1,admsProcessingStarted:!1,process:function(e){try{if(this.admsProcessingStarted)return;this.admsProcessingStarted=!0;var t,n,s,i=o;if("function"!=typeof e||"function"!=typeof e.getInstance)throw this.noVisitorAPI=!0,new Error("Visitor does not exist.");if(i!==Object(i)||!(t=i.namespace)||"string"!=typeof t)throw this.releaseType="no namespace",new Error("DIL.create() needs the initConfig property `visitorService`:{namespace:'<Experience Cloud Org ID>'}");if(!((n=e.getInstance(t,{idSyncContainerID:r}))===Object(n)&&n instanceof e&&"function"==typeof n.isAllowed&&"function"==typeof n.getMarketingCloudVisitorID&&"function"==typeof n.getCustomerIDs&&"function"==typeof n.isOptedOut&&"function"==typeof n.publishDestinations))throw this.releaseType="invalid instance",s="Invalid Visitor instance.",n===Object(n)&&"function"!=typeof n.publishDestinations&&(s+=" In particular, visitorInstance.publishDestinations is not a function. This is needed to fire URL destinations in DIL v8.0+ and should be present in Visitor v3.3.0+ ."),new Error(s);if(this.VisitorAPI=e,!n.isAllowed())return this.releaseType="VisitorAPI is not allowed to write cookies",void this.releaseRequests();this.instance=n,this.waitForMidToReleaseRequests()}catch(e){if(!D)throw new Error("Error in processing Visitor API, which is a hard dependency for DIL v8.0+: "+e.message);this.releaseRequests()}},waitForMidToReleaseRequests:function(){var t=this;this.instance&&(this.instance.getMarketingCloudVisitorID(function(e){t.mid=e,t.releaseType="VisitorAPI",t.releaseRequests()},!0),(!N.exists||!N.isIabContext&&N.isApproved()||N.isIabContext&&B.hasGoSignal())&&setTimeout(function(){"VisitorAPI"!==t.releaseType&&(t.releaseType="timeout",t.releaseRequests())},this.getLoadTimeout()))},releaseRequests:function(){this.calledBack=!0,A.registerRequest()},getMarketingCloudVisitorID:function(){return this.instance?this.instance.getMarketingCloudVisitorID():null},getMIDQueryString:function(){var e=k.isPopulatedString,t=this.getMarketingCloudVisitorID();return e(this.mid)&&this.mid===t||(this.mid=t),e(this.mid)?"d_mid="+this.mid+"&":""},getCustomerIDs:function(){return this.instance?this.instance.getCustomerIDs():null},getCustomerIDsQueryString:function(e){if(e!==Object(e))return"";var t,n,s,i,r="",o=[],a=[];for(t in e)e.hasOwnProperty(t)&&(n=e[a[0]=t])===Object(n)&&(a[1]=n.id||"",a[2]=n.authState||0,o.push(a),a=[]);if(i=o.length)for(s=0;s<i;s++)r+="&d_cid_ic="+x.encodeAndBuildRequest(o[s],"%01");return r},getIsOptedOut:function(){this.instance?this.instance.isOptedOut([this,this.isOptedOutCallback],this.VisitorAPI.OptOut.GLOBAL,!0):(this.isOptedOut=!1,this.isOptedOutCallbackCalled=!0)},isOptedOutCallback:function(e){this.isOptedOut=e,this.isOptedOutCallbackCalled=!0,A.registerRequest(),N.isIabContext()&&B.checkQueryStringObject()},getLoadTimeout:function(){var e=this.instance;if(e){if("function"==typeof e.getLoadTimeout)return e.getLoadTimeout();if(void 0!==e.loadTimeout)return e.loadTimeout}return this.TIME_TO_CATCH_ALL_REQUESTS_RELEASE}},declaredId:{declaredId:{init:null,request:null},declaredIdCombos:{},setDeclaredId:function(e,t){var n=k.isPopulatedString,s=encodeURIComponent;if(e===Object(e)&&n(t)){var i=e.dpid,r=e.dpuuid,o=null;if(n(i)&&n(r))return o=s(i)+"$"+s(r),!0===this.declaredIdCombos[o]?"setDeclaredId: combo exists for type '"+t+"'":(this.declaredIdCombos[o]=!0,this.declaredId[t]={dpid:i,dpuuid:r},"setDeclaredId: succeeded for type '"+t+"'")}return"setDeclaredId: failed for type '"+t+"'"},getDeclaredIdQueryString:function(){var e=this.declaredId.request,t=this.declaredId.init,n=encodeURIComponent,s="";return null!==e?s="&d_dpid="+n(e.dpid)+"&d_dpuuid="+n(e.dpuuid):null!==t&&(s="&d_dpid="+n(t.dpid)+"&d_dpuuid="+n(t.dpuuid)),s}},registerRequest:function(e){var t,n=this.firingQueue;e===Object(e)&&(n.push(e),e.isDefaultRequest||(p=!0)),this.firing||!n.length||i&&!DIL.windowLoaded||(this.adms.isOptedOutCallbackCalled||this.adms.getIsOptedOut(),this.adms.calledBack&&!this.adms.isOptedOut&&this.adms.isOptedOutCallbackCalled&&(N.isApproved()||B.hasGoSignal())&&(this.adms.isOptedOutCallbackCalled=!1,(t=n.shift()).src=t.src.replace(/&d_nsid=/,"&"+this.adms.getMIDQueryString()+B.getQueryString()+"d_nsid="),k.isPopulatedString(t.corsPostData)&&(t.corsPostData=t.corsPostData.replace(/^d_nsid=/,this.adms.getMIDQueryString()+B.getQueryString()+"d_nsid=")),V.fireRequest(t),this.firstRequestHasFired||"script"!==t.tag&&"cors"!==t.tag||(this.firstRequestHasFired=!0)))},processVisitorAPI:function(){this.adms.process(b||window.Visitor)},getCoopQueryString:function(){var e="";return!0===d?e="&d_coop_safe=1":!1===d&&(e="&d_coop_unsafe=1"),e}};C.requestController=A;var q,j,T={sendingMessages:!1,messages:[],messagesPosted:[],destinations:[],destinationsPosted:[],jsonForComparison:[],jsonDuplicates:[],jsonWaiting:[],jsonProcessed:[],publishDestinationsVersion:null,requestToProcess:function(e,t){var n,s=this;function i(){s.jsonForComparison.push(e),s.jsonWaiting.push([e,t])}if(e&&!k.isEmptyObject(e))if(n=JSON.stringify(e.dests||[]),this.jsonForComparison.length){var r,o,a,d=!1;for(r=0,o=this.jsonForComparison.length;r<o;r++)if(a=this.jsonForComparison[r],n===JSON.stringify(a.dests||[])){d=!0;break}d?this.jsonDuplicates.push(e):i()}else i();if(this.jsonWaiting.length){var u=this.jsonWaiting.shift();this.process(u[0],u[1]),this.requestToProcess()}this.messages.length&&!this.sendingMessages&&this.sendMessages()},process:function(e){if(f){var t,n,s,i,r,o,a=encodeURIComponent,d=this.getPublishDestinationsVersion(),u=!1;if(-1!==d){if((t=e.dests)&&t instanceof Array&&(n=t.length)){for(s=0;s<n;s++)i=t[s],o=[a("dests"),a(i.id||""),a(i.y||""),a(i.c||"")].join("|"),this.addMessage(o),r={url:i.c,hideReferrer:void 0===i.hr||!!i.hr,message:o},this.addDestination(r),void 0!==i.hr&&(u=!0);1===d&&u&&R.logOnce("Warning: visitorInstance.publishDestinations version is old (Visitor v3.3.0 to v4.0.0). URL destinations will not have the option of being fired on page, only in the iframe.")}this.jsonProcessed.push(e)}}},addMessage:function(e){this.messages.push(e)},addDestination:function(e){this.destinations.push(e)},sendMessages:function(){this.sendingMessages||(this.sendingMessages=!0,f&&this.messages.length&&this.publishDestinations())},publishDestinations:function(){var t=this,e=A.adms.instance,n=[],s=[],i=function(e){R.log("visitor.publishDestinations() result: "+(e.error||e.message)),t.sendingMessages=!1,t.requestToProcess()},r=function(){t.messages=[],t.destinations=[]};return 1===this.publishDestinationsVersion?(x.extendArray(n,this.messages),x.extendArray(this.messagesPosted,this.messages),r(),e.publishDestinations(I,n,i),"Called visitor.publishDestinations() version 1"):1<this.publishDestinationsVersion?(x.extendArray(s,this.destinations),x.extendArray(this.destinationsPosted,this.destinations),r(),e.publishDestinations({subdomain:I,callback:i,urlDestinations:s}),"Called visitor.publishDestinations() version > 1"):void 0},getPublishDestinationsVersion:function(){if(null!==this.publishDestinationsVersion)return this.publishDestinationsVersion;var e=A.adms.instance,n=-1;return e.publishDestinations(null,null,function(e){if(e===Object(e)){var t=e.error;"subdomain is not a populated string."===t?n=1:"Invalid parameters passed."===t&&(n=2)}}),this.publishDestinationsVersion=n}},M={traits:function(e){return k.isValidPdata(e)&&(L.sids instanceof Array||(L.sids=[]),x.extendArray(L.sids,e)),this},pixels:function(e){return k.isValidPdata(e)&&(L.pdata instanceof Array||(L.pdata=[]),x.extendArray(L.pdata,e)),this},logs:function(e){return k.isValidLogdata(e)&&(L.logdata!==Object(L.logdata)&&(L.logdata={}),x.extendObject(L.logdata,e)),this},customQueryParams:function(e){return k.isEmptyObject(e)||x.extendObject(L,e,A.reservedKeys),this},signals:function(e,t){var n,s=e;if(!k.isEmptyObject(s)){if(t&&"string"==typeof t)for(n in s={},e)e.hasOwnProperty(n)&&(s[t+n]=e[n]);x.extendObject(L,s,A.reservedKeys)}return this},declaredId:function(e){return A.declaredId.setDeclaredId(e,"request"),this},result:function(e){return"function"==typeof e&&(L.callback=e),this},afterResult:function(e){return"function"==typeof e&&(L.postCallbackFn=e),this},useImageRequest:function(){return L.useImageRequest=!0,this},clearData:function(){return L={},this},submit:function(e){return L.isDefaultRequest=!!e,V.submitRequest(L),L={},this},getPartner:function(){return I},getContainerNSID:function(){return r},getEventLog:function(){return O},getState:function(){var e={},t={};return x.extendObject(e,A,{registerRequest:!0}),x.extendObject(t,T,{requestToProcess:!0,process:!0,sendMessages:!0}),{initConfig:n,pendingRequest:L,otherRequestInfo:e,destinationPublishingInfo:t,log:O}},idSync:function(){throw new Error("Please use the `idSyncByURL` method of the Experience Cloud ID Service (Visitor) instance")},aamIdSync:function(){throw new Error("Please use the `idSyncByDataSource` method of the Experience Cloud ID Service (Visitor) instance")},passData:function(e){return k.isEmptyObject(e)?"Error: json is empty or not an object":(V.defaultCallback(e),e)},getPlatformParams:function(){return A.platformParams},getEventCallConfigParams:function(){var e,t=A,n=t.modStatsParams,s=t.platformParams;if(!n){for(e in n={},s)s.hasOwnProperty(e)&&!t.nonModStatsParams[e]&&(n[e.replace(/^d_/,"")]=s[e]);!0===d?n.coop_safe=1:!1===d&&(n.coop_unsafe=1),t.modStatsParams=n}return n},setAsCoopSafe:function(){return d=!0,this},setAsCoopUnsafe:function(){return d=!1,this},getEventCallIabSignals:function(e){var t;return e!==Object(e)?"Error: config is not an object":"function"!=typeof e.callback?"Error: config.callback is not a function":(t=parseInt(e.timeout,10),isNaN(t)&&(t=null),void B.getQueryStringObject(e.callback,t))}},V={corsMetadata:(q="none","undefined"!=typeof XMLHttpRequest&&XMLHttpRequest===Object(XMLHttpRequest)&&"withCredentials"in new XMLHttpRequest&&(q="XMLHttpRequest"),{corsType:q}),getCORSInstance:function(){return"none"===this.corsMetadata.corsType?null:new window[this.corsMetadata.corsType]},submitRequest:function(e){return A.registerRequest(V.createQueuedRequest(e)),!0},createQueuedRequest:function(e){var t,n,s,i,r,o=e.callback,a="img",d=e.isDefaultRequest;if(delete e.isDefaultRequest,!k.isEmptyObject(u))for(s in u)if(u.hasOwnProperty(s)){if(null==(i=u[s])||""===i)continue;if(s in e&&!(i in e)&&!(i in A.reservedKeys)){if(null==(r=e[s])||""===r)continue;e[i]=r}}return k.isValidPdata(e.sids)||(e.sids=[]),k.isValidPdata(e.pdata)||(e.pdata=[]),k.isValidLogdata(e.logdata)||(e.logdata={}),e.logdataArray=x.convertObjectToKeyValuePairs(e.logdata,"=",!0),e.logdataArray.push("_ts="+(new Date).getTime()),"function"!=typeof o&&(o=this.defaultCallback),t=this.makeRequestSrcData(e),(n=this.getCORSInstance())&&!0!==e.useImageRequest&&(a="cors"),{tag:a,src:t.src,corsSrc:t.corsSrc,callbackFn:o,postCallbackFn:e.postCallbackFn,useImageRequest:!!e.useImageRequest,requestData:e,corsInstance:n,corsPostData:t.corsPostData,isDefaultRequest:d}},defaultCallback:function(e,t){var n,s,i,r,o,a,d,u,c;if(g&&(n=e.stuff)&&n instanceof Array&&(s=n.length))for(i=0;i<s;i++)(r=n[i])&&r===Object(r)&&(o=r.cn,a=r.cv,void 0!==(d=r.ttl)&&""!==d||(d=Math.floor(x.getMaxCookieExpiresInMinutes()/60/24)),u=r.dmn||"."+document.domain.replace(/^www\./,""),c=r.type,o&&(a||"number"==typeof a)&&("var"!==c&&(d=parseInt(d,10))&&!isNaN(d)&&x.setCookie(o,a,24*d*60,"/",u,!1),P.stuffed[o]=a));var l,f,p=e.uuid;k.isPopulatedString(p)&&(k.isEmptyObject(h)||("string"==typeof(l=h.path)&&l.length||(l="/"),f=parseInt(h.days,10),isNaN(f)&&(f=100),x.setCookie(h.name||"aam_did",p,24*f*60,l,h.domain||"."+document.domain.replace(/^www\./,""),!0===h.secure))),A.abortRequests||T.requestToProcess(e,t)},makeRequestSrcData:function(r){r.sids=k.removeEmptyArrayValues(r.sids||[]),r.pdata=k.removeEmptyArrayValues(r.pdata||[]);var o=A,e=o.platformParams,t=x.encodeAndBuildRequest(r.sids,","),n=x.encodeAndBuildRequest(r.pdata,","),s=(r.logdataArray||[]).join("&");delete r.logdataArray;var i,a,d=encodeURIComponent,u=E.IS_HTTPS?"https://":"http://",c=o.declaredId.getDeclaredIdQueryString(),l=o.adms.instance?o.adms.getCustomerIDsQueryString(o.adms.getCustomerIDs()):"",f=function(){var e,t,n,s,i=[];for(e in r)if(!(e in o.reservedKeys)&&r.hasOwnProperty(e))if(t=r[e],e=d(e),t instanceof Array)for(n=0,s=t.length;n<s;n++)i.push(e+"="+d(t[n]));else i.push(e+"="+d(t));return i.length?"&"+i.join("&"):""}(),p="d_dil_ver="+d(DIL.version),h="d_nsid="+e.d_nsid+o.getCoopQueryString()+c+l+(t.length?"&d_sid="+t:"")+(n.length?"&d_px="+n:"")+(s.length?"&d_ld="+d(s):""),g="&d_rtbd="+e.d_rtbd+"&d_jsonv="+e.d_jsonv+"&d_dst="+e.d_dst,m=y?"&h_referer="+d(location.href):"";return a=(i=u+I+".demdex.net/event")+"?"+p+"&"+h+g+f+m,{corsSrc:i+"?"+p+"&_ts="+(new Date).getTime(),src:a,corsPostData:h+g+f+m,isDeclaredIdCall:""!==c}},fireRequest:function(e){if("img"===e.tag)this.fireImage(e);else{var t=A.declaredId,n=t.declaredId.request||t.declaredId.init||{},s={dpid:n.dpid||"",dpuuid:n.dpuuid||""};this.fireCORS(e,s)}},fireImage:function(t){var e,n,s=A;s.abortRequests||(s.firing=!0,e=new Image(0,0),s.sent.push(t),e.onload=function(){s.firing=!1,s.fired.push(t),s.num_of_img_responses++,s.registerRequest()},n=function(e){c="imgAbortOrErrorHandler received the event of type "+e.type,R.log(c),s.abortRequests=!0,s.firing=!1,s.errored.push(t),s.num_of_img_errors++,s.registerRequest()},e.addEventListener("error",n),e.addEventListener("abort",n),e.src=t.src)},fireCORS:function(s,i){var r=this,o=A,e=this.corsMetadata.corsType,t=s.corsSrc,n=s.corsInstance,a=s.corsPostData,d=s.postCallbackFn,u="function"==typeof d;if(!o.abortRequests&&!v){o.firing=!0;try{n.open("post",t,!0),"XMLHttpRequest"===e&&(n.withCredentials=!0,n.setRequestHeader("Content-Type","application/x-www-form-urlencoded"),n.onreadystatechange=function(){4===this.readyState&&200===this.status&&function(e){var t;try{if((t=JSON.parse(e))!==Object(t))return r.handleCORSError(s,i,"Response is not JSON")}catch(e){return r.handleCORSError(s,i,"Error parsing response as JSON")}try{var n=s.callbackFn;o.firing=!1,o.fired.push(s),o.num_of_cors_responses++,n(t,i),u&&d(t,i)}catch(e){e.message="DIL handleCORSResponse caught error with message "+e.message,c=e.message,R.log(c),e.filename=e.filename||"dil.js",e.partner=I,DIL.errorModule.handleError(e);try{n({error:e.name+"|"+e.message},i),u&&d({error:e.name+"|"+e.message},i)}catch(e){}}finally{o.registerRequest()}}(this.responseText)}),n.onerror=function(){r.handleCORSError(s,i,"onerror")},n.ontimeout=function(){r.handleCORSError(s,i,"ontimeout")},n.send(a)}catch(e){this.handleCORSError(s,i,"try-catch")}o.sent.push(s),o.declaredId.declaredId.request=null}},handleCORSError:function(e,t,n){A.num_of_cors_errors++,A.corsErrorSources.push(n)}},k={isValidPdata:function(e){return!!(e instanceof Array&&this.removeEmptyArrayValues(e).length)},isValidLogdata:function(e){return!this.isEmptyObject(e)},isEmptyObject:function(e){if(e!==Object(e))return!0;var t;for(t in e)if(e.hasOwnProperty(t))return!1;return!0},removeEmptyArrayValues:function(e){var t,n=0,s=e.length,i=[];for(n=0;n<s;n++)null!=(t=e[n])&&""!==t&&i.push(t);return i},isPopulatedString:function(e){return"string"==typeof e&&e.length}},x={convertObjectToKeyValuePairs:function(e,t,n){var s,i,r=[];for(s in t||(t="="),e)e.hasOwnProperty(s)&&null!=(i=e[s])&&""!==i&&r.push(s+t+(n?encodeURIComponent(i):i));return r},encodeAndBuildRequest:function(e,t){return e.map(function(e){return encodeURIComponent(e)}).join(t)},getCookie:function(e){var t,n,s,i=e+"=",r=document.cookie.split(";");for(t=0,n=r.length;t<n;t++){for(s=r[t];" "===s.charAt(0);)s=s.substring(1,s.length);if(0===s.indexOf(i))return decodeURIComponent(s.substring(i.length,s.length))}return null},setCookie:function(e,t,n,s,i,r){var o=new Date;n&&(n=1e3*n*60),document.cookie=e+"="+encodeURIComponent(t)+(n?";expires="+new Date(o.getTime()+n).toUTCString():"")+(s?";path="+s:"")+(i?";domain="+i:"")+(r?";secure":"")},extendArray:function(e,t){return e instanceof Array&&t instanceof Array&&(Array.prototype.push.apply(e,t),!0)},extendObject:function(e,t,n){var s;if(e!==Object(e)||t!==Object(t))return!1;for(s in t)if(t.hasOwnProperty(s)){if(!k.isEmptyObject(n)&&s in n)continue;e[s]=t[s]}return!0},getMaxCookieExpiresInMinutes:function(){return E.SIX_MONTHS_IN_MINUTES},replaceMethodsWithFunction:function(e,t){var n;if(e===Object(e)&&"function"==typeof t)for(n in e)e.hasOwnProperty(n)&&"function"==typeof e[n]&&(e[n]=t)}},N=(j=C.requestController,{exists:null,instance:null,aamIsApproved:null,init:function(){var e=this;this.checkIfExists()?(this.exists=!0,this.instance=window.adobe.optIn,this.instance.fetchPermissions(function(){e.callback()},!0)):this.exists=!1},checkIfExists:function(){return window.adobe===Object(window.adobe)&&window.adobe.optIn===Object(window.adobe.optIn)},callback:function(){this.aamIsApproved=this.instance.isApproved([this.instance.Categories.AAM]),j.adms.waitForMidToReleaseRequests(),j.adms.getIsOptedOut()},isApproved:function(){return!this.isIabContext()&&!j.adms.isOptedOut&&(!this.exists||this.aamIsApproved)},isIabContext:function(){return this.instance&&this.instance.isIabContext}});C.optIn=N;var F,Q,H,U,B=(Q=(F=C).requestController,H=F.optIn,U={isVendorConsented:null,doesGdprApply:null,consentString:null,queryStringObjectCallbacks:[],init:function(){this.fetchConsentData()},hasGoSignal:function(){return!(!(H.isIabContext()&&this.isVendorConsented&&this.doesGdprApply&&"string"==typeof this.consentString&&this.consentString.length)||Q.adms.isOptedOut)},fetchConsentData:function(n,e){var s=this,t={};"function"!=typeof n&&(n=function(){}),H.instance&&H.isIabContext()?(e&&(t.timeout=e),H.instance.execute({command:"iabPlugin.fetchConsentData",params:t,callback:function(e,t){t===Object(t)?(s.doesGdprApply=!!t.gdprApplies,s.consentString=t.consentString||""):(s.doesGdprApply=!1,s.consentString=""),s.isVendorConsented=H.instance.isApproved(H.instance.Categories.AAM),e?n({}):s.checkQueryStringObject(n),Q.adms.waitForMidToReleaseRequests()}})):n({})},getQueryString:function(){return H.isIabContext()?"gdpr="+(this.doesGdprApply?1:0)+"&gdpr_consent="+this.consentString+"&":""},getQueryStringObject:function(e,t){this.fetchConsentData(e,t)},checkQueryStringObject:function(e){U.hasGoSignal()&&"function"==typeof e&&e({gdpr:this.doesGdprApply?1:0,gdpr_consent:this.consentString})}});C.iab=B,"error"===I&&0===r&&window.addEventListener("load",function(){DIL.windowLoaded=!0});var G=!1,W=function(){G||(G=!0,A.registerRequest(),X())},X=function(){setTimeout(function(){p||A.firstRequestHasFired||("function"==typeof m?M.afterResult(m).submit(!0):M.submit(!0))},DIL.constants.TIME_TO_DEFAULT_REQUEST)},K=document;"error"!==I&&(DIL.windowLoaded?W():"complete"!==K.readyState&&"loaded"!==K.readyState?window.addEventListener("load",function(){DIL.windowLoaded=!0,W()}):(DIL.windowLoaded=!0,W())),A.declaredId.setDeclaredId(s,"init"),N.init(),B.init(),A.processVisitorAPI();E.IS_IE_LESS_THAN_10&&x.replaceMethodsWithFunction(M,function(){return this}),this.api=M,this.getStuffedVariable=function(e){var t=P.stuffed[e];return t||"number"==typeof t||(t=x.getCookie(e))||"number"==typeof t||(t=""),t},this.validators=k,this.helpers=x,this.constants=E,this.log=O,this.pendingRequest=L,this.requestController=A,this.destinationPublishing=T,this.requestProcs=V,this.units=C,this.initConfig=n,this.logger=R,w&&(this.variables=P,this.callWindowLoadFunctions=W)},DIL.extendStaticPropertiesAndMethods=function(e){var t;if(e===Object(e))for(t in e)e.hasOwnProperty(t)&&(this[t]=e[t])},DIL.extendStaticPropertiesAndMethods({version:"9.3",jsonVersion:1,constants:{TIME_TO_DEFAULT_REQUEST:500},variables:{scriptNodeList:document.getElementsByTagName("script")},windowLoaded:!1,dils:{},isAddedPostWindowLoad:function(){var e=arguments[0];this.windowLoaded="function"==typeof e?!!e():"boolean"!=typeof e||e},create:function(e){try{return new DIL(e)}catch(e){throw new Error("Error in attempt to create DIL instance with DIL.create(): "+e.message)}},registerDil:function(e,t,n){var s=t+"$"+n;s in this.dils||(this.dils[s]=e)},getDil:function(e,t){var n;return"string"!=typeof e&&(e=""),t||(t=0),(n=e+"$"+t)in this.dils?this.dils[n]:new Error("The DIL instance with partner = "+e+" and containerNSID = "+t+" was not found")},dexGetQSVars:function(e,t,n){var s=this.getDil(t,n);return s instanceof this?s.getStuffedVariable(e):""}}),DIL.errorModule=(r=DIL.create({partner:"error",containerNSID:0,ignoreHardDependencyOnVisitorAPI:!0}),a=!(o={harvestererror:14138,destpuberror:14139,dpmerror:14140,generalerror:14137,error:14137,noerrortypedefined:15021,evalerror:15016,rangeerror:15017,referenceerror:15018,typeerror:15019,urierror:15020}),{activate:function(){a=!0},handleError:function(e){if(!a)return"DIL error module has not been activated";e!==Object(e)&&(e={});var t=e.name?(e.name+"").toLowerCase():"",n=t in o?o[t]:o.noerrortypedefined,s=[],i={name:t,filename:e.filename?e.filename+"":"",partner:e.partner?e.partner+"":"no_partner",site:e.site?e.site+"":document.location.href,message:e.message?e.message+"":""};return s.push(n),r.api.pixels(s).logs(i).useImageRequest().submit(),"DIL error report sent"},pixelMap:o}),DIL.tools={},DIL.modules={helpers:{}})}();

  /* END Module Audience Management - used for AAM - version 2.17.0 */

  s.loadModule("AudienceManagement");

  /*
  ============== DO NOT ALTER ANYTHING BELOW THIS LINE ! ===============

  AppMeasurement for JavaScript version: 2.17.0
  Copyright 1996-2016 Adobe, Inc. All Rights Reserved
  More info available at http://www.adobe.com/marketing-cloud.html
   */
  function AppMeasurement(r){var a=this;a.version="2.17.0";var h=window;h.s_c_in||(h.s_c_il=[],h.s_c_in=0);a._il=h.s_c_il;a._in=h.s_c_in;a._il[a._in]=a;h.s_c_in++;a._c="s_c";var q=h.AppMeasurement.ec;q||(q=null);var p=h,m,s;try{for(m=p.parent,s=p.location;m&&m.location&&s&&""+m.location!=""+s&&p.location&&""+m.location!=""+p.location&&m.location.host==s.host;)p=m,m=p.parent}catch(u){}a.C=function(a){try{console.log(a)}catch(b){}};a.Pa=function(a){return""+parseInt(a)==""+a};a.replace=function(a,b,d){return!a||
  0>a.indexOf(b)?a:a.split(b).join(d)};a.escape=function(c){var b,d;if(!c)return c;c=encodeURIComponent(c);for(b=0;7>b;b++)d="+~!*()'".substring(b,b+1),0<=c.indexOf(d)&&(c=a.replace(c,d,"%"+d.charCodeAt(0).toString(16).toUpperCase()));return c};a.unescape=function(c){if(!c)return c;c=0<=c.indexOf("+")?a.replace(c,"+"," "):c;try{return decodeURIComponent(c)}catch(b){}return unescape(c)};a.Kb=function(){var c=h.location.hostname,b=a.fpCookieDomainPeriods,d;b||(b=a.cookieDomainPeriods);if(c&&!a.Ia&&!/^[0-9.]+$/.test(c)&&
  (b=b?parseInt(b):2,b=2<b?b:2,d=c.lastIndexOf("."),0<=d)){for(;0<=d&&1<b;)d=c.lastIndexOf(".",d-1),b--;a.Ia=0<d?c.substring(d):c}return a.Ia};a.c_r=a.cookieRead=function(c){c=a.escape(c);var b=" "+a.d.cookie,d=b.indexOf(" "+c+"="),f=0>d?d:b.indexOf(";",d);c=0>d?"":a.unescape(b.substring(d+2+c.length,0>f?b.length:f));return"[[B]]"!=c?c:""};a.c_w=a.cookieWrite=function(c,b,d){var f=a.Kb(),e=a.cookieLifetime,g;b=""+b;e=e?(""+e).toUpperCase():"";d&&"SESSION"!=e&&"NONE"!=e&&((g=""!=b?parseInt(e?e:0):-60)?
  (d=new Date,d.setTime(d.getTime()+1E3*g)):1===d&&(d=new Date,g=d.getYear(),d.setYear(g+2+(1900>g?1900:0))));return c&&"NONE"!=e?(a.d.cookie=a.escape(c)+"="+a.escape(""!=b?b:"[[B]]")+"; path=/;"+(d&&"SESSION"!=e?" expires="+d.toUTCString()+";":"")+(f?" domain="+f+";":""),a.cookieRead(c)==b):0};a.Hb=function(){var c=a.Util.getIeVersion();"number"===typeof c&&10>c&&(a.unsupportedBrowser=!0,a.ub(a,function(){}))};a.ub=function(a,b){for(var d in a)a.hasOwnProperty(d)&&"function"===typeof a[d]&&(a[d]=b)};
  a.K=[];a.ea=function(c,b,d){if(a.Ja)return 0;a.maxDelay||(a.maxDelay=250);var f=0,e=(new Date).getTime()+a.maxDelay,g=a.d.visibilityState,k=["webkitvisibilitychange","visibilitychange"];g||(g=a.d.webkitVisibilityState);if(g&&"prerender"==g){if(!a.fa)for(a.fa=1,d=0;d<k.length;d++)a.d.addEventListener(k[d],function(){var c=a.d.visibilityState;c||(c=a.d.webkitVisibilityState);"visible"==c&&(a.fa=0,a.delayReady())});f=1;e=0}else d||a.u("_d")&&(f=1);f&&(a.K.push({m:c,a:b,t:e}),a.fa||setTimeout(a.delayReady,
  a.maxDelay));return f};a.delayReady=function(){var c=(new Date).getTime(),b=0,d;for(a.u("_d")?b=1:a.ya();0<a.K.length;){d=a.K.shift();if(b&&!d.t&&d.t>c){a.K.unshift(d);setTimeout(a.delayReady,parseInt(a.maxDelay/2));break}a.Ja=1;a[d.m].apply(a,d.a);a.Ja=0}};a.setAccount=a.sa=function(c){var b,d;if(!a.ea("setAccount",arguments))if(a.account=c,a.allAccounts)for(b=a.allAccounts.concat(c.split(",")),a.allAccounts=[],b.sort(),d=0;d<b.length;d++)0!=d&&b[d-1]==b[d]||a.allAccounts.push(b[d]);else a.allAccounts=
  c.split(",")};a.foreachVar=function(c,b){var d,f,e,g,k="";e=f="";if(a.lightProfileID)d=a.O,(k=a.lightTrackVars)&&(k=","+k+","+a.ka.join(",")+",");else{d=a.g;if(a.pe||a.linkType)k=a.linkTrackVars,f=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(k=a[e].ac,f=a[e].$b));k&&(k=","+k+","+a.F.join(",")+",");f&&k&&(k+=",events,")}b&&(b=","+b+",");for(f=0;f<d.length;f++)e=d[f],(g=a[e])&&(!k||0<=k.indexOf(","+e+","))&&(!b||0<=b.indexOf(","+e+","))&&c(e,g)};a.o=function(c,
  b,d,f,e){var g="",k,l,h,n,m=0;"contextData"==c&&(c="c");if(b){for(k in b)if(!(Object.prototype[k]||e&&k.substring(0,e.length)!=e)&&b[k]&&(!d||0<=d.indexOf(","+(f?f+".":"")+k+","))){h=!1;if(m)for(l=0;l<m.length;l++)if(k.substring(0,m[l].length)==m[l]){h=!0;break}if(!h&&(""==g&&(g+="&"+c+"."),l=b[k],e&&(k=k.substring(e.length)),0<k.length))if(h=k.indexOf("."),0<h)l=k.substring(0,h),h=(e?e:"")+l+".",m||(m=[]),m.push(h),g+=a.o(l,b,d,f,h);else if("boolean"==typeof l&&(l=l?"true":"false"),l){if("retrieveLightData"==
  f&&0>e.indexOf(".contextData."))switch(h=k.substring(0,4),n=k.substring(4),k){case "transactionID":k="xact";break;case "channel":k="ch";break;case "campaign":k="v0";break;default:a.Pa(n)&&("prop"==h?k="c"+n:"eVar"==h?k="v"+n:"list"==h?k="l"+n:"hier"==h&&(k="h"+n,l=l.substring(0,255)))}g+="&"+a.escape(k)+"="+a.escape(l)}}""!=g&&(g+="&."+c)}return g};a.usePostbacks=0;a.Nb=function(){var c="",b,d,f,e,g,k,l,h,n="",m="",p=e="",r=a.T();if(a.lightProfileID)b=a.O,(n=a.lightTrackVars)&&(n=","+n+","+a.ka.join(",")+
  ",");else{b=a.g;if(a.pe||a.linkType)n=a.linkTrackVars,m=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(n=a[e].ac,m=a[e].$b));n&&(n=","+n+","+a.F.join(",")+",");m&&(m=","+m+",",n&&(n+=",events,"));a.events2&&(p+=(""!=p?",":"")+a.events2)}if(r&&r.getCustomerIDs){e=q;if(g=r.getCustomerIDs())for(d in g)Object.prototype[d]||(f=g[d],"object"==typeof f&&(e||(e={}),f.id&&(e[d+".id"]=f.id),f.authState&&(e[d+".as"]=f.authState)));e&&(c+=a.o("cid",e))}a.AudienceManagement&&
  a.AudienceManagement.isReady()&&(c+=a.o("d",a.AudienceManagement.getEventCallConfigParams()));for(d=0;d<b.length;d++){e=b[d];g=a[e];f=e.substring(0,4);k=e.substring(4);g||("events"==e&&p?(g=p,p=""):"marketingCloudOrgID"==e&&r&&a.V("ECID")&&(g=r.marketingCloudOrgID));if(g&&(!n||0<=n.indexOf(","+e+","))){switch(e){case "customerPerspective":e="cp";break;case "marketingCloudOrgID":e="mcorgid";break;case "supplementalDataID":e="sdid";break;case "timestamp":e="ts";break;case "dynamicVariablePrefix":e=
  "D";break;case "visitorID":e="vid";break;case "marketingCloudVisitorID":e="mid";break;case "analyticsVisitorID":e="aid";break;case "audienceManagerLocationHint":e="aamlh";break;case "audienceManagerBlob":e="aamb";break;case "authState":e="as";break;case "pageURL":e="g";255<g.length&&(a.pageURLRest=g.substring(255),g=g.substring(0,255));break;case "pageURLRest":e="-g";break;case "referrer":e="r";break;case "vmk":case "visitorMigrationKey":e="vmt";break;case "visitorMigrationServer":e="vmf";a.ssl&&
  a.visitorMigrationServerSecure&&(g="");break;case "visitorMigrationServerSecure":e="vmf";!a.ssl&&a.visitorMigrationServer&&(g="");break;case "charSet":e="ce";break;case "visitorNamespace":e="ns";break;case "cookieDomainPeriods":e="cdp";break;case "cookieLifetime":e="cl";break;case "variableProvider":e="vvp";break;case "currencyCode":e="cc";break;case "channel":e="ch";break;case "transactionID":e="xact";break;case "campaign":e="v0";break;case "latitude":e="lat";break;case "longitude":e="lon";break;
  case "resolution":e="s";break;case "colorDepth":e="c";break;case "javascriptVersion":e="j";break;case "javaEnabled":e="v";break;case "cookiesEnabled":e="k";break;case "browserWidth":e="bw";break;case "browserHeight":e="bh";break;case "connectionType":e="ct";break;case "homepage":e="hp";break;case "events":p&&(g+=(""!=g?",":"")+p);if(m)for(k=g.split(","),g="",f=0;f<k.length;f++)l=k[f],h=l.indexOf("="),0<=h&&(l=l.substring(0,h)),h=l.indexOf(":"),0<=h&&(l=l.substring(0,h)),0<=m.indexOf(","+l+",")&&(g+=
  (g?",":"")+k[f]);break;case "events2":g="";break;case "contextData":c+=a.o("c",a[e],n,e);g="";break;case "lightProfileID":e="mtp";break;case "lightStoreForSeconds":e="mtss";a.lightProfileID||(g="");break;case "lightIncrementBy":e="mti";a.lightProfileID||(g="");break;case "retrieveLightProfiles":e="mtsr";break;case "deleteLightProfiles":e="mtsd";break;case "retrieveLightData":a.retrieveLightProfiles&&(c+=a.o("mts",a[e],n,e));g="";break;default:a.Pa(k)&&("prop"==f?e="c"+k:"eVar"==f?e="v"+k:"list"==
  f?e="l"+k:"hier"==f&&(e="h"+k,g=g.substring(0,255)))}g&&(c+="&"+e+"="+("pev"!=e.substring(0,3)?a.escape(g):g))}"pev3"==e&&a.e&&(c+=a.e)}a.ja&&(c+="&lrt="+a.ja,a.ja=null);return c};a.B=function(a){var b=a.tagName;if("undefined"!=""+a.hc||"undefined"!=""+a.Wb&&"HTML"!=(""+a.Wb).toUpperCase())return"";b=b&&b.toUpperCase?b.toUpperCase():"";"SHAPE"==b&&(b="");b&&(("INPUT"==b||"BUTTON"==b)&&a.type&&a.type.toUpperCase?b=a.type.toUpperCase():!b&&a.href&&(b="A"));return b};a.La=function(a){var b=h.location,
  d=a.href?a.href:"",f,e,g;f=d.indexOf(":");e=d.indexOf("?");g=d.indexOf("/");d&&(0>f||0<=e&&f>e||0<=g&&f>g)&&(e=a.protocol&&1<a.protocol.length?a.protocol:b.protocol?b.protocol:"",f=b.pathname.lastIndexOf("/"),d=(e?e+"//":"")+(a.host?a.host:b.host?b.host:"")+("/"!=d.substring(0,1)?b.pathname.substring(0,0>f?0:f)+"/":"")+d);return d};a.L=function(c){var b=a.B(c),d,f,e="",g=0;return b&&(d=c.protocol,f=c.onclick,!c.href||"A"!=b&&"AREA"!=b||f&&d&&!(0>d.toLowerCase().indexOf("javascript"))?f?(e=a.replace(a.replace(a.replace(a.replace(""+
  f,"\r",""),"\n",""),"\t","")," ",""),g=2):"INPUT"==b||"SUBMIT"==b?(c.value?e=c.value:c.innerText?e=c.innerText:c.textContent&&(e=c.textContent),g=3):"IMAGE"==b&&c.src&&(e=c.src):e=a.La(c),e)?{id:e.substring(0,100),type:g}:0};a.fc=function(c){for(var b=a.B(c),d=a.L(c);c&&!d&&"BODY"!=b;)if(c=c.parentElement?c.parentElement:c.parentNode)b=a.B(c),d=a.L(c);d&&"BODY"!=b||(c=0);c&&(b=c.onclick?""+c.onclick:"",0<=b.indexOf(".tl(")||0<=b.indexOf(".trackLink("))&&(c=0);return c};a.Vb=function(){var c,b,d=a.linkObject,
  f=a.linkType,e=a.linkURL,g,k;a.la=1;d||(a.la=0,d=a.clickObject);if(d){c=a.B(d);for(b=a.L(d);d&&!b&&"BODY"!=c;)if(d=d.parentElement?d.parentElement:d.parentNode)c=a.B(d),b=a.L(d);b&&"BODY"!=c||(d=0);if(d&&!a.linkObject){var l=d.onclick?""+d.onclick:"";if(0<=l.indexOf(".tl(")||0<=l.indexOf(".trackLink("))d=0}}else a.la=1;!e&&d&&(e=a.La(d));e&&!a.linkLeaveQueryString&&(g=e.indexOf("?"),0<=g&&(e=e.substring(0,g)));if(!f&&e){var m=0,n=0,p;if(a.trackDownloadLinks&&a.linkDownloadFileTypes)for(l=e.toLowerCase(),
  g=l.indexOf("?"),k=l.indexOf("#"),0<=g?0<=k&&k<g&&(g=k):g=k,0<=g&&(l=l.substring(0,g)),g=a.linkDownloadFileTypes.toLowerCase().split(","),k=0;k<g.length;k++)(p=g[k])&&l.substring(l.length-(p.length+1))=="."+p&&(f="d");if(a.trackExternalLinks&&!f&&(l=e.toLowerCase(),a.Oa(l)&&(a.linkInternalFilters||(a.linkInternalFilters=h.location.hostname),g=0,a.linkExternalFilters?(g=a.linkExternalFilters.toLowerCase().split(","),m=1):a.linkInternalFilters&&(g=a.linkInternalFilters.toLowerCase().split(",")),g))){for(k=
  0;k<g.length;k++)p=g[k],0<=l.indexOf(p)&&(n=1);n?m&&(f="e"):m||(f="e")}}a.linkObject=d;a.linkURL=e;a.linkType=f;if(a.trackClickMap||a.trackInlineStats)a.e="",d&&(f=a.pageName,e=1,d=d.sourceIndex,f||(f=a.pageURL,e=0),h.s_objectID&&(b.id=h.s_objectID,d=b.type=1),f&&b&&b.id&&c&&(a.e="&pid="+a.escape(f.substring(0,255))+(e?"&pidt="+e:"")+"&oid="+a.escape(b.id.substring(0,100))+(b.type?"&oidt="+b.type:"")+"&ot="+c+(d?"&oi="+d:"")))};a.Ob=function(){var c=a.la,b=a.linkType,d=a.linkURL,f=a.linkName;b&&(d||
  f)&&(b=b.toLowerCase(),"d"!=b&&"e"!=b&&(b="o"),a.pe="lnk_"+b,a.pev1=d?a.escape(d):"",a.pev2=f?a.escape(f):"",c=1);a.abort&&(c=0);if(a.trackClickMap||a.trackInlineStats||a.Rb()){var b={},d=0,e=a.pb(),g=e?e.split("&"):0,k,l,h,e=0;if(g)for(k=0;k<g.length;k++)l=g[k].split("="),f=a.unescape(l[0]).split(","),l=a.unescape(l[1]),b[l]=f;f=a.account.split(",");k={};for(h in a.contextData)h&&!Object.prototype[h]&&"a.activitymap."==h.substring(0,14)&&(k[h]=a.contextData[h],a.contextData[h]="");a.e=a.o("c",k)+
  (a.e?a.e:"");if(c||a.e){c&&!a.e&&(e=1);for(l in b)if(!Object.prototype[l])for(h=0;h<f.length;h++)for(e&&(g=b[l].join(","),g==a.account&&(a.e+=("&"!=l.charAt(0)?"&":"")+l,b[l]=[],d=1)),k=0;k<b[l].length;k++)g=b[l][k],g==f[h]&&(e&&(a.e+="&u="+a.escape(g)+("&"!=l.charAt(0)?"&":"")+l+"&u=0"),b[l].splice(k,1),d=1);c||(d=1);if(d){e="";k=2;!c&&a.e&&(e=a.escape(f.join(","))+"="+a.escape(a.e),k=1);for(l in b)!Object.prototype[l]&&0<k&&0<b[l].length&&(e+=(e?"&":"")+a.escape(b[l].join(","))+"="+a.escape(l),
  k--);a.wb(e)}}}return c};a.pb=function(){if(a.useLinkTrackSessionStorage){if(a.Ca())return h.sessionStorage.getItem(a.P)}else return a.cookieRead(a.P)};a.Ca=function(){return h.sessionStorage?!0:!1};a.wb=function(c){a.useLinkTrackSessionStorage?a.Ca()&&h.sessionStorage.setItem(a.P,c):a.cookieWrite(a.P,c)};a.Pb=function(){if(!a.Zb){var c=new Date,b=p.location,d,f,e=f=d="",g="",k="",l="1.2",h=a.cookieWrite("s_cc","true",0)?"Y":"N",m="",q="";if(c.setUTCDate&&(l="1.3",(0).toPrecision&&(l="1.5",c=[],c.forEach))){l=
  "1.6";f=0;d={};try{f=new Iterator(d),f.next&&(l="1.7",c.reduce&&(l="1.8",l.trim&&(l="1.8.1",Date.parse&&(l="1.8.2",Object.create&&(l="1.8.5")))))}catch(r){}}d=screen.width+"x"+screen.height;e=navigator.javaEnabled()?"Y":"N";f=screen.pixelDepth?screen.pixelDepth:screen.colorDepth;g=a.w.innerWidth?a.w.innerWidth:a.d.documentElement.offsetWidth;k=a.w.innerHeight?a.w.innerHeight:a.d.documentElement.offsetHeight;try{a.b.addBehavior("#default#homePage"),m=a.b.gc(b)?"Y":"N"}catch(s){}try{a.b.addBehavior("#default#clientCaps"),
  q=a.b.connectionType}catch(t){}a.resolution=d;a.colorDepth=f;a.javascriptVersion=l;a.javaEnabled=e;a.cookiesEnabled=h;a.browserWidth=g;a.browserHeight=k;a.connectionType=q;a.homepage=m;a.Zb=1}};a.Q={};a.loadModule=function(c,b){var d=a.Q[c];if(!d){d=h["AppMeasurement_Module_"+c]?new h["AppMeasurement_Module_"+c](a):{};a.Q[c]=a[c]=d;d.ib=function(){return d.sb};d.xb=function(b){if(d.sb=b)a[c+"_onLoad"]=b,a.ea(c+"_onLoad",[a,d],1)||b(a,d)};try{Object.defineProperty?Object.defineProperty(d,"onLoad",
  {get:d.ib,set:d.xb}):d._olc=1}catch(f){d._olc=1}}b&&(a[c+"_onLoad"]=b,a.ea(c+"_onLoad",[a,d],1)||b(a,d))};a.u=function(c){var b,d;for(b in a.Q)if(!Object.prototype[b]&&(d=a.Q[b])&&(d._olc&&d.onLoad&&(d._olc=0,d.onLoad(a,d)),d[c]&&d[c]()))return 1;return 0};a.Rb=function(){return a.ActivityMap&&a.ActivityMap._c?!0:!1};a.Sb=function(){var c=Math.floor(1E13*Math.random()),b=a.visitorSampling,d=a.visitorSamplingGroup,d="s_vsn_"+(a.visitorNamespace?a.visitorNamespace:a.account)+(d?"_"+d:""),f=a.cookieRead(d);
  if(b){b*=100;f&&(f=parseInt(f));if(!f){if(!a.cookieWrite(d,c))return 0;f=c}if(f%1E4>b)return 0}return 1};a.S=function(c,b){var d,f,e,g,k,h,m;m={};for(d=0;2>d;d++)for(f=0<d?a.Ea:a.g,e=0;e<f.length;e++)if(g=f[e],(k=c[g])||c["!"+g]){if(k&&!b&&("contextData"==g||"retrieveLightData"==g)&&a[g])for(h in a[g])k[h]||(k[h]=a[g][h]);a[g]||(m["!"+g]=1);m[g]=a[g];a[g]=k}return m};a.cc=function(c){var b,d,f,e;for(b=0;2>b;b++)for(d=0<b?a.Ea:a.g,f=0;f<d.length;f++)e=d[f],c[e]=a[e],c[e]||"prop"!==e.substring(0,4)&&
  "eVar"!==e.substring(0,4)&&"hier"!==e.substring(0,4)&&"list"!==e.substring(0,4)&&"channel"!==e&&"events"!==e&&"eventList"!==e&&"products"!==e&&"productList"!==e&&"purchaseID"!==e&&"transactionID"!==e&&"state"!==e&&"zip"!==e&&"campaign"!==e&&"events2"!==e&&"latitude"!==e&&"longitude"!==e&&"ms_a"!==e&&"contextData"!==e&&"supplementalDataID"!==e&&"tnt"!==e&&"timestamp"!==e&&"abort"!==e&&"useBeacon"!==e&&"linkObject"!==e&&"clickObject"!==e&&"linkType"!==e&&"linkName"!==e&&"linkURL"!==e&&"bodyClickTarget"!==
  e&&"bodyClickFunction"!==e||(c["!"+e]=1)};a.Jb=function(a){var b,d,f,e,g,k=0,h,m="",n="";if(a&&255<a.length&&(b=""+a,d=b.indexOf("?"),0<d&&(h=b.substring(d+1),b=b.substring(0,d),e=b.toLowerCase(),f=0,"http://"==e.substring(0,7)?f+=7:"https://"==e.substring(0,8)&&(f+=8),d=e.indexOf("/",f),0<d&&(e=e.substring(f,d),g=b.substring(d),b=b.substring(0,d),0<=e.indexOf("google")?k=",q,ie,start,search_key,word,kw,cd,":0<=e.indexOf("yahoo.co")?k=",p,ei,":0<=e.indexOf("baidu.")&&(k=",wd,word,"),k&&h)))){if((a=
  h.split("&"))&&1<a.length){for(f=0;f<a.length;f++)e=a[f],d=e.indexOf("="),0<d&&0<=k.indexOf(","+e.substring(0,d)+",")?m+=(m?"&":"")+e:n+=(n?"&":"")+e;m&&n?h=m+"&"+n:n=""}d=253-(h.length-n.length)-b.length;a=b+(0<d?g.substring(0,d):"")+"?"+h}return a};a.bb=function(c){var b=a.d.visibilityState,d=["webkitvisibilitychange","visibilitychange"];b||(b=a.d.webkitVisibilityState);if(b&&"prerender"==b){if(c)for(b=0;b<d.length;b++)a.d.addEventListener(d[b],function(){var b=a.d.visibilityState;b||(b=a.d.webkitVisibilityState);
  "visible"==b&&c()});return!1}return!0};a.ba=!1;a.H=!1;a.zb=function(){a.H=!0;a.p()};a.I=!1;a.Ab=function(c){a.marketingCloudVisitorID=c.MCMID;a.visitorOptedOut=c.MCOPTOUT;a.analyticsVisitorID=c.MCAID;a.audienceManagerLocationHint=c.MCAAMLH;a.audienceManagerBlob=c.MCAAMB;a.I=!1;a.p()};a.ab=function(c){a.maxDelay||(a.maxDelay=250);return a.u("_d")?(c&&setTimeout(function(){c()},a.maxDelay),!1):!0};a.Z=!1;a.G=!1;a.ya=function(){a.G=!0;a.p()};a.isReadyToTrack=function(){var c=!0;if(!a.mb()||!a.kb())return!1;
  a.ob()||(c=!1);a.rb()||(c=!1);return c};a.mb=function(){a.ba||a.H||(a.bb(a.zb)?a.H=!0:a.ba=!0);return a.ba&&!a.H?!1:!0};a.kb=function(){var c=a.va();if(c)if(a.ra||a.aa)if(a.ra){if(!c.isApproved(c.Categories.ANALYTICS))return!1}else return!1;else return c.fetchPermissions(a.tb,!0),a.aa=!0,!1;return!0};a.V=function(c){var b=a.va();return b&&!b.isApproved(b.Categories[c])?!1:!0};a.va=function(){return h.adobe&&h.adobe.optIn?h.adobe.optIn:null};a.Y=!0;a.ob=function(){var c=a.T();if(!c||!c.getVisitorValues)return!0;
  a.Y&&(a.Y=!1,a.I||(a.I=!0,c.getVisitorValues(a.Ab)));return!a.I};a.T=function(){var c=a.visitor;c&&!c.isAllowed()&&(c=null);return c};a.rb=function(){a.Z||a.G||(a.ab(a.ya)?a.G=!0:a.Z=!0);return a.Z&&!a.G?!1:!0};a.aa=!1;a.tb=function(){a.aa=!1;a.ra=!0};a.j=q;a.q=0;a.callbackWhenReadyToTrack=function(c,b,d){var f;f={};f.Eb=c;f.Db=b;f.Bb=d;a.j==q&&(a.j=[]);a.j.push(f);0==a.q&&(a.q=setInterval(a.p,100))};a.p=function(){var c;if(a.isReadyToTrack()&&(a.yb(),a.j!=q))for(;0<a.j.length;)c=a.j.shift(),c.Db.apply(c.Eb,
  c.Bb)};a.yb=function(){a.q&&(clearInterval(a.q),a.q=0)};a.ta=function(c){var b,d={};a.cc(d);if(c!=q)for(b in c)d[b]=c[b];a.callbackWhenReadyToTrack(a,a.Da,[d]);a.Ba()};a.Lb=function(){var c=a.cookieRead("s_fid"),b="",d="",f;f=8;var e=4;if(!c||0>c.indexOf("-")){for(c=0;16>c;c++)f=Math.floor(Math.random()*f),b+="0123456789ABCDEF".substring(f,f+1),f=Math.floor(Math.random()*e),d+="0123456789ABCDEF".substring(f,f+1),f=e=16;c=b+"-"+d}a.cookieWrite("s_fid",c,1)||(c=0);return c};a.Da=function(c){var b=new Date,
  d="s"+Math.floor(b.getTime()/108E5)%10+Math.floor(1E13*Math.random()),f=b.getYear(),f="t="+a.escape(b.getDate()+"/"+b.getMonth()+"/"+(1900>f?f+1900:f)+" "+b.getHours()+":"+b.getMinutes()+":"+b.getSeconds()+" "+b.getDay()+" "+b.getTimezoneOffset()),e=a.T(),g;c&&(g=a.S(c,1));a.Sb()&&!a.visitorOptedOut&&(a.wa()||(a.fid=a.Lb()),a.Vb(),a.usePlugins&&a.doPlugins&&a.doPlugins(a),a.account&&(a.abort||(a.trackOffline&&!a.timestamp&&(a.timestamp=Math.floor(b.getTime()/1E3)),c=h.location,a.pageURL||(a.pageURL=
  c.href?c.href:c),a.referrer||a.Za||(c=a.Util.getQueryParam("adobe_mc_ref",null,null,!0),a.referrer=c||void 0===c?void 0===c?"":c:p.document.referrer),a.Za=1,a.referrer=a.Jb(a.referrer),a.u("_g")),a.Ob()&&!a.abort&&(e&&a.V("TARGET")&&!a.supplementalDataID&&e.getSupplementalDataID&&(a.supplementalDataID=e.getSupplementalDataID("AppMeasurement:"+a._in,a.expectSupplementalData?!1:!0)),a.V("AAM")||(a.contextData["cm.ssf"]=1),a.Pb(),f+=a.Nb(),a.qb(d,f),a.u("_t"),a.referrer="")));a.Ba();g&&a.S(g,1)};a.t=
  a.track=function(c,b){b&&a.S(b);a.Y=!0;a.isReadyToTrack()?null!=a.j&&0<a.j.length?(a.ta(c),a.p()):a.Da(c):a.ta(c)};a.Ba=function(){a.abort=a.supplementalDataID=a.timestamp=a.pageURLRest=a.linkObject=a.clickObject=a.linkURL=a.linkName=a.linkType=h.s_objectID=a.pe=a.pev1=a.pev2=a.pev3=a.e=a.lightProfileID=a.useBeacon=a.referrer=0};a.Aa=[];a.registerPreTrackCallback=function(c){for(var b=[],d=1;d<arguments.length;d++)b.push(arguments[d]);"function"==typeof c?a.Aa.push([c,b]):a.debugTracking&&a.C("DEBUG: Non function type passed to registerPreTrackCallback")};
  a.fb=function(c){a.ua(a.Aa,c)};a.za=[];a.registerPostTrackCallback=function(c){for(var b=[],d=1;d<arguments.length;d++)b.push(arguments[d]);"function"==typeof c?a.za.push([c,b]):a.debugTracking&&a.C("DEBUG: Non function type passed to registerPostTrackCallback")};a.eb=function(c){a.ua(a.za,c)};a.ua=function(c,b){if("object"==typeof c)for(var d=0;d<c.length;d++){var f=c[d][0],e=c[d][1].slice();e.unshift(b);if("function"==typeof f)try{f.apply(null,e)}catch(g){a.debugTracking&&a.C(g.message)}}};a.tl=
  a.trackLink=function(c,b,d,f,e){a.linkObject=c;a.linkType=b;a.linkName=d;e&&(a.bodyClickTarget=c,a.bodyClickFunction=e);return a.track(f)};a.trackLight=function(c,b,d,f){a.lightProfileID=c;a.lightStoreForSeconds=b;a.lightIncrementBy=d;return a.track(f)};a.clearVars=function(){var c,b;for(c=0;c<a.g.length;c++)if(b=a.g[c],"prop"==b.substring(0,4)||"eVar"==b.substring(0,4)||"hier"==b.substring(0,4)||"list"==b.substring(0,4)||"channel"==b||"events"==b||"eventList"==b||"products"==b||"productList"==b||
  "purchaseID"==b||"transactionID"==b||"state"==b||"zip"==b||"campaign"==b)a[b]=void 0};a.tagContainerMarker="";a.qb=function(c,b){var d=a.gb()+"/"+c+"?AQB=1&ndh=1&pf=1&"+(a.xa()?"callback=s_c_il["+a._in+"].doPostbacks&et=1&":"")+b+"&AQE=1";a.fb(d);a.cb(d);a.U()};a.gb=function(){var c=a.hb();return"http"+(a.ssl?"s":"")+"://"+c+"/b/ss/"+a.account+"/"+(a.mobile?"5.":"")+(a.xa()?"10":"1")+"/JS-"+a.version+(a.Yb?"T":"")+(a.tagContainerMarker?"-"+a.tagContainerMarker:"")};a.xa=function(){return a.AudienceManagement&&
  a.AudienceManagement.isReady()||0!=a.usePostbacks};a.hb=function(){var c=a.dc,b=a.trackingServer;b?a.trackingServerSecure&&a.ssl&&(b=a.trackingServerSecure):(c=c?(""+c).toLowerCase():"d1","d1"==c?c="112":"d2"==c&&(c="122"),b=a.jb()+"."+c+".2o7.net");return b};a.jb=function(){var c=a.visitorNamespace;c||(c=a.account.split(",")[0],c=c.replace(/[^0-9a-z]/gi,""));return c};a.Ya=/{(%?)(.*?)(%?)}/;a.bc=RegExp(a.Ya.source,"g");a.Ib=function(c){if("object"==typeof c.dests)for(var b=0;b<c.dests.length;++b){var d=
  c.dests[b];if("string"==typeof d.c&&"aa."==d.id.substr(0,3))for(var f=d.c.match(a.bc),e=0;e<f.length;++e){var g=f[e],k=g.match(a.Ya),h="";"%"==k[1]&&"timezone_offset"==k[2]?h=(new Date).getTimezoneOffset():"%"==k[1]&&"timestampz"==k[2]&&(h=a.Mb());d.c=d.c.replace(g,a.escape(h))}}};a.Mb=function(){var c=new Date,b=new Date(6E4*Math.abs(c.getTimezoneOffset()));return a.k(4,c.getFullYear())+"-"+a.k(2,c.getMonth()+1)+"-"+a.k(2,c.getDate())+"T"+a.k(2,c.getHours())+":"+a.k(2,c.getMinutes())+":"+a.k(2,c.getSeconds())+
  (0<c.getTimezoneOffset()?"-":"+")+a.k(2,b.getUTCHours())+":"+a.k(2,b.getUTCMinutes())};a.k=function(a,b){return(Array(a+1).join(0)+b).slice(-a)};a.pa={};a.doPostbacks=function(c){if("object"==typeof c)if(a.Ib(c),"object"==typeof a.AudienceManagement&&"function"==typeof a.AudienceManagement.isReady&&a.AudienceManagement.isReady()&&"function"==typeof a.AudienceManagement.passData)a.AudienceManagement.passData(c);else if("object"==typeof c&&"object"==typeof c.dests)for(var b=0;b<c.dests.length;++b){var d=
  c.dests[b];"object"==typeof d&&"string"==typeof d.c&&"string"==typeof d.id&&"aa."==d.id.substr(0,3)&&(a.pa[d.id]=new Image,a.pa[d.id].alt="",a.pa[d.id].src=d.c)}};a.cb=function(c){a.i||a.Qb();a.i.push(c);a.ia=a.A();a.Wa()};a.Qb=function(){a.i=a.Tb();a.i||(a.i=[])};a.Tb=function(){var c,b;if(a.oa()){try{(b=h.localStorage.getItem(a.ma()))&&(c=h.JSON.parse(b))}catch(d){}return c}};a.oa=function(){var c=!0;a.trackOffline&&a.offlineFilename&&h.localStorage&&h.JSON||(c=!1);return c};a.Ma=function(){var c=
  0;a.i&&(c=a.i.length);a.l&&c++;return c};a.U=function(){if(a.l&&(a.v&&a.v.complete&&a.v.D&&a.v.R(),a.l))return;a.Na=q;if(a.na)a.ia>a.N&&a.Ua(a.i),a.qa(500);else{var c=a.Cb();if(0<c)a.qa(c);else if(c=a.Ka())a.l=1,a.Ub(c),a.Xb(c)}};a.qa=function(c){a.Na||(c||(c=0),a.Na=setTimeout(a.U,c))};a.Cb=function(){var c;if(!a.trackOffline||0>=a.offlineThrottleDelay)return 0;c=a.A()-a.Sa;return a.offlineThrottleDelay<c?0:a.offlineThrottleDelay-c};a.Ka=function(){if(0<a.i.length)return a.i.shift()};a.Ub=function(c){if(a.debugTracking){var b=
  "AppMeasurement Debug: "+c;c=c.split("&");var d;for(d=0;d<c.length;d++)b+="\n\t"+a.unescape(c[d]);a.C(b)}};a.wa=function(){return a.marketingCloudVisitorID||a.analyticsVisitorID};a.X=!1;var t;try{t=JSON.parse('{"x":"y"}')}catch(w){t=null}t&&"y"==t.x?(a.X=!0,a.W=function(a){return JSON.parse(a)}):h.$&&h.$.parseJSON?(a.W=function(a){return h.$.parseJSON(a)},a.X=!0):a.W=function(){return null};a.Xb=function(c){var b,d,f;a.lb(c)&&(d=1,b={send:function(c){a.useBeacon=!1;navigator.sendBeacon(c)?b.R():b.ga()}});
  !b&&a.wa()&&2047<c.length&&(a.$a()&&(d=2,b=new XMLHttpRequest),b&&(a.AudienceManagement&&a.AudienceManagement.isReady()||0!=a.usePostbacks)&&(a.X?b.Fa=!0:b=0));!b&&a.Xa&&(c=c.substring(0,2047));!b&&a.d.createElement&&(0!=a.usePostbacks||a.AudienceManagement&&a.AudienceManagement.isReady())&&(b=a.d.createElement("SCRIPT"))&&"async"in b&&((f=(f=a.d.getElementsByTagName("HEAD"))&&f[0]?f[0]:a.d.body)?(b.type="text/javascript",b.setAttribute("async","async"),d=3):b=0);b||(b=new Image,b.alt="",b.abort||
  "undefined"===typeof h.InstallTrigger||(b.abort=function(){b.src=q}));b.Ta=Date.now();b.Ha=function(){try{b.D&&(clearTimeout(b.D),b.D=0)}catch(a){}};b.onload=b.R=function(){b.Ta&&(a.ja=Date.now()-b.Ta);a.eb(c);b.Ha();a.Gb();a.ca();a.l=0;a.U();if(b.Fa){b.Fa=!1;try{a.doPostbacks(a.W(b.responseText))}catch(d){}}};b.onabort=b.onerror=b.ga=function(){b.Ha();(a.trackOffline||a.na)&&a.l&&a.i.unshift(a.Fb);a.l=0;a.ia>a.N&&a.Ua(a.i);a.ca();a.qa(500)};b.onreadystatechange=function(){4==b.readyState&&(200==
  b.status?b.R():b.ga())};a.Sa=a.A();if(1===d)b.send(c);else if(2===d)f=c.indexOf("?"),d=c.substring(0,f),f=c.substring(f+1),f=f.replace(/&callback=[a-zA-Z0-9_.\[\]]+/,""),b.open("POST",d,!0),b.withCredentials=!0,b.send(f);else if(b.src=c,3===d){if(a.Qa)try{f.removeChild(a.Qa)}catch(e){}f.firstChild?f.insertBefore(b,f.firstChild):f.appendChild(b);a.Qa=a.v}b.D=setTimeout(function(){b.D&&(b.complete?b.R():(a.trackOffline&&b.abort&&b.abort(),b.ga()))},5E3);a.Fb=c;a.v=h["s_i_"+a.replace(a.account,",","_")]=
  b;if(a.useForcedLinkTracking&&a.J||a.bodyClickFunction)a.forcedLinkTrackingTimeout||(a.forcedLinkTrackingTimeout=250),a.da=setTimeout(a.ca,a.forcedLinkTrackingTimeout)};a.lb=function(c){var b=!1;navigator.sendBeacon&&(a.nb(c)?b=!0:a.useBeacon&&(b=!0));a.vb(c)&&(b=!1);return b};a.nb=function(a){return a&&0<a.indexOf("pe=lnk_e")?!0:!1};a.vb=function(a){return 64E3<=a.length};a.$a=function(){return"undefined"!==typeof XMLHttpRequest&&"withCredentials"in new XMLHttpRequest?!0:!1};a.Gb=function(){if(a.oa()&&
  !(a.Ra>a.N))try{h.localStorage.removeItem(a.ma()),a.Ra=a.A()}catch(c){}};a.Ua=function(c){if(a.oa()){a.Wa();try{h.localStorage.setItem(a.ma(),h.JSON.stringify(c)),a.N=a.A()}catch(b){}}};a.Wa=function(){if(a.trackOffline){if(!a.offlineLimit||0>=a.offlineLimit)a.offlineLimit=10;for(;a.i.length>a.offlineLimit;)a.Ka()}};a.forceOffline=function(){a.na=!0};a.forceOnline=function(){a.na=!1};a.ma=function(){return a.offlineFilename+"-"+a.visitorNamespace+a.account};a.A=function(){return(new Date).getTime()};
  a.Oa=function(a){a=a.toLowerCase();return 0!=a.indexOf("#")&&0!=a.indexOf("about:")&&0!=a.indexOf("opera:")&&0!=a.indexOf("javascript:")?!0:!1};a.setTagContainer=function(c){var b,d,f;a.Yb=c;for(b=0;b<a._il.length;b++)if((d=a._il[b])&&"s_l"==d._c&&d.tagContainerName==c){a.S(d);if(d.lmq)for(b=0;b<d.lmq.length;b++)f=d.lmq[b],a.loadModule(f.n);if(d.ml)for(f in d.ml)if(a[f])for(b in c=a[f],f=d.ml[f],f)!Object.prototype[b]&&("function"!=typeof f[b]||0>(""+f[b]).indexOf("s_c_il"))&&(c[b]=f[b]);if(d.mmq)for(b=
  0;b<d.mmq.length;b++)f=d.mmq[b],a[f.m]&&(c=a[f.m],c[f.f]&&"function"==typeof c[f.f]&&(f.a?c[f.f].apply(c,f.a):c[f.f].apply(c)));if(d.tq)for(b=0;b<d.tq.length;b++)a.track(d.tq[b]);d.s=a;break}};a.Util={urlEncode:a.escape,urlDecode:a.unescape,cookieRead:a.cookieRead,cookieWrite:a.cookieWrite,getQueryParam:function(c,b,d,f){var e,g="";b||(b=a.pageURL?a.pageURL:h.location);d=d?d:"&";if(!c||!b)return g;b=""+b;e=b.indexOf("?");if(0>e)return g;b=d+b.substring(e+1)+d;if(!f||!(0<=b.indexOf(d+c+d)||0<=b.indexOf(d+
  c+"="+d))){e=b.indexOf("#");0<=e&&(b=b.substr(0,e)+d);e=b.indexOf(d+c+"=");if(0>e)return g;b=b.substring(e+d.length+c.length+1);e=b.indexOf(d);0<=e&&(b=b.substring(0,e));0<b.length&&(g=a.unescape(b));return g}},getIeVersion:function(){if(document.documentMode)return document.documentMode;for(var a=7;4<a;a--){var b=document.createElement("div");b.innerHTML="\x3c!--[if IE "+a+"]><span></span><![endif]--\x3e";if(b.getElementsByTagName("span").length)return a}return null}};a.F="supplementalDataID timestamp dynamicVariablePrefix visitorID marketingCloudVisitorID analyticsVisitorID audienceManagerLocationHint authState fid vmk visitorMigrationKey visitorMigrationServer visitorMigrationServerSecure charSet visitorNamespace cookieDomainPeriods fpCookieDomainPeriods cookieLifetime pageName pageURL customerPerspective referrer contextData currencyCode lightProfileID lightStoreForSeconds lightIncrementBy retrieveLightProfiles deleteLightProfiles retrieveLightData".split(" ");
  a.g=a.F.concat("purchaseID variableProvider channel server pageType transactionID campaign state zip events events2 products audienceManagerBlob tnt".split(" "));a.ka="timestamp charSet visitorNamespace cookieDomainPeriods cookieLifetime contextData lightProfileID lightStoreForSeconds lightIncrementBy".split(" ");a.O=a.ka.slice(0);a.Ea="account allAccounts debugTracking visitor visitorOptedOut trackOffline offlineLimit offlineThrottleDelay offlineFilename usePlugins doPlugins configURL visitorSampling visitorSamplingGroup linkObject clickObject linkURL linkName linkType trackDownloadLinks trackExternalLinks trackClickMap trackInlineStats linkLeaveQueryString linkTrackVars linkTrackEvents linkDownloadFileTypes linkExternalFilters linkInternalFilters useForcedLinkTracking forcedLinkTrackingTimeout useLinkTrackSessionStorage trackingServer trackingServerSecure ssl abort mobile dc lightTrackVars maxDelay expectSupplementalData useBeacon usePostbacks registerPreTrackCallback registerPostTrackCallback bodyClickTarget bodyClickFunction AudienceManagement".split(" ");
  for(m=0;250>=m;m++)76>m&&(a.g.push("prop"+m),a.O.push("prop"+m)),a.g.push("eVar"+m),a.O.push("eVar"+m),6>m&&a.g.push("hier"+m),4>m&&a.g.push("list"+m);m="pe pev1 pev2 pev3 latitude longitude resolution colorDepth javascriptVersion javaEnabled cookiesEnabled browserWidth browserHeight connectionType homepage pageURLRest marketingCloudOrgID ms_a".split(" ");a.g=a.g.concat(m);a.F=a.F.concat(m);a.ssl=0<=h.location.protocol.toLowerCase().indexOf("https");a.charSet="UTF-8";a.contextData={};a.offlineThrottleDelay=
  0;a.offlineFilename="AppMeasurement.offline";a.P="s_sq";a.Sa=0;a.ia=0;a.N=0;a.Ra=0;a.linkDownloadFileTypes="exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx";a.w=h;a.d=h.document;try{if(a.Xa=!1,navigator){var v=navigator.userAgent;if("Microsoft Internet Explorer"==navigator.appName||0<=v.indexOf("MSIE ")||0<=v.indexOf("Trident/")&&0<=v.indexOf("Windows NT 6"))a.Xa=!0}}catch(x){}a.ca=function(){a.da&&(h.clearTimeout(a.da),a.da=q);a.bodyClickTarget&&a.J&&a.bodyClickTarget.dispatchEvent(a.J);
  a.bodyClickFunction&&("function"==typeof a.bodyClickFunction?a.bodyClickFunction():a.bodyClickTarget&&a.bodyClickTarget.href&&(a.d.location=a.bodyClickTarget.href));a.bodyClickTarget=a.J=a.bodyClickFunction=0};a.Va=function(){a.b=a.d.body;a.b?(a.r=function(c){var b,d,f,e,g;if(!(a.d&&a.d.getElementById("cppXYctnr")||c&&c["s_fe_"+a._in])){if(a.Ga)if(a.useForcedLinkTracking)a.b.removeEventListener("click",a.r,!1);else{a.b.removeEventListener("click",a.r,!0);a.Ga=a.useForcedLinkTracking=0;return}else a.useForcedLinkTracking=
  0;a.clickObject=c.srcElement?c.srcElement:c.target;try{if(!a.clickObject||a.M&&a.M==a.clickObject||!(a.clickObject.tagName||a.clickObject.parentElement||a.clickObject.parentNode))a.clickObject=0;else{var k=a.M=a.clickObject;a.ha&&(clearTimeout(a.ha),a.ha=0);a.ha=setTimeout(function(){a.M==k&&(a.M=0)},1E4);f=a.Ma();a.track();if(f<a.Ma()&&a.useForcedLinkTracking&&c.target){for(e=c.target;e&&e!=a.b&&"A"!=e.tagName.toUpperCase()&&"AREA"!=e.tagName.toUpperCase();)e=e.parentNode;if(e&&(g=e.href,a.Oa(g)||
  (g=0),d=e.target,c.target.dispatchEvent&&g&&(!d||"_self"==d||"_top"==d||"_parent"==d||h.name&&d==h.name))){try{b=a.d.createEvent("MouseEvents")}catch(l){b=new h.MouseEvent}if(b){try{b.initMouseEvent("click",c.bubbles,c.cancelable,c.view,c.detail,c.screenX,c.screenY,c.clientX,c.clientY,c.ctrlKey,c.altKey,c.shiftKey,c.metaKey,c.button,c.relatedTarget)}catch(m){b=0}b&&(b["s_fe_"+a._in]=b.s_fe=1,c.stopPropagation(),c.stopImmediatePropagation&&c.stopImmediatePropagation(),c.preventDefault(),a.bodyClickTarget=
  c.target,a.J=b)}}}}}catch(n){a.clickObject=0}}},a.b&&a.b.attachEvent?a.b.attachEvent("onclick",a.r):a.b&&a.b.addEventListener&&(navigator&&(0<=navigator.userAgent.indexOf("WebKit")&&a.d.createEvent||0<=navigator.userAgent.indexOf("Firefox/2")&&h.MouseEvent)&&(a.Ga=1,a.useForcedLinkTracking=1,a.b.addEventListener("click",a.r,!0)),a.b.addEventListener("click",a.r,!1))):setTimeout(a.Va,30)};a.Hb();a.ic||(r?a.setAccount(r):a.C("Error, missing Report Suite ID in AppMeasurement initialization"),a.Va(),
  a.loadModule("ActivityMap"))}function s_gi(r){var a,h=window.s_c_il,q,p,m=r.split(","),s,u,t=0;if(h)for(q=0;!t&&q<h.length;){a=h[q];if("s_c"==a._c&&(a.account||a.oun))if(a.account&&a.account==r)t=1;else for(p=a.account?a.account:a.oun,p=a.allAccounts?a.allAccounts:p.split(","),s=0;s<m.length;s++)for(u=0;u<p.length;u++)m[s]==p[u]&&(t=1);q++}t?a.setAccount&&a.setAccount(r):a=new AppMeasurement(r);return a}AppMeasurement.getInstance=s_gi;window.s_objectID||(window.s_objectID=0);
  function s_pgicq(){var r=window,a=r.s_giq,h,q,p;if(a)for(h=0;h<a.length;h++)q=a[h],p=s_gi(q.oun),p.setAccount(q.un),p.setTagContainer(q.tagContainerName);r.s_giq=0}s_pgicq();
  /************************** Handler code SECTION **************************/
  // Handler registration
  var handler = false;
  if (typeof(window.digitalDataHandlers) != 'undefined' && window.digitalDataHandlers.indexOf(adobeHandler) == -1) {
      window.digitalDataHandlers.push(adobeHandler);
      _satellite.notify('adobe Handler registered ...');
      handler = true;
  }else {
      _satellite.notify('window.digitalDataHandler is missing ...');
  }