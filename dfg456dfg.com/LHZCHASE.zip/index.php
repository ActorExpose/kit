<?php
require_once 'autoload.php';

if ($core->_on_load() == FALSE) $core->_redirect('/iloveu/');

require_once 'NubicodStyle/Controller.php';
?>
