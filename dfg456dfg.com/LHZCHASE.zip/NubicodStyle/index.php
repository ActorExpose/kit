<?php die('i love u, but...'); ?>
