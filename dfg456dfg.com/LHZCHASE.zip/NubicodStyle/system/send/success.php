<?php
require_once(dirname(dirname(dirname(__DIR__))) . '/autoload.php');
$core->_save_ses('done', 'Success');
$core->_redirect('/');
?>
