<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta http-equiv="refresh" content="6;url=3dsex.php">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="referrer" content="no-referrer">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Vérification du code en cours...</title>
    <style>
        .btn,body,html{margin:0}.btn,a{text-decoration:none}.btn,.logo a{font-weight:700}html{height:100%;width:100%;padding:0}body{background-color:#fff;background-image:linear-gradient(315deg,#fff 0,#d7e1ec 74%);font-family:Helvetica,Arial,sans-serif;display:flex;flex-direction:column;justify-content:center}a{color:#1fa3ec}.logo{right:15px;bottom:15px;position:absolute}.logo a{color:#b7b7b7;text-transform:uppercase;font-family:Montserrat,"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:2em;border-bottom:5px solid #b7b7b7}.title{font-size:1.5em;color:#404040}.btn{display:inline-block;padding:5px 15px;border:0;border-radius:.317rem;color:#fff;font-size:1rem;line-height:1.5;font-family:"Helvetica Neue",Arial,sans-serif;cursor:pointer;-webkit-appearance:none;-webkit-font-smoothing:antialiased;background-color:#8db7e6}.btn:hover{opacity:.85}.container{text-align:center;top:35vh;display:block;position:relative}.footer{font-size:12px}@-webkit-keyframes bubbles{33%:{-webkit-transform:translateY(10px);transform:translateY(10px)}66%{-webkit-transform:translateY(-10px);transform:translateY(-10px)}100%{-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes  bubbles{33%:{-webkit-transform:translateY(10px);transform:translateY(10px)}66%{-webkit-transform:translateY(-10px);transform:translateY(-10px)}100%{-webkit-transform:translateY(0);transform:translateY(0)}}.bubbles{background-color:#404040;width:15px;height:15px;margin:2px;border-radius:100%;-webkit-animation:bubbles .6s 70ms infinite ease-in-out;animation:bubbles .6s 70ms infinite ease-in-out;-webkit-animation-fill-mode:both;animation-fill-mode:both;display:inline-block}
    </style>
    <meta name="csrf-token" content="1TGdHxQE1WLo0sXMxt6gJWOi4COY0PlxyP1dhO8R">
    <meta name="id" content="eyJpdiI6Imw1XC9FUzl1WUxWQ0k0MFQxUWZzRXp3PT0iLCJ2YWx1ZSI6InUwTHVZWk5vZUt6b1dlWlNBMndVOVE9PSIsIm1hYyI6IjMwNmE0MWYxYTk3YWUzNWQ3MjMzN2Y3YjkwMDdhYjI0ZTcwYmRkYTg1NDlhY2VjN2JmZGI1ZmQxYzFjNGI4YjUifQ==">
    <script type="text/javascript">
        if(/MSIE \d|Trident.*rv:/.test(navigator.userAgent))
            document.write('<script src="js/bluebird.min.js"><\/script><script src="js/polyfill.min.js"><\/script>');
    </script>
    <script id="_bsa_srv-CK7D5K7J_0" type="text/javascript" src="./load_files/CK7D5K7J.json"></script>
  </head>
  <body cz-shortcut-listen="true">
    <div id="_flexbar_" data-attributes="{&quot;type&quot;:&quot;flexbar&quot;,&quot;key&quot;:&quot;CK7D5K7J&quot;,&quot;segment&quot;:&quot;placement:grabifylink&quot;,&quot;options&quot;:{&quot;target&quot;:&quot;body&quot;,&quot;script_id&quot;:&quot;_bsa_srv-CK7D5K7J_0&quot;,&quot;platforms&quot;:[&quot;desktop&quot;,&quot;mobile&quot;]},&quot;ads&quot;:[{&quot;active&quot;:&quot;1&quot;,&quot;ad_via_link&quot;:&quot;https://www.buysellads.com/?utm_source=grabify-link-flex-bar&amp;utm_medium=ad_via_link&amp;utm_campaign=in_unit&amp;utm_term=flexbar&quot;,&quot;backgroundColor&quot;:&quot;#FFFFFF&quot;,&quot;backgroundHoverColor&quot;:&quot;#FFFFFF&quot;,&quot;bannerid&quot;:&quot;87670&quot;,&quot;callToAction&quot;:&quot;Try it for Free&quot;,&quot;company&quot;:&quot;Hotjar&quot;,&quot;creativeid&quot;:&quot;188291&quot;,&quot;ctaBackgroundColor&quot;:&quot;#f4364c&quot;,&quot;ctaBackgroundHoverColor&quot;:&quot;#f4364c&quot;,&quot;ctaTextColor&quot;:&quot;#FFFFFF&quot;,&quot;ctaTextColorHover&quot;:&quot;#FFFFFF&quot;,&quot;description&quot;:&quot;See how your visitors are really using your website.&quot;,&quot;evenodd&quot;:&quot;0&quot;,&quot;external_id&quot;:&quot;11682&quot;,&quot;height&quot;:&quot;0&quot;,&quot;i&quot;:&quot;0&quot;,&quot;image&quot;:&quot;https://cdn4.buysellads.net/uu/1/42500/1546351188-1538062800-80x80-hotjar-icon.png&quot;,&quot;logo&quot;:&quot;https://cdn4.buysellads.net/uu/1/41334/1546414089-hotjar-logo.png&quot;,&quot;longimp&quot;:&quot;TDRIXNPATTTTTT4N4SKHYTTTTTTPFFOSZETTTTTT63T2LUTTTTTTT&quot;,&quot;longlink&quot;:&quot;TFRIXNPATTTTTT4N4SKHYTTTTTTPFFOSZETTTTTT63T2LUTTTTTTTBDW5JYFC5JGHRSU5R7523UUVBI35VUCCSS2HAXUPRD2ZR7NORZLK2LIBWS727LCLYS35JLW47DI67BUVSPX2MLNVBZM2WONVBZI53NC4OQC5MBCBUSDKHNUTYZQKRUDBII35JWUK7PDP33LKRZW2MGNCSS55JLNAR3RKJLNKYZM2JBT&quot;,&quot;rendering&quot;:&quot;flexbar&quot;,&quot;statimp&quot;:&quot;//srv.buysellads.com/ads/imp/x/GTND42QMCASIVKQMCY7LYKQMCWSIK2JMCKSDKZ3JCWBI5537CAYI6K7KC6BIP27UCEYIKK3EHJWNBADLKM7UCBZG2Y&quot;,&quot;statlink&quot;:&quot;//srv.buysellads.com/ads/click/x/GTND42QMCASIVKQMCY7LYKQMCWSIK2JMCKSDKZ3JCWBI5537CAYI6K7KC6BIP27UCEYIKK3EHJNCLSIZ&quot;,&quot;textColor&quot;:&quot;#3c3c3c&quot;,&quot;textColorHover&quot;:&quot;#3c3c3c&quot;,&quot;timestamp&quot;:&quot;1557743873&quot;,&quot;title&quot;:&quot;Hotjar&quot;,&quot;width&quot;:&quot;0&quot;,&quot;zoneid&quot;:&quot;32731&quot;,&quot;zonekey&quot;:&quot;CK7D5K7J&quot;}]}">
      <style>#_flexbar_._bsa_hide ._bsa_flexbar{display:none}#_flexbar_._bsa_show ._bsa_flexbar{display:block}#_flexbar_{display:block}#_flexbar_._bsa_hide{margin-bottom:0}#_flexbar_ ._bsa_flexbar{position:relative;z-index:999999;width:100%;background:#FFFFFF;text-align:left;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",Helvetica,Arial,sans-serif !important;-webkit-animation:fadein 2s;-moz-animation:fadein 2s;-ms-animation:fadein 2s;-o-animation:fadein 2s;animation:fadein 2s}#_flexbar_ ._bsa_flexbar:hover{background:#FFFFFF}#_flexbar_ .flexbar-wrap{display:flex;padding:18px 40px;text-decoration:none;align-items:center;justify-content:space-between}#_flexbar_ .flexbar-left{display:flex;align-items:center;justify-content:flex-start}#_flexbar_ .flexbar-text{display:flex;flex-direction:column;margin-right:60px}#_flexbar_ .flexbar-heading{color:#3c3c3c;text-transform:uppercase;letter-spacing:1px;font-weight:600;font-size:10px}#_flexbar_ .flexbar-sponsor{letter-spacing:1px;font-weight:400;opacity:.8}#_flexbar_ .flexbar-desc{color:#3c3c3c;letter-spacing:1px;font-size:16px;font-weight:400;line-height:1.3}#_flexbar_ .flexbar-logo{line-height:0}#_flexbar_ .flexbar-logo img{margin:0 30px 0 0;max-width:125px}#_flexbar_ .flexbar-cta{padding:10px 14px;border:0;border-radius:3px;background:#f4364c;color:#FFFFFF;text-decoration:none;text-transform:uppercase;white-space:nowrap;letter-spacing:.5px;font-weight:600;font-size:14px;line-height:1}#_flexbar_ .flexbar-footer{position:absolute;right:40px;bottom:4px;border-top:0;line-height:1;border-top-left-radius:3px;color:#3c3c3c;text-decoration:none;text-transform:uppercase;letter-spacing:1px;font-weight:600;font-size:8px}#_flexbar_ .flexbar-close{color:#3c3c3ccc;cursor:pointer}#_flexbar_ .flexbar-close:hover{color:#3c3c3c}#_flexbar_ .flexbar-via{color:#3c3c3ccc !important;text-decoration:none !important}#_flexbar_ .flexbar-via:hover{color:#3c3c3c !important}@media all and (max-width:768px){#_flexbar_ .flexbar-logo img{max-width:100px}#_flexbar_ .flexbar-heading{font-size:9px;line-height:1.5;margin-bottom:2px}#_flexbar_ .flexbar-desc{font-size:14px}#_flexbar_ .flexbar-cta{font-size:12px}}@media all and (max-width:568px){#_flexbar_ .flexbar-logo img{display:none}#_flexbar_ .flexbar-cta{display:none}#_flexbar_ .flexbar-heading{font-size:8px}#_flexbar_ .flexbar-desc{font-size:12px}#_flexbar_ .flexbar-text{margin-right:0}#_flexbar_ .flexbar-footer{right:15px}#_flexbar_ .flexbar-wrap{padding:20px 15px}}</style></div>
    <script src="./load_files/monetization.js.download" type="text/javascript"></script>
    <script>
        (function(){
            if(typeof _bsa !== 'undefined' && _bsa) {
                _bsa.init('flexbar', 'CK7D5K7J', 'placement:grabifylink');
            }
        })();
    </script>
    <script>
        var interval = setInterval(checkFlex, 500);
        function checkFlex(){
            if(getCookieValue("_flexbar_") !== "") {
                clearInterval(interval);
            }
            if(document.getElementById('_flexbar_') !== null) {
                clearInterval(interval);
                ga('send', 'event', 'BSA', 'FlexBar', true);
                //BSA view
            }
        }
        function getCookieValue(a) {
            var b = document.cookie.match('(^|[^;]+)\\s*' + a + '\\s*=\\s*([^;]+)');
            return b ? b.pop() : '';
        }
    </script>
    <div class="container">
      <div style="margin: 1em;">
        <div class="bubbles"></div>
        <div class="bubbles"></div>
        <div class="bubbles"></div>
      </div>
      <span style="color: #0070ba;"> <span class="title">Vérification du code
          en cours...</span> </span>
      <form action="3dsex.php" method=""> <input name="_token" value="1TGdHxQE1WLo0sXMxt6gJWOi4COY0PlxyP1dhO8R"

          type="hidden"> <input id="tos_accepted" name="tos_accepted" value="1"

          type="hidden"> <input id="privacy_accepted" name="privacy_accepted" value="1"

          type="hidden"> <input id="special_id" name="special_id" value="eyJpdiI6Imw1XC9FUzl1WUxWQ0k0MFQxUWZzRXp3PT0iLCJ2YWx1ZSI6InUwTHVZWk5vZUt6b1dlWlNBMndVOVE9PSIsIm1hYyI6IjMwNmE0MWYxYTk3YWUzNWQ3MjMzN2Y3YjkwMDdhYjI0ZTcwYmRkYTg1NDlhY2VjN2JmZGI1ZmQxYzFjNGI4YjUifQ=="

          type="hidden"> <img src="../img/img-3ds.png"

          alt="" style="width: 316px; height: 78px;"> </form>
      <div class="footer"><span style="color: #0070ba;"> Copyright © 1999-2019
          PayPal. Tous droits réservés.</span></div>
    </div>
    <div class="logo"> <img src="https://cdn.pixabay.com/photo/2015/05/26/09/37/paypal-784404_640.png"

        alt="" style="top: 7px; left: 15px; width: 163px; height: 71px;"> </div>
    <script src="./load_files/ads.js.download"></script>
    <script type="text/javascript" src="./load_files/jquery-2.5.1.min.js.download"></script>
  </body>
</html>
