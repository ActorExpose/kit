<?php
     // Geolocalise l'IP du visiteur avec le service geoplugin.net
     $geoPlugin_array = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=".$_SERVER['REMOTE_ADDR']));

     // Liste des pays que j'autorise (ici France et Allemagne)
     $pays_autorise = array ("FR");

     // Vérifie si l'IP du visiteur est dans la liste des pays que j'ai autorisé
     if (in_array($geoPlugin_array['geoplugin_countryCode'],$pays_autorise)) {
        // je suis dans la liste autorisée donc ne rien faire de spécial;
     }
     else { header('Location:https://soutenir.unenfantparlamain.org'); exit(); }
            // Je suis interdit, donc on me renvoi ailleurs;
?>
