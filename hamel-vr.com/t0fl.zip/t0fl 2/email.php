<?

$to = "f.mcnicoll1@gmail.com, fellynuna@yandex.com";

?>