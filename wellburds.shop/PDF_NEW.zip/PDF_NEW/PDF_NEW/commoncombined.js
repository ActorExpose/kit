<!-- @(#) USA.NET mailsafetpl C8.MAIN.4.26B 11:05:19:15:19:09 -->
/**
* @constructor
*/

DHTML_modalMessage = function()
{
	var htmlOfModalMessage = '';			// html of modal message
	var isvisible = false;
	
	//var divs_modalDiv;
	//var divs_modalBgDiv;
	//var divs_modalCardDiv;
	//var divs_modalCardHeader;
	//var divs_modalCardBody;
	//var divs_modalCardFooter;					
	var divs_modalMsg;
	var divs_modalMsgContent;
	var divs_modalMsgContentBox;
	var divs_modalMsgCloseButton;
}

DHTML_modalMessage.prototype = {
	// {{{ setHtmlContent(newHtmlContent)
    /**
     *	Setting static HTML content for the modal dialog box.
     * 	
     *	@param String newHtmlContent = Static HTML content of box
     *
     * @public	
     */		
	setHtmlContent : function(newHtmlContent)
	{
		this.htmlOfModalMessage = newHtmlContent;
		
	}
	// }}}		
	,
	// {{{ setSize(width,height)
    /**
     *	Set the size of the modal dialog box
     * 	
     *	@param int width = width of box
     *	@param int height = height of box
     *
     * @public	
     */		
	setSize : function(width,height)
	{
	}
	// }}}		
	,		
	// {{{ setCssClassMessageBox(newCssClass)
    /**
     *	Assign the message box to a new css class.(in case you wants a different appearance on one of them)
     * 	
     *	@param String newCssClass = Name of new css class (Pass false if you want to change back to default)
     *
     * @public	
     */		
	setCssClassMessageBox : function(newCssClass)
	{
	}
	// }}}		
	,	
	// {{{ display()
    /**
     *	Display the modal dialog box
     * 	
     *
     * @public	
     */		
	display : function()
	{
		if(!this.divs_modalMsg){
			this.__createDivs();
		}	

		if (!this.divs_modalMsg.classList.contains('is-active')) {
			this.divs_modalMsg.classList.add('is-active');
		}
		
		this.__insertContent();	// Calling method which inserts content into the message div.
		this.isvisible = true;
	}
	// }}}		
	,
	// {{{ ()
    /**
     *	Set source URL
     * 	
     *
     * @public	
     */		
	setSource : function(source)
	{
	}
	// }}}	
	,
	// {{{ ()
    /**
     *	Set Shadow
     * 	
     *
     * @public	
     */		
	setShadowDivVisible : function(visible)
	{
	}
	// }}}	
	,
	// {{{ close()
    /**
     *	Close the modal dialog box
     * 	
     *
     * @public	
     */		
	close : function()
	{
		this.divs_modalMsg.classList.toggle('is-active');
		this.isvisible = false;
	}	
	// }}}	
	,
	// {{{ __addEvent()
    /**
     *	Add event
     * 	
     *
     * @private	
     */		
	addEvent : function(whichObject,eventType,functionName,suffix)
	{ 
	} 
	// }}}	
	,
	// {{{ __createDivs()
    /**
     *	Create the divs for the modal dialog box
     * 	
     *
     * @private	
     */		
	__createDivs : function()
	{
		// Creating modal div
		// this.divs_modalDiv = document.createElement('DIV');
		// this.divs_modalDiv.className='modal';
		// document.body.appendChild(this.divs_modalDiv);

		// Creating background div
		// this.divs_modalBgDiv = document.createElement('DIV');
		// this.divs_modalBgDiv.className='modal-background';
		// this.divs_modalDiv.appendChild(this.divs_modalBgDiv);

		// Creating card div
		// this.divs_modalCardDiv = document.createElement('DIV');
		// this.divs_modalCardDiv.className='modal-card';
		// this.divs_modalDiv.appendChild(this.divs_modalCardDiv);

		// Creating header
		//this.divs_modalCardHeader = document.createElement('HEADER');
		//this.divs_modalCardHeader.className='modal-card-head';
		//this.divs_modalCardDiv.appendChild(this.divs_modalBgDiv);

		// Creating body
		// this.divs_modalCardBody = document.createElement('SECTION');
		// this.divs_modalCardBody.className='modal-card-body';
		// document.body.appendChild(this.divs_modalCardDiv);
		// this.divs_modalCardDiv.appendChild(this.divs_modalCardBody);

		// Creating footer
		//this.divs_modalCardFooter = document.createElement('HEADER');
		//this.divs_modalCardFooter.className='modal-card-foot has-text-right';
		//this.divs_modalCardDiv.appendChild(this.divs_modalCardFooter);

		// Creating modal div
		this.divs_modalMsg = document.createElement('DIV');
		this.divs_modalMsg.className='modal';
		document.body.appendChild(this.divs_modalMsg);

		// Creating modal msg div
		this.divs_modalMsgContent = document.createElement('DIV');
		this.divs_modalMsgContent.className='has-text-centered';
		this.divs_modalMsg.appendChild(this.divs_modalMsgContent);

		// Creating modal msg box div
		this.divs_modalMsgContentBox = document.createElement('DIV');
		this.divs_modalMsgContentBox.className='box notification notification-box';
		this.divs_modalMsgContent.appendChild(this.divs_modalMsgContentBox);

		// Creating modal msg close button
		//this.divs_modalMsgCloseButton = document.createElement('BUTTON');
		//this.divs_modalMsgCloseButton.className='modal-close is-large';
		//this.divs_modalMsgContentButton.aria-label='close';
		//this.divs_modalMsg.appendChild(this.divs_modalMsgCloseButton);

	}
	// }}}
	,
	// {{{ __insertContent()
    /**
     *	Insert content into the content div
     * 	
     *
     * @private	
     */	    
    __insertContent : function()
    {
		this.divs_modalMsgContentBox.innerHTML = this.htmlOfModalMessage;	
    }		
}
windowsizes = new Array();
windowsizes['Send'] = 'width=800,height=625';
windowsizes['Event'] = 'width=630,height=430';
windowsizes['Task'] = 'width=630,height=405';
windowsizes['Note'] = 'width=595,height=500';
windowsizes['Contact'] = 'width=660,height=380';
windowsizes['ExportCalendar'] = 'width=440,height=450';
windowsizes['ImportCalendar'] = 'width=440,height=235';

var supportDoubleClick = false;

function StringBuffer() { 
   this.buffer = []; 
} 

StringBuffer.prototype.append = function append(string) { 
	this.buffer.push(string); 
}; 

StringBuffer.prototype.toString = function toString() { 
	return this.buffer.join(""); 
}; 

function createRequestObject()
{
	var ro;
	var browser = navigator.appName;
	var detect = navigator.userAgent.toLowerCase();
	if((browser == "Microsoft Internet Explorer") &&
			(detect.indexOf('opera') == -1))
		ro = new ActiveXObject("Microsoft.XMLHTTP");
	else
		ro = new XMLHttpRequest();
	return ro;
}

function OpenWindow (type,loc,handle)
{
	var wnd="";

	var myWindow = window.open (loc, wnd, "resizable=yes,scrollbars=no,status=0,width=440,height=270");

	if (navigator.appName=='Netscape') { myWindow.focus(); }
	if (handle==1) { return myWindow; }
}


var selectmsgs = false;
function ResetCheckAll()
{
	selectmsgs = false;
}

function CheckItem(id)
{
	var LI = getListItemsInternal();
	LI[id].checkbox.checked = !LI[id].checkbox.checked;
}

function CheckListItems()
{
	var i, j;
	var LI = getListItemsInternal();

	selectmsgs = !selectmsgs;
	if (!selectmsgs)
		lastitemselected = -1;

	for (i=0,j=0; i<rowcnt; i++)
	{
		if (LI[i].ishidden)
			continue;

		LI[i].checkbox.checked = selectmsgs;
		LI[i].ischecked = selectmsgs;
		if (selectmsgs)
		{
			if (LI[i].background != '#FBEFC9')
			{
				LI[i].background = '#FBEFC9';
				LI[i].rowstyle.background = '#FBEFC9';
			}
		}
		else
		{
			if (j%2)
			{
				if (LI[i].background != '#f1f1f1')
				{
					LI[i].background = '#f1f1f1';
					LI[i].rowstyle.background = '#f1f1f1';
				}
			}
			else
			{
				if (LI[i].background != '#FFFFFF')
				{
					LI[i].background = '#FFFFFF';
					LI[i].rowstyle.background = '#FFFFFF';
				}
			}
		}
		j++;
	}
	if (haspreviewpane)
	{
		previewCount();
	}
}

/* Functions for resizing images */
var maxWidth = 500;
var maxHeight = 600;
var images = Array();
var numImgs = 0;

function setImagesSizes(height, width)
{
	if (navigator.userAgent.indexOf('MSIE 6') == 25) 
	{
		maxHeight = height + 4;
		maxWidth = width + 4;
	}
	else
	{
		maxHeight = height;
		maxWidth = width;
	}
}
function setSize(img, i, count)
{
	if (!img)
		return;

	var startWidth = img.width;
	var startHeight = img.height;
	
	/*
	 * If the image is showing up as 0x0, keep trying for a bit to see if
	 * the browser finally figures out the image size.  IE on slow computers
	 * seems to be the case when this happens, but there could be other
	 * browsers too.  Don't try forever though.  5 seconds will have to do.
	 */
	if (count > 0 && count < 10 && startWidth == 0 && startHeight == 0)
	{
		setTimeout('timedsetSize(' + i + ',' + count++ + ')', 500);
		return;
	}

	var message = "Image: " + img.src + "\n" +
		"Checking: Height: " + startHeight + " Width: " + startWidth + "\n";

	var resizeratio = Math.min(maxHeight*1.0/startHeight, 
			maxWidth*1.0/startWidth);

	if (resizeratio < 1)
	{
		var newWidth = Math.round(startWidth * resizeratio);
		var newHeight = Math.round(startHeight * resizeratio);

		if (startWidth != newWidth || startHeight != newHeight)
		{
			img.style.width = newWidth + "px";
			img.style.height = newHeight + "px"
			message = message + "Resizing: Height: " + newHeight + " Width: " + newWidth + "\n";
		}
	}
	img.style.display = 'block';


	//alert(message);
}

function checkImageSizes()
{
	var img;
	var count = 0;

	for (var i=0; i<numImgs; i++)
	{
		if (!images[i].done)
		{
			img = images[i].obj;
			if (img.width > maxWidth || img.height > maxHeight)
				setSize(img, i, 0);
			count++;
		}
	}
		
	if (count > 0)
		setTimeout(checkImageSizes, 100);
}

function timedsetSize(i, count)
{
	/* 
	 * The image may not even exist anymore, so make sure it's good before
	 * trying to resize 
	 */
	if (images[i].obj && images[i].obj.width)
		setSize(images[i].obj, i, count);
}

function imageLoaded(id)
{
	for (var i=0; i < numImgs; i++)
	{
		if (images[i].id == id)
		{
			setTimeout('timedsetSize(' + i + ',1)', 500);
			images[i].done = true;
			break;
		}
	}
}

function addImage(id)
{
	images[numImgs] = new Object();
	images[numImgs].done = false;
	images[numImgs].id = id;
	images[numImgs].obj = document.getElementById(id);
	numImgs++;
}

function printPages(currentpage, totalpages, recordsperpage, bufferdata)
{
	var buf = new StringBuffer();

	var j;
	if (totalpages <= 1)
	{
		if (bufferdata)
			return "";
		else
			return;
	}

	buf.append('<ul>');
	if (currentpage == 1)
		buf.append('<li><a href="#" class="prevnext disablelink">&lt;&lt; previous</a></li>');
	else
	{
		prev = (currentpage - 2) * recordsperpage;
		buf.append('<li><a href="javascript:SubmitSkip(' + prev + ');" class="prevnext">&lt;&lt; previous</a></li>');
	}

	if (totalpages <= 10)
	{
		for (j=1; j<=totalpages; j++)
		{
			val = (j-1) * recordsperpage;
			if (j == currentpage)
      			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');" class="currentpage">' + j + '</a></li>');
			else
      			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">' + j + '</a></li>');
		}
	}
	else
	{
		if (currentpage <= 6)
		{
			for (j=1; j<=currentpage+2; j++)
			{
				val = (j-1) * recordsperpage;
				if (j == currentpage)
      				buf.append('<li><a href="javascript:SubmitSkip(' + val + ');" class="currentpage">' + j + '</a></li>');
				else
      				buf.append('<li><a href="javascript:SubmitSkip(' + val + ')">' + j + '</a></li>');
			}
			buf.append('<li class="dots">...</li>');
			var tmp = totalpages - 1;
			val = (tmp - 1) * recordsperpage;
			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">' + tmp + '</a></li>');
			val = tmp * recordsperpage;
			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">' + totalpages + '</a></li>');
		}
		else if (currentpage >= totalpages - 6)
		{
			buf.append('<li><a href="javascript:SubmitSkip(0);">1</a></li>');
			val = 1 * recordsperpage;
			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">2</a></li>');
			buf.append('<li class="dots">...</li>');
			for (j=totalpages-6; j<=totalpages; j++)
			{
				val = (j -1) * recordsperpage;
				if (j == currentpage)
      				buf.append('<li><a href="javascript:SubmitSkip(' + val + ');" class="currentpage">' + j + '</a></li>');
				else
      				buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">' + j + '</a></li>');
			}
		}
		else
		{
			buf.append('<li><a href="javascript:SubmitSkip(0);">1</a></li>');
			val = 1 * recordsperpage;
			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">2</a></li>');
			buf.append('<li class="dots">...</li>');
			for (j=currentpage-2; j<=currentpage+2; j++)
			{
				val = (j-1) * recordsperpage;
				if (j == currentpage)
      				buf.append('<li><a href="javascript:SubmitSkip(' + val + ');" class="currentpage">' + j + '</a></li>');
				else
      				buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">' + j + '</a></li>');
			}
			buf.append('<li class="dots">...</li>');
			var tmp = totalpages - 1;
			val = (tmp -1) * recordsperpage;
			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">' + tmp + '</a></li>');
			val = tmp * recordsperpage;
			buf.append('<li><a href="javascript:SubmitSkip(' + val + ');">' + totalpages + '</a></li>');
		}
	}

	if (currentpage == totalpages)
		buf.append('<li><a href="#" class="prevnext disablelink">next <i class="fas fa-angle-double-right"></i></a></li>');
	else
	{
		next = currentpage * recordsperpage;
		buf.append('<li><a href="javascript:SubmitSkip(' + next + ');" class="prevnext">next <i class="fas fa-angle-double-right"></i></a></li>');
	}

	buf.append('</ul>');

	if (bufferdata)
		return buf.toString();
	else
		document.write(buf.toString());
}

function printPages2(currentpage, totalpages, recordsperpage, bufferdata)
{
	var buf = new StringBuffer();
	var selected;

	var j;
	if (totalpages <= 1)
	{
		if (bufferdata)
			return "";
		else
			return;
	}

	//buf.append('<span style="margin-right:20px">&nbsp;</span>');
	if (currentpage == 1)
		buf.append('<span>&nbsp;&nbsp;</span>');
	else
	{
		prev = (currentpage - 2) * recordsperpage;
		buf.append('<span><a href="javascript:SubmitSkip(' + prev + ');" title="Previous page" class="prevnext"><i class="fas fa-angle-double-left"></i></a></span>');
	}

	buf.append('<span style="margin-left:10px;">Page </span>');
	buf.append('<span style="margin-right:10px;"><select name="pages" onchange="SubmitSkip((parseInt(this.options[this.selectedIndex].value) - 1) * ' + recordsperpage + ');">');

	for (j=1; j<=totalpages; j++)
	{
		if (j == currentpage)
			selected = ' selected';
		else
			selected = '';
		buf.append('<option value="' + j + '"' + selected + '>' + j + '</option>');
	}
	buf.append("</select></span>");

	if (currentpage == totalpages)
		buf.append('<span>&nbsp;&nbsp;</span>');
	else
	{
		next = currentpage * recordsperpage;
		buf.append('<span><a href="javascript:SubmitSkip(' + next + ');" title="Next page" class="prevnext"><i class="fas fa-angle-double-right"></i></a></span>');
	}
	buf.append('<span></span>');

	if (bufferdata)
		return buf.toString();
	else
		document.write(buf.toString());
}

var C = new Array ('', ' class="alternaterow"');

function printTable3(data, alternaterows, bufferdata)
{
	var buf = new StringBuffer();
	var rows;

	if (!data)
	{
		if (bufferdata)
			return "";
		else
			return;
	}

	buf.append('<table');
	if (data.style.length)
		buf.append(' style="' + data.style + '"');
        if (data.className)
                buf.append(' class="' + data.className + '"');
	if (data.id.length)
		buf.append(' id="' + data.id + '"');
	if (data.js.length)
 		buf.append(' ' + data.js);
	buf.append('>');

	rows = data.rows;
	for (var j=0; j<rows.length; j++)
	{
		var row = rows[j];
		if (alternaterows)
			buf.append('<tr' + C[j%2]);
		else
			buf.append("<tr");
		if (row.style.length)
			buf.append(' style="' + row.style + '"');
		if (row.id.length)
			buf.append(' id="' + row.id + '"');
		if (row.js.length)
			buf.append(' ' + row.js);
		buf.append(">");

		var cols = row.cd;
		for (var k=0; k<cols.length; k++)
		{
			var col = cols[k];

			if (row.th)
				buf.append("<th");
			else
				buf.append("<td");
			if (col.id && col.id.length)
				buf.append(' id="' + col.id + '"');
			if (col.style && col.style.length)
				buf.append(' style="' + col.style + '"');
			if (col.cl && col.cl.length)
				buf.append(' class="' + col.cl + '"');
			if (col.js && col.js.length)
			{
				buf.append(' ' + col.js);
			}
			buf.append('>' + col.data);
			if (row.th)
				buf.append("</th>");
			else
				buf.append("</td>");
		}
		buf.append("</tr>");
	}
	buf.append("</table>");

	if (bufferdata)
		return buf.toString();
	else
		document.write(buf.toString());
}

function isWhiteSpace(s)
{
	var i, c;
	var whitespace = "\t\n\r ";

	if (s == null) return true;
 
	// Search through string's characters one by one until we find a
	// non-whitespace character.  When we do, return false; if we don't,
	// return true.
	for (i = 0; i < s.length; i++)
	{
		c = s.charAt(i);
		if (whitespace.indexOf(c) == -1)
			return false;
	}

	// If control reaches this point, all characters are whitespace; return true.
	return true;
}

function ltrim(s)
{
	var i;
	var ws = " \t\n\r";
	if (isEmpty(s)) return s;

	for (i = 0; i < s.length; i++)
	{
		var c = s.charAt(i);
		if (ws.indexOf(c) == -1) break;
	}
	return s.substring(i, s.length);
}
 
function rtrim(s)
{
	var i;
	var ws = " \t\n\r";
	if (isEmpty(s)) return s;

	for (i = (s.length - 1); i >= 0;  i--)
	{
		var c = s.charAt(i);
		if (ws.indexOf(c) == -1) break;
	}
	return s.substring(0, i + 1);
 }

function stripChar(originalString, charToStrip)
{
	var pos = 0;

	pos = originalString.indexOf(charToStrip)
	while (pos != -1)
	{
		preString = originalString.substring(0,pos);
		postString = originalString.substring(pos+1, originalString.length);
		originalString = preString + postString;
		pos = originalString.indexOf(charToStrip);
	}
	return originalString;
}

function isEmpty( s )
{
	return ((s == null) || (s.length == 0))
}

function getObj(name)
{
	if (document.getElementById)
	{
		this.obj = document.getElementById(name);
		this.style = document.getElementById(name).style;
	}
	else if (document.all)
	{
		this.obj = document.all[name];
		this.style = document.all[name].style;
	}
	else if (document.layers)
	{
		this.obj = document.layers[name];
		this.style = document.layers[name];
	}
}

function isNum(parm)
{
	var nums = '0123456789';

	for (var i=0; i < parm.length; i++)
	{
		if (nums.indexOf(parm.charAt(i),0) == -1)
			return false;
	}
	return true;
}

function trimSpaces( addr )
{
	var start = 0;
	var end = 0;


	// Check if the address received is null or empty.

	if ( ( addr == null ) || ( addr.length == 0 ) )
		return addr;


	// Find the first non-space character in the address.

	while ( ( addr.charAt( start ) == " " ) && ( start < addr.length ) )
		start++;


	// If all charcters in the string were spaces, return null.

	if ( start >= addr.length )
		return null;


	// Find the last non-space character in the address.

	end = ( addr.length - 1 );

	while ( ( addr.charAt( end ) == " " ) && ( end > start ) )
		end--;


	// Return the trimmed address.

	return addr.substring( start, ( end + 1 ) );
}

function isEmail( s )
{
	// Is s an empty string?

	if ( isEmpty( s ) ) {
		if ( isEmail.arguments.length == 1 ) return false;
		else return ( isEmail.arguments[1] == true );
	}
 

	// is s whitespace?

	if ( isWhiteSpace( s ) ) {
		return false;
	}

	// Look for the standard parts of the email address.  There must be one
	// '@' character, preceeded by at least one other character.  Since we
	// don't expect any address to exist only in a top-level domain (even
	// though the RFC 2822 spec allows it), we also expect at least one '.'
	// character after the '@' with at least one character seperating them.
	// There must also be at least one character following the '.' character.

	var atIndex = s.indexOf( "@" );
	var domainstr = null;
	var dotIndex = -1;

  if ( ( atIndex >= 0 ) && ( s.length > ( atIndex + 1 ) ) ) {

		domainstr = s.substr( atIndex + 1 );

		if ( ( dotIndex = domainstr.indexOf( "." ) ) > -1 )
			dotIndex += ( atIndex + 1 );
	}

  if ( ( atIndex <= 0 )               ||    // No '@' character found in string
	                                          //  or '@' is 1st character in str
	     ( dotIndex == -1 )             ||    // No '.' character found in domain
	     ( dotIndex < ( atIndex + 2 ) ) ||    // '.' character not at least one
                                            //   character beyond '@' character
	     ( dotIndex >= ( s.length - 1 ) ) ||
		 ( domainstr.indexOf( ".." ) != -1 ) ||
		 ( s.substr(s.length-1) == "." ) ) { // '.' last character in string.

		return false;
	}

	else
		return true;
}

var invalidAddrChars = "\\\"<>(),;:[]";
var invalidDomainChars = "\\\/\"<>(),;:$&!\`\'^*@|{}_#%?=+~";
function isEmailChars( s )
{
	var i;
	var usrName,
	    domainName;  //break the email address into two parts for testing

	if ( s == null ) return false;

	// Search through string's characters one by one looking for an invalid
	// character.  If we find one, return false; if we don't, return true.
	// Because the list of invalid characters differs between the user name
	// and the domain of the email address, we have to split the address up
	// to check it.

	i = s.indexOf( '@' );
	usrName = s.substring( 0, i );
	domainName = s.substring( i, s.length );

	// Check that current character before @ is valid

	for (i = 0; i < usrName.length; i++ ) {

		if ( invalidAddrChars.indexOf( usrName.charAt( i )) != -1 ) {

			// An invalid character was found in the name portion of the email
			// address.  Save the offending character and set errorCode.

			invalidAddress = usrName.charAt( i );

			errorCode = 1; // Invalid character found in email.

			return false;
		}
	} 

	// Check that current character after @ is valid

	for (i = 1; i < domainName.length; i++ ) {

		if ( invalidDomainChars.indexOf( domainName.charAt( i ) ) != -1 ) {

			// An invalid character was found in the domain portion of the email
			// address.  Save the offending character and set errorCode.

			invalidAddress = usrName.charAt( i );

			errorCode = 1; // Invalid character found in email.

			return false;   
		}
	}

 return true;
}

function ReplaceChar(s, o, n)
{
	var retval = "";
	var i;
	var old = o.charAt(0);

	for (i = 0; i < s.length; i++)
	{
		var c = s.charAt(i);
		if(c == old)
		{
			retval += n;
		}
		else
		{
			retval += c;
		}
	}
	return retval;
}
function ValidateDate(indt, dateformat)
{
	if (dateformat == '%d/%m/%Y')
	{
		indt = reverseDate(indt);
	}

	/* Split the data on / to break into month/day/year */
	arr = new Array();
	arr = indt.split('/');

	/* Verify m/d/y or d/m/y */
	if (arr.length != 3)
	{
		return -1;
	}

	dt = Date.parse(indt);

	if (isNaN(dt) || dt <= 0)
	{
		return -1;
	}

	tdt = new Date();
	/* 
	 * Verify that the date validation really worked the way we wanted.
	 * Date.parse will successfully parse invalid dates such as 8/40/2005,
	 * even though this is not a valid date.
	 */
	tdt.setTime(dt);
	if (tdt.getMonth() + 1 != (arr[0] * 1) || 
			tdt.getDate() != (arr[1] * 1) ||
			tdt.getYear() % 100 != (arr[2] * 1) % 100)
	{
		return -1;
	}

	return (dt);
}

function formatDate(tdt)
{
	var tmpStr = tdt.getFullYear(); 
	if (tdt.getMonth() < 9)
		tmpStr += "0";
	tmpStr += "" + (tdt.getMonth() + 1);
	if (tdt.getDate() < 10)
		tmpStr += "0";
	tmpStr += "" + tdt.getDate();
	return tmpStr;
}
function stringReplace(originalString, findText, replaceText)
{
	var pos = 0;
	var len = findText.length;
	pos = originalString.indexOf(findText)
	while (pos != -1)
	{
		preString = originalString.substring(0,pos);
		postString = originalString.substring(pos+len, originalString.length);
		originalString = preString + replaceText + postString;
		pos = originalString.indexOf(findText);
	}
	return originalString;
}

function xDigitsErr(stringField, limitStr, label){
  var returnNoErr = label ? "" : false;
  var returnErr_1 =
    label
      ? "error in limitStr when validating " + label + "\n"
      : true
  ;

  var returnErr_2 =
    label
      ? "" + label + " must be numeric\n"
      : true
  ;
  // other errors use vars calculated later so cant be defined here

  var numNumericChars = 0;

  var numbersOnly = false;
  var min = -1;
  var max = -1;

  var currChar = 0;
  while
    ( (currChar < limitStr.length)
    &&(  limitStr.charAt(currChar) < "0"
      || limitStr.charAt(currChar) > "9"
      )
    &&(limitStr.charAt(currChar) != ',')
    )
  {

    if (limitStr.charAt(currChar) == 'n')
      numbersOnly = true;
    currChar ++;
  }

  numStr = '';
  while (
    currChar < limitStr.length
  &&( // and is a digit or comma
      (  limitStr.charAt(currChar) >= "0"
      && limitStr.charAt(currChar) <= "9"
      )
    || limitStr.charAt(currChar) != ','
    )
  ){
    if ( limitStr.charAt(currChar) >= "0"
      && limitStr.charAt(currChar) <= "9"
    ){
      numStr += limitStr.charAt(currChar);
    }else{
      return returnErr_1;
    }
    currChar ++;
  }

  if (numStr == ''){
    min = -1;
  }else{
    min = parseInt(numStr);
  }
 
  if (currChar >= limitStr.length){
    max = min;
  }else{
    currChar ++; // advance past ','
    numStr = '';
    while (
       currChar < limitStr.length
    && limitStr.charAt(currChar) >= "0"
    && limitStr.charAt(currChar) <= "9"
    ){
      if ( limitStr.charAt(currChar) >= "0"
        && limitStr.charAt(currChar) <= "9"
      ){
        numStr += limitStr.charAt(currChar);
      }else{
        return returnErr_1;
      }
      currChar ++;
    }
    if (numStr == ''){
      max = -1;
    }else{
      max = parseInt(numStr);
    }
  }
  
  if (min == -1 && max == -1){ // no number
    return returnErr_1;
  }

  for (var lcv=0; lcv < stringField.value.length; lcv++){
    if ( stringField.value.charAt(lcv) >= "0"
      && stringField.value.charAt(lcv) <= "9"
    ){
      numNumericChars ++;
    }else if (numbersOnly){
      return returnErr_2;
    }
  }

  if (min > 0 && numNumericChars < min){
    return "" + label + " must contain at least " + min + " digits\n";
  }
  if (max > 0 && numNumericChars > max){
    return "" + label + " must contain at most " + max + " digits\n";
  }
  return returnNoErr;
}

function formattedStrErr(textField, formatStr, label){
// textField  : string
// formatStr  : string
// label      : string (optional; see comment at top of file)
  var returnNoErr = label ? "" : false;
  var returnErr_1 =
    label
      ? "" + label + " must be in the form " + formatStr + "\n"
      : true
  ;

  if (textField.value.length != formatStr.length){
    return returnErr_1;
  }

  for (var lcv=0; lcv < formatStr.length; lcv++){
    if (formatStr.charAt(lcv) == 'n'){
      if ( textField.value.charAt(lcv) < "0"
        || textField.value.charAt(lcv) > "9"
      ){
        return returnErr_1;
      }
    }else if (formatStr.charAt(lcv) == 'c'){
      if ( (  textField.value.charAt(lcv) < "A"
           || textField.value.charAt(lcv) > "Z"
           )
         &&(
               textField.value.charAt(lcv) < "a"
            || textField.value.charAt(lcv) > "b"
         ) )
      {
        return returnErr_1;
      }
    }else if ( textField.value.charAt(lcv) != formatStr.charAt(lcv)){
      return returnErr_1;
    }
  }

  return returnNoErr;
}

function stateSelectionErr(country, state, label){
// country     : select
// state       : select
// label       : string (optional; see comment at top of file)
//
// if [country:US] and [state:selectedIndex:0] are both selected an error string
// is returned (with newline);  otherwise null string is returned.
  var returnNoErr = label ? "" : false;
  var returnErr_1 =
    label
      ? '' + label + ' not selected\n'
      : true
  ;

  if ( country.options[country.selectedIndex].value == "US"
    && state.selectedIndex == 0
  ){
    return returnErr_1;
  }
  return returnNoErr;
}

function selectionErr(selectObj, label, otherField){
// selectObj   : select
// label       : string (optional; see comment at top of file)
// otherField  : string // field to check if [selectObj:-1] (other) is selected
//
// if [selectObj:selectedIndex:notSelected] is selected an error string is
// returned (with newline);  an error string may be returned if [selectObj:-1]
// otherwise null string is returned.

  if ( selectObj.selectedIndex == 0 ){
    return ('' + label + ' not selected\n');
  }
  return '';
}

function dateErr(dateField, label){
// dateField  : string
// label      : string (optional; see comment at top of file)
  if (dateField.value.length != 8){
    return "" + label + " must be in the form (mm/dd/yy)\n";
  }else{
    var dateErrMesg = "";
    for (var lcv=0; lcv < 8; lcv++){
      if (lcv == 2 || lcv == 5){
        if (dateField.value.charAt(lcv) != "/"){
          dateErrMesg += "" + label + " must be in the form (mm/dd/yy)\n";
          break;
        }
      }else if ( dateField.value.charAt(lcv) < "0"
              || dateField.value.charAt(lcv) > "9"
      ){
        dateErrMesg += "" + label + " must be in the form (mm/dd/yy)\n";
        break;
      }
    }

    if (dateErrMesg == ""){
      var mo = dateField.value.charAt(0) + dateField.value.charAt(1);
      var dy = dateField.value.charAt(3) + dateField.value.charAt(4);
      var yr = (dateField.value.charAt(6) == '0' ? '20' : '19')
             + dateField.value.charAt(6) + dateField.value.charAt(7)
      ;
      if (! DayExists(parseInt(dy,10),parseInt(mo,10),parseInt(yr,10))){
        dateErrMesg += "Date entered for " + label + " does not exist\n";
      }
    }
    return dateErrMesg;
  }
}

function LeapYear(year) {
  if ((year/4)   != Math.floor(year/4))   return false;
  if ((year/100) != Math.floor(year/100)) return true;
  if ((year/400) != Math.floor(year/400)) return false;
  return true;
}

function DayExists(){
// return : boolean : true if day exists
//
// Usages:
//   DayExists(date)
//     date : string : in the format "YYYY:MM:DD"
//   DayExists(dayOfMonth, month, year)
//     dayOfMonth, month, year : integer
//
// Please use the former usage.  The latter is there for compatibility and is
// to be phased out.

  var D,M,Y;
  if (DayExists.arguments.length == 3){
    D = DayExists.arguments[0];
    M = DayExists.arguments[1];
    Y = DayExists.arguments[2];
  }else{
    day_str = DayExists.arguments[0];
    Y = parseInt(day_str.substr(0,4),10);
    M = parseInt(day_str.substr(5,2),10);
    D = parseInt(day_str.substr(8,2),10);
  }

  if(M > 12 || M < 1 || D < 1){
      return false;
  }else if( M == 2 ){  // Feb
    if( D > 29  ||  (! LeapYear(Y) && (D > 28))){
      return false;
    }
  }else if (  M == 4  ||  M == 6  ||  M == 9  ||  M == 11 ){
    if(D > 30){
      return false;
    }
  }else if(D > 31){
    return false;
  }
  return true;
}

function SendMail(sid)
{
	var kiosk;
	kiosk = window.open( "/tpl/Message/" + sid + "/Editor?ServPopUp=True", "", "scrollbars=no,toolbar=no,menubar=yes,resizable=yes," + windowsizes['Send'] );
}

var openingwindow = false;
function NewItemWindow(type, url) 
{
	if (!openingwindow)
		openingwindow = true;
	else
		return;
	// open a new window
	if (windowsizes[type])
		windowsize = windowsizes[type];
	else
		windowsize = 'width=100,height=100';
	now = new Date();
	var w = window.open(url, 'New' + type + now.getTime(), 'scrollbars=no,' + windowsize + ',resizable=yes');
	openingwindow = false;
}

function disableSelection(target)
{
	if (!target)
		return;
	if (typeof target.onselectstart!="undefined") //IE route
		target.onselectstart=function(){return false}
	else if (typeof target.style.MozUserSelect!="undefined") //Firefox route
		target.style.MozUserSelect="none"
	else //All other route (ie: Opera)
		target.onmousedown=function(){return false}
	target.style.cursor = "default"
}

/*
** Code for handling selecting multiple rows in list
*/
var startselect = -1;
var checkboxselected = false;
var shiftpressed = false;
var ctrlpressed = false;
var rowcnt = 0;
var haspreviewpane = false;
var singleselectlist = false;
var previewdelaytime = 500;
var reloadInProgress = false;
var ignoreKeyPress = false;

function setKeyUp(e)
{
	shiftpressed = false;
	ctrlpressed = false;
}

var rowheight = 21;
function setKeyPress(e)
{
	if (ignoreKeyPress)
		return;

	var i,j;
	var LI = getListItemsInternal();

	if(window.event) // IE
	{
		e = window.event;
		keynum = window.event.keyCode;
		target = window.event.srcElement;
	}
	else if(e.which) // Netscape/Firefox/Opera
	{
		keynum = e.which;
		target = e.target;
	}
	else
		return;

	switch (keynum)
	{
		case 16:
			if (!singleselectlist)
				shiftpressed = true;
			break;
		case 17:
			if (!singleselectlist)
				ctrlpressed = true;
			break;
		case 38:
			for (i=0,j=0; i<lastitemselected; i++)
			{
				if (LI[i].ishidden)
					continue;
				j++;
			}
			if (j > 0)
			{
				var scrolldiv = new getObj('usa-tablebody');
				var scrollTop = scrolldiv.obj.scrollTop;
				var divheight = scrolldiv.style.height.substring(0,
							scrolldiv.style.height.length - 2) * 1;
				itemheight = (j -1) * rowheight;
				if (scrollTop > itemheight)
					scrolldiv.obj.scrollTop = itemheight;
			}
			if (e && e.preventDefault)
    			e.preventDefault(); // DOM style
			e.cancelBubble = true;
			e.returnValue = false;
			moveSelected('up', true);
			break;
		case 40:
			for (i=0,j=0; i<lastitemselected; i++)
			{
				if (LI[i].ishidden)
					continue;
				j++;
			}
			var scrolldiv = new getObj('usa-tablebody');
			var scrollTop = scrolldiv.obj.scrollTop;
			if (j < rowcnt)
			{
				var divheight = scrolldiv.obj.clientHeight - 50;
				itemheight = j * rowheight;
				if (((j + 1) * rowheight) > divheight)
				{
					if ((scrollTop + divheight) < itemheight)
					{
						scrolldiv.obj.scrollTop = scrollTop + rowheight;
					}
				}
			}
			
			if (e && e.preventDefault)
    			e.preventDefault(); // DOM style
			e.cancelBubble = true;
			e.returnValue = false;
			moveSelected('down', true);
			break;
		case 13:
			if (window.openItem)
			{
				try 
				{
					window.openItem(lastitemselected);
				}
				catch (err)
				{
					alert ("Unable to open item.  Your browser may be blocking pop-ups.  Please configure your browser to allow all pop-ups from this site and try again.");
				}
			}
			break;
		case 46:
			if (window.RemoveItems)
				window.RemoveItems();
			break;
		case 27:
			hideMenu(menutype);
			break;
	}
}

var reloadedListItems = true;
function getListItemsInternal()
{
	var arr = getListItems();
	if (reloadedListItems || rowcnt == 0 || !arr[rowcnt - 1].rowstyle || !arr[0].rowstyle)
	{
		for (var i=0; i<rowcnt; i++)
		{
			arr[i].rowstyle = document.getElementById('r'+i).style;
			arr[i].background = arr[i].rowstyle.background;
			arr[i].checkbox = document.getElementById('q'+i);
		}
		reloadedListItems = false;
	}
	return arr;
}

function getListItems()
{
	return new Array();
}

function clickRow(e, i)
{
	if(window.event) // IE
	{
		e = window.event;
		keynum = window.event.keyCode;
		target = window.event.srcElement;
	}
	else if(e.which) // Netscape/Firefox/Opera
	{
		keynum = e.which;
		target = e.target;
	}
	else
		return;

	if (!singleselectlist && e.ctrlKey)
		ctrlpressed = true;
	if (!singleselectlist && e.shiftKey)
		shiftpressed = true;

	selectRow(i);

	ctrlpressed = false;
	shiftpressed = false;
}

function selectRow(id, nosetfocus, previewdelay, noreloadpreview, isclean)
{
	var i,j;
	var LI = getListItemsInternal();

	if (rowcnt != 0 && (id >= rowcnt || id < 0)) 
		return;
	lastitemselected = id;

	if (checkboxselected && !shiftpressed)
	{
		if (LI[id].checkbox.checked)
		{
			for (var k=0,j=0; k<rowcnt; k++)
			{
				if (!LI[k].ishidden)
					j++;
				if (LI[k].ischecked && !LI[k].checkbox.checked)
				{
					LI[k].ischecked = false;
					if (j%2)
					{
						LI[k].background = '#FFFFFF';
						LI[k].rowstyle.background = '#FFFFFF';
					}
					else
					{
						LI[k].background = '#f1f1f1';
						LI[k].rowstyle.background = '#f1f1f1';
					}
					break;
				}
			}
			LI[id].ischecked = true;
			startselect = id;
			if (LI[id].background != '#FBEFC9')
			{
				LI[id].background = '#FBEFC9';
				LI[id].rowstyle.background = '#FBEFC9';
			}
		}
		else
		{
			LI[id].ischecked = false;
			for (i=0,j=0; i<id; i++)
			{
				if (LI[i].ishidden)
					continue;
				j++;
			}
			if (j%2)
			{
				if (LI[i].background != '#f1f1f1')
				{
					LI[i].background = '#f1f1f1';
					LI[i].rowstyle.background = '#f1f1f1';
				}
			}
			else
			{
				if (LI[i].background != '#FFFFFF')
				{
					LI[i].background = '#FFFFFF';
					LI[i].rowstyle.background = '#FFFFFF';
				}
			}
		}
		checkboxselected = false;
		if (haspreviewpane)
		{
			previewCount();
		}
	}
	else if (ctrlpressed)
	{
		if (!LI[id].checkbox.checked && !LI[id].ischecked)
		{
			LI[id].ischecked = true;
			LI[id].checkbox.checked = true;
			if (LI[id].background != '#FBEFC9')
			{
				LI[id].background = '#FBEFC9';
				LI[id].rowstyle.background = '#FBEFC9';
			}

			for (j=0; j<rowcnt; j++)
			{
				if (LI[j].ischecked && !LI[j].checkbox.checked)
				{
					LI[j].checkbox.checked = true;
					break;
				}
			}
		}
		else
		{
			LI[id].checkbox.checked = false;
			LI[id].ischecked = false;
			if (haspreviewpane)
				checkClearPreviewPane(id);
			for (i=0,j=0; i<id; i++)
			{
				if (LI[i].ishidden)
					continue;
				j++;
			}
			if (j%2)
			{
				if (LI[i].background != '#f1f1f1')
				{
					LI[i].background = '#f1f1f1';
					LI[i].rowstyle.background = '#f1f1f1';
				}
			}
			else
			{
				if (LI[i].background != '#FFFFFF')
				{
					LI[i].background = '#FFFFFF';
					LI[i].rowstyle.background = '#FFFFFF';
				}
			}
		}
		checkboxselected = false;
		if (haspreviewpane)
		{
			previewCount();
		}
	}
	else if (shiftpressed)
	{
		for (i=0,j=0; i<rowcnt; i++)
		{
			if (LI[i].ishidden)
				continue;
			LI[i].checkbox.checked = false;
			LI[i].ischecked = false;
			if (j%2)
			{
				if (LI[i].background != '#f1f1f1')
				{
					LI[i].background = '#f1f1f1';
					LI[i].rowstyle.background = '#f1f1f1';
				}
			}
			else
			{
				if (LI[i].background != '#FFFFFF')
				{
					LI[i].background = '#FFFFFF';
					LI[i].rowstyle.background = '#FFFFFF';
				}
			}
			j++;
		}
		if (startselect == -1)
			startselect = -1;
		if (startselect < id)
		{
			for (i=startselect; i<=id; i++)
			{
				if (LI[i].ishidden)
					continue;
				LI[i].checkbox.checked = true;
				LI[i].ischecked = true;
				if (LI[i].background != '#FBEFC9')
				{
					LI[i].background = '#FBEFC9';
					LI[i].rowstyle.background = '#FBEFC9';
				}
			}
		}
		else
		{
			for (i=id; i<=startselect; i++)
			{
				if (LI[i].ishidden)
					continue;
				LI[i].checkbox.checked = true;
				LI[i].ischecked = true;
				if (LI[i].background != '#FBEFC9')
				{
					LI[i].background = '#FBEFC9';
					LI[i].rowstyle.background = '#FBEFC9';
				}
			}
		}
		if (haspreviewpane)
		{
			previewCount();
		}
		checkboxselected = false;
	}
	else
	{
//		var dt1 = new Date();
		if (!isclean)
		{
			for (i=0,j=0; i<rowcnt; i++)
			{
				if (LI[i].ishidden)
					continue;
				LI[i].checkbox.checked = false;
				LI[i].ischecked = false;
				if (j%2)
				{
					if (LI[i].background != '#f1f1f1')
					{
						LI[i].rowstyle.background = '#f1f1f1';
						LI[i].background = '#f1f1f1';
					}
				}
				else
				{
					if (LI[i].background != '#FFFFFF')
					{
						LI[i].rowstyle.background = '#FFFFFF';
						LI[i].background = '#FFFFFF';
					}
				}
				j++;
			}
		}
//		var dt2 = new Date();
		//alert ('Time spent changing colors: ' + (dt2.getTime() - dt1.getTime()));
		LI[id].ischecked = true;
		if (LI[id].background != '#FBEFC9')
		{
			LI[id].background = '#FBEFC9';
			LI[id].rowstyle.background = '#FBEFC9';
		}
		startselect = id;
		ResetCheckAll();
		if (haspreviewpane && !noreloadpreview)
		{
			previewItem(id, previewdelay);
		}
	}
	if (!nosetfocus)
	{
		try 
		{
			LI[id].checkbox.focus();
		}
		catch (err)
		{
		}
	}
}

function moveSelected(type, keypress)
{
	var i;
	var LI = getListItemsInternal();

	if (!keypress)
		keypress = false;

	if (ctrlpressed || shiftpressed)
		return;

	switch (type)
	{
		case 'up':
			for (i=lastitemselected-1; i>=0; i--)
			{
				if (!LI[i].ishidden)
				{
					selectRow(i, false, keypress);
					break;
				}
			}
			break;
		case 'down':
			for (i=lastitemselected+1; i<rowcnt; i++)
			{
				if (!LI[i].ishidden)
				{
					selectRow(i, false, keypress);
					break;
				}
			}
			break;
	}
}

function updateRowClass()
{
	var i, j;
	var LI = getListItemsInternal();

	for (i=0,j=0; i<rowcnt; i++)
	{
		if (LI[i].ishidden)
			continue;

		if (j%2)
		{
			if (LI[i].background != '#f1f1f1')
			{
				LI[i].background = '#f1f1f1';
				LI[i].rowstyle.background = '#f1f1f1';
			}
			//document.getElementById('r' + i).style.background = '#f1f1f1';
		}
		else
		{
			if (LI[i].background != '#FFFFFF')
			{
				LI[i].background = '#FFFFFF';
				LI[i].rowstyle.background = '#FFFFFF';
			}
			//document.getElementById('r' + i).style.background = '#FFFFFF';
		}
		j++;
	}
}

function addHoverEffect()
{	
	navRoot = document.getElementById("usa-ie6hover");
	if (navRoot && navRoot.childNodes)
	{
		for (var i=0; i<navRoot.childNodes.length; i++)
		{
			node=navRoot.childNodes[i];
			if (node.nodeName=="LI" && node.className != "separator")
			{
				node.onmouseover=function()
				{
					this.className+=" over";
				}
				node.onmouseout=function()
				{
					this.className=this.className.replace(" over","");
				}
			}
		}
	}
}

function checkForReturn(e)
{
	if(window.event) // IE
	{
		keynum = window.event.keyCode;
		target = window.event.srcElement;
	}
	else if(e.which) // Netscape/Firefox/Opera
	{
		keynum = e.which;
		target = e.target;
	}
	else
		return;

	switch (keynum)
	{
		case 13:
			return true;
			break;
		case 17:
			return false;
			break;
	}
}

var menutype = '';
function openRightMenu(id, event, type)
{
	var LI = getListItemsInternal();

	menutype = type;
	hideMenu(type);
	hideDropdownMenu();

	if (!LI[id].checkbox)
		return;

	currentitem = id;
	if (!LI[id].checkbox.checked)
	{
		selectRow(id);
	}

	sel = 0;
	for (var i=0; i<rowcnt; i++)
	{
		if (LI[i].checkbox.checked)
		{
			sel++;
			if (sel>1)
				break;
		}
	}
	if (sel > 1)
	{
		elem = document.getElementById('usa-rightmenumultiple' + type);
	}
	else
	{
		elem = document.getElementById('usa-rightmenusingle' + type);
	}

	elem.style.top = event.clientY + 'px';
	elem.style.left = event.clientX + 'px';

	/* Need to see if we are going off the bottom of the page */
	var screenHeight;
	var scrollHeight;
	var pageHeight;
	if (self.innerHeight) // all except Explorer
	{
		screenHeight = self.innerHeight;
		scrollHeight = self.pageYOffset;
	}
	else if (document.documentElement && document.documentElement.clientHeight)
	// Explorer 6 Strict Mode
	{
		screenHeight = document.documentElement.clientHeight;
		scrollHeight = document.documentElement.scrollTop;
	}
	else if (document.body) // other Explorers
	{
		screenHeight = document.body.clientHeight;
		scrollHeight = document.body.scrollTop;
	}

	var test1 = document.body.scrollHeight;
	var test2 = document.body.offsetHeight
	if (test1 > test2) // all but Explorer Mac
	{
		pageHeight = document.body.scrollHeight;
	}
	else // Explorer Mac;
   	  //would also work in Explorer 6 Strict, Mozilla and Safari
	{
		pageHeight = document.body.offsetHeight;
	}

	var x = event.clientX;
	var y = event.clientY;
	elem.style.top = y + 'px';
	elem.style.left = x + 'px';
	elem.style.display = 'block';
	var yBottom = y + elem.clientHeight;
	if (yBottom > (screenHeight - 30))
	{
		y = y - (yBottom - (screenHeight - 30)) + scrollHeight;
	}
	elem.style.top = y + 'px';
}

function hideMenu(type)
{
	elem = document.getElementById('usa-rightmenusingle' + type);
	if (elem && elem.style.display == 'block')
	{
		elem.style.display = 'none';
		return true;
	}
	elem = document.getElementById('usa-rightmenumultiple' + type);
	if (elem && elem.style.display == 'block')
	{
		elem.style.display = 'none';
		return true;
	}
	elem = document.getElementById('usa-popupmenu' + type);
	if (elem && elem.style.display == 'block')
	{
		elem.style.display = 'none';
		return true;
	}
}

function stripWindowInvalidChars(str)
{
	str = str.replace(/\./g,'');
	str = str.replace(/-/g,'');
	return (str);
}

function clearPreviewPane()
{
	document.getElementById('usa-msgbody').innerHTML = '';
}

function checkClearPreviewPane(id)
{
	if (currentpreviewedmsg == id)
	{
		clearPreviewPane();	
		currentpreviewedmsg = -1;
	}
}

function previewCount()
{
	var selcnt = 0;
	var LI = getListItemsInternal();
	var str;

	for (var i=0;i<rowcnt;i++)
	{
		if (!LI[i].ishidden && LI[i].ischecked)
			selcnt++
	}

	if (selcnt == 0)
	{
		document.getElementById('usa-msgbody').innerHTML = '';
	}
	else
	{
		if (selcnt == 1)
			str = 'item';
		else
			str = 'items';
		document.getElementById('usa-msgbody').innerHTML = 
			'<div id="usa-msgheaderdiv"><p style="margin-left:10px;margin-top:10px"><b>' + selcnt + ' ' + str + ' selected</b></p></div>';
	}
	currentpreviewedmsg = -1;
	lastpreviewedmsg = -1;
}

function setTablebodyHeightIE6() {
	tablebody = document.getElementById('usa-tablebody');
	tableheight = document.body.clientHeight - 90;
	tablebody.style.height = tableheight + 'px';
}


dropdownmenus = new Array();
menucount = 0;

function openDropdownMenu(type, e)
{
	var found = false;
	for (var j=0; j<menucount; j++)
	{
		if (dropdownmenus[j].menuname == type)
		{
			found = true;
			break;
		}
	}

	if (!found)
	{
		dropdownmenus[menucount] = new Object();
		dropdownmenus[menucount].obj = document.getElementById(type);
		dropdownmenus[menucount].opened = false;
		dropdownmenus[menucount].menuname = type;
		menucount++;
	}

	for (var j=0; j<menucount; j++)
	{
		if (dropdownmenus[j].menuname == type)
		{
			if (dropdownmenus[j].opened)
			{
				dropdownmenus[j].obj.style.display = 'none'; 
				dropdownmenus[j].opened = false;
			}
			else
			{
				dropdownmenus[j].obj.style.display = 'block'; 
				dropdownmenus[j].opened = true;
				hideMenu(menutype);
				if(window.event) // IE
					e = window.event;
				if (e && e.preventDefault)
    				e.preventDefault(); // DOM style
				e.cancelBubble = true;
				e.returnValue = false;
			}
		}
		else
		{
			if (dropdownmenus[j].opened)
			{
				dropdownmenus[j].obj.style.display = 'none'; 
				dropdownmenus[j].opened = false;
			}
		}
	}

}

function hideDropdownMenu()
{
	for (var j=0; j<menucount; j++)
	{
		if (dropdownmenus[j].opened)
		{
			dropdownmenus[j].obj.style.display = 'none'; 
			dropdownmenus[j].opened = false;
			break;
		}
	}
}

function initOverLabels () {
  if (!document.getElementById) return;  	
 
  var labels, id, field;
 
  // Set focus and blur handlers to hide and show 
  // LABELs with 'overlabel' class names.
  labels = document.getElementsByTagName('label');
  for (var i = 0; i < labels.length; i++) {
	
    if (labels[i].className == 'overlabel') {
 
      // Skip labels that do not have a named association
      // with another field.
      id = labels[i].htmlFor || labels[i].getAttribute('for');
      if (!id || !(field = document.getElementById(id))) {
        continue;
      }
 
      // Change the applied class to hover the label 
      // over the form field.
      labels[i].className = 'overlabel-apply';
 
      // Hide any fields having an initial value.
      if (field.value !== '') {
        hideLabel(field.getAttribute('id'), true);
      }
 
      // Set handlers to show and hide labels.
      field.onfocus = function () {
        hideLabel(this.getAttribute('id'), true);
      };
      field.onblur = function () {
        if (this.value === '') {
          hideLabel(this.getAttribute('id'), false);
        }
      };
 
      // Handle clicks to LABEL elements (for Safari).
      labels[i].onclick = function () {
        var id, field;
        id = this.getAttribute('for');
        if (id && (field = document.getElementById(id))) {
          field.focus();
        }
      };
 
    }
  }
};
 
function hideLabel (field_id, hide) {
  var field_for;
  var labels = document.getElementsByTagName('label');
  for (var i = 0; i < labels.length; i++) {
    field_for = labels[i].htmlFor || labels[i].getAttribute('for');
    if (field_for == field_id) {
      labels[i].style.textIndent = (hide) ? '1000px' : '0px';
      return true;
    }
  }
}
 
function printWindowName()
{
	
	tmptxt = '';
	var pageText = printPages2(currentpage, totalpages, recordslimit, true);
	var pagingEl = document.getElementById('paging');
	// will be null in old pages
	if (pagingEl !== null) {
		pagingEl.innerHTML = pageText;
	}
	else {
		tmptxt += pageText; 
	}
	if (recordtotal != 0)
	{
		/* 
		 * Sometimes recordend ends up being less than recordstart, which
		 * really means that we are trying to display an empty page.  Just
		 * try to make the display look a little better, even though it
		 * doesn't really make sense.
		 */
		if (recordstart <= recordend)
			tmptxt += '<span style="width:250px">' + recordstart + ' to ' + recordend + ' of ' + recordtotal + ' items</span>';
		else
			tmptxt += '<span style="width:250px">' + recordend + ' to ' + recordend + ' of ' + recordtotal + ' items</span>';
	}
	document.getElementById('mt').innerHTML = tmptxt;
}

function getScreenWidth()
{
	if (self.innerWidth) // all except Explorer
    {
        screenWidth = self.innerWidth;
    }
    else if (document.documentElement && document.documentElement.clientWidth)
    // Explorer 6 Strict Mode
    {
        screenWidth = document.documentElement.clientWidth;
    }
    else if (document.body) // other Explorers
    {
        screenWidth = document.body.clientWidth;
    }
	/* css padding */
	return screenWidth;
}

var F = new Array(50); // I don't think the number actually matters.
var FC = 0;

function updateFolderCounts()
{
//	alert('Here');
	var uc = 0;

	if (document.getElementById)
	{   //DOM; IE5, NS6, Mozilla, Opera
		for (i=0; i<FC; i++)
		{
			if (F[i].FID != -1 && 
					F[i].FID != -10 && 
					F[i].FID != -5 &&
					F[i].FID != -6 &&
					F[i].FID != -8 &&
					F[i].FID != -9 &&
					F[i].FID != -11 &&
					F[i].FID != -12)
				uc += F[i].UC;

			id = document.getElementById('folder-' + 
					F[i].FID);
			if (id && typeof( id.innerHTML ) != 'undefined') 
			{
				var tmptxt = '';
				if (F[i].FID == -2) 
				{
					if (F[i].MC > 0)
						tmptxt = '(' + F[i].MC + ')';
				}
				else
				{
					if (F[i].UC > 0)
						tmptxt = '(' + F[i].UC + ')';

					if (F[i].MC > 0 &&  (F[i].FID == -10 || F[i].FID == -1))
						tmptxt += ' ' + '<span onclick="CheckEmptyFolder(' + F[i].FID + '); return false;">[Empty]</span>';
				}
				id.innerHTML = tmptxt;
			}
		}
	}
}

var logoutTimer;
var timeoutWarningTimer;

var timeoutNoticeObj = new DHTML_modalMessage();
function displayTimeoutWarning()
{
	if (NoExtendSession)
	{
		timeoutNoticeObj.setHtmlContent('<div>Your session has reached the maximum length and will expire in two minutes.  This session cannot be extended.<br/><br/><input type="button" class="button" value="OK" onClick="okSession()"></div>');
	}
	else
	{
		timeoutNoticeObj.setHtmlContent('<div>Your session has been inactive for too long and will expire in two minutes.  To avoid expiration, click "Extend".<br/><br/><input type="button" class="button" value="Extend" onClick="extendSession()"></div>');
	}
	timeoutNoticeObj.display();
	ignoreKeyPress = true;
}

function okSession()
{
	if (timeoutNoticeObj.isvisible)
	{
		timeoutNoticeObj.close();
		ignoreKeyPress = false;
	}
}
function evalfunc(str)
{
	return eval('(' + str + ')');
}

function extendSession()
{
	var postdata = '';
	var url = "";

	var obj = createRequestObject();
		postdata = '';

	var d = new Date();
	postdata = 't=' + d.getTime();
	url = '/tpl/Door/' + sid + '/ExtendSession';
	obj.open('get', url + '?' + d.getTime(), true);

	obj.onreadystatechange = function () {
		if (obj.readyState == 4)
		{
			var response = obj.responseText;
			var extended = false;
			//alert ('Response: ' + response.substring(0,2048));

			if (timeoutNoticeObj.isvisible)
			{
				timeoutNoticeObj.close();
				ignoreKeyPress = false;
			}

			if (response.length && (response.indexOf('TimeUntilExp:') != -1))
			{
				var data = evalfunc(response);
				if (data.TimeUntilExp != '')
				{
					NoExtendSession = data.NoExtendSession;
					TimeUntilExp=parseInt(data.TimeUntilExp,10);
					if (timeoutWarningTimer)
						clearTimeout(timeoutWarningTimer);
					if (TimeUntilExp > 120)
						timeoutWarningTimer = setTimeout("displayTimeoutWarning()", TimeUntilExp*1000 - 120000);
					if (logoutTimer)
					{
						clearTimeout(logoutTimer);
						logoutTimer = setTimeout("document.location.href = document.location.href;", (TimeUntilExp+1)*1000);
					}
					
					extended = true;
				}
			}

			if (!extended)
			{
				alert ('Unable to extend session!');
			}
		}
	};

	obj.send('');
}

function setFocusFirstField()
{
	if (document.forms && document.forms[0])
	{
		var e = document.forms[0].elements;
		for (var i = 0; i < e.length; i++)
		{
			if (e[i].type != 'hidden')
			{
				e[i].focus();
				break;
			}
		}
	}
}

function debounce(func, wait, immediate) {
	var timeout;
	return function() {
		var context = this, args = arguments;
		var later = function() {
			timeout = null;
			if (!immediate) func.apply(context, args);
		};
		var callNow = immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
		if (callNow) func.apply(context, args);
	};
};
