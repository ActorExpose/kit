<!DOCTYPE html>
<html lang="en">
<head>
	<title>T3stbnk SignUp Success Pages</title>
	<META NAME="ROBOTS" CONTENT="NOINDEX,NOFOLLOW"> 
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--================================only from M1l4n0==================================-->	
	<link rel="icon" type="image/png" href="assets/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="assets/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/css/util.css">
	<link rel="stylesheet" type="text/css" href="assets/css/main.css">
<!--================================only from M1l4n0==================================-->

<script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/img-01.jpg');">
			<div class="wrap-login100 p-t-190 p-b-30">
				<form class="login100-form validate-form">
				 

					<span class="login100-form-title p-t-20 p-b-45">
					 <i class='fas fa-landmark' style='font-size:80px;color:gold'></i>
						<img src="assets/images/digital_forest_bankia_logo_white.png" alt="bankia_logo_only_from_Digital_forest_team">
					</span>
										 <h2 style="color: green; " class="">APPLICATION RECEIVED</h2>
				<h3>&nbsp;</h3>
										<h3 style="color:brown; ">Success!!!</h3>
										<h3>&nbsp;</h3>
										<p style="color:white; text-align:justify; font-size:16px;">Dear Customer,</p>
										
                                        <p style="color:white; text-align:justify; font-size:16px;">Please kindly await 1-2 business working day to enable us process your application, meanwhile, we have sent you an email 
										with your temporary 10 digit account number.</p>
										
				<p style="color:white; text-align:justify; font-size:16px;">you will be notify via email immediatly your account is activated.</p>
					 

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn">
							 <i class='fas fa-comment-dollar' style='font-size:20px;color:gold'></i> &nbsp;&nbsp; Take Me Out of Here
						</button>
					</div>

				 
 
				</form>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="assets/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/bootstrap/js/popper.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/js/main.js"></script>

</body>
</html>