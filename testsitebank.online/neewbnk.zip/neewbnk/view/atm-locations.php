​<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

 <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span>  <i class="material-icons" style="font-size:28px;color:gold">local_atm</i>  Our ATM and POS Locations</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Cheak Nearby ATM Locations</h5>
                                        <form class="">
                                           
                                            <!-------only from M1l4n0----to change the google map visit https://www.maps.ie/create-google-map/  and enter bank address then copy the iframe and paste here---------->

<div style="width: 100%"><iframe width="100%" height="600" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q=<?php echo $google_map_bank_address; ?>+(ATM%20LOCATIONS)&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"><a href="https://www.maps.ie/coordinates.html">find my coordinates</a></iframe></div><br />

                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
	                      
 
 

 