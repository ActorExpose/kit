<?php
session_start();

if (isset($_POST['acc_no'])) { 
    $_SESSION['acc_no'] = $_POST['acc_no'];
}
 
?> 
<?php

require('../library/config2.php');
?>


 
 
 
 
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
					 
        
   
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                             
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fas fa-passport' style='font-size:24px;color:orange'></i> <?php echo $site_title; ?> TO <?php echo $site_title; ?>  Money Transfer </span>
                                </a>
                            </li> 
                        </ul>                   
	                      
	                      <div class="tab-content">
	                        
                                <br>

                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"> 
                                        
            
                          
                               <form action="" method="POST"  enctype="multipart/form-data" id="formValidate">
                            
                                 <?php
									if(isset($_POST['check']))
									{
										//Get form data
										$acc_no=$_POST['acc_no'];
										
										$query=mysqli_query($conn,"SELECT * FROM `tbl_accounts` WHERE `acc_no`=$acc_no");
										$row=mysqli_fetch_array($query);
										if($row['acc_no']==$acc_no){
										   
										   
										   echo '<meta content="5; url=?v=Samebank"       http-equiv="refresh" />';
                        			echo '<h4 style="
                        			
                        			
                    			       color:white;
                            		  padding: 10px;
                                      background-color: green; 
                                      width: 40%;
                                      height:40px;
                                      border-radius:10px;
                                      font-size:16px;
                                      font-weight:700;
                    			
                        			
                        			
                        			">Customer Account Number is valid....</h4>';
                        			 	
										}else{
										   echo "<h4 style='
										    color:white;
                                    		padding: 10px;
                                              background-color: brown; 
                                              width: 30%;
                                              height:40px;
                                              border-radius:6px;
                                              font-size:16px;
                                              font-weight:700;
										   
										   
										   
										   ' >Invalid Customer Account Number!</h4>"; 
										}
									 }
								
								?>
                       
                          
                          
                            <div class="position-relative form-group"><label for="exampleAddress" class="">10 Digit <?php echo $site_title; ?>  Account Number</label>
                            <input name="acc_no" placeholder="Enter Beneficiary Account Number" id="token" style="height:80px;"  type="text" class="form-control" required=""></div>
 
                                            
                                            <button  id="submitButton" type="submit" name="check"   class="mt-2 btn btn-primary">
                                                <i class='fas fa-passport' style='font-size:24px;color:orange'></i>&nbsp;
                                                Check Account ></button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>

 
 
 
 
 
 
  