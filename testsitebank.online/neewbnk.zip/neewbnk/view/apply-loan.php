<script src='https://kit.fontawesome.com/a076d05399.js'></script>
  
  
  
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fas fa-store-alt-slash' style='font-size:20px;color:gold'></i> Loan and Mortage Application</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
	                          
	                           
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Confidential Document Application</h5>
                                       in need of facility? kindly complete the form below, approval take 1-2 business working days
                                       
                                       <br>
                                      
                                        <form action="<?php echo WEB_ROOT; ?>view/process.php?action=applyloan" method="post">
              
                            <input type="hidden" class="form-control"   name="accno"  value="<?php echo $_SESSION['hlbank_user']['acc_no'] ?>" />
                            <input type="hidden" class="form-control"  name="email"  value="<?php echo $_SESSION['hlbank_user']['email']; ?>" />
                            <input type="hidden" class="form-control"  name="siteemail"  value="<?php echo $site_email; ?>"/>
                            <input type="hidden" class="form-control"  name="sitetitle"  value="<?php echo $site_title; ?>"/>
                                           
                                            <div class="position-relative form-group"><label for="exampleAddress" class="">Loan Amount</label>
                                            <input name="amt" id="exampleAddress"  type="text" placeholder="Enter Loan Amount e.g $10,000.00" class="form-control" required></div>
                                            
                                            
                                            <div class="position-relative form-group"><label for="exampleAddress2" class="">Duration of Facility</label>
                                            <input name="dura" id="exampleAddress2"   placeholder="Duration of Loan (e.g 12months)"  type="text" class="form-control" required>
                                            </div>
                                            
                                             <div class="position-relative form-group"><label for="exampleAddress2" class="">Loan Naration</label>
                                            <textarea class="form-control" rows="5" name="body" placeholder="Enter Full Loan Details" required=""></textarea>
                                            </div>
                                           
                                            
                                            
                                            <button type="submit" name="login" class="mt-2 btn btn-primary">
                                                <i class='fas fa-store-alt-slash' style='font-size:20px;color:gold'></i>
                                                Submit Application</button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
	                      
  
  
  
    