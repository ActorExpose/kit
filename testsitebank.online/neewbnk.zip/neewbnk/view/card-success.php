<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Language" content="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Modals - Wide selection of modal dialogs styles and animations available.</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
<meta name="description" content="Wide selection of modal dialogs styles and animations available.">
<meta name="msapplication-tap-highlight" content="no">



<script>

$(document).ready(function(){

    $(".show-modal").click(function(){

        $("#centralModalSuccess").modal({

            backdrop: 'static',

            keyboard: false

        });

    });

});

</script>
	
	<style>
	    
 

/* Modal Content/Box */
.modal-body {
  background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 90%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
} 
	</style>
</head>

<body>
    


 <!-- Central Modal Medium Success -->
 <div class="modal fade" id="centralModalSuccess" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <div class="modal-dialog modal-notify modal-success" role="document">
     <!--Content-->
     <div class="modal-content">
       <!--Header-->
       <div class="modal-header" style="background-color:white; color:white;">
         
         
         <h1 class="heading lead">&nbsp;</h1>

         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
           
         </button>
       </div>

       <!--Body-->
       <div class="modal-body">
           <div class="modal-header" style="background-color:green; color:white;">
         
         
         <h1 class="heading lead">Bank Card Request</h1>

         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
           <span aria-hidden="true" class="white-text">&times;</span>
         </button>
       </div>
       
         <div class="text-center">
           <i class="fas fa-check fa-4x mb-3 animated rotateIn" style="color:green;"></i>
           <p>Your card request messages has been sent successfully to <?php echo $site_title; ?> Card Issuance Department for processing. 
                    you will be notified via email within 1-2 working days. Your Card Ticket Number:  
                    #1209<?php echo $_SESSION['hlbank_user']['acc_no'] ?><?php echo $_SESSION['hlbank_user']['id'] ?>000000</p>
         </div>
       </div>
        <meta content="10; url=?v=dashboard"       http-equiv="refresh" />
       <!--Footer-->
       <div class="modal-footer justify-content-center">
         <a type="button" class="btn btn-success">OKAY<i class="far fa-gem ml-1 text-white"></i></a> 
       </div>
     </div>
     <!--/.Content-->
   </div>
 </div>
 <!-- Central Modal Medium Success-->
 <!-- Central Modal Medium Success-->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script>
  $('#centralModalSuccess').modal('show');
 
</script>


 
</body>
</html>

  
 
 
 