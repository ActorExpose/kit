<?php
session_start();
?>


<?php 

if (isset($_POST['telex_no'])) { 
    $_SESSION['telex_no'] = $_POST['telex_no'];
}

?>     
            
<?php  
$errorMessage = (isset($_GET['msg']) && $_GET['msg'] != '') ? $_GET['msg'] : '&nbsp;';
$msgMessage = (isset($_GET['success']) && $_GET['success'] != '') ? $_GET['success'] : '&nbsp;';
?>


   

<div id="errorCls" style="color:#FF0000 !important;font-size:14px;font-weight:bold;"><?php echo $errorMessage; ?></div>
<div style="color:#99FF00 !important;font-size:14px;font-weight:bold;"><?php echo $msgMessage; ?></div>
 
						
						
					 
						
						 
                  
    
 	<script src='https://kit.fontawesome.com/a076d05399.js'></script>
					 
								
						 
               
   
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                             
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fas fa-passport' style='font-size:24px;color:orange'></i>Telex Transfer Form (MT101, MT103)</span>
                                </a>
                            </li> 
                        </ul>                   
	                      
	                      <div class="tab-content">
	                           <div class="form-desc" style="color:#05194B; text-align:justify;">
                               This transfer will be processed manually at <?php echo $site_title; ?> Funds Transfer Department at <?php echo $site_address; ?> within 2-3 business working days 
                  and you will be notified via email of it's <strong; style="color:red">STATUS</strong>
                                
                            </div>
                                <br>

                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Please ensure all fields are completed</h5>
                                        
                                        
                                        
                                        <form id="formValidate" action="<?php echo WEB_ROOT; ?>view/process3.php?action=transfer" method="post">
                                            
                            <div class="position-relative form-group"><label for="exampleAddress" class="">Telex Approval Code</label>
                            <input  id="exampleAddress" readonly name="accno" value="<?php echo $site_initial; ?>/<?php   echo $_SESSION['telex_no']  ; ?>/TELEX/29292<?php   echo $_SESSION['telex_no']  ; ?>000292" type="text" class="form-control"></div>
                                            
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Customer Name</label>
                                    <input name="" id="exampleEmail11" value="<?php echo $_SESSION['hlbank_user_name'];  ?>" placeholder="Receiver Bank Name" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Customer Date of Birth</label>
                                    <input name="" id="examplePassword11" value="<?php echo $_SESSION['hlbank_user']['dob']; ?>" placeholder="Receiver Account Number" type="text"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                             <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Customer Email Address</label>
                                    <input name="" id="exampleEmail11" value="<?php echo $_SESSION['hlbank_user']['email']; ?>" placeholder="Receiver Fullname" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Mobile Number</label>
                                    <input name="" id="examplePassword11" value="<?php echo $_SESSION['hlbank_user']['phone']; ?>" placeholder="Receiver Email Address" type="text"  class="form-control" required="required"></div>
                                </div>
                            </div>
                             <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Postal Code</label>
                                    <input name="" id="exampleEmail11" value="<?php echo $_SESSION['hlbank_user']['zipcode']; ?>" placeholder="Receiver Fullname" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Country</label>
                                    <input name="" id="examplePassword11" value="<?php echo $_SESSION['hlbank_user']['country']; ?>" placeholder="Receiver Email Address" type="text"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                            <div class="position-relative form-group"><label for="exampleAddress" class="">Sender's Address</label>
                            <input name=""  value="<?php echo $_SESSION['hlbank_user']['address']; ?>"  style="height:80px;" id="exampleAddress"  type="text" class="form-control"></div>
                            
                             
                              <h3 style="font-weight:700;">Receiver/Beneficiary's Details</h3>
                              
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Receiver's Bank Name</label>
                                    <input name="r_bank" id="exampleEmail11" name="rbname" placeholder="Beneficiary Bank Name" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Receiver Account Number</label>
                                    <input  id="examplePassword11" name="r_accno" placeholder="Beneficiary Account Number" type="text"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Receiver's Name</label>
                                    <input name="bname" id="exampleEmail11" name="rname" placeholder="Beneficiary Name" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Receiver Email</label>
                                    <input  id="examplePassword11" name="r_email" placeholder="Beneficiary Email ID" type="email"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                            
                              
                             <div class="form-row">
                                 
                                    <script type= "text/javascript" src="<?php echo WEB_ROOT; ?>assets/Digital_forest_team_bankia_countries.js"></script>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Receiver Country</label>
                                     <select id="country" class="form-control" required="required" name="rcountry"></select>  </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Receiver State</label>
                                       <select class="form-control"  name ="rstate" id ="state" required ></select> </div>
                                </div>
                            </div>
                            
                            
                             <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Swift Code/Routing/IBAN</label>
                                    <input name="swift" id="exampleEmail11" value="" placeholder="Swift Code/Routing/IBAN" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Amount (<?php echo $_SESSION['hlbank_user']['currency'] ?>):</label>
                                    <input name="amt" id="amt" value="" placeholder="Amount" type="text"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                            
                            <div class="position-relative form-group"><label for="exampleAddress" class="">Transaction Naration</label>
                            <input name="description"  style="height:80px;" id="exampleAddress"  type="text" class="form-control"></div>
                            
                                           
                                <input type="hidden" value="<?php echo date("h:i A d M Y"); ?>" name="dot" > 
                                	<input name="toption" type="hidden" readonly="true" value="IT"  class="form-control"  />
						<input name="saccno" type="hidden" readonly="true" value="<?php echo $_SESSION['hlbank_user']['acc_no'] ?>"  id="saccno" class="form-control"  />
                                            
                                            <button name="submitButton" id="submitButton" type="submit" class="mt-2 btn btn-primary">
                                                <i class='fas fa-passport' style='font-size:24px;color:orange'></i>&nbsp;
                                                Proceed Telex Transfer ></button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
 
  
    
                  
        
            

 <script language="javascript">
	populateCountries("country", "state"); // first parameter is id of country drop-down and second parameter is id of state drop-down
	populateCountries("country2");
	populateCountries("country2");
</script>
   
    
    
 
