
						
						<div class="row">
						
						
								 <?php 
	  $user_id = $_SESSION['hlbank_user']['user_id'];
	  $acc_no = $_SESSION['hlbank_user']['acc_no'];
	  
	  $balance_sql = "SELECT balance FROM tbl_accounts WHERE user_id = $user_id AND acc_no = $acc_no";
	  $result = dbQuery($balance_sql);
	  $row = dbFetchAssoc($result);
	  ?>
                            <div class="col-md-6 col-xl-4">
                               
								<div class="card mb-3 widget-content bg-grow-early">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Total Balance</div>
                                            <div class="widget-subheading">cumulative balance</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span><?php echo $_SESSION['hlbank_user']['currency']; ?>. <?php echo number_format($row['balance'] , 2); ?></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-arielle-smile">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Legder Balance</div>
                                            <div class="widget-subheading">none withdrawal</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span><?php echo $_SESSION['hlbank_user']['currency']; ?>.  <?php echo number_format($row['balance'] + 150 , 2); ?></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                 <div class="card mb-3 widget-content bg-midnight-bloom">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Card Balance</div>
                                            <div class="widget-subheading">ATM only</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span><?php echo $_SESSION['hlbank_user']['currency']; ?>.  <?php echo number_format($row['balance'] / 4, 2); ?></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-xl-none d-lg-block col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-premium-dark">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Loan Balance</div>
                                            <div class="widget-subheading">Avaliable </div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-warning"><span><?php echo $_SESSION['hlbank_user']['currency']; ?>.  <?php echo number_format($row['balance'] * 10, 2); ?></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						
						
						
						
						 <div class="row">
                            <div class="col-md-6 col-lg-3">
                                <div class="card-shadow-danger mb-3 widget-chart widget-chart2 text-left card">
                                    <div class="widget-content">
                                        <div class="widget-content-outer">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-left pr-2 fsize-1">
                                                    <div class="widget-numbers mt-0 fsize-3 text-danger"><?php echo number_format($row['balance'] / 300, 2); ?>%</div>
                                                </div>
                                                <div class="widget-content-right w-100">
                                                    <div class="progress-bar-xs progress">
                                                        <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="31" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo number_format($row['balance'] / 300, 2); ?>%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="widget-content-left fsize-1">
                                                <div class="text-muted opacity-6">Deposit Log</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="card-shadow-success mb-3 widget-chart widget-chart2 text-left card">
                                    <div class="widget-content">
                                        <div class="widget-content-outer">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-left pr-2 fsize-1">
                                                    <div class="widget-numbers mt-0 fsize-3 text-success"><?php echo number_format($row['balance'] / 150, 2); ?>%</div>
                                                </div>
                                                <div class="widget-content-right w-100">
                                                    <div class="progress-bar-xs progress">
                                                        <div class="progress-bar bg-success" role="progressbar" aria-valuenow="74" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo number_format($row['balance'] / 150, 2); ?>%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="widget-content-left fsize-1">
                                                <div class="text-muted opacity-6">Withdrawal Log</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="card-shadow-warning mb-3 widget-chart widget-chart2 text-left card">
                                    <div class="widget-content">
                                        <div class="widget-content-outer">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-left pr-2 fsize-1">
                                                    <div class="widget-numbers mt-0 fsize-3 text-warning"><?php echo number_format($row['balance'] / 900, 2); ?>%</div>
                                                </div>
                                                <div class="widget-content-right w-100">
                                                    <div class="progress-bar-xs progress">
                                                        <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="12" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo number_format($row['balance'] / 900, 2); ?>%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="widget-content-left fsize-1">
                                                <div class="text-muted opacity-6">ATM Logs</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="card-shadow-info mb-3 widget-chart widget-chart2 text-left card">
                                    <div class="widget-content">
                                        <div class="widget-content-outer">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-left pr-2 fsize-1">
                                                    <div class="widget-numbers mt-0 fsize-3 text-info"><?php echo number_format($row['balance'] / 200, 2); ?>%</div>
                                                </div>
                                                <div class="widget-content-right w-100">
                                                    <div class="progress-bar-xs progress">
                                                        <div class="progress-bar bg-info" role="progressbar" aria-valuenow="99" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo number_format($row['balance'] / 200, 2); ?>%;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="widget-content-left fsize-1">
                                                <div class="text-muted opacity-6">Transaction Logs</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
                        <div class="row">
                            <div class="col-md-12 col-lg-6">
                                <div class="mb-3 card">
                                    <div class="card-header-tab card-header-tab-animation card-header">
                                        <div class="card-header-title">
                                            <i class="header-icon lnr-apartment icon-gradient bg-love-kiss"> </i>
                                            Transaction Statistics
                                        </div>
                                        
                                    </div>
                                    <div class="card-body">
                                        <div class="tab-content">
                                            <div class="tab-pane fade show active" id="tabs-eg-77">
                                                <div class="card mb-3 widget-chart widget-chart2 text-left w-100">
                                                    <div class="widget-chat-wrapper-outer">
                                                        <div class="widget-chart-wrapper widget-chart-wrapper-lg opacity-10 m-0">
                                                            <canvas id="canvas"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                                <h6 class="text-muted text-uppercase font-size-md opacity-5 font-weight-normal">Recent Transactions</h6>
                                              
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-6">
                                <div class="mb-3 card">
                                    <div class="card-header-tab card-header">
                                        <div class="card-header-title">
                                            <i class="header-icon lnr-rocket icon-gradient bg-tempting-azure"> </i>
                                            Loan Repayment Graph
                                        </div>
                                        <div class="btn-actions-pane-right">
                                           
                                        </div>
                                    </div>
                                    <div class="tab-content">
                                        <div class="tab-pane fade active show" id="tab-eg-55">
                                            <div class="widget-chart p-3">
                                                <div style="height: 350px">
                                                    <canvas id="line-chart"></canvas>
                                                </div>
                                                <div class="widget-chart-content text-center mt-5">
                                                    <div class="widget-description mt-0 text-warning">
                                                        <i class="fa fa-arrow-left"></i>
                                                        <span class="pl-1">15.5%</span>
                                                        <span class="text-muted opacity-8 pl-1">Proceed to Loan Section</span>
                                                    </div>
                                                </div>
                                            </div>
                                             
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content">
                                    <div class="widget-content-outer">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Total Money Transfer</div>
                                                <div class="widget-subheading">all method </div>
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-success">
                                        
                                      <?php echo number_format($row['balance'] / 1400, 2); ?>
                                                    
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content">
                                    <div class="widget-content-outer">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Total Bank Deposit</div>
                                                <div class="widget-subheading">Cash T3stbnk</div>
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-warning">
                                                    
                                   <?php echo number_format($row['balance'] / 1800, 2); ?>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content">
                                    <div class="widget-content-outer">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Total Wire Transfer</div>
                                                <div class="widget-subheading">Offshore only</div>
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-danger"><?php echo number_format($row['balance'] / 1500, 2); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-xl-none d-lg-block col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content">
                                    <div class="widget-content-outer">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Total Telex Transfer</div>
                                                <div class="widget-subheading">Quick Transfer</div>
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-focus"><?php echo number_format($row['balance'] / 5000, 2); ?></div>
                                            </div>
                                        </div>
                                        <div class="widget-progress-wrapper">
                                            <div class="progress-bar-sm progress-bar-animated-alt progress">
                                                <div class="progress-bar bg-info" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="1" style="width: 1%;"></div>
                                            </div>
                                            <div class="progress-sub-label">
                                                <div class="sub-label-left">Expenses</div>
                                                <div class="sub-label-right">0%</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                
                
                
                
                 <div class="row">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-header">Recent Account History
                                        <div class="btn-actions-pane-right">
                                            <div role="group" class="btn-group-sm btn-group">
                                                <button class="active btn btn-focus">Last Week</button>
                                                <button class="btn btn-focus">All Month</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                                            <thead>
                                            <tr>
                                                <th class="text-center">USER</th>
                                                <th>DATE</th>
                                                <th class="text-center">REFERENCE NO</th>
                                                <th class="text-center">NARATION</th>
                                                <th class="text-center">TYPE</th>
                                                <th class="text-center">RECEIVER A/C</th>
                                                <th class="text-center">RECEIVER EMAIL</th>
                                                <th class="text-center">RECEIVER BANK</th>
                                                <th class="text-center">SWIFT/IBAN/RT</th>
                                                <th class="text-center">DEBIT (<?php echo $_SESSION['hlbank_user']['currency'] ?>)</th>
                                                <th class="text-center">CREDIT (<?php echo $_SESSION['hlbank_user']['currency'] ?>)</th>
                                                <th class="text-center">STATUS</th>
                                            </tr>
                                            </thead>
                                            
                                           <?php
                                                if (!defined('WEB_ROOT')) {
                                                	exit;
                                                }
                                                
                                                $user = $_SESSION['hlbank_user'];
                                                $acc_no = $user['acc_no'];
                                                if (!isset($acc_no) && $acc_no <= 0) {
                                                	header('Location: index.php');
                                                }
                                                
                                                $sql = "SELECT * FROM tbl_transaction WHERE to_accno = $acc_no 
                                                		ORDER BY id DESC LIMIT 4";
                                                $result = dbQuery($sql);
                                                
                                                ?>    
                                            
                                            <tbody>
                                            
                                            
                                            
                                            
                                            
                                            <tr <?php echo $class; ?> >
                                                
                                                	<?php

                                                    if(dbAffectedRows($result) > 0) { //if
                                                    $i = 0;
                                                    while($row = dbFetchAssoc($result)) {
                                                    	extract($row);
                                                    	if ($i%2) {$class = 'row1';} 
                                                    	else {$class = 'row2';}
                                                    	$i += 1;
                                                    ?>
                                                <td class="text-center text-muted">
                                                    <?php
														$my_pic = $_SESSION['hlbank_user']['pics'];
														$upics = (isset($my_pic) && $my_pic != "") ? $my_pic : "anonymous-user.jpg"; 
														?>
                                                                    <img width="40" class="rounded-circle" src="<?php echo WEB_ROOT; ?>images/thumbnails/<?php echo $upics; ?>" alt="">
                                                    
                                                </td>
                                            
                                                <td class="text-center"> <?php echo $date; ?></td>
                                                 <td class="text-center"> <?php echo $tx_no; ?></td>
                                                  <td class="text-center"><?php echo $description; ?></td>
                                                  <td class="text-center"><?php echo $comments; ?></td>
                                                  <td class="text-center"><?php echo $r_accno; ?></td>
                                                  <td class="text-center"><?php echo $r_email; ?></td>
                                                  <td class="text-center"><?php echo $r_bank; ?></td>
                                                  <td class="text-center"><?php echo $swift; ?></td>
                                                <td class="text-center">
                                                    <div class="badge badge-danger"><?php echo $tx_type == "debit" ? "&nbsp;" . number_format($amount, 2) : ""; ?></div>
                                                </td>
                                                <td class="text-center">
                                                    <button type="button" class="badge badge-warning"><?php echo $tx_type == "credit" ? "&nbsp;" . number_format($amount, 2) : ""; ?></button>
                                                </td>
                                                 <td class="text-center">
                                                    <div class="badge badge-success"><?php echo $status; ?></div>
                                                </td>
                                            </tr>
                                             
                                             <?php
						} // end while
						}//if
						else {
						?>
						  <tr> 
						   <td colspan="6" align="right">You have no transaction history yet, seems that you haven't done any transaction yet.</td>
						  </tr>
						<?php 
						}//else
	$user_id = $_SESSION['hlbank_user']['user_id'];
	$acc_no = $_SESSION['hlbank_user']['acc_no'];
	  
	$balance_sql = "SELECT balance FROM tbl_accounts WHERE user_id = $user_id AND acc_no = $acc_no";
	$result = dbQuery($balance_sql);
	$row = dbFetchAssoc($result);
?>

                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-block text-center card-footer">
                                        <button class="mr-2 btn-icon btn-icon-only btn btn-outline-danger"><i class="pe-7s-trash btn-icon-wrapper"> </i></button>
                                        <button class="btn-wide btn btn-success">  <a href="<?php echo WEB_ROOT; ?>view/?v=Statement">View More</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
 
 
                      
                                                
                                                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                         
                            </div>
                        </div>
                    </div>