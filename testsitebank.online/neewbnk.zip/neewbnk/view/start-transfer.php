 	<div class="panel-header bg-primary-gradient">
					<div class="page-inner py-5">
						<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
							<div> 
								<h2 class="text-white pb-2 fw-bold"><i class='far fa-money-bill-alt' style='font-size:24px'></i> Start Wire Transfer</h2>
								<h5 class="text-white op-7 mb-2"> Choose wire Transfer Option </h5>
							</div>
						 
						</div>
					</div>
				</div>
 	
 	
 	<style>
         	.th {
          background-color: white;
          color: white;
        }
 	    .{tr:nth-child(even) {background-color: white;};
 	    }
 	</style>
 	
 	<div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
              
                <div class="card-body">
                  <form>
                   
                   <table >
                       <tr>
                           <td bgcolor="white">    <!-----TO switch to COT CODE REQUEST change ?v=Transfer   to  ?v=intl-transfer---BELOW -->
                          <a href="<?php echo WEB_ROOT; ?>view/?v=loading" class="button ecogreen max-width-for-mobile"><img src="<?php echo WEB_ROOT; ?>include/assets/intl.png" title="International Funds Transfer" /></a>
						  <h3><strong >Int'l Wire Transfer</strong></h3></td>
                           <td> <a href="<?php echo WEB_ROOT; ?>view/?v=local-transfer2" class="button ecogreen max-width-for-mobile"><img src="<?php echo WEB_ROOT; ?>include/assets/local.png" title="Local Funds Transfer"   /></a>
						  <h3><strong >Local Transfer(USA => USA)</strong></h3></td>
                       </tr>
                       
                   </table>
                  
                    <button type="submit" class="button ecogreen max-width-for-mobile">Add Beneficiary</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>