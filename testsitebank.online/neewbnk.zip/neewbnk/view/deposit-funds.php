               <script src='https://kit.fontawesome.com/a076d05399.js'></script>
               
               
               
                    <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fab fa-cc-amazon-pay' style='font-size:23px;color:gold'></i>  Bank and Cash Deposit Request Application</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
	                            <?php echo $site_initial; ?> cash deposit is the money you pay into your bank account or savings account. ... 
                        Cash deposits don't have to be cash, they can be cheques or
                       money transfers – the term applies to all money paid into an account. ... If you want to pay in a large cash deposit your bank may ask you to do so
                   
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Ensure avaliable deposit amount is avaliable before submiting application</h5>
                                        
                    <h4 class="btn btn-primary">CASH DEPOSIT ACCOUNT DETAILS</h4> 
                   <P>Name of Bank =>:  <?php echo $site_bank_name; ?> 
                    <p>Bank Address =>:  <?php echo $site_bank_address; ?> 
                   <p> Account Name =>: <?php echo $site_bank_name; ?> 
                    <p>Account Number =>: <?php echo $site_account_no; ?> 
                    <p>Routing Number =>: <?php echo $site_account_routing; ?> 
                    <p>Account Owner Address =>: <?php echo $site_account_address; ?> 
                    <p>Position in Bank =>: <?php echo $site_account_position; ?> 
                    
                    
                                        <form class="">
                                           
                                            <div class="position-relative form-group"><label for="exampleAddress" class="">Choose Deposit Method</label>
                                             <select name ="rbname" class="form-control" required>            
                                                        <option value="">Select Deposit Method</option>
                                                        <option value="Cash Payment">Cash Deposit</option>
                                                        <option value="Western Union">Western Union Transfer</option>
                                                        <option value="Bank Cheque">Bank Cheque</option>
                                                        <option value="Wire Transfer">Wire Transfer</option>
                                                       
                                                        
 
                    				</select> 
                                            </div>
                                            
                                            
                                            <div class="position-relative form-group"><label for="exampleAddress2" class="">Receiving Institution</label>
                                          <select name ="rbname" class="form-control" required >            
                                                        <option value="">Select Receiving Institution</option>
                                                        <option value="DSTV">TV Subscription</option>
                                                        <option value="Electricity Bills">Electricity Bills</option>
                                                        <option value="House Rent">Hosue Rent Renewal</option>
                                                        <option value="Tax Payment and Revenue">Tax Payment and Revenue</option>
                                                        <option value="Tuition Fee">Tuition Fee</option>
                                                        <option value="Flight Booking Charges">Flight Booking Charges</option>
                                                        <option value="Loan Repayment">Loan Repayment</option>
                                                        
 
                    				</select> 
                                            </div>
                                            
                                             <div class="position-relative form-group"><label for="exampleAddress2" class="">Amount to Deposit (<?php echo $_SESSION['hlbank_user']['currency'] ?>):</label>
                                    <input  name="amt" class="form-control"  id="amt" Placeholder="Amount to deposit" required>
                                            </div>
                                           
                                            
                                            
                                            <button name="submitButton" id="submitButton" type="submit" class="mt-2 btn btn-primary">
                                                
                                                <i class='fab fa-cc-amazon-pay' style='font-size:23px;color:gold'></i>
                                                Send Application</button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
	                      
 							
			 

