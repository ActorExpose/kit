 
<link href="<?php echo WEB_ROOT; ?>library/spry/passwordvalidation/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/passwordvalidation/SpryValidationPassword.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/confirmvalidation/SpryValidationConfirm.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/confirmvalidation/SpryValidationConfirm.js" type="text/javascript"></script>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>



<ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span>  <i class='fas fa-fingerprint' style='font-size:20px;color:gold'></i>  Modify Your Transaction PIN Number</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Disabled in the Demo Version</h5>
                                        
                                      
               
                 <form action=" " method="post">
                     
                     	  <input type="hidden"   value="<?php echo $_SESSION['hlbank_user_name'];  ?>" disabled="disabled" />
							<input type="hidden" name="id" value="<?php echo $_SESSION['hlbank_user']['user_id'];?>" /> 
						  <input type="hidden"   value="<?php echo $_SESSION['hlbank_user']['acc_no'] ?>" disabled="disabled"/>
                          
                                           
                                            <div class="position-relative form-group"><label for="exampleAddress" class="">New Transaction PIN</label>
                                             <span id="sprytf_pin">
						  <input type="text" class="form-control" style="height:40px; background-color:white;"  name="pin"/>
						  <br/>
            <span class="textfieldRequiredMsg">required.</span>
			<span class="textfieldMinCharsMsg">min of 4 digits.</span>
			<span class="textfieldMaxCharsMsg">max of 6 digits.</span>
			<span class="textfieldInvalidFormatMsg">must be Integer.</span>
		</span>
                                            
                                            </div>
                                            
                                            
                                            <div class="position-relative form-group"><label for="exampleAddress2" class="">Repeat New Transaction PIN</label>
                                             <span id="sprytf_cpin" >
						  <input type="text"  name="cpin" class="form-control" style="height:40px; background-color:white; "   />
						  <br/>
           	<span class="confirmRequiredMsg">Confirm PIN required.</span>
			<span class="textfieldRequiredMsg">Account Pin required.</span>
			<span class="confirmInvalidMsg">values don't match</span>
		</span>
                                            </div>
                                           
                                            
                                            
                                            <button name="submitButton" type="submit"  id="submitButton" class="mt-2 btn btn-primary">
                                                <i class='fas fa-fingerprint' style='font-size:48px;color:gold'></i> </button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
	                      
 





  
<script type="text/javascript">
<!--
var spry_pin = new Spry.Widget.ValidationTextField("sprytf_pin", 'integer', {minChars:4, maxChars: 6, validateOn:["blur", "change"]});
//Confirm Password
var spry_cpin = new Spry.Widget.ValidationConfirm("sprytf_cpin", "sprytf_pin", {minChars:4, maxChars: 6, validateOn:["blur", "change"]});
//-->
</script>