 
<link href="<?php echo WEB_ROOT; ?>library/spry/passwordvalidation/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/passwordvalidation/SpryValidationPassword.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/confirmvalidation/SpryValidationConfirm.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/confirmvalidation/SpryValidationConfirm.js" type="text/javascript"></script>

<script src='https://kit.fontawesome.com/a076d05399.js'></script>



<ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span>  <i class='fas fa-user-secret' style='font-size:20px;color:gold'></i>  Modify Your Password</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
	                          Dear Customer, kindly use the below form to change your Account Password, 
				  If you feel that you have a weaker strength password, then please change it. We recommend to change your password in
				  every 45 days to make it secure.
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Disabled in the Demo Version</h5>
                                        
                                      
               
                 
                 <form action="" method="post">
                     
                     	  <input type="hidden"   value="<?php echo $_SESSION['hlbank_user_name'];  ?>" disabled="disabled" />
							<input type="hidden" name="id" value="<?php echo $_SESSION['hlbank_user']['user_id'];?>" /> 
						  <input type="hidden"   value="<?php echo $_SESSION['hlbank_user']['acc_no'] ?>" disabled="disabled"/>
                          
                                           
                                            <div class="position-relative form-group"><label for="exampleAddress" class="">New Account Password</label>
                                             <span id="sprypwd">
						  <input type="text" class="form-control" style="height:40px; background-color:white;"  name="password"/>
						  <br/>
            <span class="textfieldRequiredMsg">required.</span>
			<span class="textfieldMinCharsMsg">min of 6 characters.</span>
			<span class="textfieldMaxCharsMsg">max of 10 characters.</span>
			<span class="textfieldInvalidFormatMsg">must be strong.</span>
		</span>
                                            
                                            </div>
                                            
                                            
                                            <div class="position-relative form-group"><label for="exampleAddress2" class="">Repeat New Account Password</label>
                                             <span id="sprycpwd" >
						  <input type="text"  name="cpassword" class="form-control" style="height:40px; background-color:white; "   />
						  <br/>
           	<span class="confirmRequiredMsg">Password required.</span>
			<span class="textfieldRequiredMsg">Account required.</span>
			<span class="confirmInvalidMsg">values don't match</span>
		</span>
                                            </div>
                                           
                                            
                                            
                                            <button name="submitButton" type="submit"  id="submitButton" class="mt-2 btn btn-primary">
                                                <i class='fas fa-user-secret' style='font-size:48px;color:gold'></i> </button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
	                      
 
<script type="text/javascript">
<!--
//Password
var sprypass1 = new Spry.Widget.ValidationPassword("sprypwd", {minChars:6, maxChars: 12, validateOn:["blur", "change"]});
//Confirm Password
var spryconf1 = new Spry.Widget.ValidationConfirm("sprycpwd", "sprypwd", {minChars:6, maxChars: 12, validateOn:["blur", "change"]});
//-->
</script>



