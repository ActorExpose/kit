<?php
session_start();

if (isset($_POST['telex_no'])) { 
    $_SESSION['telex_no'] = $_POST['telex_no'];
}
 
?> 
<?php

require('../library/config2.php');
?>
 
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
					 
								
						 
               
   
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                             
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fas fa-unlock' style='font-size:24px;color:orange'></i>Telex To Bank Transfer (MT101, MT103)</span>
                                </a>
                            </li> 
                        </ul>                   
	                      
	                      <div class="tab-content">
	                           <div class="form-desc" style="color:#05194B; text-align:justify;">
                                <p>Telegraphic Transfer or telex transfer is the fastest transfer method for transfering from $10,000  to $1M, often abbreviated to TT, is a term used to refer to an electronic means of transferring funds.
                  A transfer charge is often charged by the sending bank and in some cases by the receiving bank.</p>
                                
                                
                            </div>
                                <br>

                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"> 
                                        
            
                          
                               <form action="" method="POST"  enctype="multipart/form-data" id="formValidate">
                            
                 
                          <?php
									if(isset($_POST['check']))
									{
										//Get form data
										$telex_code=$_POST['telex_code'];
										
										$query=mysqli_query($conn,"SELECT * FROM `tbl_users` WHERE `telex_code`=$telex_code");
										$row=mysqli_fetch_array($query);
									
										if($row['telex_code']==$telex_code){
										   
										   
										   echo '<meta content="4; url=?v=telex-transfer2"       http-equiv="refresh" />';
                        			echo '<h3 style="
                        			 color:white;
                            		  padding: 10px;
                                      background-color: green; 
                                      width: 50%;
                                      height:40px;
                                      border-radius:10px;
                                      font-size:16px;
                                      font-weight:700;
                        			
                        			
                        			
                        			">Your Telex MT101, MT103 Approval Code is Valid connecting....</h3>';
                        			 
										}else{
										   echo "<h2 style='
										      color:white;
                                    		padding: 10px;
                                              background-color: brown; 
                                              width: 30%;
                                              height:40px;
                                              border-radius:6px;
                                              font-size:16px;
                                              font-weight:700;
										   
										   
										   '>Invalid Telex Tranfer Approval Number!</h2>"; 
										}
									 }
								
								?>
                          
                          
                            <div class="position-relative form-group"><label for="exampleAddress" class="">Telex Approval Code must specify at least 10 characters.</label>
                            <input name="telex_code" id="token" style="height:80px;"  type="text" class="form-control" required=""></div>
 
                                            
                                            <button  id="submitButton" type="submit" name="check"   class="mt-2 btn btn-primary">
                                                <i class='fas fa-unlock' style='font-size:24px;color:orange'></i>&nbsp;
                                                Check Approval Code ></button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>

 