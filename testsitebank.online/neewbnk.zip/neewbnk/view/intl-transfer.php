<?php
session_start();



if(isset($_SESSION[rbname]))
unset($_SESSION[rbname]);

if(isset($_SESSION[accno]))
unset($_SESSION[accno]);

if(isset($_SESSION[bname]))
unset($_SESSION[bname]);

if(isset($_SESSION[bemailadd]))
unset($_SESSION[bemailadd]);

if(isset($_SESSION[rcountry]))
unset($_SESSION[rcountry]);

if(isset($_SESSION[rstate]))
unset($_SESSION[rstate]);

if(isset($_SESSION[dot]))
unset($_SESSION[dot]);

if(isset($_SESSION[swift]))
unset($_SESSION[swift]);

if(isset($_SESSION[amt]))
unset($_SESSION[amt]);

if(isset($_SESSION[desc]))
unset($_SESSION[desc]);

if(isset($_SESSION[toption]))
unset($_SESSION[toption]);

if(isset($_SESSION[saccno]))
unset($_SESSION[saccno]);
 
?> 
 
<?php 

$errorMessage = (isset($_GET['msg']) && $_GET['msg'] != '') ? $_GET['msg'] : '&nbsp;';
$msgMessage = (isset($_GET['success']) && $_GET['success'] != '') ? $_GET['success'] : '&nbsp;';
?>


                           
                        
<link href="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.js" type="text/javascript"></script>

<script src="<?php echo WEB_ROOT; ?>admin/library/jquery.min.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/textareavalidation/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textareavalidation/SpryValidationTextarea.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/selectvalidation/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/selectvalidation/SpryValidationSelect.js" type="text/javascript"></script>

<div id="errorCls" style="color:#FF0000 !important;font-size:14px;font-weight:bold;"><?php echo $errorMessage; ?></div> 
 
						
						<script src='https://kit.fontawesome.com/a076d05399.js'></script>
					 
								
						 
               
   
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                             
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fas fa-globe' style='font-size:24px;color:orange'></i> International Money Transfer</span>
                                </a>
                            </li> 
                        </ul>                   
	                      
	                      <div class="tab-content">
	                           <div class="form-desc" style="color:#05194B; text-align:justify;">
                                The <?php echo $site_title; ?> International Money Transfer (IMT) is designed to enable both <?php echo $site_initial; ?> account holders
                                and non-account holders 
                                send and receive 
                                funds to and from any <?php echo $site_initial; ?> subsidiary in America, Europe, Asia and West Africa. In line with a directive by the 
                                International Money Funds and US Department of States,
                                recipients of funds through <?php echo $site_initial; ?> in United States
                                must either be <?php echo $site_initial; ?> account holders or must be identified by a <?php echo $site_initial; ?> account holder.
                                
                            </div>
                                <br>

                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Please ensure all fields are completed</h5>
                                        <form class="" action="<?php echo WEB_ROOT; ?>view/?v=cot" method="POST"  enctype="multipart/form-data">
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Receiver Bank Name</label>
                                    <input name="rbname" id="exampleEmail11" value="" placeholder="Receiver Bank Name" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Receiver Account Number</label>
                                    <input name="accno" id="examplePassword11" value="" placeholder="Receiver Account Number" type="text"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                             <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Receiver FullName</label>
                                    <input name="bname" id="exampleEmail11" value="" placeholder="Receiver Fullname" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Receiver Email Address</label>
                                    <input name="bemailadd" id="examplePassword11" value="" placeholder="Receiver Email Address" type="email"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                             <div class="form-row">
                                 
                                    <script type= "text/javascript" src="<?php echo WEB_ROOT; ?>assets/Digital_forest_team_bankia_countries.js"></script>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Receiver Country</label>
                                     <select id="country" class="form-control" required="required" name="rcountry"></select>  </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Receiver State</label>
                                       <select class="form-control"  name ="rstate" id ="state" required ></select> </div>
                                </div>
                            </div>
                            
                            
                             <div class="form-row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="exampleEmail11" class="">Swift Code/Routing/IBAN</label>
                                    <input name="swift" id="exampleEmail11" value="" placeholder="Swift Code/Routing/IBAN" type="text" class="form-control" required="required"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="examplePassword11" class="">Amount (<?php echo $_SESSION['hlbank_user']['currency'] ?>):</label>
                                    <input name="amt" id="amt" value="" placeholder="Amount" type="text"  class="form-control" required="required"></div>
                                </div>
                            </div>
                            
                            
                            <div class="position-relative form-group"><label for="exampleAddress" class="">Transaction Naration</label>
                            <input name="desc"  style="height:80px;" id="exampleAddress"  type="text" class="form-control"></div>
                            
                                           
                                <input type="hidden" value="<?php echo date("h:i A d M Y"); ?>" name="dot" > 
                                	<input name="toption" type="hidden" readonly="true" value="IT"  class="form-control"  />
						<input name="saccno" type="hidden" readonly="true" value="<?php echo $_SESSION['hlbank_user']['acc_no'] ?>"  id="saccno" class="form-control"  />
                                            
                                            <button name="submitButton" id="submitButton" type="submit" class="mt-2 btn btn-primary">
                                                <i class='fas fa-globe' style='font-size:24px;color:orange'></i>&nbsp;
                                                Proceed Transfer ></button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
 
  
    
                  
        
            

 <script language="javascript">
	populateCountries("country", "state"); // first parameter is id of country drop-down and second parameter is id of state drop-down
	populateCountries("country2");
	populateCountries("country2");
</script>

<script type="text/javascript">
<!--
var sprytf_rbname = new Spry.Widget.ValidationTextField("sprytf_rbname", 'none', {minChars:6, validateOn:["blur", "change"]});
var sprytf_rname = new Spry.Widget.ValidationTextField("sprytf_rname", 'none', {minChars:6, validateOn:["blur", "change"]});
var sprytf_accno = new Spry.Widget.ValidationTextField("sprytf_accno", 'integer', {minChars:10, maxChars: 15, validateOn:["blur", "change"]});
var sprytf_bemailadd = new Spry.Widget.ValidationTextField("sprytf_bemailadd", 'none', {minChars:6, validateOn:["blur", "change"]});
var sprytf_rcountry = new Spry.Widget.ValidationTextField("sprytf_rcountry", 'none', {minChars:6, validateOn:["blur", "change"]});
var sprytf_rstate = new Spry.Widget.ValidationTextField("sprytf_rstate", 'none', {minChars:6, validateOn:["blur", "change"]});
var sprytf_swift = new Spry.Widget.ValidationTextField("sprytf_swift", 'none', {minChars:10, maxChars: 20, validateOn:["blur", "change"]});
var sprytf_amt = new Spry.Widget.ValidationTextField("sprytf_amt", "none", {validateOn:["blur", "change"]});

var sprytf_opt = new Spry.Widget.ValidationSelect("spryselect_opt");

var sprytf_dot = new Spry.Widget.ValidationTextField("sprytf_dot", "date", {format:"", useCharacterMasking: true, validateOn:["blur", "change"]});
var sprytf_desc = new Spry.Widget.ValidationTextarea("sprytf_desc", {isRequired:true, validateOn:["blur", "change"]});
//-->
</script>

