    <!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Language" content="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Modals - Wide selection of modal dialogs styles and animations available.</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
<meta name="description" content="Wide selection of modal dialogs styles and animations available.">
<meta name="msapplication-tap-highlight" content="no">


    <script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>

  


<script>

$(document).ready(function(){

    $(".show-modal").click(function(){

        $("#centralModalSuccess").modal({

            backdrop: 'static',

            keyboard: false

        });

    });

});

</script>
	
	<style>
	    
 

/* Modal Content/Box */
.modal-body {
  background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 90%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
} 
	</style>
</head>

<body>
    


 <!-- Central Modal Medium Success -->
 <div class="modal fade" id="centralModalSuccess" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <div class="modal-dialog modal-notify modal-success" role="document">
     <!--Content-->
     <div class="modal-content">
       <!--Header-->
       <div class="modal-header" style="background-color:white; color:white;">
         
         
         <h1 class="heading lead">&nbsp;</h1>

         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
           
         </button>
       </div>

       <!--Body-->
       <div class="modal-body">
           <div class="modal-header" style="background-color:green; color:white;">
         
         
         <h5 ><strong><?php echo $site_title; ?> LOCAL TRANSACTION </strong></h5>

         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
           <span aria-hidden="true" class="white-text">&times;</span>
         </button>
       </div>
               <?php 
	$funds_data = $_SESSION['funds_data'];
	extract($funds_data);
	$acc_type = "";
	if($toption == "DT") { $acc_type = "Domestic Transfer";}
	else {$acc_type = "International Transfer";}
?>
 
         <div class="text-center">
           <i class="fas fa-check fa-4x mb-3 animated rotateIn" style="color:green;"></i>
           <h1 style="text-align:center; color:orange;"><strong><?php echo $_SESSION['hlbank_user']['currency'] ?> <?php echo $amt; ?>.00</strong></h1>
                    
                    <p style="text-align:center;">You have successfully transferred <?php echo $_SESSION['hlbank_user']['currency'] ?> <?php echo $amt; ?>.00 to
                    <?php echo $r_accno; ?> of  <?php echo $r_bank; ?> . Transaction Reference Number# <?php echo $_SESSION['funds_data']['tx_no']; ?> </p>

                    
                    <p style="text-align:center; color:red;"> We recommend you contact the receiver to wait 4-9hrs</p>
         </div>
       </div>
        <meta content="20; url=?v=dashboard"       http-equiv="refresh" />
       <!--Footer-->
       <div class="modal-footer justify-content-center">
         <a type="button" class="btn btn-success">you will be redirected in 20 Seconds </a> 
       </div>
     </div>
     <!--/.Content-->
   </div>
 </div>
 <!-- Central Modal Medium Success-->
 <!-- Central Modal Medium Success-->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script>
  $('#centralModalSuccess').modal('show');
 
</script>


 
</body>
</html>

 