 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script src='https://kit.fontawesome.com/a076d05399.js'></script>

  
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span>  <i class='far fa-comment-dots' style='font-size:20px;color:gold'></i>   Get Quick Help</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
	                          
	                           
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Confidential Messaging Application</h5>
                                       	   Customer service is the act of taking care of the customer's needs by providing and delivering professional, 
helpful, high quality service and assistance before, during, and after the customer's requirements are met. Customer service is meeting the
needs and desires of any customer, Use our Internal Messaging Application to Contact our customer's service with easy.
                                       
                                       <br>
                                      
                                      <form action="<?php echo WEB_ROOT; ?>view/process.php?action=support" method="post">
             
                 
                            <input type="hidden" class="form-control"  name="accno" value="<?php echo $_SESSION['hlbank_user']['acc_no'] ?>" disabled/> 
                            <input type="hidden" class="form-control"  name="email"  value="<?php echo $_SESSION['hlbank_user']['email']; ?>"/>
                            <input type="hidden" class="form-control"  name="siteemail"  value="<?php echo $site_email; ?>"/>
                            <input type="hidden" class="form-control"  name="sitetitle"  value="<?php echo $site_title; ?>"/>
                    
                                           <br>
                                            <div class="position-relative form-group"><label for="exampleAddress" class="">Please Select Customer Service Department 
                                            </label>
                                            <select class="form-control"  name="dept"  required="">
                                
                                <option  value="">Please Select Customer Service Department</option>
                                <option  value="Customer Services Department">Customer Services Department</option>
                                <option  value="Account Department">Account Department</option>
                                <option  value="Transfer Department">Transfer Department</option>
                                <option  value="Card Services Department">Card Services Department</option>
                                <option  value="Loan Department">Loan Department</option>
                                <option  value="Bank Deposit Department">Bank Deposit Department</option>
                                
                            </select>
                                            
                                            </div>
                                            
                                            
                                          
                                             <div class="position-relative form-group"><label for="exampleAddress2" class="">Message Body</label>
                                          <textarea class="form-control" rows="5" name="body" placeholder="Enter Message Details Here" required=""></textarea>
                                            </div>
                                           
                                            
                                            
                                            <button type="submit" name="login" class="mt-2 btn btn-primary">
                                               <i class='far fa-comment-dots' style='font-size:20px;color:gold'></i> 
                                                Submit Message</button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
 