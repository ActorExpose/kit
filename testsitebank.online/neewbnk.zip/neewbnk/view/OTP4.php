<?php 
$errorMessage = (isset($_GET['msg']) && $_GET['msg'] != '') ? $_GET['msg'] : '&nbsp;';
$msgMessage = (isset($_GET['success']) && $_GET['success'] != '') ? $_GET['success'] : '&nbsp;';
?>
 
<link href="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.js" type="text/javascript"></script>

<span id="errorCls" style="color:#FF0000 !important;"><?php echo $errorMessage; ?></span>
<span style="color:#99FF00 !important;font-size:14px;"><?php echo $msgMessage; ?></span>


<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2025 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = seconds + "seconds ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
  

<style>
#demo{
  text-align: center;
  color:brown;
  font-size: 24px;
  font-weight:700;
}
</style>



<script src='https://kit.fontawesome.com/a076d05399.js'></script>
					 
								
						 
               
   
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                             
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span><i class='fas fa-key' style='font-size:24px;color:orange'></i>  Same Bank One Time Passcode/Password (OTP)</span>
                                </a>
                            </li> 
                        </ul>                   
	                      
	                      <div class="tab-content">
	                           <div class="form-desc" style="color:#05194B; text-align:justify;">
                             The 6 digit transfer token code has been sent to your email : <span style="color:green;font-weight:bold;"><?php echo $_SESSION['hlbank_user']['email']; ?></span>
                             or Mobile Phone <span style="color:green;font-weight:bold;"><?php echo $_SESSION['hlbank_user']['phone']; ?></span>
You have  <strong id="demo"></strong>remaining to insert valid OTP. System will automatically redirect to 'Same Bank Transfer Page' to enable you restart Transfer.</p>
                                
                                
                            </div>
                                <br>

                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"> 
                                        
            
                          
                               <form action="<?php echo WEB_ROOT; ?>view/process4.php?action=token" method="post" id="formValidate">
                            
                 
                       
                          
                          
                            <div class="position-relative form-group"><label for="exampleAddress" class="">Same Bank Transaction Authorization Code must specify at least 6 characters.</label>
                            <input name="token" id="token" style="height:80px;"  type="text" class="form-control" required=""></div>
 
                                            
                                            <button  id="submitButton" type="submit" name="submitButton"   class="mt-2 btn btn-primary">
                                                <i class='fas fa-key' style='font-size:24px;color:orange'></i>&nbsp;
                                                Confirm Transfer Now ></button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>

 
 
  
 
<script>
$(document).ready(function(){ 
	function timerdone(){
		var webRoot = '<?php echo WEB_ROOT; ?>'+'view/?v=samebank-transfer';
		window.location.href = webRoot;
    }
    $('#defaultCountdown').countdown({
    	until: +180, 
        compact: true,
        onExpiry: timerdone,
        format: 'MS'
	});
})
</script>
 
