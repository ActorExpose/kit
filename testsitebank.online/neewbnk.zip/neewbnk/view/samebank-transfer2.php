<?php
session_start();
?>


<?php 

if (isset($_POST['acc_no'])) { 
    $_SESSION['acc_no'] = $_POST['acc_no'];
}

?> 
 
 
<?php 

$errorMessage = (isset($_GET['msg']) && $_GET['msg'] != '') ? $_GET['msg'] : '&nbsp;';
$msgMessage = (isset($_GET['success']) && $_GET['success'] != '') ? $_GET['success'] : '&nbsp;';
?>


                           
                        
<link href="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.js" type="text/javascript"></script>

<script src="<?php echo WEB_ROOT; ?>admin/library/jquery.min.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/textareavalidation/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textareavalidation/SpryValidationTextarea.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/selectvalidation/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/selectvalidation/SpryValidationSelect.js" type="text/javascript"></script>

<div id="errorCls" style="color:#FF0000 !important;font-size:14px;font-weight:bold;"><?php echo $errorMessage; ?></div>
<div style="color:#99FF00 !important;font-size:14px;font-weight:bold;"><?php echo $msgMessage; ?></div>
 
						
						
					 
								
  
  
	   <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span> <?php echo $site_title; ?> TO  <?php echo $site_title; ?> Transfer Form</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Same Bank Transfer</h5>
                                        <form action="<?php echo WEB_ROOT; ?>view/process4.php?action=transfer" method="post" enctype="multipart/form-data">
                                           
                                            <div class="position-relative form-group"><label for="exampleAddress" class="">Beneficiary Bank Account</label>
                                            <input  id="exampleAddress" readonly name="r_accno" value="<?php   echo $_SESSION['acc_no']  ; ?>" type="text" class="form-control"></div>
                                            
                                            <div class="position-relative form-group"><label for="exampleAddress2" class="">Amount to Transfer (<?php echo $_SESSION['hlbank_user']['currency'] ?>):</label>
                                            <input name="amt" id="exampleAddress2" value="" placeholder="500" type="text" class="form-control" required>
                                            </div>
                                            
                                            <div class="position-relative form-group"><label for="exampleAddress2" class="">Transfer Naration</label>
                                            <input name="description" style="height:100px;"  id="exampleAddress2" value="" type="text" class="form-control" required>
                                            </div>
                                           
                                                 <input type="hidden"   name="dot" class="form-control"  id="amt" value="<?php echo date("h:i A d M Y"); ?>"> 
						<input name="toption" type="hidden" readonly="true" value="LT" class="form-control"  />
						<input name="saccno" type="hidden" readonly="true" value="<?php echo $_SESSION['hlbank_user']['acc_no'] ?>"  id="saccno" class="form-control"  />
                                            
                                            <button name="submitButton" id="submitButton" type="submit" class="mt-2 btn btn-primary">Proceed Now</button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
	                      
	                      
	               
 
 
 						 
                  
      
       
                   
                      
   