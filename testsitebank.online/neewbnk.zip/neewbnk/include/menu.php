   <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                        <div class="header__pane ml-auto">
                            <div>
                                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="app-header__mobile-menu">
                        <div>
                            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
                    </div>    <div class="scrollbar-sidebar">
                        <div class="app-sidebar__inner">
                            <ul class="vertical-nav-menu">
                                <li class="app-sidebar__heading">Dashboards</li>
                                <li>
                                    <a href="<?php echo WEB_ROOT; ?>view/?v=dashboard" class="mm-active">
                                       <i class='fas fa-landmark' style='font-size:20px;color:orange'></i>&nbsp;
                                        Main Menu
                                    </a>
                                </li>
                                <li class="app-sidebar__heading">T3stbnk Menu</li>
                                <li >
                                    <a href="#">
                                        <i class='fas fa-hand-holding-usd' style='font-size:20px;color:orange'></i>&nbsp;
                                        My Account Menu
                                        &nbsp;<i class="arrow down"></i>
                                    </a>
                                    <ul >
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=Account">
                                                <i class="metismenu-icon"></i>
                                                Customer Profile
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=nok">
                                                <i class="metismenu-icon">
                                                </i>Next of kin
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=Account">
                                                <i class="metismenu-icon">
                                                </i>Beneficiary List
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=job">
                                                <i class="metismenu-icon">
                                                </i>Job History
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=Summary">
                                                <i class="metismenu-icon">
                                                </i>Account Summary
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=transaction-codes">
                                                <i class="metismenu-icon">
                                                </i>Transaction Codes
                                            </a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                <li >
                                    <a href="#">
                                       <i class='fas fa-money-bill-wave' style='font-size:20px;color:orange'></i>&nbsp;
                                        Money Transfer
                                       &nbsp;<i class="arrow down"></i>
                                    </a>
                                    <ul >
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=intl-transfer">
                                                <i class="metismenu-icon">
                                                </i>Wire Transfer
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=samebank-transfer">
                                                <i class="metismenu-icon">
                                                </i>Same Bank Transfer
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=local-transfer">
                                                <i class="metismenu-icon">
                                                </i>Local Transfer
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=telex-transfer">
                                                <i class="metismenu-icon">
                                                </i>Telex Transfer
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="metismenu-icon">
                                                </i>Swift Transfer
                                            </a>
                                        </li>
                                         
                                         
                                        <li>
                                            <a href="components-scrollable-elements.html">
                                                <i class="metismenu-icon">
                                                </i>
                                            </a>
                                        </li>
                                       
                                    </ul>
                                </li>
								
								
								
								
								
								<li >
                                    <a href="#">
                                         <i class='fas fa-file-invoice-dollar' style='font-size:20px;color:orange'></i>&nbsp;
                                        Account Statement
                                        &nbsp;<i class="arrow down"></i>
                                    </a>
                                    <ul >
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=Statement">
                                                <i class="metismenu-icon">
                                                </i>View E-Estatement
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="metismenu-icon">
                                                </i>Print Statement
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="metismenu-icon">
                                                </i>Get Help on E-Statement
                                            </a>
                                        </li>
                                   
                                       
                                    </ul>
                                </li>
								
								<li >
                                    <a href="#">
                                         <i class='fas fa-piggy-bank' style='font-size:20px;color:orange'></i>&nbsp;
                                        Loan & Mortage
                                        &nbsp;<i class="arrow down"></i>
                                    </a>
                                    <ul >
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=apply-loan">
                                                <i class="metismenu-icon">
                                                </i>Request Loan
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=loan-menu">
                                                <i class="metismenu-icon">
                                                </i>Loan Status
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="metismenu-icon">
                                                </i>My Apporved Loan
                                            </a>
                                        </li>
                                   
                                       
                                    </ul>
                                </li>
									<li class="app-sidebar__heading">ATM Card</li>
								<li >
                                    <a href="#">
                                       <i class='fas fa-money-check-alt' style='font-size:20px;color:orange'></i>&nbsp;
                                        My Bank Card
                                        &nbsp;<i class="arrow down"></i>
                                    </a>
                                    <ul >
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=request-card">
                                                <i class="metismenu-icon">
                                                </i>Request Credit/Debit Card
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=card">
                                                <i class="metismenu-icon">
                                                </i>My Card Status
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=card">
                                                <i class="metismenu-icon">
                                                </i>My Apporved Cards
                                            </a>
                                        </li>
                                   
                                       
                                    </ul>
                                </li>
									<li class="app-sidebar__heading">Support</li>
								<li >
                                    <a href="#">
                                        <i class='fas fa-user-graduate' style='font-size:20px;color:orange'></i>&nbsp;
                                        Customer Support
                                        &nbsp;<i class="arrow down"></i>
                                    </a>
                                    <ul >
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=support">
                                                <i class="metismenu-icon">
                                                </i>Contact Customer Services
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="metismenu-icon">
                                                </i>View Ticket
                                            </a>
                                        </li>
										<li>
                                            <a href="">
                                                <i class="metismenu-icon">
                                                </i>Open Ticket
                                            </a>
                                        </li>
                                       
                                   
                                       
                                    </ul>
                                </li>
								
								<li><a href="<?php echo WEB_ROOT; ?>view/?v=atm-location">
                                           <i class='fas fa-user-cog' style='font-size:20px;color:orange'></i>&nbsp;
                                        Our ATM Location 
                                    </a>
								</li>
								<li><a href="<?php echo WEB_ROOT; ?>view/?v=deposit-funds">
                                           <i class='fas fa-user-cog' style='font-size:20px;color:orange'></i>&nbsp;
                                        Make Deposit
                                    </a>
								</li>
								<li><a href="<?php echo WEB_ROOT; ?>view/?v=pay-bills">
                                           <i class='fas fa-user-cog' style='font-size:20px;color:orange'></i>&nbsp;
                                        Pay Utility Bills
                                    </a>
								</li>
								
									<li class="app-sidebar__heading">Settings</li>
								<li >
                                    <a href="#">
                                           <i class='fas fa-user-cog' style='font-size:20px;color:orange'></i>&nbsp;
                                        Account Settings
                                        &nbsp;<i class="arrow down"></i>
                                    </a>
                                    <ul >
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=ChangePin">
                                                <i class="metismenu-icon">
                                                </i>Change Transaction PIN
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=ChangePwd">
                                                <i class="metismenu-icon">
                                                </i>Change Account Password
                                            </a>
                                        </li>
										<li>
                                            <a href="<?php echo WEB_ROOT; ?>view/?v=security_question">
                                                <i class="metismenu-icon">
                                                </i>My Security Questions
                                            </a>
                                        </li>
                                       
                                   
                                       
                                    </ul>
                                </li>
								 
                                <li  >
                                    <a href="<?php echo WEB_ROOT; ?>?logout">
                                      <i class='fas fa-power-off' style='font-size:20px;color:orange'></i>&nbsp;
                                        Logout
                                    </a>
                                </li>
                                
                                 
                            </ul>
                        </div>
                    </div>
                </div> 