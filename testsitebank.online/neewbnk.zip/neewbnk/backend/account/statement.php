<?php
if (!defined('WEB_ROOT')) {
	exit;
}

if (isset($_GET['accNo']) && $_GET['accNo'] > 0) {
	$acc_no = $_GET['accNo'];
} else {
	header('Location: index.php');
}

$sql = "SELECT * FROM tbl_transaction WHERE to_accno = $acc_no ORDER BY id DESC LIMIT 200";
$result = dbQuery($sql);

?> 

<div class="row">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-header" > <a href="" class="badge badge-warning"><?php echo $acc_no; ?>  Account Statement</a>
                                        <div class="btn-actions-pane-right">
                                            <div role="group" class="btn-group-sm btn-group">
                                                <button class="active btn btn-focus">Last Week</button>
                                                <button class="btn btn-focus">All Month</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        
                                          <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                                            <thead>
                                        
                                            <tr>
                                                
                                                <th>DATE</th>
                                                <th class="text-center">REFERENCE NO</th>
                                                <th class="text-center">TYPE</th>
                                                <th class="text-center">CURRENCY</th>
                                                <th class="text-center">AMOUNT</th>
                                                <th class="text-center">NARATION</th>
                                                <th class="text-center">SENDER</th>
                                                <th class="text-center">RECEIVER A/C</th>
                                                <th class="text-center">NOTE</th>
                                                <th class="text-center">STATUS</th>
                                             </tr>
                                            </thead>
                                            
                                              
                                            
                                            <tbody>
          <?php
if(dbNumRows($result) > 0) {
while($row = dbFetchAssoc($result)) {
	extract($row);
	if ($i%2) {$class = 'row1';}
	else {$class = 'row2';}
	$i += 1;
?>
					  <tr class="<?php echo $class; ?>"> 
                        <td class="badge badge-danger"><?php echo $date; ?></td>
                        <td class="text-center text-muted"><?php echo $tx_no; ?></td> 
                        <td class="text-center text-muted"><?php echo $tx_type; ?></td>
                        <td class="text-center text-muted"><?php echo $currency; ?></td>
                        <td class="badge badge-warning"><?php echo $amount; ?></td>
                        <td class="text-center text-muted"><?php echo $description; ?></td>
                        <td class="text-center text-muted"><?php echo $s_accno; ?></td>
                        <td class="text-center text-muted"><?php echo $r_accno; ?></td>
                        <td class="text-center text-muted"><?php echo $comments; ?></td>
                        <td class="badge badge-success"><?php echo $status; ?>'</td>
                                                    
                                                
                    </tr>
                    			 <?php
}// end while
?>
                    	</table>
                    	
                    	      
                            </div>
                        </div>
                    </div>
                    </div>



<?php 
}//
else {
?> 


			
			 
                                        
                                      
                  
                
                
                   

<?php 
}//else
?>
