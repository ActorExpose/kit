<?php
if (!defined('WEB_ROOT')) {
	exit;
}

if (isset($_GET['userId']) && (int)$_GET['userId'] > 0) {
	$userId = (int)$_GET['userId'];
} else {
	header('Location: index.php');
}

$errorMessage = (isset($_GET['error']) && $_GET['error'] != '') ? $_GET['error'] : '&nbsp;';

$sql = "SELECT id, fname, lname, email FROM tbl_users
        WHERE id = $userId";
$result = dbQuery($sql);		
extract(dbFetchAssoc($result));

?> 


                         <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span>Change Customer Email Address</span>
                                </a>
                            </li>
                           
                        </ul>                   
	                      
	                      <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Edit Customer Email ID</h5>
                                    
                                    <p class="errorMessage"><?php echo $errorMessage; ?></p>
                                       
                                       <form action="processUser.php?action=email" method="post" >
                                           
                                <div class="position-relative form-group"><label for="exampleAddress" class="">Username/Fullname</label>
                                <input name="txtUserName" id="exampleAddress" value="<?php echo $fname. ' '.$lname; ?>" type="text"  readonly="readonly" class="form-control"> 
                                    <input name="hidUserId" type="hidden" id="hidUserId" value="<?php echo $id; ?>"> </td>
                                
                                </div>
                               
                               
                               
                                <div class="position-relative form-group"><label for="exampleAddress2" class="">Old Email Address</label>
                                <input name="old_email" id="exampleAddress2" value="<?php echo $email; ?>" type="text" class="form-control" readonly="readonly">
                                </div>
                                
                                <div class="position-relative form-group"><label for="exampleAddress2" class="">New Email Address</label>
                                <input name="new_email" id="exampleAddress2"  type="text" class="form-control" required>
                                </div>
                                           
                                            
                                            
                                            <button name="btnModifyUser"   id="btnModifyUser" type="submit" class="mt-2 btn btn-primary">Modify Email ID</button>
                                            
                                              <button name="btnCancel" id="btnCancel" onClick="window.location.href='index.php';" class="mt-2 btn btn-primary">Cancel</button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>





 