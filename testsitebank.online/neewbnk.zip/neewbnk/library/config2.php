<?php
 
// second database connection	//  This are my database constants for bank pro

define("DB_SERVER","localhost");
define("DB_USER","natiojad_mi");
define("DB_NAME","natiojad_mi");
define("DB_PASS","2020money@L");
$conn=mysqli_connect(DB_SERVER, DB_USER, DB_PASS);
if(!$conn){
  #echo "<h1>Server connection is successful!</h1><br>";
}
$db=mysqli_select_db($conn,DB_NAME);
 if(!$db){
   echo '<meta content=0.000001;../customer_login.php http-equiv="refresh" />';
}


// Third Databse connection //  This are my database constants for bank pro
 $host = "localhost";
$database = "natiojad_mi";
$username = "natiojad_mi";
$password = "2020money@L";


?>