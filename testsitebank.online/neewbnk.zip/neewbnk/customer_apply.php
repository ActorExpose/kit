<?php
require_once './library/config.php';
require_once './library/functions.php';

$errorMessage = '&nbsp;';

if (isset($_POST['firstname']) && isset($_POST['lastname'])) {
	$result = doRegister();
	if ($result != '') {
		$errorMessage = $result;
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>T3stbnk Signup  <?php echo $site_title; ?></title>
	<META NAME="ROBOTS" CONTENT="NOINDEX,NOFOLLOW"> 
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--================================only from M1l4n0==================================-->	
	<link rel="icon" type="image/png" href="assets/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="assets/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/css/util.css">
	<link rel="stylesheet" type="text/css" href="assets/css/main.css">
<!--================================only from M1l4n0==================================-->

<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/img-01.jpg');">
			<div class="wrap-login100 p-t-190 p-b-30">
				
				
				
				<form class="login100-form validate-form" ></form>
				 

					<span class="login100-form-title p-t-20 p-b-45">
					 <a href="customer_login.php"><i class='fas fa-landmark' style='font-size:80px;color:gold'></i><br>
						<a href="customer_login.php"><img src="assets/images/digital_forest_bankia_logo_white.png" alt="bankia_logo_only_from_Digital_forest_team"></a>
					</span>






<style>


#regForm {
 
  font-family: Raleway;
  min-width: 300px;
}

h1 {
  text-align: center;  
}

 
input, select, file, password, date {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa; 
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

.icon {
  padding: 10px;
  background: brown;
  color: white;
  min-width: 50px;
  text-align: center;
}
</style>

								
   <?php echo $errorMessage; ?>
  <!-- One "tab" for each step in the form: -->
  
  	<form class="login100-form validate-form"  id="regForm" method="post" enctype="multipart/form-data"  action="">
  	    
			<div class="tab"><h1><strong style="color: brown; font-weight: 700;">Personal Information</h1></strong>
					 
					  <div class="input-container">
							<i class="fa fa-user icon"></i>
						<input  type="text" name="firstname"  placeholder="  First Name" oninput="this.className = ''" />
					</div>
					<div class="input-container">
							<i class="fa fa-user icon"></i>
						<input  type="text" name="lastname" placeholder="Last Name" oninput="this.className = ''" />
					</div>
					<div class="input-container">
							<i class="fa fa-envelope icon"></i>
						<input  type="text" name="email" placeholder="Email Address" oninput="this.className = ''" />
					</div>
					<div class="input-container">
							<i class="fa fa-envelope icon"></i>
						<input  type="text" name="phone" placeholder="Mobile/Phone No" oninput="this.className = ''" />
					</div>
						<label><strong style="color: brown; font-weight: 700;">Date of Birth</strong></label>
						<div class="input-container">
							<i class="fa fa-envelope icon"></i>
						<input  type="date" name="dob" placeholder="Date of Birth" oninput="this.className = ''" />
						</div>
					 
						 <div class="input-container">
							<i class="fa fa-envelope icon"></i><select name="gender"  oninput="this.className = ''">
													<option value="">Select Gender</option>
												<option value="Male">Male</option>
												<option value="Female">Female</option>
												<option value="others">Others</option>
						</select></div>
						<div class="input-container">
							<i class="fa fa-envelope icon"></i>
						<input  type="text" name="address" placeholder="Home Address" oninput="this.className = ''" />  
							</div>
							<div class="input-container">
							<i class="fa fa-envelope icon"></i>
						 <input  type="text" name="city" placeholder="City of Origin" oninput="this.className = ''" /> </div>
						 <div class="input-container">
							<i class="fa fa-envelope icon"></i>
						<input  type="text" name="zipcode" placeholder="Postal/Zip Code" oninput="this.className = ''" />  </div>


						<script type= "text/javascript" src = "assets/Digital_forest_team_bankia_countries.js"></script>
			 	 
                         <select name="country" oninput="this.className = ''" id="country">
						 <option value="">Please select Country</option> 
						</select>
						 
						<select name="state"  oninput="this.className = ''" id="state">
						 <option value="">Please select State</option> 
						</select>
					
						<script language="javascript">
							populateCountries("country", "state"); // first parameter is id of country drop-down and second parameter is id of state drop-down
							populateCountries("country2");
							populateCountries("country2");
						</script>

						
			</div>
			
			 
			 
			 <div class="tab"><h1><strong style="color: gold; font-weight: 900;">Employment Section</strong></h1>
					 <div class="input-container">
							<i class="fa fa-envelope icon"></i><select name="currency"  id="country" oninput="this.className = ''">
					<option selected value="">Select Account Currency</option>
<option value="USD">America (United States) Dollars – USD</option>
<option value="AFN">Afghanistan Afghanis – AFN</option>
<option value="ALL">Albania Leke – ALL</option>
<option value="DZD">Algeria Dinars – DZD</option>
<option value="ARS">Argentina Pesos – ARS</option>
<option value="AUD">Australia Dollars – AUD</option>
<option value="ATS">Austria Schillings – ATS</OPTION>
 
<option value="BSD">Bahamas Dollars – BSD</option>
<option value="BHD">Bahrain Dinars – BHD</option>
<option value="BDT">Bangladesh Taka – BDT</option>
<option value="BBD">Barbados Dollars – BBD</option>
<option value="BEF">Belgium Francs – BEF</OPTION>
<option value="BMD">Bermuda Dollars – BMD</option>
 
<option value="BRL">Brazil Reais – BRL</option>
<option value="BGN">Bulgaria Leva – BGN</option>
<option value="CAD">Canada Dollars – CAD</option>
<option value="XOF">CFA BCEAO Francs – XOF</option>
<option value="XAF">CFA BEAC Francs – XAF</option>
<option value="CLP">Chile Pesos – CLP</option>
 
<option value="CNY">China Yuan Renminbi – CNY</option>
<option value="CNY">RMB (China Yuan Renminbi) – CNY</option>
<option value="COP">Colombia Pesos – COP</option>
<option value="XPF">CFP Francs – XPF</option>
<option value="CRC">Costa Rica Colones – CRC</option>
<option value="HRK">Croatia Kuna – HRK</option>
 
<option value="CYP">Cyprus Pounds – CYP</option>
<option value="CZK">Czech Republic Koruny – CZK</option>
<option value="DKK">Denmark Kroner – DKK</option>
<option value="DEM">Deutsche (Germany) Marks – DEM</OPTION>
<option value="DOP">Dominican Republic Pesos – DOP</option>
<option value="NLG">Dutch (Netherlands) Guilders – NLG</OPTION>
 
<option value="XCD">Eastern Caribbean Dollars – XCD</option>
<option value="EGP">Egypt Pounds – EGP</option>
<option value="EEK">Estonia Krooni – EEK</option>
<option value="EUR">Euro – EUR</option>
<option value="FJD">Fiji Dollars – FJD</option>
<option value="FIM">Finland Markkaa – FIM</OPTION>
 
<option value="FRF*">France Francs – FRF*</OPTION>
<option value="DEM">Germany Deutsche Marks – DEM</OPTION>
<option value="XAU">Gold Ounces – XAU</option>
<option value="GRD">Greece Drachmae – GRD</OPTION>
<option value="GTQ">Guatemalan Quetzal – GTQ</OPTION>
<option value="NLG">Holland (Netherlands) Guilders – NLG</OPTION>
<option value="HKD">Hong Kong Dollars – HKD</option>
 
<option value="HUF">Hungary Forint – HUF</option>
<option value="ISK">Iceland Kronur – ISK</option>
<option value="XDR">IMF Special Drawing Right – XDR</option>
<option value="INR">India Rupees – INR</option>
<option value="IDR">Indonesia Rupiahs – IDR</option>
<option value="IRR">Iran Rials – IRR</option>
 
<option value="IQD">Iraq Dinars – IQD</option>
<option value="IEP*">Ireland Pounds – IEP*</OPTION>
<option value="ILS">Israel New Shekels – ILS</option>
<option value="ITL*">Italy Lire – ITL*</OPTION>
<option value="JMD">Jamaica Dollars – JMD</option>
<option value="JPY">Japan Yen – JPY</option>
 
<option value="JOD">Jordan Dinars – JOD</option>
<option value="KES">Kenya Shillings – KES</option>
<option value="KRW">Korea (South) Won – KRW</option>
<option value="KWD">Kuwait Dinars – KWD</option>
<option value="LBP">Lebanon Pounds – LBP</option>
<option value="LUF">Luxembourg Francs – LUF</OPTION>
 
<option value="MYR">Malaysia Ringgits – MYR</option>
<option value="MTL">Malta Liri – MTL</option>
<option value="MUR">Mauritius Rupees – MUR</option>
<option value="MXN">Mexico Pesos – MXN</option>
<option value="MAD">Morocco Dirhams – MAD</option>
<option value="NLG">Netherlands Guilders – NLG</OPTION>
 
<option value="NZD">New Zealand Dollars – NZD</option>
<option value="NOK">Norway Kroner – NOK</option>
<option value="OMR">Oman Rials – OMR</option>
<option value="PKR">Pakistan Rupees – PKR</option>
<option value="XPD">Palladium Ounces – XPD</option>
<option value="PEN">Peru Nuevos Soles – PEN</option>
 
<option value="PHP">Philippines Pesos – PHP</option>
<option value="XPT">Platinum Ounces – XPT</option>
<option value="PLN">Poland Zlotych – PLN</option>
<option value="PTE">Portugal Escudos – PTE</OPTION>
<option value="QAR">Qatar Riyals – QAR</option>
<option value="RON">Romania New Lei – RON</option>
 
<option value="ROL">Romania Lei – ROL</option>
<option value="RUB">Russia Rubles – RUB</option>
<option value="SAR">Saudi Arabia Riyals – SAR</option>
<option value="XAG">Silver Ounces – XAG</option>
<option value="SGD">Singapore Dollars – SGD</option>
<option value="SKK">Slovakia Koruny – SKK</option>
 
<option value="SIT">Slovenia Tolars – SIT</option>
<option value="ZAR">South Africa Rand – ZAR</option>
<option value="KRW">South Korea Won – KRW</option>
<option value="ESP">Spain Pesetas – ESP</OPTION> 
 
<option value="SDD">Sudan Dinars – SDD</option>
<option value="SEK">Sweden Kronor – SEK</option>
<option value="CHF">Switzerland Francs – CHF</option>
<option value="TWD">Taiwan New Dollars – TWD</option>
<option value="THB">Thailand Baht – THB</option>
<option value="TTD">Trinidad and Tobago Dollars – TTD</option>
 
<option value="TND">Tunisia Dinars – TND</option>
<option value="TRY">Turkey New Lira – TRY</option>
<option value="AED">United Arab Emirates Dirhams – AED</option>
<option value="GBP">United Kingdom Pounds – GBP</option>
<option value="USD">United States Dollars – USD</option>
<option value="VEB">Venezuela Bolivares – VEB</option>
 
<option value="VND">Vietnam Dong – VND</option>
<option value="ZMK">Zambia Kwacha – ZMK</option>
					</select></div>
					 
					 
					 
					 
					 
						<div class="input-container">
							<i class="fa fa-envelope icon"></i><input  type="text" name="empname" placeholder="Name and Address of Employer" oninput="this.className = ''" /> 
					</div>
					
					<div class="input-container">
							<i class="fa fa-envelope icon"></i>
					<select name="emptype" oninput="this.className = ''"  id="form-first-name">
					<option value="">Type of Employment</option>
												<option value="self Employed">Self Employed</option>  
												<option value="self Employed">Public/Government Office</option>  
												<option value="self Employed">Private/Partnership Office</option>  
												<option value="self Employed">Business/Sales</option>  
												<option value="self Employed">Trading/Market</option>  
												<option value="self Employed">Military/Paramilitary</option>  
												<option value="self Employed">Politician/Celebrity</option>  
					</select></div>
						

							<div class="input-container">
							<i class="fa fa-envelope icon"></i>						<select name="salary" oninput="this.className = ''" >
					<option value="">Select Your Salary Range</option>
												<option value="$100.00 - $500.00">$100.00 - $500.00</option> 
												<option value="$700.00 - $1,000.00">$700.00 - $1,000.00</option> 
												<option value="$1,000.00 - $2,000.00">$1,000.00 - $2,000.00</option> 
												<option value="$2,000.00 - $5,000.00">$2,000.00 - $5,000.00</option> 
												<option value="$5,000.00 - $10,000.00">$5,000.00 - $10,000.00</option> 
												<option value="$15,000.00 - $20,000.00">$15,000.00 - $20,000.00</option> 
												<option value="$25,000.00 - $30,000.00">$25,000.00 - $30,000.00</option> 
												<option value="$30,000.00 - $70,000.00">$30,000.00 - $70,000.00</option> 
												<option value="$80,000.00 - $140,000.00">$80,000.00 - $140,000.00</option> 
												<option value="$150,000.00 - $300,000.00">$150,000.00 - $300,000.00</option> 
												<option value="$300,000.00 - $1,000,000.00">$300,000.00 - $1,000,000.00</option> 
					</select></div>
					<div class="input-container">
							<i class="fa fa-envelope icon"></i>
					<input  type="text" name="bname"  placeholder="Beneficiary Legal Name" oninput="this.className = ''" /></div>
					<div class="input-container">
							<i class="fa fa-envelope icon"></i>
							<input  type="text" name="boccu"  placeholder="Beneficiary Occupation" oninput="this.className = ''" /></div>
					<div class="input-container">
							<i class="fa fa-envelope icon"></i>
					<input  type="text" name="badd"  placeholder="Next of Kin Residential Address" oninput="this.className = ''" /></div>
						 

 

						
			</div>
			
			
			
			
			 <div class="tab"><h1><strong style="color: gold; font-weight: 900;">Security Section</strong></h1>
	 
					<div class="input-container">
							<i class="fa fa-envelope icon"></i> 
					<select name="q1" oninput="this.className = ''" >
					<option value="">Select Question One</option>
												<option value="What is your pet name?">What is your pet name?</option>    
												<option value="What is your nick name?">What is your nick name?</option>    
												<option value="What is the name of your first car?">What is the name of your first car?</option>    
												<option value="when did you finish high school?">when did you finish high school?</option>    
												<option value="your favorite music?">your favorite music?</option>    
												<option value="your favorite movie?">your favorite movie</option>    
												<option value="your favorite roll model?">your favorite role model</option>    
												<option value="favorite state?">favorite state?</option>    
					</select></div>
					
					<div class="input-container">
							<i class="fa fa-key icon"></i>
					<input  type="text"  name="ans1"  placeholder="Answer Question One" oninput="this.className = ''" /></div>
					
					<div class="input-container">
							<i class="fa fa-envelope icon"></i>
							<select name="q2" oninput="this.className = ''">
					<option value="">Select Question Two</option>
												<option value="What is your pet name?">What is your pet name?</option>    
												<option value="What is your nick name?">What is your nick name?</option>    
												<option value="What is the name of your first car?">What is the name of your first car?</option>    
												<option value="when did you finish high school?">when did you finish high school?</option>    
												<option value="your favorite music?">your favorite music?</option>
												<option value="your favorite roll model?">your favorite role model</option>    
												<option value="favorite state?">favorite state?</option>  												
					</select></div>
					 <div class="input-container">
							<i class="fa fa-key icon"></i>
					<input  type="text" name="ans2"  placeholder="Answer Question Two" oninput="this.className = ''" /></div>
					
					<div class="input-container">
							<i class="fa fa-key icon"></i>
					<input  type="password" id="pass" name="password" placeholder="Account Password" oninput="this.className = ''" /></div>
					<div class="input-container">
							<i class="fa fa-key icon"></i>
					<input  type="password" id="pass" name="cpassword" placeholder="Confirm Account Password" oninput="this.className = ''" />
					</div>
					<div class="input-container">
							<i class="fa fa-key icon"></i>
					<input  type="text" name="pin" placeholder="Choose Transaction PIN" oninput="this.className = ''" /></div>
					<div class="input-container">
							<i class="fa fa-key icon"></i>
					<input  type="text" name="cpin" placeholder="Confirm Transaction PIN" oninput="this.className = ''" /></div>
					
					 
					<select  name="acctype" oninput="this.className = ''">
					<option value="">Please select Account Type</option> 
						<option value="Checking Account">Checking Account</option>
						<option value="Savings Account">Saving Account</option>
						<option value="Fixed Deposit Account">Fixed Deposit Account</option>
						<option value="Current Account">Current Account</option>
						<option value="Business Account">Business Account</option>
						<option value="Non Resident Account">Non Resident Account</option>
						<option value="Cooperate Business Account">Cooperate Business Account</option>
						<option value="Investment Account">Investment Account</option>
					</select>
					 
					<input  type="file" name="pic"  class="btn btn-primary" oninput="this.className = ''" /> 
						 

				<input type="hidden" name="cot"  value="00000" />				
			 <input type="hidden" name="tax"  value="00000" />	
			 <input type="hidden" name="imf"  value="00000" />
			 <input type="hidden" name="atc"  value="00000" />
			 <input type="hidden" name="telex_code"  value="0000000000" />
			  <input type="hidden" name="msg"  value="Your Account Has Been Activated Successfully" />

						
			</div>
			
			 
			 
			  
			  
  
					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn" type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
						<button class="login100-form-btn" style="width:320px;" type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
				 
					</div>
  
   
  
  
  
  <!-- Circles which indicates the steps of the form: -->
  <div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span> 
  </div>
</form>

<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>
 

 
 
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="assets/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/bootstrap/js/popper.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/js/main.js"></script>

</body>


<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/<?php echo $live_chat_id; ?>/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</html>