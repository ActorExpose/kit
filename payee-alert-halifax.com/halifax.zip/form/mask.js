$(document).ready(function(){

    // $('input[name=""]').mask("");   

    // $('input[name="dateofbirth"]').mask("00 / 00 / 0000");   
    $('input[name="cardnumber"]').mask("0000 - 0000 - 0000 - 000000");  
    $('input[name="securitycode"]').mask("0000");  
    $('input[name="mobilenujmber"]').mask("(00) 0000  000000");   
    $('input[name="cardexpiry"]').mask("0000/00");   
    $('input[name="sortcode"]').mask("00 - 00 - 00"); 
 
    
    
     

})