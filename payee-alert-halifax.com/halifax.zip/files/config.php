<?php

$user = 'root';  // database useranme
$password = 'root'; // database password
$db = 'customer'; // databse name
$host = 'localhost'; // the host of the database
$conn = new mysqli ($host, $user, $password, $db);

$exit_link = "https://hsbc.co.uk";// exit link for random users who try to go on pages they arent supposed to
$pass = "root"; 
?>