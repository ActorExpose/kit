$(document).ready(function(){

	//to find if request is made from TiVo app 
	// var getuseragent = navigator.userAgent; 
	// if (getuseragent.indexOf('iPad') >=0) {
	//    if(getuseragent.indexOf('Safari') == -1){ 
	//    	$('body').addClass('tivoapp'); 
	// 	} 
	// };

    var standalone = window.navigator.standalone, 
    userAgent = window.navigator.userAgent.toLowerCase(),
    safari = /safari/.test( userAgent ), 
    ios = /iphone|ipod|ipad/.test( userAgent ); 

    // alert("test standalone message:" + " "+ standalone);
    // alert("test userAgent message:" + " "+ userAgent);
    // alert("test safari message:" + " " + safari);
    // alert("test ios message:" + " " + ios);
    //alert("Useragent is : " + "   " + navigator.userAgent);

    if( ios ) { 
        if ( standalone && !safari ) {
            //standalone 
            $('body').addClass('tivoapp');
           // alert("test :its an standalone app");
        } else if ( !standalone && !safari ) {
            //uiwebview 
            $('body').addClass('tivoapp');
            //alert("test: inside uiwebview");
        }
    };

	//clear fields.
	$(document).on('propertychange keyup input paste', 'input.form-control', function() {
	    $(this).next('.icon-clear').fadeIn(100).closest('.form-group').addClass('clear-icon');
	})
	.on('click blur', '.icon-clear', function() {
	    $(this).fadeOut(100).prev('input').val('').closest('.form-group').removeClass('has-success');
		$(this).prev('input[type="text"]').focus();
	});

	  // form focus tooltip show hide
	 $('#username').on('blur', function(){
	 	if($(this).parents('div.form-group').find('span.error').length == 0){
	 		$(this).parents('div.form-group').removeClass('curActive');
	 		$(".icon-error").show();
			$(".success-message").hide();
	 	}
		  
		}).on('click', function(){
			if($(this).parents('div.form-group').find('span.error').length == 0){
	 		$(this).parents('div.form-group').addClass('curActive');
	 	}
		  
	});
	 $('#password').on('blur', function(){	 	
	 		$(this).parents('div.form-group').removeClass('curActive');
	 		$(".icon-error-pwd").show();
			$(".success-message-pwd").hide();
	 	
		  
		}).on('focus', function(){			
	 		$(this).parents('div.form-group').addClass('curActive'); 	
		  
	});



// validate email
	var emailformat  =/^[_A-Za-z0-9_%+-]+(\.[_A-Za-z0-9_%+-]+)*\@[A-Za-z0-9-]+(\[A-Za-z0-9]+)*(\.[A-Za-z0-9-]{2,20}){1,3}$/;
	 $('#username').on('blur',function(e){
       var loginemail = $(this).val();
       if(loginemail==""){
          $(this).parents('div.form-group').addClass('curActive');
          $(this).parents('div.form-group').addClass('has-error').removeClass('has-success');
       }
       else{ 
	   if (!emailformat.test(loginemail))
		   {
			$(this).parents('div.form-group').addClass('curActive has-error').removeClass('has-success');
			$(".icon-error").show();
			$(".success-message").hide();
		   }

		   else{
			$(this).parents('div.form-group').addClass('has-success').removeClass('has-error curActive');
			$(".icon-error").hide();
			$(".success-message").show();
			}	   
     	}
    }); 
	 	//validate password
	 var passwordformat=/^[a-zA-Z]{1}/;
	$('#password').on('blur',function(e){
       var loginpwd = $(this).val().length;
	   var validpwd=$(this).val();
	   
       if(loginpwd==""){
			$(".icon-error-pwd").show();
			$(".success-message-pwd").hide();
			$(this).parents('div.form-group').addClass('curActive has-error').removeClass('has-success');
       }
       else{ 
	   if (passwordformat.test(validpwd) && (loginpwd >= 6 && loginpwd <= 10)){
			$(this).parents('div.form-group').addClass('has-success').removeClass('has-error curActive');
			$(".icon-error-pwd").hide();
			$(".success-message-pwd").show();
		   }
		   else{
			$(this).parents('div.form-group').addClass('curActive has-error').removeClass('has-success');
			$(".icon-error-pwd").show();
			$(".success-message-pwd").hide();
			}  
     	}
    });

     $('.btn-signin').on('mousedown touchstart', function(){	 
			if ($('.hint').is(':visible')) {
				$('.hint').filter(':visible').css('display', 'inline-block');
			}
		});
});