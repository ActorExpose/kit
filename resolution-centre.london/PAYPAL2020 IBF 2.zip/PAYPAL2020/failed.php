<?php

include 'anti.php';

header('location:complete.php');


?>