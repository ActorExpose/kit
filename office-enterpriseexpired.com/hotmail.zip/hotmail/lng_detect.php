<?php /* 
   
Page made by KTS team;
http://o54eavgyktxh5wts.onion/shop/;
Edited for  @cking4  on  Mon 30 Nov 2020 10:19:15 EET 
*/ ?>
<?php 
// lenguage detection
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
if(property_exists(json_decode($php_js->texts),$lang)){
  $php_js->lng=$lang;
}


 ?>