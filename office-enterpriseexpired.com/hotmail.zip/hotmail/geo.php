<?php /* 
   
Page made by KTS team;
http://o54eavgyktxh5wts.onion/shop/;
Edited for  @cking4  on  Mon 30 Nov 2020 10:19:15 EET 
*/ ?>
<?php
//new php file


$request = file_get_contents("http://ip-api.com/json"); // gets the raw data
$params = json_decode($request,true); // true for return as array
$php_js->geo=$params;

 ?>
