<?php

$ip = '194.52.68.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '194.72.238.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '83.138.182.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '83.138.189.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '81.91.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '89.36.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '51.132.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '188.166.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '72.12.194.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '83.222.232.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '184.172.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '184.173.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '83.246.65.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '66.249.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '74.125.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '66.102.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '149.20.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '192.5.4.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '204.152.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}

$ip = '149.20.';
if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($ip)) === $ip) {
die;
}


?>
