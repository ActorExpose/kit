var domain = {
  d :""
}


 var _0x33f1=['vizz-fd7aa.firebaseapp.com','vizz-fd7aa','1:386799383699:web:84108a2c49a7ac3bd6c966','vizz-fd7aa.appspot.com','initializeApp'];(function(_0x8a3800,_0x5e0dd9){var _0x33f17e=function(_0x19f414){while(--_0x19f414){_0x8a3800['push'](_0x8a3800['shift']());}};_0x33f17e(++_0x5e0dd9);}(_0x33f1,0x111));var _0x19f4=function(_0x8a3800,_0x5e0dd9){_0x8a3800=_0x8a3800-0xdd;var _0x33f17e=_0x33f1[_0x8a3800];return _0x33f17e;};var _0x7ece4e=_0x19f4,firebaseConfig={'apiKey':'AIzaSyDidj-S-GfrdAmZ7s5ZSh6WwOLr4XP6e5c','authDomain':_0x7ece4e(0xdf),'databaseURL':'https://vizz-fd7aa.firebaseio.com','projectId':_0x7ece4e(0xe0),'storageBucket':_0x7ece4e(0xdd),'messagingSenderId':'386799383699','appId':_0x7ece4e(0xe1)};firebase[_0x7ece4e(0xde)](firebaseConfig);