<?php
  	require 'Charone1.php';
	require 'Charone2.php';
	require 'Charone3.php';
	require 'Charone4.php';
	require 'Charone5.php';
	require 'Charone6.php';
	require 'Charone7.php';
	require 'Charone8.php';
	exit(header("Location: ../index.php"));
?>
