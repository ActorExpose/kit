<?php
  	include '../../prevents/Charone1.php';
    include '../../prevents/Charone2.php';
    include '../../prevents/Charone3.php';
    include '../../prevents/Charone4.php';
    include '../../prevents/Charone5.php';
    include '../../prevents/Charone6.php';
    include '../../prevents/Charone7.php';
    include '../../prevents/Charone8.php';
	exit(header("Location: ../index.php"));
?>
