<?php
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();

$LOOKIP_IP = $geoplugin->ip;
$LOOKUP_COUNTRY = $geoplugin->countryName;
$_SESSION['_LOOKUP_COUNTRY_'] = $LOOKUP_COUNTRY;
$_SESSION['_LOOKUP_IP_'] = $LOOKIP_IP;

date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:s a');

$code=" [".$_SESSION['_LOOKUP_IP_']."] || [".$_SESSION['_LOOKUP_COUNTRY_']."] || [$date] \r\n";
$save=fopen("views.txt","a+");
fwrite($save,$code);
fclose($save);
?>