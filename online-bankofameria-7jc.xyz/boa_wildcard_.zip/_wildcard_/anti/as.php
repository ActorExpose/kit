<?php

session_start();

//////////////////////////////////////// GET Country & Country CODE ! ////////////////////////////////////////////////
$_SESSION['_LOOKUP_COUNTRY_'] = $_SERVER['REMOTE_ADDR'];
$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$_SESSION['_ip_']));
$LOOKUP_COUNTRY = $IP_LOOKUP->country . "\r\n";
$LOOKUP_CITY    = $IP_LOOKUP->city . "\r\n";
$LOOKUP_REGION  = $IP_LOOKUP->region . "\r\n";
$LOOKUP_STATE   = $IP_LOOKUP->regionName . "\r\n";
$LOOKUP_ZIPCODE = $IP_LOOKUP->zip . "\r\n";
$_SESSION['_LOOKUP_COUNTRY_'] = $LOOKUP_COUNTRY;
$_SESSION['_LOOKUP_CITY_']    = $LOOKUP_CITY;
$_SESSION['_LOOKUP_REGION_']  = $LOOKUP_REGION;
$_SESSION['_LOOKUP_STATE_']   = $LOOKUP_STATE;
$_SESSION['_LOOKUP_ZIPCODE_'] = $LOOKUP_ZIPCODE;

echo $_SESSION['_LOOKUP_COUNTRY_']


?>
