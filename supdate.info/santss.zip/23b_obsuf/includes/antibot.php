<?php
    if ($antibot == 1){

         // Check files
        $get_block_ua = file_get_contents($directory.'/includes/block_ua.txt');
        $block_ua = explode("\n", $get_block_ua);
        $get_block_part = file_get_contents($directory.'/includes/block_part_ua.txt');
        $block_part = explode("\n", $get_block_part);

        $dp2 = strtolower($_SERVER['HTTP_USER_AGENT']);
        foreach ($block_ua as $word2) {
            if (substr_count($dp2, strtolower(trim($word2))) > 0 ) {
                 log_visitors_denied('Antibot', $directory);
                 header("HTTP/1.0 404 Not Found");
                 die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
            }
        }

        $dp3 = strtolower($_SERVER['HTTP_USER_AGENT']);
        foreach ($block_part as $word2) {
            if (substr_count($dp3, strtolower(trim($word2))) > 0  ) {
                 log_visitors_denied('Antibot', $directory);
                 header("HTTP/1.0 404 Not Found");
                 die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
            }
        }

    }


?>