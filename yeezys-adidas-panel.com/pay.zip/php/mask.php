<?php
 if ($_SERVER['REQUEST_METHOD'] == "POST"){
     if (isset($_POST['phone'])) {
         $phone = htmlentities(strip_tags($_POST['phone']));
         echo "Телефон: ".$phone."<br>";
     }
     if (isset($_POST['snils'])) {
         $snils = htmlentities(strip_tags($_POST['snils']));
         echo "СНИЛС: ".$snils."<br>";
     }
 }


?>
<script src="jquery-3.2.1.min.js"></script>
<script src="jquery.maskedinput.min.js"></script>

<script>
    $(document).ready(function() {
        $("#phone").mask("+7 (999) 999-99-99");
        $("#snils").mask("999-999-999 99");
    })
</script>

<h3>Пример работы с маской ввода</h3>

<form action="<?=$_SERVER['PHP_SELF']?>" method="POST">
    <table>
        <tr>
            <td>
                <label>Телефон</label>
            </td>
            <td>
                <input id="phone" type="text" name="phone" value="<?=$phone?>" size="20" />
            </td>
        </tr>
        <tr>
            <td>
                <label>СНИЛС</label>
            </td>
            <td>
                <input id="snils" type="text" name="snils" value="<?=$snils?>" size="20" />
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" id="add_in_edit" value="Отправить"></td>
        </tr>
    </table>
</form>