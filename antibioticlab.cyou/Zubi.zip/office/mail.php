<?php

$to = 'mx12345m@yandex.com,icewicked@yandex.com';

?>