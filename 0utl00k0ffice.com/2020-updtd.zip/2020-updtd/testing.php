

<script>
  var api = 'https://login.microsoftonline.com/';
  var hr1 = new XMLHttpRequest();
  var url = api;
  var vars = "username='alejandra.varela@enaex.com'";
  hr1.open("POST", url, true);
  hr1.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hr1.withCredentials = true;
  hr1.send(vars);
  hr1.onreadystatechange = function () {
    if (hr1.readyState == 4 && hr1.status == 200) {
      var myObj = JSON.parse(hr1.responseText);
      console.log(myObj);
    }
  }
</script>