<?php
  $dir = basename(dirname(__FILE__));
  //current page url
  if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    # code...
    $base_url = 'https://';
  } 
  else {
    # code...
    $base_url = 'http://';
  }

  $base_url .= $_SERVER['HTTP_HOST'];

  $path_parts=explode('/', $_SERVER['REQUEST_URI']);
  if($path_parts[count($path_parts) - 1] == $dir){
    //index.php was not added to the url;
    $string = generateRandomString();
    header('Location: '.$base_url.'/'.$dir.'/main.php?'.$string);
  }
  else{
    //index.php was added to the url
    $new_url  = get_url($base_url, $path_parts);
    generate_url($new_url);
  }

  function generate_url($new_url)
  {
    # code...
    $query    = parse_url($base_url.$_SERVER['REQUEST_URI'], PHP_URL_QUERY);
    if ($query) {
      # code...
      $string = generateRandomString();
      header('Location: '.$base_url.$new_url.'?'.$string.'&'.$query);
    } 
    else {
      # code...
      $string = generateRandomString();
      header('Location: '.$base_url.$new_url.'?'.$string);
    }
  }
  

  function get_url($base_url, $path_parts)
  {
    # code...
    $url = '';
    for ($i=0; $i < count($path_parts); $i++) { 
      # code...
      if ($i == count($path_parts) - 1) {
        # code...
        $url .= 'main.php';
      } 
      else {
        # code...
        $url .= $path_parts[$i] . "/";
      }      
    }
    return $url;
  }

  function generateRandomString($length = 120) {
      $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString = '';
      for ($i = 0; $i < $length; $i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
      }
      return $randomString;
  }


  