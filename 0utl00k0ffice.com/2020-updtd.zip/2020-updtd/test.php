<!DOCTYPE HTML>
<html>
    <head>
        <!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
        <title>404</title>
    </head>

    <body id="Background404">
        <!-- <p>404-Page not found. <a href="http://url.com">Home.</a></p> -->
    <?php
        $dir = './images';
        $fileNames = array();
        if(is_dir($dir)){
            $handle = opendir($dir);
            while(false !== ($file = readdir($handle))){
                if(is_file($dir.'/'.$file) && is_readable($dir.'/'.$file)){
                    $fileNames[] = $file;
                }
            }
            closedir($handle);
            $fileNames = array_reverse($fileNames);
            // print_r($fileNames);
        }
        $totalLength = count($fileNames);
        $randInt = rand(0, $totalLength -1);
        $randFile = $fileNames[$randInt];
        // echo $randFile;
        echo "<style> #Background404{background: url('./images/$randFile');}</style>";
    ?>

    </body>
</html>