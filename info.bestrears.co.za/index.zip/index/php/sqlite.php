<?php
date_default_timezone_set("Africa/Johannesburg");
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('phpliteadmin/results.db');
      }
   }
   $db = new MyDB();
   
   //$dbconnect = mysqli_connect('localhost', 'krqnv13s_result', 'rBh8qJvSE8', 'krqnv13s_result');

function generateRandomString($length = 3, $range) {
    return substr(str_shuffle(str_repeat($range, ceil($length/strlen($range)) )),1,$length);
}