<?php
require_once("load.php");
valid_file("index.php");