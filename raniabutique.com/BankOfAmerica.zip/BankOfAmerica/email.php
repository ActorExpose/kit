<?php

$email = "godgrace1477@yahoo.com"; // PUT UR E-MAIL HERE

?>