<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->session->set_userdata('email', '');
		redirect(md5(time()).md5(time()).md5(time()).md5(time()));
	}

	public function email($em)
	{
		$this->session->set_userdata('email', $em);
		redirect(md5(time()).md5(time()).md5(time()).md5(time()));
	}

	public function main()
	{
		if ($this->session->has_userdata('email')) {
			$data['email'] = $this->session->userdata('email');
		}else{
			$data['email'] = '';
		}
		$this->load->view('home',$data);
	}

}

/* End of file Home.php */
/* Location: ./application/controllers/Home.php */