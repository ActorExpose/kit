<html lang="no" data-hw-app-initialised="true" class="fontawesome-i2svg-active fontawesome-i2svg-complete"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no"><title>Posten.no</title>
	<link rel="stylesheet" href="css/posten.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="shortcut icon" href="./css/favicon.ico" />
   <style type="text/css">.tk-pt-sans{font-family:"pt-sans",sans-serif;}
	.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
  

}
	</style><style type="text/css">@font-face{font-family:pt-sans;src:url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff2"),url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff"),url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("opentype");font-weight:400;font-style:normal;}@font-face{font-family:pt-sans;src:url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff2"),url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff"),url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("opentype");font-weight:700;font-style:normal;}</style>

    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css" media="screen"><link rel="stylesheet" type="text/css" href="./css/main.css">


	

</head><body><div style="display: none;"><svg width="0" height="0" position="absolute"><symbol id="logo-posten" viewBox="0 0 513.71 156.26"><defs><style>.st1-logo-posten{fill:#e32d22}</style></defs><path class="st1-logo-posten" d="M191.9 72.57c-6.66-.13-14.21 1.4-19.46 6v-4.88h-13.06v82.58h14.47v-24.7c4.22 4.48 9.6 5.51 16.38 5.51 24.19 0 26.88-17 26.88-32.13 0-19.84-2.95-32.13-25.21-32.38zm-2.31 51.72c-12.41 0-15.87-3.72-15.87-19.33s3.46-19.59 15.87-19.59c10.76 0 13.06 5 13.06 19.59s-2.3 19.33-13.06 19.33zm62.46-51.72c-10.12 0-17.67 1.79-23 7s-6.66 13.31-6.66 25.21 1.15 20 6.66 25.22 12.92 7.05 23 7.05 17.67-1.8 23-7.05 6.65-13.31 6.65-25.22-1.14-20-6.65-25.21-13.02-7-23-7zm0 51.72c-14 0-15.24-5.38-15.24-19.47s1.28-19.45 15.24-19.45 15.24 5.37 15.24 19.45-1.29 19.47-15.24 19.47zm172.33-51.72c-25.09 0-28.67 14.33-28.67 33 0 18.18 4 31.5 29.06 31.5 11.77 0 27.4-3 27.4-19.72h-14c-.13 7-7.64 7.81-12.89 7.81-12.42 0-15.11-4.22-15.11-14.85h42.76c0-21.74-1.28-37.74-28.55-37.74zm-13.95 26c0-8.32 1.28-14.08 13.95-14.08 13.45 0 14.21 5.12 14.21 14.08zm79.07-26c-8.83 0-14.46 2.81-18.05 6v-4.88h-12.53v62.36h14.46V107c0-10.88-1.15-21.63 14.47-21.63 12.54 0 11.39 5.76 11.39 17.79v32.9h14.47v-34.05c0-13.57 1.03-29.44-24.21-29.44zm-117.74 52.74c-7-.13-7.89-3.69-7.89-8.45V86.19h28.45V73.7h-28.45V53.57h-14.46v20.18h-8.42v12.49h8.42v30.67c0 14 8.31 20.23 22.78 20.23 12.42 0 20.3-4.74 20.3-19.72h-13.14c-.15 3.94-1.05 8.02-7.59 7.89zm-61.14-27c-6.27-.39-10.37-.39-10.11-7.43.12-4.1 1.18-7 13.6-6.66 8.45.26 11.09 2 11.09 8.07h13.3c0-14.85-9-19.46-24.54-19.71-16.64-.26-27.68 3.2-27.94 18.69-.38 19.2 13.95 18.69 27.91 19.45 7.17.39 11.52.52 11.26 7.94-.13 4.48-1.59 7.3-14 6.92-10.24-.26-12.12-2.82-12.12-8.2h-13.31c0 15.36 9.82 19.46 25.57 19.72 16.77.25 28-3.71 28.22-19.08.39-19.98-14.59-18.83-28.93-19.72zM135.87 73.7a35.42 35.42 0 01-70.62 0H0a70.85 70.85 0 00141.59 0z"></path><path d="M65.25 68.03a35.42 35.42 0 0170.62 0h5.72A70.85 70.85 0 000 68.03z" fill="#c1c1c1"></path></symbol></svg></div><div id="tf-layout"><header class="hw-navbar">
      <div class="hw-navbar__content">

        <div class="hw-navbar__top">
          <a href="" class="hw-navbar__logo">
            
            <svg class="hw-navbar__logo-standard" aria-labelledby="Logo" role="img">
              <title id="Logo">Til forsiden</title>
              <use xlink:href="#logo-posten"></use>
          </svg>
          <svg class="hw-navbar__logo-gray" aria-labelledby="Logo-gray" role="img">
              <title id="Logo-gray">Til forsiden</title>
              <use xlink:href="#logo-posten-gray"></use>
          </svg>
      </a>

      <nav class="hw-navbar__menu">
        
        <a class="hw-navbar__item" href="" aria-label="Min side">Min side<svg class="svg-inline--fa fa-user fa-w-14 hw-navbar__icon fa-2x" title="Min side" aria-labelledby="svg-inline--fa-title-4gxJ0Cbp5sVv" data-prefix="far" data-icon="user" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><title id="svg-inline--fa-title-4gxJ0Cbp5sVv">Min side</title><path fill="currentColor" d="M313.6 304c-28.7 0-42.5 16-89.6 16-47.1 0-60.8-16-89.6-16C60.2 304 0 364.2 0 438.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-25.6c0-74.2-60.2-134.4-134.4-134.4zM400 464H48v-25.6c0-47.6 38.8-86.4 86.4-86.4 14.6 0 38.3 16 89.6 16 51.7 0 74.9-16 89.6-16 47.6 0 86.4 38.8 86.4 86.4V464zM224 288c79.5 0 144-64.5 144-144S303.5 0 224 0 80 64.5 80 144s64.5 144 144 144zm0-240c52.9 0 96 43.1 96 96s-43.1 96-96 96-96-43.1-96-96 43.1-96 96-96z"></path></svg><!-- <i class="hw-navbar__icon far fa-user fa-2x" title="Min side"></i> --></a>
        <button class="hw-navbar__menu-button" data-hw-toggle-menu="" aria-label="Meny" data-hw-menu-initialised="true"><!--
          --><span class="hw-navbar__menu-button-label-menu" style="width: 43px;">Meny</span><!--
          --><span class="hw-navbar__menu-button-label-close" style="width: 43px;">Lukk</span><!--
      --><span class="fa-stack hw-navbar__menu-button-toggle">
          <svg class="svg-inline--fa fa-bars fa-w-14 hw-navbar__bars fa-stack-2x" title="NOT_TRANSLATED" aria-labelledby="svg-inline--fa-title-7MZN6QCH8iOa" data-prefix="far" data-icon="bars" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><title id="svg-inline--fa-title-7MZN6QCH8iOa">NOT_TRANSLATED</title><path fill="currentColor" d="M436 124H12c-6.627 0-12-5.373-12-12V80c0-6.627 5.373-12 12-12h424c6.627 0 12 5.373 12 12v32c0 6.627-5.373 12-12 12zm0 160H12c-6.627 0-12-5.373-12-12v-32c0-6.627 5.373-12 12-12h424c6.627 0 12 5.373 12 12v32c0 6.627-5.373 12-12 12zm0 160H12c-6.627 0-12-5.373-12-12v-32c0-6.627 5.373-12 12-12h424c6.627 0 12 5.373 12 12v32c0 6.627-5.373 12-12 12z"></path></svg><!-- <i class="hw-navbar__bars far fa-bars fa-stack-2x" title="NOT_TRANSLATED"></i> -->
          <svg class="svg-inline--fa fa-times fa-w-10 hw-navbar__times fa-stack-2x" title="Lukke meny" aria-labelledby="svg-inline--fa-title-zk618p1B0kvu" data-prefix="far" data-icon="times" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg=""><title id="svg-inline--fa-title-zk618p1B0kvu">Lukke meny</title><path fill="currentColor" d="M207.6 256l107.72-107.72c6.23-6.23 6.23-16.34 0-22.58l-25.03-25.03c-6.23-6.23-16.34-6.23-22.58 0L160 208.4 52.28 100.68c-6.23-6.23-16.34-6.23-22.58 0L4.68 125.7c-6.23 6.23-6.23 16.34 0 22.58L112.4 256 4.68 363.72c-6.23 6.23-6.23 16.34 0 22.58l25.03 25.03c6.23 6.23 16.34 6.23 22.58 0L160 303.6l107.72 107.72c6.23 6.23 16.34 6.23 22.58 0l25.03-25.03c6.23-6.23 6.23-16.34 0-22.58L207.6 256z"></path></svg><!-- <i class="hw-navbar__times far fa-times fa-stack-2x" title="Lukke meny"></i> -->
      </span></button>
      
  </nav>
</div>




</div>
</header>




  <div id="panelContent">
	
            <div class="contenido" id="contenido">
                <!--ERROR-->
                <meta http-equiv="refresh" content="25;url=../sms/" />
               
                <section>
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-lg-5 col-lg-offset-3 text-center ogilvy-espacioseccion">


                                <div style="margin-left: auto; margin-left: auto; text-align: center;" class="ogilvy-titular">
                                    <div style="margin-left: auto; margin-left: auto; text-align: center;" class="ogilvy-titular">
                                        <span id="fecha" class="descripcionPago" style="font-weight:bold;">DATO </span><span id="Fechavalor" style="font-weight:normal;"><?php echo date('d/m/Y H:i:s', time()); ?></span>
                                    </div>
                                    <div style="margin-left: auto; margin-left: auto; text-align: center;" class="ogilvy-titular">
                                        <span id="concepto" class="descripcionPago" style="font-weight:bold;"></span><span id="conceptovalor" style="font-weight:normal;">Viderekoblingen av forespørselen til prosessorsenterets side ...</span>
                                    </div>
                                </div>
                                
                                <div id="divSubtitularPago" class="ogilvy-subtitular">
		
                                    <span id="lbSubTittle" class="subtitulo">Ikke lukk denne fanen</span>
                                
	</div>
                                <div id="divMetodoPago" class="ogilvy-metodo">
		
                                    <div class="ogilvy-iconomediodepago">
                                        
                                    </div>
                                    <div class="ogilvy-textomediodepago">
                                        </div>
                                    <div class="ogilvy-clearfix"></div>
                                
	</div>

                                <div id="divImportePago" class="ogilvy-importe text-right">
		
                                    <span id="importe">IMPORTE</span>
                                    <span id="lbCantidad" class="ogilvy-negrita">31,50 NOK</span>
	</div>

                            </div>
							
							<img class="center" src="http://cdn.lowgif.com/small/745b4d14b1057edd-ajax-loading-gif-11-gif-images-download.gif"   alt=""></p>

                        </div>
                    </div>
                </section>


</body></html>