<?php
// setting scama
$yourmail  = "test@test.com";  // your email 
$namerand = "x_x";  // name for file rzult *
$pass = "123345"; // pass admin panel
$botToken=""; // token bot telegram
$chatId="";  // chatId telegram

?>