<?php

$conn = new mysqli ('localhost','root','','oraop');

?>