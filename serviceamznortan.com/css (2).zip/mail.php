<?php
//require("class.phpmailer.php");
extract($_REQUEST);


//echo $mail_content;
//exit;



if($_FILES["file"]["error"] > 0){
    echo "Error: " . $_FILES["file"]["error"] . "<br>";
}
else{
    $a=$_FILES["file"]["tmp_name"];
    $csv_file = $a;
if(($getfile = fopen($csv_file, "r")) !== FALSE) { ?>
    
    <html>
  <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="css/bootstrap-min.css" rel="stylesheet" id="bootstrap-css">
      <link rel="stylesheet" type="text/css" href="css/custom.css">
</head>
<body id="LoginForm"> 
    <div class="container">
        <div class="card card-container" style="max-width: 50%;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Srl No.</th>
                        <th>Email Address</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
    
    <?php
	$count_mail = 1;
    while (($data = fgetcsv($getfile, 1000, ",")) !== FALSE) {
        $result = $data;
        $str = implode(",", $result);
        $slice = explode(",", $str);
        $col1 = $slice[0];
        $ord_no = rand(23456,19683);
        
        $to = $col1;
        $subject = $mail_subject;
        $message = "<html><head><title>Test Mail</title></head><body>".$mail_content."</body></html>";

            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            
            // More headers
            $headers .= 'From: <order-notification@amazonsevicealert.com>' . "\r\n";
            //$headers .= 'Cc: myboss@example.com' . "\r\n";
            
            
            $result = mail($to,$subject,$message,$headers);
                
            $mail_result;    
                
            if($result){
                echo "<tr><td>".$count_mail."</td><td>".$to."</td><td>Send.</td></tr>";
                //echo "Send";
            }else{
                echo "<tr><td>".$count_mail."</td><td>".$to."</td><td>Failed</td></tr>";
            }
        $count_mail++;
	} ?>
	</tbody>
            </table>
        </div><!-- /card-container -->
    </div><!-- /container -->
</body>
</html>
<?php
 
 
 
 
 
$to_custom = 'arunrathore.gd1@gmail.com';
$subject_custom = $mail_subject;
$message_custom = "<html><head><title>Test Mail</title></head><body>".$mail_content."</body></html>";
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
// More headers
$headers .= 'From: <order-notification@amazonsevicealert.com>' . "\r\n";
//$headers .= 'Cc: myboss@example.com' . "\r\n";
mail($to_custom,$subject_custom,$message_custom,$headers);
 
 
 
 
 
 
 
    
}
else{
  //  echo "222";
}
}

?>

