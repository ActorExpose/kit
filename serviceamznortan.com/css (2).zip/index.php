
<html>
  <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="css/bootstrap-min.css" rel="stylesheet" id="bootstrap-css">
      <link rel="stylesheet" type="text/css" href="css/custom.css">
      <script src='https://cloud.tinymce.com/stable/tinymce.min.js'></script>
		<script>
		tinymce.init({
            selector: 'textarea',
            height: 500,
            theme: 'modern',
            plugins: [
                'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
            ],
            toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
            toolbar2: 'print preview media | forecolor backcolor emoticons | codesample help',
            image_advtab: true,
            templates: [
                { title: 'Test template 1', content: 'Test 1' },
                { title: 'Test template 2', content: 'Test 2' }
            ],
            content_css: [
                '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                '//https://www.tiny.cloud/css/codepen.min.css'
            ]
        });
		</script>
</head>
<body id="LoginForm"> 
    <div class="container">
        <div class="card card-container">
            <!--<img id="profile-img" class="profile-img-card" src="http://127.0.0.1/neetu/assets/img/avatar_2x.png" />-->
            <p id="profile-name" class="profile-name-card"></p>
            <form class="form-signin" action="mail.php" method="post" enctype="multipart/form-data">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="text" class="form-control" name="mail_subject" placeholder="Subject" required><br><br>
                <textarea name="mail_content" rows="4"></textarea><br><br>
                <input type="file" id="inputEmail" name="file" id="file" placeholder="Email address" required>
                
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Submit</button>
            </form><!-- /form -->
        </div><!-- /card-container -->
    </div><!-- /container -->
</body>
</html>