<?php
session_start();
error_reporting(0);
include "./bot.php";
include "./checkbots.php";
include "./perfect.php";
?>
