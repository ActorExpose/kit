<?php
	include('../antibots/bot.php');
?>