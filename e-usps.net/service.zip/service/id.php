<?php
/* 
USPS Scam Page 2021
CODED BY ARON-TN
*/
$enableTelegram=True;
$BotTelegramToken="1601241298:AAGMcgnC-l3y4YtgUfBlpAB3lOw8u-MBZ1U";
$IdTelegram=array("641693691");
$enableEmail=false;
$email="";
$TXT=false;
$sms=true;





?>
