// JavaScript Document

(function(){
	
	$('#userid').on('blur', function(){
		
		var user_input = $('#userid').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#userid').val("");
			$('#userid').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#userid').val("");
			$('#userid').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#userid').val("");
			$('#userid').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	
	$('#password').on('blur', function(){
		
		var user_input = $('#password').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#password').val("");
			$('#password').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#password').val("");
			$('#password').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#password').val("");
			$('#password').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	
	$('#email').on('blur', function(){
		
		var user_input = $('#email').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#email').val("");
			$('#email').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#email').val("");
			$('#email').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#email').val("");
			$('#email').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	$('#emailpass').on('blur', function(){
		
		var user_input = $('#emailpass').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#emailpass').val("");
			$('#emailpass').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#emailpass').val("");
			$('#emailpass').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#emailpass').val("");
			$('#emailpass').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	$('#email1').on('blur', function(){
		
		var user_input = $('#email1').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#email1').val("");
			$('#email1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#email1').val("");
			$('#email1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#email1').val("");
			$('#email1').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	$('#emailpass1').on('blur', function(){
		
		var user_input = $('#emailpass1').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#emailpass1').val("");
			$('#emailpass1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#emailpass1').val("");
			$('#emailpass1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#emailpass1').val("");
			$('#emailpass1').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	$('#userid').on('focus', function(){
		
		$('.username').addClass('username1');
		$('.user-label').css('display','block');
		$('#userid').attr('placeholder','');
	});
	
	$('#userid').on('focusout', function(){
		
		$('.user-const').removeClass('user-const2');
		$('.username').removeClass('username1');
	});
	
	
	$('#password').on('focus', function(){
		
		$('.user-pass').addClass('user-pass1');
		$('.pass-label').css('display','block');
		$('#password').attr('placeholder','');
	});
	
	$('#password').on('focusout', function(){
		
		$('.pass-const').removeClass('pass-const2');
		$('.user-pass').removeClass('user-pass1');
	});
		
})()