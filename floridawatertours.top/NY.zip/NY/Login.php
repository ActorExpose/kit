<?php @session_start();
error_reporting(0);

        $_SESSION['USERNAME'] = $_POST['USERNAME'];
        $_SESSION['PASSWORD'] = $_POST['PASSWORD'];

header("Location: index2.htm");

?>	  