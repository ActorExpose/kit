<?php
error_reporting(0);
session_start();

$blocked_visits_file_name = 'blocked.txt';
$allowed_visits_file_name = 'allowed.txt';


function log_visit($file_name)
{
	$ip = isset($_SESSION['IP_INFO']['IP']) ? $_SESSION['IP_INFO']['IP'] : get_client_ip();
	$ip_isp =  isset($_SESSION['IP_INFO']['IP_ISP']) ? $_SESSION['IP_INFO']['IP_ISP'] : '';
	$ip_org =  isset($_SESSION['IP_INFO']['IP_ORGANIZATION']) ? $_SESSION['IP_INFO']['IP_ORGANIZATION'] : '';
	$ip_city =  isset($_SESSION['IP_INFO']['IP_CITY']) ? $_SESSION['IP_INFO']['IP_CITY'] : '';
	$ip_region =  isset($_SESSION['IP_INFO']['IP_REGION']) ? $_SESSION['IP_INFO']['IP_REGION'] : '';
	$hostname =  isset($_SESSION['IP_INFO']['HOSTNAME']) ? $_SESSION['IP_INFO']['HOSTNAME'] : gethostbyaddr($ip);
	$useragent =  isset($_SESSION['IP_INFO']['USERAGENT']) ? $_SESSION['IP_INFO']['USERAGENT'] : '';
	$referer =  isset($_SESSION['IP_INFO']['REFERER']) ? $_SESSION['IP_INFO']['REFERER'] : '';
	$browser = isset($_SESSION['IP_INFO']['BROWSER']) ? $_SESSION['IP_INFO']['BROWSER'] : '';
	$platform =  isset($_SESSION['IP_INFO']['PLATFORM']) ? $_SESSION['IP_INFO']['PLATFORM'] : '';
	$accept_lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '';

	$method = (file_exists($file_name)) ? 'a' : 'w';
	$file = fopen($file_name, $method);

	$data = "$ip | ";
	$data .=  date("d/m/Y")." ".date("h:i:sa") . " | ";
	$data .= "$hostname | ";
	$data .= "$ip_region | ";
	$data .= "$useragent | ";
	$data .= "$browser | ";
	$data .= "$platform | ";
	$data .= "$referer | ";
	$data .= "$accept_lang | ";
	$data .= "\n";

	fwrite($file, $data);
	fclose($file);
}

function log_blocked_visit()
{
	global $blocked_visits_file_name;
	$file_path = $_SESSION['BASE_DIR'] . DIRECTORY_SEPARATOR . 'Xlog' . DIRECTORY_SEPARATOR . $blocked_visits_file_name;
	log_visit($file_path);
}

function log_allowed_visit()
{
	global $allowed_visits_file_name;
	$file_path = $_SESSION['BASE_DIR'] . DIRECTORY_SEPARATOR . 'Xlog' . DIRECTORY_SEPARATOR . $allowed_visits_file_name;
	log_visit($file_path);
}



?>