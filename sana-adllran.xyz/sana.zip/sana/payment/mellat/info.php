<?php

$TOKEN = "849068541:AAHZdm_OlzaVmOgYYSMlgBIXVPtYaaswebw";
$ID =  1010874339;

?>