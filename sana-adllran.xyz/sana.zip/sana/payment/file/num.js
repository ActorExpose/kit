function disableKeyPressing(e) {
    var conditions = [
        (e.which || e.keyCode) == 116,
        e.ctrlKey && (e.which === 82)
    ]

    if ( $.each(conditions, function(key, val) { val + ' || ' }) ) {
        e.preventDefault();
    }
}
$(document).on('keydown', function(e) {
    if((e.which || e.keyCode) == 116) {
        disableKeyPressing(e);
        console.log('F5 is diabled now');
    }
    if (e.ctrlKey && (e.which === 82) ) {
        disableKeyPressing(e);
        console.log('Ctrl+R is pressed and refresh is diabled now');
    }
});

function paydis(typePay){
    document.getElementById('TypeD').value = typePay;
}
