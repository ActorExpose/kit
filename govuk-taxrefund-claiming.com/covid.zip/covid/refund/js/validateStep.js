function validateForm() {
    var canProceed = true;
    $("form#basicInfo input[type='text'],form#basicInfo select").each(function () {
        $(this).closest('.inputFieldsWrapper').removeClass('error');
    });
    $("form#basicInfo input[type='text'],form#basicInfo select").each(function () {
        if ($(this).attr('id') == "address2") {
            return;
        }
        if ($(this).val().trim() == "") {
            $(this).closest('.inputFieldsWrapper').addClass('error');
            canProceed = false;
            $(this).focus();
            return false;
        }
    });
    return canProceed;
}