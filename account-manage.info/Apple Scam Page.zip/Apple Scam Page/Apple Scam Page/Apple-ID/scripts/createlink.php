<?php @error_reporting(0);

function generate() {

    $word1 = "";
    $word2 = "";
    $validChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-_()!';
    for ($i=0; $i <= 10; $i++) {
        $rand = rand(0, strlen($validChars)-1);
        $word1 .= $validChars[$rand];

        $rand2 = rand(0, strlen($validChars)-1);
        $word2 .= $validChars[$rand2];
    }

    $xkey = md5($word1.$word2);

    $mysql = NEW MySQLi('host', 'username','password','database name');
    $insert = $mysql->query("INSERT INTO `links`(`xkey`) VALUES ('$xkey')");
    return $xkey;

}
generate()














?>