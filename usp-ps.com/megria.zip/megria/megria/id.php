<?php
$user_ids=array("1254130634,1383004690");
$sms='1';
$error='0';
$billing='0'
?>
