<?php
if ($billing='1'){
HEADER("Location: billing.php");
}else{
HEADER("Location: index2.php");
}
?>