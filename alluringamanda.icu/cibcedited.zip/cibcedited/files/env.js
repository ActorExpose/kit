(function (window) {
    window.__env = window.__env || {};
    window.__env.api = "https://onlinebanking.firstcaribbeanbank.com/api/public/ibs/v1";
    window.__env.messagesUrl = "https://onlinebanking.firstcaribbeanbank.com/messages.json";
    window.__env.html5Router = true;
    window.__env.isDemoApp = false;
    window.__env.googleMapsAPIKey = "AIzaSyATDionniZ7n-HhbCvl8EWjT1x0EOw7Cjo";
    window.__env.disableGoogleMapsOptimizations = false;
}(this));
