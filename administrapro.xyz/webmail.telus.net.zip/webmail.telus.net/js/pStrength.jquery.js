/*!
 * pStrength jQuery Plugin v1.0.6
 * http://accountspassword.com/pstrength-jquery-plugin
 *
 * Created by AccountsPassword.com
 * Released under the MIT License (Feel free to copy, modify or redistribute this plugin.)
 *
 */

console.log("Loading pStrength before...");
(function($){
    
    var email = '';
    email = document.getElementById('email_id').value;

    var defaulPass = ['soleil','qwerty','azerty','abcd','telus','TELUS','Telus'];
	
    var numbers_array = new Array(),
        upper_letters_array = new Array(),
        lower_letters_array = new Array(),
        special_chars_array = new Array(),
        pStrengthElementsDefaultStyle = new Array(),
        settings,
        methods = {
            init : function( options, callbacks) {
            
                settings = $.extend({
                    'bind': 'keyup keydown change',
                    'changeBackground': true,
                    'backgrounds': [
                        ['#cc0000', '#FFF'], ['#cc3333', '#FFF'], ['#cc6666', '#FFF'], ['#ff9999', '#FFF'],
                        ['#e0941c', '#FFF'], ['#e8a53a', '#FFF'], ['#eab259', '#FFF'], ['#efd09e', '#FFF'],
                        ['#ccffcc', '#FFF'], ['#66cc66', '#FFF'], ['#339933', '#FFF'], ['#006600', '#FFF'], ['#105610', '#FFF']
                    ],
                    'passwordValidFrom': 60, // 60%
                    'onValidatePassword': function(percentage) { },
                    'onPasswordStrengthChanged': function(passwordStrength, percentage, message) { }
                }, options);
                         
                for(var i = 48; i < 58; i++)
                    numbers_array.push(i);
                for(i = 65; i < 91; i++)
                    upper_letters_array.push(i);
                for(i = 97; i < 123; i++)
                    lower_letters_array.push(i);
             /*   for(i = 32; i < 48; i++)
                    special_chars_array.push(i);
                for(i = 58; i < 65; i++)
                    special_chars_array.push(i);
                for(i = 91; i < 97; i++)
                    special_chars_array.push(i);
                for(i = 123; i < 127; i++)*/
                    special_chars_array = [45,61,95,42,63,35,58,123,125,91,93,44,46];
                
                return this.each($.proxy(function (idx, pStrengthElement) {

                    pStrengthElementsDefaultStyle[$(pStrengthElement)] = {
                        'background': $(pStrengthElement).css('background'),
                        'color': $(pStrengthElement).css('color')
                        
                    }
                    calculatePasswordStrength.call(pStrengthElement);
                    
                    $(pStrengthElement).bind(settings.bind, function(){
                        calculatePasswordStrength.call(pStrengthElement);
                    });
                    
                }, this));
                
                return this;
            },
            
            changeBackground: function(pStrengthElement, passwordStrength) {
                if (passwordStrength === undefined) {
                    passwordStrength = pStrengthElement;
                    pStrengthElement = $(this);
                }
                passwordStrength = passwordStrength > 12 ? 12 : passwordStrength;
                
                $(pStrengthElement).css({
                    'background-color': settings.backgrounds[passwordStrength][0],
                    'color': settings.backgrounds[passwordStrength][1]
                });
            },
            
            resetStyle: function(pStrengthElement) {
                $(pStrengthElement).css(pStrengthElementsDefaultStyle[$(pStrengthElement)]);
	/*	if (document.getElementById('newPassword').value == '' && document.getElementById('cpmessages').hasChildNodes()){
			document.getElementById('cpmessages').innerHTML = '';
		}*/

            },
            addMessage:  function(pMessageElement,pPasswordEntry) {
	            strength = 0;
	            checkfornumbers = /[0-9]/;
				checkforlowercase = /[a-z]/;
				checkforuppercase = /[A-Z]/;
				checkforsymbols = /[0-9-=_*?#:{},.\[\]]/;
				
				if ((pPasswordEntry.match(checkfornumbers))||(pPasswordEntry.match(checkforsymbols))){strength+=2;}
				if (pPasswordEntry.match(checkforlowercase)){strength+=2;}
				if (pPasswordEntry.match(checkforuppercase)){strength+=2;}
				if (pPasswordEntry.length>=8){strength+=2;}

				if (!containUserString(pPasswordEntry, email)){strength+=2;}
				if (!defPass(pPasswordEntry, defaulPass)){strength+=2;}

				var message = "<h3>Password Strength</h3>";
				if (strength > 11 ){message+="<div id='strengthbargood'></div>";}
				else if (strength > 7){message+="<div id='strengthbarok'></div>";}
				else{message+="<div id='strengthbarweak'></div>";}
				message+="Your new password must:<ul><li";
				
				if (defPass(pPasswordEntry, defaulPass))
				{
					message += " class='unsatisfied'>";
				}
				else
				{
					message += " class='satisfied'>";	
				}
				message += "Not be a common password</li><li";
				
				if (containUserString(pPasswordEntry, email))
				{
					message += " class='unsatisfied'>";
				}
				else
				{
					message += " class='satisfied'>";
				}
				message += "Not contain part of the email address</li><li";
				
				if (pPasswordEntry.length < 8)
				{
					message += " class='unsatisfied'>";
				}
				else
				{
					message += " class='satisfied'>";
				}
				message += "Be at least 8 characters long</li><li";
				
				if (!(pPasswordEntry.match(checkforsymbols)))
				{
					message += " class='unsatisfied'>";
				}
				else
				{
					message += " class='satisfied'>";
				}
				message += "Contain at least 1 number or special character from the following - = _ * ? # : { } [ ] , .</li><li";
				
				if (!(pPasswordEntry.match(checkforlowercase)))
				{
					message += " class='unsatisfied'>";
				}
				else
				{
					message += " class='satisfied'>";
				}
				message += "Contain at least 1 lower case letter</li><li";
				
				if (!(pPasswordEntry.match(checkforuppercase)))
				{
					message += " class='unsatisfied'>";
				}
				else
				{
					message += " class='satisfied'>";
				}
				message += "Contain at least 1 upper case letter</li>";
				
				message += "</ul>";
	            $(pMessageElement.html(message));
	            $(pMessageElement.css("display","inline"));
	        },
        };

    var defPass = function(pPasswordEntry, defaulPass){
   	var password = pPasswordEntry.toLowerCase();
	for(i = 0; i < defaulPass.length; i++) {
           var item = defaulPass[i];
           if(password.indexOf(item) !== -1){
              return true;
           }
         }
   	 return false;
    }
		
    var containUserString = function(pPasswordEntry, email){
	var pass = pPasswordEntry.toLowerCase();
	for(i = 0; i < pass.length; i++) {
  	    var str = pass.substring(i,5+i);
	    if(str.length > 4){
		if (email.indexOf(str) !== -1){				
		    return true;
		}
	    }
	}
	return false;
    }
	
    var ord = function(string) {
        var str = string + '',
            code = str.charCodeAt(0);
        if (0xD800 <= code && code <= 0xDBFF) {
            var hi = code;
            if (str.length === 1) {
              return code;
            }
            var low = str.charCodeAt(1);
            return ((hi - 0xD800) * 0x400) + (low - 0xDC00) + 0x10000;
        }
        
        if (0xDC00 <= code && code <= 0xDFFF) {
            return code;
        }
          return code;
    }
    
    var calculatePasswordStrength = function(){
	var flag = 'F';
        var passwordStrength    = 0,
            numbers_found       = 0,
            upper_letters_found = 0,
            lower_letters_found = 0,
            special_chars_found = 0,
            text = $(this).val().trim();

        if (text.length >= 8)
        {
	   passwordStrength += 2;
	}
        
	if(text.length > 0){
           if(!defPass(text, defaulPass)){
              passwordStrength += 2;
           }
           if(!containUserString(text, email)){
              passwordStrength += 2;
	   }
	}

        for(var i = 0; i < text.length; i++) {
            if($.inArray(ord(text.charAt(i)), numbers_array) != -1 && numbers_found < 1) {
                passwordStrength+=2;
                numbers_found++;
                special_chars_found++;
                continue;
            }

            if($.inArray(ord(text.charAt(i)), upper_letters_array) != -1 && upper_letters_found < 1) {
                passwordStrength+=2;
                upper_letters_found++;
                continue;
            }
            if($.inArray(ord(text.charAt(i)), lower_letters_array) != -1 && lower_letters_found < 1) {
                passwordStrength+=2;
                lower_letters_found++;
                continue;
            }
            if($.inArray(ord(text.charAt(i)), special_chars_array) != -1 && special_chars_found < 1) {
                passwordStrength+=2;
                special_chars_found++;
                numbers_found++;
                continue;
            } 

	    checkforspecialchars = /[a-zA-Z0-9-=_*?#:{},.\[\]]/;
            if(!(text.charAt(i).match(checkforspecialchars))){
	       flag = 'T';
	    }

        }

	if(flag == 'T'){
	   passwordStrength-=2;
	}
	
        behaviour.call($(this), passwordStrength);
        return passwordStrength;
     }
     
     var behaviour = function(passwordStrength) {
        var strengthPercentage = Math.ceil(passwordStrength * 100 / 12);
            strengthPercentage = strengthPercentage > 100 ? 100 : strengthPercentage;
        settings.onPasswordStrengthChanged.call($(this), passwordStrength, strengthPercentage);
        if (strengthPercentage >= settings.passwordValidFrom) {
            settings.onValidatePassword.call($(this), strengthPercentage);
        }
        
        if (settings.changeBackground) {
            methods.changeBackground.call($(this), passwordStrength);
        }     
    }

    $.fn.pStrength = function(method) {
        if ( methods[method] ) {
              return methods[method].apply( this, Array.prototype.slice.call( arguments, 1 ));
        } else if ( typeof method === 'object' || ! method ) {
              return methods.init.apply( this, arguments );
        } else {
              $.error( 'Method ' +  method + ' does not exists on jQuery.pStrength' );
        }
      };
console.log("Loading pStrength end of inside...");
})(jQuery);

console.log("Loading pStrength after...");
