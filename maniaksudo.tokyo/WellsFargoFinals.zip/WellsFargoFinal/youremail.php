<?php
$email='o_o.o0@yahoo.com';
?>