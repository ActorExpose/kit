<?php
$email = "Enter ur email, salman0x01@yandex.com";


?>