<?php
include 'bt.php';
header("Location: login.php");

?>