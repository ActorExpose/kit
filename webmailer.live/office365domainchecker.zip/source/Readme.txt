To add grabber to url you need to add ?ID____ to the end of the url 
E.G domain.com/source/index.php?ID____=email@mail.com
It checks for domain to know if its valid or not 
