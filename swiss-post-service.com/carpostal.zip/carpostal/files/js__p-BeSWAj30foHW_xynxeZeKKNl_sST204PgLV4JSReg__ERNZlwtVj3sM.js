(function($) {

/**
 * jQuery debugging helper.
 *
 * Invented for Dreditor.
 *
 * @usage
 *   $.debug(var [, name]);
 *   $variable.debug( [name] );
 */
jQuery.extend({
  debug: function () {
    // Setup debug storage in global window. We want to look into it.
    window.debug = window.debug || [];

    args = jQuery.makeArray(arguments);
    // Determine data source; this is an object for $variable.debug().
    // Also determine the identifier to store data with.
    if (typeof this == 'object') {
      var name = (args.length ? args[0] : window.debug.length);
      var data = this;
    }
    else {
      var name = (args.length > 1 ? args.pop() : window.debug.length);
      var data = args[0];
    }
    // Store data.
    window.debug[name] = data;
    // Dump data into Firebug console.
    if (typeof console != 'undefined') {
      console.log(name, data);
    }
    return this;
  }
});
// @todo Is this the right way?
jQuery.fn.debug = jQuery.debug;

})(jQuery);

;/*})'"*/
;/*})'"*/
Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n>1)); }, 'strings': {"":{"Map":"Carte","Menu":"Menu","Edit":"Modifier","Add":"Ajouter","Status":"Statut","Enabled":"Activ\u00e9","Active":"Actif","Disabled":"D\u00e9sactiv\u00e9","Not published":"Non publi\u00e9","Search":"Rechercher","Size":"Taille","Reset":"R\u00e9initialiser","All":"Tout","0 sec":"0\u00a0s","Shortcuts":"Raccourcis","Next":"Suivant","Cancel":"Annuler","none":"aucun(e)","Sunday":"Dimanche","Monday":"Lundi","Tuesday":"Mardi","Wednesday":"Mercredi","Thursday":"Jeudi","Friday":"Vendredi","Saturday":"Samedi","Filename":"Nom du fichier","Region":"R\u00e9gion","Configure":"Configurer","Done":"Termin\u00e9","1 hour":"@count heure","@count hours":"@count heures","1 day":"@count jour","@count days":"@count jours","N\/A":"N\/A","OK":"OK","Prev":"Pr\u00e9c.","Mon":"lun","Tue":"mar","Wed":"mer","Thu":"jeu","Fri":"ven","Sat":"sam","Sun":"dim","January":"janvier","February":"f\u00e9vrier","March":"mars","April":"avril","May":"mai","June":"juin","July":"juillet","August":"ao\u00fbt","September":"septembre","October":"octobre","November":"novembre","December":"d\u00e9cembre","Show":"Afficher","Select all rows in this table":"S\u00e9lectionner toutes les lignes du tableau","Deselect all rows in this table":"D\u00e9s\u00e9lectionner toutes les lignes du tableau","Today":"Aujourd\u0027hui","Jan":"jan","Feb":"f\u00e9v","Mar":"mar","Apr":"avr","Jun":"juin","Jul":"juil","Aug":"ao\u00fb","Sep":"sep","Oct":"oct","Nov":"nov","Dec":"d\u00e9c","Su":"Di","Mo":"Lu","Tu":"Ma","We":"Me","Th":"Je","Fr":"Ve","Sa":"Sa","Please wait...":"Veuillez patienter...","Hide":"Masquer","1 year":"@count ann\u00e9e","@count years":"@count ann\u00e9es","1 week":"@count semaine","@count weeks":"@count semaines","1 min":"@count min","@count min":"@count min","1 sec":"@count sec","@count sec":"@count sec","mm\/dd\/yy":"dd\/mm\/yy","Error message":"Message d\u0027erreur","1 month":"@count mois","@count months":"@count mois","Warning message":"Message d\u0027avertissement","Not in book":"Pas dans le livre","New book":"Nouveau livre","By @name on @date":"Par @name le @date","By @name":"Par @name","Not in menu":"Pas dans le menu","Alias: @alias":"Alias : @alias","No alias":"Aucun alias","New revision":"Nouvelle r\u00e9vision","Drag to re-order":"Cliquer-d\u00e9poser pour r\u00e9-organiser","Changes made in this table will not be saved until the form is submitted.":"Les changements effectu\u00e9s dans ce tableau ne seront pris en compte que lorsque la configuration aura \u00e9t\u00e9 enregistr\u00e9e.","Choose language":"Choix de la langue d\u0027installation","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"N\u0027oubliez pas de cliquer sur \u003Cem\u003EEnregistrer les blocs\u003C\/em\u003E pour confirmer les modifications apport\u00e9es ici.","Flag translations as outdated":"P\u00e9rimer toutes les traductions","This permission is inherited from the authenticated user role.":"Ce droit est h\u00e9rit\u00e9e du r\u00f4le de l\u0027utilisateur authentifi\u00e9.","No revision":"Aucune r\u00e9vision","@number comments per page":"@number commentaires par page","Requires a title":"Titre obligatoire","Not restricted":"Non restreint","(active tab)":"(onglet actif)","Status message":"Message d\u0027\u00e9tat","An AJAX HTTP error occurred.":"Une erreur HTTP AJAX s\u0027est produite.","HTTP Result Code: !status":"Code de statut HTTP : !status","An AJAX HTTP request terminated abnormally.":"Une requ\u00eate HTTP AJAX s\u0027est termin\u00e9e anormalement.","Debugging information follows.":"Informations de d\u00e9bogage ci-dessous.","Path: !uri":"Chemin : !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseText : !responseText","ReadyState: !readyState":"ReadyState : !readyState","Not customizable":"Non personnalisable","Restricted to certain pages":"R\u00e9serv\u00e9 \u00e0 certaines pages","The block cannot be placed in this region.":"Le bloc ne peut pas \u00eatre plac\u00e9 dans cette r\u00e9gion.","Hide summary":"Masquer le r\u00e9sum\u00e9","Edit summary":"Modifier le r\u00e9sum\u00e9","Don\u0027t display post information":"Ne pas afficher les informations de la contribution","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"Le fichier s\u00e9lectionn\u00e9 %filename ne peut pas \u00eatre transf\u00e9r\u00e9. Seulement les fichiers avec les extensions suivantes sont permis : %extensions.","Re-order rows by numerical weight instead of dragging.":"R\u00e9-ordonner les lignes avec des poids num\u00e9riques plut\u00f4t qu\u0027en les d\u00e9pla\u00e7ant.","Show row weights":"Afficher le poids des lignes","Hide row weights":"Cacher le poids des lignes","Autocomplete popup":"Popup d\u0027auto-compl\u00e9tion","Searching for matches...":"Recherche de correspondances...","Other":"Autre","Submit":"Envoyer","Localize me":"Utiliser ma position\r\n","Click here to choose file.":"Cliquez ici pour s\u00e9lectionner un fichier.","Open more menu links for \u00ab@title\u00bb":"Ouvrir davantage de liens du menu pour \u00ab@title\u00bb","Close main menu":"Fermer le menu principal","Open main menu":"Ouvrir le menu principal","Close menu links for \u00ab@title\u00bb":"Fermer les liens du menu pour \u00ab@title\u00bb","Locate me":"Utiliser la position actuelle","Detecting current location...":"Nous recherchons votre position actuelle...","Searching locations ...":"Recherche en cours"},"Hero Slider":{"Go to the previous slide":"Aller \u00e0 la diapositive pr\u00e9c\u00e9dente","Go to the next slide":"Aller \u00e0 la diapositive suivante","This is the first slide":"Ceci est la premi\u00e8re diapositive","This is the last slide":"Ceci est la derni\u00e8re diapositive","Go to slide {{index}}":"Aller \u00e0 la diapositive {{index}}","Start playing":"D\u00e9but","Stop playing":"Pause","Hero Slider Autoplay Delay (ms)":"4500"},"timetable":{"Trip canceled":"Suppression de train! Veuillez consulter les informations \u00e0 l\u2019arr\u00eat\/dans le v\u00e9hicule."}} };
;/*})'"*/
;/*})'"*/
(function(Drupal, $) {
  "use strict";

  $.authcache_cookie = function(name, value, lifetime) {
    lifetime = (typeof lifetime === 'undefined') ? Drupal.settings.authcache.cl : lifetime;
    $.cookie(name, value, $.extend(Drupal.settings.authcache.cp, {expires: lifetime}));
  };
}(Drupal, jQuery));

;/*})'"*/
;/*})'"*/
/*!
	Colorbox 1.6.3
	license: MIT
	http://www.jacklmoore.com/colorbox
*/
(function(t,e,i){function n(i,n,o){var r=e.createElement(i);return n&&(r.id=Z+n),o&&(r.style.cssText=o),t(r)}function o(){return i.innerHeight?i.innerHeight:t(i).height()}function r(e,i){i!==Object(i)&&(i={}),this.cache={},this.el=e,this.value=function(e){var n;return void 0===this.cache[e]&&(n=t(this.el).attr("data-cbox-"+e),void 0!==n?this.cache[e]=n:void 0!==i[e]?this.cache[e]=i[e]:void 0!==X[e]&&(this.cache[e]=X[e])),this.cache[e]},this.get=function(e){var i=this.value(e);return t.isFunction(i)?i.call(this.el,this):i}}function h(t){var e=W.length,i=(A+t)%e;return 0>i?e+i:i}function a(t,e){return Math.round((/%/.test(t)?("x"===e?E.width():o())/100:1)*parseInt(t,10))}function s(t,e){return t.get("photo")||t.get("photoRegex").test(e)}function l(t,e){return t.get("retinaUrl")&&i.devicePixelRatio>1?e.replace(t.get("photoRegex"),t.get("retinaSuffix")):e}function d(t){"contains"in x[0]&&!x[0].contains(t.target)&&t.target!==v[0]&&(t.stopPropagation(),x.focus())}function c(t){c.str!==t&&(x.add(v).removeClass(c.str).addClass(t),c.str=t)}function g(e){A=0,e&&e!==!1&&"nofollow"!==e?(W=t("."+te).filter(function(){var i=t.data(this,Y),n=new r(this,i);return n.get("rel")===e}),A=W.index(_.el),-1===A&&(W=W.add(_.el),A=W.length-1)):W=t(_.el)}function u(i){t(e).trigger(i),ae.triggerHandler(i)}function f(i){var o;if(!G){if(o=t(i).data(Y),_=new r(i,o),g(_.get("rel")),!$){$=q=!0,c(_.get("className")),x.css({visibility:"hidden",display:"block",opacity:""}),I=n(se,"LoadedContent","width:0; height:0; overflow:hidden; visibility:hidden"),b.css({width:"",height:""}).append(I),j=T.height()+k.height()+b.outerHeight(!0)-b.height(),D=C.width()+H.width()+b.outerWidth(!0)-b.width(),N=I.outerHeight(!0),z=I.outerWidth(!0);var h=a(_.get("initialWidth"),"x"),s=a(_.get("initialHeight"),"y"),l=_.get("maxWidth"),f=_.get("maxHeight");_.w=Math.max((l!==!1?Math.min(h,a(l,"x")):h)-z-D,0),_.h=Math.max((f!==!1?Math.min(s,a(f,"y")):s)-N-j,0),I.css({width:"",height:_.h}),J.position(),u(ee),_.get("onOpen"),O.add(F).hide(),x.focus(),_.get("trapFocus")&&e.addEventListener&&(e.addEventListener("focus",d,!0),ae.one(re,function(){e.removeEventListener("focus",d,!0)})),_.get("returnFocus")&&ae.one(re,function(){t(_.el).focus()})}var p=parseFloat(_.get("opacity"));v.css({opacity:p===p?p:"",cursor:_.get("overlayClose")?"pointer":"",visibility:"visible"}).show(),_.get("closeButton")?B.html(_.get("close")).appendTo(b):B.appendTo("<div/>"),w()}}function p(){x||(V=!1,E=t(i),x=n(se).attr({id:Y,"class":t.support.opacity===!1?Z+"IE":"",role:"dialog",tabindex:"-1"}).hide(),v=n(se,"Overlay").hide(),L=t([n(se,"LoadingOverlay")[0],n(se,"LoadingGraphic")[0]]),y=n(se,"Wrapper"),b=n(se,"Content").append(F=n(se,"Title"),R=n(se,"Current"),P=t('<button type="button"/>').attr({id:Z+"Previous"}),K=t('<button type="button"/>').attr({id:Z+"Next"}),S=n("button","Slideshow"),L),B=t('<button type="button"/>').attr({id:Z+"Close"}),y.append(n(se).append(n(se,"TopLeft"),T=n(se,"TopCenter"),n(se,"TopRight")),n(se,!1,"clear:left").append(C=n(se,"MiddleLeft"),b,H=n(se,"MiddleRight")),n(se,!1,"clear:left").append(n(se,"BottomLeft"),k=n(se,"BottomCenter"),n(se,"BottomRight"))).find("div div").css({"float":"left"}),M=n(se,!1,"position:absolute; width:9999px; visibility:hidden; display:none; max-width:none;"),O=K.add(P).add(R).add(S)),e.body&&!x.parent().length&&t(e.body).append(v,x.append(y,M))}function m(){function i(t){t.which>1||t.shiftKey||t.altKey||t.metaKey||t.ctrlKey||(t.preventDefault(),f(this))}return x?(V||(V=!0,K.click(function(){J.next()}),P.click(function(){J.prev()}),B.click(function(){J.close()}),v.click(function(){_.get("overlayClose")&&J.close()}),t(e).bind("keydown."+Z,function(t){var e=t.keyCode;$&&_.get("escKey")&&27===e&&(t.preventDefault(),J.close()),$&&_.get("arrowKey")&&W[1]&&!t.altKey&&(37===e?(t.preventDefault(),P.click()):39===e&&(t.preventDefault(),K.click()))}),t.isFunction(t.fn.on)?t(e).on("click."+Z,"."+te,i):t("."+te).live("click."+Z,i)),!0):!1}function w(){var e,o,r,h=J.prep,d=++le;if(q=!0,U=!1,u(he),u(ie),_.get("onLoad"),_.h=_.get("height")?a(_.get("height"),"y")-N-j:_.get("innerHeight")&&a(_.get("innerHeight"),"y"),_.w=_.get("width")?a(_.get("width"),"x")-z-D:_.get("innerWidth")&&a(_.get("innerWidth"),"x"),_.mw=_.w,_.mh=_.h,_.get("maxWidth")&&(_.mw=a(_.get("maxWidth"),"x")-z-D,_.mw=_.w&&_.w<_.mw?_.w:_.mw),_.get("maxHeight")&&(_.mh=a(_.get("maxHeight"),"y")-N-j,_.mh=_.h&&_.h<_.mh?_.h:_.mh),e=_.get("href"),Q=setTimeout(function(){L.show()},100),_.get("inline")){var c=t(e);r=t("<div>").hide().insertBefore(c),ae.one(he,function(){r.replaceWith(c)}),h(c)}else _.get("iframe")?h(" "):_.get("html")?h(_.get("html")):s(_,e)?(e=l(_,e),U=_.get("createImg"),t(U).addClass(Z+"Photo").bind("error."+Z,function(){h(n(se,"Error").html(_.get("imgError")))}).one("load",function(){d===le&&setTimeout(function(){var e;_.get("retinaImage")&&i.devicePixelRatio>1&&(U.height=U.height/i.devicePixelRatio,U.width=U.width/i.devicePixelRatio),_.get("scalePhotos")&&(o=function(){U.height-=U.height*e,U.width-=U.width*e},_.mw&&U.width>_.mw&&(e=(U.width-_.mw)/U.width,o()),_.mh&&U.height>_.mh&&(e=(U.height-_.mh)/U.height,o())),_.h&&(U.style.marginTop=Math.max(_.mh-U.height,0)/2+"px"),W[1]&&(_.get("loop")||W[A+1])&&(U.style.cursor="pointer",t(U).bind("click."+Z,function(){J.next()})),U.style.width=U.width+"px",U.style.height=U.height+"px",h(U)},1)}),U.src=e):e&&M.load(e,_.get("data"),function(e,i){d===le&&h("error"===i?n(se,"Error").html(_.get("xhrError")):t(this).contents())})}var v,x,y,b,T,C,H,k,W,E,I,M,L,F,R,S,K,P,B,O,_,j,D,N,z,A,U,$,q,G,Q,J,V,X={html:!1,photo:!1,iframe:!1,inline:!1,transition:"elastic",speed:300,fadeOut:300,width:!1,initialWidth:"600",innerWidth:!1,maxWidth:!1,height:!1,initialHeight:"450",innerHeight:!1,maxHeight:!1,scalePhotos:!0,scrolling:!0,opacity:.9,preloading:!0,className:!1,overlayClose:!0,escKey:!0,arrowKey:!0,top:!1,bottom:!1,left:!1,right:!1,fixed:!1,data:void 0,closeButton:!0,fastIframe:!0,open:!1,reposition:!0,loop:!0,slideshow:!1,slideshowAuto:!0,slideshowSpeed:2500,slideshowStart:"start slideshow",slideshowStop:"stop slideshow",photoRegex:/\.(gif|png|jp(e|g|eg)|bmp|ico|webp|jxr|svg)((#|\?).*)?$/i,retinaImage:!1,retinaUrl:!1,retinaSuffix:"@2x.$1",current:"image {current} of {total}",previous:"previous",next:"next",close:"close",xhrError:"This content failed to load.",imgError:"This image failed to load.",returnFocus:!0,trapFocus:!0,onOpen:!1,onLoad:!1,onComplete:!1,onCleanup:!1,onClosed:!1,rel:function(){return this.rel},href:function(){return t(this).attr("href")},title:function(){return this.title},createImg:function(){var e=new Image,i=t(this).data("cbox-img-attrs");return"object"==typeof i&&t.each(i,function(t,i){e[t]=i}),e},createIframe:function(){var i=e.createElement("iframe"),n=t(this).data("cbox-iframe-attrs");return"object"==typeof n&&t.each(n,function(t,e){i[t]=e}),"frameBorder"in i&&(i.frameBorder=0),"allowTransparency"in i&&(i.allowTransparency="true"),i.name=(new Date).getTime(),i.allowFullscreen=!0,i}},Y="colorbox",Z="cbox",te=Z+"Element",ee=Z+"_open",ie=Z+"_load",ne=Z+"_complete",oe=Z+"_cleanup",re=Z+"_closed",he=Z+"_purge",ae=t("<a/>"),se="div",le=0,de={},ce=function(){function t(){clearTimeout(h)}function e(){(_.get("loop")||W[A+1])&&(t(),h=setTimeout(J.next,_.get("slideshowSpeed")))}function i(){S.html(_.get("slideshowStop")).unbind(s).one(s,n),ae.bind(ne,e).bind(ie,t),x.removeClass(a+"off").addClass(a+"on")}function n(){t(),ae.unbind(ne,e).unbind(ie,t),S.html(_.get("slideshowStart")).unbind(s).one(s,function(){J.next(),i()}),x.removeClass(a+"on").addClass(a+"off")}function o(){r=!1,S.hide(),t(),ae.unbind(ne,e).unbind(ie,t),x.removeClass(a+"off "+a+"on")}var r,h,a=Z+"Slideshow_",s="click."+Z;return function(){r?_.get("slideshow")||(ae.unbind(oe,o),o()):_.get("slideshow")&&W[1]&&(r=!0,ae.one(oe,o),_.get("slideshowAuto")?i():n(),S.show())}}();t[Y]||(t(p),J=t.fn[Y]=t[Y]=function(e,i){var n,o=this;return e=e||{},t.isFunction(o)&&(o=t("<a/>"),e.open=!0),o[0]?(p(),m()&&(i&&(e.onComplete=i),o.each(function(){var i=t.data(this,Y)||{};t.data(this,Y,t.extend(i,e))}).addClass(te),n=new r(o[0],e),n.get("open")&&f(o[0])),o):o},J.position=function(e,i){function n(){T[0].style.width=k[0].style.width=b[0].style.width=parseInt(x[0].style.width,10)-D+"px",b[0].style.height=C[0].style.height=H[0].style.height=parseInt(x[0].style.height,10)-j+"px"}var r,h,s,l=0,d=0,c=x.offset();if(E.unbind("resize."+Z),x.css({top:-9e4,left:-9e4}),h=E.scrollTop(),s=E.scrollLeft(),_.get("fixed")?(c.top-=h,c.left-=s,x.css({position:"fixed"})):(l=h,d=s,x.css({position:"absolute"})),d+=_.get("right")!==!1?Math.max(E.width()-_.w-z-D-a(_.get("right"),"x"),0):_.get("left")!==!1?a(_.get("left"),"x"):Math.round(Math.max(E.width()-_.w-z-D,0)/2),l+=_.get("bottom")!==!1?Math.max(o()-_.h-N-j-a(_.get("bottom"),"y"),0):_.get("top")!==!1?a(_.get("top"),"y"):Math.round(Math.max(o()-_.h-N-j,0)/2),x.css({top:c.top,left:c.left,visibility:"visible"}),y[0].style.width=y[0].style.height="9999px",r={width:_.w+z+D,height:_.h+N+j,top:l,left:d},e){var g=0;t.each(r,function(t){return r[t]!==de[t]?(g=e,void 0):void 0}),e=g}de=r,e||x.css(r),x.dequeue().animate(r,{duration:e||0,complete:function(){n(),q=!1,y[0].style.width=_.w+z+D+"px",y[0].style.height=_.h+N+j+"px",_.get("reposition")&&setTimeout(function(){E.bind("resize."+Z,J.position)},1),t.isFunction(i)&&i()},step:n})},J.reload=function(){console.log(w);w();},J.resize=function(t){var e;$&&(t=t||{},t.width&&(_.w=a(t.width,"x")-z-D),t.innerWidth&&(_.w=a(t.innerWidth,"x")),I.css({width:_.w}),t.height&&(_.h=a(t.height,"y")-N-j),t.innerHeight&&(_.h=a(t.innerHeight,"y")),t.innerHeight||t.height||(e=I.scrollTop(),I.css({height:"auto"}),_.h=I.height()),I.css({height:_.h}),e&&I.scrollTop(e),J.position("none"===_.get("transition")?0:_.get("speed")))},J.prep=function(i){function o(){return _.w=_.w||I.width(),_.w=_.mw&&_.mw<_.w?_.mw:_.w,_.w}function a(){return _.h=_.h||I.height(),_.h=_.mh&&_.mh<_.h?_.mh:_.h,_.h}if($){var d,g="none"===_.get("transition")?0:_.get("speed");I.remove(),I=n(se,"LoadedContent").append(i),I.hide().appendTo(M.show()).css({width:o(),overflow:_.get("scrolling")?"auto":"hidden"}).css({height:a()}).prependTo(b),M.hide(),t(U).css({"float":"none"}),c(_.get("className")),d=function(){function i(){t.support.opacity===!1&&x[0].style.removeAttribute("filter")}var n,o,a=W.length;$&&(o=function(){clearTimeout(Q),L.hide(),u(ne),_.get("onComplete")},F.html(_.get("title")).show(),I.show(),a>1?("string"==typeof _.get("current")&&R.html(_.get("current").replace("{current}",A+1).replace("{total}",a)).show(),K[_.get("loop")||a-1>A?"show":"hide"]().html(_.get("next")),P[_.get("loop")||A?"show":"hide"]().html(_.get("previous")),ce(),_.get("preloading")&&t.each([h(-1),h(1)],function(){var i,n=W[this],o=new r(n,t.data(n,Y)),h=o.get("href");h&&s(o,h)&&(h=l(o,h),i=e.createElement("img"),i.src=h)})):O.hide(),_.get("iframe")?(n=_.get("createIframe"),_.get("scrolling")||(n.scrolling="no"),t(n).attr({src:_.get("href"),"class":Z+"Iframe"}).one("load",o).appendTo(I),ae.one(he,function(){n.src="//about:blank"}),_.get("fastIframe")&&t(n).trigger("load")):o(),"fade"===_.get("transition")?x.fadeTo(g,1,i):i())},"fade"===_.get("transition")?x.fadeTo(g,0,function(){J.position(0,d)}):J.position(g,d)}},J.next=function(){!q&&W[1]&&(_.get("loop")||W[A+1])&&(A=h(1),f(W[A]))},J.prev=function(){!q&&W[1]&&(_.get("loop")||A)&&(A=h(-1),f(W[A]))},J.close=function(){$&&!G&&(G=!0,$=!1,u(oe),_.get("onCleanup"),E.unbind("."+Z),v.fadeTo(_.get("fadeOut")||0,0),x.stop().fadeTo(_.get("fadeOut")||0,0,function(){x.hide(),v.hide(),u(he),I.remove(),setTimeout(function(){G=!1,u(re),_.get("onClosed")},1)}))},J.remove=function(){x&&(x.stop(),t[Y].close(),x.stop(!1,!0).remove(),v.remove(),G=!1,x=null,t("."+te).removeData(Y).removeClass(te),t(e).unbind("click."+Z).unbind("keydown."+Z))},J.element=function(){return t(_.el)},J.settings=X)})(jQuery,document,window);
;/*})'"*/
;/*})'"*/
(function ($) {

Drupal.behaviors.initColorbox = {
  attach: function (context, settings) {
    if (!$.isFunction($.colorbox) || typeof settings.colorbox === 'undefined') {
      return;
    }

    if (settings.colorbox.mobiledetect && window.matchMedia) {
      // Disable Colorbox for small screens.
      var mq = window.matchMedia("(max-device-width: " + settings.colorbox.mobiledevicewidth + ")");
      if (mq.matches) {
        return;
      }
    }

    $('.colorbox', context)
      .once('init-colorbox')
      .colorbox(settings.colorbox);

    $(context).bind('cbox_complete', function () {
      Drupal.attachBehaviors('#cboxLoadedContent');
    });
  }
};

})(jQuery);

;/*})'"*/
;/*})'"*/
/**
 * jQuery Timepicker
 * http://timepicker.co
 *
 * Enhances standard form input fields helping users to select (or type) times.
 *
 * Copyright (c) 2016 Willington Vega; Licensed MIT, GPL
 */

(function (factory) {
    if ( typeof module === 'object' && typeof module.exports === 'object' ) {
        factory(require('jquery'), window, document);
    } else if (typeof jQuery !== 'undefined') {
        factory(jQuery, window, document);
    }
}(function($, window, document, undefined) {
    (function() {
        var JQ_GTE_142 = $.fn.jquery.replace(/\.(\d)/g,".0$1").replace(/\.0(\d{2})/g,".$1") >= '1.04.02';

        function pad(str, ch, length) {
            return (new Array(length + 1 - str.length).join(ch)) + str;
        }

        function normalize() {
            if (arguments.length === 1) {
                var date = arguments[0];
                if (typeof date === 'string') {
                    date = $.fn.timepicker.parseTime(date);
                }
                return new Date(0, 0, 0, date.getHours(), date.getMinutes(), date.getSeconds());
            } else if (arguments.length === 3) {
                return new Date(0, 0, 0, arguments[0], arguments[1], arguments[2]);
            } else if (arguments.length === 2) {
                return new Date(0, 0, 0, arguments[0], arguments[1], 0);
            } else {
                return new Date(0, 0, 0);
            }
        }

        $.TimePicker = function() {
            var widget = this;

            widget.container = $('.ui-timepicker-container');
            widget.ui = widget.container.find('.ui-timepicker');

            if (widget.container.length === 0) {
                widget.container = $('<div></div>').addClass('ui-timepicker-container')
                                    .addClass('ui-timepicker-hidden ui-helper-hidden')
                                    .appendTo('body')
                                    .hide();
                widget.ui = $( '<div></div>' ).addClass('ui-timepicker')
                                    .addClass('ui-widget ui-widget-content ui-menu')
                                    .addClass('ui-corner-all')
                                    .appendTo(widget.container);
                widget.viewport = $('<ul></ul>').addClass( 'ui-timepicker-viewport' )
                                    .appendTo( widget.ui );

                if (JQ_GTE_142) {
                    widget.ui.delegate('a', 'mouseenter.timepicker', function() {
                        // passing false instead of an instance object tells the function
                        // to use the current instance
                        widget.activate(false, $(this).parent());
                    }).delegate('a', 'mouseleave.timepicker', function() {
                        widget.deactivate(false);
                    }).delegate('a', 'click.timepicker', function(event) {
                        event.preventDefault();
                        widget.select(false, $(this).parent());
                    });
                }
            }
        };

        $.TimePicker.count = 0;
        $.TimePicker.instance = function() {
            if (!$.TimePicker._instance) {
                $.TimePicker._instance = new $.TimePicker();
            }
            return $.TimePicker._instance;
        };

        $.TimePicker.prototype = {
            // extracted from from jQuery UI Core
            // http://github,com/jquery/jquery-ui/blob/master/ui/jquery.ui.core.js
            keyCode: {
                ALT: 18,
                BLOQ_MAYUS: 20,
                CTRL: 17,
                DOWN: 40,
                END: 35,
                ENTER: 13,
                HOME: 36,
                LEFT: 37,
                NUMPAD_ENTER: 108,
                PAGE_DOWN: 34,
                PAGE_UP: 33,
                RIGHT: 39,
                SHIFT: 16,
                TAB: 9,
                UP: 38
            },

            _items: function(i, startTime) {
                var widget = this, ul = $('<ul></ul>'), item = null, time, end;

                // interval should be a multiple of 60 if timeFormat is not
                // showing minutes
                if (i.options.timeFormat.indexOf('m') === -1 && i.options.interval % 60 !== 0) {
                    i.options.interval = Math.max(Math.round(i.options.interval / 60), 1) * 60;
                }

                if (startTime) {
                    time = normalize(startTime);
                } else if (i.options.startTime) {
                    time = normalize(i.options.startTime);
                } else {
                    time = normalize(i.options.startHour, i.options.startMinutes);
                }

                end = new Date(time.getTime() + 24 * 60 * 60 * 1000);

                while(time < end) {
                    if (widget._isValidTime(i, time)) {
                        item = $('<li>').addClass('ui-menu-item').appendTo(ul);
                        $('<a>').addClass('ui-corner-all').text($.fn.timepicker.formatTime(i.options.timeFormat, time)).appendTo(item);
                        item.data('time-value', time);
                    }
                    time = new Date(time.getTime() + i.options.interval * 60 * 1000);
                }

                return ul.children();
            },

            _isValidTime: function(i, time) {
                var min = null, max = null;

                time = normalize(time);

                if (i.options.minTime !== null) {
                    min = normalize(i.options.minTime);
                } else if (i.options.minHour !== null || i.options.minMinutes !== null) {
                    min = normalize(i.options.minHour, i.options.minMinutes);
                }

                if (i.options.maxTime !== null) {
                    max = normalize(i.options.maxTime);
                } else if (i.options.maxHour !== null || i.options.maxMinutes !== null) {
                    max = normalize(i.options.maxHour, i.options.maxMinutes);
                }

                if (min !== null && max !== null) {
                    return time >= min && time <= max;
                } else if (min !== null) {
                    return time >= min;
                } else if (max !== null) {
                    return time <= max;
                }

                return true;
            },

            _hasScroll: function() {
                // fix for jQuery 1.6 new prop method
                var m = typeof this.ui.prop !== 'undefined' ? 'prop' : 'attr';
                return this.ui.height() < this.viewport[m]('scrollHeight');
            },

            /**
             * TODO: Write me!
             *
             * @param i
             * @param direction
             * @param edge
             * */
            _move: function(i, direction, edge) {
                var widget = this;
                if (widget.closed()) {
                    widget.open(i);
                }
                if (!widget.active) {
                    widget.activate( i, widget.viewport.children( edge ) );
                    return;
                }
                var next = widget.active[direction + 'All']('.ui-menu-item').eq(0);
                if (next.length) {
                    widget.activate(i, next);
                } else {
                    widget.activate( i, widget.viewport.children( edge ) );
                }
            },

            //
            // protected methods
            //

            register: function(node, options) {
                var widget = this, i = {}; // timepicker instance object

                i.element = $(node);

                if (i.element.data('TimePicker')) {
                    return;
                }

                i.options = $.metadata ? $.extend({}, options, i.element.metadata()) : $.extend({}, options);
                i.widget = widget;

                // proxy functions for the exposed api methods
                $.extend(i, {
                    next: function() {return widget.next(i) ;},
                    previous: function() {return widget.previous(i) ;},
                    first: function() { return widget.first(i) ;},
                    last: function() { return widget.last(i) ;},
                    selected: function() { return widget.selected(i) ;},
                    open: function() { return widget.open(i) ;},
                    close: function() { return widget.close(i) ;},
                    closed: function() { return widget.closed(i) ;},
                    destroy: function() { return widget.destroy(i) ;},

                    parse: function(str) { return widget.parse(i, str) ;},
                    format: function(time, format) { return widget.format(i, time, format); },
                    getTime: function() { return widget.getTime(i) ;},
                    setTime: function(time, silent) { return widget.setTime(i, time, silent); },
                    option: function(name, value) { return widget.option(i, name, value); }
                });

                widget._setDefaultTime(i);
                widget._addInputEventsHandlers(i);

                i.element.data('TimePicker', i);
            },

            _setDefaultTime: function(i) {
                if (i.options.defaultTime === 'now') {
                    i.setTime(normalize(new Date()));
                } else if (i.options.defaultTime && i.options.defaultTime.getFullYear) {
                    i.setTime(normalize(i.options.defaultTime));
                } else if (i.options.defaultTime) {
                    i.setTime($.fn.timepicker.parseTime(i.options.defaultTime));
                }
            },

            _addInputEventsHandlers: function(i) {
                var widget = this;

                i.element.bind('keydown.timepicker', function(event) {
                    switch (event.which || event.keyCode) {
                    case widget.keyCode.ENTER:
                    case widget.keyCode.NUMPAD_ENTER:
                        event.preventDefault();
                        if (widget.closed()) {
                            i.element.trigger('change.timepicker');
                        } else {
                            widget.select(i, widget.active);
                        }
                        break;
                    case widget.keyCode.UP:
                        i.previous();
                        break;
                    case widget.keyCode.DOWN:
                        i.next();
                        break;
                    default:
                        if (!widget.closed()) {
                            i.close(true);
                        }
                        break;
                    }
                }).bind('focus.timepicker', function() {
                    i.open();
                }).bind('blur.timepicker', function() {
                    setTimeout(function() {
                        if (i.element.data('timepicker-user-clicked-outside')) {
                            i.close();
                        }
                    });
                }).bind('change.timepicker', function() {
                    if (i.closed()) {
                        i.setTime($.fn.timepicker.parseTime(i.element.val()));
                    }
                });
            },

            select: function(i, item) {
                var widget = this, instance = i === false ? widget.instance : i;
                widget.setTime(instance, $.fn.timepicker.parseTime(item.children('a').text()));
                widget.close(instance, true);
            },

            activate: function(i, item) {
                var widget = this, instance = i === false ? widget.instance : i;

                if (instance !== widget.instance) {
                    return;
                } else {
                    widget.deactivate();
                }

                if (widget._hasScroll()) {
                    var offset = item.offset().top - widget.ui.offset().top,
                        scroll = widget.viewport.scrollTop(),
                        height = widget.viewport.height();
                    if (offset < 0) {
                        widget.viewport.scrollTop(scroll + offset);
                    } else if (offset >= height) {
                        widget.viewport.scrollTop(scroll + offset - height/2 + item.height());
                    }
                }

                widget.active = item.eq(0).children('a').addClass('ui-state-hover')
                                                        .attr('id', 'ui-active-item')
                                          .end();
            },

            deactivate: function() {
                var widget = this;
                if (!widget.active) { return; }
                widget.active.children('a').removeClass('ui-state-hover').removeAttr('id');
                widget.active = null;
            },

            /**
             * _activate, _deactivate, first, last, next, previous, _move and
             * _hasScroll were extracted from jQuery UI Menu
             * http://github,com/jquery/jquery-ui/blob/menu/ui/jquery.ui.menu.js
             */

            //
            // public methods
            //

            next: function(i) {
                if (this.closed() || this.instance === i) {
                    this._move(i, 'next', '.ui-menu-item:first');
                }
                return i.element;
            },

            previous: function(i) {
                if (this.closed() || this.instance === i) {
                    this._move(i, 'prev', '.ui-menu-item:last');
                }
                return i.element;
            },

            first: function(i) {
                if (this.instance === i) {
                    return this.active && this.active.prevAll('.ui-menu-item').length === 0;
                }
                return false;
            },

            last: function(i) {
                if (this.instance === i) {
                    return this.active && this.active.nextAll('.ui-menu-item').length === 0;
                }
                return false;
            },

            selected: function(i) {
                if (this.instance === i)  {
                    return this.active ? this.active : null;
                }
                return null;
            },

            open: function(i) {
                var widget = this,
                    selectedTime = i.getTime(),
                    arrange = i.options.dynamic && selectedTime;

                // return if dropdown is disabled
                if (!i.options.dropdown) { return i.element; }

                // fix for issue https://github.com/wvega/timepicker/issues/56
                // idea from https://prototype.lighthouseapp.com/projects/8887/tickets/248-results-popup-from-ajaxautocompleter-disappear-when-user-clicks-on-scrollbars-in-ie6ie7
                i.element.data('timepicker-event-namespace', Math.random());

                $(document).bind('click.timepicker-' + i.element.data('timepicker-event-namespace'), function(event) {
                    if (i.element.get(0) === event.target) {
                        i.element.data('timepicker-user-clicked-outside', false);
                    } else {
                        i.element.data('timepicker-user-clicked-outside', true).blur();
                    }
                });

                // if a date is already selected and options.dynamic is true,
                // arrange the items in the list so the first item is
                // cronologically right after the selected date.
                // TODO: set selectedTime
                if (i.rebuild || !i.items || arrange) {
                    i.items = widget._items(i, arrange ? selectedTime : null);
                }

                // remove old li elements keeping associated events, then append
                // the new li elements to the ul
                if (i.rebuild || widget.instance !== i || arrange) {
                    // handle menu events when using jQuery versions previous to
                    // 1.4.2 (thanks to Brian Link)
                    // http://github.com/wvega/timepicker/issues#issue/4
                    if (!JQ_GTE_142) {
                        widget.viewport.children().remove();
                        widget.viewport.append(i.items);
                        widget.viewport.find('a').bind('mouseover.timepicker', function() {
                            widget.activate(i, $(this).parent());
                        }).bind('mouseout.timepicker', function() {
                            widget.deactivate(i);
                        }).bind('click.timepicker', function(event) {
                            event.preventDefault();
                            widget.select(i, $(this).parent());
                        });
                    } else {
                        widget.viewport.children().detach();
                        widget.viewport.append(i.items);
                    }
                }

                i.rebuild = false;

                // theme
                widget.container.removeClass('ui-helper-hidden ui-timepicker-hidden ui-timepicker-standard ui-timepicker-corners').show();

                switch (i.options.theme) {
                case 'standard':
                    widget.container.addClass('ui-timepicker-standard');
                    break;
                case 'standard-rounded-corners':
                    widget.container.addClass('ui-timepicker-standard ui-timepicker-corners');
                    break;
                default:
                    break;
                }

                /* resize ui */

                // we are hiding the scrollbar in the dropdown menu adding a 40px
                // padding to the wrapper element making the scrollbar appear in the
                // part of the wrapper that's hidden by the container (a DIV).
                if ( ! widget.container.hasClass( 'ui-timepicker-no-scrollbar' ) && ! i.options.scrollbar ) {
                    widget.container.addClass( 'ui-timepicker-no-scrollbar' );
                    widget.viewport.css( { paddingRight: 40 } );
                }

                var containerDecorationHeight = widget.container.outerHeight() - widget.container.height(),
                    zindex = i.options.zindex ? i.options.zindex : i.element.offsetParent().css( 'z-index' ),
                    elementOffset = i.element.offset();

                // position the container right below the element, or as close to as possible.
                widget.container.css( {
                    top: elementOffset.top + i.element.outerHeight(),
                    left: elementOffset.left
                } );

                // then show the container so that the browser can consider the timepicker's
                // height to calculate the page's total height and decide if adding scrollbars
                // is necessary.
                widget.container.show();

                // now we need to calculate the element offset and position the container again.
                // If the browser added scrollbars, the container's original position is not aligned
                // with the element's final position. This step fixes that problem.
                widget.container.css( {
                    left: i.element.offset().left,
                    height: widget.ui.outerHeight() + containerDecorationHeight,
                    width: i.element.outerWidth(),
                    zIndex: zindex,
                    cursor: 'default'
                } );

                var calculatedWidth = widget.container.width() - ( widget.ui.outerWidth() - widget.ui.width() );

                // hardcode ui, viewport and item's width. I couldn't get it to work using CSS only
                widget.ui.css( { width: calculatedWidth } );
                widget.viewport.css( { width: calculatedWidth } );
                i.items.css( { width: calculatedWidth } );

                // XXX: what's this line doing here?
                widget.instance = i;

                // try to match input field's current value with an item in the
                // dropdown
                if (selectedTime) {
                    i.items.each(function() {
                        var item = $(this), time;

                        if (!JQ_GTE_142) {
                            time = $.fn.timepicker.parseTime(item.find('a').text());
                        } else {
                            time = item.data('time-value');
                        }

                        if (time.getTime() === selectedTime.getTime()) {
                            widget.activate(i, item);

                            // scroll to active item
                            //widget.container.scrollTop(item.position().top);
                            return false;
                        }
                        return true;
                    });
                } else {
                    widget.deactivate(i);
                }

                // don't break the chain
                return i.element;
            },

            close: function(i) {
                var widget = this;

                if (widget.instance === i) {
                    widget.container.addClass('ui-helper-hidden ui-timepicker-hidden').hide();
                    widget.ui.scrollTop(0);
                    widget.ui.children().removeClass('ui-state-hover');
                }

                $(document).unbind('click.timepicker-' + i.element.data('timepicker-event-namespace'));

                return i.element;
            },

            closed: function() {
                return this.ui.is(':hidden');
            },

            destroy: function(i) {
                var widget = this;
                widget.close(i, true);
                return i.element.unbind('.timepicker').data('TimePicker', null);
            },

            //

            parse: function(i, str) {
                return $.fn.timepicker.parseTime(str);
            },

            format: function(i, time, format) {
                format = format || i.options.timeFormat;
                return $.fn.timepicker.formatTime(format, time);
            },

            getTime: function(i) {
                var widget = this,
                    current = $.fn.timepicker.parseTime(i.element.val());

                // if current value is not valid, we return null.
                // stored Date object is ignored, because the current value
                // (valid or invalid) always takes priority
                if (current instanceof Date && !widget._isValidTime(i, current)) {
                    return null;
                } else if (current instanceof Date && i.selectedTime) {
                    // if the textfield's value and the stored Date object
                    // have the same representation using current format
                    // we prefer the stored Date object to avoid unnecesary
                    // lost of precision.
                    if (i.format(current) === i.format(i.selectedTime)) {
                        return i.selectedTime;
                    } else {
                        return current;
                    }
                } else if (current instanceof Date) {
                    return current;
                } else {
                    return null;
                }
            },

            setTime: function(i, time, silent) {
                var widget = this, previous = i.selectedTime;

                if (typeof time === 'string') {
                    time = i.parse(time);
                }

                if (time && time.getMinutes && widget._isValidTime(i, time)) {
                    time = normalize(time);
                    i.selectedTime = time;
                    i.element.val(i.format(time, i.options.timeFormat));

                    // TODO: add documentaion about setTime being chainable
                    if (silent) { return i; }
                } else {
                    i.selectedTime = null;
                }

                // custom change event and change callback
                // TODO: add documentation about this event
                if (previous !== null || i.selectedTime !== null) {
                    i.element.trigger('time-change', [time]);
                    if ($.isFunction(i.options.change)) {
                        i.options.change.apply(i.element, [time]);
                    }
                }

                return i.element;
            },

            option: function(i, name, value) {
                if (typeof value === 'undefined') {
                    return i.options[name];
                }

                var time = i.getTime(),
                    options, destructive;

                if (typeof name === 'string') {
                    options = {};
                    options[name] = value;
                } else {
                    options = name;
                }

                // some options require rebuilding the dropdown items
                destructive = ['minHour', 'minMinutes', 'minTime',
                               'maxHour', 'maxMinutes', 'maxTime',
                               'startHour', 'startMinutes', 'startTime',
                               'timeFormat', 'interval', 'dropdown'];


                $.each(options, function(name) {
                    i.options[name] = options[name];
                    i.rebuild = i.rebuild || $.inArray(name, destructive) > -1;
                });

                if (i.rebuild) {
                    i.setTime(time);
                }
            }
        };

        $.TimePicker.defaults =  {
            timeFormat: 'hh:mm p',
            minHour: null,
            minMinutes: null,
            minTime: null,
            maxHour: null,
            maxMinutes: null,
            maxTime: null,
            startHour: null,
            startMinutes: null,
            startTime: null,
            interval: 30,
            dynamic: true,
            theme: 'standard',
            zindex: null,
            dropdown: true,
            scrollbar: false,
            // callbacks
            change: function(/*time*/) {}
        };

        $.TimePicker.methods = {
            chainable: [
                'next',
                'previous',
                'open',
                'close',
                'destroy',
                'setTime'
            ]
        };

        $.fn.timepicker = function(options) {
            // support calling API methods using the following syntax:
            //   $(...).timepicker('parse', '11p');
            if (typeof options === 'string') {
                var args = Array.prototype.slice.call(arguments, 1),
                    method, result;

                // chainable API methods
                if (options === 'option' && arguments.length > 2) {
                    method = 'each';
                } else if ($.inArray(options, $.TimePicker.methods.chainable) !== -1) {
                    method = 'each';
                // API methods that return a value
                } else {
                    method = 'map';
                }

                result = this[method](function() {
                    var element = $(this), i = element.data('TimePicker');
                    if (typeof i === 'object') {
                        return i[options].apply(i, args);
                    }
                });

                if (method === 'map' && this.length === 1) {
                    return $.makeArray(result).shift();
                } else if (method === 'map') {
                    return $.makeArray(result);
                } else {
                    return result;
                }
            }

            // calling the constructor again on a jQuery object with a single
            // element returns a reference to a TimePicker object.
            if (this.length === 1 && this.data('TimePicker')) {
                return this.data('TimePicker');
            }

            var globals = $.extend({}, $.TimePicker.defaults, options);

            return this.each(function() {
                $.TimePicker.instance().register(this, globals);
            });
        };

        /**
         * TODO: documentation
         */
        $.fn.timepicker.formatTime = function(format, time) {
            var hours = time.getHours(),
                hours12 = hours % 12,
                minutes = time.getMinutes(),
                seconds = time.getSeconds(),
                replacements = {
                    hh: pad((hours12 === 0 ? 12 : hours12).toString(), '0', 2),
                    HH: pad(hours.toString(), '0', 2),
                    mm: pad(minutes.toString(), '0', 2),
                    ss: pad(seconds.toString(), '0', 2),
                    h: (hours12 === 0 ? 12 : hours12),
                    H: hours,
                    m: minutes,
                    s: seconds,
                    p: hours > 11 ? 'PM' : 'AM'
                },
                str = format, k = '';
            for (k in replacements) {
                if (replacements.hasOwnProperty(k)) {
                    str = str.replace(new RegExp(k,'g'), replacements[k]);
                }
            }
            // replacements is not guaranteed to be order and the 'p' can cause problems
            str = str.replace(new RegExp('a','g'), hours > 11 ? 'pm' : 'am');
            return str;
        };

        /**
         * Convert a string representing a given time into a Date object.
         *
         * The Date object will have attributes others than hours, minutes and
         * seconds set to current local time values. The function will return
         * false if given string can't be converted.
         *
         * If there is an 'a' in the string we set am to true, if there is a 'p'
         * we set pm to true, if both are present only am is setted to true.
         *
         * All non-digit characters are removed from the string before trying to
         * parse the time.
         *
         * ''       can't be converted and the function returns false.
         * '1'      is converted to     01:00:00 am
         * '11'     is converted to     11:00:00 am
         * '111'    is converted to     01:11:00 am
         * '1111'   is converted to     11:11:00 am
         * '11111'  is converted to     01:11:11 am
         * '111111' is converted to     11:11:11 am
         *
         * Only the first six (or less) characters are considered.
         *
         * Special case:
         *
         * When hours is greater than 24 and the last digit is less or equal than 6, and minutes
         * and seconds are less or equal than 60, we append a trailing zero and
         * start parsing process again. Examples:
         *
         * '95' is treated as '950' and converted to 09:50:00 am
         * '46' is treated as '460' and converted to 05:00:00 am
         * '57' can't be converted and the function returns false.
         *
         * For a detailed list of supported formats check the unit tests at
         * http://github.com/wvega/timepicker/tree/master/tests/
         */
        $.fn.timepicker.parseTime = (function() {
            var patterns = [
                    // 1, 12, 123, 1234, 12345, 123456
                    [/^(\d+)$/, '$1'],
                    // :1, :2, :3, :4 ... :9
                    [/^:(\d)$/, '$10'],
                    // :1, :12, :123, :1234 ...
                    [/^:(\d+)/, '$1'],
                    // 6:06, 5:59, 5:8
                    [/^(\d):([7-9])$/, '0$10$2'],
                    [/^(\d):(\d\d)$/, '$1$2'],
                    [/^(\d):(\d{1,})$/, '0$1$20'],
                    // 10:8, 10:10, 10:34
                    [/^(\d\d):([7-9])$/, '$10$2'],
                    [/^(\d\d):(\d)$/, '$1$20'],
                    [/^(\d\d):(\d*)$/, '$1$2'],
                    // 123:4, 1234:456
                    [/^(\d{3,}):(\d)$/, '$10$2'],
                    [/^(\d{3,}):(\d{2,})/, '$1$2'],
                    //
                    [/^(\d):(\d):(\d)$/, '0$10$20$3'],
                    [/^(\d{1,2}):(\d):(\d\d)/, '$10$2$3']
                ],
                length = patterns.length;

            return function(str) {
                var time = normalize(new Date()),
                    am = false, pm = false, h = false, m = false, s = false;

                if (typeof str === 'undefined' || !str.toLowerCase) { return null; }

                str = str.toLowerCase();
                am = /a/.test(str);
                pm = am ? false : /p/.test(str);
                str = str.replace(/[^0-9:]/g, '').replace(/:+/g, ':');

                for (var k = 0; k < length; k = k + 1) {
                    if (patterns[k][0].test(str)) {
                        str = str.replace(patterns[k][0], patterns[k][1]);
                        break;
                    }
                }
                str = str.replace(/:/g, '');

                if (str.length === 1) {
                    h = str;
                } else if (str.length === 2) {
                    h = str;
                } else if (str.length === 3 || str.length === 5) {
                    h = str.substr(0, 1);
                    m = str.substr(1, 2);
                    s = str.substr(3, 2);
                } else if (str.length === 4 || str.length > 5) {
                    h = str.substr(0, 2);
                    m = str.substr(2, 2);
                    s = str.substr(4, 2);
                }

                if (str.length > 0 && str.length < 5) {
                    if (str.length < 3) {
                        m = 0;
                    }
                    s = 0;
                }

                if (h === false || m === false || s === false) {
                    return false;
                }

                h = parseInt(h, 10);
                m = parseInt(m, 10);
                s = parseInt(s, 10);

                if (am && h === 12) {
                    h = 0;
                } else if (pm && h < 12) {
                    h = h + 12;
                }

                if (h > 24) {
                    if (str.length >= 6) {
                        return $.fn.timepicker.parseTime(str.substr(0,5));
                    } else {
                        return $.fn.timepicker.parseTime(str + '0' + (am ? 'a' : '') + (pm ? 'p' : ''));
                    }
                } else {
                    time.setHours(h, m, s);
                    return time;
                }
            };
        })();
    })();
}));

;/*})'"*/
;/*})'"*/
/**
 * Attaches the calendar behavior to all required fields
 */
(function($) {
  function makeFocusHandler(e) {
    if (!$(this).hasClass('date-popup-init')) {
      var datePopup = e.data;
      // Explicitely filter the methods we accept.
      switch (datePopup.func) {
        case 'datepicker':
          $(this)
            .datepicker(datePopup.settings)
            .addClass('date-popup-init');
          $(this).click(function(){
            $(this).focus();
          });
          break;

        case 'timeEntry':
          $(this)
            .timeEntry(datePopup.settings)
            .addClass('date-popup-init');
          $(this).click(function(){
            $(this).focus();
          });
          break;

        case 'timepicker':
          // Translate the PHP date format into the style the timepicker uses.
          datePopup.settings.timeFormat = datePopup.settings.timeFormat
            // 12-hour, leading zero,
            .replace('h', 'hh')
            // 12-hour, no leading zero.
            .replace('g', 'h')
            // 24-hour, leading zero.
            .replace('H', 'HH')
            // 24-hour, no leading zero.
            .replace('G', 'H')
            // AM/PM.
            .replace('A', 'p')
            // Minutes with leading zero.
            .replace('i', 'mm')
            // Seconds with leading zero.
            .replace('s', 'ss');

          datePopup.settings.startTime = new Date(datePopup.settings.startTime);
          $(this)
            .timepicker(datePopup.settings)
            .addClass('date-popup-init');
          $(this).click(function(){
            $(this).focus();
          });
          break;
      }
    }
  }

  Drupal.behaviors.date_popup = {
    attach: function (context) {
      for (var id in Drupal.settings.datePopup) {
        $('#'+ id).bind('focus', Drupal.settings.datePopup[id], makeFocusHandler);
      }
    }
  };
})(jQuery);

;/*})'"*/
;/*})'"*/
/**
 * @file
 * Swaps out the datepicker with HTML date inputs on mobile resolutions.
 */

(function ($) {
  var isMobile = /iPhone|iPad|iPod|Android|BlackBerry|Opera Mini|IEMobile/i.test(navigator.userAgent);
  if (isMobile) {
    Drupal.behaviors.date_popup = {
      attach: function (context, settings) {
        var timestamp;
        var dateFields;
        var self = this;

        // There are two phases to this process, which only run if the current screen width is < 768px:
        // 1. On page load, change all the datepicker text inputs to date inputs, and format the initial value of the field to
        //    be the format that date inputs expect, which is YYYY-MM-DD.
        // 2. On form submit, change all of the altered date inputs back into text fields, and change the format of them
        //    to match the original format of the field, which luckily gets passed into Drupal.settings per-field already.
        // Cycle through all of the fields originally set by the date_popup module to have the popup on them,
        // so that we can make sure that we only operate on the right fields.

        // dateFields will always contain the most recent dateFields on the whole page
        this.dateFields = this.getDateFields(context, settings);

        // Catch client-side validation errors (cv will always fail because field type is switched to html5)
        $(document).off('clientsideValidationInitialized').on('clientsideValidationInitialized', function(e) {
          var $input;

          for (var id in self.dateFields) {
            // do not limit jquery selector to context because cv events are global
            $input = $('#' + id);

            // remove this element from client-side validation rules in the parent form
            delete $input.parents('form').first().validate().settings.rules[$input.attr('name')];
          }
        });

        for (var id in this.dateFields) {
          var $input = $('#' + id, context); // The input itself.

          // Prevent default UI datepicker from showing.
          if (typeof $input.datepicker === 'function') {
            $input.datepicker({
              beforeShow: function() {
                return false;
              }
            });
          }

          var initialDate = $input.val();

          // Change the input type to date. Can't use jQuery's .attr() because jQuery doesn't allow you to change "type",
          // so we have to fall back to regular old JS for this one line.
          try {
            $input.removeAttr('value');
            $input[0].type = 'date';
          } catch (e) {
            // ignore any errors when switching date format
          }


          // If there's a default value in the field, then we have to reformat it to be in the YYYY-MM-DD format that
          // HTML5 date fields expect. Otherwise it would just be ignored altogether, which is bad bad bad.
          if (initialDate) {
            if (typeof Drupal.settings.datePopup[id] !== 'undefined' && typeof Drupal.settings.datePopup[id].settings.dateFormat === 'string') {
              timestamp = Date.parse($.datepicker.parseDate(Drupal.settings.datePopup[id].settings.dateFormat, initialDate));
            } else {
              timestamp = Date.parse(initialDate);
            }
            $input.val($.datepicker.formatDate('yy-mm-dd', new Date(timestamp)));
          }

          // Ensure inputs reverted on form submission.
          $input.parents('form').once('mobile-popup').bind('submit', function () {
            if ($(this).valid && $(this).valid() === true) {
              Drupal.behaviors.date_popup.revertInputs(context, settings);
            }
          });
        }
      },

      /**
       * Revert inputs on AJAX detach.
       *
       * @param context
       * @param settings
       */
      detach: function (context, settings) {
        this.revertInputs(context, settings);
      },

      /**
       * Change inputs back to original format.
       *
       * @param context
       * @param settings
       */
      revertInputs: function (context, settings) {
        var dateFields = this.getDateFields(context, settings);
        for (var id in dateFields) {
          Drupal.behaviors.date_popup.inputDateToText(id);
        }
      },

      /**
       * Helper function to get valid date fields from settings
       *
       * @param context
       * @param settings
       * @returns {{}|*}
       */
      getDateFields: function (context, settings) {
        var dateFields = {};
        for (var id in settings.datePopup) {
          var $input = $('#' + id, context); // The input itself.
          // Verify element exists.
          if ($input.length != 0) {
            // The date_popup module also handles the time fields, and we want to leave those alone, so we short
            // circuit and continue the loop here if we're not currently looking at a date field.
            if (settings.datePopup[id].func !== 'datepicker') {
              continue;
            }
            dateFields[id] = settings.datePopup[id];
          }
        }
        return dateFields;
      },

      /**
       * Changes altered date inputs back to text fields.
       * @param thisId
       */
      inputDateToText: function (thisId) {
        var $thisInput = $('#' + thisId);

        // If this input isn't of type date or datepicker.
        if ($thisInput[0].type !== 'date' || Drupal.settings.datePopup[thisId].func !== 'datepicker') {
          return;
        }

        // The original expected format of the field is provided in Drupal.settings for us.
        var format = Drupal.settings.datePopup[thisId].settings.dateFormat;
        var formattedDate;

        if ($thisInput.val()) {

          // We have the value in the format YYYY-MM-DD, most likely, since that's what HTML5 date inputs pass over
          // the wire, so we have to check to make sure that's really the format, and then reformat it.
          var dateParts = $thisInput.val().split('-');

          if (dateParts.length === 1) {
            // Hey, look at that, it's not in YYYY-MM-DD format after all, so just leave as-is.
            formattedDate = $thisInput.val();

          } else {
            // This is the common case. We're looking at YYYY-MM-DD date input format, and we have to reformat it
            // to match the expected format for that particular field, which can be many different things.
            // Luckily, $.datepicker.formatDate() exists to make that easy for us.
            var year = parseInt(dateParts[0]);
            var month = parseInt(dateParts[1]);
            var day = parseInt(dateParts[2]);
            formattedDate = $.datepicker.formatDate(format, new Date(year, month - 1, day));
          }
        } else {
          // This is an empty field, so just set it to an empty string.
          formattedDate = '';
        }

        $thisInput[0].type = 'text'; // Back to 'text' we go.
        $thisInput.val(formattedDate); // Set the value, and we're done, and ready to submit the form.
      }
    };
  }
})(jQuery);

;/*})'"*/
;/*})'"*/
(function ($) {
  "use strict";

  $(document).bind('clientsideValidationAddCustomRules', function(event){
    // Clientside validation of phone numbers. Overwrites the default from
    // the client side validation integration. Aims to be much faster.
    $.validator.addMethod("phone", function(value, element, param) {
      // Do not fire on every keystroke. Ajax callbacks are expensive.
      // if (this.settings['name_event'] == 'onkeyup') {
      //   return true;
      // }
      // Empty, no processing needed and - ok if optional.
      if (!value.toString().length) {
        return this.optional(element);
      }
      // Skip if library isn't loaded.
      if (typeof (libphonenumber) === 'undefined') {
        return this.optional(element);
      }
      var result = false;
      var orgVal = value;
      var formattedInput;

      // Replace 00 with +.
      value = value.replace(/^00/, '+');

      var asYouType =  new libphonenumber.AsYouType('CH');
      if (asYouType) {
        formattedInput = asYouType.input(value);
      }
      try {
        var phone = libphonenumber.parsePhoneNumber(value, 'CH');
      }
      catch(err) {
        return result;
      }
      if (phone && phone.isValid()) {
        formattedInput = phone.formatInternational();
        result = true;
      }
      if (orgVal !== formattedInput) {
        // Set modified value while maintaining cursor position.
        if (Drupal.Pa && Drupal.Pa.GetCursorPostition) {
          var pos = Drupal.Pa.GetCursorPostition(element);
          // If stuff was deleted move the cursor accordingly.
          pos -= orgVal.length - formattedInput.length;
        }
        $(element).val(formattedInput);
        if (Drupal.Pa && Drupal.Pa.SetCursorPostition) {
          Drupal.Pa.SetCursorPostition(element, pos);
        }
      }
      return result;
    }, $.format('Please fill in a valid phone number'));
  });

})(jQuery);




;/*})'"*/
;/*})'"*/
(function ($) {

  Drupal.shoppingCartIcon = {
    timeouts: {},
    fetch: function() {
      var elem = jQuery('.shopping-cart-icon');
      // Check that the element is there.
      if (elem.length) {
        $.ajax({
          url: Drupal.settings.basePath + Drupal.settings.pathPrefix + 'js/shopping_cart_icon',
          dataType: "json",
          data: {
            js_module: 'postauto',
            js_callback: 'shopping_cart_icon',
            js_token: Drupal.settings.js && Drupal.settings.js.tokens && Drupal.settings.js.tokens['postauto-shopping_cart_icon'] || ''
          }
        }).done(function( data ) {
          if (data) {
            $(elem).replaceWith(data);
          }
        });
      }
    }
  };
  Drupal.behaviors.shoppingCartIcon = {
    attach: function(context, settings) {
      $('.pane-postauto-shopping-cart-icon', context).once(function(i, elem) {
        Drupal.shoppingCartIcon.fetch();
      });
    }
  };

})(jQuery);

;/*})'"*/
;/*})'"*/
/**
 * jQuery Validation Plugin 1.11.0pre
 *
 * http://bassistance.de/jquery-plugins/jquery-plugin-validation/
 * http://docs.jquery.com/Plugins/Validation
 *
 * Copyright (c) 2012 Jörn Zaefferer
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 */

(function($) {

$.extend($.fn, {
	// http://docs.jquery.com/Plugins/Validation/validate
	validate: function( options ) {

		// if nothing is selected, return nothing; can't chain anyway
		if (!this.length) {
			if (options && options.debug && window.console) {
				console.warn( "nothing selected, can't validate, returning nothing" );
			}
			return;
		}

		// check if a validator for this form was already created
		var validator = $.data(this[0], 'validator');
		if ( validator ) {
			return validator;
		}

		// Add novalidate tag if HTML5.
		this.attr('novalidate', 'novalidate');

		validator = new $.validator( options, this[0] );
		$.data(this[0], 'validator', validator);

		if ( validator.settings.onsubmit ) {

			this.validateDelegate( ":submit", "click", function(ev) {
				validator.submitButton = ev.target;
				// allow suppressing validation by adding a cancel class to the submit button
				if ( $(ev.target).hasClass('cancel') ) {
					validator.cancelSubmit = true;
				}
			});

			// validate the form on submit
			this.submit( function( event ) {
				// Ensure the proper event name is set.
				validator.settings['name_event'] = "on" + event.type.replace(/^validate/, "");
				if ( validator.settings.debug ) {
					// prevent form submit to be able to see console output
					event.preventDefault();
				}
				function handle() {
					var hidden;
					if ( validator.settings.submitHandler ) {
						if (validator.submitButton) {
							// insert a hidden input as a replacement for the missing submit button
							hidden = $("<input type='hidden'/>").attr("name", validator.submitButton.name).val(validator.submitButton.value).appendTo(validator.currentForm);
						}
						validator.settings.submitHandler.call( validator, validator.currentForm, event );
						if (validator.submitButton) {
							// and clean up afterwards; thanks to no-block-scope, hidden can be referenced
							hidden.remove();
						}
						return false;
					}
					return true;
				}

				// prevent submit for invalid forms or custom submit handlers
				if ( validator.cancelSubmit ) {
					validator.cancelSubmit = false;
					return handle();
				}
				if ( validator.form() ) {
					if ( validator.pendingRequest ) {
						validator.formSubmitted = true;
						return false;
					}
					return handle();
				} else {
					validator.focusInvalid();
					return false;
				}
			});
		}

		return validator;
	},
	// http://docs.jquery.com/Plugins/Validation/valid
	valid: function() {
		if ( $(this[0]).is('form')) {
			return this.validate().form();
		} else {
			var valid = true;
			var validator = $(this[0].form).validate();
			this.each(function() {
				valid &= validator.element(this);
			});
			return valid;
		}
	},
	// attributes: space seperated list of attributes to retrieve and remove
	removeAttrs: function(attributes) {
		var result = {},
			$element = this;
		$.each(attributes.split(/\s/), function(index, value) {
			result[value] = $element.attr(value);
			$element.removeAttr(value);
		});
		return result;
	},
	// http://docs.jquery.com/Plugins/Validation/rules
	rules: function(command, argument) {
		var element = this[0];

		if (command) {
			var settings = $.data(element.form, 'validator').settings;
			var staticRules = settings.rules;
			var existingRules = $.validator.staticRules(element);
			switch(command) {
			case "add":
				$.extend(existingRules, $.validator.normalizeRule(argument));
				staticRules[element.name] = existingRules;
				if (argument.messages) {
					settings.messages[element.name] = $.extend( settings.messages[element.name], argument.messages );
				}
				break;
			case "remove":
				if (!argument) {
					delete staticRules[element.name];
					return existingRules;
				}
				var filtered = {};
				$.each(argument.split(/\s/), function(index, method) {
					filtered[method] = existingRules[method];
					delete existingRules[method];
				});
				return filtered;
			}
		}

		var data = $.validator.normalizeRules(
		$.extend(
			{},
			$.validator.classRules(element),
			$.validator.attributeRules(element),
			$.validator.dataRules(element),
			$.validator.staticRules(element)
		), element);

		// make sure required is at front
		if (data.required) {
			var param = data.required;
			delete data.required;
			data = $.extend({required: param}, data);
		}

		return data;
	}
});

// Custom selectors
$.extend($.expr[":"], {
	// http://docs.jquery.com/Plugins/Validation/blank
	blank: function(a) {return !$.trim("" + a.value);},
	// http://docs.jquery.com/Plugins/Validation/filled
	filled: function(a) {return !!$.trim("" + a.value);},
	// http://docs.jquery.com/Plugins/Validation/unchecked
	unchecked: function(a) {return !a.checked;}
});

// constructor for validator
$.validator = function( options, form ) {
	this.settings = $.extend( true, {}, $.validator.defaults, options );
	this.currentForm = form;
	this.init();
};

$.validator.format = function(source, params) {
	if ( arguments.length === 1 ) {
		return function() {
			var args = $.makeArray(arguments);
			args.unshift(source);
			return $.validator.format.apply( this, args );
		};
	}
	if ( arguments.length > 2 && params.constructor !== Array  ) {
		params = $.makeArray(arguments).slice(1);
	}
	if ( params.constructor !== Array ) {
		params = [ params ];
	}
	$.each(params, function(i, n) {
		source = source.replace(new RegExp("\\{" + i + "\\}", "g"), n);
	});
	return source;
};

$.extend($.validator, {

	defaults: {
		messages: {},
		groups: {},
		rules: {},
		errorClass: "error",
		validClass: "valid",
		errorElement: "label",
		focusInvalid: true,
		errorContainer: $( [] ),
		errorLabelContainer: $( [] ),
		onsubmit: true,
		ignore: ":hidden",
		ignoreTitle: false,
		onfocusin: function(element, event) {
			this.lastActive = element;

			// hide error label and remove error class on focus if enabled
			if ( this.settings.focusCleanup && !this.blockFocusCleanup ) {
				if ( this.settings.unhighlight ) {
					this.settings.unhighlight.call( this, element, this.settings.errorClass, this.settings.validClass );
				}
				this.addWrapper(this.errorsFor(element)).hide();
			}
		},
		onfocusout: function(element, event) {
			if ( !this.checkable(element) && (element.name in this.submitted || !this.optional(element)) ) {
				this.element(element);
			}
		},
		onkeyup: function(element, event) {
			if ( event.which === 9 && this.elementValue(element) === '' ) {
				return;
			} else if ( element.name in this.submitted || element === this.lastElement ) {
				this.element(element);
			}
		},
		onclick: function(element, event) {
			// click on selects, radiobuttons and checkboxes
			if ( element.name in this.submitted ) {
				this.element(element);
			}
			// or option elements, check parent select in that case
			else if (element.parentNode.name in this.submitted) {
				this.element(element.parentNode);
			}
		},
		highlight: function(element, errorClass, validClass) {
			if (element.type === 'radio') {
				this.findByName(element.name).addClass(errorClass).removeClass(validClass);
			} else {
				$(element).addClass(errorClass).removeClass(validClass);
			}
		},
		unhighlight: function(element, errorClass, validClass) {
			if (element.type === 'radio') {
				this.findByName(element.name).removeClass(errorClass).addClass(validClass);
			} else {
				$(element).removeClass(errorClass).addClass(validClass);
			}
		}
	},

	// http://docs.jquery.com/Plugins/Validation/Validator/setDefaults
	setDefaults: function(settings) {
		$.extend( $.validator.defaults, settings );
	},

	messages: {
		required: "This field is required.",
		remote: "Please fix this field.",
		email: "Please enter a valid email address.",
		url: "Please enter a valid URL.",
		date: "Please enter a valid date.",
		dateISO: "Please enter a valid date (ISO).",
		number: "Please enter a valid number.",
		digits: "Please enter only digits.",
		creditcard: "Please enter a valid credit card number.",
		equalTo: "Please enter the same value again.",
		maxlength: $.validator.format("Please enter no more than {0} characters."),
		minlength: $.validator.format("Please enter at least {0} characters."),
		rangelength: $.validator.format("Please enter a value between {0} and {1} characters long."),
		range: $.validator.format("Please enter a value between {0} and {1}."),
		max: $.validator.format("Please enter a value less than or equal to {0}."),
		min: $.validator.format("Please enter a value greater than or equal to {0}.")
	},

	autoCreateRanges: false,

	prototype: {

		init: function() {
			this.labelContainer = $(this.settings.errorLabelContainer);
			this.errorContext = this.labelContainer.length && this.labelContainer || $(this.currentForm);
			this.containers = $(this.settings.errorContainer).add( this.settings.errorLabelContainer );
			this.submitted = {};
			this.valueCache = {};
			this.pendingRequest = 0;
			this.pending = {};
			this.invalid = {};
			this.reset();

			var groups = (this.groups = {});
			$.each(this.settings.groups, function(key, value) {
				if (typeof value === "string") {
					value = value.split(/\s/);
				}
				$.each(value, function(index, name) {
					groups[name] = key;
				});
			});
			var rules = this.settings.rules;
			$.each(rules, function(key, value) {
				rules[key] = $.validator.normalizeRule(value);
			});

			function delegate(event) {
				var validator = $.data(this[0].form, "validator"),
					eventType = "on" + event.type.replace(/^validate/, "");
				if (validator.settings[eventType]) {
					validator.settings['name_event'] = eventType;
					validator.settings[eventType].call(validator, this[0], event);
				}
			}
			$(this.currentForm)
				.validateDelegate(":text, [type='password'], [type='file'], select, textarea, " +
					"[type='number'], [type='search'] ,[type='tel'], [type='url'], " +
					"[type='email'], [type='datetime'], [type='date'], [type='month'], " +
					"[type='week'], [type='time'], [type='datetime-local'], " +
					"[type='range'], [type='color'] ",
					"focusin focusout keyup", delegate)
				.validateDelegate("[type='radio'], [type='checkbox'], select, option", "click", delegate);

			if (this.settings.invalidHandler) {
				$(this.currentForm).bind("invalid-form.validate", this.settings.invalidHandler);
			}
		},

		// http://docs.jquery.com/Plugins/Validation/Validator/form
		form: function() {
			this.checkForm();
			$.extend(this.submitted, this.errorMap);
			this.invalid = $.extend({}, this.errorMap);
			if (!this.valid()) {
				$(this.currentForm).triggerHandler("invalid-form", [this]);
			}
			this.showErrors();
			return this.valid();
		},

		checkForm: function() {
			this.prepareForm();
			for ( var i = 0, elements = (this.currentElements = this.elements()); elements[i]; i++ ) {
				this.check( elements[i] );
			}
			return this.valid();
		},

		// http://docs.jquery.com/Plugins/Validation/Validator/element
		element: function( element ) {
			element = this.validationTargetFor( this.clean( element ) );
			this.lastElement = element;
			this.prepareElement( element );
			this.currentElements = $(element);
			var result = this.check( element ) !== false;
			if (result) {
				delete this.invalid[element.name];
			} else {
				this.invalid[element.name] = true;
			}
			if ( !this.numberOfInvalids() ) {
				// Hide error containers on last error
				this.toHide = this.toHide.add( this.containers );
			}
			this.showErrors();
			return result;
		},

		// http://docs.jquery.com/Plugins/Validation/Validator/showErrors
		showErrors: function(errors) {
			if(errors) {
				// add items to error list and map
				$.extend( this.errorMap, errors );
				this.errorList = [];
				for ( var name in errors ) {
					this.errorList.push({
						message: errors[name],
						element: this.findByName(name)[0]
					});
				}
				// remove items from success list
				this.successList = $.grep( this.successList, function(element) {
					return !(element.name in errors);
				});
			}
			if (this.settings.showErrors) {
				this.settings.showErrors.call( this, this.errorMap, this.errorList );
			} else {
				this.defaultShowErrors();
			}
		},

		// http://docs.jquery.com/Plugins/Validation/Validator/resetForm
		resetForm: function() {
			if ( $.fn.resetForm ) {
				$( this.currentForm ).resetForm();
			}
			this.submitted = {};
			this.lastElement = null;
			this.prepareForm();
			this.hideErrors();
			this.elements().removeClass( this.settings.errorClass ).removeData( "previousValue" );
		},

		numberOfInvalids: function() {
			return this.objectLength(this.invalid);
		},

		objectLength: function( obj ) {
			var count = 0;
			for ( var i in obj ) {
				count++;
			}
			return count;
		},

		hideErrors: function() {
			this.addWrapper( this.toHide ).hide();
		},

		valid: function() {
			return this.size() === 0;
		},

		size: function() {
			return this.errorList.length;
		},

		focusInvalid: function() {
			if( this.settings.focusInvalid ) {
				try {
					$(this.findLastActive() || this.errorList.length && this.errorList[0].element || [])
					.filter(":visible")
					.focus()
					// manually trigger focusin event; without it, focusin handler isn't called, findLastActive won't have anything to find
					.trigger("focusin");
				} catch(e) {
					// ignore IE throwing errors when focusing hidden elements
				}
			}
		},

		findLastActive: function() {
			var lastActive = this.lastActive;
			return lastActive && $.grep(this.errorList, function(n) {
				return n.element.name === lastActive.name;
			}).length === 1 && lastActive;
		},

		elements: function() {
			var validator = this,
				rulesCache = {};

			// select all valid inputs inside the form (no submit or reset buttons)
			return $(this.currentForm)
			.find("input, select, textarea")
			.not(":submit, :reset, :image, [disabled]")
			.not( this.settings.ignore )
			.filter(function() {
				if ( !this.name && validator.settings.debug && window.console ) {
					console.error( "%o has no name assigned", this);
				}

				// select only the first element for each name, and only those with rules specified
				if ( this.name in rulesCache || !validator.objectLength($(this).rules()) ) {
					return false;
				}

				rulesCache[this.name] = true;
				return true;
			});
		},

		clean: function( selector ) {
			return $( selector )[0];
		},

		errors: function() {
			var errorClass = this.settings.errorClass.replace(' ', '.');
			return $( this.settings.errorElement + "." + errorClass, this.errorContext );
		},

		reset: function() {
			this.successList = [];
			this.errorList = [];
			this.errorMap = {};
			this.toShow = $([]);
			this.toHide = $([]);
			this.currentElements = $([]);
		},

		prepareForm: function() {
			this.reset();
			this.toHide = this.errors().add( this.containers );
		},

		prepareElement: function( element ) {
			this.reset();
			this.toHide = this.errorsFor(element);
		},

		elementValue: function( element ) {
			var type = $(element).attr('type'),
				val = $(element).val();

			if ( type === 'radio' || type === 'checkbox' ) {
				return $('input[name="' + $(element).attr('name') + '"]:checked').val();
			}

			if ( typeof val === 'string' ) {
				return val.replace(/\r/g, "");
			}
			return val;
		},

		check: function( element ) {
			element = this.validationTargetFor( this.clean( element ) );

			var rules = $(element).rules();
			var dependencyMismatch = false;
			var val = this.elementValue(element);
			var result;

			for (var method in rules ) {
				var rule = { method: method, parameters: rules[method] };
				try {

					result = $.validator.methods[method].call( this, val, element, rule.parameters );

					// if a method indicates that the field is optional and therefore valid,
					// don't mark it as valid when there are no other rules
					if ( result === "dependency-mismatch" ) {
						dependencyMismatch = true;
						continue;
					}
					dependencyMismatch = false;

					if ( result === "pending" ) {
						this.toHide = this.toHide.not( this.errorsFor(element) );
						return;
					}

					if( !result ) {
						this.formatAndAdd( element, rule );
						return false;
					}
				} catch(e) {
					if ( this.settings.debug && window.console ) {
						console.log("exception occured when checking element " + element.id + ", check the '" + rule.method + "' method", e);
					}
					throw e;
				}
			}
			if (dependencyMismatch) {
				return;
			}
			if ( this.objectLength(rules) ) {
				this.successList.push(element);
			}
			return true;
		},

		// return the custom message for the given element and validation method
		// specified in the element's HTML5 data attribute
		customDataMessage: function(element, method) {
			return $(element).data('msg-' + method.toLowerCase()) || (element.attributes && $(element).attr('data-msg-' + method.toLowerCase()));
		},

		// return the custom message for the given element name and validation method
		customMessage: function( name, method ) {
			var m = this.settings.messages[name];
			return m && (m.constructor === String ? m : m[method]);
		},

		// return the first defined argument, allowing empty strings
		findDefined: function() {
			for(var i = 0; i < arguments.length; i++) {
				if (arguments[i] !== undefined) {
					return arguments[i];
				}
			}
			return undefined;
		},

		defaultMessage: function( element, method) {
			return this.findDefined(
				this.customMessage( element.name, method ),
				this.customDataMessage( element, method ),
				// title is never undefined, so handle empty string as undefined
				!this.settings.ignoreTitle && element.title || undefined,
				$.validator.messages[method],
				"<strong>Warning: No message defined for " + element.name + "</strong>"
			);
		},

		formatAndAdd: function( element, rule ) {
			var message = this.defaultMessage( element, rule.method ),
				theregex = /\$?\{(\d+)\}/g;
			if ( typeof message === "function" ) {
				message = message.call(this, rule.parameters, element);
			} else if (theregex.test(message)) {
				message = $.validator.format(message.replace(theregex, '{$1}'), rule.parameters);
			}
			this.errorList.push({
				message: message,
				element: element
			});

			this.errorMap[element.name] = message;
			this.submitted[element.name] = message;
		},

		addWrapper: function(toToggle) {
			if ( this.settings.wrapper ) {
				toToggle = toToggle.add( toToggle.parent( this.settings.wrapper ) );
			}
			return toToggle;
		},

		defaultShowErrors: function() {
			var i, elements;
			for ( i = 0; this.errorList[i]; i++ ) {
				var error = this.errorList[i];
				if ( this.settings.highlight ) {
					this.settings.highlight.call( this, error.element, this.settings.errorClass, this.settings.validClass );
				}
				this.showLabel( error.element, error.message );
			}
			if( this.errorList.length ) {
				this.toShow = this.toShow.add( this.containers );
			}
			if (this.settings.success) {
				for ( i = 0; this.successList[i]; i++ ) {
					this.showLabel( this.successList[i] );
				}
			}
			if (this.settings.unhighlight) {
				for ( i = 0, elements = this.validElements(); elements[i]; i++ ) {
					this.settings.unhighlight.call( this, elements[i], this.settings.errorClass, this.settings.validClass );
				}
			}
			this.toHide = this.toHide.not( this.toShow );
			this.hideErrors();
			this.addWrapper( this.toShow ).show();
		},

		validElements: function() {
			return this.currentElements.not(this.invalidElements());
		},

		invalidElements: function() {
			return $(this.errorList).map(function() {
				return this.element;
			});
		},

		showLabel: function(element, message) {
			var label = this.errorsFor( element );
			if ( label.length ) {
				// refresh error/success class
				label.removeClass( this.settings.validClass ).addClass( this.settings.errorClass );

				// check if we have a generated label, replace the message then
				if ( label.attr("generated") ) {
					label.html(message);
				}
			} else {
				// create label
				label = $("<" + this.settings.errorElement + "/>")
					.attr({"for":  this.idOrName(element), generated: true})
					.addClass(this.settings.errorClass)
					.html(message || "");
				if ( this.settings.wrapper ) {
					// make sure the element is visible, even in IE
					// actually showing the wrapped element is handled elsewhere
					label = label.hide().show().wrap("<" + this.settings.wrapper + "/>").parent();
				}
				if ( !this.labelContainer.append(label).length ) {
					if ( this.settings.errorPlacement ) {
						this.settings.errorPlacement(label, $(element) );
					} else {
						label.insertAfter(element);
					}
				}
			}
			if ( !message && this.settings.success ) {
				label.text("");
				if ( typeof this.settings.success === "string" ) {
					label.addClass( this.settings.success );
				} else {
					this.settings.success( label, element );
				}
			}
			this.toShow = this.toShow.add(label);
		},

		errorsFor: function(element) {
			var name = this.idOrName(element);
			return this.errors().filter(function() {
				return $(this).attr('for') === name;
			});
		},

		idOrName: function(element) {
			return this.groups[element.name] || (this.checkable(element) ? element.name : element.id || element.name);
		},

		validationTargetFor: function(element) {
			// if radio/checkbox, validate first element in group instead
			if (this.checkable(element)) {
				element = this.findByName( element.name ).not(this.settings.ignore)[0];
			}
			return element;
		},

		checkable: function( element ) {
			return (/radio|checkbox/i).test(element.type);
		},

		findByName: function( name ) {
			return $(this.currentForm).find('[name="' + name + '"]');
		},

		getLength: function(value, element) {
			switch( element.nodeName.toLowerCase() ) {
			case 'select':
				return $("option:selected", element).length;
			case 'input':
				if( this.checkable( element) ) {
					return this.findByName(element.name).filter(':checked').length;
				}
			}
			return value.length;
		},

		depend: function(param, element) {
			return this.dependTypes[typeof param] ? this.dependTypes[typeof param](param, element) : true;
		},

		dependTypes: {
			"boolean": function(param, element) {
				return param;
			},
			"string": function(param, element) {
				return !!$(param, element.form).length;
			},
			"function": function(param, element) {
				return param(element);
			}
		},

		optional: function(element) {
			var val = this.elementValue(element);
			return !$.validator.methods.required.call(this, val, element) && "dependency-mismatch";
		},

		startRequest: function(element) {
			if (!this.pending[element.name]) {
				this.pendingRequest++;
				this.pending[element.name] = true;
			}
		},

		stopRequest: function(element, valid) {
			this.pendingRequest--;
			// sometimes synchronization fails, make sure pendingRequest is never < 0
			if (this.pendingRequest < 0) {
				this.pendingRequest = 0;
			}
			delete this.pending[element.name];
			if ( valid && this.pendingRequest === 0 && this.formSubmitted && this.form() ) {
				var hidden;
				// If no submit handler is set but a submit button is present
				// ensure the following scripted submit has the value of the
				// submit button by injecting a hidden field.
				if ( !this.settings.submitHandler && this.submitButton ) {
				  hidden = $("<input type='hidden'/>")
					.attr("name", this.submitButton.name)
					.val($(this.submitButton).val())
					.appendTo(this.currentForm);
				}
				var that = this;
				// Disconnect the form submit from the rest of the handling.
				// For some reason we run into trouble with loosing form values
				// when the form submit is triggered right here. With a interval
				// we change the context which seems to work just fine.
				window.setTimeout(function(){
				  $(that.currentForm).submit();
				  if ( hidden ) {
					hidden.remove();
				  }
				  that.formSubmitted = false;
				}, 1);
			} else if (!valid && this.pendingRequest === 0 && this.formSubmitted) {
				$(this.currentForm).triggerHandler("invalid-form", [this]);
				this.formSubmitted = false;
			}
		},

		previousValue: function(element) {
			return $.data(element, "previousValue") || $.data(element, "previousValue", {
				old: null,
				valid: true,
				message: this.defaultMessage( element, "remote" )
			});
		}

	},

	classRuleSettings: {
		required: {required: true},
		email: {email: true},
		url: {url: true},
		date: {date: true},
		dateISO: {dateISO: true},
		number: {number: true},
		digits: {digits: true},
		creditcard: {creditcard: true}
	},

	addClassRules: function(className, rules) {
		if ( className.constructor === String ) {
			this.classRuleSettings[className] = rules;
		} else {
			$.extend(this.classRuleSettings, className);
		}
	},

	classRules: function(element) {
		var rules = {};
		var classes = $(element).attr('class');
		if ( classes ) {
			$.each(classes.split(' '), function() {
				if (this in $.validator.classRuleSettings) {
					$.extend(rules, $.validator.classRuleSettings[this]);
				}
			});
		}
		return rules;
	},

	attributeRules: function(element) {
		var rules = {};
		var $element = $(element);

		for (var method in $.validator.methods) {
			var value;

			// support for <input required> in both html5 and older browsers
			if (method === 'required') {
				value = $element.get(0).getAttribute(method);
				// Some browsers return an empty string for the required attribute
				// and non-HTML5 browsers might have required="" markup
				if (value === "") {
					value = true;
				}
				// force non-HTML5 browsers to return bool
				value = !!value;
			} else {
				value = $element.attr(method);
			}

			if (value) {
				rules[method] = value;
			} else if ($element[0].getAttribute("type") === method) {
				rules[method] = true;
			}
		}

		// maxlength may be returned as -1, 2147483647 (IE) and 524288 (safari) for text inputs
		if (rules.maxlength && /-1|2147483647|524288/.test(rules.maxlength)) {
			delete rules.maxlength;
		}

		return rules;
	},

	dataRules: function(element) {
		var method, value,
			rules = {}, $element = $(element);
		for (method in $.validator.methods) {
			value = $element.data('rule-' + method.toLowerCase());
			if (value !== undefined) {
				rules[method] = value;
			}
		}
		return rules;
	},

	staticRules: function(element) {
		var rules = {};
		var validator = $.data(element.form, 'validator');
		if (validator.settings.rules) {
			rules = $.validator.normalizeRule(validator.settings.rules[element.name]) || {};
		}
		return rules;
	},

	normalizeRules: function(rules, element) {
		// handle dependency check
		$.each(rules, function(prop, val) {
			// ignore rule when param is explicitly false, eg. required:false
			if (val === false) {
				delete rules[prop];
				return;
			}
			if (val.param || val.depends) {
				var keepRule = true;
				switch (typeof val.depends) {
				case "string":
					keepRule = !!$(val.depends, element.form).length;
					break;
				case "function":
					keepRule = val.depends.call(element, element);
					break;
				}
				if (keepRule) {
					rules[prop] = val.param !== undefined ? val.param : true;
				} else {
					delete rules[prop];
				}
			}
		});

		// evaluate parameters
		$.each(rules, function(rule, parameter) {
			rules[rule] = $.isFunction(parameter) ? parameter(element) : parameter;
		});

		// clean number parameters
		$.each(['minlength', 'maxlength', 'min', 'max'], function() {
			if (rules[this]) {
				rules[this] = Number(rules[this]);
			}
		});
		$.each(['rangelength', 'range'], function() {
			var parts;
			if (rules[this]) {
				if ($.isArray(rules[this])) {
					rules[this] = [Number(rules[this][0]), Number(rules[this][1])];
				} else if (typeof rules[this] === 'string') {
					parts = rules[this].split(/[\s,]+/);
					rules[this] = [Number(parts[0]), Number(parts[1])];
				}
			}
		});

		if ($.validator.autoCreateRanges) {
			// auto-create ranges
			if (rules.min && rules.max) {
				rules.range = [rules.min, rules.max];
				delete rules.min;
				delete rules.max;
			}
			if (rules.minlength && rules.maxlength) {
				rules.rangelength = [rules.minlength, rules.maxlength];
				delete rules.minlength;
				delete rules.maxlength;
			}
		}

		return rules;
	},

	// Converts a simple string to a {string: true} rule, e.g., "required" to {required:true}
	normalizeRule: function(data) {
		if( typeof data === "string" ) {
			var transformed = {};
			$.each(data.split(/\s/), function() {
				transformed[this] = true;
			});
			data = transformed;
		}
		return data;
	},

	// http://docs.jquery.com/Plugins/Validation/Validator/addMethod
	addMethod: function(name, method, message) {
		$.validator.methods[name] = method;
		$.validator.messages[name] = message !== undefined ? message : $.validator.messages[name];
		if (method.length < 3) {
			$.validator.addClassRules(name, $.validator.normalizeRule(name));
		}
	},

	methods: {

		// http://docs.jquery.com/Plugins/Validation/Methods/required
		required: function(value, element, param) {
			// check if dependency is met
			if ( !this.depend(param, element) ) {
				return "dependency-mismatch";
			}
			if ( element.nodeName.toLowerCase() === "select" ) {
				// could be an array for select-multiple or a string, both are fine this way
				var val = $(element).val();
				return val && val.length > 0;
			}
			if ( this.checkable(element) ) {
				return this.getLength(value, element) > 0;
			}
			return $.trim(value).length > 0;
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/remote
		remote: function(value, element, param) {
			if ( this.optional(element) ) {
				return "dependency-mismatch";
			}

			var previous = this.previousValue(element);
			if (!this.settings.messages[element.name] ) {
				this.settings.messages[element.name] = {};
			}
			previous.originalMessage = this.settings.messages[element.name].remote;
			this.settings.messages[element.name].remote = previous.message;

			param = typeof param === "string" && {url:param} || param;

			if ( previous.old === value ) {
				return previous.valid;
			}

			previous.old = value;
			var validator = this;
			this.startRequest(element);
			var data = {};
			data[element.name] = value;
			$.ajax($.extend(true, {
				url: param,
				mode: "abort",
				port: "validate" + element.name,
				dataType: "json",
				data: data,
				complete: function(response) {
					validator.settings.messages[element.name].remote = previous.originalMessage;
					var valid = response === true || response === "true";
					if ( valid ) {
						var submitted = validator.formSubmitted;
						validator.prepareElement(element);
						validator.formSubmitted = submitted;
						validator.successList.push(element);
						delete validator.invalid[element.name];
						validator.showErrors();
					} else {
						var errors = {};
						var message = response || validator.defaultMessage( element, "remote" );
						errors[element.name] = previous.message = $.isFunction(message) ? message(value) : message;
						validator.invalid[element.name] = true;
						validator.showErrors(errors);
					}
					previous.valid = valid;
					validator.stopRequest(element, valid);
				}
			}, param));
			return "pending";
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/minlength
		minlength: function(value, element, param) {
			var length = $.isArray( value ) ? value.length : this.getLength($.trim(value), element);
			return this.optional(element) || length >= param;
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/maxlength
		maxlength: function(value, element, param) {
			var length = $.isArray( value ) ? value.length : this.getLength($.trim(value), element);
			return this.optional(element) || length <= param;
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/rangelength
		rangelength: function(value, element, param) {
			var length = $.isArray( value ) ? value.length : this.getLength($.trim(value), element);
			return this.optional(element) || ( length >= param[0] && length <= param[1] );
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/min
		min: function( value, element, param ) {
			return this.optional(element) || value >= param;
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/max
		max: function( value, element, param ) {
			return this.optional(element) || value <= param;
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/range
		range: function( value, element, param ) {
			return this.optional(element) || ( value >= param[0] && value <= param[1] );
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/email
		email: function(value, element) {
			// contributed by Scott Gonzalez: http://projects.scottsplayground.com/email_address_validation/
			return this.optional(element) || /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(value);
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/url
		url: function(value, element) {
			// contributed by Scott Gonzalez: http://projects.scottsplayground.com/iri/
			return this.optional(element) || /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/date
		date: function(value, element) {
			return this.optional(element) || !/Invalid|NaN/.test(new Date(value).toString());
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/dateISO
		dateISO: function(value, element) {
			return this.optional(element) || /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(value);
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/number
		number: function(value, element) {
			return this.optional(element) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value);
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/digits
		digits: function(value, element) {
			return this.optional(element) || /^\d+$/.test(value);
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/creditcard
		// based on http://en.wikipedia.org/wiki/Luhn
		creditcard: function(value, element) {
			if ( this.optional(element) ) {
				return "dependency-mismatch";
			}
			// accept only spaces, digits and dashes
			if (/[^0-9 \-]+/.test(value)) {
				return false;
			}
			var nCheck = 0,
				nDigit = 0,
				bEven = false;

			value = value.replace(/\D/g, "");

			for (var n = value.length - 1; n >= 0; n--) {
				var cDigit = value.charAt(n);
				nDigit = parseInt(cDigit, 10);
				if (bEven) {
					if ((nDigit *= 2) > 9) {
						nDigit -= 9;
					}
				}
				nCheck += nDigit;
				bEven = !bEven;
			}

			return (nCheck % 10) === 0;
		},

		// http://docs.jquery.com/Plugins/Validation/Methods/equalTo
		equalTo: function(value, element, param) {
			// bind to the blur event of the target in order to revalidate whenever the target field is updated
			// TODO find a way to bind the event just once, avoiding the unbind-rebind overhead
			var target = $(param);
			if (this.settings.onfocusout) {
				target.unbind(".validate-equalTo").bind("blur.validate-equalTo", function() {
					$(element).valid();
				});
			}
			return value === target.val();
		}

	}

});

// deprecated, use $.validator.format instead
$.format = $.validator.format;

}(jQuery));

// ajax mode: abort
// usage: $.ajax({ mode: "abort"[, port: "uniqueport"]});
// if mode:"abort" is used, the previous request on that port (port can be undefined) is aborted via XMLHttpRequest.abort()
(function($) {
	var pendingRequests = {};
	// Use a prefilter if available (1.5+)
	if ( $.ajaxPrefilter ) {
		$.ajaxPrefilter(function(settings, _, xhr) {
			var port = settings.port;
			if (settings.mode === "abort") {
				if ( pendingRequests[port] ) {
					pendingRequests[port].abort();
				}
				pendingRequests[port] = xhr;
			}
		});
	} else {
		// Proxy ajax
		var ajax = $.ajax;
		$.ajax = function(settings) {
			var mode = ( "mode" in settings ? settings : $.ajaxSettings ).mode,
				port = ( "port" in settings ? settings : $.ajaxSettings ).port;
			if (mode === "abort") {
				if ( pendingRequests[port] ) {
					pendingRequests[port].abort();
				}
				return (pendingRequests[port] = ajax.apply(this, arguments));
			}
			return ajax.apply(this, arguments);
		};
	}
}(jQuery));

// provides delegate(type: String, delegate: Selector, handler: Callback) plugin for easier event delegation
// handler is only called when $(event.target).is(delegate), in the scope of the jquery-object for event.target
(function($) {
	$.extend($.fn, {
		validateDelegate: function(delegate, type, handler) {
			return this.bind(type, function(event) {
				var target = $(event.target);
				if (target.is(delegate)) {
					return handler.apply(target, arguments);
				}
			});
		}
	});
}(jQuery));

;/*})'"*/
;/*})'"*/
(function ($) {

/**
 * Attaches the autocomplete behavior to all required fields.
 */
Drupal.behaviors.autocomplete = {
  attach: function (context, settings) {
    var acdb = [];
    $('input.autocomplete', context).once('autocomplete', function () {
      var uri = this.value;
      if (!acdb[uri]) {
        acdb[uri] = new Drupal.ACDB(uri);
      }
      var $input = $('#' + this.id.substr(0, this.id.length - 13))
        .attr('autocomplete', 'OFF')
        .attr('aria-autocomplete', 'list');
      $($input[0].form).submit(Drupal.autocompleteSubmit);
      $input.parent()
        .attr('role', 'application')
        .append($('<span class="element-invisible" aria-live="assertive"></span>')
          .attr('id', $input.attr('id') + '-autocomplete-aria-live')
        );
      new Drupal.jsAC($input, acdb[uri]);
    });
  }
};

/**
 * Prevents the form from submitting if the suggestions popup is open
 * and closes the suggestions popup when doing so.
 */
Drupal.autocompleteSubmit = function () {
  return $('#autocomplete').each(function () {
    this.owner.hidePopup();
  }).length == 0;
};

/**
 * An AutoComplete object.
 */
Drupal.jsAC = function ($input, db) {
  var ac = this;
  this.input = $input[0];
  this.ariaLive = $('#' + this.input.id + '-autocomplete-aria-live');
  this.db = db;

  $input
    .keydown(function (event) { return ac.onkeydown(this, event); })
    .keyup(function (event) { ac.onkeyup(this, event); })
    .blur(function () { ac.hidePopup(); ac.db.cancel(); });

};

/**
 * Handler for the "keydown" event.
 */
Drupal.jsAC.prototype.onkeydown = function (input, e) {
  if (!e) {
    e = window.event;
  }
  switch (e.keyCode) {
    case 40: // down arrow.
      this.selectDown();
      return false;
    case 38: // up arrow.
      this.selectUp();
      return false;
    default: // All other keys.
      return true;
  }
};

/**
 * Handler for the "keyup" event.
 */
Drupal.jsAC.prototype.onkeyup = function (input, e) {
  if (!e) {
    e = window.event;
  }
  switch (e.keyCode) {
    case 16: // Shift.
    case 17: // Ctrl.
    case 18: // Alt.
    case 20: // Caps lock.
    case 33: // Page up.
    case 34: // Page down.
    case 35: // End.
    case 36: // Home.
    case 37: // Left arrow.
    case 38: // Up arrow.
    case 39: // Right arrow.
    case 40: // Down arrow.
      return true;

    case 9:  // Tab.
    case 13: // Enter.
    case 27: // Esc.
      this.hidePopup(e.keyCode);
      return true;

    default: // All other keys.
      if (input.value.length > 0 && !input.readOnly) {
        this.populatePopup();
      }
      else {
        this.hidePopup(e.keyCode);
      }
      return true;
  }
};

/**
 * Puts the currently highlighted suggestion into the autocomplete field.
 */
Drupal.jsAC.prototype.select = function (node) {
  this.input.value = $(node).data('autocompleteValue');
  $(this.input).trigger('autocompleteSelect', [node]);
};

/**
 * Highlights the next suggestion.
 */
Drupal.jsAC.prototype.selectDown = function () {
  if (this.selected && this.selected.nextSibling) {
    this.highlight(this.selected.nextSibling);
  }
  else if (this.popup) {
    var lis = $('li', this.popup);
    if (lis.length > 0) {
      this.highlight(lis.get(0));
    }
  }
};

/**
 * Highlights the previous suggestion.
 */
Drupal.jsAC.prototype.selectUp = function () {
  if (this.selected && this.selected.previousSibling) {
    this.highlight(this.selected.previousSibling);
  }
};

/**
 * Highlights a suggestion.
 */
Drupal.jsAC.prototype.highlight = function (node) {
  if (this.selected) {
    $(this.selected).removeClass('selected');
  }
  $(node).addClass('selected');
  this.selected = node;
  $(this.ariaLive).html($(this.selected).html());
};

/**
 * Unhighlights a suggestion.
 */
Drupal.jsAC.prototype.unhighlight = function (node) {
  $(node).removeClass('selected');
  this.selected = false;
  $(this.ariaLive).empty();
};

/**
 * Hides the autocomplete suggestions.
 */
Drupal.jsAC.prototype.hidePopup = function (keycode) {
  // Select item if the right key or mousebutton was pressed.
  if (this.selected && ((keycode && keycode != 46 && keycode != 8 && keycode != 27) || !keycode)) {
    this.select(this.selected);
  }
  // Hide popup.
  var popup = this.popup;
  if (popup) {
    this.popup = null;
    $(popup).fadeOut('fast', function () { $(popup).remove(); });
  }
  this.selected = false;
  $(this.ariaLive).empty();
};

/**
 * Positions the suggestions popup and starts a search.
 */
Drupal.jsAC.prototype.populatePopup = function () {
  var $input = $(this.input);
  var position = $input.position();
  // Show popup.
  if (this.popup) {
    $(this.popup).remove();
  }
  this.selected = false;
  this.popup = $('<div id="autocomplete"></div>')[0];
  this.popup.owner = this;
  $(this.popup).css({
    top: parseInt(position.top + this.input.offsetHeight, 10) + 'px',
    left: parseInt(position.left, 10) + 'px',
    width: $input.innerWidth() + 'px',
    display: 'none'
  });
  $input.before(this.popup);

  // Do search.
  this.db.owner = this;
  this.db.search(this.input.value);
};

/**
 * Fills the suggestion popup with any matches received.
 */
Drupal.jsAC.prototype.found = function (matches) {
  // If no value in the textfield, do not show the popup.
  if (!this.input.value.length) {
    return false;
  }

  // Prepare matches.
  var ul = $('<ul></ul>');
  var ac = this;
  for (key in matches) {
    $('<li></li>')
      .html($('<div></div>').html(matches[key]))
      .mousedown(function () { ac.hidePopup(this); })
      .mouseover(function () { ac.highlight(this); })
      .mouseout(function () { ac.unhighlight(this); })
      .data('autocompleteValue', key)
      .appendTo(ul);
  }

  // Show popup with matches, if any.
  if (this.popup) {
    if (ul.children().length) {
      $(this.popup).empty().append(ul).show();
      $(this.ariaLive).html(Drupal.t('Autocomplete popup'));
    }
    else {
      $(this.popup).css({ visibility: 'hidden' });
      this.hidePopup();
    }
  }
};

Drupal.jsAC.prototype.setStatus = function (status) {
  switch (status) {
    case 'begin':
      $(this.input).addClass('throbbing');
      $(this.ariaLive).html(Drupal.t('Searching for matches...'));
      break;
    case 'cancel':
    case 'error':
    case 'found':
      $(this.input).removeClass('throbbing');
      break;
  }
};

/**
 * An AutoComplete DataBase object.
 */
Drupal.ACDB = function (uri) {
  this.uri = uri;
  this.delay = 300;
  this.cache = {};
};

/**
 * Performs a cached and delayed search.
 */
Drupal.ACDB.prototype.search = function (searchString) {
  var db = this;
  this.searchString = searchString;

  // See if this string needs to be searched for anyway. The pattern ../ is
  // stripped since it may be misinterpreted by the browser.
  searchString = searchString.replace(/^\s+|\.{2,}\/|\s+$/g, '');
  // Skip empty search strings, or search strings ending with a comma, since
  // that is the separator between search terms.
  if (searchString.length <= 0 ||
    searchString.charAt(searchString.length - 1) == ',') {
    return;
  }

  // See if this key has been searched for before.
  if (this.cache[searchString]) {
    return this.owner.found(this.cache[searchString]);
  }

  // Initiate delayed search.
  if (this.timer) {
    clearTimeout(this.timer);
  }
  this.timer = setTimeout(function () {
    db.owner.setStatus('begin');

    // Ajax GET request for autocompletion. We use Drupal.encodePath instead of
    // encodeURIComponent to allow autocomplete search terms to contain slashes.
    $.ajax({
      type: 'GET',
      url: Drupal.sanitizeAjaxUrl(db.uri + '/' + Drupal.encodePath(searchString)),
      dataType: 'json',
      jsonp: false,
      success: function (matches) {
        if (typeof matches.status == 'undefined' || matches.status != 0) {
          db.cache[searchString] = matches;
          // Verify if these are still the matches the user wants to see.
          if (db.searchString == searchString) {
            db.owner.found(matches);
          }
          db.owner.setStatus('found');
        }
      },
      error: function (xmlhttp) {
        Drupal.displayAjaxError(Drupal.ajaxError(xmlhttp, db.uri));
      }
    });
  }, this.delay);
};

/**
 * Cancels the current autocomplete request.
 */
Drupal.ACDB.prototype.cancel = function () {
  if (this.owner) this.owner.setStatus('cancel');
  if (this.timer) clearTimeout(this.timer);
  this.searchString = '';
};

})(jQuery);

;/*})'"*/
;/*})'"*/
(function ($) {

// Auto-submit main search input after autocomplete
if (typeof Drupal.jsAC != 'undefined') {

  var getSetting = function (input, setting, defaultValue) {
    // Earlier versions of jQuery, like the default for Drupal 7, don't properly
    // convert data-* attributes to camel case, so we access it via the verbatim
    // name from the attribute (which also works in newer versions).
    var search = $(input).data('search-api-autocomplete-search');
    if (typeof search == 'undefined'
        || typeof Drupal.settings.search_api_autocomplete == 'undefined'
        || typeof Drupal.settings.search_api_autocomplete[search] == 'undefined'
        || typeof Drupal.settings.search_api_autocomplete[search][setting] == 'undefined') {
      return defaultValue;
    }
    return Drupal.settings.search_api_autocomplete[search][setting];
  };

  var oldJsAC = Drupal.jsAC;
  /**
   * An AutoComplete object.
   *
   * Overridden to set the proper "role" attribute on the input element.
   */
  Drupal.jsAC = function ($input, db) {
    if ($input.data('search-api-autocomplete-search')) {
      $input.attr('role', 'combobox');
      $input.parent().attr('role', 'search');
    }
    this.inSelect = false;
    oldJsAC.call(this, $input, db);
  };
  Drupal.jsAC.prototype = oldJsAC.prototype;

  /**
   * Handler for the "keyup" event.
   *
   * Extend from Drupal's autocomplete.js to automatically submit the form
   * when Enter is hit.
   */
  var default_onkeyup = Drupal.jsAC.prototype.onkeyup;
  Drupal.jsAC.prototype.onkeyup = function (input, e) {
    if (!e) {
      e = window.event;
    }
    // Fire standard function.
    default_onkeyup.call(this, input, e);

    if (13 == e.keyCode && $(input).hasClass('auto_submit')) {
      var selector = getSetting(input, 'selector', ':submit');
      $(selector, input.form).trigger('click');
    }
  };

  /**
   * Handler for the "keydown" event.
   *
   * Extend from Drupal's autocomplete.js to avoid ajax interfering with the
   * autocomplete.
   */
  var default_onkeydown = Drupal.jsAC.prototype.onkeydown;
  Drupal.jsAC.prototype.onkeydown = function (input, e) {
    if (!e) {
      e = window.event;
    }
    // Fire standard function.
    default_onkeydown.call(this, input, e);

    // Prevent that the ajax handling of Views fires too early and thus
    // misses the form update.
    if (13 == e.keyCode && $(input).hasClass('auto_submit')) {
      e.preventDefault();
      return false;
    }
  };

  var default_select = Drupal.jsAC.prototype.select;
  Drupal.jsAC.prototype.select = function(node) {
    // Check if this is a Search API autocomplete field
    if (!$(this.input).data('search-api-autocomplete-search')) {
      // Not a Search API field
      return default_select.call(this, node);
    }

    // Protect against an (potentially infinite) recursion.
    if (this.inSelect) {
      return false;
    }
    this.inSelect = true;

    var autocompleteValue = $(node).data('autocompleteValue');
    // Check whether this is not a suggestion but a "link".
    if (autocompleteValue.charAt(0) == ' ') {
      window.location.href = autocompleteValue.substr(1);
      this.inSelect = false;
      return false;
    }
    this.input.value = autocompleteValue;
    $(this.input).trigger('autocompleteSelect', [node]);
    if ($(this.input).hasClass('auto_submit')) {
      if (typeof Drupal.search_api_ajax != 'undefined') {
        // Use Search API Ajax to submit
        Drupal.search_api_ajax.navigateQuery($(this.input).val());
      }
      else {
        var selector = getSetting(this.input, 'selector', ':submit');
        $(selector, this.input.form).trigger('click');
      }
      this.inSelect = false;
      return true;
    }
    this.inSelect = false;
  };

  /**
   * Overwrite default behaviour.
   *
   * Just always return true to make it possible to submit even when there was
   * an autocomplete suggestion list open.
   */
  Drupal.autocompleteSubmit = function () {
    $('#autocomplete').each(function () {
      this.owner.hidePopup();
    });
    return true;
  };

  /**
   * Performs a cached and delayed search.
   */
  Drupal.ACDB.prototype.search = function (searchString) {
    this.searchString = searchString;

    // Check allowed length of string for autocomplete.
    var data = $(this.owner.input).first().data('min-autocomplete-length');
    if (data && searchString.length < data) {
      return;
    }

    // See if this string needs to be searched for anyway.
    if (searchString.match(/^\s*$/)) {
      return;
    }

    // Prepare search string.
    searchString = searchString.replace(/^\s+/, '');
    searchString = searchString.replace(/\s+/g, ' ');

    // See if this key has been searched for before.
    if (this.cache[searchString]) {
      return this.owner.found(this.cache[searchString]);
    }

    var db = this;
    this.searchString = searchString;

    // Initiate delayed search.
    if (this.timer) {
      clearTimeout(this.timer);
    }
    var sendAjaxRequest = function () {
      db.owner.setStatus('begin');

      var url;

      // Allow custom Search API Autocomplete overrides for specific searches.
      if (getSetting(db.owner.input, 'custom_path', false)) {
        var queryChar = db.uri.indexOf('?') >= 0 ? '&' : '?';
        url = db.uri + queryChar + 'search=' + encodeURIComponent(searchString);
      }
      else {
        // We use Drupal.encodePath instead of encodeURIComponent to allow
        // autocomplete search terms to contain slashes.
        url = db.uri + '/' + Drupal.encodePath(searchString);
      }

      // Ajax GET request for autocompletion.
      $.ajax({
        type: 'GET',
        url: url,
        dataType: 'json',
        success: function (matches) {
          if (typeof matches.status == 'undefined' || matches.status != 0) {
            db.cache[searchString] = matches;
            // Verify if these are still the matches the user wants to see.
            if (db.searchString == searchString) {
              db.owner.found(matches);
            }
            db.owner.setStatus('found');
          }
        },
        error: function (xmlhttp) {
          if (xmlhttp.status) {
            alert(Drupal.ajaxError(xmlhttp, db.uri));
          }
        }
      });
    };
    // Make it possible to override the delay via a setting.
    var delay = getSetting(this.owner.input, 'delay', this.delay);
    if (delay > 0) {
      this.timer = setTimeout(sendAjaxRequest, delay);
    }
    else {
      sendAjaxRequest.apply();
    }
  };
}

})(jQuery);

;/*})'"*/
;/*})'"*/
(function ($) {
  "use strict";

  $(document).bind('clientsideValidationAddCustomRules', function(event){
    // Clientside validation of phone numbers. Overwrites the default from
    // the client side validation integration. Aims to be much faster.
    $.validator.addMethod("addressfieldName", function(value, element, param) {
      var result = false;
      result = (value.search(/[\[\]\$£\/\+\?%\#\)\(:;€\&=\^\@\!\*\d]/gi) === -1);
      if (result) {
        var specialNameCharsResult = (value.match(/(['\.\,\-\d])/gi) || []);
        var relation = specialNameCharsResult.length / value.length;
        result = (relation < 0.3);
      }
      return this.optional(element) || result;
    }, $.format('Please fill in a valid name'));
    $.validator.addMethod("addressfieldLocality", function(value, element, param) {
      var result = false;
      result = (value.search(/[\[\]\$£\/\+\?%\#\)\(:;€\&=\^\@\!\*]/gi) === -1);
      if (result) {
        var specialNameCharsResult = (value.match(/(['\.\,\-\d])/gi) || []);
        var relation = specialNameCharsResult.length / value.length;
        result = (relation < 0.3);
      }
      return this.optional(element) || result;
    }, $.format('Please fill in a valid name'));
  });

})(jQuery);




;/*})'"*/
;/*})'"*/
(function ($) {
  Drupal.behaviors.language_switcher_dropdown = {};
  Drupal.behaviors.language_switcher_dropdown.attach = function(context, settings) {
    $('.cando-ctools-language-switcher-dropdown-content-type-form', context).bind('submit', function(e) {
      e.preventDefault();
      window.location.href = $('.form-select', this).val();
      return false;
    });
    $('.cando-ctools-language-switcher-dropdown-content-type-form .form-select', context).bind('change', function(e) {
      $(this).submit();
    });
    $('.cando-ctools-language-switcher-dropdown-content-type-form .form-actions', context).addClass('visually-hidden').attr('aria-hidden', 'true');
  }
})(jQuery);

;/*})'"*/
;/*})'"*/
(function ($) {

/**
 * A progressbar object. Initialized with the given id. Must be inserted into
 * the DOM afterwards through progressBar.element.
 *
 * method is the function which will perform the HTTP request to get the
 * progress bar state. Either "GET" or "POST".
 *
 * e.g. pb = new progressBar('myProgressBar');
 *      some_element.appendChild(pb.element);
 */
Drupal.progressBar = function (id, updateCallback, method, errorCallback) {
  var pb = this;
  this.id = id;
  this.method = method || 'GET';
  this.updateCallback = updateCallback;
  this.errorCallback = errorCallback;

  // The WAI-ARIA setting aria-live="polite" will announce changes after users
  // have completed their current activity and not interrupt the screen reader.
  this.element = $('<div class="progress" aria-live="polite"></div>').attr('id', id);
  this.element.html('<div class="bar"><div class="filled"></div></div>' +
                    '<div class="percentage"></div>' +
                    '<div class="message">&nbsp;</div>');
};

/**
 * Set the percentage and status message for the progressbar.
 */
Drupal.progressBar.prototype.setProgress = function (percentage, message) {
  if (percentage >= 0 && percentage <= 100) {
    $('div.filled', this.element).css('width', percentage + '%');
    $('div.percentage', this.element).html(percentage + '%');
  }
  $('div.message', this.element).html(message);
  if (this.updateCallback) {
    this.updateCallback(percentage, message, this);
  }
};

/**
 * Start monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.startMonitoring = function (uri, delay) {
  this.delay = delay;
  this.uri = uri;
  this.sendPing();
};

/**
 * Stop monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.stopMonitoring = function () {
  clearTimeout(this.timer);
  // This allows monitoring to be stopped from within the callback.
  this.uri = null;
};

/**
 * Request progress data from server.
 */
Drupal.progressBar.prototype.sendPing = function () {
  if (this.timer) {
    clearTimeout(this.timer);
  }
  if (this.uri) {
    var pb = this;
    // When doing a post request, you need non-null data. Otherwise a
    // HTTP 411 or HTTP 406 (with Apache mod_security) error may result.
    $.ajax({
      type: this.method,
      url: this.uri,
      data: '',
      dataType: 'json',
      success: function (progress) {
        // Display errors.
        if (progress.status == 0) {
          pb.displayError(progress.data);
          return;
        }
        // Update display.
        pb.setProgress(progress.percentage, progress.message);
        // Schedule next timer.
        pb.timer = setTimeout(function () { pb.sendPing(); }, pb.delay);
      },
      error: function (xmlhttp) {
        pb.displayError(Drupal.ajaxError(xmlhttp, pb.uri));
      }
    });
  }
};

/**
 * Display errors on the page.
 */
Drupal.progressBar.prototype.displayError = function (string) {
  var error = $('<div class="messages error"></div>').html(string);
  $(this.element).before(error).hide();

  if (this.errorCallback) {
    this.errorCallback(this);
  }
};

})(jQuery);

;/*})'"*/
;/*})'"*/
(function($) {
  Drupal.behaviors.chosen = {
    attach: function(context, settings) {
      settings.chosen = settings.chosen || Drupal.settings.chosen;

      // Prepare selector and add unwantend selectors.
      var selector = settings.chosen.selector;

      // Function to prepare all the options together for the chosen() call.
      var getElementOptions = function (element) {
        var options = $.extend({}, settings.chosen.options);

        // The width default option is considered the minimum width, so this
        // must be evaluated for every option.
        if ($(element).width() < settings.chosen.minimum_width) {
          options.width = settings.chosen.minimum_width + 'px';
        }
        else {
          options.width = $(element).width() + 'px';
        }

        // Some field widgets have cardinality, so we must respect that.
        // @see chosen_pre_render_select()
        if ($(element).attr('multiple') && $(element).data('cardinality')) {
          options.max_selected_options = $(element).data('cardinality');
        }

        return options;
      };

      // Process elements that have opted-in for Chosen.
      // @todo Remove support for the deprecated chosen-widget class.
      $('select.chosen-enable, select.chosen-widget', context).once('chosen', function() {
        options = getElementOptions(this);
        $(this).chosen(options);
      });

      $(selector, context)
        // Disabled on:
        // - Field UI
        // - WYSIWYG elements
        // - Tabledrag weights
        // - Elements that have opted-out of Chosen
        // - Elements already processed by Chosen
        .not('#field-ui-field-overview-form select, #field-ui-display-overview-form select, .wysiwyg, .draggable select[name$="[weight]"], .draggable select[name$="[position]"], .chosen-disable, .chosen-processed')
        .filter(function() {
          // Filter out select widgets that do not meet the minimum number of
          // options.
          var minOptions = $(this).attr('multiple') ? settings.chosen.minimum_multiple : settings.chosen.minimum_single;
          if (!minOptions) {
            // Zero value means no minimum.
            return true;
          }
          else {
            return $(this).find('option').length >= minOptions;
          }
        })
        .once('chosen', function() {
          options = getElementOptions(this);
          $(this).chosen(options);
        });
    }
  };
})(jQuery);

;/*})'"*/
;/*})'"*/
/* Chosen v1.2.0 | (c) 2011-2014 by Harvest | MIT License, https://github.com/harvesthq/chosen/blob/master/LICENSE.md */
!function(){var a,AbstractChosen,Chosen,SelectParser,b,c={}.hasOwnProperty,d=function(a,b){function d(){this.constructor=a}for(var e in b)c.call(b,e)&&(a[e]=b[e]);return d.prototype=b.prototype,a.prototype=new d,a.__super__=b.prototype,a};SelectParser=function(){function SelectParser(){this.options_index=0,this.parsed=[]}return SelectParser.prototype.add_node=function(a){return"OPTGROUP"===a.nodeName.toUpperCase()?this.add_group(a):this.add_option(a)},SelectParser.prototype.add_group=function(a){var b,c,d,e,f,g;for(b=this.parsed.length,this.parsed.push({array_index:b,group:!0,label:this.escapeExpression(a.label),children:0,disabled:a.disabled}),f=a.childNodes,g=[],d=0,e=f.length;e>d;d++)c=f[d],g.push(this.add_option(c,b,a.disabled));return g},SelectParser.prototype.add_option=function(a,b,c){return"OPTION"===a.nodeName.toUpperCase()?(""!==a.text?(null!=b&&(this.parsed[b].children+=1),this.parsed.push({array_index:this.parsed.length,options_index:this.options_index,value:a.value,text:a.text,html:a.innerHTML,selected:a.selected,disabled:c===!0?c:a.disabled,group_array_index:b,classes:a.className,style:a.style.cssText})):this.parsed.push({array_index:this.parsed.length,options_index:this.options_index,empty:!0}),this.options_index+=1):void 0},SelectParser.prototype.escapeExpression=function(a){var b,c;return null==a||a===!1?"":/[\&\<\>\"\'\`]/.test(a)?(b={"<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;","`":"&#x60;"},c=/&(?!\w+;)|[\<\>\"\'\`]/g,a.replace(c,function(a){return b[a]||"&amp;"})):a},SelectParser}(),SelectParser.select_to_array=function(a){var b,c,d,e,f;for(c=new SelectParser,f=a.childNodes,d=0,e=f.length;e>d;d++)b=f[d],c.add_node(b);return c.parsed},AbstractChosen=function(){function AbstractChosen(a,b){this.form_field=a,this.options=null!=b?b:{},AbstractChosen.browser_is_supported()&&(this.is_multiple=this.form_field.multiple,this.set_default_text(),this.set_default_values(),this.setup(),this.set_up_html(),this.register_observers())}return AbstractChosen.prototype.set_default_values=function(){var a=this;return this.click_test_action=function(b){return a.test_active_click(b)},this.activate_action=function(b){return a.activate_field(b)},this.active_field=!1,this.mouse_on_container=!1,this.results_showing=!1,this.result_highlighted=null,this.allow_single_deselect=null!=this.options.allow_single_deselect&&null!=this.form_field.options[0]&&""===this.form_field.options[0].text?this.options.allow_single_deselect:!1,this.disable_search_threshold=this.options.disable_search_threshold||0,this.disable_search=this.options.disable_search||!1,this.enable_split_word_search=null!=this.options.enable_split_word_search?this.options.enable_split_word_search:!0,this.group_search=null!=this.options.group_search?this.options.group_search:!0,this.search_contains=this.options.search_contains||!1,this.single_backstroke_delete=null!=this.options.single_backstroke_delete?this.options.single_backstroke_delete:!0,this.max_selected_options=this.options.max_selected_options||1/0,this.inherit_select_classes=this.options.inherit_select_classes||!1,this.display_selected_options=null!=this.options.display_selected_options?this.options.display_selected_options:!0,this.display_disabled_options=null!=this.options.display_disabled_options?this.options.display_disabled_options:!0},AbstractChosen.prototype.set_default_text=function(){return this.default_text=this.form_field.getAttribute("data-placeholder")?this.form_field.getAttribute("data-placeholder"):this.is_multiple?this.options.placeholder_text_multiple||this.options.placeholder_text||AbstractChosen.default_multiple_text:this.options.placeholder_text_single||this.options.placeholder_text||AbstractChosen.default_single_text,this.results_none_found=this.form_field.getAttribute("data-no_results_text")||this.options.no_results_text||AbstractChosen.default_no_result_text},AbstractChosen.prototype.mouse_enter=function(){return this.mouse_on_container=!0},AbstractChosen.prototype.mouse_leave=function(){return this.mouse_on_container=!1},AbstractChosen.prototype.input_focus=function(){var a=this;if(this.is_multiple){if(!this.active_field)return setTimeout(function(){return a.container_mousedown()},50)}else if(!this.active_field)return this.activate_field()},AbstractChosen.prototype.input_blur=function(){var a=this;return this.mouse_on_container?void 0:(this.active_field=!1,setTimeout(function(){return a.blur_test()},100))},AbstractChosen.prototype.results_option_build=function(a){var b,c,d,e,f;for(b="",f=this.results_data,d=0,e=f.length;e>d;d++)c=f[d],b+=c.group?this.result_add_group(c):this.result_add_option(c),(null!=a?a.first:void 0)&&(c.selected&&this.is_multiple?this.choice_build(c):c.selected&&!this.is_multiple&&this.single_set_selected_text(c.text));return b},AbstractChosen.prototype.result_add_option=function(a){var b,c;return a.search_match?this.include_option_in_results(a)?(b=[],a.disabled||a.selected&&this.is_multiple||b.push("active-result"),!a.disabled||a.selected&&this.is_multiple||b.push("disabled-result"),a.selected&&b.push("result-selected"),null!=a.group_array_index&&b.push("group-option"),""!==a.classes&&b.push(a.classes),c=document.createElement("li"),c.className=b.join(" "),c.style.cssText=a.style,c.setAttribute("data-option-array-index",a.array_index),c.innerHTML=a.search_text,this.outerHTML(c)):"":""},AbstractChosen.prototype.result_add_group=function(a){var b;return a.search_match||a.group_match?a.active_options>0?(b=document.createElement("li"),b.className="group-result",b.innerHTML=a.search_text,this.outerHTML(b)):"":""},AbstractChosen.prototype.results_update_field=function(){return this.set_default_text(),this.is_multiple||this.results_reset_cleanup(),this.result_clear_highlight(),this.results_build(),this.results_showing?this.winnow_results():void 0},AbstractChosen.prototype.reset_single_select_options=function(){var a,b,c,d,e;for(d=this.results_data,e=[],b=0,c=d.length;c>b;b++)a=d[b],a.selected?e.push(a.selected=!1):e.push(void 0);return e},AbstractChosen.prototype.results_toggle=function(){return this.results_showing?this.results_hide():this.results_show()},AbstractChosen.prototype.results_search=function(){return this.results_showing?this.winnow_results():this.results_show()},AbstractChosen.prototype.winnow_results=function(){var a,b,c,d,e,f,g,h,i,j,k,l;for(this.no_results_clear(),d=0,f=this.get_search_text(),a=f.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&"),i=new RegExp(a,"i"),c=this.get_search_regex(a),l=this.results_data,j=0,k=l.length;k>j;j++)b=l[j],b.search_match=!1,e=null,this.include_option_in_results(b)&&(b.group&&(b.group_match=!1,b.active_options=0),null!=b.group_array_index&&this.results_data[b.group_array_index]&&(e=this.results_data[b.group_array_index],0===e.active_options&&e.search_match&&(d+=1),e.active_options+=1),(!b.group||this.group_search)&&(b.search_text=b.group?b.label:b.text,b.search_match=this.search_string_match(b.search_text,c),b.search_match&&!b.group&&(d+=1),b.search_match?(f.length&&(g=b.search_text.search(i),h=b.search_text.substr(0,g+f.length)+"</em>"+b.search_text.substr(g+f.length),b.search_text=h.substr(0,g)+"<em>"+h.substr(g)),null!=e&&(e.group_match=!0)):null!=b.group_array_index&&this.results_data[b.group_array_index].search_match&&(b.search_match=!0)));return this.result_clear_highlight(),1>d&&f.length?(this.update_results_content(""),this.no_results(f)):(this.update_results_content(this.results_option_build()),this.winnow_results_set_highlight())},AbstractChosen.prototype.get_search_regex=function(a){var b;return b=this.search_contains?"":"^",new RegExp(b+a,"i")},AbstractChosen.prototype.search_string_match=function(a,b){var c,d,e,f;if(b.test(a))return!0;if(this.enable_split_word_search&&(a.indexOf(" ")>=0||0===a.indexOf("["))&&(d=a.replace(/\[|\]/g,"").split(" "),d.length))for(e=0,f=d.length;f>e;e++)if(c=d[e],b.test(c))return!0},AbstractChosen.prototype.choices_count=function(){var a,b,c,d;if(null!=this.selected_option_count)return this.selected_option_count;for(this.selected_option_count=0,d=this.form_field.options,b=0,c=d.length;c>b;b++)a=d[b],a.selected&&(this.selected_option_count+=1);return this.selected_option_count},AbstractChosen.prototype.choices_click=function(a){return a.preventDefault(),this.results_showing||this.is_disabled?void 0:this.results_show()},AbstractChosen.prototype.keyup_checker=function(a){var b,c;switch(b=null!=(c=a.which)?c:a.keyCode,this.search_field_scale(),b){case 8:if(this.is_multiple&&this.backstroke_length<1&&this.choices_count()>0)return this.keydown_backstroke();if(!this.pending_backstroke)return this.result_clear_highlight(),this.results_search();break;case 13:if(a.preventDefault(),this.results_showing)return this.result_select(a);break;case 27:return this.results_showing&&this.results_hide(),!0;case 9:case 38:case 40:case 16:case 91:case 17:break;default:return this.results_search()}},AbstractChosen.prototype.clipboard_event_checker=function(){var a=this;return setTimeout(function(){return a.results_search()},50)},AbstractChosen.prototype.container_width=function(){return null!=this.options.width?this.options.width:""+this.form_field.offsetWidth+"px"},AbstractChosen.prototype.include_option_in_results=function(a){return this.is_multiple&&!this.display_selected_options&&a.selected?!1:!this.display_disabled_options&&a.disabled?!1:a.empty?!1:!0},AbstractChosen.prototype.search_results_touchstart=function(a){return this.touch_started=!0,this.search_results_mouseover(a)},AbstractChosen.prototype.search_results_touchmove=function(a){return this.touch_started=!1,this.search_results_mouseout(a)},AbstractChosen.prototype.search_results_touchend=function(a){return this.touch_started?this.search_results_mouseup(a):void 0},AbstractChosen.prototype.outerHTML=function(a){var b;return a.outerHTML?a.outerHTML:(b=document.createElement("div"),b.appendChild(a),b.innerHTML)},AbstractChosen.browser_is_supported=function(){return"Microsoft Internet Explorer"===window.navigator.appName?document.documentMode>=8:/iP(od|hone)/i.test(window.navigator.userAgent)?!1:/Android/i.test(window.navigator.userAgent)&&/Mobile/i.test(window.navigator.userAgent)?!1:!0},AbstractChosen.default_multiple_text="Select Some Options",AbstractChosen.default_single_text="Select an Option",AbstractChosen.default_no_result_text="No results match",AbstractChosen}(),a=jQuery,a.fn.extend({chosen:function(b){return AbstractChosen.browser_is_supported()?this.each(function(){var c,d;c=a(this),d=c.data("chosen"),"destroy"===b&&d instanceof Chosen?d.destroy():d instanceof Chosen||c.data("chosen",new Chosen(this,b))}):this}}),Chosen=function(c){function Chosen(){return b=Chosen.__super__.constructor.apply(this,arguments)}return d(Chosen,c),Chosen.prototype.setup=function(){return this.form_field_jq=a(this.form_field),this.current_selectedIndex=this.form_field.selectedIndex,this.is_rtl=this.form_field_jq.hasClass("chosen-rtl")},Chosen.prototype.set_up_html=function(){var b,c;return b=["chosen-container"],b.push("chosen-container-"+(this.is_multiple?"multi":"single")),this.inherit_select_classes&&this.form_field.className&&b.push(this.form_field.className),this.is_rtl&&b.push("chosen-rtl"),c={"class":b.join(" "),style:"width: "+this.container_width()+";",title:this.form_field.title},this.form_field.id.length&&(c.id=this.form_field.id.replace(/[^\w]/g,"_")+"_chosen"),this.container=a("<div />",c),this.is_multiple?this.container.html('<ul class="chosen-choices"><li class="search-field"><input type="text" value="'+this.default_text+'" class="default" autocomplete="off" style="width:25px;" /></li></ul><div class="chosen-drop"><ul class="chosen-results"></ul></div>'):this.container.html('<a class="chosen-single chosen-default" tabindex="-1"><span>'+this.default_text+'</span><div><b></b></div></a><div class="chosen-drop"><div class="chosen-search"><input type="text" autocomplete="off" /></div><ul class="chosen-results"></ul></div>'),this.form_field_jq.hide().after(this.container),this.dropdown=this.container.find("div.chosen-drop").first(),this.search_field=this.container.find("input").first(),this.search_results=this.container.find("ul.chosen-results").first(),this.search_field_scale(),this.search_no_results=this.container.find("li.no-results").first(),this.is_multiple?(this.search_choices=this.container.find("ul.chosen-choices").first(),this.search_container=this.container.find("li.search-field").first()):(this.search_container=this.container.find("div.chosen-search").first(),this.selected_item=this.container.find(".chosen-single").first()),this.results_build(),this.set_tab_index(),this.set_label_behavior(),this.form_field_jq.trigger("chosen:ready",{chosen:this})},Chosen.prototype.register_observers=function(){var a=this;return this.container.bind("touchstart.chosen",function(b){a.container_mousedown(b)}),this.container.bind("touchend.chosen",function(b){a.container_mouseup(b)}),this.container.bind("mousedown.chosen",function(b){a.container_mousedown(b)}),this.container.bind("mouseup.chosen",function(b){a.container_mouseup(b)}),this.container.bind("mouseenter.chosen",function(b){a.mouse_enter(b)}),this.container.bind("mouseleave.chosen",function(b){a.mouse_leave(b)}),this.search_results.bind("mouseup.chosen",function(b){a.search_results_mouseup(b)}),this.search_results.bind("mouseover.chosen",function(b){a.search_results_mouseover(b)}),this.search_results.bind("mouseout.chosen",function(b){a.search_results_mouseout(b)}),this.search_results.bind("mousewheel.chosen DOMMouseScroll.chosen",function(b){a.search_results_mousewheel(b)}),this.search_results.bind("touchstart.chosen",function(b){a.search_results_touchstart(b)}),this.search_results.bind("touchmove.chosen",function(b){a.search_results_touchmove(b)}),this.search_results.bind("touchend.chosen",function(b){a.search_results_touchend(b)}),this.form_field_jq.bind("chosen:updated.chosen",function(b){a.results_update_field(b)}),this.form_field_jq.bind("chosen:activate.chosen",function(b){a.activate_field(b)}),this.form_field_jq.bind("chosen:open.chosen",function(b){a.container_mousedown(b)}),this.form_field_jq.bind("chosen:close.chosen",function(b){a.input_blur(b)}),this.search_field.bind("blur.chosen",function(b){a.input_blur(b)}),this.search_field.bind("keyup.chosen",function(b){a.keyup_checker(b)}),this.search_field.bind("keydown.chosen",function(b){a.keydown_checker(b)}),this.search_field.bind("focus.chosen",function(b){a.input_focus(b)}),this.search_field.bind("cut.chosen",function(b){a.clipboard_event_checker(b)}),this.search_field.bind("paste.chosen",function(b){a.clipboard_event_checker(b)}),this.is_multiple?this.search_choices.bind("click.chosen",function(b){a.choices_click(b)}):this.container.bind("click.chosen",function(a){a.preventDefault()})},Chosen.prototype.destroy=function(){return a(this.container[0].ownerDocument).unbind("click.chosen",this.click_test_action),this.search_field[0].tabIndex&&(this.form_field_jq[0].tabIndex=this.search_field[0].tabIndex),this.container.remove(),this.form_field_jq.removeData("chosen"),this.form_field_jq.show()},Chosen.prototype.search_field_disabled=function(){return this.is_disabled=this.form_field_jq[0].disabled,this.is_disabled?(this.container.addClass("chosen-disabled"),this.search_field[0].disabled=!0,this.is_multiple||this.selected_item.unbind("focus.chosen",this.activate_action),this.close_field()):(this.container.removeClass("chosen-disabled"),this.search_field[0].disabled=!1,this.is_multiple?void 0:this.selected_item.bind("focus.chosen",this.activate_action))},Chosen.prototype.container_mousedown=function(b){return this.is_disabled||(b&&"mousedown"===b.type&&!this.results_showing&&b.preventDefault(),null!=b&&a(b.target).hasClass("search-choice-close"))?void 0:(this.active_field?this.is_multiple||!b||a(b.target)[0]!==this.selected_item[0]&&!a(b.target).parents("a.chosen-single").length||(b.preventDefault(),this.results_toggle()):(this.is_multiple&&this.search_field.val(""),a(this.container[0].ownerDocument).bind("click.chosen",this.click_test_action),this.results_show()),this.activate_field())},Chosen.prototype.container_mouseup=function(a){return"ABBR"!==a.target.nodeName||this.is_disabled?void 0:this.results_reset(a)},Chosen.prototype.search_results_mousewheel=function(a){var b;return a.originalEvent&&(b=a.originalEvent.deltaY||-a.originalEvent.wheelDelta||a.originalEvent.detail),null!=b?(a.preventDefault(),"DOMMouseScroll"===a.type&&(b=40*b),this.search_results.scrollTop(b+this.search_results.scrollTop())):void 0},Chosen.prototype.blur_test=function(){return!this.active_field&&this.container.hasClass("chosen-container-active")?this.close_field():void 0},Chosen.prototype.close_field=function(){return a(this.container[0].ownerDocument).unbind("click.chosen",this.click_test_action),this.active_field=!1,this.results_hide(),this.container.removeClass("chosen-container-active"),this.clear_backstroke(),this.show_search_field_default(),this.search_field_scale()},Chosen.prototype.activate_field=function(){return this.container.addClass("chosen-container-active"),this.active_field=!0,this.search_field.val(this.search_field.val()),this.search_field.focus()},Chosen.prototype.test_active_click=function(b){var c;return c=a(b.target).closest(".chosen-container"),c.length&&this.container[0]===c[0]?this.active_field=!0:this.close_field()},Chosen.prototype.results_build=function(){return this.parsing=!0,this.selected_option_count=null,this.results_data=SelectParser.select_to_array(this.form_field),this.is_multiple?this.search_choices.find("li.search-choice").remove():this.is_multiple||(this.single_set_selected_text(),this.disable_search||this.form_field.options.length<=this.disable_search_threshold?(this.search_field[0].readOnly=!0,this.container.addClass("chosen-container-single-nosearch")):(this.search_field[0].readOnly=!1,this.container.removeClass("chosen-container-single-nosearch"))),this.update_results_content(this.results_option_build({first:!0})),this.search_field_disabled(),this.show_search_field_default(),this.search_field_scale(),this.parsing=!1},Chosen.prototype.result_do_highlight=function(a){var b,c,d,e,f;if(a.length){if(this.result_clear_highlight(),this.result_highlight=a,this.result_highlight.addClass("highlighted"),d=parseInt(this.search_results.css("maxHeight"),10),f=this.search_results.scrollTop(),e=d+f,c=this.result_highlight.position().top+this.search_results.scrollTop(),b=c+this.result_highlight.outerHeight(),b>=e)return this.search_results.scrollTop(b-d>0?b-d:0);if(f>c)return this.search_results.scrollTop(c)}},Chosen.prototype.result_clear_highlight=function(){return this.result_highlight&&this.result_highlight.removeClass("highlighted"),this.result_highlight=null},Chosen.prototype.results_show=function(){return this.is_multiple&&this.max_selected_options<=this.choices_count()?(this.form_field_jq.trigger("chosen:maxselected",{chosen:this}),!1):(this.container.addClass("chosen-with-drop"),this.results_showing=!0,this.search_field.focus(),this.search_field.val(this.search_field.val()),this.winnow_results(),this.form_field_jq.trigger("chosen:showing_dropdown",{chosen:this}))},Chosen.prototype.update_results_content=function(a){return this.search_results.html(a)},Chosen.prototype.results_hide=function(){return this.results_showing&&(this.result_clear_highlight(),this.container.removeClass("chosen-with-drop"),this.form_field_jq.trigger("chosen:hiding_dropdown",{chosen:this})),this.results_showing=!1},Chosen.prototype.set_tab_index=function(){var a;return this.form_field.tabIndex?(a=this.form_field.tabIndex,this.form_field.tabIndex=-1,this.search_field[0].tabIndex=a):void 0},Chosen.prototype.set_label_behavior=function(){var b=this;return this.form_field_label=this.form_field_jq.parents("label"),!this.form_field_label.length&&this.form_field.id.length&&(this.form_field_label=a("label[for='"+this.form_field.id+"']")),this.form_field_label.length>0?this.form_field_label.bind("click.chosen",function(a){return b.is_multiple?b.container_mousedown(a):b.activate_field()}):void 0},Chosen.prototype.show_search_field_default=function(){return this.is_multiple&&this.choices_count()<1&&!this.active_field?(this.search_field.val(this.default_text),this.search_field.addClass("default")):(this.search_field.val(""),this.search_field.removeClass("default"))},Chosen.prototype.search_results_mouseup=function(b){var c;return c=a(b.target).hasClass("active-result")?a(b.target):a(b.target).parents(".active-result").first(),c.length?(this.result_highlight=c,this.result_select(b),this.search_field.focus()):void 0},Chosen.prototype.search_results_mouseover=function(b){var c;return c=a(b.target).hasClass("active-result")?a(b.target):a(b.target).parents(".active-result").first(),c?this.result_do_highlight(c):void 0},Chosen.prototype.search_results_mouseout=function(b){return a(b.target).hasClass("active-result")?this.result_clear_highlight():void 0},Chosen.prototype.choice_build=function(b){var c,d,e=this;return c=a("<li />",{"class":"search-choice"}).html("<span>"+b.html+"</span>"),b.disabled?c.addClass("search-choice-disabled"):(d=a("<a />",{"class":"search-choice-close","data-option-array-index":b.array_index}),d.bind("click.chosen",function(a){return e.choice_destroy_link_click(a)}),c.append(d)),this.search_container.before(c)},Chosen.prototype.choice_destroy_link_click=function(b){return b.preventDefault(),b.stopPropagation(),this.is_disabled?void 0:this.choice_destroy(a(b.target))},Chosen.prototype.choice_destroy=function(a){return this.result_deselect(a[0].getAttribute("data-option-array-index"))?(this.show_search_field_default(),this.is_multiple&&this.choices_count()>0&&this.search_field.val().length<1&&this.results_hide(),a.parents("li").first().remove(),this.search_field_scale()):void 0},Chosen.prototype.results_reset=function(){return this.reset_single_select_options(),this.form_field.options[0].selected=!0,this.single_set_selected_text(),this.show_search_field_default(),this.results_reset_cleanup(),this.form_field_jq.trigger("change"),this.active_field?this.results_hide():void 0},Chosen.prototype.results_reset_cleanup=function(){return this.current_selectedIndex=this.form_field.selectedIndex,this.selected_item.find("abbr").remove()},Chosen.prototype.result_select=function(a){var b,c;return this.result_highlight?(b=this.result_highlight,this.result_clear_highlight(),this.is_multiple&&this.max_selected_options<=this.choices_count()?(this.form_field_jq.trigger("chosen:maxselected",{chosen:this}),!1):(this.is_multiple?b.removeClass("active-result"):this.reset_single_select_options(),c=this.results_data[b[0].getAttribute("data-option-array-index")],c.selected=!0,this.form_field.options[c.options_index].selected=!0,this.selected_option_count=null,this.is_multiple?this.choice_build(c):this.single_set_selected_text(c.text),(a.metaKey||a.ctrlKey)&&this.is_multiple||this.results_hide(),this.search_field.val(""),(this.is_multiple||this.form_field.selectedIndex!==this.current_selectedIndex)&&this.form_field_jq.trigger("change",{selected:this.form_field.options[c.options_index].value}),this.current_selectedIndex=this.form_field.selectedIndex,this.search_field_scale())):void 0},Chosen.prototype.single_set_selected_text=function(a){return null==a&&(a=this.default_text),a===this.default_text?this.selected_item.addClass("chosen-default"):(this.single_deselect_control_build(),this.selected_item.removeClass("chosen-default")),this.selected_item.find("span").text(a)},Chosen.prototype.result_deselect=function(a){var b;return b=this.results_data[a],this.form_field.options[b.options_index].disabled?!1:(b.selected=!1,this.form_field.options[b.options_index].selected=!1,this.selected_option_count=null,this.result_clear_highlight(),this.results_showing&&this.winnow_results(),this.form_field_jq.trigger("change",{deselected:this.form_field.options[b.options_index].value}),this.search_field_scale(),!0)},Chosen.prototype.single_deselect_control_build=function(){return this.allow_single_deselect?(this.selected_item.find("abbr").length||this.selected_item.find("span").first().after('<abbr class="search-choice-close"></abbr>'),this.selected_item.addClass("chosen-single-with-deselect")):void 0},Chosen.prototype.get_search_text=function(){return this.search_field.val()===this.default_text?"":a("<div/>").text(a.trim(this.search_field.val())).html()},Chosen.prototype.winnow_results_set_highlight=function(){var a,b;return b=this.is_multiple?[]:this.search_results.find(".result-selected.active-result"),a=b.length?b.first():this.search_results.find(".active-result").first(),null!=a?this.result_do_highlight(a):void 0},Chosen.prototype.no_results=function(b){var c;return c=a('<li class="no-results">'+this.results_none_found+' "<span></span>"</li>'),c.find("span").first().html(b),this.search_results.append(c),this.form_field_jq.trigger("chosen:no_results",{chosen:this})},Chosen.prototype.no_results_clear=function(){return this.search_results.find(".no-results").remove()},Chosen.prototype.keydown_arrow=function(){var a;return this.results_showing&&this.result_highlight?(a=this.result_highlight.nextAll("li.active-result").first())?this.result_do_highlight(a):void 0:this.results_show()},Chosen.prototype.keyup_arrow=function(){var a;return this.results_showing||this.is_multiple?this.result_highlight?(a=this.result_highlight.prevAll("li.active-result"),a.length?this.result_do_highlight(a.first()):(this.choices_count()>0&&this.results_hide(),this.result_clear_highlight())):void 0:this.results_show()},Chosen.prototype.keydown_backstroke=function(){var a;return this.pending_backstroke?(this.choice_destroy(this.pending_backstroke.find("a").first()),this.clear_backstroke()):(a=this.search_container.siblings("li.search-choice").last(),a.length&&!a.hasClass("search-choice-disabled")?(this.pending_backstroke=a,this.single_backstroke_delete?this.keydown_backstroke():this.pending_backstroke.addClass("search-choice-focus")):void 0)},Chosen.prototype.clear_backstroke=function(){return this.pending_backstroke&&this.pending_backstroke.removeClass("search-choice-focus"),this.pending_backstroke=null},Chosen.prototype.keydown_checker=function(a){var b,c;switch(b=null!=(c=a.which)?c:a.keyCode,this.search_field_scale(),8!==b&&this.pending_backstroke&&this.clear_backstroke(),b){case 8:this.backstroke_length=this.search_field.val().length;break;case 9:this.results_showing&&!this.is_multiple&&this.result_select(a),this.mouse_on_container=!1;break;case 13:this.results_showing&&a.preventDefault();break;case 32:this.disable_search&&a.preventDefault();break;case 38:a.preventDefault(),this.keyup_arrow();break;case 40:a.preventDefault(),this.keydown_arrow()}},Chosen.prototype.search_field_scale=function(){var b,c,d,e,f,g,h,i,j;if(this.is_multiple){for(d=0,h=0,f="position:absolute; left: -1000px; top: -1000px; display:none;",g=["font-size","font-style","font-weight","font-family","line-height","text-transform","letter-spacing"],i=0,j=g.length;j>i;i++)e=g[i],f+=e+":"+this.search_field.css(e)+";";return b=a("<div />",{style:f}),b.text(this.search_field.val()),a("body").append(b),h=b.width()+25,b.remove(),c=this.container.outerWidth(),h>c-10&&(h=c-10),this.search_field.css({width:h+"px"})}},Chosen}(AbstractChosen)}.call(this);
;/*})'"*/
;/*})'"*/
// OpenLayers 3. See http://openlayers.org/
// License: https://raw.githubusercontent.com/openlayers/ol3/master/LICENSE.md
// Version: v3.10.1-162-gf2ff1f3

(function (root, factory) {
  if (typeof exports === "object") {
    module.exports = factory();
  } else if (typeof define === "function" && define.amd) {
    define([], factory);
  } else {
    root.ol = factory();
  }
}(this, function () {
  var OPENLAYERS = {};
  var l,aa=aa||{},ba=this;function ca(a){return void 0!==a}function u(a,c,d){a=a.split(".");d=d||ba;a[0]in d||!d.execScript||d.execScript("var "+a[0]);for(var e;a.length&&(e=a.shift());)!a.length&&ca(c)?d[e]=c:d[e]?d=d[e]:d=d[e]={}}function da(){}function ea(a){a.Hb=function(){return a.ng?a.ng:a.ng=new a}}
function fa(a){var c=typeof a;if("object"==c)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return c;var d=Object.prototype.toString.call(a);if("[object Window]"==d)return"object";if("[object Array]"==d||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==d||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==c&&"undefined"==typeof a.call)return"object";return c}function ga(a){return"array"==fa(a)}function ha(a){var c=fa(a);return"array"==c||"object"==c&&"number"==typeof a.length}function ia(a){return"string"==typeof a}function ja(a){return"number"==typeof a}function ka(a){return"function"==fa(a)}function la(a){var c=typeof a;return"object"==c&&null!=a||"function"==c}function v(a){return a[ma]||(a[ma]=++na)}var ma="closure_uid_"+(1E9*Math.random()>>>0),na=0;
function pa(a,c,d){return a.call.apply(a.bind,arguments)}function qa(a,c,d){if(!a)throw Error();if(2<arguments.length){var e=Array.prototype.slice.call(arguments,2);return function(){var d=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(d,e);return a.apply(c,d)}}return function(){return a.apply(c,arguments)}}function sa(a,c,d){sa=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?pa:qa;return sa.apply(null,arguments)}
function ta(a,c){var d=Array.prototype.slice.call(arguments,1);return function(){var c=d.slice();c.push.apply(c,arguments);return a.apply(this,c)}}var ua=Date.now||function(){return+new Date};function w(a,c){function d(){}d.prototype=c.prototype;a.ba=c.prototype;a.prototype=new d;a.prototype.constructor=a;a.Lo=function(a,d,g){for(var h=Array(arguments.length-2),k=2;k<arguments.length;k++)h[k-2]=arguments[k];return c.prototype[d].apply(a,h)}};var va,wa;function xa(){};function ya(a){if(Error.captureStackTrace)Error.captureStackTrace(this,ya);else{var c=Error().stack;c&&(this.stack=c)}a&&(this.message=String(a))}w(ya,Error);ya.prototype.name="CustomError";var za;function Aa(a,c){var d=a.length-c.length;return 0<=d&&a.indexOf(c,d)==d}function Ba(a,c){for(var d=a.split("%s"),e="",f=Array.prototype.slice.call(arguments,1);f.length&&1<d.length;)e+=d.shift()+f.shift();return e+d.join("%s")}var Ca=String.prototype.trim?function(a){return a.trim()}:function(a){return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g,"")};
function Da(a){if(!Ea.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(Fa,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(Ha,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(Ia,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(Ja,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(Ka,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(Ma,"&#0;"));return a}var Fa=/&/g,Ha=/</g,Ia=/>/g,Ja=/"/g,Ka=/'/g,Ma=/\x00/g,Ea=/[\x00&<>"']/,Na=String.prototype.repeat?function(a,c){return a.repeat(c)}:function(a,c){return Array(c+1).join(a)};
function Pa(a){a=ca(void 0)?a.toFixed(void 0):String(a);var c=a.indexOf(".");-1==c&&(c=a.length);return Na("0",Math.max(0,2-c))+a}
function Qa(a,c){for(var d=0,e=Ca(String(a)).split("."),f=Ca(String(c)).split("."),g=Math.max(e.length,f.length),h=0;0==d&&h<g;h++){var k=e[h]||"",m=f[h]||"",n=RegExp("(\\d*)(\\D*)","g"),p=RegExp("(\\d*)(\\D*)","g");do{var q=n.exec(k)||["","",""],r=p.exec(m)||["","",""];if(0==q[0].length&&0==r[0].length)break;d=Ra(0==q[1].length?0:parseInt(q[1],10),0==r[1].length?0:parseInt(r[1],10))||Ra(0==q[2].length,0==r[2].length)||Ra(q[2],r[2])}while(0==d)}return d}function Ra(a,c){return a<c?-1:a>c?1:0};function Sa(a,c,d){return Math.min(Math.max(a,c),d)}var Ta=function(){var a;"cosh"in Math?a=Math.cosh:a=function(a){a=Math.exp(a);return(a+1/a)/2};return a}();function Ua(a,c,d,e,f,g){var h=f-d,k=g-e;if(0!==h||0!==k){var m=((a-d)*h+(c-e)*k)/(h*h+k*k);1<m?(d=f,e=g):0<m&&(d+=h*m,e+=k*m)}return Va(a,c,d,e)}function Va(a,c,d,e){a=d-a;c=e-c;return a*a+c*c}function Wa(a){return a*Math.PI/180};function Xa(a){return function(c){if(c)return[Sa(c[0],a[0],a[2]),Sa(c[1],a[1],a[3])]}}function Ya(a){return a};var Za=Array.prototype;function $a(a,c){return Za.indexOf.call(a,c,void 0)}function ab(a,c){Za.forEach.call(a,c,void 0)}function bb(a,c){return Za.filter.call(a,c,void 0)}function cb(a,c){return Za.map.call(a,c,void 0)}function db(a,c){return Za.some.call(a,c,void 0)}function fb(a,c){var d=gb(a,c,void 0);return 0>d?null:ia(a)?a.charAt(d):a[d]}function gb(a,c,d){for(var e=a.length,f=ia(a)?a.split(""):a,g=0;g<e;g++)if(g in f&&c.call(d,f[g],g,a))return g;return-1}
function hb(a,c){var d=$a(a,c),e;(e=0<=d)&&Za.splice.call(a,d,1);return e}function ib(a){return Za.concat.apply(Za,arguments)}function jb(a){var c=a.length;if(0<c){for(var d=Array(c),e=0;e<c;e++)d[e]=a[e];return d}return[]}function kb(a,c){for(var d=1;d<arguments.length;d++){var e=arguments[d];if(ha(e)){var f=a.length||0,g=e.length||0;a.length=f+g;for(var h=0;h<g;h++)a[f+h]=e[h]}else a.push(e)}}function lb(a,c,d,e){Za.splice.apply(a,mb(arguments,1))}
function mb(a,c,d){return 2>=arguments.length?Za.slice.call(a,c):Za.slice.call(a,c,d)}function nb(a,c){a.sort(c||ob)}function pb(a){for(var c=qb,d=0;d<a.length;d++)a[d]={index:d,value:a[d]};var e=c||ob;nb(a,function(a,c){return e(a.value,c.value)||a.index-c.index});for(d=0;d<a.length;d++)a[d]=a[d].value}function rb(a,c){if(!ha(a)||!ha(c)||a.length!=c.length)return!1;for(var d=a.length,e=sb,f=0;f<d;f++)if(!e(a[f],c[f]))return!1;return!0}function ob(a,c){return a>c?1:a<c?-1:0}
function sb(a,c){return a===c}function tb(a){for(var c=[],d=0;d<arguments.length;d++){var e=arguments[d];if(ga(e))for(var f=0;f<e.length;f+=8192)for(var g=tb.apply(null,mb(e,f,f+8192)),h=0;h<g.length;h++)c.push(g[h]);else c.push(e)}return c};function ub(a,c){return 0<=a.indexOf(c)}function vb(a,c,d){var e=a.length;if(a[0]<=c)return 0;if(!(c<=a[e-1]))if(0<d)for(d=1;d<e;++d){if(a[d]<c)return d-1}else if(0>d)for(d=1;d<e;++d){if(a[d]<=c)return d}else for(d=1;d<e;++d){if(a[d]==c)return d;if(a[d]<c)return a[d-1]-c<c-a[d]?d-1:d}return e-1};function wb(a){return function(c,d,e){if(void 0!==c)return c=vb(a,c,e),c=Sa(c+d,0,a.length-1),a[c]}}function xb(a,c,d){return function(e,f,g){if(void 0!==e)return e=Math.max(Math.floor(Math.log(c/e)/Math.log(a)+(0<g?0:0>g?1:.5))+f,0),void 0!==d&&(e=Math.min(e,d)),c/Math.pow(a,e)}};function yb(a){if(void 0!==a)return 0}function zb(a,c){if(void 0!==a)return a+c}function Ab(a){var c=2*Math.PI/a;return function(a,e){if(void 0!==a)return a=Math.floor((a+e)/c+.5)*c}}function Bb(){var a=Wa(5);return function(c,d){if(void 0!==c)return Math.abs(c+d)<=a?0:c+d}};function Cb(a,c,d){this.center=a;this.resolution=c;this.rotation=d};var Db;a:{var Eb=ba.navigator;if(Eb){var Fb=Eb.userAgent;if(Fb){Db=Fb;break a}}Db=""}function Gb(a){return-1!=Db.indexOf(a)};function Hb(a,c,d){for(var e in a)c.call(d,a[e],e,a)}function Jb(a,c){for(var d in a)if(c.call(void 0,a[d],d,a))return!0;return!1}function Kb(a){var c=0,d;for(d in a)c++;return c}function Lb(a){var c=[],d=0,e;for(e in a)c[d++]=a[e];return c}function Mb(a){var c=[],d=0,e;for(e in a)c[d++]=e;return c}function Nb(a,c){return c in a}function Ob(a,c){for(var d in a)if(a[d]==c)return!0;return!1}function Pb(a,c){for(var d in a)if(c.call(void 0,a[d],d,a))return d}
function Qb(a){for(var c in a)return!1;return!0}function Rb(a){for(var c in a)delete a[c]}function Sb(a,c,d){return c in a?a[c]:d}function Tb(a,c){var d=[];return c in a?a[c]:a[c]=d}function Ub(a){var c={},d;for(d in a)c[d]=a[d];return c}function Vb(a){var c=fa(a);if("object"==c||"array"==c){if(ka(a.clone))return a.clone();var c="array"==c?[]:{},d;for(d in a)c[d]=Vb(a[d]);return c}return a}var Wb="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
function Xb(a,c){for(var d,e,f=1;f<arguments.length;f++){e=arguments[f];for(d in e)a[d]=e[d];for(var g=0;g<Wb.length;g++)d=Wb[g],Object.prototype.hasOwnProperty.call(e,d)&&(a[d]=e[d])}};var Yb=Gb("Opera")||Gb("OPR"),Zb=Gb("Trident")||Gb("MSIE"),$b=Gb("Edge"),ac=Gb("Gecko")&&!(-1!=Db.toLowerCase().indexOf("webkit")&&!Gb("Edge"))&&!(Gb("Trident")||Gb("MSIE"))&&!Gb("Edge"),bc=-1!=Db.toLowerCase().indexOf("webkit")&&!Gb("Edge"),cc=Gb("Macintosh"),dc=Gb("Windows"),ec=Gb("Linux")||Gb("CrOS");function fc(){var a=Db;if(ac)return/rv\:([^\);]+)(\)|;)/.exec(a);if($b)return/Edge\/([\d\.]+)/.exec(a);if(Zb)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);if(bc)return/WebKit\/(\S+)/.exec(a)}
function gc(){var a=ba.document;return a?a.documentMode:void 0}var hc=function(){if(Yb&&ba.opera){var a;var c=ba.opera.version;try{a=c()}catch(d){a=c}return a}a="";(c=fc())&&(a=c?c[1]:"");return Zb&&(c=gc(),c>parseFloat(a))?String(c):a}(),ic={};function jc(a){return ic[a]||(ic[a]=0<=Qa(hc,a))}var kc=ba.document,lc=kc&&Zb?gc()||("CSS1Compat"==kc.compatMode?parseInt(hc,10):5):void 0;var mc=!Zb||9<=lc,nc=!Zb||9<=lc,pc=Zb&&!jc("9");!bc||jc("528");ac&&jc("1.9b")||Zb&&jc("8")||Yb&&jc("9.5")||bc&&jc("528");ac&&!jc("8")||Zb&&jc("9");function qc(){0!=rc&&(sc[v(this)]=this);this.fa=this.fa;this.ka=this.ka}var rc=0,sc={};qc.prototype.fa=!1;qc.prototype.sc=function(){if(!this.fa&&(this.fa=!0,this.W(),0!=rc)){var a=v(this);delete sc[a]}};function tc(a,c){var d=ta(uc,c);a.fa?d.call(void 0):(a.ka||(a.ka=[]),a.ka.push(ca(void 0)?sa(d,void 0):d))}qc.prototype.W=function(){if(this.ka)for(;this.ka.length;)this.ka.shift()()};function uc(a){a&&"function"==typeof a.sc&&a.sc()};function vc(a,c){this.type=a;this.g=this.target=c;this.j=!1;this.mh=!0}vc.prototype.c=function(){this.j=!0};vc.prototype.preventDefault=function(){this.mh=!1};function wc(a){a.c()}function xc(a){a.preventDefault()};var yc=Zb?"focusout":"DOMFocusOut";function zc(a){zc[" "](a);return a}zc[" "]=da;function Ac(a,c){vc.call(this,a?a.type:"");this.relatedTarget=this.g=this.target=null;this.v=this.i=this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.A=this.f=this.a=this.D=!1;this.state=null;this.l=!1;this.b=null;if(a){var d=this.type=a.type,e=a.changedTouches?a.changedTouches[0]:null;this.target=a.target||a.srcElement;this.g=c;var f=a.relatedTarget;if(f){if(ac){var g;a:{try{zc(f.nodeName);g=!0;break a}catch(h){}g=!1}g||(f=null)}}else"mouseover"==d?
f=a.fromElement:"mouseout"==d&&(f=a.toElement);this.relatedTarget=f;null===e?(this.offsetX=bc||void 0!==a.offsetX?a.offsetX:a.layerX,this.offsetY=bc||void 0!==a.offsetY?a.offsetY:a.layerY,this.clientX=void 0!==a.clientX?a.clientX:a.pageX,this.clientY=void 0!==a.clientY?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0):(this.clientX=void 0!==e.clientX?e.clientX:e.pageX,this.clientY=void 0!==e.clientY?e.clientY:e.pageY,this.screenX=e.screenX||0,this.screenY=e.screenY||0);this.button=
a.button;this.i=a.keyCode||0;this.v=a.charCode||("keypress"==d?a.keyCode:0);this.D=a.ctrlKey;this.a=a.altKey;this.f=a.shiftKey;this.A=a.metaKey;this.l=cc?a.metaKey:a.ctrlKey;this.state=a.state;this.b=a;a.defaultPrevented&&this.preventDefault()}}w(Ac,vc);var Bc=[1,4,2];function Cc(a){return(mc?0==a.b.button:"click"==a.type?!0:!!(a.b.button&Bc[0]))&&!(bc&&cc&&a.D)}Ac.prototype.c=function(){Ac.ba.c.call(this);this.b.stopPropagation?this.b.stopPropagation():this.b.cancelBubble=!0};
Ac.prototype.preventDefault=function(){Ac.ba.preventDefault.call(this);var a=this.b;if(a.preventDefault)a.preventDefault();else if(a.returnValue=!1,pc)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(c){}};var Dc="closure_listenable_"+(1E6*Math.random()|0);function Ec(a){return!(!a||!a[Dc])}var Fc=0;function Gc(a,c,d,e,f){this.listener=a;this.b=null;this.src=c;this.type=d;this.Tc=!!e;this.Ud=f;this.key=++Fc;this.Jc=this.Bd=!1}function Hc(a){a.Jc=!0;a.listener=null;a.b=null;a.src=null;a.Ud=null};function Ic(a){this.src=a;this.b={};this.a=0}Ic.prototype.add=function(a,c,d,e,f){var g=a.toString();a=this.b[g];a||(a=this.b[g]=[],this.a++);var h=Jc(a,c,e,f);-1<h?(c=a[h],d||(c.Bd=!1)):(c=new Gc(c,this.src,g,!!e,f),c.Bd=d,a.push(c));return c};Ic.prototype.remove=function(a,c,d,e){a=a.toString();if(!(a in this.b))return!1;var f=this.b[a];c=Jc(f,c,d,e);return-1<c?(Hc(f[c]),Za.splice.call(f,c,1),0==f.length&&(delete this.b[a],this.a--),!0):!1};
function Kc(a,c){var d=c.type;if(!(d in a.b))return!1;var e=hb(a.b[d],c);e&&(Hc(c),0==a.b[d].length&&(delete a.b[d],a.a--));return e}function Lc(a,c,d,e,f){a=a.b[c.toString()];c=-1;a&&(c=Jc(a,d,e,f));return-1<c?a[c]:null}function Nc(a,c,d){var e=ca(c),f=e?c.toString():"",g=ca(d);return Jb(a.b,function(a){for(var c=0;c<a.length;++c)if(!(e&&a[c].type!=f||g&&a[c].Tc!=d))return!0;return!1})}
function Jc(a,c,d,e){for(var f=0;f<a.length;++f){var g=a[f];if(!g.Jc&&g.listener==c&&g.Tc==!!d&&g.Ud==e)return f}return-1};var Oc="closure_lm_"+(1E6*Math.random()|0),Pc={},Qc=0;function B(a,c,d,e,f){if(ga(c)){for(var g=0;g<c.length;g++)B(a,c[g],d,e,f);return null}d=Rc(d);return Ec(a)?a.Ka(c,d,e,f):Sc(a,c,d,!1,e,f)}
function Sc(a,c,d,e,f,g){if(!c)throw Error("Invalid event type");var h=!!f,k=Tc(a);k||(a[Oc]=k=new Ic(a));d=k.add(c,d,e,f,g);if(d.b)return d;e=Uc();d.b=e;e.src=a;e.listener=d;if(a.addEventListener)a.addEventListener(c.toString(),e,h);else if(a.attachEvent)a.attachEvent(Vc(c.toString()),e);else throw Error("addEventListener and attachEvent are unavailable.");Qc++;return d}
function Uc(){var a=Wc,c=nc?function(d){return a.call(c.src,c.listener,d)}:function(d){d=a.call(c.src,c.listener,d);if(!d)return d};return c}function Xc(a,c,d,e,f){if(ga(c)){for(var g=0;g<c.length;g++)Xc(a,c[g],d,e,f);return null}d=Rc(d);return Ec(a)?a.nb.add(String(c),d,!0,e,f):Sc(a,c,d,!0,e,f)}function Yc(a,c,d,e,f){if(ga(c))for(var g=0;g<c.length;g++)Yc(a,c[g],d,e,f);else d=Rc(d),Ec(a)?a.Ef(c,d,e,f):a&&(a=Tc(a))&&(c=Lc(a,c,d,!!e,f))&&Zc(c)}
function Zc(a){if(ja(a)||!a||a.Jc)return!1;var c=a.src;if(Ec(c))return Kc(c.nb,a);var d=a.type,e=a.b;c.removeEventListener?c.removeEventListener(d,e,a.Tc):c.detachEvent&&c.detachEvent(Vc(d),e);Qc--;(d=Tc(c))?(Kc(d,a),0==d.a&&(d.src=null,c[Oc]=null)):Hc(a);return!0}function Vc(a){return a in Pc?Pc[a]:Pc[a]="on"+a}function $c(a,c,d,e){var f=!0;if(a=Tc(a))if(c=a.b[c.toString()])for(c=c.concat(),a=0;a<c.length;a++){var g=c[a];g&&g.Tc==d&&!g.Jc&&(g=ad(g,e),f=f&&!1!==g)}return f}
function ad(a,c){var d=a.listener,e=a.Ud||a.src;a.Bd&&Zc(a);return d.call(e,c)}
function Wc(a,c){if(a.Jc)return!0;if(!nc){var d;if(!(d=c))a:{d=["window","event"];for(var e=ba,f;f=d.shift();)if(null!=e[f])e=e[f];else{d=null;break a}d=e}f=d;d=new Ac(f,this);e=!0;if(!(0>f.keyCode||void 0!=f.returnValue)){a:{var g=!1;if(0==f.keyCode)try{f.keyCode=-1;break a}catch(m){g=!0}if(g||void 0==f.returnValue)f.returnValue=!0}f=[];for(g=d.g;g;g=g.parentNode)f.push(g);for(var g=a.type,h=f.length-1;!d.j&&0<=h;h--){d.g=f[h];var k=$c(f[h],g,!0,d),e=e&&k}for(h=0;!d.j&&h<f.length;h++)d.g=f[h],k=
$c(f[h],g,!1,d),e=e&&k}return e}return ad(a,new Ac(c,this))}function Tc(a){a=a[Oc];return a instanceof Ic?a:null}var bd="__closure_events_fn_"+(1E9*Math.random()>>>0);function Rc(a){if(ka(a))return a;a[bd]||(a[bd]=function(c){return a.handleEvent(c)});return a[bd]};function cd(){qc.call(this);this.nb=new Ic(this);this.xd=this;this.Ta=null}w(cd,qc);cd.prototype[Dc]=!0;l=cd.prototype;l.addEventListener=function(a,c,d,e){B(this,a,c,d,e)};l.removeEventListener=function(a,c,d,e){Yc(this,a,c,d,e)};
l.u=function(a){var c,d=this.Ta;if(d)for(c=[];d;d=d.Ta)c.push(d);var d=this.xd,e=a.type||a;if(ia(a))a=new vc(a,d);else if(a instanceof vc)a.target=a.target||d;else{var f=a;a=new vc(e,d);Xb(a,f)}var f=!0,g;if(c)for(var h=c.length-1;!a.j&&0<=h;h--)g=a.g=c[h],f=dd(g,e,!0,a)&&f;a.j||(g=a.g=d,f=dd(g,e,!0,a)&&f,a.j||(f=dd(g,e,!1,a)&&f));if(c)for(h=0;!a.j&&h<c.length;h++)g=a.g=c[h],f=dd(g,e,!1,a)&&f;return f};
l.W=function(){cd.ba.W.call(this);if(this.nb){var a=this.nb,c=0,d;for(d in a.b){for(var e=a.b[d],f=0;f<e.length;f++)++c,Hc(e[f]);delete a.b[d];a.a--}}this.Ta=null};l.Ka=function(a,c,d,e){return this.nb.add(String(a),c,!1,d,e)};l.Ef=function(a,c,d,e){return this.nb.remove(String(a),c,d,e)};
function dd(a,c,d,e){c=a.nb.b[String(c)];if(!c)return!0;c=c.concat();for(var f=!0,g=0;g<c.length;++g){var h=c[g];if(h&&!h.Jc&&h.Tc==d){var k=h.listener,m=h.Ud||h.src;h.Bd&&Kc(a.nb,h);f=!1!==k.call(m,e)&&f}}return f&&0!=e.mh}function ed(a,c,d){return Nc(a.nb,ca(c)?String(c):void 0,d)};function fd(){cd.call(this);this.b=0}w(fd,cd);function gd(a){Zc(a)}l=fd.prototype;l.s=function(){++this.b;this.u("change")};l.M=function(){return this.b};l.G=function(a,c,d){return B(this,a,c,!1,d)};l.N=function(a,c,d){return Xc(this,a,c,!1,d)};l.L=function(a,c,d){Yc(this,a,c,!1,d)};l.O=gd;function hd(a,c,d){vc.call(this,a);this.key=c;this.oldValue=d}w(hd,vc);function id(a){fd.call(this);v(this);this.D={};void 0!==a&&this.K(a)}w(id,fd);var jd={};function kd(a){return jd.hasOwnProperty(a)?jd[a]:jd[a]="change:"+a}l=id.prototype;l.get=function(a){var c;this.D.hasOwnProperty(a)&&(c=this.D[a]);return c};l.R=function(){return Object.keys(this.D)};l.S=function(){var a={},c;for(c in this.D)a[c]=this.D[c];return a};
function ld(a,c,d){var e;e=kd(c);a.u(new hd(e,c,d));a.u(new hd("propertychange",c,d))}l.set=function(a,c){var d=this.D[a];this.D[a]=c;ld(this,a,d)};l.K=function(a){for(var c in a)this.set(c,a[c])};l.U=function(a){if(a in this.D){var c=this.D[a];delete this.D[a];ld(this,a,c)}};function md(a,c,d){void 0===d&&(d=[0,0]);d[0]=a[0]+2*c;d[1]=a[1]+2*c;return d}function nd(a,c,d){void 0===d&&(d=[0,0]);d[0]=a[0]*c+.5|0;d[1]=a[1]*c+.5|0;return d}function od(a,c){if(ga(a))return a;void 0===c?c=[a,a]:(c[0]=a,c[1]=a);return c};function pd(a,c){var d=a%c;return 0>d*c?d+c:d}function qd(a,c,d){return a+d*(c-a)};function rd(a,c){a[0]+=c[0];a[1]+=c[1];return a}function sd(a,c){var d=a[0],e=a[1],f=c[0],g=c[1],h=f[0],f=f[1],k=g[0],g=g[1],m=k-h,n=g-f,d=0===m&&0===n?0:(m*(d-h)+n*(e-f))/(m*m+n*n||0);0>=d||(1<=d?(h=k,f=g):(h+=d*m,f+=d*n));return[h,f]}function td(a,c){var d=pd(a+180,360)-180,e=Math.abs(Math.round(3600*d));return Math.floor(e/3600)+"\u00b0 "+Pa(Math.floor(e/60%60))+"\u2032 "+Pa(Math.floor(e%60))+"\u2033 "+c.charAt(0>d?1:0)}
function ud(a,c,d){return a?c.replace("{x}",a[0].toFixed(d)).replace("{y}",a[1].toFixed(d)):""}function vd(a,c){for(var d=!0,e=a.length-1;0<=e;--e)if(a[e]!=c[e]){d=!1;break}return d}function wd(a,c){var d=Math.cos(c),e=Math.sin(c),f=a[1]*d+a[0]*e;a[0]=a[0]*d-a[1]*e;a[1]=f;return a}function xd(a,c){var d=a[0]-c[0],e=a[1]-c[1];return d*d+e*e}function yd(a,c){return xd(a,sd(a,c))}function zd(a,c){return ud(a,"{x}, {y}",c)};function Ad(a){this.length=a.length||a;for(var c=0;c<this.length;c++)this[c]=a[c]||0}Ad.prototype.b=4;Ad.prototype.set=function(a,c){c=c||0;for(var d=0;d<a.length&&c+d<this.length;d++)this[c+d]=a[d]};Ad.prototype.toString=Array.prototype.join;"undefined"==typeof Float32Array&&(Ad.BYTES_PER_ELEMENT=4,Ad.prototype.BYTES_PER_ELEMENT=Ad.prototype.b,Ad.prototype.set=Ad.prototype.set,Ad.prototype.toString=Ad.prototype.toString,u("Float32Array",Ad,void 0));function Bd(a){this.length=a.length||a;for(var c=0;c<this.length;c++)this[c]=a[c]||0}Bd.prototype.b=8;Bd.prototype.set=function(a,c){c=c||0;for(var d=0;d<a.length&&c+d<this.length;d++)this[c+d]=a[d]};Bd.prototype.toString=Array.prototype.join;if("undefined"==typeof Float64Array){try{Bd.BYTES_PER_ELEMENT=8}catch(a){}Bd.prototype.BYTES_PER_ELEMENT=Bd.prototype.b;Bd.prototype.set=Bd.prototype.set;Bd.prototype.toString=Bd.prototype.toString;u("Float64Array",Bd,void 0)};function Cd(a,c,d,e,f){a[0]=c;a[1]=d;a[2]=e;a[3]=f};function Dd(){var a=Array(16);Ed(a,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);return a}function Fd(){var a=Array(16);Ed(a,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1);return a}function Ed(a,c,d,e,f,g,h,k,m,n,p,q,r,t,y,A,F){a[0]=c;a[1]=d;a[2]=e;a[3]=f;a[4]=g;a[5]=h;a[6]=k;a[7]=m;a[8]=n;a[9]=p;a[10]=q;a[11]=r;a[12]=t;a[13]=y;a[14]=A;a[15]=F}
function Gd(a,c){a[0]=c[0];a[1]=c[1];a[2]=c[2];a[3]=c[3];a[4]=c[4];a[5]=c[5];a[6]=c[6];a[7]=c[7];a[8]=c[8];a[9]=c[9];a[10]=c[10];a[11]=c[11];a[12]=c[12];a[13]=c[13];a[14]=c[14];a[15]=c[15]}function Hd(a){a[0]=1;a[1]=0;a[2]=0;a[3]=0;a[4]=0;a[5]=1;a[6]=0;a[7]=0;a[8]=0;a[9]=0;a[10]=1;a[11]=0;a[12]=0;a[13]=0;a[14]=0;a[15]=1}
function Id(a,c,d){var e=a[0],f=a[1],g=a[2],h=a[3],k=a[4],m=a[5],n=a[6],p=a[7],q=a[8],r=a[9],t=a[10],y=a[11],A=a[12],F=a[13],z=a[14];a=a[15];var x=c[0],M=c[1],L=c[2],H=c[3],J=c[4],ra=c[5],Ga=c[6],K=c[7],oa=c[8],Oa=c[9],La=c[10],Ib=c[11],eb=c[12],Mc=c[13],oc=c[14];c=c[15];d[0]=e*x+k*M+q*L+A*H;d[1]=f*x+m*M+r*L+F*H;d[2]=g*x+n*M+t*L+z*H;d[3]=h*x+p*M+y*L+a*H;d[4]=e*J+k*ra+q*Ga+A*K;d[5]=f*J+m*ra+r*Ga+F*K;d[6]=g*J+n*ra+t*Ga+z*K;d[7]=h*J+p*ra+y*Ga+a*K;d[8]=e*oa+k*Oa+q*La+A*Ib;d[9]=f*oa+m*Oa+r*La+F*Ib;d[10]=
g*oa+n*Oa+t*La+z*Ib;d[11]=h*oa+p*Oa+y*La+a*Ib;d[12]=e*eb+k*Mc+q*oc+A*c;d[13]=f*eb+m*Mc+r*oc+F*c;d[14]=g*eb+n*Mc+t*oc+z*c;d[15]=h*eb+p*Mc+y*oc+a*c}
function Jd(a,c){var d=a[0],e=a[1],f=a[2],g=a[3],h=a[4],k=a[5],m=a[6],n=a[7],p=a[8],q=a[9],r=a[10],t=a[11],y=a[12],A=a[13],F=a[14],z=a[15],x=d*k-e*h,M=d*m-f*h,L=d*n-g*h,H=e*m-f*k,J=e*n-g*k,ra=f*n-g*m,Ga=p*A-q*y,K=p*F-r*y,oa=p*z-t*y,Oa=q*F-r*A,La=q*z-t*A,Ib=r*z-t*F,eb=x*Ib-M*La+L*Oa+H*oa-J*K+ra*Ga;0!=eb&&(eb=1/eb,c[0]=(k*Ib-m*La+n*Oa)*eb,c[1]=(-e*Ib+f*La-g*Oa)*eb,c[2]=(A*ra-F*J+z*H)*eb,c[3]=(-q*ra+r*J-t*H)*eb,c[4]=(-h*Ib+m*oa-n*K)*eb,c[5]=(d*Ib-f*oa+g*K)*eb,c[6]=(-y*ra+F*L-z*M)*eb,c[7]=(p*ra-r*L+t*
M)*eb,c[8]=(h*La-k*oa+n*Ga)*eb,c[9]=(-d*La+e*oa-g*Ga)*eb,c[10]=(y*J-A*L+z*x)*eb,c[11]=(-p*J+q*L-t*x)*eb,c[12]=(-h*Oa+k*K-m*Ga)*eb,c[13]=(d*Oa-e*K+f*Ga)*eb,c[14]=(-y*H+A*M-F*x)*eb,c[15]=(p*H-q*M+r*x)*eb)}function Kd(a,c,d){var e=a[1]*c+a[5]*d+0*a[9]+a[13],f=a[2]*c+a[6]*d+0*a[10]+a[14],g=a[3]*c+a[7]*d+0*a[11]+a[15];a[12]=a[0]*c+a[4]*d+0*a[8]+a[12];a[13]=e;a[14]=f;a[15]=g}
function Ld(a,c,d){Ed(a,a[0]*c,a[1]*c,a[2]*c,a[3]*c,a[4]*d,a[5]*d,a[6]*d,a[7]*d,1*a[8],1*a[9],1*a[10],1*a[11],a[12],a[13],a[14],a[15])}function Md(a,c){var d=a[0],e=a[1],f=a[2],g=a[3],h=a[4],k=a[5],m=a[6],n=a[7],p=Math.cos(c),q=Math.sin(c);a[0]=d*p+h*q;a[1]=e*p+k*q;a[2]=f*p+m*q;a[3]=g*p+n*q;a[4]=d*-q+h*p;a[5]=e*-q+k*p;a[6]=f*-q+m*p;a[7]=g*-q+n*p}new Float64Array(3);new Float64Array(3);new Float64Array(4);new Float64Array(4);new Float64Array(4);new Float64Array(16);function Nd(a){for(var c=Od(),d=0,e=a.length;d<e;++d)Pd(c,a[d]);return c}function Qd(a,c,d){var e=Math.min.apply(null,a),f=Math.min.apply(null,c);a=Math.max.apply(null,a);c=Math.max.apply(null,c);return Rd(e,f,a,c,d)}function Sd(a,c,d){return d?(d[0]=a[0]-c,d[1]=a[1]-c,d[2]=a[2]+c,d[3]=a[3]+c,d):[a[0]-c,a[1]-c,a[2]+c,a[3]+c]}function Td(a,c){return c?(c[0]=a[0],c[1]=a[1],c[2]=a[2],c[3]=a[3],c):a.slice()}
function Ud(a,c,d){c=c<a[0]?a[0]-c:a[2]<c?c-a[2]:0;a=d<a[1]?a[1]-d:a[3]<d?d-a[3]:0;return c*c+a*a}function Vd(a,c){return Wd(a,c[0],c[1])}function Xd(a,c){return a[0]<=c[0]&&c[2]<=a[2]&&a[1]<=c[1]&&c[3]<=a[3]}function Wd(a,c,d){return a[0]<=c&&c<=a[2]&&a[1]<=d&&d<=a[3]}function Yd(a,c){var d=a[1],e=a[2],f=a[3],g=c[0],h=c[1],k=0;g<a[0]?k=k|16:g>e&&(k=k|4);h<d?k|=8:h>f&&(k|=2);0===k&&(k=1);return k}function Od(){return[Infinity,Infinity,-Infinity,-Infinity]}
function Rd(a,c,d,e,f){return f?(f[0]=a,f[1]=c,f[2]=d,f[3]=e,f):[a,c,d,e]}function Zd(a,c){var d=a[0],e=a[1];return Rd(d,e,d,e,c)}function $d(a,c){return a[0]==c[0]&&a[2]==c[2]&&a[1]==c[1]&&a[3]==c[3]}function ae(a,c){c[0]<a[0]&&(a[0]=c[0]);c[2]>a[2]&&(a[2]=c[2]);c[1]<a[1]&&(a[1]=c[1]);c[3]>a[3]&&(a[3]=c[3]);return a}function Pd(a,c){c[0]<a[0]&&(a[0]=c[0]);c[0]>a[2]&&(a[2]=c[0]);c[1]<a[1]&&(a[1]=c[1]);c[1]>a[3]&&(a[3]=c[1])}
function be(a,c,d,e,f){for(;d<e;d+=f){var g=a,h=c[d],k=c[d+1];g[0]=Math.min(g[0],h);g[1]=Math.min(g[1],k);g[2]=Math.max(g[2],h);g[3]=Math.max(g[3],k)}return a}function ce(a,c,d){var e;return(e=c.call(d,de(a)))||(e=c.call(d,ee(a)))||(e=c.call(d,fe(a)))?e:(e=c.call(d,ge(a)))?e:!1}function he(a){var c=0;ie(a)||(c=je(a)*ke(a));return c}function de(a){return[a[0],a[1]]}function ee(a){return[a[2],a[1]]}function le(a){return[(a[0]+a[2])/2,(a[1]+a[3])/2]}
function me(a,c,d,e){var f=c*e[0]/2;e=c*e[1]/2;c=Math.cos(d);d=Math.sin(d);f=[-f,-f,f,f];e=[-e,e,-e,e];var g,h,k;for(g=0;4>g;++g)h=f[g],k=e[g],f[g]=a[0]+h*c-k*d,e[g]=a[1]+h*d+k*c;return Qd(f,e,void 0)}function ke(a){return a[3]-a[1]}function ne(a,c,d){d=d?d:Od();oe(a,c)&&(d[0]=a[0]>c[0]?a[0]:c[0],d[1]=a[1]>c[1]?a[1]:c[1],d[2]=a[2]<c[2]?a[2]:c[2],d[3]=a[3]<c[3]?a[3]:c[3]);return d}function ge(a){return[a[0],a[3]]}function fe(a){return[a[2],a[3]]}function je(a){return a[2]-a[0]}
function oe(a,c){return a[0]<=c[2]&&a[2]>=c[0]&&a[1]<=c[3]&&a[3]>=c[1]}function ie(a){return a[2]<a[0]||a[3]<a[1]}function pe(a,c){var d=(a[2]-a[0])/2*(c-1),e=(a[3]-a[1])/2*(c-1);a[0]-=d;a[2]+=d;a[1]-=e;a[3]+=e}function qe(a,c,d){a=[a[0],a[1],a[0],a[3],a[2],a[1],a[2],a[3]];c(a,a,2);return Qd([a[0],a[2],a[4],a[6]],[a[1],a[3],a[5],a[7]],d)};function re(a){return function(){return a}}var se=re(!1),te=re(!0),ue=re(null);function ve(a){return a}function we(a){var c;c=c||0;return function(){return a.apply(this,Array.prototype.slice.call(arguments,0,c))}}function xe(a){var c=arguments,d=c.length;return function(){for(var a,f=0;f<d;f++)a=c[f].apply(this,arguments);return a}}function ye(a){var c=arguments,d=c.length;return function(){for(var a=0;a<d;a++)if(!c[a].apply(this,arguments))return!1;return!0}};/*

 Latitude/longitude spherical geodesy formulae taken from
 http://www.movable-type.co.uk/scripts/latlong.html
 Licensed under CC-BY-3.0.
*/
function ze(a){this.radius=a}ze.prototype.a=function(a){for(var c=0,d=a.length,e=a[d-1][0],f=a[d-1][1],g=0;g<d;g++)var h=a[g][0],k=a[g][1],c=c+Wa(h-e)*(2+Math.sin(Wa(f))+Math.sin(Wa(k))),e=h,f=k;return c*this.radius*this.radius/2};ze.prototype.b=function(a,c){var d=Wa(a[1]),e=Wa(c[1]),f=(e-d)/2,g=Wa(c[0]-a[0])/2,d=Math.sin(f)*Math.sin(f)+Math.sin(g)*Math.sin(g)*Math.cos(d)*Math.cos(e);return 2*this.radius*Math.atan2(Math.sqrt(d),Math.sqrt(1-d))};
ze.prototype.offset=function(a,c,d){var e=Wa(a[1]);c/=this.radius;var f=Math.asin(Math.sin(e)*Math.cos(c)+Math.cos(e)*Math.sin(c)*Math.cos(d));return[180*(Wa(a[0])+Math.atan2(Math.sin(d)*Math.sin(c)*Math.cos(e),Math.cos(c)-Math.sin(e)*Math.sin(f)))/Math.PI,180*f/Math.PI]};var Ae=new ze(6370997);var Be={};Be.degrees=2*Math.PI*Ae.radius/360;Be.ft=.3048;Be.m=1;Be["us-ft"]=1200/3937;
function Ce(a){this.b=a.code;this.f=a.units;this.i=void 0!==a.extent?a.extent:null;this.j=void 0!==a.worldExtent?a.worldExtent:null;this.g=void 0!==a.axisOrientation?a.axisOrientation:"enu";this.c=void 0!==a.global?a.global:!1;this.a=!(!this.c||!this.i);this.D=void 0!==a.getPointResolution?a.getPointResolution:this.qj;this.l=null;var c=De,d=a.code;if("function"==typeof proj4&&void 0===c[d]){var e=proj4.defs(d);if(void 0!==e){void 0!==e.axis&&void 0===a.axisOrientation&&(this.g=e.axis);void 0===a.units&&
(a=e.units,void 0===e.to_meter||void 0!==a&&void 0!==Be[a]||(a=e.to_meter.toString(),Be[a]=e.to_meter),this.f=a);for(var f in c)a=proj4.defs(f),void 0!==a&&(c=Ee(f),a===e?Fe([c,this]):(a=proj4(f,d),Ge(c,this,a.forward,a.inverse)))}}}l=Ce.prototype;l.Qi=function(){return this.b};l.J=function(){return this.i};l.Jl=function(){return this.f};l.yc=function(){return Be[this.f]};l.Bj=function(){return this.j};function He(a){return a.g}l.nk=function(){return this.c};
l.ao=function(a){this.c=a;this.a=!(!a||!this.i)};l.Kl=function(a){this.i=a;this.a=!(!this.c||!a)};l.mo=function(a){this.j=a};l.$n=function(a){this.D=a};l.qj=function(a,c){if("degrees"==this.f)return a;var d=Ie(this,Ee("EPSG:4326")),e=[c[0]-a/2,c[1],c[0]+a/2,c[1],c[0],c[1]-a/2,c[0],c[1]+a/2],e=d(e,e,2),d=(Ae.b(e.slice(0,2),e.slice(2,4))+Ae.b(e.slice(4,6),e.slice(6,8)))/2,e=this.yc();void 0!==e&&(d/=e);return d};l.getPointResolution=function(a,c){return this.D(a,c)};var De={},Je={};
function Fe(a){Le(a);a.forEach(function(c){a.forEach(function(a){c!==a&&Me(c,a,Ne)})})}function Oe(){var a=Pe,c=Qe,d=Re;Se.forEach(function(e){a.forEach(function(a){Me(e,a,c);Me(a,e,d)})})}function Te(a){De[a.b]=a;Me(a,a,Ne)}function Le(a){var c=[];a.forEach(function(a){c.push(Te(a))})}function Ue(a){return a?ia(a)?Ee(a):a:Ee("EPSG:3857")}function Me(a,c,d){a=a.b;c=c.b;a in Je||(Je[a]={});Je[a][c]=d}function Ge(a,c,d,e){a=Ee(a);c=Ee(c);Me(a,c,Ve(d));Me(c,a,Ve(e))}
function Ve(a){return function(c,d,e){var f=c.length;e=void 0!==e?e:2;d=void 0!==d?d:Array(f);var g,h;for(h=0;h<f;h+=e)for(g=a([c[h],c[h+1]]),d[h]=g[0],d[h+1]=g[1],g=e-1;2<=g;--g)d[h+g]=c[h+g];return d}}function Ee(a){var c;a instanceof Ce?c=a:ia(a)?(c=De[a],void 0===c&&"function"==typeof proj4&&void 0!==proj4.defs(a)&&(c=new Ce({code:a}),Te(c))):c=null;return c}function We(a,c){return a===c?!0:a.b===c.b?!0:a.f!=c.f?!1:Ie(a,c)===Ne}function Xe(a,c){var d=Ee(a),e=Ee(c);return Ie(d,e)}
function Ie(a,c){var d=a.b,e=c.b,f;d in Je&&e in Je[d]&&(f=Je[d][e]);void 0===f&&(f=Ye);return f}function Ye(a,c){if(void 0!==c&&a!==c){for(var d=0,e=a.length;d<e;++d)c[d]=a[d];a=c}return a}function Ne(a,c){var d;if(void 0!==c){d=0;for(var e=a.length;d<e;++d)c[d]=a[d];d=c}else d=a.slice();return d}function Ze(a,c,d){return Xe(c,d)(a,void 0,a.length)}function $e(a,c,d){c=Xe(c,d);return qe(a,c)};function af(){id.call(this);this.v=Od();this.A=-1;this.g={};this.l=this.i=0}w(af,id);l=af.prototype;l.bb=function(a,c){var d=c?c:[NaN,NaN];this.$a(a[0],a[1],d,Infinity);return d};l.Pe=function(a){return this.bc(a[0],a[1])};l.bc=se;l.J=function(a){this.A!=this.b&&(this.v=this.Cd(this.v),this.A=this.b);var c=this.v;a?(a[0]=c[0],a[1]=c[1],a[2]=c[2],a[3]=c[3]):a=c;return a};l.mb=function(a){return this.Od(a*a)};l.Xa=function(a,c){this.Ub(Xe(a,c));return this};function bf(a,c,d,e,f,g){var h=f[0],k=f[1],m=f[4],n=f[5],p=f[12];f=f[13];for(var q=g?g:[],r=0;c<d;c+=e){var t=a[c],y=a[c+1];q[r++]=h*t+m*y+p;q[r++]=k*t+n*y+f}g&&q.length!=r&&(q.length=r);return q};function cf(){af.call(this);this.a="XY";this.I=2;this.o=null}w(cf,af);function df(a){if("XY"==a)return 2;if("XYZ"==a||"XYM"==a)return 3;if("XYZM"==a)return 4}l=cf.prototype;l.bc=se;l.Cd=function(a){var c=this.o,d=this.o.length,e=this.I;a=Rd(Infinity,Infinity,-Infinity,-Infinity,a);return be(a,c,0,d,e)};l.yb=function(){return this.o.slice(0,this.I)};l.zb=function(){return this.o.slice(this.o.length-this.I)};l.Ab=function(){return this.a};
l.Od=function(a){this.l!=this.b&&(Rb(this.g),this.i=0,this.l=this.b);if(0>a||0!==this.i&&a<=this.i)return this;var c=a.toString();if(this.g.hasOwnProperty(c))return this.g[c];var d=this.zc(a);if(d.o.length<this.o.length)return this.g[c]=d;this.i=a;return this};l.zc=function(){return this};function ef(a,c,d){a.I=df(c);a.a=c;a.o=d}function ff(a,c,d,e){if(c)d=df(c);else{for(c=0;c<e;++c){if(0===d.length){a.a="XY";a.I=2;return}d=d[0]}d=d.length;c=2==d?"XY":3==d?"XYZ":4==d?"XYZM":void 0}a.a=c;a.I=d}
l.Ub=function(a){this.o&&(a(this.o,this.o,this.I),this.s())};l.Dc=function(a,c){var d=this.o;if(d){var e=d.length,f=this.I,g=d?d:[],h=0,k,m;for(k=0;k<e;k+=f)for(g[h++]=d[k]+a,g[h++]=d[k+1]+c,m=k+2;m<k+f;++m)g[h++]=d[m];d&&g.length!=h&&(g.length=h);this.s()}};function gf(a,c,d,e){for(var f=0,g=a[d-e],h=a[d-e+1];c<d;c+=e)var k=a[c],m=a[c+1],f=f+(h*k-g*m),g=k,h=m;return f/2}function hf(a,c,d,e){var f=0,g,h;g=0;for(h=d.length;g<h;++g){var k=d[g],f=f+gf(a,c,k,e);c=k}return f};function jf(a,c,d,e,f,g,h){var k=a[c],m=a[c+1],n=a[d]-k,p=a[d+1]-m;if(0!==n||0!==p)if(g=((f-k)*n+(g-m)*p)/(n*n+p*p),1<g)c=d;else if(0<g){for(f=0;f<e;++f)h[f]=qd(a[c+f],a[d+f],g);h.length=e;return}for(f=0;f<e;++f)h[f]=a[c+f];h.length=e}function kf(a,c,d,e,f){var g=a[c],h=a[c+1];for(c+=e;c<d;c+=e){var k=a[c],m=a[c+1],g=Va(g,h,k,m);g>f&&(f=g);g=k;h=m}return f}function lf(a,c,d,e,f){var g,h;g=0;for(h=d.length;g<h;++g){var k=d[g];f=kf(a,c,k,e,f);c=k}return f}
function mf(a,c,d,e,f,g,h,k,m,n,p){if(c==d)return n;var q;if(0===f){q=Va(h,k,a[c],a[c+1]);if(q<n){for(p=0;p<e;++p)m[p]=a[c+p];m.length=e;return q}return n}for(var r=p?p:[NaN,NaN],t=c+e;t<d;)if(jf(a,t-e,t,e,h,k,r),q=Va(h,k,r[0],r[1]),q<n){n=q;for(p=0;p<e;++p)m[p]=r[p];m.length=e;t+=e}else t+=e*Math.max((Math.sqrt(q)-Math.sqrt(n))/f|0,1);if(g&&(jf(a,d-e,c,e,h,k,r),q=Va(h,k,r[0],r[1]),q<n)){n=q;for(p=0;p<e;++p)m[p]=r[p];m.length=e}return n}
function nf(a,c,d,e,f,g,h,k,m,n,p){p=p?p:[NaN,NaN];var q,r;q=0;for(r=d.length;q<r;++q){var t=d[q];n=mf(a,c,t,e,f,g,h,k,m,n,p);c=t}return n};function of(a,c){var d=0,e,f;e=0;for(f=c.length;e<f;++e)a[d++]=c[e];return d}function pf(a,c,d,e){var f,g;f=0;for(g=d.length;f<g;++f){var h=d[f],k;for(k=0;k<e;++k)a[c++]=h[k]}return c}function qf(a,c,d,e,f){f=f?f:[];var g=0,h,k;h=0;for(k=d.length;h<k;++h)c=pf(a,c,d[h],e),f[g++]=c;f.length=g;return f};function rf(a,c,d,e,f){f=void 0!==f?f:[];for(var g=0;c<d;c+=e)f[g++]=a.slice(c,c+e);f.length=g;return f}function sf(a,c,d,e,f){f=void 0!==f?f:[];var g=0,h,k;h=0;for(k=d.length;h<k;++h){var m=d[h];f[g++]=rf(a,c,m,e,f[g]);c=m}f.length=g;return f};function tf(a,c,d,e,f,g,h){var k=(d-c)/e;if(3>k){for(;c<d;c+=e)g[h++]=a[c],g[h++]=a[c+1];return h}var m=Array(k);m[0]=1;m[k-1]=1;d=[c,d-e];for(var n=0,p;0<d.length;){var q=d.pop(),r=d.pop(),t=0,y=a[r],A=a[r+1],F=a[q],z=a[q+1];for(p=r+e;p<q;p+=e){var x=Ua(a[p],a[p+1],y,A,F,z);x>t&&(n=p,t=x)}t>f&&(m[(n-c)/e]=1,r+e<n&&d.push(r,n),n+e<q&&d.push(n,q))}for(p=0;p<k;++p)m[p]&&(g[h++]=a[c+p*e],g[h++]=a[c+p*e+1]);return h}
function uf(a,c,d,e,f,g,h,k){var m,n;m=0;for(n=d.length;m<n;++m){var p=d[m];a:{var q=a,r=p,t=e,y=f,A=g;if(c!=r){var F=y*Math.round(q[c]/y),z=y*Math.round(q[c+1]/y);c+=t;A[h++]=F;A[h++]=z;var x=void 0,M=void 0;do if(x=y*Math.round(q[c]/y),M=y*Math.round(q[c+1]/y),c+=t,c==r){A[h++]=x;A[h++]=M;break a}while(x==F&&M==z);for(;c<r;){var L,H;L=y*Math.round(q[c]/y);H=y*Math.round(q[c+1]/y);c+=t;if(L!=x||H!=M){var J=x-F,ra=M-z,Ga=L-F,K=H-z;J*K==ra*Ga&&(0>J&&Ga<J||J==Ga||0<J&&Ga>J)&&(0>ra&&K<ra||ra==K||0<ra&&
K>ra)||(A[h++]=x,A[h++]=M,F=x,z=M);x=L;M=H}}A[h++]=x;A[h++]=M}}k.push(h);c=p}return h};function vf(a,c){cf.call(this);this.c=this.j=-1;this.ja(a,c)}w(vf,cf);l=vf.prototype;l.clone=function(){var a=new vf(null);wf(a,this.a,this.o.slice());return a};l.$a=function(a,c,d,e){if(e<Ud(this.J(),a,c))return e;this.c!=this.b&&(this.j=Math.sqrt(kf(this.o,0,this.o.length,this.I,0)),this.c=this.b);return mf(this.o,0,this.o.length,this.I,this.j,!0,a,c,d,e)};l.kl=function(){return gf(this.o,0,this.o.length,this.I)};l.X=function(){return rf(this.o,0,this.o.length,this.I)};
l.zc=function(a){var c=[];c.length=tf(this.o,0,this.o.length,this.I,a,c,0);a=new vf(null);wf(a,"XY",c);return a};l.Z=function(){return"LinearRing"};l.ja=function(a,c){a?(ff(this,c,a,1),this.o||(this.o=[]),this.o.length=pf(this.o,0,a,this.I),this.s()):wf(this,"XY",null)};function wf(a,c,d){ef(a,c,d);a.s()};function C(a,c){cf.call(this);this.ja(a,c)}w(C,cf);l=C.prototype;l.clone=function(){var a=new C(null);xf(a,this.a,this.o.slice());return a};l.$a=function(a,c,d,e){var f=this.o;a=Va(a,c,f[0],f[1]);if(a<e){e=this.I;for(c=0;c<e;++c)d[c]=f[c];d.length=e;return a}return e};l.X=function(){return this.o?this.o.slice():[]};l.Cd=function(a){return Zd(this.o,a)};l.Z=function(){return"Point"};l.ya=function(a){return Wd(a,this.o[0],this.o[1])};
l.ja=function(a,c){a?(ff(this,c,a,0),this.o||(this.o=[]),this.o.length=of(this.o,a),this.s()):xf(this,"XY",null)};function xf(a,c,d){ef(a,c,d);a.s()};function yf(a,c,d,e,f){return!ce(f,function(f){return!zf(a,c,d,e,f[0],f[1])})}function zf(a,c,d,e,f,g){for(var h=!1,k=a[d-e],m=a[d-e+1];c<d;c+=e){var n=a[c],p=a[c+1];m>g!=p>g&&f<(n-k)*(g-m)/(p-m)+k&&(h=!h);k=n;m=p}return h}function Af(a,c,d,e,f,g){if(0===d.length||!zf(a,c,d[0],e,f,g))return!1;var h;c=1;for(h=d.length;c<h;++c)if(zf(a,d[c-1],d[c],e,f,g))return!1;return!0};function Bf(a,c,d,e,f,g,h){var k,m,n,p,q,r=f[g+1],t=[],y=d[0];n=a[y-e];q=a[y-e+1];for(k=c;k<y;k+=e){p=a[k];m=a[k+1];if(r<=q&&m<=r||q<=r&&r<=m)n=(r-q)/(m-q)*(p-n)+n,t.push(n);n=p;q=m}y=NaN;q=-Infinity;t.sort();n=t[0];k=1;for(m=t.length;k<m;++k){p=t[k];var A=Math.abs(p-n);A>q&&(n=(n+p)/2,Af(a,c,d,e,n,r)&&(y=n,q=A));n=p}isNaN(y)&&(y=f[g]);return h?(h.push(y,r),h):[y,r]};function Cf(a,c,d,e,f,g){for(var h=[a[c],a[c+1]],k=[],m;c+e<d;c+=e){k[0]=a[c+e];k[1]=a[c+e+1];if(m=f.call(g,h,k))return m;h[0]=k[0];h[1]=k[1]}return!1};function Df(a,c,d,e,f){var g=be(Od(),a,c,d,e);return oe(f,g)?Xd(f,g)||g[0]>=f[0]&&g[2]<=f[2]||g[1]>=f[1]&&g[3]<=f[3]?!0:Cf(a,c,d,e,function(a,c){var d=!1,e=Yd(f,a),g=Yd(f,c);if(1===e||1===g)d=!0;else{var q=f[0],r=f[1],t=f[2],y=f[3],A=c[0],F=c[1],z=(F-a[1])/(A-a[0]);g&2&&!(e&2)&&(d=A-(F-y)/z,d=d>=q&&d<=t);d||!(g&4)||e&4||(d=F-(A-t)*z,d=d>=r&&d<=y);d||!(g&8)||e&8||(d=A-(F-r)/z,d=d>=q&&d<=t);d||!(g&16)||e&16||(d=F-(A-q)*z,d=d>=r&&d<=y)}return d}):!1}
function Ef(a,c,d,e,f){var g=d[0];if(!(Df(a,c,g,e,f)||zf(a,c,g,e,f[0],f[1])||zf(a,c,g,e,f[0],f[3])||zf(a,c,g,e,f[2],f[1])||zf(a,c,g,e,f[2],f[3])))return!1;if(1===d.length)return!0;c=1;for(g=d.length;c<g;++c)if(yf(a,d[c-1],d[c],e,f))return!1;return!0};function Ff(a,c,d,e){for(var f=0,g=a[d-e],h=a[d-e+1];c<d;c+=e)var k=a[c],m=a[c+1],f=f+(k-g)*(m+h),g=k,h=m;return 0<f}function Gf(a,c,d,e){var f=0;e=void 0!==e?e:!1;var g,h;g=0;for(h=c.length;g<h;++g){var k=c[g],f=Ff(a,f,k,d);if(0===g){if(e&&f||!e&&!f)return!1}else if(e&&!f||!e&&f)return!1;f=k}return!0}
function Hf(a,c,d,e,f){f=void 0!==f?f:!1;var g,h;g=0;for(h=d.length;g<h;++g){var k=d[g],m=Ff(a,c,k,e);if(0===g?f&&m||!f&&!m:f&&!m||!f&&m)for(var m=a,n=k,p=e;c<n-p;){var q;for(q=0;q<p;++q){var r=m[c+q];m[c+q]=m[n-p+q];m[n-p+q]=r}c+=p;n-=p}c=k}return c}function If(a,c,d,e){var f=0,g,h;g=0;for(h=c.length;g<h;++g)f=Hf(a,f,c[g],d,e);return f};function D(a,c){cf.call(this);this.c=[];this.B=-1;this.C=null;this.T=this.P=this.H=-1;this.j=null;this.ja(a,c)}w(D,cf);l=D.prototype;l.wi=function(a){this.o?kb(this.o,a.o):this.o=a.o.slice();this.c.push(this.o.length);this.s()};l.clone=function(){var a=new D(null);Jf(a,this.a,this.o.slice(),this.c.slice());return a};l.$a=function(a,c,d,e){if(e<Ud(this.J(),a,c))return e;this.P!=this.b&&(this.H=Math.sqrt(lf(this.o,0,this.c,this.I,0)),this.P=this.b);return nf(this.o,0,this.c,this.I,this.H,!0,a,c,d,e)};
l.bc=function(a,c){return Af(Kf(this),0,this.c,this.I,a,c)};l.nl=function(){return hf(Kf(this),0,this.c,this.I)};l.X=function(a){var c;void 0!==a?(c=Kf(this).slice(),Hf(c,0,this.c,this.I,a)):c=this.o;return sf(c,0,this.c,this.I)};function Lf(a){if(a.B!=a.b){var c=le(a.J());a.C=Bf(Kf(a),0,a.c,a.I,c,0);a.B=a.b}return a.C}l.aj=function(){return new C(Lf(this))};l.fj=function(){return this.c.length};
l.bg=function(a){if(0>a||this.c.length<=a)return null;var c=new vf(null);wf(c,this.a,this.o.slice(0===a?0:this.c[a-1],this.c[a]));return c};l.Ld=function(){var a=this.a,c=this.o,d=this.c,e=[],f=0,g,h;g=0;for(h=d.length;g<h;++g){var k=d[g],m=new vf(null);wf(m,a,c.slice(f,k));e.push(m);f=k}return e};function Kf(a){if(a.T!=a.b){var c=a.o;Gf(c,a.c,a.I)?a.j=c:(a.j=c.slice(),a.j.length=Hf(a.j,0,a.c,a.I));a.T=a.b}return a.j}
l.zc=function(a){var c=[],d=[];c.length=uf(this.o,0,this.c,this.I,Math.sqrt(a),c,0,d);a=new D(null);Jf(a,"XY",c,d);return a};l.Z=function(){return"Polygon"};l.ya=function(a){return Ef(Kf(this),0,this.c,this.I,a)};l.ja=function(a,c){if(a){ff(this,c,a,2);this.o||(this.o=[]);var d=qf(this.o,0,a,this.I,this.c);this.o.length=0===d.length?0:d[d.length-1];this.s()}else Jf(this,"XY",null,this.c)};function Jf(a,c,d,e){ef(a,c,d);a.c=e;a.s()}
function Mf(a,c,d,e){var f=e?e:32;e=[];var g;for(g=0;g<f;++g)kb(e,a.offset(c,d,2*Math.PI*g/f));e.push(e[0],e[1]);a=new D(null);Jf(a,"XY",e,[e.length]);return a}function Nf(a){var c=a[0],d=a[1],e=a[2];a=a[3];c=[c,d,c,a,e,a,e,d,c,d];d=new D(null);Jf(d,"XY",c,[c.length]);return d}function Of(a,c,d){var e=c?c:32,f=a.I;c=a.a;for(var g=new D(null,c),e=f*(e+1),f=[],h=0;h<e;h++)f[h]=0;Jf(g,c,f,[f.length]);Pf(g,a.hd(),a.mf(),d);return g}
function Pf(a,c,d,e){var f=a.o,g=a.a,h=a.I,k=a.c,m=f.length/h-1;e=e?e:0;for(var n,p,q=0;q<=m;++q)p=q*h,n=e+2*pd(q,m)*Math.PI/m,f[p]=c[0]+d*Math.cos(n),f[p+1]=c[1]+d*Math.sin(n);Jf(a,g,f,k)};function Qf(a){id.call(this);a=a||{};this.c=[0,0];var c={};c.center=void 0!==a.center?a.center:null;this.g=Ue(a.projection);var d,e,f,g=void 0!==a.minZoom?a.minZoom:0;d=void 0!==a.maxZoom?a.maxZoom:28;var h=void 0!==a.zoomFactor?a.zoomFactor:2;if(void 0!==a.resolutions)d=a.resolutions,e=d[0],f=d[d.length-1],d=wb(d);else{e=Ue(a.projection);f=e.J();var k=(f?Math.max(je(f),ke(f)):360*Be.degrees/Be[e.f])/256/Math.pow(2,0),m=k/Math.pow(2,28);e=a.maxResolution;void 0!==e?g=0:e=k/Math.pow(h,g);f=a.minResolution;
void 0===f&&(f=void 0!==a.maxZoom?void 0!==a.maxResolution?e/Math.pow(h,d):k/Math.pow(h,d):m);d=g+Math.floor(Math.log(e/f)/Math.log(h));f=e/Math.pow(h,d-g);d=xb(h,e,d-g)}this.a=e;this.j=f;this.f=g;g=void 0!==a.extent?Xa(a.extent):Ya;(void 0!==a.enableRotation?a.enableRotation:1)?(e=a.constrainRotation,e=void 0===e||!0===e?Bb():!1===e?zb:ja(e)?Ab(e):zb):e=yb;this.i=new Cb(g,d,e);void 0!==a.resolution?c.resolution=a.resolution:void 0!==a.zoom&&(c.resolution=this.constrainResolution(this.a,a.zoom-this.f));
c.rotation=void 0!==a.rotation?a.rotation:0;this.K(c)}w(Qf,id);l=Qf.prototype;l.Dd=function(a){return this.i.center(a)};l.constrainResolution=function(a,c,d){return this.i.resolution(a,c||0,d||0)};l.constrainRotation=function(a,c){return this.i.rotation(a,c||0)};l.Na=function(){return this.get("center")};l.Rc=function(a){var c=this.Na(),d=this.aa(),e=this.za();return me(c,d,e,a)};l.Vk=function(){return this.g};l.aa=function(){return this.get("resolution")};
function Rf(a){var c=a.a,d=Math.log(c/a.j)/Math.log(2);return function(a){return c/Math.pow(2,a*d)}}l.za=function(){return this.get("rotation")};function Sf(a){var c=a.a,d=Math.log(c/a.j)/Math.log(2);return function(a){return Math.log(c/a)/Math.log(2)/d}}function Uf(a){var c=a.Na(),d=a.g,e=a.aa();a=a.za();return{center:[Math.round(c[0]/e)*e,Math.round(c[1]/e)*e],projection:void 0!==d?d:null,resolution:e,rotation:a}}
l.Cj=function(){var a,c=this.aa();if(void 0!==c){var d,e=0;do{d=this.constrainResolution(this.a,e);if(d==c){a=e;break}++e}while(d>this.j)}return void 0!==a?this.f+a:a};
l.Se=function(a,c,d){a instanceof cf||(a=Nf(a));var e=d||{};d=void 0!==e.padding?e.padding:[0,0,0,0];var f=void 0!==e.constrainResolution?e.constrainResolution:!0,g=void 0!==e.nearest?e.nearest:!1,h;void 0!==e.minResolution?h=e.minResolution:void 0!==e.maxZoom?h=this.constrainResolution(this.a,e.maxZoom-this.f,0):h=0;var k=a.o,m=this.za(),e=Math.cos(-m),m=Math.sin(-m),n=Infinity,p=Infinity,q=-Infinity,r=-Infinity;a=a.I;for(var t=0,y=k.length;t<y;t+=a)var A=k[t]*e-k[t+1]*m,F=k[t]*m+k[t+1]*e,n=Math.min(n,
A),p=Math.min(p,F),q=Math.max(q,A),r=Math.max(r,F);k=[n,p,q,r];c=[c[0]-d[1]-d[3],c[1]-d[0]-d[2]];c=Math.max(je(k)/c[0],ke(k)/c[1]);c=isNaN(c)?h:Math.max(c,h);f&&(h=this.constrainResolution(c,0,0),!g&&h<c&&(h=this.constrainResolution(h,-1,0)),c=h);this.Cb(c);m=-m;g=(n+q)/2+(d[1]-d[3])/2*c;d=(p+r)/2+(d[0]-d[2])/2*c;this.Wa([g*e-d*m,d*e+g*m])};
l.Bi=function(a,c,d){var e=this.za(),f=Math.cos(-e),e=Math.sin(-e),g=a[0]*f-a[1]*e;a=a[1]*f+a[0]*e;var h=this.aa(),g=g+(c[0]/2-d[0])*h;a+=(d[1]-c[1]/2)*h;e=-e;this.Wa([g*f-a*e,a*f+g*e])};function Vf(a){return!!a.Na()&&void 0!==a.aa()}l.rotate=function(a,c){if(void 0!==c){var d,e=this.Na();void 0!==e&&(d=[e[0]-c[0],e[1]-c[1]],wd(d,a-this.za()),rd(d,c));this.Wa(d)}this.de(a)};l.Wa=function(a){this.set("center",a)};function Wf(a,c){a.c[1]+=c}l.Cb=function(a){this.set("resolution",a)};
l.de=function(a){this.set("rotation",a)};l.no=function(a){a=this.constrainResolution(this.a,a-this.f,0);this.Cb(a)};function Xf(a){return Math.pow(a,3)}function Yf(a){return 1-Xf(1-a)}function Zf(a){return 3*a*a-2*a*a*a}function $f(a){return a}function ag(a){return.5>a?Zf(2*a):1-Zf(2*(a-.5))};function bg(a){var c=a.source,d=a.start?a.start:Date.now(),e=c[0],f=c[1],g=void 0!==a.duration?a.duration:1E3,h=a.easing?a.easing:Zf;return function(a,c){if(c.time<d)return c.animate=!0,c.viewHints[0]+=1,!0;if(c.time<d+g){var n=1-h((c.time-d)/g),p=e-c.viewState.center[0],q=f-c.viewState.center[1];c.animate=!0;c.viewState.center[0]+=n*p;c.viewState.center[1]+=n*q;c.viewHints[0]+=1;return!0}return!1}}
function cg(a){var c=a.rotation?a.rotation:0,d=a.start?a.start:Date.now(),e=void 0!==a.duration?a.duration:1E3,f=a.easing?a.easing:Zf,g=a.anchor?a.anchor:null;return function(a,k){if(k.time<d)return k.animate=!0,k.viewHints[0]+=1,!0;if(k.time<d+e){var m=1-f((k.time-d)/e),m=(c-k.viewState.rotation)*m;k.animate=!0;k.viewState.rotation+=m;if(g){var n=k.viewState.center;n[0]-=g[0];n[1]-=g[1];wd(n,m);rd(n,g)}k.viewHints[0]+=1;return!0}return!1}}
function dg(a){var c=a.resolution,d=a.start?a.start:Date.now(),e=void 0!==a.duration?a.duration:1E3,f=a.easing?a.easing:Zf;return function(a,h){if(h.time<d)return h.animate=!0,h.viewHints[0]+=1,!0;if(h.time<d+e){var k=1-f((h.time-d)/e),m=c-h.viewState.resolution;h.animate=!0;h.viewState.resolution+=k*m;h.viewHints[0]+=1;return!0}return!1}};function eg(a,c,d,e){return void 0!==e?(e[0]=a,e[1]=c,e[2]=d,e):[a,c,d]}function fg(a,c,d){return a+"/"+c+"/"+d}function gg(a){var c=a[0],d=Array(c),e=1<<c-1,f,g;for(f=0;f<c;++f)g=48,a[1]&e&&(g+=1),a[2]&e&&(g+=2),d[f]=String.fromCharCode(g),e>>=1;return d.join("")}function hg(a){return fg(a[0],a[1],a[2])}function ig(a,c,d){var e=a[0],f=jg(c,a);d=kg(d);if(Vd(d,f))return a;a=je(d);f[0]+=a*Math.ceil((d[0]-f[0])/a);return c.Qd(f,e)}
function lg(a,c){var d=a[0],e=a[1],f=a[2];if(c.minZoom>d||d>c.maxZoom)return!1;var g=c.J();return(d=g?mg(c,g,d):c.a?c.a[d]:null)?ng(d,e,f):!0};function og(a,c,d,e){this.b=a;this.f=c;this.a=d;this.c=e}og.prototype.contains=function(a){return ng(this,a[1],a[2])};function ng(a,c,d){return a.b<=c&&c<=a.f&&a.a<=d&&d<=a.c}function pg(a,c){return a.b==c.b&&a.a==c.a&&a.f==c.f&&a.c==c.c}function qg(a){return a.c-a.a+1}function rg(a){return a.f-a.b+1}function sg(a,c){return a.b<=c.f&&a.f>=c.b&&a.a<=c.c&&a.c>=c.a};function tg(a){this.a=a.html;this.b=a.tileRanges?a.tileRanges:null}tg.prototype.c=function(){return this.a};function ug(a,c,d){vc.call(this,a,d);this.element=c}w(ug,vc);function vg(a){id.call(this);this.a=a?a:[];wg(this)}w(vg,id);l=vg.prototype;l.clear=function(){for(;0<this.Mb();)this.pop()};l.gf=function(a){var c,d;c=0;for(d=a.length;c<d;++c)this.push(a[c]);return this};l.forEach=function(a,c){this.a.forEach(a,c)};l.Ek=function(){return this.a};l.item=function(a){return this.a[a]};l.Mb=function(){return this.get("length")};l.Vd=function(a,c){lb(this.a,a,0,c);wg(this);this.u(new ug("add",c,this))};
l.pop=function(){return this.Bf(this.Mb()-1)};l.push=function(a){var c=this.a.length;this.Vd(c,a);return c};l.remove=function(a){var c=this.a,d,e;d=0;for(e=c.length;d<e;++d)if(c[d]===a)return this.Bf(d)};l.Bf=function(a){var c=this.a[a];Za.splice.call(this.a,a,1);wg(this);this.u(new ug("remove",c,this));return c};l.Xn=function(a,c){var d=this.Mb();if(a<d)d=this.a[a],this.a[a]=c,this.u(new ug("remove",d,this)),this.u(new ug("add",c,this));else{for(;d<a;++d)this.Vd(d,void 0);this.Vd(a,c)}};
function wg(a){a.set("length",a.a.length)};var xg=/^#(?:[0-9a-f]{3}){1,2}$/i,yg=/^(?:rgb)?\((0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2})\)$/i,zg=/^(?:rgba)?\((0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2}),\s?(0|1|0\.\d{0,10})\)$/i;function Ag(a){return ga(a)?a:Bg(a)}function Cg(a){if(!ia(a)){var c=a[0];c!=(c|0)&&(c=c+.5|0);var d=a[1];d!=(d|0)&&(d=d+.5|0);var e=a[2];e!=(e|0)&&(e=e+.5|0);a="rgba("+c+","+d+","+e+","+a[3]+")"}return a}
var Bg=function(){var a={},c=0;return function(d){var e;if(a.hasOwnProperty(d))e=a[d];else{if(1024<=c){e=0;for(var f in a)0===(e++&3)&&(delete a[f],--c)}var g,h;xg.exec(d)?(h=3==d.length-1?1:2,e=parseInt(d.substr(1+0*h,h),16),f=parseInt(d.substr(1+1*h,h),16),g=parseInt(d.substr(1+2*h,h),16),1==h&&(e=(e<<4)+e,f=(f<<4)+f,g=(g<<4)+g),e=[e,f,g,1]):(h=zg.exec(d))?(e=Number(h[1]),f=Number(h[2]),g=Number(h[3]),h=Number(h[4]),e=[e,f,g,h],e=Dg(e,e)):(h=yg.exec(d))?(e=Number(h[1]),f=Number(h[2]),g=Number(h[3]),
e=[e,f,g,1],e=Dg(e,e)):e=void 0;a[d]=e;++c}return e}}();function Dg(a,c){var d=c||[];d[0]=Sa(a[0]+.5|0,0,255);d[1]=Sa(a[1]+.5|0,0,255);d[2]=Sa(a[2]+.5|0,0,255);d[3]=Sa(a[3],0,1);return d};var Eg=!Zb||9<=lc;!ac&&!Zb||Zb&&9<=lc||ac&&jc("1.9.1");Zb&&jc("9");function Fg(a,c){this.x=ca(a)?a:0;this.y=ca(c)?c:0}l=Fg.prototype;l.clone=function(){return new Fg(this.x,this.y)};l.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};l.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};l.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};l.scale=function(a,c){var d=ja(c)?c:a;this.x*=a;this.y*=d;return this};function Gg(a,c){this.width=a;this.height=c}l=Gg.prototype;l.clone=function(){return new Gg(this.width,this.height)};l.zi=function(){return this.width*this.height};l.Ba=function(){return!this.zi()};l.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};l.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};l.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};
l.scale=function(a,c){var d=ja(c)?c:a;this.width*=a;this.height*=d;return this};function Hg(a){return a?new Ig(Jg(a)):za||(za=new Ig)}function Kg(a){var c=document;return ia(a)?c.getElementById(a):a}function Lg(a,c){Hb(c,function(c,e){"style"==e?a.style.cssText=c:"class"==e?a.className=c:"for"==e?a.htmlFor=c:Mg.hasOwnProperty(e)?a.setAttribute(Mg[e],c):0==e.lastIndexOf("aria-",0)||0==e.lastIndexOf("data-",0)?a.setAttribute(e,c):a[e]=c})}
var Mg={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};function Ng(a){a=a.document.documentElement;return new Gg(a.clientWidth,a.clientHeight)}
function Og(a,c,d){var e=arguments,f=document,g=e[0],h=e[1];if(!Eg&&h&&(h.name||h.type)){g=["<",g];h.name&&g.push(' name="',Da(h.name),'"');if(h.type){g.push(' type="',Da(h.type),'"');var k={};Xb(k,h);delete k.type;h=k}g.push(">");g=g.join("")}g=f.createElement(g);h&&(ia(h)?g.className=h:ga(h)?g.className=h.join(" "):Lg(g,h));2<e.length&&Pg(f,g,e,2);return g}
function Pg(a,c,d,e){function f(d){d&&c.appendChild(ia(d)?a.createTextNode(d):d)}for(;e<d.length;e++){var g=d[e];!ha(g)||la(g)&&0<g.nodeType?f(g):ab(Qg(g)?jb(g):g,f)}}function Rg(a){return document.createElement(a)}function Sg(a,c){Pg(Jg(a),a,arguments,1)}function Tg(a){for(var c;c=a.firstChild;)a.removeChild(c)}function Ug(a,c,d){a.insertBefore(c,a.childNodes[d]||null)}function Vg(a){a&&a.parentNode&&a.parentNode.removeChild(a)}function Wg(a,c){var d=c.parentNode;d&&d.replaceChild(a,c)}
function Xg(a){if(ca(a.firstElementChild))a=a.firstElementChild;else for(a=a.firstChild;a&&1!=a.nodeType;)a=a.nextSibling;return a}function Yg(a,c){if(a.contains&&1==c.nodeType)return a==c||a.contains(c);if("undefined"!=typeof a.compareDocumentPosition)return a==c||Boolean(a.compareDocumentPosition(c)&16);for(;c&&a!=c;)c=c.parentNode;return c==a}function Jg(a){return 9==a.nodeType?a:a.ownerDocument||a.document}
function Qg(a){if(a&&"number"==typeof a.length){if(la(a))return"function"==typeof a.item||"string"==typeof a.item;if(ka(a))return"function"==typeof a.item}return!1}function Ig(a){this.b=a||ba.document||document}function Zg(){return!0}
function $g(a){var c=a.b;a=c.scrollingElement?c.scrollingElement:bc?c.body||c.documentElement:c.documentElement;c=c.parentWindow||c.defaultView;return Zb&&jc("10")&&c.pageYOffset!=a.scrollTop?new Fg(a.scrollLeft,a.scrollTop):new Fg(c.pageXOffset||a.scrollLeft,c.pageYOffset||a.scrollTop)}Ig.prototype.appendChild=function(a,c){a.appendChild(c)};Ig.prototype.contains=Yg;function ah(a){if(a.classList)return a.classList;a=a.className;return ia(a)&&a.match(/\S+/g)||[]}function bh(a,c){var d;a.classList?d=a.classList.contains(c):(d=ah(a),d=0<=$a(d,c));return d}function ch(a,c){a.classList?a.classList.add(c):bh(a,c)||(a.className+=0<a.className.length?" "+c:c)}function dh(a,c){a.classList?a.classList.remove(c):bh(a,c)&&(a.className=bb(ah(a),function(a){return a!=c}).join(" "))}function eh(a,c){bh(a,c)?dh(a,c):ch(a,c)};function fh(a,c,d,e){this.top=a;this.right=c;this.bottom=d;this.left=e}l=fh.prototype;l.clone=function(){return new fh(this.top,this.right,this.bottom,this.left)};l.contains=function(a){return this&&a?a instanceof fh?a.left>=this.left&&a.right<=this.right&&a.top>=this.top&&a.bottom<=this.bottom:a.x>=this.left&&a.x<=this.right&&a.y>=this.top&&a.y<=this.bottom:!1};
l.ceil=function(){this.top=Math.ceil(this.top);this.right=Math.ceil(this.right);this.bottom=Math.ceil(this.bottom);this.left=Math.ceil(this.left);return this};l.floor=function(){this.top=Math.floor(this.top);this.right=Math.floor(this.right);this.bottom=Math.floor(this.bottom);this.left=Math.floor(this.left);return this};l.round=function(){this.top=Math.round(this.top);this.right=Math.round(this.right);this.bottom=Math.round(this.bottom);this.left=Math.round(this.left);return this};
l.scale=function(a,c){var d=ja(c)?c:a;this.left*=a;this.right*=a;this.top*=d;this.bottom*=d;return this};function gh(a,c,d,e){this.left=a;this.top=c;this.width=d;this.height=e}l=gh.prototype;l.clone=function(){return new gh(this.left,this.top,this.width,this.height)};l.contains=function(a){return a instanceof gh?this.left<=a.left&&this.left+this.width>=a.left+a.width&&this.top<=a.top&&this.top+this.height>=a.top+a.height:a.x>=this.left&&a.x<=this.left+this.width&&a.y>=this.top&&a.y<=this.top+this.height};
l.distance=function(a){var c=a.x<this.left?this.left-a.x:Math.max(a.x-(this.left+this.width),0);a=a.y<this.top?this.top-a.y:Math.max(a.y-(this.top+this.height),0);return Math.sqrt(c*c+a*a)};l.ceil=function(){this.left=Math.ceil(this.left);this.top=Math.ceil(this.top);this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};l.floor=function(){this.left=Math.floor(this.left);this.top=Math.floor(this.top);this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
l.round=function(){this.left=Math.round(this.left);this.top=Math.round(this.top);this.width=Math.round(this.width);this.height=Math.round(this.height);return this};l.scale=function(a,c){var d=ja(c)?c:a;this.left*=a;this.width*=a;this.top*=d;this.height*=d;return this};function hh(a,c){var d=Jg(a);return d.defaultView&&d.defaultView.getComputedStyle&&(d=d.defaultView.getComputedStyle(a,null))?d[c]||d.getPropertyValue(c)||"":""}function ih(a,c){return hh(a,c)||(a.currentStyle?a.currentStyle[c]:null)||a.style&&a.style[c]}function jh(a,c,d){var e;c instanceof Fg?(e=c.x,c=c.y):(e=c,c=d);a.style.left=kh(e);a.style.top=kh(c)}
function lh(a){var c;try{c=a.getBoundingClientRect()}catch(d){return{left:0,top:0,right:0,bottom:0}}Zb&&a.ownerDocument.body&&(a=a.ownerDocument,c.left-=a.documentElement.clientLeft+a.body.clientLeft,c.top-=a.documentElement.clientTop+a.body.clientTop);return c}function mh(a){if(1==a.nodeType)return a=lh(a),new Fg(a.left,a.top);a=a.changedTouches?a.changedTouches[0]:a;return new Fg(a.clientX,a.clientY)}function kh(a){"number"==typeof a&&(a=a+"px");return a}
function nh(a){var c=oh;if("none"!=ih(a,"display"))return c(a);var d=a.style,e=d.display,f=d.visibility,g=d.position;d.visibility="hidden";d.position="absolute";d.display="inline";a=c(a);d.display=e;d.position=g;d.visibility=f;return a}function oh(a){var c=a.offsetWidth,d=a.offsetHeight,e=bc&&!c&&!d;return ca(c)&&!e||!a.getBoundingClientRect?new Gg(c,d):(a=lh(a),new Gg(a.right-a.left,a.bottom-a.top))}function ph(a,c){a.style.display=c?"":"none"}
function qh(a,c,d,e){if(/^\d+px?$/.test(c))return parseInt(c,10);var f=a.style[d],g=a.runtimeStyle[d];a.runtimeStyle[d]=a.currentStyle[d];a.style[d]=c;c=a.style[e];a.style[d]=f;a.runtimeStyle[d]=g;return c}function rh(a,c){var d=a.currentStyle?a.currentStyle[c]:null;return d?qh(a,d,"left","pixelLeft"):0}
function sh(a,c){if(Zb){var d=rh(a,c+"Left"),e=rh(a,c+"Right"),f=rh(a,c+"Top"),g=rh(a,c+"Bottom");return new fh(f,e,g,d)}d=hh(a,c+"Left");e=hh(a,c+"Right");f=hh(a,c+"Top");g=hh(a,c+"Bottom");return new fh(parseFloat(f),parseFloat(e),parseFloat(g),parseFloat(d))}var th={thin:2,medium:4,thick:6};function uh(a,c){if("none"==(a.currentStyle?a.currentStyle[c+"Style"]:null))return 0;var d=a.currentStyle?a.currentStyle[c+"Width"]:null;return d in th?th[d]:qh(a,d,"left","pixelLeft")}
function vh(a){if(Zb&&!(9<=lc)){var c=uh(a,"borderLeft"),d=uh(a,"borderRight"),e=uh(a,"borderTop");a=uh(a,"borderBottom");return new fh(e,d,a,c)}c=hh(a,"borderLeftWidth");d=hh(a,"borderRightWidth");e=hh(a,"borderTopWidth");a=hh(a,"borderBottomWidth");return new fh(parseFloat(e),parseFloat(d),parseFloat(a),parseFloat(c))};function wh(a,c,d){vc.call(this,a);this.map=c;this.frameState=void 0!==d?d:null}w(wh,vc);function xh(a){id.call(this);this.element=a.element?a.element:null;this.a=this.T=null;this.v=[];this.render=a.render?a.render:xa;a.target&&this.f(a.target)}w(xh,id);xh.prototype.W=function(){Vg(this.element);xh.ba.W.call(this)};xh.prototype.g=function(){return this.a};
xh.prototype.setMap=function(a){this.a&&Vg(this.element);0<this.v.length&&(this.v.forEach(Zc),this.v.length=0);if(this.a=a)(this.T?this.T:a.C).appendChild(this.element),this.render!==xa&&this.v.push(B(a,"postrender",this.render,!1,this)),a.render()};xh.prototype.f=function(a){this.T=Kg(a)};function yh(){this.c=0;this.f={};this.a=this.b=null}l=yh.prototype;l.clear=function(){this.c=0;this.f={};this.a=this.b=null};function zh(a,c){return a.f.hasOwnProperty(c)}l.forEach=function(a,c){for(var d=this.b;d;)a.call(c,d.oc,d.Yd,this),d=d.gb};l.get=function(a){a=this.f[a];if(a===this.a)return a.oc;a===this.b?(this.b=this.b.gb,this.b.Qb=null):(a.gb.Qb=a.Qb,a.Qb.gb=a.gb);a.gb=null;a.Qb=this.a;this.a=this.a.gb=a;return a.oc};l.Vb=function(){return this.c};
l.R=function(){var a=Array(this.c),c=0,d;for(d=this.a;d;d=d.Qb)a[c++]=d.Yd;return a};l.Zb=function(){var a=Array(this.c),c=0,d;for(d=this.a;d;d=d.Qb)a[c++]=d.oc;return a};l.pop=function(){var a=this.b;delete this.f[a.Yd];a.gb&&(a.gb.Qb=null);this.b=a.gb;this.b||(this.a=null);--this.c;return a.oc};l.set=function(a,c){var d={Yd:a,gb:null,Qb:this.a,oc:c};this.a?this.a.gb=d:this.b=d;this.a=d;this.f[a]=d;++this.c};function Ah(a){yh.call(this);this.g=void 0!==a?a:2048}w(Ah,yh);function Bh(a){return a.Vb()>a.g}function Ch(a,c){for(var d,e;Bh(a)&&!(d=a.b.oc,e=d.b[0].toString(),e in c&&c[e].contains(d.b));)a.pop().sc()};function Dh(a,c){cd.call(this);this.b=a;this.state=c}w(Dh,cd);function Eh(a){a.u("change")}Dh.prototype.qb=function(){return v(this).toString()};Dh.prototype.D=function(){return this.b};function Fh(a){id.call(this);this.f=Ee(a.projection);this.j=void 0!==a.attributions?a.attributions:null;this.ea=a.logo;this.A=void 0!==a.state?a.state:"ready";this.P=void 0!==a.wrapX?a.wrapX:!1}w(Fh,id);l=Fh.prototype;l.ie=xa;l.pa=function(){return this.j};l.oa=function(){return this.ea};l.qa=function(){return this.f};l.ra=function(){return this.A};function Gh(a){return a.P}l.la=function(a){this.j=a;this.s()};function Hh(a,c){a.A=c;a.s()};function Ih(a){this.minZoom=void 0!==a.minZoom?a.minZoom:0;this.b=a.resolutions;this.maxZoom=this.b.length-1;this.c=void 0!==a.origin?a.origin:null;this.g=null;void 0!==a.origins&&(this.g=a.origins);var c=a.extent;void 0===c||this.c||this.g||(this.c=ge(c));this.i=null;void 0!==a.tileSizes&&(this.i=a.tileSizes);this.l=void 0!==a.tileSize?a.tileSize:this.i?null:256;this.v=void 0!==c?c:null;this.a=null;void 0!==a.sizes?this.a=a.sizes.map(function(a){return new og(Math.min(0,a[0]),Math.max(a[0]-1,-1),
Math.min(0,a[1]),Math.max(a[1]-1,-1))},this):c&&Jh(this,c);this.f=[0,0]}var Kh=[0,0,0];function Lh(a,c,d,e,f){f=a.xa(c,f);for(c=c[0]-1;c>=a.minZoom;){if(d.call(null,c,mg(a,f,c,e)))return!0;--c}return!1}l=Ih.prototype;l.J=function(){return this.v};l.cg=function(){return this.maxZoom};l.dg=function(){return this.minZoom};l.wa=function(a){return this.c?this.c:this.g[a]};l.aa=function(a){return this.b[a]};l.Vg=function(){return this.b};
function Mh(a,c,d,e){return c[0]<a.maxZoom?(e=a.xa(c,e),mg(a,e,c[0]+1,d)):null}function Nh(a,c,d,e){Oh(a,c[0],c[1],d,!1,Kh);var f=Kh[1],g=Kh[2];Oh(a,c[2],c[3],d,!0,Kh);a=Kh[1];c=Kh[2];void 0!==e?(e.b=f,e.f=a,e.a=g,e.c=c):e=new og(f,a,g,c);return e}function mg(a,c,d,e){d=a.aa(d);return Nh(a,c,d,e)}function jg(a,c){var d=a.wa(c[0]),e=a.aa(c[0]),f=od(a.Ia(c[0]),a.f);return[d[0]+(c[1]+.5)*f[0]*e,d[1]+(c[2]+.5)*f[1]*e]}
l.xa=function(a,c){var d=this.wa(a[0]),e=this.aa(a[0]),f=od(this.Ia(a[0]),this.f),g=d[0]+a[1]*f[0]*e,d=d[1]+a[2]*f[1]*e;return Rd(g,d,g+f[0]*e,d+f[1]*e,c)};l.fd=function(a,c,d){return Oh(this,a[0],a[1],c,!1,d)};function Oh(a,c,d,e,f,g){var h=Ph(a,e),k=e/a.aa(h),m=a.wa(h);a=od(a.Ia(h),a.f);c=k*Math.floor((c-m[0])/e+(f?.5:0))/a[0];d=k*Math.floor((d-m[1])/e+(f?0:.5))/a[1];f?(c=Math.ceil(c)-1,d=Math.ceil(d)-1):(c=Math.floor(c),d=Math.floor(d));return eg(h,c,d,g)}
l.Qd=function(a,c,d){c=this.aa(c);return Oh(this,a[0],a[1],c,!1,d)};l.Ia=function(a){return this.l?this.l:this.i[a]};function Ph(a,c){var d=vb(a.b,c,0);return Sa(d,a.minZoom,a.maxZoom)}function Jh(a,c){for(var d=a.b.length,e=Array(d),f=a.minZoom;f<d;++f)e[f]=mg(a,c,f);a.a=e}function Qh(a){var c=a.l;if(!c){var c=kg(a),d=Rh(c,void 0,void 0),c=new Ih({extent:c,origin:ge(c),resolutions:d,tileSize:void 0});a.l=c}return c}
function Sh(a){var c={};Xb(c,void 0!==a?a:{});void 0===c.extent&&(c.extent=Ee("EPSG:3857").J());c.resolutions=Rh(c.extent,c.maxZoom,c.tileSize);delete c.maxZoom;return new Ih(c)}function Rh(a,c,d){c=void 0!==c?c:42;var e=ke(a);a=je(a);d=od(void 0!==d?d:256);d=Math.max(a/d[0],e/d[1]);c+=1;e=Array(c);for(a=0;a<c;++a)e[a]=d/Math.pow(2,a);return e}function kg(a){a=Ee(a);var c=a.J();c||(a=180*Be.degrees/a.yc(),c=Rd(-a,-a,a,a));return c};function Th(a){Fh.call(this,{attributions:a.attributions,extent:a.extent,logo:a.logo,projection:a.projection,state:a.state,wrapX:a.wrapX});this.sa=void 0!==a.opaque?a.opaque:!1;this.ma=void 0!==a.tilePixelRatio?a.tilePixelRatio:1;this.tileGrid=void 0!==a.tileGrid?a.tileGrid:null;this.a=new Ah;this.c=[0,0]}w(Th,Fh);l=Th.prototype;l.Ng=function(){return Bh(this.a)};l.Og=function(a,c){var d=this.Bc(a);d&&Ch(d,c)};
function Uh(a,c,d,e,f){c=a.Bc(c);if(!c)return!1;for(var g=!0,h,k,m=e.b;m<=e.f;++m)for(var n=e.a;n<=e.c;++n)h=a.cb(d,m,n),k=!1,zh(c,h)&&(h=c.get(h),(k=2===h.state)&&(k=!1!==f(h))),k||(g=!1);return g}l.Jd=function(){return 0};l.cb=fg;l.Ha=function(){return this.tileGrid};l.Ua=function(a){return this.tileGrid?this.tileGrid:Qh(a)};l.Bc=function(a){var c=this.f;return c&&!We(c,a)?null:this.a};l.Yb=function(a,c,d){c=this.Ua(d);return nd(od(c.Ia(a),this.c),this.ma,this.c)};
function Vh(a,c,d){d=void 0!==d?d:a.f;var e=a.Ua(d);a.P&&d.c&&(c=ig(c,e,d));return lg(c,e)?c:null}l.Gf=xa;function Wh(a,c){vc.call(this,a);this.tile=c}w(Wh,vc);function Xh(a){a=a?a:{};this.C=Rg("UL");this.A=Rg("LI");this.C.appendChild(this.A);ph(this.A,!1);this.c=void 0!==a.collapsed?a.collapsed:!0;this.j=void 0!==a.collapsible?a.collapsible:!0;this.j||(this.c=!1);var c=a.className?a.className:"ol-attribution",d=a.tipLabel?a.tipLabel:"Attributions",e=a.collapseLabel?a.collapseLabel:"\u00bb";this.P=ia(e)?Og("SPAN",{},e):e;e=a.label?a.label:"i";this.H=ia(e)?Og("SPAN",{},e):e;d=Og("BUTTON",{type:"button",title:d},this.j&&!this.c?this.P:this.H);B(d,"click",
this.Yk,!1,this);B(d,["mouseout",yc],function(){this.blur()},!1);c=Og("DIV",c+" ol-unselectable ol-control"+(this.c&&this.j?" ol-collapsed":"")+(this.j?"":" ol-uncollapsible"),this.C,d);xh.call(this,{element:c,render:a.render?a.render:Yh,target:a.target});this.B=!0;this.l={};this.i={};this.ea={}}w(Xh,xh);
function Yh(a){if(a=a.frameState){var c,d,e,f,g,h,k,m,n,p,q,r=a.layerStatesArray,t=Ub(a.attributions),y={},A=a.viewState.projection;d=0;for(c=r.length;d<c;d++)if(h=r[d].layer.ga())if(p=v(h).toString(),n=h.j)for(e=0,f=n.length;e<f;e++)if(k=n[e],m=v(k).toString(),!(m in t)){if(g=a.usedTiles[p]){var F=h.Ua(A);a:{q=k;var z=A;if(q.b){var x=void 0,M=void 0,L=void 0,H=void 0;for(H in g)if(H in q.b)for(var L=g[H],J,x=0,M=q.b[H].length;x<M;++x){J=q.b[H][x];if(sg(J,L)){q=!0;break a}var ra=mg(F,z.J(),parseInt(H,
10)),Ga=rg(ra);if(L.b<ra.b||L.f>ra.f)if(sg(J,new og(pd(L.b,Ga),pd(L.f,Ga),L.a,L.c))||rg(L)>Ga&&sg(J,ra)){q=!0;break a}}q=!1}else q=!0}}else q=!1;q?(m in y&&delete y[m],t[m]=k):y[m]=k}c=[t,y];d=c[0];c=c[1];for(var K in this.l)K in d?(this.i[K]||(ph(this.l[K],!0),this.i[K]=!0),delete d[K]):K in c?(this.i[K]&&(ph(this.l[K],!1),delete this.i[K]),delete c[K]):(Vg(this.l[K]),delete this.l[K],delete this.i[K]);for(K in d)e=Rg("LI"),e.innerHTML=d[K].a,this.C.appendChild(e),this.l[K]=e,this.i[K]=!0;for(K in c)e=
Rg("LI"),e.innerHTML=c[K].a,ph(e,!1),this.C.appendChild(e),this.l[K]=e;K=!Qb(this.i)||!Qb(a.logos);this.B!=K&&(ph(this.element,K),this.B=K);K&&Qb(this.i)?ch(this.element,"ol-logo-only"):dh(this.element,"ol-logo-only");var oa;a=a.logos;K=this.ea;for(oa in K)oa in a||(Vg(K[oa]),delete K[oa]);for(var Oa in a)Oa in K||(oa=new Image,oa.src=Oa,d=a[Oa],""===d?d=oa:(d=Og("A",{href:d}),d.appendChild(oa)),this.A.appendChild(d),K[Oa]=d);ph(this.A,!Qb(a))}else this.B&&(ph(this.element,!1),this.B=!1)}l=Xh.prototype;
l.Yk=function(a){a.preventDefault();$h(this)};function $h(a){eh(a.element,"ol-collapsed");a.c?Wg(a.P,a.H):Wg(a.H,a.P);a.c=!a.c}l.Xk=function(){return this.j};l.$k=function(a){this.j!==a&&(this.j=a,eh(this.element,"ol-uncollapsible"),!a&&this.c&&$h(this))};l.Zk=function(a){this.j&&this.c!==a&&$h(this)};l.Wk=function(){return this.c};function ai(a){a=a?a:{};var c=a.className?a.className:"ol-rotate",d=a.label?a.label:"\u21e7";this.c=null;ia(d)?this.c=Og("SPAN","ol-compass",d):(this.c=d,ch(this.c,"ol-compass"));d=Og("BUTTON",{"class":c+"-reset",type:"button",title:a.tipLabel?a.tipLabel:"Reset rotation"},this.c);B(d,"click",ai.prototype.A,!1,this);c=Og("DIV",c+" ol-unselectable ol-control",d);xh.call(this,{element:c,render:a.render?a.render:bi,target:a.target});this.j=a.duration?a.duration:250;this.i=void 0!==a.autoHide?a.autoHide:
!0;this.l=void 0;this.i&&ch(this.element,"ol-hidden")}w(ai,xh);ai.prototype.A=function(a){a.preventDefault();a=this.a;var c=a.$();if(c){var d=c.za();void 0!==d&&(0<this.j&&(d%=2*Math.PI,d<-Math.PI&&(d+=2*Math.PI),d>Math.PI&&(d-=2*Math.PI),a.Ea(cg({rotation:d,duration:this.j,easing:Yf}))),c.de(0))}};
function bi(a){if(a=a.frameState){a=a.viewState.rotation;if(a!=this.l){var c="rotate("+a+"rad)";if(this.i){var d=this.element;0===a?ch(d,"ol-hidden"):dh(d,"ol-hidden")}this.c.style.msTransform=c;this.c.style.webkitTransform=c;this.c.style.transform=c}this.l=a}};function ci(a){a=a?a:{};var c=a.className?a.className:"ol-zoom",d=a.delta?a.delta:1,e=a.zoomOutLabel?a.zoomOutLabel:"\u2212",f=a.zoomOutTipLabel?a.zoomOutTipLabel:"Zoom out",g=Og("BUTTON",{"class":c+"-in",type:"button",title:a.zoomInTipLabel?a.zoomInTipLabel:"Zoom in"},a.zoomInLabel?a.zoomInLabel:"+");B(g,"click",ta(ci.prototype.i,d),!1,this);e=Og("BUTTON",{"class":c+"-out",type:"button",title:f},e);B(e,"click",ta(ci.prototype.i,-d),!1,this);c=Og("DIV",c+" ol-unselectable ol-control",g,e);xh.call(this,
{element:c,target:a.target});this.c=void 0!==a.duration?a.duration:250}w(ci,xh);ci.prototype.i=function(a,c){c.preventDefault();var d=this.a,e=d.$();if(e){var f=e.aa();f&&(0<this.c&&d.Ea(dg({resolution:f,duration:this.c,easing:Yf})),d=e.constrainResolution(f,a),e.Cb(d))}};function di(a){a=a?a:{};var c=new vg;(void 0!==a.zoom?a.zoom:1)&&c.push(new ci(a.zoomOptions));(void 0!==a.rotate?a.rotate:1)&&c.push(new ai(a.rotateOptions));(void 0!==a.attribution?a.attribution:1)&&c.push(new Xh(a.attributionOptions));return c};var ei=bc?"webkitfullscreenchange":ac?"mozfullscreenchange":Zb?"MSFullscreenChange":"fullscreenchange";function fi(){var a=Hg().b,c=a.body;return!!(c.webkitRequestFullscreen||c.mozRequestFullScreen&&a.mozFullScreenEnabled||c.msRequestFullscreen&&a.msFullscreenEnabled||c.requestFullscreen&&a.fullscreenEnabled)}
function gi(a){a.webkitRequestFullscreen?a.webkitRequestFullscreen():a.mozRequestFullScreen?a.mozRequestFullScreen():a.msRequestFullscreen?a.msRequestFullscreen():a.requestFullscreen&&a.requestFullscreen()}function hi(){var a=Hg().b;return!!(a.webkitIsFullScreen||a.mozFullScreen||a.msFullscreenElement||a.fullscreenElement)};function ii(a){a=a?a:{};this.c=a.className?a.className:"ol-full-screen";var c=a.label?a.label:"\u2194";this.i=ia(c)?document.createTextNode(String(c)):c;c=a.labelActive?a.labelActive:"\u00d7";this.j=ia(c)?document.createTextNode(String(c)):c;c=a.tipLabel?a.tipLabel:"Toggle full-screen";c=Og("BUTTON",{"class":this.c+"-"+hi(),type:"button",title:c},this.i);B(c,"click",this.B,!1,this);B(ba.document,ei,this.l,!1,this);var d=this.c+" ol-unselectable ol-control "+(fi()?"":"ol-unsupported"),c=Og("DIV",d,
c);xh.call(this,{element:c,target:a.target});this.A=void 0!==a.keys?a.keys:!1}w(ii,xh);ii.prototype.B=function(a){a.preventDefault();fi()&&(a=this.a)&&(hi()?(a=Hg().b,a.webkitCancelFullScreen?a.webkitCancelFullScreen():a.mozCancelFullScreen?a.mozCancelFullScreen():a.msExitFullscreen?a.msExitFullscreen():a.exitFullscreen&&a.exitFullscreen()):(a=a.kf(),a=Kg(a),this.A?a.mozRequestFullScreenWithKeys?a.mozRequestFullScreenWithKeys():a.webkitRequestFullscreen?a.webkitRequestFullscreen():gi(a):gi(a)))};
ii.prototype.l=function(){var a=this.c+"-true",c=this.c+"-false",d=Xg(this.element),e=this.a;hi()?(bh(d,c)&&(dh(d,c),ch(d,a)),Wg(this.j,this.i)):(bh(d,a)&&(dh(d,a),ch(d,c)),Wg(this.i,this.j));e&&e.Mc()};function ji(a){a=a?a:{};var c=Og("DIV",a.className?a.className:"ol-mouse-position");xh.call(this,{element:c,render:a.render?a.render:ki,target:a.target});B(this,kd("projection"),this.al,!1,this);a.coordinateFormat&&this.ph(a.coordinateFormat);a.projection&&this.zg(Ee(a.projection));this.A=a.undefinedHTML?a.undefinedHTML:"";this.l=c.innerHTML;this.j=this.i=this.c=null}w(ji,xh);
function ki(a){a=a.frameState;a?this.c!=a.viewState.projection&&(this.c=a.viewState.projection,this.i=null):this.c=null;li(this,this.j)}l=ji.prototype;l.al=function(){this.i=null};l.Zf=function(){return this.get("coordinateFormat")};l.yg=function(){return this.get("projection")};l.Vj=function(a){this.j=this.a.Hd(a.b);li(this,this.j)};l.Wj=function(){li(this,null);this.j=null};
l.setMap=function(a){ji.ba.setMap.call(this,a);a&&(a=a.a,this.v.push(B(a,"mousemove",this.Vj,!1,this),B(a,"mouseout",this.Wj,!1,this)))};l.ph=function(a){this.set("coordinateFormat",a)};l.zg=function(a){this.set("projection",a)};function li(a,c){var d=a.A;if(c&&a.c){if(!a.i){var e=a.yg();a.i=e?Ie(a.c,e):Ye}if(e=a.a.Aa(c))a.i(e,e),d=(d=a.Zf())?d(e):e.toString()}a.l&&d==a.l||(a.element.innerHTML=d,a.l=d)};function mi(a,c,d){qc.call(this);this.ta=null;this.c=!1;this.i=a;this.g=d;this.b=c||window;this.a=sa(this.f,this)}w(mi,qc);mi.prototype.start=function(){ni(this);this.c=!1;var a=oi(this),c=pi(this);a&&!c&&this.b.mozRequestAnimationFrame?(this.ta=B(this.b,"MozBeforePaint",this.a),this.b.mozRequestAnimationFrame(null),this.c=!0):this.ta=a&&c?a.call(this.b,this.a):this.b.setTimeout(we(this.a),20)};
function ni(a){if(null!=a.ta){var c=oi(a),d=pi(a);c&&!d&&a.b.mozRequestAnimationFrame?Zc(a.ta):c&&d?d.call(a.b,a.ta):a.b.clearTimeout(a.ta)}a.ta=null}mi.prototype.f=function(){this.c&&this.ta&&Zc(this.ta);this.ta=null;this.i.call(this.g,ua())};mi.prototype.W=function(){ni(this);mi.ba.W.call(this)};function oi(a){a=a.b;return a.requestAnimationFrame||a.webkitRequestAnimationFrame||a.mozRequestAnimationFrame||a.oRequestAnimationFrame||a.msRequestAnimationFrame||null}
function pi(a){a=a.b;return a.cancelAnimationFrame||a.cancelRequestAnimationFrame||a.webkitCancelRequestAnimationFrame||a.mozCancelRequestAnimationFrame||a.oCancelRequestAnimationFrame||a.msCancelRequestAnimationFrame||null};function qi(a){ba.setTimeout(function(){throw a;},0)}function ri(a,c){var d=a;c&&(d=sa(a,c));d=si(d);!ka(ba.setImmediate)||ba.Window&&ba.Window.prototype&&ba.Window.prototype.setImmediate==ba.setImmediate?(ti||(ti=ui()),ti(d)):ba.setImmediate(d)}var ti;
function ui(){var a=ba.MessageChannel;"undefined"===typeof a&&"undefined"!==typeof window&&window.postMessage&&window.addEventListener&&!Gb("Presto")&&(a=function(){var a=document.createElement("IFRAME");a.style.display="none";a.src="";document.documentElement.appendChild(a);var c=a.contentWindow,a=c.document;a.open();a.write("");a.close();var d="callImmediate"+Math.random(),e="file:"==c.location.protocol?"*":c.location.protocol+"//"+c.location.host,a=sa(function(a){if(("*"==e||a.origin==e)&&a.data==
d)this.port1.onmessage()},this);c.addEventListener("message",a,!1);this.port1={};this.port2={postMessage:function(){c.postMessage(d,e)}}});if("undefined"!==typeof a&&!Gb("Trident")&&!Gb("MSIE")){var c=new a,d={},e=d;c.port1.onmessage=function(){if(ca(d.next)){d=d.next;var a=d.Vf;d.Vf=null;a()}};return function(a){e.next={Vf:a};e=e.next;c.port2.postMessage(0)}}return"undefined"!==typeof document&&"onreadystatechange"in document.createElement("SCRIPT")?function(a){var c=document.createElement("SCRIPT");
c.onreadystatechange=function(){c.onreadystatechange=null;c.parentNode.removeChild(c);c=null;a();a=null};document.documentElement.appendChild(c)}:function(a){ba.setTimeout(a,0)}}var si=ve;function vi(a,c){this.a={};this.b=[];this.c=0;var d=arguments.length;if(1<d){if(d%2)throw Error("Uneven number of arguments");for(var e=0;e<d;e+=2)this.set(arguments[e],arguments[e+1])}else if(a){a instanceof vi?(d=a.R(),e=a.Zb()):(d=Mb(a),e=Lb(a));for(var f=0;f<d.length;f++)this.set(d[f],e[f])}}l=vi.prototype;l.Vb=function(){return this.c};l.Zb=function(){wi(this);for(var a=[],c=0;c<this.b.length;c++)a.push(this.a[this.b[c]]);return a};l.R=function(){wi(this);return this.b.concat()};
l.Ba=function(){return 0==this.c};l.clear=function(){this.a={};this.c=this.b.length=0};l.remove=function(a){return xi(this.a,a)?(delete this.a[a],this.c--,this.b.length>2*this.c&&wi(this),!0):!1};function wi(a){if(a.c!=a.b.length){for(var c=0,d=0;c<a.b.length;){var e=a.b[c];xi(a.a,e)&&(a.b[d++]=e);c++}a.b.length=d}if(a.c!=a.b.length){for(var f={},d=c=0;c<a.b.length;)e=a.b[c],xi(f,e)||(a.b[d++]=e,f[e]=1),c++;a.b.length=d}}l.get=function(a,c){return xi(this.a,a)?this.a[a]:c};
l.set=function(a,c){xi(this.a,a)||(this.c++,this.b.push(a));this.a[a]=c};l.forEach=function(a,c){for(var d=this.R(),e=0;e<d.length;e++){var f=d[e],g=this.get(f);a.call(c,g,f,this)}};l.clone=function(){return new vi(this)};function xi(a,c){return Object.prototype.hasOwnProperty.call(a,c)};function yi(){this.b=ua()}new yi;yi.prototype.set=function(a){this.b=a};yi.prototype.reset=function(){this.set(ua())};yi.prototype.get=function(){return this.b};function zi(a){cd.call(this);this.b=a||window;this.a=B(this.b,"resize",this.f,!1,this);this.c=Ng(this.b||window)}w(zi,cd);zi.prototype.W=function(){zi.ba.W.call(this);this.a&&(Zc(this.a),this.a=null);this.c=this.b=null};zi.prototype.f=function(){var a=Ng(this.b||window),c=this.c;a==c||a&&c&&a.width==c.width&&a.height==c.height||(this.c=a,this.u("resize"))};function Ai(a,c,d,e,f){if(!(Zb||$b||bc&&jc("525")))return!0;if(cc&&f)return Bi(a);if(f&&!e)return!1;ja(c)&&(c=Ci(c));if(!d&&(17==c||18==c||cc&&91==c))return!1;if((bc||$b)&&e&&d)switch(a){case 220:case 219:case 221:case 192:case 186:case 189:case 187:case 188:case 190:case 191:case 192:case 222:return!1}if(Zb&&e&&c==a)return!1;switch(a){case 13:return!0;case 27:return!(bc||$b)}return Bi(a)}
function Bi(a){if(48<=a&&57>=a||96<=a&&106>=a||65<=a&&90>=a||(bc||$b)&&0==a)return!0;switch(a){case 32:case 43:case 63:case 64:case 107:case 109:case 110:case 111:case 186:case 59:case 189:case 187:case 61:case 188:case 190:case 191:case 192:case 222:case 219:case 220:case 221:return!0;default:return!1}}function Ci(a){if(ac)a=Di(a);else if(cc&&bc)a:switch(a){case 93:a=91;break a}return a}
function Di(a){switch(a){case 61:return 187;case 59:return 186;case 173:return 189;case 224:return 91;case 0:return 224;default:return a}};function Ei(a,c){cd.call(this);a&&Fi(this,a,c)}w(Ei,cd);l=Ei.prototype;l.gd=null;l.Wd=null;l.df=null;l.Xd=null;l.Va=-1;l.Kb=-1;l.Le=!1;
var Gi={3:13,12:144,63232:38,63233:40,63234:37,63235:39,63236:112,63237:113,63238:114,63239:115,63240:116,63241:117,63242:118,63243:119,63244:120,63245:121,63246:122,63247:123,63248:44,63272:46,63273:36,63275:35,63276:33,63277:34,63289:144,63302:45},Hi={Up:38,Down:40,Left:37,Right:39,Enter:13,F1:112,F2:113,F3:114,F4:115,F5:116,F6:117,F7:118,F8:119,F9:120,F10:121,F11:122,F12:123,"U+007F":46,Home:36,End:35,PageUp:33,PageDown:34,Insert:45},Ii=Zb||$b||bc&&jc("525"),Ji=cc&&ac;
Ei.prototype.b=function(a){if(bc||$b)if(17==this.Va&&!a.D||18==this.Va&&!a.a||cc&&91==this.Va&&!a.A)this.Kb=this.Va=-1;-1==this.Va&&(a.D&&17!=a.i?this.Va=17:a.a&&18!=a.i?this.Va=18:a.A&&91!=a.i&&(this.Va=91));Ii&&!Ai(a.i,this.Va,a.f,a.D,a.a)?this.handleEvent(a):(this.Kb=Ci(a.i),Ji&&(this.Le=a.a))};Ei.prototype.a=function(a){this.Kb=this.Va=-1;this.Le=a.a};
Ei.prototype.handleEvent=function(a){var c=a.b,d,e,f=c.altKey;Zb&&"keypress"==a.type?(d=this.Kb,e=13!=d&&27!=d?c.keyCode:0):(bc||$b)&&"keypress"==a.type?(d=this.Kb,e=0<=c.charCode&&63232>c.charCode&&Bi(d)?c.charCode:0):Yb&&!bc?(d=this.Kb,e=Bi(d)?c.keyCode:0):(d=c.keyCode||this.Kb,e=c.charCode||0,Ji&&(f=this.Le),cc&&63==e&&224==d&&(d=191));var g=d=Ci(d),h=c.keyIdentifier;d?63232<=d&&d in Gi?g=Gi[d]:25==d&&a.f&&(g=9):h&&h in Hi&&(g=Hi[h]);this.Va=g;a=new Ki(g,e,0,c);a.a=f;this.u(a)};
function Fi(a,c,d){a.Xd&&Li(a);a.gd=c;a.Wd=B(a.gd,"keypress",a,d);a.df=B(a.gd,"keydown",a.b,d,a);a.Xd=B(a.gd,"keyup",a.a,d,a)}function Li(a){a.Wd&&(Zc(a.Wd),Zc(a.df),Zc(a.Xd),a.Wd=null,a.df=null,a.Xd=null);a.gd=null;a.Va=-1;a.Kb=-1}Ei.prototype.W=function(){Ei.ba.W.call(this);Li(this)};function Ki(a,c,d,e){Ac.call(this,e);this.type="key";this.i=a;this.v=c}w(Ki,Ac);function Mi(a,c){cd.call(this);var d=this.b=a;(d=la(d)&&1==d.nodeType?this.b:this.b?this.b.body:null)&&ih(d,"direction");this.a=B(this.b,ac?"DOMMouseScroll":"mousewheel",this,c)}w(Mi,cd);
Mi.prototype.handleEvent=function(a){var c=0,d=0;a=a.b;if("mousewheel"==a.type){c=1;if(Zb||bc&&(dc||jc("532.0")))c=40;d=Ni(-a.wheelDelta,c);c=ca(a.wheelDeltaX)?Ni(-a.wheelDeltaY,c):d}else d=a.detail,100<d?d=3:-100>d&&(d=-3),ca(a.axis)&&a.axis===a.HORIZONTAL_AXIS||(c=d);ja(this.c)&&(c=Math.min(Math.max(c,-this.c),this.c));d=new Oi(d,a,0,c);this.u(d)};function Ni(a,c){return bc&&(cc||ec)&&0!=a%c?a:a/c}Mi.prototype.W=function(){Mi.ba.W.call(this);Zc(this.a);this.a=null};
function Oi(a,c,d,e){Ac.call(this,c);this.type="mousewheel";this.detail=a;this.B=e}w(Oi,Ac);function Pi(a,c,d){vc.call(this,a);this.b=c;a=d?d:{};this.buttons=Qi(a);this.pressure=Ri(a,this.buttons);this.bubbles="bubbles"in a?a.bubbles:!1;this.cancelable="cancelable"in a?a.cancelable:!1;this.view="view"in a?a.view:null;this.detail="detail"in a?a.detail:null;this.screenX="screenX"in a?a.screenX:0;this.screenY="screenY"in a?a.screenY:0;this.clientX="clientX"in a?a.clientX:0;this.clientY="clientY"in a?a.clientY:0;this.button="button"in a?a.button:0;this.relatedTarget="relatedTarget"in a?a.relatedTarget:
null;this.pointerId="pointerId"in a?a.pointerId:0;this.width="width"in a?a.width:0;this.height="height"in a?a.height:0;this.pointerType="pointerType"in a?a.pointerType:"";this.isPrimary="isPrimary"in a?a.isPrimary:!1;c.preventDefault&&(this.preventDefault=function(){c.preventDefault()})}w(Pi,vc);function Qi(a){if(a.buttons||Si)a=a.buttons;else switch(a.which){case 1:a=1;break;case 2:a=4;break;case 3:a=2;break;default:a=0}return a}
function Ri(a,c){var d=0;a.pressure?d=a.pressure:d=c?.5:0;return d}var Si=!1;try{Si=1===(new MouseEvent("click",{buttons:1})).buttons}catch(a){};function Ti(a,c){var d=Rg("CANVAS");a&&(d.width=a);c&&(d.height=c);return d.getContext("2d")}
var Ui=function(){var a;return function(){if(void 0===a)if(ba.getComputedStyle){var c=Rg("P"),d,e={webkitTransform:"-webkit-transform",OTransform:"-o-transform",msTransform:"-ms-transform",MozTransform:"-moz-transform",transform:"transform"};document.body.appendChild(c);for(var f in e)f in c.style&&(c.style[f]="translate(1px,1px)",d=ba.getComputedStyle(c).getPropertyValue(e[f]));Vg(c);a=d&&"none"!==d}else a=!1;return a}}(),Vi=function(){var a;return function(){if(void 0===a)if(ba.getComputedStyle){var c=
Rg("P"),d,e={webkitTransform:"-webkit-transform",OTransform:"-o-transform",msTransform:"-ms-transform",MozTransform:"-moz-transform",transform:"transform"};document.body.appendChild(c);for(var f in e)f in c.style&&(c.style[f]="translate3d(1px,1px,1px)",d=ba.getComputedStyle(c).getPropertyValue(e[f]));Vg(c);a=d&&"none"!==d}else a=!1;return a}}();function Wi(a,c){var d=a.style;d.WebkitTransform=c;d.MozTransform=c;d.b=c;d.msTransform=c;d.transform=c;Zb&&jc("9.0")&&(a.style.transformOrigin="0 0")}
function Xi(a,c){var d;if(Vi()){var e=Array(16);for(d=0;16>d;++d)e[d]=c[d].toFixed(6);Wi(a,"matrix3d("+e.join(",")+")")}else if(Ui()){var e=[c[0],c[1],c[4],c[5],c[12],c[13]],f=Array(6);for(d=0;6>d;++d)f[d]=e[d].toFixed(6);Wi(a,"matrix("+f.join(",")+")")}else a.style.left=Math.round(c[12])+"px",a.style.top=Math.round(c[13])+"px"};var Yi=["experimental-webgl","webgl","webkit-3d","moz-webgl"];function Zi(a,c){var d,e,f=Yi.length;for(e=0;e<f;++e)try{if(d=a.getContext(Yi[e],c))return d}catch(g){}return null};var $i,aj=ba.devicePixelRatio||1,bj=!1,cj=function(){if(!("HTMLCanvasElement"in ba))return!1;try{var a=Ti();return a?(void 0!==a.setLineDash&&(bj=!0),!0):!1}catch(c){return!1}}(),dj="DeviceOrientationEvent"in ba,ej="geolocation"in ba.navigator,fj="ontouchstart"in ba,gj="PointerEvent"in ba,hj=!!ba.navigator.msPointerEnabled,ij=!1,jj,kj=[];if("WebGLRenderingContext"in ba)try{var lj=Zi(Rg("CANVAS"),{failIfMajorPerformanceCaveat:!0});lj&&(ij=!0,jj=lj.getParameter(lj.MAX_TEXTURE_SIZE),kj=lj.getSupportedExtensions())}catch(a){}
$i=ij;wa=kj;va=jj;function mj(a,c){this.b=a;this.g=c};function nj(a){mj.call(this,a,{mousedown:this.qk,mousemove:this.rk,mouseup:this.uk,mouseover:this.tk,mouseout:this.sk});this.a=a.a;this.c=[]}w(nj,mj);function oj(a,c){for(var d=a.c,e=c.clientX,f=c.clientY,g=0,h=d.length,k;g<h&&(k=d[g]);g++){var m=Math.abs(f-k[1]);if(25>=Math.abs(e-k[0])&&25>=m)return!0}return!1}function pj(a){var c=qj(a,a.b),d=c.preventDefault;c.preventDefault=function(){a.preventDefault();d()};c.pointerId=1;c.isPrimary=!0;c.pointerType="mouse";return c}l=nj.prototype;
l.qk=function(a){if(!oj(this,a)){(1).toString()in this.a&&this.cancel(a);var c=pj(a);this.a[(1).toString()]=a;rj(this.b,sj,c,a)}};l.rk=function(a){if(!oj(this,a)){var c=pj(a);rj(this.b,tj,c,a)}};l.uk=function(a){if(!oj(this,a)){var c=this.a[(1).toString()];c&&c.button===a.button&&(c=pj(a),rj(this.b,uj,c,a),delete this.a[(1).toString()])}};l.tk=function(a){if(!oj(this,a)){var c=pj(a);wj(this.b,c,a)}};l.sk=function(a){if(!oj(this,a)){var c=pj(a);xj(this.b,c,a)}};
l.cancel=function(a){var c=pj(a);this.b.cancel(c,a);delete this.a[(1).toString()]};function yj(a){mj.call(this,a,{MSPointerDown:this.zk,MSPointerMove:this.Ak,MSPointerUp:this.Dk,MSPointerOut:this.Bk,MSPointerOver:this.Ck,MSPointerCancel:this.yk,MSGotPointerCapture:this.wk,MSLostPointerCapture:this.xk});this.a=a.a;this.c=["","unavailable","touch","pen","mouse"]}w(yj,mj);function zj(a,c){var d=c;ja(c.b.pointerType)&&(d=qj(c,c.b),d.pointerType=a.c[c.b.pointerType]);return d}l=yj.prototype;l.zk=function(a){this.a[a.b.pointerId.toString()]=a;var c=zj(this,a);rj(this.b,sj,c,a)};
l.Ak=function(a){var c=zj(this,a);rj(this.b,tj,c,a)};l.Dk=function(a){var c=zj(this,a);rj(this.b,uj,c,a);delete this.a[a.b.pointerId.toString()]};l.Bk=function(a){var c=zj(this,a);xj(this.b,c,a)};l.Ck=function(a){var c=zj(this,a);wj(this.b,c,a)};l.yk=function(a){var c=zj(this,a);this.b.cancel(c,a);delete this.a[a.b.pointerId.toString()]};l.xk=function(a){this.b.u(new Pi("lostpointercapture",a,a.b))};l.wk=function(a){this.b.u(new Pi("gotpointercapture",a,a.b))};function Aj(a){mj.call(this,a,{pointerdown:this.mn,pointermove:this.nn,pointerup:this.rn,pointerout:this.pn,pointerover:this.qn,pointercancel:this.ln,gotpointercapture:this.Dj,lostpointercapture:this.pk})}w(Aj,mj);l=Aj.prototype;l.mn=function(a){Bj(this.b,a)};l.nn=function(a){Bj(this.b,a)};l.rn=function(a){Bj(this.b,a)};l.pn=function(a){Bj(this.b,a)};l.qn=function(a){Bj(this.b,a)};l.ln=function(a){Bj(this.b,a)};l.pk=function(a){Bj(this.b,a)};l.Dj=function(a){Bj(this.b,a)};function Cj(a,c){mj.call(this,a,{touchstart:this.ro,touchmove:this.qo,touchend:this.po,touchcancel:this.oo});this.a=a.a;this.j=c;this.c=void 0;this.i=0;this.f=void 0}w(Cj,mj);l=Cj.prototype;l.lh=function(){this.i=0;this.f=void 0};
function Dj(a,c,d){c=qj(c,d);c.pointerId=d.identifier+2;c.bubbles=!0;c.cancelable=!0;c.detail=a.i;c.button=0;c.buttons=1;c.width=d.webkitRadiusX||d.radiusX||0;c.height=d.webkitRadiusY||d.radiusY||0;c.pressure=d.webkitForce||d.force||.5;c.isPrimary=a.c===d.identifier;c.pointerType="touch";c.clientX=d.clientX;c.clientY=d.clientY;c.screenX=d.screenX;c.screenY=d.screenY;return c}
function Ej(a,c,d){function e(){c.preventDefault()}var f=Array.prototype.slice.call(c.b.changedTouches),g=f.length,h,k;for(h=0;h<g;++h)k=Dj(a,c,f[h]),k.preventDefault=e,d.call(a,c,k)}
l.ro=function(a){var c=a.b.touches,d=Mb(this.a),e=d.length;if(e>=c.length){var f=[],g,h,k;for(g=0;g<e;++g){h=d[g];k=this.a[h];var m;if(!(m=1==h))a:{m=c.length;for(var n=void 0,p=0;p<m;p++)if(n=c[p],n.identifier===h-2){m=!0;break a}m=!1}m||f.push(k.ic)}for(g=0;g<f.length;++g)this.Me(a,f[g])}c=Kb(this.a);if(0===c||1===c&&(1).toString()in this.a)this.c=a.b.changedTouches[0].identifier,void 0!==this.f&&ba.clearTimeout(this.f);Fj(this,a);this.i++;Ej(this,a,this.gn)};
l.gn=function(a,c){this.a[c.pointerId]={target:c.target,ic:c,Wg:c.target};var d=this.b;c.bubbles=!0;rj(d,Gj,c,a);d=this.b;c.bubbles=!1;rj(d,Hj,c,a);rj(this.b,sj,c,a)};l.qo=function(a){a.preventDefault();Ej(this,a,this.vk)};l.vk=function(a,c){var d=this.a[c.pointerId];if(d){var e=d.ic,f=d.Wg;rj(this.b,tj,c,a);e&&f!==c.target&&(e.relatedTarget=c.target,c.relatedTarget=f,e.target=f,c.target?(xj(this.b,e,a),wj(this.b,c,a)):(c.target=f,c.relatedTarget=null,this.Me(a,c)));d.ic=c;d.Wg=c.target}};
l.po=function(a){Fj(this,a);Ej(this,a,this.so)};l.so=function(a,c){rj(this.b,uj,c,a);this.b.ic(c,a);var d=this.b;c.bubbles=!1;rj(d,Ij,c,a);delete this.a[c.pointerId];c.isPrimary&&(this.c=void 0,this.f=ba.setTimeout(sa(this.lh,this),200))};l.oo=function(a){Ej(this,a,this.Me)};l.Me=function(a,c){this.b.cancel(c,a);this.b.ic(c,a);var d=this.b;c.bubbles=!1;rj(d,Ij,c,a);delete this.a[c.pointerId];c.isPrimary&&(this.c=void 0,this.f=ba.setTimeout(sa(this.lh,this),200))};
function Fj(a,c){var d=a.j.c,e=c.b.changedTouches[0];if(a.c===e.identifier){var f=[e.clientX,e.clientY];d.push(f);ba.setTimeout(function(){hb(d,f)},2500)}};function Jj(a){cd.call(this);this.f=a;this.a={};this.c={};this.b=[];gj?Kj(this,new Aj(this)):hj?Kj(this,new yj(this)):(a=new nj(this),Kj(this,a),fj&&Kj(this,new Cj(this,a)));a=this.b.length;for(var c,d=0;d<a;d++)c=this.b[d],Lj(this,Object.keys(c.g))}w(Jj,cd);function Kj(a,c){var d=Object.keys(c.g);d&&(d.forEach(function(a){var d=c.g[a];d&&(this.c[a]=sa(d,c))},a),a.b.push(c))}Jj.prototype.g=function(a){var c=this.c[a.type];c&&c(a)};
function Lj(a,c){c.forEach(function(a){B(this.f,a,this.g,!1,this)},a)}function Mj(a,c){c.forEach(function(a){Yc(this.f,a,this.g,!1,this)},a)}function qj(a,c){for(var d={},e,f=0,g=Nj.length;f<g;f++)e=Nj[f][0],d[e]=a[e]||c[e]||Nj[f][1];return d}Jj.prototype.ic=function(a,c){a.bubbles=!0;rj(this,Oj,a,c)};Jj.prototype.cancel=function(a,c){rj(this,Pj,a,c)};function xj(a,c,d){a.ic(c,d);var e=c.relatedTarget;e&&Yg(c.target,e)||(c.bubbles=!1,rj(a,Ij,c,d))}
function wj(a,c,d){c.bubbles=!0;rj(a,Gj,c,d);var e=c.relatedTarget;e&&Yg(c.target,e)||(c.bubbles=!1,rj(a,Hj,c,d))}function rj(a,c,d,e){a.u(new Pi(c,e,d))}function Bj(a,c){a.u(new Pi(c.type,c,c.b))}Jj.prototype.W=function(){for(var a=this.b.length,c,d=0;d<a;d++)c=this.b[d],Mj(this,Object.keys(c.g));Jj.ba.W.call(this)};
var tj="pointermove",sj="pointerdown",uj="pointerup",Gj="pointerover",Oj="pointerout",Hj="pointerenter",Ij="pointerleave",Pj="pointercancel",Nj=[["bubbles",!1],["cancelable",!1],["view",null],["detail",null],["screenX",0],["screenY",0],["clientX",0],["clientY",0],["ctrlKey",!1],["altKey",!1],["shiftKey",!1],["metaKey",!1],["button",0],["relatedTarget",null],["buttons",0],["pointerId",0],["width",0],["height",0],["pressure",0],["tiltX",0],["tiltY",0],["pointerType",""],["hwTimestamp",0],["isPrimary",
!1],["type",""],["target",null],["currentTarget",null],["which",0]];function Qj(a,c,d,e,f){wh.call(this,a,c,f);this.b=d;this.originalEvent=d.b;this.pixel=c.Hd(this.originalEvent);this.coordinate=c.Aa(this.pixel);this.dragging=void 0!==e?e:!1}w(Qj,wh);Qj.prototype.preventDefault=function(){Qj.ba.preventDefault.call(this);this.b.preventDefault()};Qj.prototype.c=function(){Qj.ba.c.call(this);this.b.c()};function Rj(a,c,d,e,f){Qj.call(this,a,c,d.b,e,f);this.a=d}w(Rj,Qj);
function Sj(a){cd.call(this);this.c=a;this.i=0;this.j=!1;this.a=this.l=this.f=null;a=this.c.a;this.A=0;this.v={};this.g=new Jj(a);this.b=null;this.l=B(this.g,sj,this.Zj,!1,this);this.D=B(this.g,tj,this.Ln,!1,this)}w(Sj,cd);function Tj(a,c){var d;d=new Rj(Uj,a.c,c);a.u(d);0!==a.i?(ba.clearTimeout(a.i),a.i=0,d=new Rj(Vj,a.c,c),a.u(d)):a.i=ba.setTimeout(sa(function(){this.i=0;var a=new Rj(Wj,this.c,c);this.u(a)},a),250)}
function Xj(a,c){c.type==Yj||c.type==Zj?delete a.v[c.pointerId]:c.type==ak&&(a.v[c.pointerId]=!0);a.A=Kb(a.v)}l=Sj.prototype;l.jg=function(a){Xj(this,a);var c=new Rj(Yj,this.c,a);this.u(c);!this.j&&0===a.button&&Tj(this,this.a);0===this.A&&(this.f.forEach(Zc),this.f=null,this.j=!1,this.a=null,uc(this.b),this.b=null)};
l.Zj=function(a){Xj(this,a);var c=new Rj(ak,this.c,a);this.u(c);this.a=a;this.f||(this.b=new Jj(document),this.f=[B(this.b,bk,this.Rk,!1,this),B(this.b,Yj,this.jg,!1,this),B(this.g,Zj,this.jg,!1,this)])};l.Rk=function(a){if(a.clientX!=this.a.clientX||a.clientY!=this.a.clientY){this.j=!0;var c=new Rj(ck,this.c,a,this.j);this.u(c)}a.preventDefault()};l.Ln=function(a){this.u(new Rj(a.type,this.c,a,!(!this.a||a.clientX==this.a.clientX&&a.clientY==this.a.clientY)))};
l.W=function(){this.D&&(Zc(this.D),this.D=null);this.l&&(Zc(this.l),this.l=null);this.f&&(this.f.forEach(Zc),this.f=null);this.b&&(uc(this.b),this.b=null);this.g&&(uc(this.g),this.g=null);Sj.ba.W.call(this)};var Wj="singleclick",Uj="click",Vj="dblclick",ck="pointerdrag",bk="pointermove",ak="pointerdown",Yj="pointerup",Zj="pointercancel",dk={Jo:Wj,yo:Uj,zo:Vj,Co:ck,Fo:bk,Bo:ak,Io:Yj,Ho:"pointerover",Go:"pointerout",Do:"pointerenter",Eo:"pointerleave",Ao:Zj};function ek(a){id.call(this);var c=Ub(a);c.opacity=void 0!==a.opacity?a.opacity:1;c.visible=void 0!==a.visible?a.visible:!0;c.zIndex=void 0!==a.zIndex?a.zIndex:0;c.maxResolution=void 0!==a.maxResolution?a.maxResolution:Infinity;c.minResolution=void 0!==a.minResolution?a.minResolution:0;this.K(c)}w(ek,id);
function fk(a){var c=a.Nb(),d=a.bf(),e=a.pb(),f=a.J(),g=a.Ob(),h=a.Ib(),k=a.Jb();return{layer:a,opacity:Sa(c,0,1),A:d,visible:e,Lb:!0,extent:f,zIndex:g,maxResolution:h,minResolution:Math.max(k,0)}}l=ek.prototype;l.J=function(){return this.get("extent")};l.Ib=function(){return this.get("maxResolution")};l.Jb=function(){return this.get("minResolution")};l.Nb=function(){return this.get("opacity")};l.pb=function(){return this.get("visible")};l.Ob=function(){return this.get("zIndex")};
l.cc=function(a){this.set("extent",a)};l.kc=function(a){this.set("maxResolution",a)};l.lc=function(a){this.set("minResolution",a)};l.dc=function(a){this.set("opacity",a)};l.ec=function(a){this.set("visible",a)};l.fc=function(a){this.set("zIndex",a)};function gk(){};function hk(a,c,d,e,f,g){vc.call(this,a,c);this.vectorContext=d;this.frameState=e;this.context=f;this.glContext=g}w(hk,vc);function ik(a){var c=Ub(a);delete c.source;ek.call(this,c);this.i=this.l=this.j=null;a.map&&this.setMap(a.map);B(this,kd("source"),this.ek,!1,this);this.Lc(a.source?a.source:null)}w(ik,ek);function jk(a,c){return a.visible&&c>=a.minResolution&&c<a.maxResolution}l=ik.prototype;l.af=function(a){a=a?a:[];a.push(fk(this));return a};l.ga=function(){return this.get("source")||null};l.bf=function(){var a=this.ga();return a?a.A:"undefined"};l.Il=function(){this.s()};
l.ek=function(){this.i&&(Zc(this.i),this.i=null);var a=this.ga();a&&(this.i=B(a,"change",this.Il,!1,this));this.s()};l.setMap=function(a){Zc(this.j);this.j=null;a||this.s();Zc(this.l);this.l=null;a&&(this.j=B(a,"precompose",function(a){var d=fk(this);d.Lb=!1;d.zIndex=Infinity;a.frameState.layerStatesArray.push(d);a.frameState.layerStates[v(this)]=d},!1,this),this.l=B(this,"change",a.render,!1,a),this.s())};l.Lc=function(a){this.set("source",a)};function kk(a,c,d,e,f){cd.call(this);this.i=f;this.extent=a;this.c=d;this.resolution=c;this.state=e}w(kk,cd);function lk(a){a.u("change")}kk.prototype.J=function(){return this.extent};kk.prototype.aa=function(){return this.resolution};function mk(a,c,d,e,f,g,h,k){Hd(a);0===c&&0===d||Kd(a,c,d);1==e&&1==f||Ld(a,e,f);0!==g&&Md(a,g);0===h&&0===k||Kd(a,h,k);return a}function nk(a,c){return a[0]==c[0]&&a[1]==c[1]&&a[4]==c[4]&&a[5]==c[5]&&a[12]==c[12]&&a[13]==c[13]}function ok(a,c,d){var e=a[1],f=a[5],g=a[13],h=c[0];c=c[1];d[0]=a[0]*h+a[4]*c+a[12];d[1]=e*h+f*c+g;return d};function pk(a){fd.call(this);this.a=a}w(pk,fd);l=pk.prototype;l.Ya=xa;l.gc=function(a,c,d,e){a=a.slice();ok(c.pixelToCoordinateMatrix,a,a);if(this.Ya(a,c,te,this))return d.call(e,this.a)};l.ge=se;l.Ed=function(a,c,d){return function(e,f){return Uh(a,c,e,f,function(a){d[e]||(d[e]={});d[e][a.b.toString()]=a})}};l.Ll=function(a){2===a.target.state&&qk(this)};function rk(a,c){var d=c.state;2!=d&&3!=d&&B(c,"change",a.Ll,!1,a);0==d&&(c.load(),d=c.state);return 2==d}
function qk(a){var c=a.a;c.pb()&&"ready"==c.bf()&&a.s()}function sk(a,c){c.Ng()&&a.postRenderFunctions.push(ta(function(a,c,f){c=v(a).toString();a.Og(f.viewState.projection,f.usedTiles[c])},c))}function tk(a,c){if(c){var d,e,f;e=0;for(f=c.length;e<f;++e)d=c[e],a[v(d).toString()]=d}}function uk(a,c){var d=c.ea;void 0!==d&&(ia(d)?a.logos[d]="":la(d)&&(a.logos[d.src]=d.href))}
function vk(a,c,d,e){c=v(c).toString();d=d.toString();c in a?d in a[c]?(a=a[c][d],e.b<a.b&&(a.b=e.b),e.f>a.f&&(a.f=e.f),e.a<a.a&&(a.a=e.a),e.c>a.c&&(a.c=e.c)):a[c][d]=e:(a[c]={},a[c][d]=e)}function wk(a,c,d){return[c*(Math.round(a[0]/c)+d[0]%2/2),c*(Math.round(a[1]/c)+d[1]%2/2)]}
function xk(a,c,d,e,f,g,h,k,m,n){var p=v(c).toString();p in a.wantedTiles||(a.wantedTiles[p]={});var q=a.wantedTiles[p];a=a.tileQueue;var r=d.minZoom,t,y,A,F,z,x;for(x=h;x>=r;--x)for(y=mg(d,g,x,y),A=d.aa(x),F=y.b;F<=y.f;++F)for(z=y.a;z<=y.c;++z)h-x<=k?(t=c.Xb(x,F,z,e,f),0==t.state&&(q[hg(t.b)]=!0,t.qb()in a.c||yk(a,[t,p,jg(d,t.b),A])),void 0!==m&&m.call(n,t)):c.Gf(x,F,z,f)};function zk(a){this.A=a.opacity;this.C=a.rotateWithView;this.D=a.rotation;this.v=a.scale;this.P=a.snapToPixel}l=zk.prototype;l.ke=function(){return this.A};l.Nd=function(){return this.C};l.le=function(){return this.D};l.me=function(){return this.v};l.Pd=function(){return this.P};l.ne=function(a){this.A=a};l.oe=function(a){this.D=a};l.pe=function(a){this.v=a};function Ak(a){a=a||{};this.g=void 0!==a.anchor?a.anchor:[.5,.5];this.f=null;this.a=void 0!==a.anchorOrigin?a.anchorOrigin:"top-left";this.j=void 0!==a.anchorXUnits?a.anchorXUnits:"fraction";this.l=void 0!==a.anchorYUnits?a.anchorYUnits:"fraction";var c=void 0!==a.crossOrigin?a.crossOrigin:null,d=void 0!==a.img?a.img:null,e=void 0!==a.imgSize?a.imgSize:null,f=a.src;void 0!==f&&0!==f.length||!d||(f=d.src);var g=void 0!==a.src?0:2,h=Bk.Hb(),k=h.get(f,c);k||(k=new Ck(d,f,e,c,g),h.set(f,c,k));this.b=
k;this.fa=void 0!==a.offset?a.offset:[0,0];this.c=void 0!==a.offsetOrigin?a.offsetOrigin:"top-left";this.i=null;this.B=void 0!==a.size?a.size:null;zk.call(this,{opacity:void 0!==a.opacity?a.opacity:1,rotation:void 0!==a.rotation?a.rotation:0,scale:void 0!==a.scale?a.scale:1,snapToPixel:void 0!==a.snapToPixel?a.snapToPixel:!0,rotateWithView:void 0!==a.rotateWithView?a.rotateWithView:!1})}w(Ak,zk);l=Ak.prototype;
l.Gb=function(){if(this.f)return this.f;var a=this.g,c=this.rb();if("fraction"==this.j||"fraction"==this.l){if(!c)return null;a=this.g.slice();"fraction"==this.j&&(a[0]*=c[0]);"fraction"==this.l&&(a[1]*=c[1])}if("top-left"!=this.a){if(!c)return null;a===this.g&&(a=this.g.slice());if("top-right"==this.a||"bottom-right"==this.a)a[0]=-a[0]+c[0];if("bottom-left"==this.a||"bottom-right"==this.a)a[1]=-a[1]+c[1]}return this.f=a};l.Pb=function(){return this.b.b};l.Kd=function(){return this.b.c};l.md=function(){return this.b.a};
l.je=function(){var a=this.b;if(!a.g)if(a.l){var c=a.c[0],d=a.c[1],e=Ti(c,d);e.fillRect(0,0,c,d);a.g=e.canvas}else a.g=a.b;return a.g};l.wa=function(){if(this.i)return this.i;var a=this.fa;if("top-left"!=this.c){var c=this.rb(),d=this.b.c;if(!c||!d)return null;a=a.slice();if("top-right"==this.c||"bottom-right"==this.c)a[0]=d[0]-c[0]-a[0];if("bottom-left"==this.c||"bottom-right"==this.c)a[1]=d[1]-c[1]-a[1]}return this.i=a};l.zm=function(){return this.b.i};l.rb=function(){return this.B?this.B:this.b.c};
l.ff=function(a,c){return B(this.b,"change",a,!1,c)};l.load=function(){this.b.load()};l.Ff=function(a,c){Yc(this.b,"change",a,!1,c)};function Ck(a,c,d,e,f){cd.call(this);this.g=null;this.b=a?a:new Image;e&&(this.b.crossOrigin=e);this.f=null;this.a=f;this.c=d;this.i=c;this.l=!1;2==this.a&&Dk(this)}w(Ck,cd);function Dk(a){var c=Ti(1,1);try{c.drawImage(a.b,0,0),c.getImageData(0,0,1,1)}catch(d){a.l=!0}}Ck.prototype.j=function(){this.a=3;this.f.forEach(Zc);this.f=null;this.u("change")};
Ck.prototype.D=function(){this.a=2;this.c=[this.b.width,this.b.height];this.f.forEach(Zc);this.f=null;Dk(this);this.u("change")};Ck.prototype.load=function(){if(0==this.a){this.a=1;this.f=[Xc(this.b,"error",this.j,!1,this),Xc(this.b,"load",this.D,!1,this)];try{this.b.src=this.i}catch(a){this.j()}}};function Bk(){this.b={};this.a=0}ea(Bk);Bk.prototype.clear=function(){this.b={};this.a=0};Bk.prototype.get=function(a,c){var d=c+":"+a;return d in this.b?this.b[d]:null};
Bk.prototype.set=function(a,c,d){this.b[c+":"+a]=d;++this.a};function Ek(a,c){qc.call(this);this.i=c;this.f={};this.v={}}w(Ek,qc);function Fk(a){var c=a.viewState,d=a.coordinateToPixelMatrix;mk(d,a.size[0]/2,a.size[1]/2,1/c.resolution,-1/c.resolution,-c.rotation,-c.center[0],-c.center[1]);Jd(d,a.pixelToCoordinateMatrix)}l=Ek.prototype;l.W=function(){Hb(this.f,uc);Ek.ba.W.call(this)};
function Gk(){var a=Bk.Hb();if(32<a.a){var c=0,d,e;for(d in a.b){e=a.b[d];var f;if(f=0===(c++&3))Ec(e)?e=ed(e,void 0,void 0):(e=Tc(e),e=!!e&&Nc(e,void 0,void 0)),f=!e;f&&(delete a.b[d],--a.a)}}}
l.of=function(a,c,d,e,f,g){var h,k=c.viewState,m=k.resolution,n=k.projection,k=a;if(n.a){var n=n.J(),p=je(n),q=a[0];if(q<n[0]||q>n[2])k=[q+p*Math.ceil((n[0]-q)/p),a[1]]}n=c.layerStatesArray;for(p=n.length-1;0<=p;--p){var r=n[p],q=r.layer;if(!r.Lb||jk(r,m)&&f.call(g,q))if(r=Hk(this,q),q.ga()&&(h=r.Ya(Gh(q.ga())?k:a,c,d,e)),h)return h}};
l.Hg=function(a,c,d,e,f,g){var h,k=c.viewState.resolution,m=c.layerStatesArray,n;for(n=m.length-1;0<=n;--n){h=m[n];var p=h.layer;if(jk(h,k)&&f.call(g,p)&&(h=Hk(this,p).gc(a,c,d,e)))return h}};l.Ig=function(a,c,d,e){return void 0!==this.of(a,c,te,this,d,e)};function Hk(a,c){var d=v(c).toString();if(d in a.f)return a.f[d];var e=a.Qe(c);a.f[d]=e;a.v[d]=B(e,"change",a.Pj,!1,a);return e}l.Pj=function(){this.i.render()};l.we=xa;
l.Rn=function(a,c){for(var d in this.f)if(!(c&&d in c.layerStates)){var e=d,f=this.f[e];delete this.f[e];Zc(this.v[e]);delete this.v[e];uc(f)}};function Ik(a,c){for(var d in a.f)if(!(d in c.layerStates)){c.postRenderFunctions.push(sa(a.Rn,a));break}}function qb(a,c){return a.zIndex-c.zIndex};function Jk(a,c){this.j=a;this.g=c;this.b=[];this.a=[];this.c={}}Jk.prototype.clear=function(){this.b.length=0;this.a.length=0;Rb(this.c)};function Kk(a){var c=a.b,d=a.a,e=c[0];1==c.length?(c.length=0,d.length=0):(c[0]=c.pop(),d[0]=d.pop(),Lk(a,0));c=a.g(e);delete a.c[c];return e}function yk(a,c){var d=a.j(c);Infinity!=d&&(a.b.push(c),a.a.push(d),a.c[a.g(c)]=!0,Mk(a,0,a.b.length-1))}Jk.prototype.Vb=function(){return this.b.length};Jk.prototype.Ba=function(){return 0===this.b.length};
function Lk(a,c){for(var d=a.b,e=a.a,f=d.length,g=d[c],h=e[c],k=c;c<f>>1;){var m=2*c+1,n=2*c+2,m=n<f&&e[n]<e[m]?n:m;d[c]=d[m];e[c]=e[m];c=m}d[c]=g;e[c]=h;Mk(a,k,c)}function Mk(a,c,d){var e=a.b;a=a.a;for(var f=e[d],g=a[d];d>c;){var h=d-1>>1;if(a[h]>g)e[d]=e[h],a[d]=a[h],d=h;else break}e[d]=f;a[d]=g}function Nk(a){var c=a.j,d=a.b,e=a.a,f=0,g=d.length,h,k,m;for(k=0;k<g;++k)h=d[k],m=c(h),Infinity==m?delete a.c[a.g(h)]:(e[f]=m,d[f++]=h);d.length=f;e.length=f;for(c=(a.b.length>>1)-1;0<=c;c--)Lk(a,c)};function Ok(a,c){Jk.call(this,function(c){return a.apply(null,c)},function(a){return a[0].qb()});this.l=c;this.f=0}w(Ok,Jk);Ok.prototype.i=function(a){a=a.target;var c=a.state;if(2===c||3===c||4===c)Yc(a,"change",this.i,!1,this),--this.f,this.l()};function Pk(a,c,d){for(var e=0,f;a.f<c&&e<d&&0<a.Vb();)f=Kk(a)[0],0===f.state&&(B(f,"change",a.i,!1,a),f.load(),++a.f,++e)};function Qk(a,c,d){this.f=a;this.c=c;this.i=d;this.b=[];this.a=this.g=0}function Rk(a,c){var d=a.f,e=a.a,f=a.c-e,g=Math.log(a.c/a.a)/a.f;return bg({source:c,duration:g,easing:function(a){return e*(Math.exp(d*a*g)-1)/f}})};function Sk(a){id.call(this);this.v=null;this.g(!0);this.handleEvent=a.handleEvent}w(Sk,id);Sk.prototype.c=function(){return this.get("active")};Sk.prototype.g=function(a){this.set("active",a)};Sk.prototype.setMap=function(a){this.v=a};function Tk(a,c,d,e,f){if(void 0!==d){var g=c.za(),h=c.Na();void 0!==g&&h&&f&&0<f&&(a.Ea(cg({rotation:g,duration:f,easing:Yf})),e&&a.Ea(bg({source:h,duration:f,easing:Yf})));c.rotate(d,e)}}
function Uk(a,c,d,e,f){var g=c.aa();d=c.constrainResolution(g,d,0);Vk(a,c,d,e,f)}function Vk(a,c,d,e,f){if(d){var g=c.aa(),h=c.Na();void 0!==g&&h&&d!==g&&f&&0<f&&(a.Ea(dg({resolution:g,duration:f,easing:Yf})),e&&a.Ea(bg({source:h,duration:f,easing:Yf})));if(e){var k;a=c.Na();f=c.aa();void 0!==a&&void 0!==f&&(k=[e[0]-d*(e[0]-a[0])/f,e[1]-d*(e[1]-a[1])/f]);c.Wa(k)}c.Cb(d)}};function Wk(a){a=a?a:{};this.a=a.delta?a.delta:1;Sk.call(this,{handleEvent:Xk});this.f=a.duration?a.duration:250}w(Wk,Sk);function Xk(a){var c=!1,d=a.b;if(a.type==Vj){var c=a.map,e=a.coordinate,d=d.f?-this.a:this.a,f=c.$();Uk(c,f,d,e,this.f);a.preventDefault();c=!0}return!c};function Yk(a){a=a.b;return a.a&&!a.l&&a.f}function Zk(a){return"pointermove"==a.type}function $k(a){return a.type==Wj}function al(a){a=a.b;return!a.a&&!a.l&&!a.f}function bl(a){a=a.b;return!a.a&&!a.l&&a.f}function cl(a){a=a.b.target.tagName;return"INPUT"!==a&&"SELECT"!==a&&"TEXTAREA"!==a}function dl(a){return"mouse"==a.a.pointerType};function el(a){a=a?a:{};Sk.call(this,{handleEvent:a.handleEvent?a.handleEvent:fl});this.pc=a.handleDownEvent?a.handleDownEvent:se;this.qc=a.handleDragEvent?a.handleDragEvent:xa;this.Pc=a.handleMoveEvent?a.handleMoveEvent:xa;this.Ge=a.handleUpEvent?a.handleUpEvent:se;this.B=!1;this.ea={};this.i=[]}w(el,Sk);function gl(a){for(var c=a.length,d=0,e=0,f=0;f<c;f++)d+=a[f].clientX,e+=a[f].clientY;return[d/c,e/c]}
function fl(a){if(!(a instanceof Rj))return!0;var c=!1,d=a.type;if(d===ak||d===ck||d===Yj)d=a.a,a.type==Yj?delete this.ea[d.pointerId]:a.type==ak?this.ea[d.pointerId]=d:d.pointerId in this.ea&&(this.ea[d.pointerId]=d),this.i=Lb(this.ea);this.B&&(a.type==ck?this.qc(a):a.type==Yj&&(this.B=this.Ge(a)));a.type==ak?(this.B=a=this.pc(a),c=this.mc(a)):a.type==bk&&this.Pc(a);return!c}el.prototype.mc=ve;function hl(a){el.call(this,{handleDownEvent:il,handleDragEvent:jl,handleUpEvent:kl});a=a?a:{};this.a=a.kinetic;this.f=this.j=null;this.A=a.condition?a.condition:al;this.l=!1}w(hl,el);function jl(a){var c=gl(this.i);this.a&&this.a.b.push(c[0],c[1],Date.now());if(this.f){var d=this.f[0]-c[0],e=c[1]-this.f[1];a=a.map;var f=a.$(),g=Uf(f),e=d=[d,e],h=g.resolution;e[0]*=h;e[1]*=h;wd(d,g.rotation);rd(d,g.center);d=f.Dd(d);a.render();f.Wa(d)}this.f=c}
function kl(a){a=a.map;var c=a.$();if(0===this.i.length){var d;if(d=!this.l&&this.a)if(d=this.a,6>d.b.length)d=!1;else{var e=Date.now()-d.i,f=d.b.length-3;if(d.b[f+2]<e)d=!1;else{for(var g=f-3;0<g&&d.b[g+2]>e;)g-=3;var e=d.b[f+2]-d.b[g+2],h=d.b[f]-d.b[g],f=d.b[f+1]-d.b[g+1];d.g=Math.atan2(f,h);d.a=Math.sqrt(h*h+f*f)/e;d=d.a>d.c}}d&&(d=this.a,d=(d.c-d.a)/d.f,f=this.a.g,g=c.Na(),this.j=Rk(this.a,g),a.Ea(this.j),g=a.Ga(g),d=a.Aa([g[0]-d*Math.cos(f),g[1]-d*Math.sin(f)]),d=c.Dd(d),c.Wa(d));Wf(c,-1);a.render();
return!1}this.f=null;return!0}function il(a){if(0<this.i.length&&this.A(a)){var c=a.map,d=c.$();this.f=null;this.B||Wf(d,1);c.render();this.j&&hb(c.H,this.j)&&(d.Wa(a.frameState.viewState.center),this.j=null);this.a&&(a=this.a,a.b.length=0,a.g=0,a.a=0);this.l=1<this.i.length;return!0}return!1}hl.prototype.mc=se;function ll(a){a=a?a:{};el.call(this,{handleDownEvent:ml,handleDragEvent:nl,handleUpEvent:pl});this.f=a.condition?a.condition:Yk;this.a=void 0;this.j=a.duration?a.duration:250}w(ll,el);function nl(a){if(dl(a)){var c=a.map,d=c.La();a=a.pixel;d=Math.atan2(d[1]/2-a[1],a[0]-d[0]/2);if(void 0!==this.a){a=d-this.a;var e=c.$(),f=e.za();c.render();Tk(c,e,f-a)}this.a=d}}
function pl(a){if(!dl(a))return!0;a=a.map;var c=a.$();Wf(c,-1);var d=c.za(),e=this.j,d=c.constrainRotation(d,0);Tk(a,c,d,void 0,e);return!1}function ml(a){return dl(a)&&Cc(a.b)&&this.f(a)?(a=a.map,Wf(a.$(),1),a.render(),this.a=void 0,!0):!1}ll.prototype.mc=se;function ql(a){this.f=null;this.a=document.createElement("div");this.a.style.position="absolute";this.a.className="ol-box "+a;this.c=this.g=this.b=null}w(ql,qc);ql.prototype.W=function(){this.setMap(null);ql.ba.W.call(this)};function rl(a){var c=a.g,d=a.c;a=a.a.style;a.left=Math.min(c[0],d[0])+"px";a.top=Math.min(c[1],d[1])+"px";a.width=Math.abs(d[0]-c[0])+"px";a.height=Math.abs(d[1]-c[1])+"px"}
ql.prototype.setMap=function(a){if(this.b){this.b.P.removeChild(this.a);var c=this.a.style;c.left=c.top=c.width=c.height="inherit"}(this.b=a)&&this.b.P.appendChild(this.a)};function sl(a){var c=a.g,d=a.c,c=[c,[c[0],d[1]],d,[d[0],c[1]]].map(a.b.Aa,a.b);c[4]=c[0].slice();a.f?a.f.ja([c]):a.f=new D([c])}ql.prototype.Y=function(){return this.f};function tl(a,c){vc.call(this,a);this.coordinate=c}w(tl,vc);function ul(a){el.call(this,{handleDownEvent:vl,handleDragEvent:wl,handleUpEvent:xl});a=a?a:{};this.f=new ql(a.className||"ol-dragbox");this.a=null;this.A=a.condition?a.condition:te}w(ul,el);function wl(a){if(dl(a)){var c=this.f;a=a.pixel;c.g=this.a;c.c=a;sl(c);rl(c)}}ul.prototype.Y=function(){return this.f.Y()};ul.prototype.l=xa;
function xl(a){if(!dl(a))return!0;this.f.setMap(null);var c=a.pixel[0]-this.a[0],d=a.pixel[1]-this.a[1];64<=c*c+d*d&&(this.l(a),this.u(new tl("boxend",a.coordinate)));return!1}function vl(a){if(dl(a)&&Cc(a.b)&&this.A(a)){this.a=a.pixel;this.f.setMap(a.map);var c=this.f,d=this.a;c.g=this.a;c.c=d;sl(c);rl(c);this.u(new tl("boxstart",a.coordinate));return!0}return!1};function yl(a){a=a?a:{};var c=a.condition?a.condition:bl;this.j=void 0!==a.duration?a.duration:200;ul.call(this,{condition:c,className:a.className||"ol-dragzoom"})}w(yl,ul);yl.prototype.l=function(){var a=this.v,c=a.$(),d=a.La(),e=this.Y().J(),d=c.constrainResolution(Math.max(je(e)/d[0],ke(e)/d[1])),f=c.aa(),g=c.Na();a.Ea(dg({resolution:f,duration:this.j,easing:Yf}));a.Ea(bg({source:g,duration:this.j,easing:Yf}));c.Wa(le(e));c.Cb(d)};function zl(a){Sk.call(this,{handleEvent:Al});a=a||{};this.a=void 0!==a.condition?a.condition:ye(al,cl);this.f=void 0!==a.duration?a.duration:100;this.i=void 0!==a.pixelDelta?a.pixelDelta:128}w(zl,Sk);
function Al(a){var c=!1;if("key"==a.type){var d=a.b.i;if(this.a(a)&&(40==d||37==d||39==d||38==d)){var e=a.map,c=e.$(),f=c.aa()*this.i,g=0,h=0;40==d?h=-f:37==d?g=-f:39==d?g=f:h=f;d=[g,h];wd(d,c.za());f=this.f;if(g=c.Na())f&&0<f&&e.Ea(bg({source:g,duration:f,easing:$f})),e=c.Dd([g[0]+d[0],g[1]+d[1]]),c.Wa(e);a.preventDefault();c=!0}}return!c};function Bl(a){Sk.call(this,{handleEvent:Cl});a=a?a:{};this.f=a.condition?a.condition:cl;this.a=a.delta?a.delta:1;this.i=void 0!==a.duration?a.duration:100}w(Bl,Sk);function Cl(a){var c=!1;if("key"==a.type){var d=a.b.v;if(this.f(a)&&(43==d||45==d)){c=a.map;d=43==d?this.a:-this.a;c.render();var e=c.$();Uk(c,e,d,void 0,this.i);a.preventDefault();c=!0}}return!c};function Dl(a){Sk.call(this,{handleEvent:El});a=a||{};this.f=0;this.B=void 0!==a.duration?a.duration:250;this.l=void 0!==a.useAnchor?a.useAnchor:!0;this.a=null;this.j=this.i=void 0}w(Dl,Sk);function El(a){var c=!1;if("mousewheel"==a.type){var c=a.map,d=a.b;this.l&&(this.a=a.coordinate);this.f+=d.B;void 0===this.i&&(this.i=Date.now());d=Math.max(80-(Date.now()-this.i),0);ba.clearTimeout(this.j);this.j=ba.setTimeout(sa(this.A,this,c),d);a.preventDefault();c=!0}return!c}
Dl.prototype.A=function(a){var c=Sa(this.f,-1,1),d=a.$();a.render();Uk(a,d,-c,this.a,this.B);this.f=0;this.a=null;this.j=this.i=void 0};Dl.prototype.C=function(a){this.l=a;a||(this.a=null)};function Fl(a){el.call(this,{handleDownEvent:Gl,handleDragEvent:Hl,handleUpEvent:Il});a=a||{};this.f=null;this.j=void 0;this.a=!1;this.l=0;this.C=void 0!==a.threshold?a.threshold:.3;this.A=void 0!==a.duration?a.duration:250}w(Fl,el);
function Hl(a){var c=0,d=this.i[0],e=this.i[1],d=Math.atan2(e.clientY-d.clientY,e.clientX-d.clientX);void 0!==this.j&&(c=d-this.j,this.l+=c,!this.a&&Math.abs(this.l)>this.C&&(this.a=!0));this.j=d;a=a.map;d=mh(a.a);e=gl(this.i);e[0]-=d.x;e[1]-=d.y;this.f=a.Aa(e);this.a&&(d=a.$(),e=d.za(),a.render(),Tk(a,d,e+c,this.f))}function Il(a){if(2>this.i.length){a=a.map;var c=a.$();Wf(c,-1);if(this.a){var d=c.za(),e=this.f,f=this.A,d=c.constrainRotation(d,0);Tk(a,c,d,e,f)}return!1}return!0}
function Gl(a){return 2<=this.i.length?(a=a.map,this.f=null,this.j=void 0,this.a=!1,this.l=0,this.B||Wf(a.$(),1),a.render(),!0):!1}Fl.prototype.mc=se;function Jl(a){el.call(this,{handleDownEvent:Kl,handleDragEvent:Ll,handleUpEvent:Ml});a=a?a:{};this.f=null;this.l=void 0!==a.duration?a.duration:400;this.a=void 0;this.j=1}w(Jl,el);function Ll(a){var c=1,d=this.i[0],e=this.i[1],f=d.clientX-e.clientX,d=d.clientY-e.clientY,f=Math.sqrt(f*f+d*d);void 0!==this.a&&(c=this.a/f);this.a=f;1!=c&&(this.j=c);a=a.map;var f=a.$(),d=f.aa(),e=mh(a.a),g=gl(this.i);g[0]-=e.x;g[1]-=e.y;this.f=a.Aa(g);a.render();Vk(a,f,d*c,this.f)}
function Ml(a){if(2>this.i.length){a=a.map;var c=a.$();Wf(c,-1);var d=c.aa(),e=this.f,f=this.l,d=c.constrainResolution(d,0,this.j-1);Vk(a,c,d,e,f);return!1}return!0}function Kl(a){return 2<=this.i.length?(a=a.map,this.f=null,this.a=void 0,this.j=1,this.B||Wf(a.$(),1),a.render(),!0):!1}Jl.prototype.mc=se;function Nl(a){a=a?a:{};var c=new vg,d=new Qk(-.005,.05,100);(void 0!==a.altShiftDragRotate?a.altShiftDragRotate:1)&&c.push(new ll);(void 0!==a.doubleClickZoom?a.doubleClickZoom:1)&&c.push(new Wk({delta:a.zoomDelta,duration:a.zoomDuration}));(void 0!==a.dragPan?a.dragPan:1)&&c.push(new hl({kinetic:d}));(void 0!==a.pinchRotate?a.pinchRotate:1)&&c.push(new Fl);(void 0!==a.pinchZoom?a.pinchZoom:1)&&c.push(new Jl({duration:a.zoomDuration}));if(void 0!==a.keyboard?a.keyboard:1)c.push(new zl),c.push(new Bl({delta:a.zoomDelta,
duration:a.zoomDuration}));(void 0!==a.mouseWheelZoom?a.mouseWheelZoom:1)&&c.push(new Dl({duration:a.zoomDuration}));(void 0!==a.shiftDragZoom?a.shiftDragZoom:1)&&c.push(new yl({duration:a.zoomDuration}));return c};function Ol(a){var c=a||{};a=Ub(c);delete a.layers;c=c.layers;ek.call(this,a);this.c=[];this.a={};B(this,kd("layers"),this.Rj,!1,this);c?ga(c)&&(c=new vg(c.slice())):c=new vg;this.uh(c)}w(Ol,ek);l=Ol.prototype;l.Sd=function(){this.pb()&&this.s()};
l.Rj=function(){this.c.forEach(Zc);this.c.length=0;var a=this.Ec();this.c.push(B(a,"add",this.Qj,!1,this),B(a,"remove",this.Sj,!1,this));Hb(this.a,function(a){a.forEach(Zc)});Rb(this.a);var a=a.a,c,d,e;c=0;for(d=a.length;c<d;c++)e=a[c],this.a[v(e).toString()]=[B(e,"propertychange",this.Sd,!1,this),B(e,"change",this.Sd,!1,this)];this.s()};l.Qj=function(a){a=a.element;var c=v(a).toString();this.a[c]=[B(a,"propertychange",this.Sd,!1,this),B(a,"change",this.Sd,!1,this)];this.s()};
l.Sj=function(a){a=v(a.element).toString();this.a[a].forEach(Zc);delete this.a[a];this.s()};l.Ec=function(){return this.get("layers")};l.uh=function(a){this.set("layers",a)};
l.af=function(a){var c=void 0!==a?a:[],d=c.length;this.Ec().forEach(function(a){a.af(c)});a=fk(this);var e,f;for(e=c.length;d<e;d++)f=c[d],f.opacity*=a.opacity,f.visible=f.visible&&a.visible,f.maxResolution=Math.min(f.maxResolution,a.maxResolution),f.minResolution=Math.max(f.minResolution,a.minResolution),void 0!==a.extent&&(f.extent=void 0!==f.extent?ne(f.extent,a.extent):a.extent);return c};l.bf=function(){return"ready"};function Pl(a){Ce.call(this,{code:a,units:"m",extent:Ql,global:!0,worldExtent:Rl})}w(Pl,Ce);Pl.prototype.getPointResolution=function(a,c){return a/Ta(c[1]/6378137)};var Sl=6378137*Math.PI,Ql=[-Sl,-Sl,Sl,Sl],Rl=[-180,-85,180,85],Pe="EPSG:3857 EPSG:102100 EPSG:102113 EPSG:900913 urn:ogc:def:crs:EPSG:6.18:3:3857 urn:ogc:def:crs:EPSG::3857 http://www.opengis.net/gml/srs/epsg.xml#3857".split(" ").map(function(a){return new Pl(a)});
function Qe(a,c,d){var e=a.length;d=1<d?d:2;void 0===c&&(2<d?c=a.slice():c=Array(e));for(var f=0;f<e;f+=d)c[f]=6378137*Math.PI*a[f]/180,c[f+1]=6378137*Math.log(Math.tan(Math.PI*(a[f+1]+90)/360));return c}function Re(a,c,d){var e=a.length;d=1<d?d:2;void 0===c&&(2<d?c=a.slice():c=Array(e));for(var f=0;f<e;f+=d)c[f]=180*a[f]/(6378137*Math.PI),c[f+1]=360*Math.atan(Math.exp(a[f+1]/6378137))/Math.PI-90;return c};function Tl(a,c){Ce.call(this,{code:a,units:"degrees",extent:Ul,axisOrientation:c,global:!0,worldExtent:Ul})}w(Tl,Ce);Tl.prototype.getPointResolution=function(a){return a};
var Ul=[-180,-90,180,90],Se=[new Tl("CRS:84"),new Tl("EPSG:4326","neu"),new Tl("urn:ogc:def:crs:EPSG::4326","neu"),new Tl("urn:ogc:def:crs:EPSG:6.6:4326","neu"),new Tl("urn:ogc:def:crs:OGC:1.3:CRS84"),new Tl("urn:ogc:def:crs:OGC:2:84"),new Tl("http://www.opengis.net/gml/srs/epsg.xml#4326","neu"),new Tl("urn:x-ogc:def:crs:EPSG:4326","neu")];function Vl(){Fe(Pe);Fe(Se);Oe()};function Wl(a){ik.call(this,a?a:{})}w(Wl,ik);function E(a){a=a?a:{};var c=Ub(a);delete c.preload;delete c.useInterimTilesOnError;ik.call(this,c);this.f(void 0!==a.preload?a.preload:0);this.g(void 0!==a.useInterimTilesOnError?a.useInterimTilesOnError:!0)}w(E,ik);E.prototype.a=function(){return this.get("preload")};E.prototype.f=function(a){this.set("preload",a)};E.prototype.c=function(){return this.get("useInterimTilesOnError")};E.prototype.g=function(a){this.set("useInterimTilesOnError",a)};var Xl=[0,0,0,1],Yl=[],Zl=[0,0,0,1];function $l(a){a=a||{};this.b=void 0!==a.color?a.color:null;this.a=void 0}$l.prototype.c=function(){return this.b};$l.prototype.f=function(a){this.b=a;this.a=void 0};$l.prototype.xb=function(){void 0===this.a&&(this.a="f"+(this.b?Cg(this.b):"-"));return this.a};function am(){this.a=-1};function bm(){this.a=-1;this.a=64;this.b=Array(4);this.g=Array(this.a);this.f=this.c=0;this.reset()}w(bm,am);bm.prototype.reset=function(){this.b[0]=1732584193;this.b[1]=4023233417;this.b[2]=2562383102;this.b[3]=271733878;this.f=this.c=0};
function cm(a,c,d){d||(d=0);var e=Array(16);if(ia(c))for(var f=0;16>f;++f)e[f]=c.charCodeAt(d++)|c.charCodeAt(d++)<<8|c.charCodeAt(d++)<<16|c.charCodeAt(d++)<<24;else for(f=0;16>f;++f)e[f]=c[d++]|c[d++]<<8|c[d++]<<16|c[d++]<<24;c=a.b[0];d=a.b[1];var f=a.b[2],g=a.b[3],h=0,h=c+(g^d&(f^g))+e[0]+3614090360&4294967295;c=d+(h<<7&4294967295|h>>>25);h=g+(f^c&(d^f))+e[1]+3905402710&4294967295;g=c+(h<<12&4294967295|h>>>20);h=f+(d^g&(c^d))+e[2]+606105819&4294967295;f=g+(h<<17&4294967295|h>>>15);h=d+(c^f&(g^
c))+e[3]+3250441966&4294967295;d=f+(h<<22&4294967295|h>>>10);h=c+(g^d&(f^g))+e[4]+4118548399&4294967295;c=d+(h<<7&4294967295|h>>>25);h=g+(f^c&(d^f))+e[5]+1200080426&4294967295;g=c+(h<<12&4294967295|h>>>20);h=f+(d^g&(c^d))+e[6]+2821735955&4294967295;f=g+(h<<17&4294967295|h>>>15);h=d+(c^f&(g^c))+e[7]+4249261313&4294967295;d=f+(h<<22&4294967295|h>>>10);h=c+(g^d&(f^g))+e[8]+1770035416&4294967295;c=d+(h<<7&4294967295|h>>>25);h=g+(f^c&(d^f))+e[9]+2336552879&4294967295;g=c+(h<<12&4294967295|h>>>20);h=f+
(d^g&(c^d))+e[10]+4294925233&4294967295;f=g+(h<<17&4294967295|h>>>15);h=d+(c^f&(g^c))+e[11]+2304563134&4294967295;d=f+(h<<22&4294967295|h>>>10);h=c+(g^d&(f^g))+e[12]+1804603682&4294967295;c=d+(h<<7&4294967295|h>>>25);h=g+(f^c&(d^f))+e[13]+4254626195&4294967295;g=c+(h<<12&4294967295|h>>>20);h=f+(d^g&(c^d))+e[14]+2792965006&4294967295;f=g+(h<<17&4294967295|h>>>15);h=d+(c^f&(g^c))+e[15]+1236535329&4294967295;d=f+(h<<22&4294967295|h>>>10);h=c+(f^g&(d^f))+e[1]+4129170786&4294967295;c=d+(h<<5&4294967295|
h>>>27);h=g+(d^f&(c^d))+e[6]+3225465664&4294967295;g=c+(h<<9&4294967295|h>>>23);h=f+(c^d&(g^c))+e[11]+643717713&4294967295;f=g+(h<<14&4294967295|h>>>18);h=d+(g^c&(f^g))+e[0]+3921069994&4294967295;d=f+(h<<20&4294967295|h>>>12);h=c+(f^g&(d^f))+e[5]+3593408605&4294967295;c=d+(h<<5&4294967295|h>>>27);h=g+(d^f&(c^d))+e[10]+38016083&4294967295;g=c+(h<<9&4294967295|h>>>23);h=f+(c^d&(g^c))+e[15]+3634488961&4294967295;f=g+(h<<14&4294967295|h>>>18);h=d+(g^c&(f^g))+e[4]+3889429448&4294967295;d=f+(h<<20&4294967295|
h>>>12);h=c+(f^g&(d^f))+e[9]+568446438&4294967295;c=d+(h<<5&4294967295|h>>>27);h=g+(d^f&(c^d))+e[14]+3275163606&4294967295;g=c+(h<<9&4294967295|h>>>23);h=f+(c^d&(g^c))+e[3]+4107603335&4294967295;f=g+(h<<14&4294967295|h>>>18);h=d+(g^c&(f^g))+e[8]+1163531501&4294967295;d=f+(h<<20&4294967295|h>>>12);h=c+(f^g&(d^f))+e[13]+2850285829&4294967295;c=d+(h<<5&4294967295|h>>>27);h=g+(d^f&(c^d))+e[2]+4243563512&4294967295;g=c+(h<<9&4294967295|h>>>23);h=f+(c^d&(g^c))+e[7]+1735328473&4294967295;f=g+(h<<14&4294967295|
h>>>18);h=d+(g^c&(f^g))+e[12]+2368359562&4294967295;d=f+(h<<20&4294967295|h>>>12);h=c+(d^f^g)+e[5]+4294588738&4294967295;c=d+(h<<4&4294967295|h>>>28);h=g+(c^d^f)+e[8]+2272392833&4294967295;g=c+(h<<11&4294967295|h>>>21);h=f+(g^c^d)+e[11]+1839030562&4294967295;f=g+(h<<16&4294967295|h>>>16);h=d+(f^g^c)+e[14]+4259657740&4294967295;d=f+(h<<23&4294967295|h>>>9);h=c+(d^f^g)+e[1]+2763975236&4294967295;c=d+(h<<4&4294967295|h>>>28);h=g+(c^d^f)+e[4]+1272893353&4294967295;g=c+(h<<11&4294967295|h>>>21);h=f+(g^
c^d)+e[7]+4139469664&4294967295;f=g+(h<<16&4294967295|h>>>16);h=d+(f^g^c)+e[10]+3200236656&4294967295;d=f+(h<<23&4294967295|h>>>9);h=c+(d^f^g)+e[13]+681279174&4294967295;c=d+(h<<4&4294967295|h>>>28);h=g+(c^d^f)+e[0]+3936430074&4294967295;g=c+(h<<11&4294967295|h>>>21);h=f+(g^c^d)+e[3]+3572445317&4294967295;f=g+(h<<16&4294967295|h>>>16);h=d+(f^g^c)+e[6]+76029189&4294967295;d=f+(h<<23&4294967295|h>>>9);h=c+(d^f^g)+e[9]+3654602809&4294967295;c=d+(h<<4&4294967295|h>>>28);h=g+(c^d^f)+e[12]+3873151461&4294967295;
g=c+(h<<11&4294967295|h>>>21);h=f+(g^c^d)+e[15]+530742520&4294967295;f=g+(h<<16&4294967295|h>>>16);h=d+(f^g^c)+e[2]+3299628645&4294967295;d=f+(h<<23&4294967295|h>>>9);h=c+(f^(d|~g))+e[0]+4096336452&4294967295;c=d+(h<<6&4294967295|h>>>26);h=g+(d^(c|~f))+e[7]+1126891415&4294967295;g=c+(h<<10&4294967295|h>>>22);h=f+(c^(g|~d))+e[14]+2878612391&4294967295;f=g+(h<<15&4294967295|h>>>17);h=d+(g^(f|~c))+e[5]+4237533241&4294967295;d=f+(h<<21&4294967295|h>>>11);h=c+(f^(d|~g))+e[12]+1700485571&4294967295;c=d+
(h<<6&4294967295|h>>>26);h=g+(d^(c|~f))+e[3]+2399980690&4294967295;g=c+(h<<10&4294967295|h>>>22);h=f+(c^(g|~d))+e[10]+4293915773&4294967295;f=g+(h<<15&4294967295|h>>>17);h=d+(g^(f|~c))+e[1]+2240044497&4294967295;d=f+(h<<21&4294967295|h>>>11);h=c+(f^(d|~g))+e[8]+1873313359&4294967295;c=d+(h<<6&4294967295|h>>>26);h=g+(d^(c|~f))+e[15]+4264355552&4294967295;g=c+(h<<10&4294967295|h>>>22);h=f+(c^(g|~d))+e[6]+2734768916&4294967295;f=g+(h<<15&4294967295|h>>>17);h=d+(g^(f|~c))+e[13]+1309151649&4294967295;
d=f+(h<<21&4294967295|h>>>11);h=c+(f^(d|~g))+e[4]+4149444226&4294967295;c=d+(h<<6&4294967295|h>>>26);h=g+(d^(c|~f))+e[11]+3174756917&4294967295;g=c+(h<<10&4294967295|h>>>22);h=f+(c^(g|~d))+e[2]+718787259&4294967295;f=g+(h<<15&4294967295|h>>>17);h=d+(g^(f|~c))+e[9]+3951481745&4294967295;a.b[0]=a.b[0]+c&4294967295;a.b[1]=a.b[1]+(f+(h<<21&4294967295|h>>>11))&4294967295;a.b[2]=a.b[2]+f&4294967295;a.b[3]=a.b[3]+g&4294967295}
function dm(a,c){var d;ca(d)||(d=c.length);for(var e=d-a.a,f=a.g,g=a.c,h=0;h<d;){if(0==g)for(;h<=e;)cm(a,c,h),h+=a.a;if(ia(c))for(;h<d;){if(f[g++]=c.charCodeAt(h++),g==a.a){cm(a,f);g=0;break}}else for(;h<d;)if(f[g++]=c[h++],g==a.a){cm(a,f);g=0;break}}a.c=g;a.f+=d};function em(a){a=a||{};this.b=void 0!==a.color?a.color:null;this.f=a.lineCap;this.c=void 0!==a.lineDash?a.lineDash:null;this.g=a.lineJoin;this.i=a.miterLimit;this.a=a.width;this.j=void 0}l=em.prototype;l.Fm=function(){return this.b};l.cj=function(){return this.f};l.Gm=function(){return this.c};l.dj=function(){return this.g};l.ij=function(){return this.i};l.Hm=function(){return this.a};l.Im=function(a){this.b=a;this.j=void 0};l.bo=function(a){this.f=a;this.j=void 0};
l.Jm=function(a){this.c=a;this.j=void 0};l.co=function(a){this.g=a;this.j=void 0};l.eo=function(a){this.i=a;this.j=void 0};l.lo=function(a){this.a=a;this.j=void 0};
l.xb=function(){if(void 0===this.j){var a="s"+(this.b?Cg(this.b):"-")+","+(void 0!==this.f?this.f.toString():"-")+","+(this.c?this.c.toString():"-")+","+(void 0!==this.g?this.g:"-")+","+(void 0!==this.i?this.i.toString():"-")+","+(void 0!==this.a?this.a.toString():"-"),c=new bm;dm(c,a);var d=Array((56>c.c?c.a:2*c.a)-c.c);d[0]=128;for(a=1;a<d.length-8;++a)d[a]=0;for(var e=8*c.f,a=d.length-8;a<d.length;++a)d[a]=e&255,e/=256;dm(c,d);d=Array(16);for(a=e=0;4>a;++a)for(var f=0;32>f;f+=8)d[e++]=c.b[a]>>>
f&255;if(8192>=d.length)c=String.fromCharCode.apply(null,d);else for(c="",a=0;a<d.length;a+=8192)c+=String.fromCharCode.apply(null,mb(d,a,a+8192));this.j=c}return this.j};function fm(a){a=a||{};this.i=this.b=this.g=null;this.f=void 0!==a.fill?a.fill:null;this.a=void 0!==a.stroke?a.stroke:null;this.c=a.radius;this.B=[0,0];this.l=this.fa=this.j=null;var c=a.atlasManager,d,e=null,f,g=0;this.a&&(f=Cg(this.a.b),g=this.a.a,void 0===g&&(g=1),e=this.a.c,bj||(e=null));var h=2*(this.c+g)+1;f={strokeStyle:f,rd:g,size:h,lineDash:e};void 0===c?(this.b=Rg("CANVAS"),this.b.height=h,this.b.width=h,d=h=this.b.width,c=this.b.getContext("2d"),this.Rg(f,c,0,0),this.f?this.i=this.b:(c=
this.i=Rg("CANVAS"),c.height=f.size,c.width=f.size,c=c.getContext("2d"),this.Qg(f,c,0,0))):(h=Math.round(h),(e=!this.f)&&(d=sa(this.Qg,this,f)),g=this.xb(),f=c.add(g,h,h,sa(this.Rg,this,f),d),this.b=f.image,this.B=[f.offsetX,f.offsetY],d=f.image.width,this.i=e?f.mg:this.b);this.j=[h/2,h/2];this.fa=[h,h];this.l=[d,d];zk.call(this,{opacity:1,rotateWithView:!1,rotation:0,scale:1,snapToPixel:void 0!==a.snapToPixel?a.snapToPixel:!0})}w(fm,zk);l=fm.prototype;l.Gb=function(){return this.j};l.wm=function(){return this.f};
l.je=function(){return this.i};l.Pb=function(){return this.b};l.md=function(){return 2};l.Kd=function(){return this.l};l.wa=function(){return this.B};l.xm=function(){return this.c};l.rb=function(){return this.fa};l.ym=function(){return this.a};l.ff=xa;l.load=xa;l.Ff=xa;
l.Rg=function(a,c,d,e){c.setTransform(1,0,0,1,0,0);c.translate(d,e);c.beginPath();c.arc(a.size/2,a.size/2,this.c,0,2*Math.PI,!0);this.f&&(c.fillStyle=Cg(this.f.b),c.fill());this.a&&(c.strokeStyle=a.strokeStyle,c.lineWidth=a.rd,a.lineDash&&c.setLineDash(a.lineDash),c.stroke());c.closePath()};
l.Qg=function(a,c,d,e){c.setTransform(1,0,0,1,0,0);c.translate(d,e);c.beginPath();c.arc(a.size/2,a.size/2,this.c,0,2*Math.PI,!0);c.fillStyle=Cg(Xl);c.fill();this.a&&(c.strokeStyle=a.strokeStyle,c.lineWidth=a.rd,a.lineDash&&c.setLineDash(a.lineDash),c.stroke());c.closePath()};l.xb=function(){var a=this.a?this.a.xb():"-",c=this.f?this.f.xb():"-";this.g&&a==this.g[1]&&c==this.g[2]&&this.c==this.g[3]||(this.g=["c"+a+c+(void 0!==this.c?this.c.toString():"-"),a,c,this.c]);return this.g[0]};function gm(a){a=a||{};this.j=null;this.f=hm;void 0!==a.geometry&&this.Ug(a.geometry);this.g=void 0!==a.fill?a.fill:null;this.i=void 0!==a.image?a.image:null;this.c=void 0!==a.stroke?a.stroke:null;this.a=void 0!==a.text?a.text:null;this.b=a.zIndex}l=gm.prototype;l.Y=function(){return this.j};l.Yi=function(){return this.f};l.Km=function(){return this.g};l.Lm=function(){return this.i};l.Mm=function(){return this.c};l.Nm=function(){return this.a};l.Om=function(){return this.b};
l.Ug=function(a){ka(a)?this.f=a:ia(a)?this.f=function(c){return c.get(a)}:a?void 0!==a&&(this.f=function(){return a}):this.f=hm;this.j=a};l.Pm=function(a){this.b=a};function im(a){if(!ka(a)){var c;c=ga(a)?a:[a];a=function(){return c}}return a}var jm=null;function km(){if(!jm){var a=new $l({color:"rgba(255,255,255,0.4)"}),c=new em({color:"#3399CC",width:1.25});jm=[new gm({image:new fm({fill:a,stroke:c,radius:5}),fill:a,stroke:c})]}return jm}
function lm(){var a={},c=[255,255,255,1],d=[0,153,255,1];a.Polygon=[new gm({fill:new $l({color:[255,255,255,.5]})})];a.MultiPolygon=a.Polygon;a.LineString=[new gm({stroke:new em({color:c,width:5})}),new gm({stroke:new em({color:d,width:3})})];a.MultiLineString=a.LineString;a.Circle=a.Polygon.concat(a.LineString);a.Point=[new gm({image:new fm({radius:6,fill:new $l({color:d}),stroke:new em({color:c,width:1.5})}),zIndex:Infinity})];a.MultiPoint=a.Point;a.GeometryCollection=a.Polygon.concat(a.LineString,
a.Point);return a}function hm(a){return a.Y()};function G(a){a=a?a:{};var c=Ub(a);delete c.style;delete c.renderBuffer;delete c.updateWhileAnimating;delete c.updateWhileInteracting;ik.call(this,c);this.a=void 0!==a.renderBuffer?a.renderBuffer:100;this.v=null;this.c=void 0;this.g(a.style);this.C=void 0!==a.updateWhileAnimating?a.updateWhileAnimating:!1;this.P=void 0!==a.updateWhileInteracting?a.updateWhileInteracting:!1}w(G,ik);G.prototype.T=function(){return this.v};G.prototype.ea=function(){return this.c};
G.prototype.g=function(a){this.v=void 0!==a?a:km;this.c=null===a?void 0:im(this.v);this.s()};function mm(a,c,d,e,f){this.B={};this.c=a;this.P=c;this.g=d;this.ka=e;this.Pc=f;this.i=this.b=this.a=this.na=this.Ta=this.da=null;this.sa=this.ma=this.A=this.ea=this.T=this.H=0;this.Da=!1;this.j=this.sb=0;this.tb=!1;this.V=0;this.f="";this.D=this.fa=this.pc=this.xd=0;this.ca=this.v=this.l=null;this.C=[];this.qc=Dd()}
function nm(a,c,d){if(a.i){c=bf(c,0,d,2,a.ka,a.C);d=a.c;var e=a.qc,f=d.globalAlpha;1!=a.A&&(d.globalAlpha=f*a.A);var g=a.sb;a.Da&&(g+=a.Pc);var h,k;h=0;for(k=c.length;h<k;h+=2){var m=c[h]-a.H,n=c[h+1]-a.T;a.tb&&(m=m+.5|0,n=n+.5|0);if(0!==g||1!=a.j){var p=m+a.H,q=n+a.T;mk(e,p,q,a.j,a.j,g,-p,-q);d.setTransform(e[0],e[1],e[4],e[5],e[12],e[13])}d.drawImage(a.i,a.ma,a.sa,a.V,a.ea,m,n,a.V,a.ea)}0===g&&1==a.j||d.setTransform(1,0,0,1,0,0);1!=a.A&&(d.globalAlpha=f)}}
function om(a,c,d,e){var f=0;if(a.ca&&""!==a.f){a.l&&pm(a,a.l);a.v&&qm(a,a.v);var g=a.ca,h=a.c,k=a.na;k?(k.font!=g.font&&(k.font=h.font=g.font),k.textAlign!=g.textAlign&&(k.textAlign=h.textAlign=g.textAlign),k.textBaseline!=g.textBaseline&&(k.textBaseline=h.textBaseline=g.textBaseline)):(h.font=g.font,h.textAlign=g.textAlign,h.textBaseline=g.textBaseline,a.na={font:g.font,textAlign:g.textAlign,textBaseline:g.textBaseline});c=bf(c,f,d,e,a.ka,a.C);for(g=a.c;f<d;f+=e){h=c[f]+a.xd;k=c[f+1]+a.pc;if(0!==
a.fa||1!=a.D){var m=mk(a.qc,h,k,a.D,a.D,a.fa,-h,-k);g.setTransform(m[0],m[1],m[4],m[5],m[12],m[13])}a.v&&g.strokeText(a.f,h,k);a.l&&g.fillText(a.f,h,k)}0===a.fa&&1==a.D||g.setTransform(1,0,0,1,0,0)}}function rm(a,c,d,e,f,g){var h=a.c;a=bf(c,d,e,f,a.ka,a.C);h.moveTo(a[0],a[1]);for(c=2;c<a.length;c+=2)h.lineTo(a[c],a[c+1]);g&&h.lineTo(a[0],a[1]);return e}function sm(a,c,d,e,f){var g=a.c,h,k;h=0;for(k=e.length;h<k;++h)d=rm(a,c,d,e[h],f,!0),g.closePath();return d}l=mm.prototype;
l.ad=function(a,c){var d=a.toString(),e=this.B[d];void 0!==e?e.push(c):this.B[d]=[c]};l.tc=function(a){if(oe(this.g,a.J())){if(this.a||this.b){this.a&&pm(this,this.a);this.b&&qm(this,this.b);var c;c=(c=a.o)?bf(c,0,c.length,a.I,this.ka,this.C):null;var d=c[2]-c[0],e=c[3]-c[1],d=Math.sqrt(d*d+e*e),e=this.c;e.beginPath();e.arc(c[0],c[1],d,0,2*Math.PI);this.a&&e.fill();this.b&&e.stroke()}""!==this.f&&om(this,a.hd(),2,2)}};
l.Re=function(a,c){var d=(0,c.f)(a);if(d&&oe(this.g,d.J())){var e=c.b;void 0===e&&(e=0);this.ad(e,function(a){a.Qa(c.g,c.c);a.ib(c.i);a.Ra(c.a);um[d.Z()].call(a,d,null)})}};l.Fd=function(a,c){var d=a.f,e,f;e=0;for(f=d.length;e<f;++e){var g=d[e];um[g.Z()].call(this,g,c)}};l.vb=function(a){var c=a.o;a=a.I;this.i&&nm(this,c,c.length);""!==this.f&&om(this,c,c.length,a)};l.ub=function(a){var c=a.o;a=a.I;this.i&&nm(this,c,c.length);""!==this.f&&om(this,c,c.length,a)};
l.Eb=function(a){if(oe(this.g,a.J())){if(this.b){qm(this,this.b);var c=this.c,d=a.o;c.beginPath();rm(this,d,0,d.length,a.I,!1);c.stroke()}""!==this.f&&(a=vm(a),om(this,a,2,2))}};l.uc=function(a){var c=a.J();if(oe(this.g,c)){if(this.b){qm(this,this.b);var c=this.c,d=a.o,e=0,f=a.c,g=a.I;c.beginPath();var h,k;h=0;for(k=f.length;h<k;++h)e=rm(this,d,e,f[h],g,!1);c.stroke()}""!==this.f&&(a=wm(a),om(this,a,a.length,2))}};
l.wc=function(a){if(oe(this.g,a.J())){if(this.b||this.a){this.a&&pm(this,this.a);this.b&&qm(this,this.b);var c=this.c;c.beginPath();sm(this,Kf(a),0,a.c,a.I);this.a&&c.fill();this.b&&c.stroke()}""!==this.f&&(a=Lf(a),om(this,a,2,2))}};
l.vc=function(a){if(oe(this.g,a.J())){if(this.b||this.a){this.a&&pm(this,this.a);this.b&&qm(this,this.b);var c=this.c,d=xm(a),e=0,f=a.c,g=a.I,h,k;h=0;for(k=f.length;h<k;++h){var m=f[h];c.beginPath();e=sm(this,d,e,m,g);this.a&&c.fill();this.b&&c.stroke()}}""!==this.f&&(a=ym(a),om(this,a,a.length,2))}};function zm(a){var c=Object.keys(a.B).map(Number);nb(c);var d,e,f,g,h;d=0;for(e=c.length;d<e;++d)for(f=a.B[c[d].toString()],g=0,h=f.length;g<h;++g)f[g](a)}
function pm(a,c){var d=a.c,e=a.da;e?e.fillStyle!=c.fillStyle&&(e.fillStyle=d.fillStyle=c.fillStyle):(d.fillStyle=c.fillStyle,a.da={fillStyle:c.fillStyle})}
function qm(a,c){var d=a.c,e=a.Ta;e?(e.lineCap!=c.lineCap&&(e.lineCap=d.lineCap=c.lineCap),bj&&!rb(e.lineDash,c.lineDash)&&d.setLineDash(e.lineDash=c.lineDash),e.lineJoin!=c.lineJoin&&(e.lineJoin=d.lineJoin=c.lineJoin),e.lineWidth!=c.lineWidth&&(e.lineWidth=d.lineWidth=c.lineWidth),e.miterLimit!=c.miterLimit&&(e.miterLimit=d.miterLimit=c.miterLimit),e.strokeStyle!=c.strokeStyle&&(e.strokeStyle=d.strokeStyle=c.strokeStyle)):(d.lineCap=c.lineCap,bj&&d.setLineDash(c.lineDash),d.lineJoin=c.lineJoin,d.lineWidth=
c.lineWidth,d.miterLimit=c.miterLimit,d.strokeStyle=c.strokeStyle,a.Ta={lineCap:c.lineCap,lineDash:c.lineDash,lineJoin:c.lineJoin,lineWidth:c.lineWidth,miterLimit:c.miterLimit,strokeStyle:c.strokeStyle})}
l.Qa=function(a,c){if(a){var d=a.b;this.a={fillStyle:Cg(d?d:Xl)}}else this.a=null;if(c){var d=c.b,e=c.f,f=c.c,g=c.g,h=c.a,k=c.i;this.b={lineCap:void 0!==e?e:"round",lineDash:f?f:Yl,lineJoin:void 0!==g?g:"round",lineWidth:this.P*(void 0!==h?h:1),miterLimit:void 0!==k?k:10,strokeStyle:Cg(d?d:Zl)}}else this.b=null};
l.ib=function(a){if(a){var c=a.Gb(),d=a.Pb(1),e=a.wa(),f=a.rb();this.H=c[0];this.T=c[1];this.ea=f[1];this.i=d;this.A=a.A;this.ma=e[0];this.sa=e[1];this.Da=a.C;this.sb=a.D;this.j=a.v;this.tb=a.P;this.V=f[0]}else this.i=null};
l.Ra=function(a){if(a){var c=a.b;c?(c=c.b,this.l={fillStyle:Cg(c?c:Xl)}):this.l=null;var d=a.i;if(d){var c=d.b,e=d.f,f=d.c,g=d.g,h=d.a,d=d.i;this.v={lineCap:void 0!==e?e:"round",lineDash:f?f:Yl,lineJoin:void 0!==g?g:"round",lineWidth:void 0!==h?h:1,miterLimit:void 0!==d?d:10,strokeStyle:Cg(c?c:Zl)}}else this.v=null;var c=a.f,e=a.D,f=a.v,g=a.g,h=a.a,d=a.c,k=a.j;a=a.l;this.ca={font:void 0!==c?c:"10px sans-serif",textAlign:void 0!==k?k:"center",textBaseline:void 0!==a?a:"middle"};this.f=void 0!==d?d:
"";this.xd=void 0!==e?this.P*e:0;this.pc=void 0!==f?this.P*f:0;this.fa=void 0!==g?g:0;this.D=this.P*(void 0!==h?h:1)}else this.f=""};var um={Point:mm.prototype.vb,LineString:mm.prototype.Eb,Polygon:mm.prototype.wc,MultiPoint:mm.prototype.ub,MultiLineString:mm.prototype.uc,MultiPolygon:mm.prototype.vc,GeometryCollection:mm.prototype.Fd,Circle:mm.prototype.tc};function Am(a){pk.call(this,a);this.H=Dd()}w(Am,pk);
Am.prototype.A=function(a,c,d){Bm(this,"precompose",d,a,void 0);var e=this.ld();if(e){var f=c.extent,g=void 0!==f;if(g){var h=a.pixelRatio,k=ge(f),m=fe(f),n=ee(f),f=de(f);ok(a.coordinateToPixelMatrix,k,k);ok(a.coordinateToPixelMatrix,m,m);ok(a.coordinateToPixelMatrix,n,n);ok(a.coordinateToPixelMatrix,f,f);d.save();d.beginPath();d.moveTo(k[0]*h,k[1]*h);d.lineTo(m[0]*h,m[1]*h);d.lineTo(n[0]*h,n[1]*h);d.lineTo(f[0]*h,f[1]*h);d.clip()}h=this.$e();k=d.globalAlpha;d.globalAlpha=c.opacity;0===a.viewState.rotation?
d.drawImage(e,0,0,+e.width,+e.height,Math.round(h[12]),Math.round(h[13]),Math.round(e.width*h[0]),Math.round(e.height*h[5])):(d.setTransform(h[0],h[1],h[4],h[5],h[12],h[13]),d.drawImage(e,0,0),d.setTransform(1,0,0,1,0,0));d.globalAlpha=k;g&&d.restore()}Bm(this,"postcompose",d,a,void 0)};function Bm(a,c,d,e,f){var g=a.a;ed(g,c)&&(a=void 0!==f?f:Cm(a,e,0),a=new mm(d,e.pixelRatio,e.extent,a,e.viewState.rotation),g.u(new hk(c,g,a,e,d,null)),zm(a))}
function Cm(a,c,d){var e=c.viewState,f=c.pixelRatio;return mk(a.H,f*c.size[0]/2,f*c.size[1]/2,f/e.resolution,-f/e.resolution,-e.rotation,-e.center[0]+d,-e.center[1])}function Dm(a,c){var d=[0,0];ok(c,a,d);return d}
var Em=function(){var a=null,c=null;return function(d){if(!a){a=Ti(1,1);c=a.createImageData(1,1);var e=c.data;e[0]=42;e[1]=84;e[2]=126;e[3]=255}var e=a.canvas,f=d[0]<=e.width&&d[1]<=e.height;f||(e.width=d[0],e.height=d[1],e=d[0]-1,d=d[1]-1,a.putImageData(c,e,d),d=a.getImageData(e,d,1,1),f=rb(c.data,d.data));return f}}();var Fm=["Polygon","LineString","Image","Text"];function Gm(a,c,d){this.na=a;this.V=c;this.f=null;this.g=0;this.resolution=d;this.T=this.H=null;this.a=[];this.coordinates=[];this.da=Dd();this.b=[];this.ca=[];this.Ta=Dd()}w(Gm,gk);
function Hm(a,c,d,e,f,g){var h=a.coordinates.length,k=a.Ve(),m=[c[d],c[d+1]],n=[NaN,NaN],p=!0,q,r,t;for(q=d+f;q<e;q+=f)n[0]=c[q],n[1]=c[q+1],t=Yd(k,n),t!==r?(p&&(a.coordinates[h++]=m[0],a.coordinates[h++]=m[1]),a.coordinates[h++]=n[0],a.coordinates[h++]=n[1],p=!1):1===t?(a.coordinates[h++]=n[0],a.coordinates[h++]=n[1],p=!1):p=!0,m[0]=n[0],m[1]=n[1],r=t;q===d+f&&(a.coordinates[h++]=m[0],a.coordinates[h++]=m[1]);g&&(a.coordinates[h++]=c[d],a.coordinates[h++]=c[d+1]);return h}
function Im(a,c){a.H=[0,c,0];a.a.push(a.H);a.T=[0,c,0];a.b.push(a.T)}
function Jm(a,c,d,e,f,g,h,k,m){var n;nk(e,a.da)?n=a.ca:(n=bf(a.coordinates,0,a.coordinates.length,2,e,a.ca),Gd(a.da,e));e=0;var p=h.length,q=0,r;for(a=a.Ta;e<p;){var t=h[e],y,A,F,z;switch(t[0]){case 0:q=t[1];r=v(q).toString();void 0===g[r]&&q.Y()?void 0===m||oe(m,q.Y().J())?++e:e=t[2]:e=t[2];break;case 1:c.beginPath();++e;break;case 2:q=t[1];r=n[q];var x=n[q+1],M=n[q+2]-r,q=n[q+3]-x;c.arc(r,x,Math.sqrt(M*M+q*q),0,2*Math.PI,!0);++e;break;case 3:c.closePath();++e;break;case 4:q=t[1];r=t[2];y=t[3];F=
t[4]*d;var L=t[5]*d,H=t[6];A=t[7];var J=t[8],ra=t[9],x=t[11],M=t[12],Ga=t[13],K=t[14];for(t[10]&&(x+=f);q<r;q+=2){t=n[q]-F;z=n[q+1]-L;Ga&&(t=t+.5|0,z=z+.5|0);if(1!=M||0!==x){var oa=t+F,Oa=z+L;mk(a,oa,Oa,M,M,x,-oa,-Oa);c.setTransform(a[0],a[1],a[4],a[5],a[12],a[13])}oa=c.globalAlpha;1!=A&&(c.globalAlpha=oa*A);c.drawImage(y,J,ra,K,H,t,z,K*d,H*d);1!=A&&(c.globalAlpha=oa);1==M&&0===x||c.setTransform(1,0,0,1,0,0)}++e;break;case 5:q=t[1];r=t[2];F=t[3];L=t[4]*d;H=t[5]*d;x=t[6];M=t[7]*d;y=t[8];for(A=t[9];q<
r;q+=2){t=n[q]+L;z=n[q+1]+H;if(1!=M||0!==x)mk(a,t,z,M,M,x,-t,-z),c.setTransform(a[0],a[1],a[4],a[5],a[12],a[13]);A&&c.strokeText(F,t,z);y&&c.fillText(F,t,z);1==M&&0===x||c.setTransform(1,0,0,1,0,0)}++e;break;case 6:if(void 0!==k&&(q=t[1],q=k(q)))return q;++e;break;case 7:c.fill();++e;break;case 8:q=t[1];r=t[2];c.moveTo(n[q],n[q+1]);for(q+=2;q<r;q+=2)c.lineTo(n[q],n[q+1]);++e;break;case 9:c.fillStyle=t[1];++e;break;case 10:q=void 0!==t[7]?t[7]:!0;r=t[2];c.strokeStyle=t[1];c.lineWidth=q?r*d:r;c.lineCap=
t[3];c.lineJoin=t[4];c.miterLimit=t[5];bj&&c.setLineDash(t[6]);++e;break;case 11:c.font=t[1];c.textAlign=t[2];c.textBaseline=t[3];++e;break;case 12:c.stroke();++e;break;default:++e}}}function Km(a){var c=a.b;c.reverse();var d,e=c.length,f,g,h=-1;for(d=0;d<e;++d)if(f=c[d],g=f[0],6==g)h=d;else if(0==g){f[2]=d;f=a.b;for(g=d;h<g;){var k=f[h];f[h]=f[g];f[g]=k;++h;--g}h=-1}}function Lm(a,c){a.H[2]=a.a.length;a.H=null;a.T[2]=a.b.length;a.T=null;var d=[6,c];a.a.push(d);a.b.push(d)}Gm.prototype.fe=xa;
Gm.prototype.Ve=function(){return this.V};function Mm(a,c,d){Gm.call(this,a,c,d);this.l=this.ea=null;this.ka=this.fa=this.P=this.C=this.B=this.A=this.v=this.D=this.j=this.i=this.c=void 0}w(Mm,Gm);
Mm.prototype.vb=function(a,c){if(this.l){Im(this,c);var d=a.o,e=this.coordinates.length,d=Hm(this,d,0,d.length,a.I,!1);this.a.push([4,e,d,this.l,this.c,this.i,this.j,this.D,this.v,this.A,this.B,this.C,this.P,this.fa,this.ka]);this.b.push([4,e,d,this.ea,this.c,this.i,this.j,this.D,this.v,this.A,this.B,this.C,this.P,this.fa,this.ka]);Lm(this,c)}};
Mm.prototype.ub=function(a,c){if(this.l){Im(this,c);var d=a.o,e=this.coordinates.length,d=Hm(this,d,0,d.length,a.I,!1);this.a.push([4,e,d,this.l,this.c,this.i,this.j,this.D,this.v,this.A,this.B,this.C,this.P,this.fa,this.ka]);this.b.push([4,e,d,this.ea,this.c,this.i,this.j,this.D,this.v,this.A,this.B,this.C,this.P,this.fa,this.ka]);Lm(this,c)}};Mm.prototype.fe=function(){Km(this);this.i=this.c=void 0;this.l=this.ea=null;this.ka=this.fa=this.C=this.B=this.A=this.v=this.D=this.P=this.j=void 0};
Mm.prototype.ib=function(a){var c=a.Gb(),d=a.rb(),e=a.je(1),f=a.Pb(1),g=a.wa();this.c=c[0];this.i=c[1];this.ea=e;this.l=f;this.j=d[1];this.D=a.A;this.v=g[0];this.A=g[1];this.B=a.C;this.C=a.D;this.P=a.v;this.fa=a.P;this.ka=d[0]};function Nm(a,c,d){Gm.call(this,a,c,d);this.c={Zc:void 0,Uc:void 0,Vc:null,Wc:void 0,Xc:void 0,Yc:void 0,ef:0,strokeStyle:void 0,lineCap:void 0,lineDash:null,lineJoin:void 0,lineWidth:void 0,miterLimit:void 0}}w(Nm,Gm);
function Om(a,c,d,e,f){var g=a.coordinates.length;c=Hm(a,c,d,e,f,!1);g=[8,g,c];a.a.push(g);a.b.push(g);return e}l=Nm.prototype;l.Ve=function(){this.f||(this.f=Td(this.V),0<this.g&&Sd(this.f,this.resolution*(this.g+1)/2,this.f));return this.f};
function Pm(a){var c=a.c,d=c.strokeStyle,e=c.lineCap,f=c.lineDash,g=c.lineJoin,h=c.lineWidth,k=c.miterLimit;c.Zc==d&&c.Uc==e&&rb(c.Vc,f)&&c.Wc==g&&c.Xc==h&&c.Yc==k||(c.ef!=a.coordinates.length&&(a.a.push([12]),c.ef=a.coordinates.length),a.a.push([10,d,h,e,g,k,f],[1]),c.Zc=d,c.Uc=e,c.Vc=f,c.Wc=g,c.Xc=h,c.Yc=k)}
l.Eb=function(a,c){var d=this.c,e=d.lineWidth;void 0!==d.strokeStyle&&void 0!==e&&(Pm(this),Im(this,c),this.b.push([10,d.strokeStyle,d.lineWidth,d.lineCap,d.lineJoin,d.miterLimit,d.lineDash],[1]),d=a.o,Om(this,d,0,d.length,a.I),this.b.push([12]),Lm(this,c))};
l.uc=function(a,c){var d=this.c,e=d.lineWidth;if(void 0!==d.strokeStyle&&void 0!==e){Pm(this);Im(this,c);this.b.push([10,d.strokeStyle,d.lineWidth,d.lineCap,d.lineJoin,d.miterLimit,d.lineDash],[1]);var d=a.c,e=a.o,f=a.I,g=0,h,k;h=0;for(k=d.length;h<k;++h)g=Om(this,e,g,d[h],f);this.b.push([12]);Lm(this,c)}};l.fe=function(){this.c.ef!=this.coordinates.length&&this.a.push([12]);Km(this);this.c=null};
l.Qa=function(a,c){var d=c.b;this.c.strokeStyle=Cg(d?d:Zl);d=c.f;this.c.lineCap=void 0!==d?d:"round";d=c.c;this.c.lineDash=d?d:Yl;d=c.g;this.c.lineJoin=void 0!==d?d:"round";d=c.a;this.c.lineWidth=void 0!==d?d:1;d=c.i;this.c.miterLimit=void 0!==d?d:10;this.c.lineWidth>this.g&&(this.g=this.c.lineWidth,this.f=null)};
function Qm(a,c,d){Gm.call(this,a,c,d);this.c={Wf:void 0,Zc:void 0,Uc:void 0,Vc:null,Wc:void 0,Xc:void 0,Yc:void 0,fillStyle:void 0,strokeStyle:void 0,lineCap:void 0,lineDash:null,lineJoin:void 0,lineWidth:void 0,miterLimit:void 0}}w(Qm,Gm);
function Rm(a,c,d,e,f){var g=a.c,h=[1];a.a.push(h);a.b.push(h);var k,h=0;for(k=e.length;h<k;++h){var m=e[h],n=a.coordinates.length;d=Hm(a,c,d,m,f,!0);d=[8,n,d];n=[3];a.a.push(d,n);a.b.push(d,n);d=m}c=[7];a.b.push(c);void 0!==g.fillStyle&&a.a.push(c);void 0!==g.strokeStyle&&(g=[12],a.a.push(g),a.b.push(g));return d}l=Qm.prototype;
l.tc=function(a,c){var d=this.c,e=d.strokeStyle;if(void 0!==d.fillStyle||void 0!==e){Sm(this);Im(this,c);this.b.push([9,Cg(Xl)]);void 0!==d.strokeStyle&&this.b.push([10,d.strokeStyle,d.lineWidth,d.lineCap,d.lineJoin,d.miterLimit,d.lineDash]);var f=a.o,e=this.coordinates.length;Hm(this,f,0,f.length,a.I,!1);f=[1];e=[2,e];this.a.push(f,e);this.b.push(f,e);e=[7];this.b.push(e);void 0!==d.fillStyle&&this.a.push(e);void 0!==d.strokeStyle&&(d=[12],this.a.push(d),this.b.push(d));Lm(this,c)}};
l.wc=function(a,c){var d=this.c,e=d.strokeStyle;if(void 0!==d.fillStyle||void 0!==e)Sm(this),Im(this,c),this.b.push([9,Cg(Xl)]),void 0!==d.strokeStyle&&this.b.push([10,d.strokeStyle,d.lineWidth,d.lineCap,d.lineJoin,d.miterLimit,d.lineDash]),d=a.c,e=Kf(a),Rm(this,e,0,d,a.I),Lm(this,c)};
l.vc=function(a,c){var d=this.c,e=d.strokeStyle;if(void 0!==d.fillStyle||void 0!==e){Sm(this);Im(this,c);this.b.push([9,Cg(Xl)]);void 0!==d.strokeStyle&&this.b.push([10,d.strokeStyle,d.lineWidth,d.lineCap,d.lineJoin,d.miterLimit,d.lineDash]);var d=a.c,e=xm(a),f=a.I,g=0,h,k;h=0;for(k=d.length;h<k;++h)g=Rm(this,e,g,d[h],f);Lm(this,c)}};l.fe=function(){Km(this);this.c=null;var a=this.na;if(0!==a){var c=this.coordinates,d,e;d=0;for(e=c.length;d<e;++d)c[d]=a*Math.round(c[d]/a)}};
l.Ve=function(){this.f||(this.f=Td(this.V),0<this.g&&Sd(this.f,this.resolution*(this.g+1)/2,this.f));return this.f};
l.Qa=function(a,c){var d=this.c;if(a){var e=a.b;d.fillStyle=Cg(e?e:Xl)}else d.fillStyle=void 0;c?(e=c.b,d.strokeStyle=Cg(e?e:Zl),e=c.f,d.lineCap=void 0!==e?e:"round",e=c.c,d.lineDash=e?e.slice():Yl,e=c.g,d.lineJoin=void 0!==e?e:"round",e=c.a,d.lineWidth=void 0!==e?e:1,e=c.i,d.miterLimit=void 0!==e?e:10,d.lineWidth>this.g&&(this.g=d.lineWidth,this.f=null)):(d.strokeStyle=void 0,d.lineCap=void 0,d.lineDash=null,d.lineJoin=void 0,d.lineWidth=void 0,d.miterLimit=void 0)};
function Sm(a){var c=a.c,d=c.fillStyle,e=c.strokeStyle,f=c.lineCap,g=c.lineDash,h=c.lineJoin,k=c.lineWidth,m=c.miterLimit;void 0!==d&&c.Wf!=d&&(a.a.push([9,d]),c.Wf=c.fillStyle);void 0===e||c.Zc==e&&c.Uc==f&&c.Vc==g&&c.Wc==h&&c.Xc==k&&c.Yc==m||(a.a.push([10,e,k,f,h,m,g]),c.Zc=e,c.Uc=f,c.Vc=g,c.Wc=h,c.Xc=k,c.Yc=m)}function Tm(a,c,d){Gm.call(this,a,c,d);this.fa=this.P=this.C=null;this.l="";this.B=this.A=this.v=this.D=0;this.j=this.i=this.c=null}w(Tm,Gm);
Tm.prototype.wb=function(a,c,d,e,f,g){if(""!==this.l&&this.j&&(this.c||this.i)){if(this.c){f=this.c;var h=this.C;if(!h||h.fillStyle!=f.fillStyle){var k=[9,f.fillStyle];this.a.push(k);this.b.push(k);h?h.fillStyle=f.fillStyle:this.C={fillStyle:f.fillStyle}}}this.i&&(f=this.i,h=this.P,h&&h.lineCap==f.lineCap&&h.lineDash==f.lineDash&&h.lineJoin==f.lineJoin&&h.lineWidth==f.lineWidth&&h.miterLimit==f.miterLimit&&h.strokeStyle==f.strokeStyle||(k=[10,f.strokeStyle,f.lineWidth,f.lineCap,f.lineJoin,f.miterLimit,
f.lineDash,!1],this.a.push(k),this.b.push(k),h?(h.lineCap=f.lineCap,h.lineDash=f.lineDash,h.lineJoin=f.lineJoin,h.lineWidth=f.lineWidth,h.miterLimit=f.miterLimit,h.strokeStyle=f.strokeStyle):this.P={lineCap:f.lineCap,lineDash:f.lineDash,lineJoin:f.lineJoin,lineWidth:f.lineWidth,miterLimit:f.miterLimit,strokeStyle:f.strokeStyle}));f=this.j;h=this.fa;h&&h.font==f.font&&h.textAlign==f.textAlign&&h.textBaseline==f.textBaseline||(k=[11,f.font,f.textAlign,f.textBaseline],this.a.push(k),this.b.push(k),h?
(h.font=f.font,h.textAlign=f.textAlign,h.textBaseline=f.textBaseline):this.fa={font:f.font,textAlign:f.textAlign,textBaseline:f.textBaseline});Im(this,g);f=this.coordinates.length;a=Hm(this,a,c,d,e,!1);a=[5,f,a,this.l,this.D,this.v,this.A,this.B,!!this.c,!!this.i];this.a.push(a);this.b.push(a);Lm(this,g)}};
Tm.prototype.Ra=function(a){if(a){var c=a.b;c?(c=c.b,c=Cg(c?c:Xl),this.c?this.c.fillStyle=c:this.c={fillStyle:c}):this.c=null;var d=a.i;if(d){var c=d.b,e=d.f,f=d.c,g=d.g,h=d.a,d=d.i,e=void 0!==e?e:"round",f=f?f.slice():Yl,g=void 0!==g?g:"round",h=void 0!==h?h:1,d=void 0!==d?d:10,c=Cg(c?c:Zl);if(this.i){var k=this.i;k.lineCap=e;k.lineDash=f;k.lineJoin=g;k.lineWidth=h;k.miterLimit=d;k.strokeStyle=c}else this.i={lineCap:e,lineDash:f,lineJoin:g,lineWidth:h,miterLimit:d,strokeStyle:c}}else this.i=null;
var m=a.f,c=a.D,e=a.v,f=a.g,h=a.a,d=a.c,g=a.j,k=a.l;a=void 0!==m?m:"10px sans-serif";g=void 0!==g?g:"center";k=void 0!==k?k:"middle";this.j?(m=this.j,m.font=a,m.textAlign=g,m.textBaseline=k):this.j={font:a,textAlign:g,textBaseline:k};this.l=void 0!==d?d:"";this.D=void 0!==c?c:0;this.v=void 0!==e?e:0;this.A=void 0!==f?f:0;this.B=void 0!==h?h:1}else this.l=""};function Um(a,c,d,e){this.l=a;this.c=c;this.j=d;this.f=e;this.a={};this.g=Ti(1,1);this.i=Dd()}
function Vm(a){for(var c in a.a){var d=a.a[c],e;for(e in d)d[e].fe()}}function Wm(a,c,d,e,f,g){var h=a.i;mk(h,.5,.5,1/d,-1/d,-e,-c[0],-c[1]);var k=a.g;k.clearRect(0,0,1,1);var m;void 0!==a.f&&(m=Od(),Pd(m,c),Sd(m,d*a.f,m));return Xm(a,k,h,e,f,function(a){if(0<k.getImageData(0,0,1,1).data[3]){if(a=g(a))return a;k.clearRect(0,0,1,1)}},m)}
Um.prototype.b=function(a,c){var d=void 0!==a?a.toString():"0",e=this.a[d];void 0===e&&(e={},this.a[d]=e);d=e[c];void 0===d&&(d=new Ym[c](this.l,this.c,this.j),e[c]=d);return d};Um.prototype.Ba=function(){return Qb(this.a)};
function Zm(a,c,d,e,f,g){var h=Object.keys(a.a).map(Number);nb(h);var k=a.c,m=k[0],n=k[1],p=k[2],k=k[3],m=[m,n,m,k,p,k,p,n];bf(m,0,8,2,e,m);c.save();c.beginPath();c.moveTo(m[0],m[1]);c.lineTo(m[2],m[3]);c.lineTo(m[4],m[5]);c.lineTo(m[6],m[7]);c.closePath();c.clip();for(var q,r,m=0,n=h.length;m<n;++m)for(q=a.a[h[m].toString()],p=0,k=Fm.length;p<k;++p)r=q[Fm[p]],void 0!==r&&Jm(r,c,d,e,f,g,r.a,void 0);c.restore()}
function Xm(a,c,d,e,f,g,h){var k=Object.keys(a.a).map(Number);nb(k,function(a,c){return c-a});var m,n,p,q,r;m=0;for(n=k.length;m<n;++m)for(q=a.a[k[m].toString()],p=Fm.length-1;0<=p;--p)if(r=q[Fm[p]],void 0!==r&&(r=Jm(r,c,1,d,e,f,r.b,g,h)))return r}var Ym={Image:Mm,LineString:Nm,Polygon:Qm,Text:Tm};function $m(a,c,d){cf.call(this);this.Cf(a,c?c:0,d)}w($m,cf);l=$m.prototype;l.clone=function(){var a=new $m(null);ef(a,this.a,this.o.slice());a.s();return a};l.$a=function(a,c,d,e){var f=this.o;a-=f[0];var g=c-f[1];c=a*a+g*g;if(c<e){if(0===c)for(e=0;e<this.I;++e)d[e]=f[e];else for(e=this.mf()/Math.sqrt(c),d[0]=f[0]+e*a,d[1]=f[1]+e*g,e=2;e<this.I;++e)d[e]=f[e];d.length=this.I;return c}return e};l.bc=function(a,c){var d=this.o,e=a-d[0],d=c-d[1];return e*e+d*d<=an(this)};
l.hd=function(){return this.o.slice(0,this.I)};l.Cd=function(a){var c=this.o,d=c[this.I]-c[0];return Rd(c[0]-d,c[1]-d,c[0]+d,c[1]+d,a)};l.mf=function(){return Math.sqrt(an(this))};function an(a){var c=a.o[a.I]-a.o[0];a=a.o[a.I+1]-a.o[1];return c*c+a*a}l.Z=function(){return"Circle"};l.ya=function(a){var c=this.J();return oe(a,c)?(c=this.hd(),a[0]<=c[0]&&a[2]>=c[0]||a[1]<=c[1]&&a[3]>=c[1]?!0:ce(a,this.Pe,this)):!1};
l.gl=function(a){var c=this.I,d=a.slice();d[c]=d[0]+(this.o[c]-this.o[0]);var e;for(e=1;e<c;++e)d[c+e]=a[e];ef(this,this.a,d);this.s()};l.Cf=function(a,c,d){if(a){ff(this,d,a,0);this.o||(this.o=[]);d=this.o;a=of(d,a);d[a++]=d[0]+c;var e;c=1;for(e=this.I;c<e;++c)d[a++]=d[c];d.length=a}else ef(this,"XY",null);this.s()};l.hl=function(a){this.o[this.I]=this.o[0]+a;this.s()};function bn(a){af.call(this);this.f=a?a:null;cn(this)}w(bn,af);function dn(a){var c=[],d,e;d=0;for(e=a.length;d<e;++d)c.push(a[d].clone());return c}function en(a){var c,d;if(a.f)for(c=0,d=a.f.length;c<d;++c)Yc(a.f[c],"change",a.s,!1,a)}function cn(a){var c,d;if(a.f)for(c=0,d=a.f.length;c<d;++c)B(a.f[c],"change",a.s,!1,a)}l=bn.prototype;l.clone=function(){var a=new bn(null);a.rh(this.f);return a};
l.$a=function(a,c,d,e){if(e<Ud(this.J(),a,c))return e;var f=this.f,g,h;g=0;for(h=f.length;g<h;++g)e=f[g].$a(a,c,d,e);return e};l.bc=function(a,c){var d=this.f,e,f;e=0;for(f=d.length;e<f;++e)if(d[e].bc(a,c))return!0;return!1};l.Cd=function(a){Rd(Infinity,Infinity,-Infinity,-Infinity,a);for(var c=this.f,d=0,e=c.length;d<e;++d)ae(a,c[d].J());return a};l.$f=function(){return dn(this.f)};
l.Od=function(a){this.l!=this.b&&(Rb(this.g),this.i=0,this.l=this.b);if(0>a||0!==this.i&&a<this.i)return this;var c=a.toString();if(this.g.hasOwnProperty(c))return this.g[c];var d=[],e=this.f,f=!1,g,h;g=0;for(h=e.length;g<h;++g){var k=e[g],m=k.Od(a);d.push(m);m!==k&&(f=!0)}if(f)return a=new bn(null),en(a),a.f=d,cn(a),a.s(),this.g[c]=a;this.i=a;return this};l.Z=function(){return"GeometryCollection"};l.ya=function(a){var c=this.f,d,e;d=0;for(e=c.length;d<e;++d)if(c[d].ya(a))return!0;return!1};
l.Ba=function(){return 0===this.f.length};l.rh=function(a){a=dn(a);en(this);this.f=a;cn(this);this.s()};l.Ub=function(a){var c=this.f,d,e;d=0;for(e=c.length;d<e;++d)c[d].Ub(a);this.s()};l.Dc=function(a,c){var d=this.f,e,f;e=0;for(f=d.length;e<f;++e)d[e].Dc(a,c);this.s()};l.W=function(){en(this);bn.ba.W.call(this)};function fn(a,c,d,e,f){var g=NaN,h=NaN,k=(d-c)/e;if(0!==k)if(1==k)g=a[c],h=a[c+1];else if(2==k)g=.5*a[c]+.5*a[c+e],h=.5*a[c+1]+.5*a[c+e+1];else{var h=a[c],k=a[c+1],m=0,g=[0],n;for(n=c+e;n<d;n+=e){var p=a[n],q=a[n+1],m=m+Math.sqrt((p-h)*(p-h)+(q-k)*(q-k));g.push(m);h=p;k=q}d=.5*m;for(var r,h=ob,k=0,m=g.length;k<m;)n=k+m>>1,p=h(d,g[n]),0<p?k=n+1:(m=n,r=!p);r=r?k:~k;0>r?(d=(d-g[-r-2])/(g[-r-1]-g[-r-2]),c+=(-r-2)*e,g=qd(a[c],a[c+e],d),h=qd(a[c+1],a[c+e+1],d)):(g=a[c+r*e],h=a[c+r*e+1])}return f?(f[0]=
g,f[1]=h,f):[g,h]}function gn(a,c,d,e,f,g){if(d==c)return null;if(f<a[c+e-1])return g?(d=a.slice(c,c+e),d[e-1]=f,d):null;if(a[d-1]<f)return g?(d=a.slice(d-e,d),d[e-1]=f,d):null;if(f==a[c+e-1])return a.slice(c,c+e);c/=e;for(d/=e;c<d;)g=c+d>>1,f<a[(g+1)*e-1]?d=g:c=g+1;d=a[c*e-1];if(f==d)return a.slice((c-1)*e,(c-1)*e+e);g=(f-d)/(a[(c+1)*e-1]-d);d=[];var h;for(h=0;h<e-1;++h)d.push(qd(a[(c-1)*e+h],a[c*e+h],g));d.push(f);return d}
function hn(a,c,d,e,f,g){var h=0;if(g)return gn(a,h,c[c.length-1],d,e,f);if(e<a[d-1])return f?(a=a.slice(0,d),a[d-1]=e,a):null;if(a[a.length-1]<e)return f?(a=a.slice(a.length-d),a[d-1]=e,a):null;f=0;for(g=c.length;f<g;++f){var k=c[f];if(h!=k){if(e<a[h+d-1])break;if(e<=a[k-1])return gn(a,h,k,d,e,!1);h=k}}return null};function I(a,c){cf.call(this);this.c=null;this.B=this.C=this.j=-1;this.ja(a,c)}w(I,cf);l=I.prototype;l.ui=function(a){this.o?kb(this.o,a):this.o=a.slice();this.s()};l.clone=function(){var a=new I(null);jn(a,this.a,this.o.slice());return a};l.$a=function(a,c,d,e){if(e<Ud(this.J(),a,c))return e;this.B!=this.b&&(this.C=Math.sqrt(kf(this.o,0,this.o.length,this.I,0)),this.B=this.b);return mf(this.o,0,this.o.length,this.I,this.C,!1,a,c,d,e)};
l.Ji=function(a,c){return Cf(this.o,0,this.o.length,this.I,a,c)};l.il=function(a,c){return"XYM"!=this.a&&"XYZM"!=this.a?null:gn(this.o,0,this.o.length,this.I,a,void 0!==c?c:!1)};l.X=function(){return rf(this.o,0,this.o.length,this.I)};l.jl=function(){var a=this.o,c=this.I,d=a[0],e=a[1],f=0,g;for(g=0+c;g<this.o.length;g+=c)var h=a[g],k=a[g+1],f=f+Math.sqrt((h-d)*(h-d)+(k-e)*(k-e)),d=h,e=k;return f};function vm(a){a.j!=a.b&&(a.c=fn(a.o,0,a.o.length,a.I,a.c),a.j=a.b);return a.c}
l.zc=function(a){var c=[];c.length=tf(this.o,0,this.o.length,this.I,a,c,0);a=new I(null);jn(a,"XY",c);return a};l.Z=function(){return"LineString"};l.ya=function(a){return Df(this.o,0,this.o.length,this.I,a)};l.ja=function(a,c){a?(ff(this,c,a,1),this.o||(this.o=[]),this.o.length=pf(this.o,0,a,this.I),this.s()):jn(this,"XY",null)};function jn(a,c,d){ef(a,c,d);a.s()};function N(a,c){cf.call(this);this.c=[];this.j=this.B=-1;this.ja(a,c)}w(N,cf);l=N.prototype;l.vi=function(a){this.o?kb(this.o,a.o.slice()):this.o=a.o.slice();this.c.push(this.o.length);this.s()};l.clone=function(){var a=new N(null);kn(a,this.a,this.o.slice(),this.c.slice());return a};l.$a=function(a,c,d,e){if(e<Ud(this.J(),a,c))return e;this.j!=this.b&&(this.B=Math.sqrt(lf(this.o,0,this.c,this.I,0)),this.j=this.b);return nf(this.o,0,this.c,this.I,this.B,!1,a,c,d,e)};
l.ll=function(a,c,d){return"XYM"!=this.a&&"XYZM"!=this.a||0===this.o.length?null:hn(this.o,this.c,this.I,a,void 0!==c?c:!1,void 0!==d?d:!1)};l.X=function(){return sf(this.o,0,this.c,this.I)};l.ej=function(a){if(0>a||this.c.length<=a)return null;var c=new I(null);jn(c,this.a,this.o.slice(0===a?0:this.c[a-1],this.c[a]));return c};l.ed=function(){var a=this.o,c=this.c,d=this.a,e=[],f=0,g,h;g=0;for(h=c.length;g<h;++g){var k=c[g],m=new I(null);jn(m,d,a.slice(f,k));e.push(m);f=k}return e};
function wm(a){var c=[],d=a.o,e=0,f=a.c;a=a.I;var g,h;g=0;for(h=f.length;g<h;++g){var k=f[g],e=fn(d,e,k,a);kb(c,e);e=k}return c}l.zc=function(a){var c=[],d=[],e=this.o,f=this.c,g=this.I,h=0,k=0,m,n;m=0;for(n=f.length;m<n;++m){var p=f[m],k=tf(e,h,p,g,a,c,k);d.push(k);h=p}c.length=k;a=new N(null);kn(a,"XY",c,d);return a};l.Z=function(){return"MultiLineString"};l.ya=function(a){a:{var c=this.o,d=this.c,e=this.I,f=0,g,h;g=0;for(h=d.length;g<h;++g){if(Df(c,f,d[g],e,a)){a=!0;break a}f=d[g]}a=!1}return a};
l.ja=function(a,c){if(a){ff(this,c,a,2);this.o||(this.o=[]);var d=qf(this.o,0,a,this.I,this.c);this.o.length=0===d.length?0:d[d.length-1];this.s()}else kn(this,"XY",null,this.c)};function kn(a,c,d,e){ef(a,c,d);a.c=e;a.s()}function ln(a,c){var d=a.a,e=[],f=[],g,h;g=0;for(h=c.length;g<h;++g){var k=c[g];0===g&&(d=k.a);kb(e,k.o);f.push(e.length)}kn(a,d,e,f)};function mn(a,c){cf.call(this);this.ja(a,c)}w(mn,cf);l=mn.prototype;l.xi=function(a){this.o?kb(this.o,a.o):this.o=a.o.slice();this.s()};l.clone=function(){var a=new mn(null);ef(a,this.a,this.o.slice());a.s();return a};l.$a=function(a,c,d,e){if(e<Ud(this.J(),a,c))return e;var f=this.o,g=this.I,h,k,m;h=0;for(k=f.length;h<k;h+=g)if(m=Va(a,c,f[h],f[h+1]),m<e){e=m;for(m=0;m<g;++m)d[m]=f[h+m];d.length=g}return e};l.X=function(){return rf(this.o,0,this.o.length,this.I)};
l.pj=function(a){var c=this.o?this.o.length/this.I:0;if(0>a||c<=a)return null;c=new C(null);xf(c,this.a,this.o.slice(a*this.I,(a+1)*this.I));return c};l.ee=function(){var a=this.o,c=this.a,d=this.I,e=[],f,g;f=0;for(g=a.length;f<g;f+=d){var h=new C(null);xf(h,c,a.slice(f,f+d));e.push(h)}return e};l.Z=function(){return"MultiPoint"};l.ya=function(a){var c=this.o,d=this.I,e,f,g,h;e=0;for(f=c.length;e<f;e+=d)if(g=c[e],h=c[e+1],Wd(a,g,h))return!0;return!1};
l.ja=function(a,c){a?(ff(this,c,a,1),this.o||(this.o=[]),this.o.length=pf(this.o,0,a,this.I)):ef(this,"XY",null);this.s()};function O(a,c){cf.call(this);this.c=[];this.B=-1;this.C=null;this.T=this.P=this.H=-1;this.j=null;this.ja(a,c)}w(O,cf);l=O.prototype;l.yi=function(a){if(this.o){var c=this.o.length;kb(this.o,a.o);a=a.c.slice();var d,e;d=0;for(e=a.length;d<e;++d)a[d]+=c}else this.o=a.o.slice(),a=a.c.slice(),this.c.push();this.c.push(a);this.s()};l.clone=function(){var a=new O(null),c=Vb(this.c);nn(a,this.a,this.o.slice(),c);return a};
l.$a=function(a,c,d,e){if(e<Ud(this.J(),a,c))return e;if(this.P!=this.b){var f=this.c,g=0,h=0,k,m;k=0;for(m=f.length;k<m;++k)var n=f[k],h=lf(this.o,g,n,this.I,h),g=n[n.length-1];this.H=Math.sqrt(h);this.P=this.b}f=xm(this);g=this.c;h=this.I;k=this.H;m=0;var n=[NaN,NaN],p,q;p=0;for(q=g.length;p<q;++p){var r=g[p];e=nf(f,m,r,h,k,!0,a,c,d,e,n);m=r[r.length-1]}return e};
l.bc=function(a,c){var d;a:{d=xm(this);var e=this.c,f=0;if(0!==e.length){var g,h;g=0;for(h=e.length;g<h;++g){var k=e[g];if(Af(d,f,k,this.I,a,c)){d=!0;break a}f=k[k.length-1]}}d=!1}return d};l.ml=function(){var a=xm(this),c=this.c,d=0,e=0,f,g;f=0;for(g=c.length;f<g;++f)var h=c[f],e=e+hf(a,d,h,this.I),d=h[h.length-1];return e};
l.X=function(a){var c;void 0!==a?(c=xm(this).slice(),If(c,this.c,this.I,a)):c=this.o;a=c;c=this.c;var d=this.I,e=0,f=[],g=0,h,k;h=0;for(k=c.length;h<k;++h){var m=c[h];f[g++]=sf(a,e,m,d,f[g]);e=m[m.length-1]}f.length=g;return f};
function ym(a){if(a.B!=a.b){var c=a.o,d=a.c,e=a.I,f=0,g=[],h,k,m=Od();h=0;for(k=d.length;h<k;++h){var n=d[h],m=be(Rd(Infinity,Infinity,-Infinity,-Infinity,void 0),c,f,n[0],e);g.push((m[0]+m[2])/2,(m[1]+m[3])/2);f=n[n.length-1]}c=xm(a);d=a.c;e=a.I;f=0;h=[];k=0;for(m=d.length;k<m;++k)n=d[k],h=Bf(c,f,n,e,g,2*k,h),f=n[n.length-1];a.C=h;a.B=a.b}return a.C}l.bj=function(){var a=new mn(null),c=ym(this).slice();ef(a,"XY",c);a.s();return a};
function xm(a){if(a.T!=a.b){var c=a.o,d;a:{d=a.c;var e,f;e=0;for(f=d.length;e<f;++e)if(!Gf(c,d[e],a.I,void 0)){d=!1;break a}d=!0}d?a.j=c:(a.j=c.slice(),a.j.length=If(a.j,a.c,a.I));a.T=a.b}return a.j}l.zc=function(a){var c=[],d=[],e=this.o,f=this.c,g=this.I;a=Math.sqrt(a);var h=0,k=0,m,n;m=0;for(n=f.length;m<n;++m){var p=f[m],q=[],k=uf(e,h,p,g,a,c,k,q);d.push(q);h=p[p.length-1]}c.length=k;e=new O(null);nn(e,"XY",c,d);return e};
l.rj=function(a){if(0>a||this.c.length<=a)return null;var c;0===a?c=0:(c=this.c[a-1],c=c[c.length-1]);a=this.c[a].slice();var d=a[a.length-1];if(0!==c){var e,f;e=0;for(f=a.length;e<f;++e)a[e]-=c}e=new D(null);Jf(e,this.a,this.o.slice(c,d),a);return e};l.Md=function(){var a=this.a,c=this.o,d=this.c,e=[],f=0,g,h,k,m;g=0;for(h=d.length;g<h;++g){var n=d[g].slice(),p=n[n.length-1];if(0!==f)for(k=0,m=n.length;k<m;++k)n[k]-=f;k=new D(null);Jf(k,a,c.slice(f,p),n);e.push(k);f=p}return e};l.Z=function(){return"MultiPolygon"};
l.ya=function(a){a:{var c=xm(this),d=this.c,e=this.I,f=0,g,h;g=0;for(h=d.length;g<h;++g){var k=d[g];if(Ef(c,f,k,e,a)){a=!0;break a}f=k[k.length-1]}a=!1}return a};l.ja=function(a,c){if(a){ff(this,c,a,3);this.o||(this.o=[]);var d=this.o,e=this.I,f=this.c,g=0,f=f?f:[],h=0,k,m;k=0;for(m=a.length;k<m;++k)g=qf(d,g,a[k],e,f[h]),f[h++]=g,g=g[g.length-1];f.length=h;0===f.length?this.o.length=0:(d=f[f.length-1],this.o.length=0===d.length?0:d[d.length-1]);this.s()}else nn(this,"XY",null,this.c)};
function nn(a,c,d,e){ef(a,c,d);a.c=e;a.s()}function on(a,c){var d=a.a,e=[],f=[],g,h,k;g=0;for(h=c.length;g<h;++g){var m=c[g];0===g&&(d=m.a);var n=e.length;k=m.c;var p,q;p=0;for(q=k.length;p<q;++p)k[p]+=n;kb(e,m.o);f.push(k)}nn(a,d,e,f)};function pn(a,c){return v(a)-v(c)}function qn(a,c){var d=.5*a/c;return d*d}function rn(a,c,d,e,f,g){var h=!1,k,m;if(k=d.i)m=k.md(),2==m||3==m?k.Ff(f,g):(0==m&&k.load(),k.ff(f,g),h=!0);if(f=(0,d.f)(c))e=f.Od(e),(0,sn[e.Z()])(a,e,d,c);return h}
var sn={Point:function(a,c,d,e){var f=d.i;if(f){if(2!=f.md())return;var g=a.b(d.b,"Image");g.ib(f);g.vb(c,e)}if(f=d.a)a=a.b(d.b,"Text"),a.Ra(f),a.wb(c.X(),0,2,2,c,e)},LineString:function(a,c,d,e){var f=d.c;if(f){var g=a.b(d.b,"LineString");g.Qa(null,f);g.Eb(c,e)}if(f=d.a)a=a.b(d.b,"Text"),a.Ra(f),a.wb(vm(c),0,2,2,c,e)},Polygon:function(a,c,d,e){var f=d.g,g=d.c;if(f||g){var h=a.b(d.b,"Polygon");h.Qa(f,g);h.wc(c,e)}if(f=d.a)a=a.b(d.b,"Text"),a.Ra(f),a.wb(Lf(c),0,2,2,c,e)},MultiPoint:function(a,c,d,
e){var f=d.i;if(f){if(2!=f.md())return;var g=a.b(d.b,"Image");g.ib(f);g.ub(c,e)}if(f=d.a)a=a.b(d.b,"Text"),a.Ra(f),d=c.o,a.wb(d,0,d.length,c.I,c,e)},MultiLineString:function(a,c,d,e){var f=d.c;if(f){var g=a.b(d.b,"LineString");g.Qa(null,f);g.uc(c,e)}if(f=d.a)a=a.b(d.b,"Text"),a.Ra(f),d=wm(c),a.wb(d,0,d.length,2,c,e)},MultiPolygon:function(a,c,d,e){var f=d.g,g=d.c;if(g||f){var h=a.b(d.b,"Polygon");h.Qa(f,g);h.vc(c,e)}if(f=d.a)a=a.b(d.b,"Text"),a.Ra(f),d=ym(c),a.wb(d,0,d.length,2,c,e)},GeometryCollection:function(a,
c,d,e){c=c.f;var f,g;f=0;for(g=c.length;f<g;++f)(0,sn[c[f].Z()])(a,c[f],d,e)},Circle:function(a,c,d,e){var f=d.g,g=d.c;if(f||g){var h=a.b(d.b,"Polygon");h.Qa(f,g);h.tc(c,e)}if(f=d.a)a=a.b(d.b,"Text"),a.Ra(f),a.wb(c.hd(),0,2,2,c,e)}};function tn(a,c,d,e,f,g){this.g=void 0!==g?g:null;kk.call(this,a,c,d,void 0!==g?0:2,e);this.f=f;this.a=null}w(tn,kk);tn.prototype.getError=function(){return this.a};tn.prototype.j=function(a){a?(this.a=a,this.state=3):this.state=2;lk(this)};tn.prototype.load=function(){0==this.state&&(this.state=1,lk(this),this.g(sa(this.j,this)))};tn.prototype.b=function(){return this.f};var un=!((Gb("Chrome")||Gb("CriOS"))&&!Gb("Opera")&&!Gb("OPR")&&!Gb("Edge"))||Gb("iPhone")&&!Gb("iPod")&&!Gb("iPad")||Gb("iPad")||Gb("iPod");function vn(a,c,d,e){var f=Ze(d,c,a);d=c.getPointResolution(e,d);c=c.yc();void 0!==c&&(d*=c);c=a.yc();void 0!==c&&(d/=c);a=a.getPointResolution(d,f)/d;isFinite(a)&&!isNaN(a)&&0<a&&(d/=a);return d}function wn(a,c,d,e){a=d-a;c=e-c;var f=Math.sqrt(a*a+c*c);return[Math.round(d+a/f),Math.round(e+c/f)]}
function xn(a,c,d,e,f,g,h,k,m,n){var p=Ti(Math.round(d*a),Math.round(d*c));if(0===m.length)return p.canvas;p.scale(d,d);var q=Od();m.forEach(function(a){ae(q,a.extent)});var r=Ti(Math.round(d*je(q)/e),Math.round(d*ke(q)/e));r.scale(d/e,d/e);r.translate(-q[0],q[3]);m.forEach(function(a){r.drawImage(a.image,a.extent[0],-a.extent[3],je(a.extent),ke(a.extent))});var t=ge(h);k.f.forEach(function(a){var c=a.source,f=a.target,h=c[1][0],k=c[1][1],m=c[2][0],n=c[2][1];a=(f[0][0]-t[0])/g;var H=-(f[0][1]-t[1])/
g,J=(f[1][0]-t[0])/g,ra=-(f[1][1]-t[1])/g,Ga=(f[2][0]-t[0])/g,K=-(f[2][1]-t[1])/g,f=c[0][0],c=c[0][1],h=h-f,k=k-c,m=m-f,n=n-c;a:{h=[[h,k,0,0,J-a],[m,n,0,0,Ga-a],[0,0,h,k,ra-H],[0,0,m,n,K-H]];k=h.length;for(m=0;m<k;m++){for(var n=m,oa=Math.abs(h[m][m]),Oa=m+1;Oa<k;Oa++){var La=Math.abs(h[Oa][m]);La>oa&&(oa=La,n=Oa)}if(0===oa){h=null;break a}oa=h[n];h[n]=h[m];h[m]=oa;for(n=m+1;n<k;n++)for(oa=-h[n][m]/h[m][m],Oa=m;Oa<k+1;Oa++)h[n][Oa]=m==Oa?0:h[n][Oa]+oa*h[m][Oa]}m=Array(k);for(n=k-1;0<=n;n--)for(m[n]=
h[n][k]/h[n][n],oa=n-1;0<=oa;oa--)h[oa][k]-=h[oa][n]*m[n];h=m}h&&(p.save(),p.beginPath(),un?(m=(a+J+Ga)/3,n=(H+ra+K)/3,k=wn(m,n,a,H),J=wn(m,n,J,ra),Ga=wn(m,n,Ga,K),p.moveTo(k[0],k[1]),p.lineTo(J[0],J[1]),p.lineTo(Ga[0],Ga[1])):(p.moveTo(a,H),p.lineTo(J,ra),p.lineTo(Ga,K)),p.closePath(),p.clip(),p.transform(h[0],h[2],h[1],h[3],a,H),p.translate(q[0]-f,q[3]-c),p.scale(e/d,-e/d),p.drawImage(r.canvas,0,0),p.restore())});n&&(p.save(),p.strokeStyle="black",p.lineWidth=1,k.f.forEach(function(a){var c=a.target;
a=(c[0][0]-t[0])/g;var d=-(c[0][1]-t[1])/g,e=(c[1][0]-t[0])/g,f=-(c[1][1]-t[1])/g,h=(c[2][0]-t[0])/g,c=-(c[2][1]-t[1])/g;p.beginPath();p.moveTo(a,d);p.lineTo(e,f);p.lineTo(h,c);p.closePath();p.stroke()}),p.restore());return p.canvas};function yn(a,c,d,e,f){this.c=a;this.g=c;var g={},h=Xe(this.g,this.c);this.a=function(a){var c=a[0]+"/"+a[1];g[c]||(g[c]=h(a));return g[c]};this.i=e;this.v=f*f;this.f=[];this.l=!1;this.D=this.c.a&&!!e&&!!this.c.J()&&je(e)==je(this.c.J());this.b=this.c.J()?je(this.c.J()):null;this.j=this.g.J()?je(this.g.J()):null;a=ge(d);c=fe(d);e=ee(d);d=de(d);f=this.a(a);var k=this.a(c),m=this.a(e),n=this.a(d);zn(this,a,c,e,d,f,k,m,n,10);if(this.l){var p=Infinity;this.f.forEach(function(a){p=Math.min(p,a.source[0][0],
a.source[1][0],a.source[2][0])});this.f.forEach(function(a){if(Math.max(a.source[0][0],a.source[1][0],a.source[2][0])-p>this.b/2){var c=[[a.source[0][0],a.source[0][1]],[a.source[1][0],a.source[1][1]],[a.source[2][0],a.source[2][1]]];c[0][0]-p>this.b/2&&(c[0][0]-=this.b);c[1][0]-p>this.b/2&&(c[1][0]-=this.b);c[2][0]-p>this.b/2&&(c[2][0]-=this.b);Math.max(c[0][0],c[1][0],c[2][0])-Math.min(c[0][0],c[1][0],c[2][0])<this.b/2&&(a.source=c)}},this)}g={}}
function zn(a,c,d,e,f,g,h,k,m,n){var p=Nd([g,h,k,m]),q=a.b?je(p)/a.b:null,r=a.c.a&&.5<q&&1>q,t=!1;if(0<n){if(a.g.c&&a.j)var y=Nd([c,d,e,f]),t=t|.25<je(y)/a.j;!r&&a.c.c&&q&&(t|=.25<q)}if(t||!a.i||oe(p,a.i)){if(!(t||isFinite(g[0])&&isFinite(g[1])&&isFinite(h[0])&&isFinite(h[1])&&isFinite(k[0])&&isFinite(k[1])&&isFinite(m[0])&&isFinite(m[1])))if(0<n)t=!0;else return;if(0<n&&(t||(q=a.a([(c[0]+e[0])/2,(c[1]+e[1])/2]),p=r?(pd(g[0],a.b)+pd(k[0],a.b))/2-pd(q[0],a.b):(g[0]+k[0])/2-q[0],q=(g[1]+k[1])/2-q[1],
t=p*p+q*q>a.v),t)){Math.abs(c[0]-e[0])<=Math.abs(c[1]-e[1])?(r=[(d[0]+e[0])/2,(d[1]+e[1])/2],p=a.a(r),q=[(f[0]+c[0])/2,(f[1]+c[1])/2],t=a.a(q),zn(a,c,d,r,q,g,h,p,t,n-1),zn(a,q,r,e,f,t,p,k,m,n-1)):(r=[(c[0]+d[0])/2,(c[1]+d[1])/2],p=a.a(r),q=[(e[0]+f[0])/2,(e[1]+f[1])/2],t=a.a(q),zn(a,c,r,q,f,g,p,t,m,n-1),zn(a,r,d,e,q,p,h,k,t,n-1));return}if(r){if(!a.D)return;a.l=!0}a.f.push({source:[g,k,m],target:[c,e,f]});a.f.push({source:[g,h,k],target:[c,d,e]})}}
function An(a){var c=Od();a.f.forEach(function(a){a=a.source;Pd(c,a[0]);Pd(c,a[1]);Pd(c,a[2])});return c};function Bn(a,c,d,e,f,g){this.B=c;this.A=a.J();var h=c.J(),k=h?ne(d,h):d,h=vn(a,c,le(k),e);this.D=new yn(a,c,k,this.A,.5*h);this.j=e;this.g=d;a=An(this.D);this.v=(this.a=g(a,h,f))?this.a.c:1;this.f=this.l=null;f=2;g=[];this.a&&(f=0,g=this.a.i);kk.call(this,d,e,this.v,f,g)}w(Bn,kk);Bn.prototype.W=function(){1==this.state&&(Zc(this.f),this.f=null);Bn.ba.W.call(this)};Bn.prototype.b=function(){return this.l};
function Cn(a){var c=a.a.state;2==c&&(a.l=xn(je(a.g)/a.j,ke(a.g)/a.j,a.v,a.a.aa(),0,a.j,a.g,a.D,[{extent:a.a.J(),image:a.a.b()}]));a.state=c;lk(a)}Bn.prototype.load=function(){if(0==this.state){this.state=1;lk(this);var a=this.a.state;2==a||3==a?Cn(this):(this.f=this.a.Ka("change",function(){var a=this.a.state;if(2==a||3==a)Zc(this.f),this.f=null,Cn(this)},!1,this),this.a.load())}};function Dn(a){Fh.call(this,{attributions:a.attributions,extent:a.extent,logo:a.logo,projection:a.projection,state:a.state});this.C=void 0!==a.resolutions?a.resolutions:null;this.a=null;this.na=0}w(Dn,Fh);function En(a,c){if(a.C){var d=vb(a.C,c,0);c=a.C[d]}return c}
Dn.prototype.v=function(a,c,d,e){var f=this.f;if(f&&e&&!We(f,e)){if(this.a){if(this.na==this.b&&We(this.a.B,e)&&this.a.aa()==c&&this.a.c==d&&$d(this.a.J(),a))return this.a;this.a.sc();this.a=null}this.a=new Bn(f,e,a,c,d,sa(function(a,c,d){return this.dd(a,c,d,f)},this));this.na=this.b;return this.a}f&&(e=f);return this.dd(a,c,d,e)};Dn.prototype.B=function(a){a=a.target;switch(a.state){case 1:this.u(new Fn(Gn,a));break;case 2:this.u(new Fn(Hn,a));break;case 3:this.u(new Fn(In,a))}};
function Jn(a,c){a.b().src=c}function Fn(a,c){vc.call(this,a);this.image=c}w(Fn,vc);var Gn="imageloadstart",Hn="imageloadend",In="imageloaderror";function Kn(a){Dn.call(this,{attributions:a.attributions,logo:a.logo,projection:a.projection,resolutions:a.resolutions,state:void 0!==a.state?a.state:void 0});this.da=a.canvasFunction;this.V=null;this.ca=0;this.ma=void 0!==a.ratio?a.ratio:1.5}w(Kn,Dn);Kn.prototype.dd=function(a,c,d,e){c=En(this,c);var f=this.V;if(f&&this.ca==this.b&&f.aa()==c&&f.c==d&&Xd(f.J(),a))return f;a=a.slice();pe(a,this.ma);(e=this.da(a,c,d,[je(a)/c*d,ke(a)/c*d],e))&&(f=new tn(a,c,d,this.j,e));this.V=f;this.ca=this.b;return f};function P(a){id.call(this);this.ta=void 0;this.a="geometry";this.g=null;this.c=void 0;this.f=null;B(this,kd(this.a),this.Rd,!1,this);void 0!==a&&(a instanceof af||!a?this.Ca(a):this.K(a))}w(P,id);l=P.prototype;l.clone=function(){var a=new P(this.S());a.Kc(this.a);var c=this.Y();c&&a.Ca(c.clone());(c=this.g)&&a.jf(c);return a};l.Y=function(){return this.get(this.a)};l.Fa=function(){return this.ta};l.Zi=function(){return this.a};l.Hk=function(){return this.g};l.Ik=function(){return this.c};l.Jk=function(){this.s()};
l.Rd=function(){this.f&&(Zc(this.f),this.f=null);var a=this.Y();a&&(this.f=B(a,"change",this.Jk,!1,this));this.s()};l.Ca=function(a){this.set(this.a,a)};l.jf=function(a){this.c=(this.g=a)?Ln(a):void 0;this.s()};l.Sb=function(a){this.ta=a;this.s()};l.Kc=function(a){Yc(this,kd(this.a),this.Rd,!1,this);this.a=a;B(this,kd(this.a),this.Rd,!1,this);this.Rd()};function Ln(a){if(!ka(a)){var c;c=ga(a)?a:[a];a=function(){return c}}return a};function Mn(a){a.prototype.then=a.prototype.then;a.prototype.$goog_Thenable=!0}function Nn(a){if(!a)return!1;try{return!!a.$goog_Thenable}catch(c){return!1}};function On(a,c,d){this.f=d;this.c=a;this.g=c;this.a=0;this.b=null}On.prototype.get=function(){var a;0<this.a?(this.a--,a=this.b,this.b=a.next,a.next=null):a=this.c();return a};function Pn(a,c){a.g(c);a.a<a.f&&(a.a++,c.next=a.b,a.b=c)};function Qn(){this.a=this.b=null}var Sn=new On(function(){return new Rn},function(a){a.reset()},100);Qn.prototype.add=function(a,c){var d=Sn.get();d.set(a,c);this.a?this.a.next=d:this.b=d;this.a=d};Qn.prototype.remove=function(){var a=null;this.b&&(a=this.b,this.b=this.b.next,this.b||(this.a=null),a.next=null);return a};function Rn(){this.next=this.a=this.b=null}Rn.prototype.set=function(a,c){this.b=a;this.a=c;this.next=null};Rn.prototype.reset=function(){this.next=this.a=this.b=null};function Tn(a,c){Un||Vn();Wn||(Un(),Wn=!0);Xn.add(a,c)}var Un;function Vn(){if(ba.Promise&&ba.Promise.resolve){var a=ba.Promise.resolve(void 0);Un=function(){a.then(Yn)}}else Un=function(){ri(Yn)}}var Wn=!1,Xn=new Qn;function Yn(){for(var a=null;a=Xn.remove();){try{a.b.call(a.a)}catch(c){qi(c)}Pn(Sn,a)}Wn=!1};function Zn(a,c){this.b=$n;this.j=void 0;this.f=this.a=this.c=null;this.g=this.i=!1;if(a!=da)try{var d=this;a.call(c,function(a){ao(d,bo,a)},function(a){ao(d,co,a)})}catch(e){ao(this,co,e)}}var $n=0,bo=2,co=3;function eo(){this.next=this.c=this.a=this.f=this.b=null;this.g=!1}eo.prototype.reset=function(){this.c=this.a=this.f=this.b=null;this.g=!1};var fo=new On(function(){return new eo},function(a){a.reset()},100);function go(a,c,d){var e=fo.get();e.f=a;e.a=c;e.c=d;return e}
Zn.prototype.then=function(a,c,d){return ho(this,ka(a)?a:null,ka(c)?c:null,d)};Mn(Zn);Zn.prototype.cancel=function(a){this.b==$n&&Tn(function(){var c=new io(a);jo(this,c)},this)};function jo(a,c){if(a.b==$n)if(a.c){var d=a.c;if(d.a){for(var e=0,f=null,g=null,h=d.a;h&&(h.g||(e++,h.b==a&&(f=h),!(f&&1<e)));h=h.next)f||(g=h);f&&(d.b==$n&&1==e?jo(d,c):(g?(e=g,e.next==d.f&&(d.f=e),e.next=e.next.next):ko(d),lo(d,f,co,c)))}a.c=null}else ao(a,co,c)}
function mo(a,c){a.a||a.b!=bo&&a.b!=co||no(a);a.f?a.f.next=c:a.a=c;a.f=c}function ho(a,c,d,e){var f=go(null,null,null);f.b=new Zn(function(a,h){f.f=c?function(d){try{var f=c.call(e,d);a(f)}catch(n){h(n)}}:a;f.a=d?function(c){try{var f=d.call(e,c);!ca(f)&&c instanceof io?h(c):a(f)}catch(n){h(n)}}:h});f.b.c=a;mo(a,f);return f.b}Zn.prototype.D=function(a){this.b=$n;ao(this,bo,a)};Zn.prototype.v=function(a){this.b=$n;ao(this,co,a)};
function ao(a,c,d){if(a.b==$n){a==d&&(c=co,d=new TypeError("Promise cannot resolve to itself"));a.b=1;var e;a:{var f=d,g=a.D,h=a.v;if(f instanceof Zn)mo(f,go(g||da,h||null,a)),e=!0;else if(Nn(f))f.then(g,h,a),e=!0;else{if(la(f))try{var k=f.then;if(ka(k)){oo(f,k,g,h,a);e=!0;break a}}catch(m){h.call(a,m);e=!0;break a}e=!1}}e||(a.j=d,a.b=c,a.c=null,no(a),c!=co||d instanceof io||po(a,d))}}
function oo(a,c,d,e,f){function g(a){k||(k=!0,e.call(f,a))}function h(a){k||(k=!0,d.call(f,a))}var k=!1;try{c.call(a,h,g)}catch(m){g(m)}}function no(a){a.i||(a.i=!0,Tn(a.l,a))}function ko(a){var c=null;a.a&&(c=a.a,a.a=c.next,c.next=null);a.a||(a.f=null);return c}Zn.prototype.l=function(){for(var a=null;a=ko(this);)lo(this,a,this.b,this.j);this.i=!1};
function lo(a,c,d,e){if(d==co&&c.a&&!c.g)for(;a&&a.g;a=a.c)a.g=!1;if(c.b)c.b.c=null,qo(c,d,e);else try{c.g?c.f.call(c.c):qo(c,d,e)}catch(f){ro.call(null,f)}Pn(fo,c)}function qo(a,c,d){c==bo?a.f.call(a.c,d):a.a&&a.a.call(a.c,d)}function po(a,c){a.g=!0;Tn(function(){a.g&&ro.call(null,c)})}var ro=qi;function io(a){ya.call(this,a)}w(io,ya);io.prototype.name="cancel";function so(a,c,d){if(ka(a))d&&(a=sa(a,d));else if(a&&"function"==typeof a.handleEvent)a=sa(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<c?-1:ba.setTimeout(a,c||0)};var to=ba.JSON.parse,uo=ba.JSON.stringify;function vo(){}vo.prototype.b=null;function wo(a){var c;(c=a.b)||(c={},xo(a)&&(c[0]=!0,c[1]=!0),c=a.b=c);return c};var yo;function zo(){}w(zo,vo);function Ao(a){return(a=xo(a))?new ActiveXObject(a):new XMLHttpRequest}function xo(a){if(!a.a&&"undefined"==typeof XMLHttpRequest&&"undefined"!=typeof ActiveXObject){for(var c=["MSXML2.XMLHTTP.6.0","MSXML2.XMLHTTP.3.0","MSXML2.XMLHTTP","Microsoft.XMLHTTP"],d=0;d<c.length;d++){var e=c[d];try{return new ActiveXObject(e),a.a=e}catch(f){}}throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");}return a.a}yo=new zo;var Bo=/^(?:([^:/?#.]+):)?(?:\/\/(?:([^/?#]*)@)?([^/#?]*?)(?::([0-9]+))?(?=[/#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#(.*))?$/;function Co(a,c){if(a)for(var d=a.split("&"),e=0;e<d.length;e++){var f=d[e].indexOf("="),g=null,h=null;0<=f?(g=d[e].substring(0,f),h=d[e].substring(f+1)):g=d[e];c(g,h?decodeURIComponent(h.replace(/\+/g," ")):"")}}
function Do(a){if(a[1]){var c=a[0],d=c.indexOf("#");0<=d&&(a.push(c.substr(d)),a[0]=c=c.substr(0,d));d=c.indexOf("?");0>d?a[1]="?":d==c.length-1&&(a[1]=void 0)}return a.join("")}function Eo(a,c,d){if(ga(c))for(var e=0;e<c.length;e++)Eo(a,String(c[e]),d);else null!=c&&d.push("&",a,""===c?"":"=",encodeURIComponent(String(c)))}function Fo(a,c){for(var d in c)Eo(d,c[d],a);return a};function Go(a){cd.call(this);this.H=new vi;this.l=a||null;this.b=!1;this.j=this.ha=null;this.g=this.T=this.A="";this.a=this.v=this.f=this.D=!1;this.i=0;this.c=null;this.B=Ho;this.C=this.V=!1}w(Go,cd);var Ho="",Io=/^https?$/i,Jo=["POST","PUT"];
function Ko(a,c){if(a.ha)throw Error("[goog.net.XhrIo] Object is active with another request="+a.A+"; newUri="+c);a.A=c;a.g="";a.T="GET";a.D=!1;a.b=!0;a.ha=a.l?Ao(a.l):Ao(yo);a.j=a.l?wo(a.l):wo(yo);a.ha.onreadystatechange=sa(a.P,a);try{a.v=!0,a.ha.open("GET",String(c),!0),a.v=!1}catch(g){Lo(a,g);return}var d=a.H.clone(),e=fb(d.R(),Mo),f=ba.FormData&&!1;!(0<=$a(Jo,"GET"))||e||f||d.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");d.forEach(function(a,c){this.ha.setRequestHeader(c,
a)},a);a.B&&(a.ha.responseType=a.B);"withCredentials"in a.ha&&(a.ha.withCredentials=a.V);try{No(a),0<a.i&&(a.C=Oo(a.ha),a.C?(a.ha.timeout=a.i,a.ha.ontimeout=sa(a.nc,a)):a.c=so(a.nc,a.i,a)),a.f=!0,a.ha.send(""),a.f=!1}catch(g){Lo(a,g)}}function Oo(a){return Zb&&jc(9)&&ja(a.timeout)&&ca(a.ontimeout)}function Mo(a){return"content-type"==a.toLowerCase()}
Go.prototype.nc=function(){"undefined"!=typeof aa&&this.ha&&(this.g="Timed out after "+this.i+"ms, aborting",this.u("timeout"),this.ha&&this.b&&(this.b=!1,this.a=!0,this.ha.abort(),this.a=!1,this.u("complete"),this.u("abort"),Po(this)))};function Lo(a,c){a.b=!1;a.ha&&(a.a=!0,a.ha.abort(),a.a=!1);a.g=c;Qo(a);Po(a)}function Qo(a){a.D||(a.D=!0,a.u("complete"),a.u("error"))}Go.prototype.W=function(){this.ha&&(this.b&&(this.b=!1,this.a=!0,this.ha.abort(),this.a=!1),Po(this,!0));Go.ba.W.call(this)};
Go.prototype.P=function(){this.fa||(this.v||this.f||this.a?Ro(this):this.ea())};Go.prototype.ea=function(){Ro(this)};function Ro(a){if(a.b&&"undefined"!=typeof aa&&(!a.j[1]||4!=So(a)||2!=To(a)))if(a.f&&4==So(a))so(a.P,0,a);else if(a.u("readystatechange"),4==So(a)){a.b=!1;try{if(Uo(a))a.u("complete"),a.u("success");else{var c;try{c=2<So(a)?a.ha.statusText:""}catch(d){c=""}a.g=c+" ["+To(a)+"]";Qo(a)}}finally{Po(a)}}}
function Po(a,c){if(a.ha){No(a);var d=a.ha,e=a.j[0]?da:null;a.ha=null;a.j=null;c||a.u("ready");try{d.onreadystatechange=e}catch(f){}}}function No(a){a.ha&&a.C&&(a.ha.ontimeout=null);ja(a.c)&&(ba.clearTimeout(a.c),a.c=null)}
function Uo(a){var c=To(a),d;a:switch(c){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:d=!0;break a;default:d=!1}if(!d){if(c=0===c)a=String(a.A).match(Bo)[1]||null,!a&&ba.self&&ba.self.location&&(a=ba.self.location.protocol,a=a.substr(0,a.length-1)),c=!Io.test(a?a.toLowerCase():"");d=c}return d}function So(a){return a.ha?a.ha.readyState:0}function To(a){try{return 2<So(a)?a.ha.status:-1}catch(c){return-1}}function Vo(a){try{return a.ha?a.ha.responseText:""}catch(c){return""}};function Wo(){if(!Zb)return!1;try{return new ActiveXObject("MSXML2.DOMDocument"),!0}catch(a){return!1}}var Xo=Zb&&Wo();function Yo(a){var c=a.xml;if(c)return c;if("undefined"!=typeof XMLSerializer)return(new XMLSerializer).serializeToString(a);throw Error("Your browser does not support serializing XML documents");};var Zo;a:if(document.implementation&&document.implementation.createDocument)Zo=document.implementation.createDocument("","",null);else{if(Xo){var $o=new ActiveXObject("MSXML2.DOMDocument");if($o){$o.resolveExternals=!1;$o.validateOnParse=!1;try{$o.setProperty("ProhibitDTD",!0),$o.setProperty("MaxXMLSize",2048),$o.setProperty("MaxElementDepth",256)}catch(a){}}if($o){Zo=$o;break a}}throw Error("Your browser does not support creating new documents");}var ap=Zo;
function bp(a,c){return ap.createElementNS(a,c)}function cp(a,c){a||(a="");return ap.createNode(1,c,a)}var dp=document.implementation&&document.implementation.createDocument?bp:cp;function ep(a,c){return fp(a,c,[]).join("")}function fp(a,c,d){if(4==a.nodeType||3==a.nodeType)c?d.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g,"")):d.push(a.nodeValue);else for(a=a.firstChild;a;a=a.nextSibling)fp(a,c,d);return d}function gp(a){return a.localName}
function hp(a){var c=a.localName;return void 0!==c?c:a.baseName}var ip=Zb?hp:gp;function jp(a){return a instanceof Document}function kp(a){return la(a)&&9==a.nodeType}var lp=Zb?kp:jp;function mp(a){return a instanceof Node}function np(a){return la(a)&&void 0!==a.nodeType}var op=Zb?np:mp;function pp(a,c,d){return a.getAttributeNS(c,d)||""}function qp(a,c,d){var e="";a=rp(a,c,d);void 0!==a&&(e=a.nodeValue);return e}var sp=document.implementation&&document.implementation.createDocument?pp:qp;
function tp(a,c,d){return a.getAttributeNodeNS(c,d)}function up(a,c,d){var e=null;a=a.attributes;for(var f,g,h=0,k=a.length;h<k;++h)if(f=a[h],f.namespaceURI==c&&(g=f.prefix?f.prefix+":"+d:d,g==f.nodeName)){e=f;break}return e}var rp=document.implementation&&document.implementation.createDocument?tp:up;function vp(a,c,d,e){a.setAttributeNS(c,d,e)}function wp(a,c,d,e){c?(c=a.ownerDocument.createNode(2,d,c),c.nodeValue=e,a.setAttributeNode(c)):a.setAttribute(d,e)}
var xp=document.implementation&&document.implementation.createDocument?vp:wp;function yp(a){return(new DOMParser).parseFromString(a,"application/xml")}function zp(a,c){return function(d,e){var f=a.call(c,d,e);void 0!==f&&kb(e[e.length-1],f)}}function Ap(a,c){return function(d,e){var f=a.call(void 0!==c?c:this,d,e);void 0!==f&&e[e.length-1].push(f)}}function Bp(a,c){return function(d,e){var f=a.call(void 0!==c?c:this,d,e);void 0!==f&&(e[e.length-1]=f)}}
function Cp(a){return function(c,d){var e=a.call(this,c,d);void 0!==e&&Tb(d[d.length-1],c.localName).push(e)}}function Q(a,c){return function(d,e){var f=a.call(this,d,e);void 0!==f&&(e[e.length-1][void 0!==c?c:d.localName]=f)}}function R(a,c){return function(d,e,f){a.call(void 0!==c?c:this,d,e,f);f[f.length-1].node.appendChild(d)}}function Dp(a){var c,d;return function(e,f,g){if(void 0===c){c={};var h={};h[e.localName]=a;c[e.namespaceURI]=h;d=Ep(e.localName)}Fp(c,d,f,g)}}
function Ep(a,c){return function(d,e,f){d=e[e.length-1].node;e=a;void 0===e&&(e=f);f=c;void 0===c&&(f=d.namespaceURI);return dp(f,e)}}var Gp=Ep();function Hp(a,c){for(var d=c.length,e=Array(d),f=0;f<d;++f)e[f]=a[c[f]];return e}function S(a,c,d){d=void 0!==d?d:{};var e,f;e=0;for(f=a.length;e<f;++e)d[a[e]]=c;return d}function Ip(a,c,d,e){for(c=c.firstElementChild;c;c=c.nextElementSibling){var f=a[c.namespaceURI];void 0!==f&&(f=f[c.localName],void 0!==f&&f.call(e,c,d))}}
function T(a,c,d,e,f){e.push(a);Ip(c,d,e,f);return e.pop()}function Fp(a,c,d,e,f,g){for(var h=(void 0!==f?f:d).length,k,m,n=0;n<h;++n)k=d[n],void 0!==k&&(m=c.call(g,k,e,void 0!==f?f[n]:void 0),void 0!==m&&a[m.namespaceURI][m.localName].call(g,m,k,e))}function Jp(a,c,d,e,f,g,h){f.push(a);Fp(c,d,e,f,g,h);f.pop()};function Kp(a,c,d){return function(e,f,g){var h=new Go;h.B="text";B(h,"complete",function(a){a=a.target;if(Uo(a)){var e=c.Z(),f;if("json"==e)f=Vo(a);else if("text"==e)f=Vo(a);else if("xml"==e){if(!Zb)try{f=a.ha?a.ha.responseXML:null}catch(h){f=null}f||(f=yp(Vo(a)))}f&&(f=c.va(f,{featureProjection:g}),d.call(this,f))}uc(a)},!1,this);ka(a)?Ko(h,a(e,f,g)):Ko(h,a)}}function Lp(a,c){return Kp(a,c,function(a){this.Tb(a)})};function Mp(){return[[-Infinity,-Infinity,Infinity,Infinity]]};var Np,Op;
(function(){var a={ob:{}};(function(){function c(a,d){if(!(this instanceof c))return new c(a,d);this.Ke=Math.max(4,a||9);this.Pf=Math.max(2,Math.ceil(.4*this.Ke));d&&this.mi(d);this.clear()}function d(a,c){a.bbox=e(a,0,a.children.length,c)}function e(a,c,d,e){for(var g=[Infinity,Infinity,-Infinity,-Infinity],h;c<d;c++)h=a.children[c],f(g,a.Ja?e(h):h.bbox);return g}function f(a,c){a[0]=Math.min(a[0],c[0]);a[1]=Math.min(a[1],c[1]);a[2]=Math.max(a[2],c[2]);a[3]=Math.max(a[3],c[3])}function g(a,c){return a.bbox[0]-
c.bbox[0]}function h(a,c){return a.bbox[1]-c.bbox[1]}function k(a){return(a[2]-a[0])*(a[3]-a[1])}function m(a){return a[2]-a[0]+(a[3]-a[1])}function n(a,c){return a[0]<=c[0]&&a[1]<=c[1]&&c[2]<=a[2]&&c[3]<=a[3]}function p(a,c){return c[0]<=a[2]&&c[1]<=a[3]&&c[2]>=a[0]&&c[3]>=a[1]}function q(a,c,d,e,f){for(var g=[c,d],h;g.length;)d=g.pop(),c=g.pop(),d-c<=e||(h=c+Math.ceil((d-c)/e/2)*e,r(a,c,d,h,f),g.push(c,h,h,d))}function r(a,c,d,e,f){for(var g,h,k,m,n;d>c;){600<d-c&&(g=d-c+1,h=e-c+1,k=Math.log(g),
m=.5*Math.exp(2*k/3),n=.5*Math.sqrt(k*m*(g-m)/g)*(0>h-g/2?-1:1),k=Math.max(c,Math.floor(e-h*m/g+n)),h=Math.min(d,Math.floor(e+(g-h)*m/g+n)),r(a,k,h,e,f));g=a[e];h=c;m=d;t(a,c,e);for(0<f(a[d],g)&&t(a,c,d);h<m;){t(a,h,m);h++;for(m--;0>f(a[h],g);)h++;for(;0<f(a[m],g);)m--}0===f(a[c],g)?t(a,c,m):(m++,t(a,m,d));m<=e&&(c=m+1);e<=m&&(d=m-1)}}function t(a,c,d){var e=a[c];a[c]=a[d];a[d]=e}c.prototype={all:function(){return this.Kf(this.data,[])},search:function(a){var c=this.data,d=[],e=this.Sa;if(!p(a,c.bbox))return d;
for(var f=[],g,h,k,m;c;){g=0;for(h=c.children.length;g<h;g++)k=c.children[g],m=c.Ja?e(k):k.bbox,p(a,m)&&(c.Ja?d.push(k):n(a,m)?this.Kf(k,d):f.push(k));c=f.pop()}return d},load:function(a){if(!a||!a.length)return this;if(a.length<this.Pf){for(var c=0,d=a.length;c<d;c++)this.ua(a[c]);return this}a=this.Mf(a.slice(),0,a.length-1,0);this.data.children.length?this.data.height===a.height?this.Rf(this.data,a):(this.data.height<a.height&&(c=this.data,this.data=a,a=c),this.Of(a,this.data.height-a.height-1,
!0)):this.data=a;return this},ua:function(a){a&&this.Of(a,this.data.height-1);return this},clear:function(){this.data={children:[],height:1,bbox:[Infinity,Infinity,-Infinity,-Infinity],Ja:!0};return this},remove:function(a){if(!a)return this;for(var c=this.data,d=this.Sa(a),e=[],f=[],g,h,k,m;c||e.length;){c||(c=e.pop(),h=e[e.length-1],g=f.pop(),m=!0);if(c.Ja&&(k=c.children.indexOf(a),-1!==k)){c.children.splice(k,1);e.push(c);this.ki(e);break}m||c.Ja||!n(c.bbox,d)?h?(g++,c=h.children[g],m=!1):c=null:
(e.push(c),f.push(g),g=0,h=c,c=c.children[0])}return this},Sa:function(a){return a},Ne:function(a,c){return a[0]-c[0]},Oe:function(a,c){return a[1]-c[1]},toJSON:function(){return this.data},Kf:function(a,c){for(var d=[];a;)a.Ja?c.push.apply(c,a.children):d.push.apply(d,a.children),a=d.pop();return c},Mf:function(a,c,e,f){var g=e-c+1,h=this.Ke,k;if(g<=h)return k={children:a.slice(c,e+1),height:1,bbox:null,Ja:!0},d(k,this.Sa),k;f||(f=Math.ceil(Math.log(g)/Math.log(h)),h=Math.ceil(g/Math.pow(h,f-1)));
k={children:[],height:f,bbox:null};var g=Math.ceil(g/h),h=g*Math.ceil(Math.sqrt(h)),m,n,p;for(q(a,c,e,h,this.Ne);c<=e;c+=h)for(n=Math.min(c+h-1,e),q(a,c,n,g,this.Oe),m=c;m<=n;m+=g)p=Math.min(m+g-1,n),k.children.push(this.Mf(a,m,p,f-1));d(k,this.Sa);return k},ji:function(a,c,d,e){for(var f,g,h,m,n,p,q,r;;){e.push(c);if(c.Ja||e.length-1===d)break;q=r=Infinity;f=0;for(g=c.children.length;f<g;f++)h=c.children[f],n=k(h.bbox),p=h.bbox,p=(Math.max(p[2],a[2])-Math.min(p[0],a[0]))*(Math.max(p[3],a[3])-Math.min(p[1],
a[1]))-n,p<r?(r=p,q=n<q?n:q,m=h):p===r&&n<q&&(q=n,m=h);c=m}return c},Of:function(a,c,d){var e=this.Sa;d=d?a.bbox:e(a);var e=[],g=this.ji(d,this.data,c,e);g.children.push(a);for(f(g.bbox,d);0<=c;)if(e[c].children.length>this.Ke)this.pi(e,c),c--;else break;this.gi(d,e,c)},pi:function(a,c){var e=a[c],f=e.children.length,g=this.Pf;this.hi(e,g,f);f={children:e.children.splice(this.ii(e,g,f)),height:e.height};e.Ja&&(f.Ja=!0);d(e,this.Sa);d(f,this.Sa);c?a[c-1].children.push(f):this.Rf(e,f)},Rf:function(a,
c){this.data={children:[a,c],height:a.height+1};d(this.data,this.Sa)},ii:function(a,c,d){var f,g,h,m,n,p,q;n=p=Infinity;for(f=c;f<=d-c;f++)g=e(a,0,f,this.Sa),h=e(a,f,d,this.Sa),m=Math.max(0,Math.min(g[2],h[2])-Math.max(g[0],h[0]))*Math.max(0,Math.min(g[3],h[3])-Math.max(g[1],h[1])),g=k(g)+k(h),m<n?(n=m,q=f,p=g<p?g:p):m===n&&g<p&&(p=g,q=f);return q},hi:function(a,c,d){var e=a.Ja?this.Ne:g,f=a.Ja?this.Oe:h,k=this.Lf(a,c,d,e);c=this.Lf(a,c,d,f);k<c&&a.children.sort(e)},Lf:function(a,c,d,g){a.children.sort(g);
g=this.Sa;var h=e(a,0,c,g),k=e(a,d-c,d,g),n=m(h)+m(k),p,q;for(p=c;p<d-c;p++)q=a.children[p],f(h,a.Ja?g(q):q.bbox),n+=m(h);for(p=d-c-1;p>=c;p--)q=a.children[p],f(k,a.Ja?g(q):q.bbox),n+=m(k);return n},gi:function(a,c,d){for(;0<=d;d--)f(c[d].bbox,a)},ki:function(a){for(var c=a.length-1,e;0<=c;c--)0===a[c].children.length?0<c?(e=a[c-1].children,e.splice(e.indexOf(a[c]),1)):this.clear():d(a[c],this.Sa)},mi:function(a){var c=["return a"," - b",";"];this.Ne=new Function("a","b",c.join(a[0]));this.Oe=new Function("a",
"b",c.join(a[1]));this.Sa=new Function("a","return [a"+a.join(", a")+"];")}};"undefined"!==typeof a?a.ob=c:"undefined"!==typeof self?self.b=c:window.b=c})();Np=a.ob})();function Pp(a){this.a=Np(a);this.b={}}l=Pp.prototype;l.ua=function(a,c){var d=[a[0],a[1],a[2],a[3],c];this.a.ua(d);this.b[v(c)]=d};l.load=function(a,c){for(var d=Array(c.length),e=0,f=c.length;e<f;e++){var g=a[e],h=c[e],g=[g[0],g[1],g[2],g[3],h];d[e]=g;this.b[v(h)]=g}this.a.load(d)};l.remove=function(a){a=v(a);var c=this.b[a];delete this.b[a];return null!==this.a.remove(c)};function Qp(a,c,d){var e=v(d);$d(a.b[e].slice(0,4),c)||(a.remove(d),a.ua(c,d))}
function Rp(a){return a.a.all().map(function(a){return a[4]})}function Sp(a,c){return a.a.search(c).map(function(a){return a[4]})}l.forEach=function(a,c){return Tp(Rp(this),a,c)};function Up(a,c,d,e){return Tp(Sp(a,c),d,e)}function Tp(a,c,d){for(var e,f=0,g=a.length;f<g&&!(e=c.call(d,a[f]));f++);return e}l.Ba=function(){return Qb(this.b)};l.clear=function(){this.a.clear();this.b={}};l.J=function(){return this.a.data.bbox};function U(a){a=a||{};Fh.call(this,{attributions:a.attributions,logo:a.logo,projection:void 0,state:"ready",wrapX:void 0!==a.wrapX?a.wrapX:!0});this.V=xa;void 0!==a.loader?this.V=a.loader:void 0!==a.url&&(this.V=Lp(a.url,a.format));this.sa=void 0!==a.strategy?a.strategy:Mp;var c=void 0!==a.useSpatialIndex?a.useSpatialIndex:!0;this.a=c?new Pp:null;this.ca=new Pp;this.g={};this.i={};this.l={};this.v={};this.c=null;var d,e;a.features instanceof vg?(d=a.features,e=d.a):ga(a.features)&&(e=a.features);
c||void 0!==d||(d=new vg(e));void 0!==e&&Vp(this,e);void 0!==d&&Wp(this,d)}w(U,Fh);l=U.prototype;l.Fc=function(a){var c=v(a).toString();if(Xp(this,c,a)){Yp(this,c,a);var d=a.Y();d?(c=d.J(),this.a&&this.a.ua(c,a)):this.g[c]=a;this.u(new Zp("addfeature",a))}this.s()};function Yp(a,c,d){a.v[c]=[B(d,"change",a.Pg,!1,a),B(d,"propertychange",a.Pg,!1,a)]}function Xp(a,c,d){var e=!0,f=d.Fa();void 0!==f?f.toString()in a.i?e=!1:a.i[f.toString()]=d:a.l[c]=d;return e}l.Tb=function(a){Vp(this,a);this.s()};
function Vp(a,c){var d,e,f,g,h=[],k=[],m=[];e=0;for(f=c.length;e<f;e++)g=c[e],d=v(g).toString(),Xp(a,d,g)&&k.push(g);e=0;for(f=k.length;e<f;e++){g=k[e];d=v(g).toString();Yp(a,d,g);var n=g.Y();n?(d=n.J(),h.push(d),m.push(g)):a.g[d]=g}a.a&&a.a.load(h,m);e=0;for(f=k.length;e<f;e++)a.u(new Zp("addfeature",k[e]))}
function Wp(a,c){var d=!1;B(a,"addfeature",function(a){d||(d=!0,c.push(a.feature),d=!1)});B(a,"removefeature",function(a){d||(d=!0,c.remove(a.feature),d=!1)});B(c,"add",function(a){d||(a=a.element,d=!0,this.Fc(a),d=!1)},!1,a);B(c,"remove",function(a){d||(a=a.element,d=!0,this.hc(a),d=!1)},!1,a);a.c=c}
l.clear=function(a){if(a){for(var c in this.v)this.v[c].forEach(Zc);this.c||(this.v={},this.i={},this.l={})}else a=this.kh,this.a&&(this.a.forEach(a,this),Hb(this.g,a,this));this.c&&this.c.clear();this.a&&this.a.clear();this.ca.clear();this.g={};this.u(new Zp("clear"));this.s()};l.Te=function(a,c){if(this.a)return this.a.forEach(a,c);if(this.c)return this.c.forEach(a,c)};function $p(a,c,d){a.xc([c[0],c[1],c[0],c[1]],function(a){if(a.Y().Pe(c))return d.call(void 0,a)})}
l.xc=function(a,c,d){if(this.a)return Up(this.a,a,c,d);if(this.c)return this.c.forEach(c,d)};l.Fb=function(a,c,d,e){return this.xc(a,d,e)};l.Ue=function(a,c,d){return this.xc(a,function(e){if(e.Y().ya(a)&&(e=c.call(d,e)))return e})};l.Ze=function(){return this.c};l.Gc=function(){var a;this.c?a=this.c.a:this.a&&(a=Rp(this.a),Qb(this.g)||kb(a,Lb(this.g)));return a};l.Ye=function(a){var c=[];$p(this,a,function(a){c.push(a)});return c};l.Id=function(a){return Sp(this.a,a)};
l.We=function(a){var c=a[0],d=a[1],e=null,f=[NaN,NaN],g=Infinity,h=[-Infinity,-Infinity,Infinity,Infinity];Up(this.a,h,function(a){var m=a.Y(),n=g;g=m.$a(c,d,f,g);g<n&&(e=a,a=Math.sqrt(g),h[0]=c-a,h[1]=d-a,h[2]=c+a,h[3]=d+a)});return e};l.J=function(){return this.a.J()};l.Xe=function(a){a=this.i[a.toString()];return void 0!==a?a:null};
l.Pg=function(a){a=a.target;var c=v(a).toString(),d=a.Y();d?(d=d.J(),c in this.g?(delete this.g[c],this.a&&this.a.ua(d,a)):this.a&&Qp(this.a,d,a)):c in this.g||(this.a&&this.a.remove(a),this.g[c]=a);d=a.Fa();void 0!==d?(d=d.toString(),c in this.l?(delete this.l[c],this.i[d]=a):this.i[d]!==a&&(aq(this,a),this.i[d]=a)):c in this.l||(aq(this,a),this.l[c]=a);this.s();this.u(new Zp("changefeature",a))};l.Ba=function(){return this.a.Ba()&&Qb(this.g)};
l.ac=function(a,c,d){var e=this.ca;a=this.sa(a,c);var f,g;f=0;for(g=a.length;f<g;++f){var h=a[f];Up(e,h,function(a){return Xd(a.extent,h)})||(this.V.call(this,h,c,d),e.ua(h,{extent:h.slice()}))}};l.hc=function(a){var c=v(a).toString();c in this.g?delete this.g[c]:this.a&&this.a.remove(a);this.kh(a);this.s()};l.kh=function(a){var c=v(a).toString();this.v[c].forEach(Zc);delete this.v[c];var d=a.Fa();void 0!==d?delete this.i[d.toString()]:delete this.l[c];this.u(new Zp("removefeature",a))};
function aq(a,c){for(var d in a.i)if(a.i[d]===c){delete a.i[d];break}}function Zp(a,c){vc.call(this,a);this.feature=c}w(Zp,vc);function bq(a){this.c=a.source;this.sa=Dd();this.g=Ti();this.i=[0,0];this.H=null;Kn.call(this,{attributions:a.attributions,canvasFunction:sa(this.Ai,this),logo:a.logo,projection:a.projection,ratio:a.ratio,resolutions:a.resolutions,state:this.c.A});this.T=null;this.l=void 0;this.Kg(a.style);B(this.c,"change",this.Yl,void 0,this)}w(bq,Kn);l=bq.prototype;
l.Ai=function(a,c,d,e,f){var g=new Um(.5*c/d,a,c);this.c.ac(a,c,f);var h=!1;this.c.Fb(a,c,function(a){var e;if(!(e=h)){var f;(e=a.c)?f=e.call(a,c):this.l&&(f=this.l(a,c));if(f){var p,q=!1;e=0;for(p=f.length;e<p;++e)q=rn(g,a,f[e],qn(c,d),this.Xl,this)||q;e=q}else e=!1}h=e},this);Vm(g);if(h)return null;this.i[0]!=e[0]||this.i[1]!=e[1]?(this.g.canvas.width=e[0],this.g.canvas.height=e[1],this.i[0]=e[0],this.i[1]=e[1]):this.g.clearRect(0,0,e[0],e[1]);a=cq(this,le(a),c,d,e);Zm(g,this.g,d,a,0,{});this.H=
g;return this.g.canvas};l.ie=function(a,c,d,e,f){if(this.H){var g={};return Wm(this.H,a,c,0,e,function(a){var c=v(a).toString();if(!(c in g))return g[c]=!0,f(a)})}};l.Ul=function(){return this.c};l.Vl=function(){return this.T};l.Wl=function(){return this.l};function cq(a,c,d,e,f){return mk(a.sa,f[0]/2,f[1]/2,e/d,-e/d,0,-c[0],-c[1])}l.Xl=function(){this.s()};l.Yl=function(){Hh(this,this.c.A)};l.Kg=function(a){this.T=void 0!==a?a:km;this.l=a?im(this.T):void 0;this.s()};function dq(a){Am.call(this,a);this.g=null;this.i=Dd();this.c=this.f=null}w(dq,Am);l=dq.prototype;l.Ya=function(a,c,d,e){var f=this.a;return f.ga().ie(a,c.viewState.resolution,c.viewState.rotation,c.skippedFeatureUids,function(a){return d.call(e,a,f)})};
l.gc=function(a,c,d,e){if(this.ld())if(this.a.ga()instanceof bq){if(a=a.slice(),ok(c.pixelToCoordinateMatrix,a,a),this.Ya(a,c,te,this))return d.call(e,this.a)}else if(this.f||(this.f=Dd(),Jd(this.i,this.f)),c=Dm(a,this.f),this.c||(this.c=Ti(1,1)),this.c.clearRect(0,0,1,1),this.c.drawImage(this.ld(),c[0],c[1],1,1,0,0,1,1),0<this.c.getImageData(0,0,1,1).data[3])return d.call(e,this.a)};l.ld=function(){return this.g?this.g.b():null};l.$e=function(){return this.i};
l.he=function(a,c){var d=a.pixelRatio,e=a.viewState,f=e.center,g=e.resolution,h=e.rotation,k=this.a.ga(),m=a.viewHints,n=a.extent;void 0!==c.extent&&(n=ne(n,c.extent));m[0]||m[1]||ie(n)||(e=k.v(n,g,d,e.projection))&&rk(this,e)&&(this.g=e);if(this.g){var e=this.g,m=e.J(),n=e.aa(),p=e.c,g=d*n/(g*p);mk(this.i,d*a.size[0]/2,d*a.size[1]/2,g,g,h,p*(m[0]-f[0])/n,p*(f[1]-m[3])/n);this.f=null;tk(a.attributions,e.i);uk(a,k)}return!0};function eq(a){Am.call(this,a);this.c=this.i=null;this.D=!1;this.j=null;this.v=Dd();this.g=null;this.C=this.P=this.B=NaN;this.l=this.f=null;this.T=[0,0]}w(eq,Am);eq.prototype.ld=function(){return this.i};eq.prototype.$e=function(){return this.v};
eq.prototype.he=function(a,c){var d=a.pixelRatio,e=a.viewState,f=e.projection,g=this.a,h=g.ga(),k=h.Ua(f),m=h.Jd(),n=Ph(k,e.resolution),p=h.Yb(n,a.pixelRatio,f),q=p[0]/od(k.Ia(n),this.T)[0],r=k.aa(n),q=r/q,t=e.center,y;r==e.resolution?(t=wk(t,r,a.size),y=me(t,r,e.rotation,a.size)):y=a.extent;void 0!==c.extent&&(y=ne(y,c.extent));if(ie(y))return!1;var A=Nh(k,y,r),F=p[0]*rg(A),z=p[1]*qg(A),x,M;this.i?(x=this.i,M=this.j,this.c[0]<F||this.c[1]<z||this.P!==p[0]||this.C!==p[1]||this.D&&(this.c[0]>F||this.c[1]>
z)?(x.width=F,x.height=z,this.c=[F,z],this.D=!Em(this.c),this.f=null):(F=this.c[0],z=this.c[1],(x=n!=this.B)||(x=this.f,x=!(x.b<=A.b&&A.f<=x.f&&x.a<=A.a&&A.c<=x.c)),x&&(this.f=null))):(M=Ti(F,z),this.i=M.canvas,this.c=[F,z],this.j=M,this.D=!Em(this.c));var L,H;this.f?(z=this.f,F=rg(z)):(F/=p[0],z/=p[1],L=A.b-Math.floor((F-rg(A))/2),H=A.a-Math.floor((z-qg(A))/2),this.B=n,this.P=p[0],this.C=p[1],this.f=new og(L,L+F-1,H,H+z-1),this.l=Array(F*z),z=this.f);x={};x[n]={};var J=[],ra=this.Ed(h,f,x),Ga=g.c(),
K=Od(),oa=new og(0,0,0,0),Oa,La,Ib;for(H=A.b;H<=A.f;++H)for(Ib=A.a;Ib<=A.c;++Ib)La=h.Xb(n,H,Ib,d,f),L=La.state,2==L||4==L||3==L&&!Ga?x[n][hg(La.b)]=La:(Oa=Lh(k,La.b,ra,oa,K),Oa||(J.push(La),(Oa=Mh(k,La.b,oa,K))&&ra(n+1,Oa)));ra=0;for(Oa=J.length;ra<Oa;++ra)La=J[ra],H=p[0]*(La.b[1]-z.b),Ib=p[1]*(z.c-La.b[2]),M.clearRect(H,Ib,p[0],p[1]);J=Object.keys(x).map(Number);nb(J);var eb=h.sa,Mc=ge(k.xa([n,z.b,z.c],K)),oc,Ke,vj,Zh,Tf,tm,ra=0;for(Oa=J.length;ra<Oa;++ra)if(oc=J[ra],p=h.Yb(oc,d,f),Zh=x[oc],oc==
n)for(vj in Zh)La=Zh[vj],Ke=(La.b[2]-z.a)*F+(La.b[1]-z.b),this.l[Ke]!=La&&(H=p[0]*(La.b[1]-z.b),Ib=p[1]*(z.c-La.b[2]),L=La.state,4!=L&&(3!=L||Ga)&&eb||M.clearRect(H,Ib,p[0],p[1]),2==L&&M.drawImage(La.Ma(),m,m,p[0],p[1],H,Ib,p[0],p[1]),this.l[Ke]=La);else for(vj in oc=k.aa(oc)/r,Zh)for(La=Zh[vj],Ke=k.xa(La.b,K),H=(Ke[0]-Mc[0])/q,Ib=(Mc[1]-Ke[3])/q,tm=oc*p[0],Tf=oc*p[1],L=La.state,4!=L&&eb||M.clearRect(H,Ib,tm,Tf),2==L&&M.drawImage(La.Ma(),m,m,p[0],p[1],H,Ib,tm,Tf),La=mg(k,Ke,n,oa),L=Math.max(La.b,
z.b),Ib=Math.min(La.f,z.f),H=Math.max(La.a,z.a),La=Math.min(La.c,z.c);L<=Ib;++L)for(Tf=H;Tf<=La;++Tf)Ke=(Tf-z.a)*F+(L-z.b),this.l[Ke]=void 0;vk(a.usedTiles,h,n,A);xk(a,h,k,d,f,y,n,g.a());sk(a,h);uk(a,h);mk(this.v,d*a.size[0]/2,d*a.size[1]/2,d*q/e.resolution,d*q/e.resolution,e.rotation,(Mc[0]-t[0])/q,(t[1]-Mc[1])/q);this.g=null;return!0};
eq.prototype.gc=function(a,c,d,e){if(this.j&&(this.g||(this.g=Dd(),Jd(this.v,this.g)),a=Dm(a,this.g),0<this.j.getImageData(a[0],a[1],1,1).data[3]))return d.call(e,this.a)};function fq(a){Am.call(this,a);this.f=!1;this.D=-1;this.l=NaN;this.i=Od();this.c=this.j=null;this.g=Ti()}w(fq,Am);
fq.prototype.A=function(a,c,d){var e=a.extent,f=a.pixelRatio,g=c.Lb?a.skippedFeatureUids:{},h=a.viewState,k=h.projection,h=h.rotation,m=k.J(),n=this.a.ga(),p=Cm(this,a,0);Bm(this,"precompose",d,a,p);var q=this.c;if(q&&!q.Ba()){var r;ed(this.a,"render")?(this.g.canvas.width=d.canvas.width,this.g.canvas.height=d.canvas.height,r=this.g):r=d;var t=r.globalAlpha;r.globalAlpha=c.opacity;Zm(q,r,f,p,h,g);if(n.P&&k.a&&!Xd(m,e)){c=e[0];k=je(m);for(n=0;c<m[0];)--n,p=k*n,p=Cm(this,a,p),Zm(q,r,f,p,h,g),c+=k;n=
0;for(c=e[2];c>m[2];)++n,p=k*n,p=Cm(this,a,p),Zm(q,r,f,p,h,g),c-=k;p=Cm(this,a,0)}r!=d&&(Bm(this,"render",r,a,p),d.drawImage(r.canvas,0,0));r.globalAlpha=t}Bm(this,"postcompose",d,a,p)};fq.prototype.Ya=function(a,c,d,e){if(this.c){var f=c.viewState.resolution,g=c.viewState.rotation,h=this.a,k=c.layerStates[v(h)],m={};return Wm(this.c,a,f,g,k.Lb?c.skippedFeatureUids:{},function(a){var c=v(a).toString();if(!(c in m))return m[c]=!0,d.call(e,a,h)})}};fq.prototype.v=function(){qk(this)};
fq.prototype.he=function(a){function c(a){var c,e=a.c;e?c=e.call(a,n):(e=d.c)&&(c=e(a,n));if(c){if(c){var f,g=!1,e=0;for(f=c.length;e<f;++e)g=rn(r,a,c[e],qn(n,p),this.v,this)||g;a=g}else a=!1;this.f=this.f||a}}var d=this.a,e=d.ga();tk(a.attributions,e.j);uk(a,e);var f=a.viewHints[0],g=a.viewHints[1],h=d.C,k=d.P;if(!this.f&&!h&&f||!k&&g)return!0;var m=a.extent,k=a.viewState,f=k.projection,n=k.resolution,p=a.pixelRatio,g=d.b,q=d.a,h=d.get("renderOrder");void 0===h&&(h=pn);m=Sd(m,q*n);q=k.projection.J();
e.P&&k.projection.a&&!Xd(q,a.extent)&&(a=Math.max(je(m)/2,je(q)),m[0]=q[0]-a,m[2]=q[2]+a);if(!this.f&&this.l==n&&this.D==g&&this.j==h&&Xd(this.i,m))return!0;uc(this.c);this.c=null;this.f=!1;var r=new Um(.5*n/p,m,n,d.a);e.ac(m,n,f);if(h){var t=[];e.Fb(m,n,function(a){t.push(a)},this);nb(t,h);t.forEach(c,this)}else e.Fb(m,n,c,this);Vm(r);this.l=n;this.D=g;this.j=h;this.i=m;this.c=r;return!0};function gq(a,c){Ek.call(this,0,c);this.c=Ti();this.b=this.c.canvas;this.b.style.width="100%";this.b.style.height="100%";this.b.className="ol-unselectable";Ug(a,this.b,0);this.a=!0;this.g=Dd()}w(gq,Ek);gq.prototype.Qe=function(a){return a instanceof Wl?new dq(a):a instanceof E?new eq(a):a instanceof G?new fq(a):null};
function hq(a,c,d){var e=a.i,f=a.c;if(ed(e,c)){var g=d.extent,h=d.pixelRatio,k=d.viewState.rotation,m=d.pixelRatio,n=d.viewState,p=n.resolution;a=mk(a.g,a.b.width/2,a.b.height/2,m/p,-m/p,-n.rotation,-n.center[0],-n.center[1]);g=new mm(f,h,g,a,k);e.u(new hk(c,e,g,d,f,null));zm(g)}}gq.prototype.Z=function(){return"canvas"};
gq.prototype.we=function(a){if(a){var c=this.c,d=a.size[0]*a.pixelRatio,e=a.size[1]*a.pixelRatio;this.b.width!=d||this.b.height!=e?(this.b.width=d,this.b.height=e):c.clearRect(0,0,this.b.width,this.b.height);Fk(a);hq(this,"precompose",a);d=a.layerStatesArray;pb(d);var e=a.viewState.resolution,f,g,h,k;f=0;for(g=d.length;f<g;++f)k=d[f],h=k.layer,h=Hk(this,h),jk(k,e)&&"ready"==k.A&&h.he(a,k)&&h.A(a,k,c);hq(this,"postcompose",a);this.a||(ph(this.b,!0),this.a=!0);Ik(this,a);a.postRenderFunctions.push(Gk)}else this.a&&
(ph(this.b,!1),this.a=!1)};function iq(a,c){pk.call(this,a);this.target=c}w(iq,pk);iq.prototype.g=xa;iq.prototype.l=xa;function jq(a){var c=Rg("DIV");c.style.position="absolute";iq.call(this,a,c);this.c=null;this.f=Fd()}w(jq,iq);jq.prototype.Ya=function(a,c,d,e){var f=this.a;return f.ga().ie(a,c.viewState.resolution,c.viewState.rotation,c.skippedFeatureUids,function(a){return d.call(e,a,f)})};jq.prototype.g=function(){Tg(this.target);this.c=null};
jq.prototype.i=function(a,c){var d=a.viewState,e=d.center,f=d.resolution,g=d.rotation,h=this.c,k=this.a.ga(),m=a.viewHints,n=a.extent;void 0!==c.extent&&(n=ne(n,c.extent));m[0]||m[1]||ie(n)||(d=k.v(n,f,a.pixelRatio,d.projection))&&rk(this,d)&&(h=d);h&&(m=h.J(),n=h.aa(),d=Dd(),mk(d,a.size[0]/2,a.size[1]/2,n/f,n/f,g,(m[0]-e[0])/n,(e[1]-m[3])/n),h!=this.c&&(e=h.b(this),e.style.maxWidth="none",e.style.position="absolute",Tg(this.target),this.target.appendChild(e),this.c=h),nk(d,this.f)||(Xi(this.target,
d),Gd(this.f,d)),tk(a.attributions,h.i),uk(a,k));return!0};function kq(a){var c=Rg("DIV");c.style.position="absolute";iq.call(this,a,c);this.f=!0;this.D=1;this.j=0;this.c={}}w(kq,iq);kq.prototype.g=function(){Tg(this.target);this.j=0};
kq.prototype.i=function(a,c){if(!c.visible)return this.f&&(ph(this.target,!1),this.f=!1),!0;var d=a.pixelRatio,e=a.viewState,f=e.projection,g=this.a,h=g.ga(),k=h.Ua(f),m=h.Jd(),n=Ph(k,e.resolution),p=k.aa(n),q=e.center,r;p==e.resolution?(q=wk(q,p,a.size),r=me(q,p,e.rotation,a.size)):r=a.extent;void 0!==c.extent&&(r=ne(r,c.extent));var p=Nh(k,r,p),t={};t[n]={};var y=this.Ed(h,f,t),A=g.c(),F=Od(),z=new og(0,0,0,0),x,M,L,H;for(L=p.b;L<=p.f;++L)for(H=p.a;H<=p.c;++H)x=h.Xb(n,L,H,d,f),M=x.state,2==M?t[n][hg(x.b)]=
x:4==M||3==M&&!A||(M=Lh(k,x.b,y,z,F),M||(x=Mh(k,x.b,z,F))&&y(n+1,x));var J;if(this.j!=h.b){for(J in this.c)A=this.c[+J],Vg(A.target);this.c={};this.j=h.b}F=Object.keys(t).map(Number);nb(F);var y={},ra;L=0;for(H=F.length;L<H;++L){J=F[L];J in this.c?A=this.c[J]:(A=k.Qd(q,J),A=new lq(k,A),y[J]=!0,this.c[J]=A);J=t[J];for(ra in J){x=A;M=J[ra];var Ga=m,K=M.b,oa=K[0],Oa=K[1],La=K[2],K=hg(K);if(!(K in x.a)){var oa=od(x.f.Ia(oa),x.l),Ib=M.Ma(x),eb=Ib.style;eb.maxWidth="none";var Mc=void 0,oc=void 0;0<Ga?(Mc=
Rg("DIV"),oc=Mc.style,oc.overflow="hidden",oc.width=oa[0]+"px",oc.height=oa[1]+"px",eb.position="absolute",eb.left=-Ga+"px",eb.top=-Ga+"px",eb.width=oa[0]+2*Ga+"px",eb.height=oa[1]+2*Ga+"px",Mc.appendChild(Ib)):(eb.width=oa[0]+"px",eb.height=oa[1]+"px",Mc=Ib,oc=eb);oc.position="absolute";oc.left=(Oa-x.c[1])*oa[0]+"px";oc.top=(x.c[2]-La)*oa[1]+"px";x.b||(x.b=document.createDocumentFragment());x.b.appendChild(Mc);x.a[K]=M}}A.b&&(A.target.appendChild(A.b),A.b=null)}m=Object.keys(this.c).map(Number);
nb(m);L=Dd();ra=0;for(F=m.length;ra<F;++ra)if(J=m[ra],A=this.c[J],J in t)if(x=A.aa(),H=A.wa(),mk(L,a.size[0]/2,a.size[1]/2,x/e.resolution,x/e.resolution,e.rotation,(H[0]-q[0])/x,(q[1]-H[1])/x),A.setTransform(L),J in y){for(--J;0<=J;--J)if(J in this.c){H=this.c[J].target;H.parentNode&&H.parentNode.insertBefore(A.target,H.nextSibling);break}0>J&&Ug(this.target,A.target,0)}else{if(!a.viewHints[0]&&!a.viewHints[1]){M=mg(A.f,r,A.c[0],z);J=[];x=H=void 0;for(x in A.a)H=A.a[x],M.contains(H.b)||J.push(H);
Ga=M=void 0;M=0;for(Ga=J.length;M<Ga;++M)H=J[M],x=hg(H.b),Vg(H.Ma(A)),delete A.a[x]}}else Vg(A.target),delete this.c[J];c.opacity!=this.D&&(this.D=this.target.style.opacity=c.opacity);c.visible&&!this.f&&(ph(this.target,!0),this.f=!0);vk(a.usedTiles,h,n,p);xk(a,h,k,d,f,r,n,g.a());sk(a,h);uk(a,h);return!0};
function lq(a,c){this.target=Rg("DIV");this.target.style.position="absolute";this.target.style.width="100%";this.target.style.height="100%";this.f=a;this.c=c;this.i=ge(a.xa(c));this.j=a.aa(c[0]);this.a={};this.b=null;this.g=Fd();this.l=[0,0]}lq.prototype.wa=function(){return this.i};lq.prototype.aa=function(){return this.j};lq.prototype.setTransform=function(a){nk(a,this.g)||(Xi(this.target,a),Gd(this.g,a))};function mq(a){this.j=Ti();var c=this.j.canvas;c.style.maxWidth="none";c.style.position="absolute";iq.call(this,a,c);this.f=!1;this.B=-1;this.A=NaN;this.D=Od();this.c=this.v=null;this.P=Dd();this.C=Dd()}w(mq,iq);
mq.prototype.l=function(a,c){var d=a.viewState,e=d.center,f=d.rotation,g=d.resolution,d=a.pixelRatio,h=a.size[0],k=a.size[1],m=h*d,n=k*d,e=mk(this.P,d*h/2,d*k/2,d/g,-d/g,-f,-e[0],-e[1]),g=this.j;g.canvas.width=m;g.canvas.height=n;h=mk(this.C,0,0,1/d,1/d,0,-(m-h)/2*d,-(n-k)/2*d);Xi(g.canvas,h);nq(this,"precompose",a,e);(h=this.c)&&!h.Ba()&&(g.globalAlpha=c.opacity,Zm(h,g,d,e,f,c.Lb?a.skippedFeatureUids:{}),nq(this,"render",a,e));nq(this,"postcompose",a,e)};
function nq(a,c,d,e){var f=a.j;a=a.a;ed(a,c)&&(e=new mm(f,d.pixelRatio,d.extent,e,d.viewState.rotation),a.u(new hk(c,a,e,d,f,null)),zm(e))}mq.prototype.Ya=function(a,c,d,e){if(this.c){var f=c.viewState.resolution,g=c.viewState.rotation,h=this.a,k=c.layerStates[v(h)],m={};return Wm(this.c,a,f,g,k.Lb?c.skippedFeatureUids:{},function(a){var c=v(a).toString();if(!(c in m))return m[c]=!0,d.call(e,a,h)})}};mq.prototype.H=function(){qk(this)};
mq.prototype.i=function(a){function c(a){var c,e=a.c;e?c=e.call(a,m):(e=d.c)&&(c=e(a,m));if(c){if(c){var f,g=!1,e=0;for(f=c.length;e<f;++e)g=rn(p,a,c[e],qn(m,n),this.H,this)||g;a=g}else a=!1;this.f=this.f||a}}var d=this.a,e=d.ga();tk(a.attributions,e.j);uk(a,e);var f=a.viewHints[0],g=a.viewHints[1],h=d.C,k=d.P;if(!this.f&&!h&&f||!k&&g)return!0;var g=a.extent,h=a.viewState,f=h.projection,m=h.resolution,n=a.pixelRatio;a=d.b;k=d.a;h=d.get("renderOrder");void 0===h&&(h=pn);g=Sd(g,k*m);if(!this.f&&this.A==
m&&this.B==a&&this.v==h&&Xd(this.D,g))return!0;uc(this.c);this.c=null;this.f=!1;var p=new Um(.5*m/n,g,m,d.a);e.ac(g,m,f);if(h){var q=[];e.Fb(g,m,function(a){q.push(a)},this);nb(q,h);q.forEach(c,this)}else e.Fb(g,m,c,this);Vm(p);this.A=m;this.B=a;this.v=h;this.D=g;this.c=p;return!0};function oq(a,c){Ek.call(this,0,c);this.c=Ti();var d=this.c.canvas;d.style.position="absolute";d.style.width="100%";d.style.height="100%";d.className="ol-unselectable";Ug(a,d,0);this.g=Dd();this.b=Rg("DIV");this.b.className="ol-unselectable";d=this.b.style;d.position="absolute";d.width="100%";d.height="100%";B(this.b,"touchstart",xc);Ug(a,this.b,0);this.a=!0}w(oq,Ek);oq.prototype.W=function(){Vg(this.b);oq.ba.W.call(this)};
oq.prototype.Qe=function(a){if(a instanceof Wl)a=new jq(a);else if(a instanceof E)a=new kq(a);else if(a instanceof G)a=new mq(a);else return null;return a};function pq(a,c,d){var e=a.i;if(ed(e,c)){var f=d.extent,g=d.pixelRatio,h=d.viewState,k=h.rotation,m=a.c,n=m.canvas;mk(a.g,n.width/2,n.height/2,g/h.resolution,-g/h.resolution,-h.rotation,-h.center[0],-h.center[1]);a=new mm(m,g,f,a.g,k);e.u(new hk(c,e,a,d,m,null));zm(a)}}oq.prototype.Z=function(){return"dom"};
oq.prototype.we=function(a){if(a){var c=this.i;if(ed(c,"precompose")||ed(c,"postcompose")){var c=this.c.canvas,d=a.pixelRatio;c.width=a.size[0]*d;c.height=a.size[1]*d}pq(this,"precompose",a);c=a.layerStatesArray;pb(c);var d=a.viewState.resolution,e,f,g,h;e=0;for(f=c.length;e<f;++e)h=c[e],g=h.layer,g=Hk(this,g),Ug(this.b,g.target,e),jk(h,d)&&"ready"==h.A?g.i(a,h)&&g.l(a,h):g.g();var c=a.layerStates,k;for(k in this.f)k in c||(g=this.f[k],Vg(g.target));this.a||(ph(this.b,!0),this.a=!0);Fk(a);Ik(this,
a);a.postRenderFunctions.push(Gk);pq(this,"postcompose",a)}else this.a&&(ph(this.b,!1),this.a=!1)};function qq(a){this.b=a}function rq(a){this.b=a}w(rq,qq);rq.prototype.Z=function(){return 35632};function sq(a){this.b=a}w(sq,qq);sq.prototype.Z=function(){return 35633};function tq(){this.b="precision mediump float;varying vec2 a;varying float b;uniform float k;uniform sampler2D l;void main(void){vec4 texColor=texture2D(l,a);gl_FragColor.rgb=texColor.rgb;float alpha=texColor.a*b*k;if(alpha==0.0){discard;}gl_FragColor.a=alpha;}"}w(tq,rq);ea(tq);
function uq(){this.b="varying vec2 a;varying float b;attribute vec2 c;attribute vec2 d;attribute vec2 e;attribute float f;attribute float g;uniform mat4 h;uniform mat4 i;uniform mat4 j;void main(void){mat4 offsetMatrix=i;if(g==1.0){offsetMatrix=i*j;}vec4 offsets=offsetMatrix*vec4(e,0.,0.);gl_Position=h*vec4(c,0.,1.)+offsets;a=d;b=f;}"}w(uq,sq);ea(uq);
function vq(a,c){this.l=a.getUniformLocation(c,"j");this.D=a.getUniformLocation(c,"i");this.i=a.getUniformLocation(c,"k");this.j=a.getUniformLocation(c,"h");this.b=a.getAttribLocation(c,"e");this.a=a.getAttribLocation(c,"f");this.f=a.getAttribLocation(c,"c");this.c=a.getAttribLocation(c,"g");this.g=a.getAttribLocation(c,"d")};function wq(a){this.b=void 0!==a?a:[]};function xq(a,c){this.v=a;this.b=c;this.a={};this.i={};this.g={};this.l=this.D=this.f=this.j=null;(this.c=ub(wa,"OES_element_index_uint"))&&c.getExtension("OES_element_index_uint");B(this.v,"webglcontextlost",this.Ym,!1,this);B(this.v,"webglcontextrestored",this.Zm,!1,this)}
function yq(a,c,d){var e=a.b,f=d.b,g=v(d);if(g in a.a)e.bindBuffer(c,a.a[g].buffer);else{var h=e.createBuffer();e.bindBuffer(c,h);var k;34962==c?k=new Float32Array(f):34963==c&&(k=a.c?new Uint32Array(f):new Uint16Array(f));e.bufferData(c,k,35044);a.a[g]={a:d,buffer:h}}}function zq(a,c){var d=a.b,e=v(c),f=a.a[e];d.isContextLost()||d.deleteBuffer(f.buffer);delete a.a[e]}l=xq.prototype;
l.W=function(){var a=this.b;a.isContextLost()||(Hb(this.a,function(c){a.deleteBuffer(c.buffer)}),Hb(this.g,function(c){a.deleteProgram(c)}),Hb(this.i,function(c){a.deleteShader(c)}),a.deleteFramebuffer(this.f),a.deleteRenderbuffer(this.l),a.deleteTexture(this.D))};l.Xm=function(){return this.b};
function Aq(a){if(!a.f){var c=a.b,d=c.createFramebuffer();c.bindFramebuffer(c.FRAMEBUFFER,d);var e=Bq(c,1,1),f=c.createRenderbuffer();c.bindRenderbuffer(c.RENDERBUFFER,f);c.renderbufferStorage(c.RENDERBUFFER,c.DEPTH_COMPONENT16,1,1);c.framebufferTexture2D(c.FRAMEBUFFER,c.COLOR_ATTACHMENT0,c.TEXTURE_2D,e,0);c.framebufferRenderbuffer(c.FRAMEBUFFER,c.DEPTH_ATTACHMENT,c.RENDERBUFFER,f);c.bindTexture(c.TEXTURE_2D,null);c.bindRenderbuffer(c.RENDERBUFFER,null);c.bindFramebuffer(c.FRAMEBUFFER,null);a.f=d;
a.D=e;a.l=f}return a.f}function Cq(a,c){var d=v(c);if(d in a.i)return a.i[d];var e=a.b,f=e.createShader(c.Z());e.shaderSource(f,c.b);e.compileShader(f);return a.i[d]=f}function Dq(a,c,d){var e=v(c)+"/"+v(d);if(e in a.g)return a.g[e];var f=a.b,g=f.createProgram();f.attachShader(g,Cq(a,c));f.attachShader(g,Cq(a,d));f.linkProgram(g);return a.g[e]=g}l.Ym=function(){Rb(this.a);Rb(this.i);Rb(this.g);this.l=this.D=this.f=this.j=null};l.Zm=function(){};
l.qe=function(a){if(a==this.j)return!1;this.b.useProgram(a);this.j=a;return!0};function Eq(a,c,d){var e=a.createTexture();a.bindTexture(a.TEXTURE_2D,e);a.texParameteri(a.TEXTURE_2D,a.TEXTURE_MAG_FILTER,a.LINEAR);a.texParameteri(a.TEXTURE_2D,a.TEXTURE_MIN_FILTER,a.LINEAR);void 0!==c&&a.texParameteri(3553,10242,c);void 0!==d&&a.texParameteri(3553,10243,d);return e}function Bq(a,c,d){var e=Eq(a,void 0,void 0);a.texImage2D(a.TEXTURE_2D,0,a.RGBA,c,d,0,a.RGBA,a.UNSIGNED_BYTE,null);return e}
function Fq(a,c){var d=Eq(a,33071,33071);a.texImage2D(a.TEXTURE_2D,0,a.RGBA,a.RGBA,a.UNSIGNED_BYTE,c);return d};function Gq(a,c){this.P=this.C=void 0;this.D=le(c);this.B=[];this.i=[];this.ka=void 0;this.g=[];this.f=[];this.T=this.H=void 0;this.a=[];this.fa=this.l=null;this.ea=void 0;this.Da=Fd();this.sb=Fd();this.ca=this.V=void 0;this.tb=Fd();this.na=this.Ta=this.da=void 0;this.sa=[];this.j=[];this.b=[];this.A=null;this.c=[];this.v=[];this.ma=void 0}w(Gq,gk);
function Hq(a,c){var d=a.A,e=a.l,f=a.sa,g=a.j,h=c.b;return function(){if(!h.isContextLost()){var a,m;a=0;for(m=f.length;a<m;++a)h.deleteTexture(f[a]);a=0;for(m=g.length;a<m;++a)h.deleteTexture(g[a])}zq(c,d);zq(c,e)}}
function Iq(a,c,d,e){var f=a.C,g=a.P,h=a.ka,k=a.H,m=a.T,n=a.ea,p=a.V,q=a.ca,r=a.da?1:0,t=a.Ta,y=a.na,A=a.ma,F=Math.cos(t),t=Math.sin(t),z=a.a.length,x=a.b.length,M,L,H,J,ra,Ga;for(M=0;M<d;M+=e)ra=c[M]-a.D[0],Ga=c[M+1]-a.D[1],L=x/8,H=-y*f,J=-y*(h-g),a.b[x++]=ra,a.b[x++]=Ga,a.b[x++]=H*F-J*t,a.b[x++]=H*t+J*F,a.b[x++]=p/m,a.b[x++]=(q+h)/k,a.b[x++]=n,a.b[x++]=r,H=y*(A-f),J=-y*(h-g),a.b[x++]=ra,a.b[x++]=Ga,a.b[x++]=H*F-J*t,a.b[x++]=H*t+J*F,a.b[x++]=(p+A)/m,a.b[x++]=(q+h)/k,a.b[x++]=n,a.b[x++]=r,H=y*(A-
f),J=y*g,a.b[x++]=ra,a.b[x++]=Ga,a.b[x++]=H*F-J*t,a.b[x++]=H*t+J*F,a.b[x++]=(p+A)/m,a.b[x++]=q/k,a.b[x++]=n,a.b[x++]=r,H=-y*f,J=y*g,a.b[x++]=ra,a.b[x++]=Ga,a.b[x++]=H*F-J*t,a.b[x++]=H*t+J*F,a.b[x++]=p/m,a.b[x++]=q/k,a.b[x++]=n,a.b[x++]=r,a.a[z++]=L,a.a[z++]=L+1,a.a[z++]=L+2,a.a[z++]=L,a.a[z++]=L+2,a.a[z++]=L+3}Gq.prototype.ub=function(a,c){this.c.push(this.a.length);this.v.push(c);var d=a.o;Iq(this,d,d.length,a.I)};
Gq.prototype.vb=function(a,c){this.c.push(this.a.length);this.v.push(c);var d=a.o;Iq(this,d,d.length,a.I)};function Jq(a,c){var d=c.b;a.B.push(a.a.length);a.i.push(a.a.length);a.A=new wq(a.b);yq(c,34962,a.A);a.l=new wq(a.a);yq(c,34963,a.l);var e={};Kq(a.sa,a.g,e,d);Kq(a.j,a.f,e,d);a.C=void 0;a.P=void 0;a.ka=void 0;a.g=null;a.f=null;a.H=void 0;a.T=void 0;a.a=null;a.ea=void 0;a.V=void 0;a.ca=void 0;a.da=void 0;a.Ta=void 0;a.na=void 0;a.b=null;a.ma=void 0}
function Kq(a,c,d,e){var f,g,h,k=c.length;for(h=0;h<k;++h)f=c[h],g=v(f).toString(),g in d?f=d[g]:(f=Fq(e,f),d[g]=f),a[h]=f}
function Lq(a,c,d,e,f,g,h,k,m,n,p){var q=c.b;yq(c,34962,a.A);yq(c,34963,a.l);var r=tq.Hb(),t=uq.Hb(),t=Dq(c,r,t);a.fa?r=a.fa:(r=new vq(q,t),a.fa=r);c.qe(t);q.enableVertexAttribArray(r.f);q.vertexAttribPointer(r.f,2,5126,!1,32,0);q.enableVertexAttribArray(r.b);q.vertexAttribPointer(r.b,2,5126,!1,32,8);q.enableVertexAttribArray(r.g);q.vertexAttribPointer(r.g,2,5126,!1,32,16);q.enableVertexAttribArray(r.a);q.vertexAttribPointer(r.a,1,5126,!1,32,24);q.enableVertexAttribArray(r.c);q.vertexAttribPointer(r.c,
1,5126,!1,32,28);t=a.tb;mk(t,0,0,2/(e*g[0]),2/(e*g[1]),-f,-(d[0]-a.D[0]),-(d[1]-a.D[1]));d=a.sb;e=2/g[0];g=2/g[1];Hd(d);d[0]=e;d[5]=g;d[10]=1;d[15]=1;g=a.Da;Hd(g);0!==f&&Md(g,-f);q.uniformMatrix4fv(r.j,!1,t);q.uniformMatrix4fv(r.D,!1,d);q.uniformMatrix4fv(r.l,!1,g);q.uniform1f(r.i,h);var y;if(void 0===m)Mq(a,q,c,k,a.sa,a.B);else{if(n)a:{f=c.c?5125:5123;c=c.c?4:2;g=a.c.length-1;for(h=a.j.length-1;0<=h;--h)for(q.bindTexture(3553,a.j[h]),n=0<h?a.i[h-1]:0,t=a.i[h];0<=g&&a.c[g]>=n;){y=a.c[g];d=a.v[g];
e=v(d).toString();if(void 0===k[e]&&d.Y()&&(void 0===p||oe(p,d.Y().J()))&&(q.clear(q.COLOR_BUFFER_BIT|q.DEPTH_BUFFER_BIT),q.drawElements(4,t-y,f,y*c),t=m(d))){a=t;break a}t=y;g--}a=void 0}else q.clear(q.COLOR_BUFFER_BIT|q.DEPTH_BUFFER_BIT),Mq(a,q,c,k,a.j,a.i),a=(a=m(null))?a:void 0;y=a}q.disableVertexAttribArray(r.f);q.disableVertexAttribArray(r.b);q.disableVertexAttribArray(r.g);q.disableVertexAttribArray(r.a);q.disableVertexAttribArray(r.c);return y}
function Mq(a,c,d,e,f,g){var h=d.c?5125:5123;d=d.c?4:2;if(Qb(e)){var k;a=0;e=f.length;for(k=0;a<e;++a){c.bindTexture(3553,f[a]);var m=g[a];c.drawElements(4,m-k,h,k*d);k=m}}else{k=0;var n,m=0;for(n=f.length;m<n;++m){c.bindTexture(3553,f[m]);for(var p=0<m?g[m-1]:0,q=g[m],r=p;k<a.c.length&&a.c[k]<=q;){var t=v(a.v[k]).toString();void 0!==e[t]?(r!==p&&c.drawElements(4,p-r,h,r*d),p=r=k===a.c.length-1?q:a.c[k+1]):p=k===a.c.length-1?q:a.c[k+1];k++}r!==p&&c.drawElements(4,p-r,h,r*d)}}}
Gq.prototype.ib=function(a){var c=a.Gb(),d=a.Pb(1),e=a.Kd(),f=a.je(1),g=a.A,h=a.wa(),k=a.C,m=a.D,n=a.rb();a=a.v;var p;0===this.g.length?this.g.push(d):(p=this.g[this.g.length-1],v(p)!=v(d)&&(this.B.push(this.a.length),this.g.push(d)));0===this.f.length?this.f.push(f):(p=this.f[this.f.length-1],v(p)!=v(f)&&(this.i.push(this.a.length),this.f.push(f)));this.C=c[0];this.P=c[1];this.ka=n[1];this.H=e[1];this.T=e[0];this.ea=g;this.V=h[0];this.ca=h[1];this.Ta=m;this.da=k;this.na=a;this.ma=n[0]};
function Nq(a,c,d){this.f=c;this.g=a;this.c=d;this.a={}}function Oq(a,c){var d=[],e;for(e in a.a)d.push(Hq(a.a[e],c));return xe.apply(null,d)}function Pq(a,c){for(var d in a.a)Jq(a.a[d],c)}Nq.prototype.b=function(a,c){var d=this.a[c];void 0===d&&(d=new Qq[c](this.g,this.f),this.a[c]=d);return d};Nq.prototype.Ba=function(){return Qb(this.a)};function Rq(a,c,d,e,f,g,h,k,m,n){var p=Sq,q,r;for(q=Fm.length-1;0<=q;--q)if(r=a.a[Fm[q]],void 0!==r&&(r=Lq(r,c,d,e,f,p,g,h,k,m,n)))return r}
function Tq(a,c,d,e,f,g,h,k){var m=d.b;m.bindFramebuffer(m.FRAMEBUFFER,Aq(d));var n;void 0!==a.c&&(n=Sd(Zd(c),e*a.c));return Rq(a,d,c,e,f,g,h,function(a){var c=new Uint8Array(4);m.readPixels(0,0,1,1,m.RGBA,m.UNSIGNED_BYTE,c);if(0<c[3]&&(a=k(a)))return a},!0,n)}function Uq(a,c,d,e,f,g,h){var k=d.b;k.bindFramebuffer(k.FRAMEBUFFER,Aq(d));return void 0!==Rq(a,d,c,e,f,g,h,function(){var a=new Uint8Array(4);k.readPixels(0,0,1,1,k.RGBA,k.UNSIGNED_BYTE,a);return 0<a[3]},!1)}var Qq={Image:Gq},Sq=[1,1];function Vq(a,c,d,e,f,g){this.a=a;this.g=c;this.f=g;this.l=f;this.j=e;this.i=d;this.c=null;this.b={}}w(Vq,gk);l=Vq.prototype;l.ad=function(a,c){var d=a.toString(),e=this.b[d];void 0!==e?e.push(c):this.b[d]=[c]};l.tc=function(){};l.Re=function(a,c){var d=(0,c.f)(a);if(d&&oe(this.f,d.J())){var e=c.b;void 0===e&&(e=0);this.ad(e,function(a){a.Qa(c.g,c.c);a.ib(c.i);a.Ra(c.a);var e=Wq[d.Z()];e&&e.call(a,d,null)})}};
l.Fd=function(a,c){var d=a.f,e,f;e=0;for(f=d.length;e<f;++e){var g=d[e],h=Wq[g.Z()];h&&h.call(this,g,c)}};l.vb=function(a,c){var d=this.a,e=(new Nq(1,this.f)).b(0,"Image");e.ib(this.c);e.vb(a,c);Jq(e,d);Lq(e,this.a,this.g,this.i,this.j,this.l,1,{},void 0,!1);Hq(e,d)()};l.Eb=function(){};l.uc=function(){};l.ub=function(a,c){var d=this.a,e=(new Nq(1,this.f)).b(0,"Image");e.ib(this.c);e.ub(a,c);Jq(e,d);Lq(e,this.a,this.g,this.i,this.j,this.l,1,{},void 0,!1);Hq(e,d)()};l.vc=function(){};l.wc=function(){};
l.wb=function(){};l.Qa=function(){};l.ib=function(a){this.c=a};l.Ra=function(){};var Wq={Point:Vq.prototype.vb,MultiPoint:Vq.prototype.ub,GeometryCollection:Vq.prototype.Fd};function Xq(){this.b="precision mediump float;varying vec2 a;uniform float f;uniform sampler2D g;void main(void){vec4 texColor=texture2D(g,a);gl_FragColor.rgb=texColor.rgb;gl_FragColor.a=texColor.a*f;}"}w(Xq,rq);ea(Xq);function Yq(){this.b="varying vec2 a;attribute vec2 b;attribute vec2 c;uniform mat4 d;uniform mat4 e;void main(void){gl_Position=e*vec4(b,0.,1.);a=(d*vec4(c,0.,1.)).st;}"}w(Yq,sq);ea(Yq);
function Zq(a,c){this.c=a.getUniformLocation(c,"f");this.f=a.getUniformLocation(c,"e");this.i=a.getUniformLocation(c,"d");this.g=a.getUniformLocation(c,"g");this.b=a.getAttribLocation(c,"b");this.a=a.getAttribLocation(c,"c")};function $q(a,c){pk.call(this,c);this.c=a;this.T=new wq([-1,-1,0,0,1,-1,1,0,-1,1,0,1,1,1,1,1]);this.g=this.Za=null;this.i=void 0;this.D=Dd();this.A=Fd();this.v=null}w($q,pk);
function ar(a,c,d){var e=a.c.c;if(void 0===a.i||a.i!=d){c.postRenderFunctions.push(ta(function(a,c,d){a.isContextLost()||(a.deleteFramebuffer(c),a.deleteTexture(d))},e,a.g,a.Za));c=Bq(e,d,d);var f=e.createFramebuffer();e.bindFramebuffer(36160,f);e.framebufferTexture2D(36160,36064,3553,c,0);a.Za=c;a.g=f;a.i=d}else e.bindFramebuffer(36160,a.g)}
$q.prototype.Jg=function(a,c,d){br(this,"precompose",d,a);yq(d,34962,this.T);var e=d.b,f=Xq.Hb(),g=Yq.Hb(),f=Dq(d,f,g);this.v?g=this.v:this.v=g=new Zq(e,f);d.qe(f)&&(e.enableVertexAttribArray(g.b),e.vertexAttribPointer(g.b,2,5126,!1,16,0),e.enableVertexAttribArray(g.a),e.vertexAttribPointer(g.a,2,5126,!1,16,8),e.uniform1i(g.g,0));e.uniformMatrix4fv(g.i,!1,this.D);e.uniformMatrix4fv(g.f,!1,this.A);e.uniform1f(g.c,c.opacity);e.bindTexture(3553,this.Za);e.drawArrays(5,0,4);br(this,"postcompose",d,a)};
function br(a,c,d,e){a=a.a;if(ed(a,c)){var f=e.viewState;a.u(new hk(c,a,new Vq(d,f.center,f.resolution,f.rotation,e.size,e.extent),e,null,d))}}$q.prototype.pf=function(){this.g=this.Za=null;this.i=void 0};function cr(a,c){$q.call(this,a,c);this.l=this.j=this.f=null}w(cr,$q);function dr(a,c){var d=c.b();return Fq(a.c.c,d)}cr.prototype.Ya=function(a,c,d,e){var f=this.a;return f.ga().ie(a,c.viewState.resolution,c.viewState.rotation,c.skippedFeatureUids,function(a){return d.call(e,a,f)})};
cr.prototype.qf=function(a,c){var d=this.c.c,e=a.pixelRatio,f=a.viewState,g=f.center,h=f.resolution,k=f.rotation,m=this.f,n=this.Za,p=this.a.ga(),q=a.viewHints,r=a.extent;void 0!==c.extent&&(r=ne(r,c.extent));q[0]||q[1]||ie(r)||(f=p.v(r,h,e,f.projection))&&rk(this,f)&&(m=f,n=dr(this,f),this.Za&&a.postRenderFunctions.push(ta(function(a,c){a.isContextLost()||a.deleteTexture(c)},d,this.Za)));m&&(d=this.c.g.v,er(this,d.width,d.height,e,g,h,k,m.J()),this.l=null,e=this.D,Hd(e),Ld(e,1,-1),Kd(e,0,-1),this.f=
m,this.Za=n,tk(a.attributions,m.i),uk(a,p));return!0};function er(a,c,d,e,f,g,h,k){c*=g;d*=g;a=a.A;Hd(a);Ld(a,2*e/c,2*e/d);Md(a,-h);Kd(a,k[0]-f[0],k[1]-f[1]);Ld(a,(k[2]-k[0])/2,(k[3]-k[1])/2);Kd(a,1,1)}cr.prototype.ge=function(a,c){return void 0!==this.Ya(a,c,te,this)};
cr.prototype.gc=function(a,c,d,e){if(this.f&&this.f.b())if(this.a.ga()instanceof bq){if(a=a.slice(),ok(c.pixelToCoordinateMatrix,a,a),this.Ya(a,c,te,this))return d.call(e,this.a)}else{var f=[this.f.b().width,this.f.b().height];if(!this.l){var g=c.size;c=Dd();Hd(c);Kd(c,-1,-1);Ld(c,2/g[0],2/g[1]);Kd(c,0,g[1]);Ld(c,1,-1);g=Dd();Jd(this.A,g);var h=Dd();Hd(h);Kd(h,0,f[1]);Ld(h,1,-1);Ld(h,f[0]/2,f[1]/2);Kd(h,1,1);var k=Dd();Id(h,g,k);Id(k,c,k);this.l=k}c=[0,0];ok(this.l,a,c);if(!(0>c[0]||c[0]>f[0]||0>
c[1]||c[1]>f[1])&&(this.j||(this.j=Ti(1,1)),this.j.clearRect(0,0,1,1),this.j.drawImage(this.f.b(),c[0],c[1],1,1,0,0,1,1),0<this.j.getImageData(0,0,1,1).data[3]))return d.call(e,this.a)}};function fr(){this.b="precision mediump float;varying vec2 a;uniform sampler2D e;void main(void){gl_FragColor=texture2D(e,a);}"}w(fr,rq);ea(fr);function gr(){this.b="varying vec2 a;attribute vec2 b;attribute vec2 c;uniform vec4 d;void main(void){gl_Position=vec4(b*d.xy+d.zw,0.,1.);a=c;}"}w(gr,sq);ea(gr);function hr(a,c){this.c=a.getUniformLocation(c,"e");this.f=a.getUniformLocation(c,"d");this.b=a.getAttribLocation(c,"b");this.a=a.getAttribLocation(c,"c")};function ir(a,c){$q.call(this,a,c);this.P=fr.Hb();this.ea=gr.Hb();this.f=null;this.C=new wq([0,0,0,1,1,0,1,1,0,1,0,0,1,1,1,0]);this.B=this.j=null;this.l=-1;this.H=[0,0]}w(ir,$q);l=ir.prototype;l.W=function(){zq(this.c.g,this.C);ir.ba.W.call(this)};l.Ed=function(a,c,d){var e=this.c;return function(f,g){return Uh(a,c,f,g,function(a){var c=zh(e.a,a.qb());c&&(d[f]||(d[f]={}),d[f][a.b.toString()]=a);return c})}};l.pf=function(){ir.ba.pf.call(this);this.f=null};
l.qf=function(a,c,d){var e=this.c,f=d.b,g=a.viewState,h=g.projection,k=this.a,m=k.ga(),n=m.Ua(h),p=Ph(n,g.resolution),q=n.aa(p),r=m.Yb(p,a.pixelRatio,h),t=r[0]/od(n.Ia(p),this.H)[0],y=q/t,A=m.Jd(),F=g.center,z;q==g.resolution?(F=wk(F,q,a.size),z=me(F,q,g.rotation,a.size)):z=a.extent;q=Nh(n,z,q);if(this.j&&pg(this.j,q)&&this.l==m.b)y=this.B;else{var x=[rg(q),qg(q)],M=Math.pow(2,Math.ceil(Math.log(Math.max(x[0]*r[0],x[1]*r[1]))/Math.LN2)),x=y*M,L=n.wa(p),H=L[0]+q.b*r[0]*y,y=L[1]+q.a*r[1]*y,y=[H,y,H+
x,y+x];ar(this,a,M);f.viewport(0,0,M,M);f.clearColor(0,0,0,0);f.clear(16384);f.disable(3042);M=Dq(d,this.P,this.ea);d.qe(M);this.f||(this.f=new hr(f,M));yq(d,34962,this.C);f.enableVertexAttribArray(this.f.b);f.vertexAttribPointer(this.f.b,2,5126,!1,16,0);f.enableVertexAttribArray(this.f.a);f.vertexAttribPointer(this.f.a,2,5126,!1,16,8);f.uniform1i(this.f.c,0);d={};d[p]={};var J=this.Ed(m,h,d),ra=k.c(),M=!0,H=Od(),Ga=new og(0,0,0,0),K,oa,Oa;for(oa=q.b;oa<=q.f;++oa)for(Oa=q.a;Oa<=q.c;++Oa){L=m.Xb(p,
oa,Oa,t,h);if(void 0!==c.extent&&(K=n.xa(L.b,H),!oe(K,c.extent)))continue;K=L.state;if(2==K){if(zh(e.a,L.qb())){d[p][hg(L.b)]=L;continue}}else if(4==K||3==K&&!ra)continue;M=!1;K=Lh(n,L.b,J,Ga,H);K||(L=Mh(n,L.b,Ga,H))&&J(p+1,L)}c=Object.keys(d).map(Number);nb(c);for(var J=new Float32Array(4),La,Ib,eb,ra=0,Ga=c.length;ra<Ga;++ra)for(La in Ib=d[c[ra]],Ib)L=Ib[La],K=n.xa(L.b,H),oa=2*(K[2]-K[0])/x,Oa=2*(K[3]-K[1])/x,eb=2*(K[0]-y[0])/x-1,K=2*(K[1]-y[1])/x-1,Cd(J,oa,Oa,eb,K),f.uniform4fv(this.f.f,J),jr(e,
L,r,A*t),f.drawArrays(5,0,4);M?(this.j=q,this.B=y,this.l=m.b):(this.B=this.j=null,this.l=-1,a.animate=!0)}vk(a.usedTiles,m,p,q);var Mc=e.l;xk(a,m,n,t,h,z,p,k.a(),function(a){var c;(c=2!=a.state||zh(e.a,a.qb()))||(c=a.qb()in Mc.c);c||yk(Mc,[a,jg(n,a.b),n.aa(a.b[0]),r,A*t])},this);sk(a,m);uk(a,m);f=this.D;Hd(f);Kd(f,(F[0]-y[0])/(y[2]-y[0]),(F[1]-y[1])/(y[3]-y[1]));0!==g.rotation&&Md(f,g.rotation);Ld(f,a.size[0]*g.resolution/(y[2]-y[0]),a.size[1]*g.resolution/(y[3]-y[1]));Kd(f,-.5,-.5);return!0};
l.gc=function(a,c,d,e){if(this.g){var f=[0,0];ok(this.D,[a[0]/c.size[0],(c.size[1]-a[1])/c.size[1]],f);a=[f[0]*this.i,f[1]*this.i];c=this.c.g.b;c.bindFramebuffer(c.FRAMEBUFFER,this.g);f=new Uint8Array(4);c.readPixels(a[0],a[1],1,1,c.RGBA,c.UNSIGNED_BYTE,f);if(0<f[3])return d.call(e,this.a)}};function kr(a,c){$q.call(this,a,c);this.l=!1;this.H=-1;this.P=NaN;this.B=Od();this.j=this.f=this.C=null}w(kr,$q);l=kr.prototype;l.Jg=function(a,c,d){this.j=c;var e=a.viewState,f=this.f;if(f&&!f.Ba()){var g=e.center,h=e.resolution,e=e.rotation,k=a.size,m=c.opacity;a=c.Lb?a.skippedFeatureUids:{};var n,p;c=0;for(n=Fm.length;c<n;++c)p=f.a[Fm[c]],void 0!==p&&Lq(p,d,g,h,e,k,m,a,void 0,!1)}};l.W=function(){var a=this.f;a&&(Oq(a,this.c.g)(),this.f=null);kr.ba.W.call(this)};
l.Ya=function(a,c,d,e){if(this.f&&this.j){var f=c.viewState,g=this.a,h=this.j,k={};return Tq(this.f,a,this.c.g,f.resolution,f.rotation,h.opacity,h.Lb?c.skippedFeatureUids:{},function(a){var c=v(a).toString();if(!(c in k))return k[c]=!0,d.call(e,a,g)})}};l.ge=function(a,c){if(this.f&&this.j){var d=c.viewState;return Uq(this.f,a,this.c.g,d.resolution,d.rotation,this.j.opacity,c.skippedFeatureUids)}return!1};
l.gc=function(a,c,d,e){a=a.slice();ok(c.pixelToCoordinateMatrix,a,a);if(this.ge(a,c))return d.call(e,this.a)};l.Ol=function(){qk(this)};
l.qf=function(a,c,d){function e(a){var c,d=a.c;d?c=d.call(a,n):(d=f.c)&&(c=d(a,n));if(c){if(c){var e,g=!1,d=0;for(e=c.length;d<e;++d)g=rn(r,a,c[d],qn(n,p),this.Ol,this)||g;a=g}else a=!1;this.l=this.l||a}}var f=this.a;c=f.ga();tk(a.attributions,c.j);uk(a,c);var g=a.viewHints[0],h=a.viewHints[1],k=f.C,m=f.P;if(!this.l&&!k&&g||!m&&h)return!0;var h=a.extent,k=a.viewState,g=k.projection,n=k.resolution,p=a.pixelRatio,k=f.b,q=f.a,m=f.get("renderOrder");void 0===m&&(m=pn);h=Sd(h,q*n);if(!this.l&&this.P==
n&&this.H==k&&this.C==m&&Xd(this.B,h))return!0;this.f&&a.postRenderFunctions.push(Oq(this.f,d));this.l=!1;var r=new Nq(.5*n/p,h,f.a);c.ac(h,n,g);if(m){var t=[];c.Fb(h,n,function(a){t.push(a)},this);nb(t,m);t.forEach(e,this)}else c.Fb(h,n,e,this);Pq(r,d);this.P=n;this.H=k;this.C=m;this.B=h;this.f=r;return!0};function lr(a,c){Ek.call(this,0,c);this.b=Rg("CANVAS");this.b.style.width="100%";this.b.style.height="100%";this.b.className="ol-unselectable";Ug(a,this.b,0);this.B=this.C=0;this.P=Ti();this.D=!0;this.c=Zi(this.b,{antialias:!0,depth:!1,failIfMajorPerformanceCaveat:!0,preserveDrawingBuffer:!1,stencil:!0});this.g=new xq(this.b,this.c);B(this.b,"webglcontextlost",this.Ml,!1,this);B(this.b,"webglcontextrestored",this.Nl,!1,this);this.a=new yh;this.A=null;this.l=new Jk(sa(function(a){var c=a[1];a=a[2];
var f=c[0]-this.A[0],c=c[1]-this.A[1];return 65536*Math.log(a)+Math.sqrt(f*f+c*c)/a},this),function(a){return a[0].qb()});this.H=sa(function(){if(!this.l.Ba()){Nk(this.l);var a=Kk(this.l);jr(this,a[0],a[3],a[4])}},this);this.j=0;mr(this)}w(lr,Ek);
function jr(a,c,d,e){var f=a.c,g=c.qb();if(zh(a.a,g))a=a.a.get(g),f.bindTexture(3553,a.Za),9729!=a.pg&&(f.texParameteri(3553,10240,9729),a.pg=9729),9729!=a.qg&&(f.texParameteri(3553,10240,9729),a.qg=9729);else{var h=f.createTexture();f.bindTexture(3553,h);if(0<e){var k=a.P.canvas,m=a.P;a.C!==d[0]||a.B!==d[1]?(k.width=d[0],k.height=d[1],a.C=d[0],a.B=d[1]):m.clearRect(0,0,d[0],d[1]);m.drawImage(c.Ma(),e,e,d[0],d[1],0,0,d[0],d[1]);f.texImage2D(3553,0,6408,6408,5121,k)}else f.texImage2D(3553,0,6408,6408,
5121,c.Ma());f.texParameteri(3553,10240,9729);f.texParameteri(3553,10241,9729);f.texParameteri(3553,10242,33071);f.texParameteri(3553,10243,33071);a.a.set(g,{Za:h,pg:9729,qg:9729})}}l=lr.prototype;l.Qe=function(a){return a instanceof Wl?new cr(this,a):a instanceof E?new ir(this,a):a instanceof G?new kr(this,a):null};
function nr(a,c,d){var e=a.i;if(ed(e,c)){var f=a.g;a=d.viewState;a=new Vq(f,a.center,a.resolution,a.rotation,d.size,d.extent);e.u(new hk(c,e,a,d,null,f));c=Object.keys(a.b).map(Number);nb(c);var g,h;d=0;for(e=c.length;d<e;++d)for(f=a.b[c[d].toString()],g=0,h=f.length;g<h;++g)f[g](a)}}l.W=function(){var a=this.c;a.isContextLost()||this.a.forEach(function(c){c&&a.deleteTexture(c.Za)});uc(this.g);lr.ba.W.call(this)};
l.Ei=function(a,c){for(var d=this.c,e;1024<this.a.Vb()-this.j;){if(e=this.a.b.oc)d.deleteTexture(e.Za);else if(+this.a.b.Yd==c.index)break;else--this.j;this.a.pop()}};l.Z=function(){return"webgl"};l.Ml=function(a){a.preventDefault();this.a.clear();this.j=0;Hb(this.f,function(a){a.pf()})};l.Nl=function(){mr(this);this.i.render()};function mr(a){a=a.c;a.activeTexture(33984);a.blendFuncSeparate(770,771,1,771);a.disable(2884);a.disable(2929);a.disable(3089);a.disable(2960)}
l.we=function(a){var c=this.g,d=this.c;if(d.isContextLost())return!1;if(!a)return this.D&&(ph(this.b,!1),this.D=!1),!1;this.A=a.focus;this.a.set((-a.index).toString(),null);++this.j;nr(this,"precompose",a);var e=[],f=a.layerStatesArray;pb(f);var g=a.viewState.resolution,h,k,m,n;h=0;for(k=f.length;h<k;++h)n=f[h],jk(n,g)&&"ready"==n.A&&(m=Hk(this,n.layer),m.qf(a,n,c)&&e.push(n));f=a.size[0]*a.pixelRatio;g=a.size[1]*a.pixelRatio;if(this.b.width!=f||this.b.height!=g)this.b.width=f,this.b.height=g;d.bindFramebuffer(36160,
null);d.clearColor(0,0,0,0);d.clear(16384);d.enable(3042);d.viewport(0,0,this.b.width,this.b.height);h=0;for(k=e.length;h<k;++h)n=e[h],m=Hk(this,n.layer),m.Jg(a,n,c);this.D||(ph(this.b,!0),this.D=!0);Fk(a);1024<this.a.Vb()-this.j&&a.postRenderFunctions.push(sa(this.Ei,this));this.l.Ba()||(a.postRenderFunctions.push(this.H),a.animate=!0);nr(this,"postcompose",a);Ik(this,a);a.postRenderFunctions.push(Gk)};
l.of=function(a,c,d,e,f,g){var h;if(this.c.isContextLost())return!1;var k=c.viewState,m=c.layerStatesArray,n;for(n=m.length-1;0<=n;--n){h=m[n];var p=h.layer;if(jk(h,k.resolution)&&f.call(g,p)&&(h=Hk(this,p).Ya(a,c,d,e)))return h}};l.Ig=function(a,c,d,e){var f=!1;if(this.c.isContextLost())return!1;var g=c.viewState,h=c.layerStatesArray,k;for(k=h.length-1;0<=k;--k){var m=h[k],n=m.layer;if(jk(m,g.resolution)&&d.call(e,n)&&(f=Hk(this,n).ge(a,c)))return!0}return f};
l.Hg=function(a,c,d,e,f){if(this.c.isContextLost())return!1;var g=c.viewState,h,k=c.layerStatesArray,m;for(m=k.length-1;0<=m;--m){h=k[m];var n=h.layer;if(jk(h,g.resolution)&&f.call(e,n)&&(h=Hk(this,n).gc(a,c,d,e)))return h}};var or=["canvas","webgl","dom"];
function V(a){id.call(this);var c=pr(a);this.pc=void 0!==a.loadTilesWhileAnimating?a.loadTilesWhileAnimating:!1;this.qc=void 0!==a.loadTilesWhileInteracting?a.loadTilesWhileInteracting:!1;this.Ge=void 0!==a.pixelRatio?a.pixelRatio:aj;this.Pc=c.logos;this.v=new mi(this.Sn,void 0,this);tc(this,this.v);this.sb=Dd();this.He=Dd();this.tb=0;this.c=null;this.sa=Od();this.B=this.T=null;this.a=Og("DIV","ol-viewport");this.a.style.position="relative";this.a.style.overflow="hidden";this.a.style.width="100%";
this.a.style.height="100%";this.a.style.msTouchAction="none";this.a.style.touchAction="none";fj&&ch(this.a,"ol-touch");this.P=Og("DIV","ol-overlaycontainer");this.a.appendChild(this.P);this.C=Og("DIV","ol-overlaycontainer-stopevent");B(this.C,["click","dblclick","mousedown","touchstart","MSPointerDown",ak,ac?"DOMMouseScroll":"mousewheel"],wc);this.a.appendChild(this.C);a=new Sj(this);B(a,Lb(dk),this.ig,!1,this);tc(this,a);this.da=c.keyboardEventTarget;this.A=new Ei;B(this.A,"key",this.hg,!1,this);
tc(this,this.A);a=new Mi(this.a);B(a,"mousewheel",this.hg,!1,this);tc(this,a);this.g=c.controls;this.f=c.interactions;this.i=c.overlays;this.V={};this.j=new c.Un(this.a,this);tc(this,this.j);this.Da=new zi;tc(this,this.Da);this.ea=this.l=null;this.H=[];this.ma=[];this.na=new Ok(sa(this.yj,this),sa(this.Tk,this));this.ca={};B(this,kd("layergroup"),this.Mj,!1,this);B(this,kd("view"),this.gk,!1,this);B(this,kd("size"),this.dk,!1,this);B(this,kd("target"),this.fk,!1,this);this.K(c.values);this.g.forEach(function(a){a.setMap(this)},
this);B(this.g,"add",function(a){a.element.setMap(this)},!1,this);B(this.g,"remove",function(a){a.element.setMap(null)},!1,this);this.f.forEach(function(a){a.setMap(this)},this);B(this.f,"add",function(a){a.element.setMap(this)},!1,this);B(this.f,"remove",function(a){a.element.setMap(null)},!1,this);this.i.forEach(this.Uf,this);B(this.i,"add",function(a){this.Uf(a.element)},!1,this);B(this.i,"remove",function(a){var c=a.element.Fa();void 0!==c&&delete this.V[c.toString()];a.element.setMap(null)},
!1,this)}w(V,id);l=V.prototype;l.si=function(a){this.g.push(a)};l.ti=function(a){this.f.push(a)};l.Sf=function(a){this.Wb().Ec().push(a)};l.Tf=function(a){this.i.push(a)};l.Uf=function(a){var c=a.Fa();void 0!==c&&(this.V[c.toString()]=a);a.setMap(this)};l.Ea=function(a){this.render();Array.prototype.push.apply(this.H,arguments)};l.W=function(){Vg(this.a);V.ba.W.call(this)};l.cd=function(a,c,d,e,f){if(this.c)return a=this.Aa(a),this.j.of(a,this.c,c,void 0!==d?d:null,void 0!==e?e:te,void 0!==f?f:null)};
l.Sk=function(a,c,d,e,f){if(this.c)return this.j.Hg(a,this.c,c,void 0!==d?d:null,void 0!==e?e:te,void 0!==f?f:null)};l.ik=function(a,c,d){if(!this.c)return!1;a=this.Aa(a);return this.j.Ig(a,this.c,void 0!==c?c:te,void 0!==d?d:null)};l.Ti=function(a){return this.Aa(this.Hd(a))};l.Hd=function(a){var c;c=this.a;a=mh(a);c=mh(c);c=new Fg(a.x-c.x,a.y-c.y);return[c.x,c.y]};l.kf=function(){return this.get("target")};l.Ac=function(){var a=this.kf();return void 0!==a?Kg(a):null};
l.Aa=function(a){var c=this.c;return c?(a=a.slice(),ok(c.pixelToCoordinateMatrix,a,a)):null};l.Ri=function(){return this.g};l.mj=function(){return this.i};l.lj=function(a){a=this.V[a.toString()];return void 0!==a?a:null};l.$i=function(){return this.f};l.Wb=function(){return this.get("layergroup")};l.wg=function(){return this.Wb().Ec()};l.Ga=function(a){var c=this.c;return c?(a=a.slice(0,2),ok(c.coordinateToPixelMatrix,a,a)):null};l.La=function(){return this.get("size")};l.$=function(){return this.get("view")};
l.Aj=function(){return this.a};l.yj=function(a,c,d,e){var f=this.c;if(!(f&&c in f.wantedTiles&&f.wantedTiles[c][hg(a.b)]))return Infinity;a=d[0]-f.focus[0];d=d[1]-f.focus[1];return 65536*Math.log(e)+Math.sqrt(a*a+d*d)/e};l.hg=function(a,c){var d=new Qj(c||a.type,this,a);this.ig(d)};l.ig=function(a){if(this.c){this.ea=a.coordinate;a.frameState=this.c;var c=this.f.a,d;if(!1!==this.u(a))for(d=c.length-1;0<=d;d--){var e=c[d];if(e.c()&&!e.handleEvent(a))break}}};
l.bk=function(){var a=this.c,c=this.na;if(!c.Ba()){var d=16,e=d,f=0;a&&(f=a.viewHints,f[0]&&(d=this.pc?8:0,e=2),f[1]&&(d=this.qc?8:0,e=2),f=Kb(a.wantedTiles));d*=f;e*=f;c.f<d&&(Nk(c),Pk(c,d,e))}c=this.ma;d=0;for(e=c.length;d<e;++d)c[d](this,a);c.length=0};l.dk=function(){this.render()};l.fk=function(){var a=this.Ac();Li(this.A);a?(a.appendChild(this.a),Fi(this.A,this.da?this.da:a),this.l||(this.l=B(this.Da,"resize",this.Mc,!1,this))):(Vg(this.a),this.l&&(Zc(this.l),this.l=null));this.Mc()};l.Tk=function(){this.render()};
l.hk=function(){this.render()};l.gk=function(){this.T&&(Zc(this.T),this.T=null);var a=this.$();a&&(this.T=B(a,"propertychange",this.hk,!1,this));this.render()};l.Nj=function(){this.render()};l.Oj=function(){this.render()};l.Mj=function(){this.B&&(this.B.forEach(Zc),this.B=null);var a=this.Wb();a&&(this.B=[B(a,"propertychange",this.Oj,!1,this),B(a,"change",this.Nj,!1,this)]);this.render()};l.Tn=function(){var a=this.v;ni(a);a.f()};l.render=function(){null!=this.v.ta||this.v.start()};l.Mn=function(a){return this.g.remove(a)};
l.Nn=function(a){return this.f.remove(a)};l.Pn=function(a){return this.Wb().Ec().remove(a)};l.Qn=function(a){return this.i.remove(a)};
l.Sn=function(a){var c,d,e,f=this.La(),g=this.$(),h=null;if(void 0!==f&&0<f[0]&&0<f[1]&&g&&Vf(g)){var h=g.c.slice(),k=this.Wb().af(),m={};c=0;for(d=k.length;c<d;++c)m[v(k[c].layer)]=k[c];e=Uf(g);h={animate:!1,attributions:{},coordinateToPixelMatrix:this.sb,extent:null,focus:this.ea?this.ea:e.center,index:this.tb++,layerStates:m,layerStatesArray:k,logos:Ub(this.Pc),pixelRatio:this.Ge,pixelToCoordinateMatrix:this.He,postRenderFunctions:[],size:f,skippedFeatureUids:this.ca,tileQueue:this.na,time:a,usedTiles:{},
viewState:e,viewHints:h,wantedTiles:{}}}if(h){a=this.H;c=f=0;for(d=a.length;c<d;++c)g=a[c],g(this,h)&&(a[f++]=g);a.length=f;h.extent=me(e.center,e.resolution,e.rotation,h.size)}this.c=h;this.j.we(h);h&&(h.animate&&this.render(),Array.prototype.push.apply(this.ma,h.postRenderFunctions),0!==this.H.length||h.viewHints[0]||h.viewHints[1]||$d(h.extent,this.sa)||(this.u(new wh("moveend",this,h)),Td(h.extent,this.sa)));this.u(new wh("postrender",this,h));ri(this.bk,this)};
l.th=function(a){this.set("layergroup",a)};l.Df=function(a){this.set("size",a)};l.Uk=function(a){this.set("target",a)};l.ko=function(a){this.set("view",a)};l.yh=function(a){a=v(a).toString();this.ca[a]=!0;this.render()};
l.Mc=function(){var a=this.Ac();if(a){var c=Jg(a),d=Zb&&a.currentStyle;d&&Zg(Hg(c))&&"auto"!=d.width&&"auto"!=d.height&&!d.boxSizing?(c=qh(a,d.width,"width","pixelWidth"),a=qh(a,d.height,"height","pixelHeight"),a=new Gg(c,a)):(d=new Gg(a.offsetWidth,a.offsetHeight),c=sh(a,"padding"),a=vh(a),a=new Gg(d.width-a.left-c.left-c.right-a.right,d.height-a.top-c.top-c.bottom-a.bottom));this.Df([a.width,a.height])}else this.Df(void 0)};l.Bh=function(a){a=v(a).toString();delete this.ca[a];this.render()};
function pr(a){var c=null;void 0!==a.keyboardEventTarget&&(c=ia(a.keyboardEventTarget)?document.getElementById(a.keyboardEventTarget):a.keyboardEventTarget);var d={},e={};if(void 0===a.logo||"boolean"==typeof a.logo&&a.logo)e["data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAA3NCSVQICAjb4U/gAAAACXBIWXMAAAHGAAABxgEXwfpGAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAhNQTFRF////AP//AICAgP//AFVVQECA////K1VVSbbbYL/fJ05idsTYJFtbbcjbJllmZszWWMTOIFhoHlNiZszTa9DdUcHNHlNlV8XRIVdiasrUHlZjIVZjaMnVH1RlIFRkH1RkH1ZlasvYasvXVsPQH1VkacnVa8vWIVZjIFRjVMPQa8rXIVVkXsXRsNveIFVkIFZlIVVj3eDeh6GmbMvXH1ZkIFRka8rWbMvXIFVkIFVjIFVkbMvWH1VjbMvWIFVlbcvWIFVla8vVIFVkbMvWbMvVH1VkbMvWIFVlbcvWIFVkbcvVbMvWjNPbIFVkU8LPwMzNIFVkbczWIFVkbsvWbMvXIFVkRnB8bcvW2+TkW8XRIFVkIlZlJVloJlpoKlxrLl9tMmJwOWd0Omh1RXF8TneCT3iDUHiDU8LPVMLPVcLPVcPQVsPPVsPQV8PQWMTQWsTQW8TQXMXSXsXRX4SNX8bSYMfTYcfTYsfTY8jUZcfSZsnUaIqTacrVasrVa8jTa8rWbI2VbMvWbcvWdJObdcvUdszUd8vVeJaee87Yfc3WgJyjhqGnitDYjaarldPZnrK2oNbborW5o9bbo9fbpLa6q9ndrL3ArtndscDDutzfu8fJwN7gwt7gxc/QyuHhy+HizeHi0NfX0+Pj19zb1+Tj2uXk29/e3uLg3+Lh3+bl4uXj4ufl4+fl5Ofl5ufl5ujm5+jmySDnBAAAAFp0Uk5TAAECAgMEBAYHCA0NDg4UGRogIiMmKSssLzU7PkJJT1JTVFliY2hrdHZ3foSFhYeJjY2QkpugqbG1tre5w8zQ09XY3uXn6+zx8vT09vf4+Pj5+fr6/P39/f3+gz7SsAAAAVVJREFUOMtjYKA7EBDnwCPLrObS1BRiLoJLnte6CQy8FLHLCzs2QUG4FjZ5GbcmBDDjxJBXDWxCBrb8aM4zbkIDzpLYnAcE9VXlJSWlZRU13koIeW57mGx5XjoMZEUqwxWYQaQbSzLSkYGfKFSe0QMsX5WbjgY0YS4MBplemI4BdGBW+DQ11eZiymfqQuXZIjqwyadPNoSZ4L+0FVM6e+oGI6g8a9iKNT3o8kVzNkzRg5lgl7p4wyRUL9Yt2jAxVh6mQCogae6GmflI8p0r13VFWTHBQ0rWPW7ahgWVcPm+9cuLoyy4kCJDzCm6d8PSFoh0zvQNC5OjDJhQopPPJqph1doJBUD5tnkbZiUEqaCnB3bTqLTFG1bPn71kw4b+GFdpLElKIzRxxgYgWNYc5SCENVHKeUaltHdXx0dZ8uBI1hJ2UUDgq82CM2MwKeibqAvSO7MCABq0wXEPiqWEAAAAAElFTkSuQmCC"]=
"http://openlayers.org/";else{var f=a.logo;ia(f)?e[f]="":la(f)&&(e[f.src]=f.href)}f=a.layers instanceof Ol?a.layers:new Ol({layers:a.layers});d.layergroup=f;d.target=a.target;d.view=void 0!==a.view?a.view:new Qf;var f=Ek,g;void 0!==a.renderer?ga(a.renderer)?g=a.renderer:ia(a.renderer)&&(g=[a.renderer]):g=or;var h,k;h=0;for(k=g.length;h<k;++h){var m=g[h];if("canvas"==m){if(cj){f=gq;break}}else if("dom"==m){f=oq;break}else if("webgl"==m&&$i){f=lr;break}}var n;void 0!==a.controls?n=ga(a.controls)?new vg(a.controls.slice()):
a.controls:n=di();var p;void 0!==a.interactions?p=ga(a.interactions)?new vg(a.interactions.slice()):a.interactions:p=Nl();a=void 0!==a.overlays?ga(a.overlays)?new vg(a.overlays.slice()):a.overlays:new vg;return{controls:n,interactions:p,keyboardEventTarget:c,logos:e,overlays:a,Un:f,values:d}}Vl();function qr(a){id.call(this);this.ta=a.id;this.j=void 0!==a.insertFirst?a.insertFirst:!0;this.l=void 0!==a.stopEvent?a.stopEvent:!0;this.c=Og("DIV",{"class":"ol-overlay-container"});this.c.style.position="absolute";this.autoPan=void 0!==a.autoPan?a.autoPan:!1;this.g=void 0!==a.autoPanAnimation?a.autoPanAnimation:{};this.i=void 0!==a.autoPanMargin?a.autoPanMargin:20;this.a={Ad:"",Zd:"",xe:"",ye:"",visible:!0};this.f=null;B(this,kd("element"),this.Ij,!1,this);B(this,kd("map"),this.Tj,!1,this);B(this,
kd("offset"),this.Yj,!1,this);B(this,kd("position"),this.$j,!1,this);B(this,kd("positioning"),this.ak,!1,this);void 0!==a.element&&this.qh(a.element);this.vh(void 0!==a.offset?a.offset:[0,0]);this.wh(void 0!==a.positioning?a.positioning:"top-left");void 0!==a.position&&this.lf(a.position)}w(qr,id);l=qr.prototype;l.be=function(){return this.get("element")};l.Fa=function(){return this.ta};l.ce=function(){return this.get("map")};l.eg=function(){return this.get("offset")};l.xg=function(){return this.get("position")};
l.fg=function(){return this.get("positioning")};l.Ij=function(){Tg(this.c);var a=this.be();a&&Sg(this.c,a)};l.Tj=function(){this.f&&(Vg(this.c),Zc(this.f),this.f=null);var a=this.ce();a&&(this.f=B(a,"postrender",this.render,!1,this),rr(this),a=this.l?a.C:a.P,this.j?Ug(a,this.c,0):Sg(a,this.c))};l.render=function(){rr(this)};l.Yj=function(){rr(this)};
l.$j=function(){rr(this);if(void 0!==this.get("position")&&this.autoPan){var a=this.ce();if(void 0!==a&&a.Ac()){var c=sr(a.Ac(),a.La()),d=this.be(),e=d.offsetWidth,f=d.currentStyle||window.getComputedStyle(d),e=e+(parseInt(f.marginLeft,10)+parseInt(f.marginRight,10)),f=d.offsetHeight,g=d.currentStyle||window.getComputedStyle(d),f=f+(parseInt(g.marginTop,10)+parseInt(g.marginBottom,10)),h=sr(d,[e,f]),d=this.i;Xd(c,h)||(e=h[0]-c[0],f=c[2]-h[2],g=h[1]-c[1],h=c[3]-h[3],c=[0,0],0>e?c[0]=e-d:0>f&&(c[0]=
Math.abs(f)+d),0>g?c[1]=g-d:0>h&&(c[1]=Math.abs(h)+d),0===c[0]&&0===c[1])||(d=a.$().Na(),e=a.Ga(d),c=[e[0]+c[0],e[1]+c[1]],this.g&&(this.g.source=d,a.Ea(bg(this.g))),a.$().Wa(a.Aa(c)))}}};l.ak=function(){rr(this)};l.qh=function(a){this.set("element",a)};l.setMap=function(a){this.set("map",a)};l.vh=function(a){this.set("offset",a)};l.lf=function(a){this.set("position",a)};
function sr(a,c){var d=Jg(a),e=new Fg(0,0),f;f=d?Jg(d):document;f=!Zb||9<=lc||Zg(Hg(f))?f.documentElement:f.body;a!=f&&(f=lh(a),d=$g(Hg(d)),e.x=f.left+d.x,e.y=f.top+d.y);return[e.x,e.y,e.x+c[0],e.y+c[1]]}l.wh=function(a){this.set("positioning",a)};function tr(a,c){a.a.visible!==c&&(ph(a.c,c),a.a.visible=c)}
function rr(a){var c=a.ce(),d=a.xg();if(void 0!==c&&c.c&&void 0!==d){var d=c.Ga(d),e=c.La(),c=a.c.style,f=a.eg(),g=a.fg(),h=f[0],f=f[1];if("bottom-right"==g||"center-right"==g||"top-right"==g)""!==a.a.Zd&&(a.a.Zd=c.left=""),h=Math.round(e[0]-d[0]-h)+"px",a.a.xe!=h&&(a.a.xe=c.right=h);else{""!==a.a.xe&&(a.a.xe=c.right="");if("bottom-center"==g||"center-center"==g||"top-center"==g)h-=nh(a.c).width/2;h=Math.round(d[0]+h)+"px";a.a.Zd!=h&&(a.a.Zd=c.left=h)}if("bottom-left"==g||"bottom-center"==g||"bottom-right"==
g)""!==a.a.ye&&(a.a.ye=c.top=""),d=Math.round(e[1]-d[1]-f)+"px",a.a.Ad!=d&&(a.a.Ad=c.bottom=d);else{""!==a.a.Ad&&(a.a.Ad=c.bottom="");if("center-left"==g||"center-center"==g||"center-right"==g)f-=nh(a.c).height/2;d=Math.round(d[1]+f)+"px";a.a.ye!=d&&(a.a.ye=c.top=d)}tr(a,!0)}else tr(a,!1)};function ur(a){a=a?a:{};this.i=void 0!==a.collapsed?a.collapsed:!0;this.j=void 0!==a.collapsible?a.collapsible:!0;this.j||(this.i=!1);var c=a.className?a.className:"ol-overviewmap",d=a.tipLabel?a.tipLabel:"Overview map",e=a.collapseLabel?a.collapseLabel:"\u00ab";this.A=ia(e)?Og("SPAN",{},e):e;e=a.label?a.label:"\u00bb";this.B=ia(e)?Og("SPAN",{},e):e;d=Og("BUTTON",{type:"button",title:d},this.j&&!this.i?this.A:this.B);B(d,"click",this.dl,!1,this);var e=Og("DIV","ol-overviewmap-map"),f=this.c=new V({controls:new vg,
interactions:new vg,target:e,view:a.view});a.layers&&a.layers.forEach(function(a){f.Sf(a)},this);var g=Og("DIV","ol-overviewmap-box");this.l=new qr({position:[0,0],positioning:"bottom-left",element:g});this.c.Tf(this.l);c=Og("DIV",c+" ol-unselectable ol-control"+(this.i&&this.j?" ol-collapsed":"")+(this.j?"":" ol-uncollapsible"),e,d);xh.call(this,{element:c,render:a.render?a.render:vr,target:a.target})}w(ur,xh);l=ur.prototype;
l.setMap=function(a){var c=this.a;a!==c&&(c&&(c=c.$())&&Yc(c,kd("rotation"),this.Td,!1,this),ur.ba.setMap.call(this,a),a&&(this.v.push(B(a,"propertychange",this.Uj,!1,this)),0===this.c.wg().Mb()&&this.c.th(a.Wb()),a=a.$()))&&(B(a,kd("rotation"),this.Td,!1,this),Vf(a)&&(this.c.Mc(),wr(this)))};l.Uj=function(a){"view"===a.key&&((a=a.oldValue)&&Yc(a,kd("rotation"),this.Td,!1,this),a=this.a.$(),B(a,kd("rotation"),this.Td,!1,this))};l.Td=function(){this.c.$().de(this.a.$().za())};
function vr(){var a=this.a,c=this.c;if(a.c&&c.c){var d=a.La(),a=a.$().Rc(d),e=c.La(),d=c.$().Rc(e),f=c.Ga(ge(a)),c=c.Ga(ee(a)),c=new Gg(Math.abs(f[0]-c[0]),Math.abs(f[1]-c[1])),f=e[0],e=e[1];c.width<.1*f||c.height<.1*e||c.width>.75*f||c.height>.75*e?wr(this):Xd(d,a)||(a=this.c,d=this.a.$(),a.$().Wa(d.Na()))}xr(this)}function wr(a){var c=a.a;a=a.c;var d=c.La(),c=c.$().Rc(d),d=a.La();a=a.$();pe(c,1/(.1*Math.pow(2,Math.log(7.5)/Math.LN2/2)));a.Se(c,d)}
function xr(a){var c=a.a,d=a.c;if(c.c&&d.c){var e=c.La(),f=c.$(),g=d.$();d.La();var c=f.za(),h=a.l,d=a.l.be(),f=f.Rc(e),e=g.aa(),g=de(f),f=fe(f),k;if(a=a.a.$().Na())k=[g[0]-a[0],g[1]-a[1]],wd(k,c),rd(k,a);h.lf(k);d&&(k=new Gg(Math.abs((g[0]-f[0])/e),Math.abs((f[1]-g[1])/e)),c=Zg(Hg(Jg(d))),!Zb||jc("10")||c&&jc("8")?(d=d.style,ac?d.MozBoxSizing="border-box":bc?d.WebkitBoxSizing="border-box":d.boxSizing="border-box",d.width=Math.max(k.width,0)+"px",d.height=Math.max(k.height,0)+"px"):(a=d.style,c?(c=
sh(d,"padding"),d=vh(d),a.pixelWidth=k.width-d.left-c.left-c.right-d.right,a.pixelHeight=k.height-d.top-c.top-c.bottom-d.bottom):(a.pixelWidth=k.width,a.pixelHeight=k.height)))}}l.dl=function(a){a.preventDefault();yr(this)};function yr(a){eh(a.element,"ol-collapsed");a.i?Wg(a.A,a.B):Wg(a.B,a.A);a.i=!a.i;var c=a.c;a.i||c.c||(c.Mc(),wr(a),Xc(c,"postrender",function(){xr(this)},!1,a))}l.cl=function(){return this.j};
l.fl=function(a){this.j!==a&&(this.j=a,eh(this.element,"ol-uncollapsible"),!a&&this.i&&yr(this))};l.el=function(a){this.j&&this.i!==a&&yr(this)};l.bl=function(){return this.i};l.nj=function(){return this.c};function zr(a){a=a?a:{};var c=a.className?a.className:"ol-scale-line";this.l=Og("DIV",c+"-inner");this.j=Og("DIV",c+" ol-unselectable",this.l);this.B=null;this.A=void 0!==a.minWidth?a.minWidth:64;this.c=!1;this.H=void 0;this.C="";this.i=null;xh.call(this,{element:this.j,render:a.render?a.render:Ar,target:a.target});B(this,kd("units"),this.V,!1,this);this.ea(a.units||"metric")}w(zr,xh);var Br=[1,2,5];zr.prototype.P=function(){return this.get("units")};
function Ar(a){(a=a.frameState)?this.B=a.viewState:this.B=null;Cr(this)}zr.prototype.V=function(){Cr(this)};zr.prototype.ea=function(a){this.set("units",a)};
function Cr(a){var c=a.B;if(c){var d=c.center,e=c.projection,c=e.getPointResolution(c.resolution,d),f=e.f,g=a.P();"degrees"!=f||"metric"!=g&&"imperial"!=g&&"us"!=g&&"nautical"!=g?"degrees"!=f&&"degrees"==g?(a.i||(a.i=Ie(e,Ee("EPSG:4326"))),d=Math.cos(Wa(a.i(d)[1])),e=Ae.radius,e/=Be[f],c*=180/(Math.PI*d*e)):a.i=null:(a.i=null,d=Math.cos(Wa(d[1])),c*=Math.PI*d*Ae.radius/180);d=a.A*c;f="";"degrees"==g?d<1/60?(f="\u2033",c*=3600):1>d?(f="\u2032",c*=60):f="\u00b0":"imperial"==g?.9144>d?(f="in",c/=.0254):
1609.344>d?(f="ft",c/=.3048):(f="mi",c/=1609.344):"nautical"==g?(c/=1852,f="nm"):"metric"==g?1>d?(f="mm",c*=1E3):1E3>d?f="m":(f="km",c/=1E3):"us"==g&&(.9144>d?(f="in",c*=39.37):1609.344>d?(f="ft",c/=.30480061):(f="mi",c/=1609.3472));for(d=3*Math.floor(Math.log(a.A*c)/Math.log(10));;){e=Br[d%3]*Math.pow(10,Math.floor(d/3));g=Math.round(e/c);if(isNaN(g)){ph(a.j,!1);a.c=!1;return}if(g>=a.A)break;++d}c=e+" "+f;a.C!=c&&(a.l.innerHTML=c,a.C=c);a.H!=g&&(a.l.style.width=g+"px",a.H=g);a.c||(ph(a.j,!0),a.c=
!0)}else a.c&&(ph(a.j,!1),a.c=!1)};function Dr(a){qc.call(this);this.a=a;this.b={}}w(Dr,qc);var Er=[];Dr.prototype.Ka=function(a,c,d,e){ga(c)||(c&&(Er[0]=c.toString()),c=Er);for(var f=0;f<c.length;f++){var g=B(a,c[f],d||this.handleEvent,e||!1,this.a||this);if(!g)break;this.b[g.key]=g}return this};
Dr.prototype.Ef=function(a,c,d,e,f){if(ga(c))for(var g=0;g<c.length;g++)this.Ef(a,c[g],d,e,f);else d=d||this.handleEvent,f=f||this.a||this,d=Rc(d),e=!!e,c=Ec(a)?Lc(a.nb,String(c),d,e,f):a?(a=Tc(a))?Lc(a,c,d,e,f):null:null,c&&(Zc(c),delete this.b[c.key]);return this};function Fr(a){Hb(a.b,function(a,d){this.b.hasOwnProperty(d)&&Zc(a)},a);a.b={}}Dr.prototype.W=function(){Dr.ba.W.call(this);Fr(this)};Dr.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented");};function Gr(a,c,d){cd.call(this);this.target=a;this.handle=c||a;this.b=d||new gh(NaN,NaN,NaN,NaN);this.i=Jg(a);this.a=new Dr(this);tc(this,this.a);this.g=this.f=this.D=this.l=this.screenY=this.screenX=this.clientY=this.clientX=0;this.c=!1;B(this.handle,["touchstart","mousedown"],this.zh,!1,this)}w(Gr,cd);var Hr=Zb||ac&&jc("1.9.3");l=Gr.prototype;
l.W=function(){Gr.ba.W.call(this);Yc(this.handle,["touchstart","mousedown"],this.zh,!1,this);Fr(this.a);Hr&&this.i.releaseCapture();this.handle=this.target=null};
l.zh=function(a){var c="mousedown"==a.type;if(this.c||c&&!Cc(a))this.u("earlycancel");else if(this.u(new Ir("start",this,a.clientX,a.clientY))){this.c=!0;a.preventDefault();var c=this.i,d=c.documentElement,e=!Hr;this.a.Ka(c,["touchmove","mousemove"],this.Xj,e);this.a.Ka(c,["touchend","mouseup"],this.Gd,e);Hr?(d.setCapture(!1),this.a.Ka(d,"losecapture",this.Gd)):this.a.Ka(c?c.parentWindow||c.defaultView:window,"blur",this.Gd);this.v&&this.a.Ka(this.v,"scroll",this.dn,e);this.clientX=this.l=a.clientX;
this.clientY=this.D=a.clientY;this.screenX=a.screenX;this.screenY=a.screenY;this.f=this.target.offsetLeft;this.g=this.target.offsetTop;this.j=$g(Hg(this.i))}};l.Gd=function(a){Fr(this.a);Hr&&this.i.releaseCapture();this.c?(this.c=!1,this.u(new Ir("end",this,a.clientX,a.clientY,0,Jr(this,this.f),Kr(this,this.g)))):this.u("earlycancel")};
l.Xj=function(a){var c=1*(a.clientX-this.clientX),d=a.clientY-this.clientY;this.clientX=a.clientX;this.clientY=a.clientY;this.screenX=a.screenX;this.screenY=a.screenY;if(!this.c){var e=this.l-this.clientX,f=this.D-this.clientY;if(0<e*e+f*f)if(this.u(new Ir("start",this,a.clientX,a.clientY)))this.c=!0;else{this.fa||this.Gd(a);return}}d=Lr(this,c,d);c=d.x;d=d.y;this.c&&this.u(new Ir("beforedrag",this,a.clientX,a.clientY,0,c,d))&&(Mr(this,a,c,d),a.preventDefault())};
function Lr(a,c,d){var e=$g(Hg(a.i));c+=e.x-a.j.x;d+=e.y-a.j.y;a.j=e;a.f+=c;a.g+=d;return new Fg(Jr(a,a.f),Kr(a,a.g))}l.dn=function(a){var c=Lr(this,0,0);a.clientX=this.clientX;a.clientY=this.clientY;Mr(this,a,c.x,c.y)};function Mr(a,c,d,e){a.target.style.left=d+"px";a.target.style.top=e+"px";a.u(new Ir("drag",a,c.clientX,c.clientY,0,d,e))}function Jr(a,c){var d=a.b,e=isNaN(d.left)?null:d.left,d=isNaN(d.width)?0:d.width;return Math.min(null!=e?e+d:Infinity,Math.max(null!=e?e:-Infinity,c))}
function Kr(a,c){var d=a.b,e=isNaN(d.top)?null:d.top,d=isNaN(d.height)?0:d.height;return Math.min(null!=e?e+d:Infinity,Math.max(null!=e?e:-Infinity,c))}function Ir(a,c,d,e,f,g,h){vc.call(this,a);this.clientX=d;this.clientY=e;this.left=ca(g)?g:c.f;this.top=ca(h)?h:c.g}w(Ir,vc);function Nr(a){a=a?a:{};this.i=void 0;this.j=Or;this.l=null;this.B=!1;this.A=a.duration?a.duration:200;var c=a.className?a.className:"ol-zoomslider",d=Og("BUTTON",{type:"button","class":c+"-thumb ol-unselectable"}),c=Og("DIV",[c,"ol-unselectable","ol-control"],d);this.c=new Gr(d);tc(this,this.c);B(this.c,"start",this.Hj,!1,this);B(this.c,"drag",this.Fj,!1,this);B(this.c,"end",this.Gj,!1,this);B(c,"click",this.Ej,!1,this);B(d,"click",wc);xh.call(this,{element:c,render:a.render?a.render:Pr})}w(Nr,xh);
var Or=0;l=Nr.prototype;l.setMap=function(a){Nr.ba.setMap.call(this,a);a&&a.render()};
function Pr(a){if(a.frameState){if(!this.B){var c=this.element,d=nh(c),e=Xg(c),c=sh(e,"margin"),f=new Gg(e.offsetWidth,e.offsetHeight),e=f.width+c.right+c.left,c=f.height+c.top+c.bottom;this.l=[e,c];e=d.width-e;c=d.height-c;d.width>d.height?(this.j=1,d=new gh(0,0,e,0)):(this.j=Or,d=new gh(0,0,0,c));this.c.b=d||new gh(NaN,NaN,NaN,NaN);this.B=!0}a=a.frameState.viewState.resolution;a!==this.i&&(this.i=a,a=1-Sf(this.a.$())(a),d=this.c,c=Xg(this.element),1==this.j?jh(c,d.b.left+d.b.width*a):jh(c,d.b.left,
d.b.top+d.b.height*a))}}l.Ej=function(a){var c=this.a,d=c.$(),e=d.aa();c.Ea(dg({resolution:e,duration:this.A,easing:Yf}));a=Qr(this,Rr(this,a.offsetX-this.l[0]/2,a.offsetY-this.l[1]/2));d.Cb(d.constrainResolution(a))};l.Hj=function(){Wf(this.a.$(),1)};l.Fj=function(a){this.i=Qr(this,Rr(this,a.left,a.top));this.a.$().Cb(this.i)};l.Gj=function(){var a=this.a,c=a.$();Wf(c,-1);a.Ea(dg({resolution:this.i,duration:this.A,easing:Yf}));a=c.constrainResolution(this.i);c.Cb(a)};
function Rr(a,c,d){var e=a.c.b;return Sa(1===a.j?(c-e.left)/e.width:(d-e.top)/e.height,0,1)}function Qr(a,c){return Rf(a.a.$())(1-c)};function Sr(a){a=a?a:{};this.c=a.extent?a.extent:null;var c=a.className?a.className:"ol-zoom-extent",d=Og("BUTTON",{type:"button",title:a.tipLabel?a.tipLabel:"Fit to extent"},a.label?a.label:"E");B(d,"click",this.i,!1,this);c=Og("DIV",c+" ol-unselectable ol-control",d);xh.call(this,{element:c,target:a.target})}w(Sr,xh);Sr.prototype.i=function(a){a.preventDefault();var c=this.a;a=c.$();var d=this.c?this.c:a.g.J(),c=c.La();a.Se(d,c)};function Tr(a){id.call(this);a=a?a:{};this.a=null;B(this,kd("tracking"),this.Gk,!1,this);this.hf(void 0!==a.tracking?a.tracking:!1)}w(Tr,id);l=Tr.prototype;l.W=function(){this.hf(!1);Tr.ba.W.call(this)};
l.en=function(a){a=a.b;if(null!==a.alpha){var c=Wa(a.alpha);this.set("alpha",c);"boolean"==typeof a.absolute&&a.absolute?this.set("heading",c):ja(a.webkitCompassHeading)&&-1!=a.webkitCompassAccuracy&&this.set("heading",Wa(a.webkitCompassHeading))}null!==a.beta&&this.set("beta",Wa(a.beta));null!==a.gamma&&this.set("gamma",Wa(a.gamma));this.s()};l.Mi=function(){return this.get("alpha")};l.Pi=function(){return this.get("beta")};l.Xi=function(){return this.get("gamma")};l.Fk=function(){return this.get("heading")};
l.sg=function(){return this.get("tracking")};l.Gk=function(){if(dj){var a=this.sg();a&&!this.a?this.a=B(ba,"deviceorientation",this.en,!1,this):!a&&this.a&&(Zc(this.a),this.a=null)}};l.hf=function(a){this.set("tracking",a)};function Ur(){this.defaultDataProjection=null}function Vr(a,c,d){var e;d&&(e={dataProjection:d.dataProjection?d.dataProjection:a.Pa(c),featureProjection:d.featureProjection});return Wr(a,e)}function Wr(a,c){var d;c&&(d={featureProjection:c.featureProjection,dataProjection:c.dataProjection?c.dataProjection:a.defaultDataProjection,rightHanded:c.rightHanded});return d}
function Xr(a,c,d){var e=d?Ee(d.featureProjection):null;d=d?Ee(d.dataProjection):null;return e&&d&&!We(e,d)?a instanceof af?(c?a.clone():a).Xa(c?e:d,c?d:e):$e(c?a.slice():a,c?e:d,c?d:e):a};function Yr(){this.defaultDataProjection=null}w(Yr,Ur);function Zr(a){return la(a)?a:ia(a)?(a=to(a))?a:null:null}l=Yr.prototype;l.Z=function(){return"json"};l.Bb=function(a,c){return this.Hc(Zr(a),Vr(this,a,c))};l.va=function(a,c){return this.wf(Zr(a),Vr(this,a,c))};l.Ic=function(a,c){return this.bh(Zr(a),Vr(this,a,c))};l.Pa=function(a){return this.ih(Zr(a))};l.td=function(a,c){return uo(this.Nc(a,c))};l.Db=function(a,c){return uo(this.Be(a,c))};l.Oc=function(a,c){return uo(this.De(a,c))};function $r(a){a=a?a:{};this.defaultDataProjection=null;this.b=a.geometryName}w($r,Yr);
function as(a,c){if(!a)return null;var d;if(ja(a.x)&&ja(a.y))d="Point";else if(a.points)d="MultiPoint";else if(a.paths)d=1===a.paths.length?"LineString":"MultiLineString";else if(a.rings){var e=a.rings,f=bs(a),g=[];d=[];var h,k;h=0;for(k=e.length;h<k;++h){var m=tb(e[h]);Ff(m,0,m.length,f.length)?g.push([e[h]]):d.push(e[h])}for(;d.length;){e=d.shift();f=!1;for(h=g.length-1;0<=h;h--)if(Xd((new vf(g[h][0])).J(),(new vf(e)).J())){g[h].push(e);f=!0;break}f||g.push([e.reverse()])}a=Ub(a);1===g.length?(d=
"Polygon",a.rings=g[0]):(d="MultiPolygon",a.rings=g)}return Xr((0,cs[d])(a),!1,c)}function bs(a){var c="XY";!0===a.hasZ&&!0===a.hasM?c="XYZM":!0===a.hasZ?c="XYZ":!0===a.hasM&&(c="XYM");return c}function ds(a){a=a.a;return{hasZ:"XYZ"===a||"XYZM"===a,hasM:"XYM"===a||"XYZM"===a}}
var cs={Point:function(a){return void 0!==a.m&&void 0!==a.z?new C([a.x,a.y,a.z,a.m],"XYZM"):void 0!==a.z?new C([a.x,a.y,a.z],"XYZ"):void 0!==a.m?new C([a.x,a.y,a.m],"XYM"):new C([a.x,a.y])},LineString:function(a){return new I(a.paths[0],bs(a))},Polygon:function(a){return new D(a.rings,bs(a))},MultiPoint:function(a){return new mn(a.points,bs(a))},MultiLineString:function(a){return new N(a.paths,bs(a))},MultiPolygon:function(a){return new O(a.rings,bs(a))}},es={Point:function(a){var c=a.X();a=a.a;if("XYZ"===
a)return{x:c[0],y:c[1],z:c[2]};if("XYM"===a)return{x:c[0],y:c[1],m:c[2]};if("XYZM"===a)return{x:c[0],y:c[1],z:c[2],m:c[3]};if("XY"===a)return{x:c[0],y:c[1]}},LineString:function(a){var c=ds(a);return{hasZ:c.hasZ,hasM:c.hasM,paths:[a.X()]}},Polygon:function(a){var c=ds(a);return{hasZ:c.hasZ,hasM:c.hasM,rings:a.X(!1)}},MultiPoint:function(a){var c=ds(a);return{hasZ:c.hasZ,hasM:c.hasM,points:a.X()}},MultiLineString:function(a){var c=ds(a);return{hasZ:c.hasZ,hasM:c.hasM,paths:a.X()}},MultiPolygon:function(a){var c=
ds(a);a=a.X(!1);for(var d=[],e=0;e<a.length;e++)for(var f=a[e].length-1;0<=f;f--)d.push(a[e][f]);return{hasZ:c.hasZ,hasM:c.hasM,rings:d}}};l=$r.prototype;l.Hc=function(a,c){var d=as(a.geometry,c),e=new P;this.b&&e.Kc(this.b);e.Ca(d);c&&c.cf&&a.attributes[c.cf]&&e.Sb(a.attributes[c.cf]);a.attributes&&e.K(a.attributes);return e};
l.wf=function(a,c){var d=c?c:{};if(a.features){var e=[],f=a.features,g,h;d.cf=a.objectIdFieldName;g=0;for(h=f.length;g<h;++g)e.push(this.Hc(f[g],d));return e}return[this.Hc(a,d)]};l.bh=function(a,c){return as(a,c)};l.ih=function(a){return a.spatialReference&&a.spatialReference.wkid?Ee("EPSG:"+a.spatialReference.wkid):null};function fs(a,c){return(0,es[a.Z()])(Xr(a,!0,c),c)}l.De=function(a,c){return fs(a,Wr(this,c))};
l.Nc=function(a,c){c=Wr(this,c);var d={},e=a.Y();e&&(d.geometry=fs(e,c));e=a.S();delete e[a.a];d.attributes=Qb(e)?{}:e;c&&c.featureProjection&&(d.spatialReference={wkid:Ee(c.featureProjection).b.split(":").pop()});return d};l.Be=function(a,c){c=Wr(this,c);var d=[],e,f;e=0;for(f=a.length;e<f;++e)d.push(this.Nc(a[e],c));return{features:d}};function gs(a){a=a?a:{};this.defaultDataProjection=null;this.defaultDataProjection=Ee(a.defaultDataProjection?a.defaultDataProjection:"EPSG:4326");this.b=a.geometryName}w(gs,Yr);function hs(a,c){return a?Xr((0,is[a.type])(a),!1,c):null}function js(a,c){return(0,ks[a.Z()])(Xr(a,!0,c),c)}
var is={Point:function(a){return new C(a.coordinates)},LineString:function(a){return new I(a.coordinates)},Polygon:function(a){return new D(a.coordinates)},MultiPoint:function(a){return new mn(a.coordinates)},MultiLineString:function(a){return new N(a.coordinates)},MultiPolygon:function(a){return new O(a.coordinates)},GeometryCollection:function(a,c){var d=a.geometries.map(function(a){return hs(a,c)});return new bn(d)}},ks={Point:function(a){return{type:"Point",coordinates:a.X()}},LineString:function(a){return{type:"LineString",
coordinates:a.X()}},Polygon:function(a,c){var d;c&&(d=c.rightHanded);return{type:"Polygon",coordinates:a.X(d)}},MultiPoint:function(a){return{type:"MultiPoint",coordinates:a.X()}},MultiLineString:function(a){return{type:"MultiLineString",coordinates:a.X()}},MultiPolygon:function(a,c){var d;c&&(d=c.rightHanded);return{type:"MultiPolygon",coordinates:a.X(d)}},GeometryCollection:function(a,c){return{type:"GeometryCollection",geometries:a.f.map(function(a){return js(a,c)})}},Circle:function(){return{type:"GeometryCollection",
geometries:[]}}};l=gs.prototype;l.Hc=function(a,c){var d=hs(a.geometry,c),e=new P;this.b&&e.Kc(this.b);e.Ca(d);a.id&&e.Sb(a.id);a.properties&&e.K(a.properties);return e};l.wf=function(a,c){if("Feature"==a.type)return[this.Hc(a,c)];if("FeatureCollection"==a.type){var d=[],e=a.features,f,g;f=0;for(g=e.length;f<g;++f)d.push(this.Hc(e[f],c));return d}return[]};l.bh=function(a,c){return hs(a,c)};
l.ih=function(a){return(a=a.crs)?"name"==a.type?Ee(a.properties.name):"EPSG"==a.type?Ee("EPSG:"+a.properties.code):null:this.defaultDataProjection};l.Nc=function(a,c){c=Wr(this,c);var d={type:"Feature"},e=a.Fa();e&&(d.id=e);e=a.Y();d.geometry=e?js(e,c):null;e=a.S();delete e[a.a];d.properties=Qb(e)?null:e;return d};l.Be=function(a,c){c=Wr(this,c);var d=[],e,f;e=0;for(f=a.length;e<f;++e)d.push(this.Nc(a[e],c));return{type:"FeatureCollection",features:d}};l.De=function(a,c){return js(a,Wr(this,c))};function ls(){this.defaultDataProjection=null}w(ls,Ur);l=ls.prototype;l.Z=function(){return"xml"};l.Bb=function(a,c){if(lp(a))return ms(this,a,c);if(op(a))return this.$g(a,c);if(ia(a)){var d=yp(a);return ms(this,d,c)}return null};function ms(a,c,d){a=ns(a,c,d);return 0<a.length?a[0]:null}l.va=function(a,c){if(lp(a))return ns(this,a,c);if(op(a))return this.Rb(a,c);if(ia(a)){var d=yp(a);return ns(this,d,c)}return[]};
function ns(a,c,d){var e=[];for(c=c.firstChild;c;c=c.nextSibling)1==c.nodeType&&kb(e,a.Rb(c,d));return e}l.Ic=function(a,c){if(lp(a))return this.v(a,c);if(op(a)){var d=this.se(a,[Vr(this,a,c?c:{})]);return d?d:null}return ia(a)?(d=yp(a),this.v(d,c)):null};l.Pa=function(a){return lp(a)?this.Af(a):op(a)?this.ve(a):ia(a)?(a=yp(a),this.Af(a)):null};l.Af=function(){return this.defaultDataProjection};l.ve=function(){return this.defaultDataProjection};l.td=function(a,c){var d=this.B(a,c);return Yo(d)};
l.Db=function(a,c){var d=this.a(a,c);return Yo(d)};l.Oc=function(a,c){var d=this.D(a,c);return Yo(d)};function os(a){a=a?a:{};this.featureType=a.featureType;this.featureNS=a.featureNS;this.srsName=a.srsName;this.schemaLocation="";this.b={};this.b["http://www.opengis.net/gml"]={featureMember:Bp(os.prototype.pd),featureMembers:Bp(os.prototype.pd)};this.defaultDataProjection=null}w(os,ls);l=os.prototype;
l.pd=function(a,c){var d=ip(a),e;if("FeatureCollection"==d)"http://www.opengis.net/wfs"===a.namespaceURI?e=T([],this.b,a,c,this):e=T(null,this.b,a,c,this);else if("featureMembers"==d||"featureMember"==d){var f=c[0],g=f.featureType;e=f.featureNS;var h,k;if(!g&&a.childNodes){g=[];e={};h=0;for(k=a.childNodes.length;h<k;++h){var m=a.childNodes[h];if(1===m.nodeType){var n=m.nodeName.split(":").pop();if(-1===g.indexOf(n)){var p;Ob(e,m.namespaceURI)?p=Pb(e,function(a){return a===m.namespaceURI}):(p="p"+
Kb(e),e[p]=m.namespaceURI);g.push(p+":"+n)}}}f.featureType=g;f.featureNS=e}ia(e)&&(h=e,e={},e.p0=h);var f={},g=ga(g)?g:[g],q;for(q in e){n={};h=0;for(k=g.length;h<k;++h)(-1===g[h].indexOf(":")?"p0":g[h].split(":")[0])===q&&(n[g[h].split(":").pop()]="featureMembers"==d?Ap(this.vf,this):Bp(this.vf,this));f[e[q]]=n}e=T([],f,a,c)}e||(e=[]);return e};l.se=function(a,c){var d=c[0];d.srsName=a.firstElementChild.getAttribute("srsName");var e=T(null,this.Jf,a,c,this);if(e)return Xr(e,!1,d)};
l.vf=function(a,c){var d,e=a.getAttribute("fid")||sp(a,"http://www.opengis.net/gml","id"),f={},g;for(d=a.firstElementChild;d;d=d.nextElementSibling){var h=ip(d);if(0===d.childNodes.length||1===d.childNodes.length&&(3===d.firstChild.nodeType||4===d.firstChild.nodeType)){var k=ep(d,!1);/^[\s\xa0]*$/.test(k)&&(k=void 0);f[h]=k}else"boundedBy"!==h&&(g=h),f[h]=this.se(d,c)}d=new P(f);g&&d.Kc(g);e&&d.Sb(e);return d};l.hh=function(a,c){var d=this.re(a,c);if(d){var e=new C(null);xf(e,"XYZ",d);return e}};
l.fh=function(a,c){var d=T([],this.Wh,a,c,this);if(d)return new mn(d)};l.eh=function(a,c){var d=T([],this.Vh,a,c,this);if(d){var e=new N(null);ln(e,d);return e}};l.gh=function(a,c){var d=T([],this.Xh,a,c,this);if(d){var e=new O(null);on(e,d);return e}};l.Xg=function(a,c){Ip(this.$h,a,c,this)};l.og=function(a,c){Ip(this.Th,a,c,this)};l.Yg=function(a,c){Ip(this.ai,a,c,this)};l.te=function(a,c){var d=this.re(a,c);if(d){var e=new I(null);jn(e,"XYZ",d);return e}};
l.zn=function(a,c){var d=T(null,this.vd,a,c,this);if(d)return d};l.dh=function(a,c){var d=this.re(a,c);if(d){var e=new vf(null);wf(e,"XYZ",d);return e}};l.ue=function(a,c){var d=T([null],this.Fe,a,c,this);if(d&&d[0]){var e=new D(null),f=d[0],g=[f.length],h,k;h=1;for(k=d.length;h<k;++h)kb(f,d[h]),g.push(f.length);Jf(e,"XYZ",f,g);return e}};l.re=function(a,c){return T(null,this.vd,a,c,this)};l.Wh=Object({"http://www.opengis.net/gml":{pointMember:Ap(os.prototype.Xg),pointMembers:Ap(os.prototype.Xg)}});
l.Vh=Object({"http://www.opengis.net/gml":{lineStringMember:Ap(os.prototype.og),lineStringMembers:Ap(os.prototype.og)}});l.Xh=Object({"http://www.opengis.net/gml":{polygonMember:Ap(os.prototype.Yg),polygonMembers:Ap(os.prototype.Yg)}});l.$h=Object({"http://www.opengis.net/gml":{Point:Ap(os.prototype.re)}});l.Th=Object({"http://www.opengis.net/gml":{LineString:Ap(os.prototype.te)}});l.ai=Object({"http://www.opengis.net/gml":{Polygon:Ap(os.prototype.ue)}});l.wd=Object({"http://www.opengis.net/gml":{LinearRing:Bp(os.prototype.zn)}});
l.Rb=function(a,c){var d={featureType:this.featureType,featureNS:this.featureNS};c&&Xb(d,Vr(this,a,c));return this.pd(a,[d])};l.ve=function(a){return Ee(this.A?this.A:a.firstElementChild.getAttribute("srsName"))};function ps(a){a=ep(a,!1);return qs(a)}function qs(a){if(a=/^\s*(true|1)|(false|0)\s*$/.exec(a))return void 0!==a[1]||!1}
function rs(a){a=ep(a,!1);if(a=/^\s*(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(Z|(?:([+\-])(\d{2})(?::(\d{2}))?))\s*$/.exec(a)){var c=Date.UTC(parseInt(a[1],10),parseInt(a[2],10)-1,parseInt(a[3],10),parseInt(a[4],10),parseInt(a[5],10),parseInt(a[6],10))/1E3;if("Z"!=a[7]){var d="-"==a[8]?-1:1,c=c+60*d*parseInt(a[9],10);void 0!==a[10]&&(c+=3600*d*parseInt(a[10],10))}return c}}function ss(a){a=ep(a,!1);return ts(a)}
function ts(a){if(a=/^\s*([+\-]?\d*\.?\d+(?:e[+\-]?\d+)?)\s*$/i.exec(a))return parseFloat(a[1])}function us(a){a=ep(a,!1);return vs(a)}function vs(a){if(a=/^\s*(\d+)\s*$/.exec(a))return parseInt(a[1],10)}function W(a){return ep(a,!1).trim()}function ws(a,c){xs(a,c?"1":"0")}function ys(a,c){a.appendChild(ap.createTextNode(c.toPrecision()))}function zs(a,c){a.appendChild(ap.createTextNode(c.toString()))}function xs(a,c){a.appendChild(ap.createTextNode(c))};function As(a){a=a?a:{};os.call(this,a);this.b["http://www.opengis.net/gml"].featureMember=Ap(os.prototype.pd);this.schemaLocation=a.schemaLocation?a.schemaLocation:"http://www.opengis.net/gml http://schemas.opengis.net/gml/2.1.2/feature.xsd"}w(As,os);l=As.prototype;
l.ah=function(a,c){var d=ep(a,!1).replace(/^\s*|\s*$/g,""),e=c[0].srsName,f=a.parentNode.getAttribute("srsDimension"),g="enu";e&&(g=He(Ee(e)));d=d.split(/[\s,]+/);e=2;a.getAttribute("srsDimension")?e=vs(a.getAttribute("srsDimension")):a.getAttribute("dimension")?e=vs(a.getAttribute("dimension")):f&&(e=vs(f));for(var h,k,m=[],n=0,p=d.length;n<p;n+=e)f=parseFloat(d[n]),h=parseFloat(d[n+1]),k=3===e?parseFloat(d[n+2]):0,"en"===g.substr(0,2)?m.push(f,h,k):m.push(h,f,k);return m};
l.xn=function(a,c){var d=T([null],this.Ph,a,c,this);return Rd(d[1][0],d[1][1],d[1][3],d[1][4])};l.kk=function(a,c){var d=T(void 0,this.wd,a,c,this);d&&c[c.length-1].push(d)};l.fn=function(a,c){var d=T(void 0,this.wd,a,c,this);d&&(c[c.length-1][0]=d)};l.vd=Object({"http://www.opengis.net/gml":{coordinates:Bp(As.prototype.ah)}});l.Fe=Object({"http://www.opengis.net/gml":{innerBoundaryIs:As.prototype.kk,outerBoundaryIs:As.prototype.fn}});l.Ph=Object({"http://www.opengis.net/gml":{coordinates:Ap(As.prototype.ah)}});
l.Jf=Object({"http://www.opengis.net/gml":{Point:Bp(os.prototype.hh),MultiPoint:Bp(os.prototype.fh),LineString:Bp(os.prototype.te),MultiLineString:Bp(os.prototype.eh),LinearRing:Bp(os.prototype.dh),Polygon:Bp(os.prototype.ue),MultiPolygon:Bp(os.prototype.gh),Box:Bp(As.prototype.xn)}});function Bs(a){a=a?a:{};os.call(this,a);this.l=void 0!==a.surface?a.surface:!1;this.g=void 0!==a.curve?a.curve:!1;this.i=void 0!==a.multiCurve?a.multiCurve:!0;this.j=void 0!==a.multiSurface?a.multiSurface:!0;this.schemaLocation=a.schemaLocation?a.schemaLocation:"http://www.opengis.net/gml http://schemas.opengis.net/gml/3.1.1/profiles/gmlsfProfile/1.0.0/gmlsf.xsd"}w(Bs,os);l=Bs.prototype;l.Cn=function(a,c){var d=T([],this.Uh,a,c,this);if(d){var e=new N(null);ln(e,d);return e}};
l.Dn=function(a,c){var d=T([],this.Yh,a,c,this);if(d){var e=new O(null);on(e,d);return e}};l.Xf=function(a,c){Ip(this.Qh,a,c,this)};l.Ah=function(a,c){Ip(this.ei,a,c,this)};l.Gn=function(a,c){return T([null],this.Zh,a,c,this)};l.In=function(a,c){return T([null],this.di,a,c,this)};l.Hn=function(a,c){return T([null],this.Fe,a,c,this)};l.Bn=function(a,c){return T([null],this.vd,a,c,this)};l.mk=function(a,c){var d=T(void 0,this.wd,a,c,this);d&&c[c.length-1].push(d)};
l.Fi=function(a,c){var d=T(void 0,this.wd,a,c,this);d&&(c[c.length-1][0]=d)};l.jh=function(a,c){var d=T([null],this.fi,a,c,this);if(d&&d[0]){var e=new D(null),f=d[0],g=[f.length],h,k;h=1;for(k=d.length;h<k;++h)kb(f,d[h]),g.push(f.length);Jf(e,"XYZ",f,g);return e}};l.Zg=function(a,c){var d=T([null],this.Rh,a,c,this);if(d){var e=new I(null);jn(e,"XYZ",d);return e}};l.yn=function(a,c){var d=T([null],this.Sh,a,c,this);return Rd(d[1][0],d[1][1],d[2][0],d[2][1])};
l.An=function(a,c){for(var d=ep(a,!1),e=/^\s*([+\-]?\d*\.?\d+(?:[eE][+\-]?\d+)?)\s*/,f=[],g;g=e.exec(d);)f.push(parseFloat(g[1])),d=d.substr(g[0].length);if(""===d){d=c[0].srsName;e="enu";d&&(e=He(Ee(d)));if("neu"===e)for(d=0,e=f.length;d<e;d+=3)g=f[d],f[d]=f[d+1],f[d+1]=g;d=f.length;2==d&&f.push(0);return 0===d?void 0:f}};
l.yf=function(a,c){var d=ep(a,!1).replace(/^\s*|\s*$/g,""),e=c[0].srsName,f=a.parentNode.getAttribute("srsDimension"),g="enu";e&&(g=He(Ee(e)));d=d.split(/\s+/);e=2;a.getAttribute("srsDimension")?e=vs(a.getAttribute("srsDimension")):a.getAttribute("dimension")?e=vs(a.getAttribute("dimension")):f&&(e=vs(f));for(var h,k,m=[],n=0,p=d.length;n<p;n+=e)f=parseFloat(d[n]),h=parseFloat(d[n+1]),k=3===e?parseFloat(d[n+2]):0,"en"===g.substr(0,2)?m.push(f,h,k):m.push(h,f,k);return m};
l.vd=Object({"http://www.opengis.net/gml":{pos:Bp(Bs.prototype.An),posList:Bp(Bs.prototype.yf)}});l.Fe=Object({"http://www.opengis.net/gml":{interior:Bs.prototype.mk,exterior:Bs.prototype.Fi}});
l.Jf=Object({"http://www.opengis.net/gml":{Point:Bp(os.prototype.hh),MultiPoint:Bp(os.prototype.fh),LineString:Bp(os.prototype.te),MultiLineString:Bp(os.prototype.eh),LinearRing:Bp(os.prototype.dh),Polygon:Bp(os.prototype.ue),MultiPolygon:Bp(os.prototype.gh),Surface:Bp(Bs.prototype.jh),MultiSurface:Bp(Bs.prototype.Dn),Curve:Bp(Bs.prototype.Zg),MultiCurve:Bp(Bs.prototype.Cn),Envelope:Bp(Bs.prototype.yn)}});l.Uh=Object({"http://www.opengis.net/gml":{curveMember:Ap(Bs.prototype.Xf),curveMembers:Ap(Bs.prototype.Xf)}});
l.Yh=Object({"http://www.opengis.net/gml":{surfaceMember:Ap(Bs.prototype.Ah),surfaceMembers:Ap(Bs.prototype.Ah)}});l.Qh=Object({"http://www.opengis.net/gml":{LineString:Ap(os.prototype.te),Curve:Ap(Bs.prototype.Zg)}});l.ei=Object({"http://www.opengis.net/gml":{Polygon:Ap(os.prototype.ue),Surface:Ap(Bs.prototype.jh)}});l.fi=Object({"http://www.opengis.net/gml":{patches:Bp(Bs.prototype.Gn)}});l.Rh=Object({"http://www.opengis.net/gml":{segments:Bp(Bs.prototype.In)}});
l.Sh=Object({"http://www.opengis.net/gml":{lowerCorner:Ap(Bs.prototype.yf),upperCorner:Ap(Bs.prototype.yf)}});l.Zh=Object({"http://www.opengis.net/gml":{PolygonPatch:Bp(Bs.prototype.Hn)}});l.di=Object({"http://www.opengis.net/gml":{LineStringSegment:Bp(Bs.prototype.Bn)}});function Cs(a,c,d){d=d[d.length-1].srsName;c=c.X();for(var e=c.length,f=Array(e),g,h=0;h<e;++h){g=c[h];var k=h,m="enu";d&&(m=He(Ee(d)));f[k]="en"===m.substr(0,2)?g[0]+" "+g[1]:g[1]+" "+g[0]}xs(a,f.join(" "))}
l.Lh=function(a,c,d){var e=d[d.length-1].srsName;e&&a.setAttribute("srsName",e);e=dp(a.namespaceURI,"pos");a.appendChild(e);d=d[d.length-1].srsName;a="enu";d&&(a=He(Ee(d)));c=c.X();xs(e,"en"===a.substr(0,2)?c[0]+" "+c[1]:c[1]+" "+c[0])};var Ds={"http://www.opengis.net/gml":{lowerCorner:R(xs),upperCorner:R(xs)}};l=Bs.prototype;l.vo=function(a,c,d){var e=d[d.length-1].srsName;e&&a.setAttribute("srsName",e);Jp({node:a},Ds,Gp,[c[0]+" "+c[1],c[2]+" "+c[3]],d,["lowerCorner","upperCorner"],this)};
l.Ih=function(a,c,d){var e=d[d.length-1].srsName;e&&a.setAttribute("srsName",e);e=dp(a.namespaceURI,"posList");a.appendChild(e);Cs(e,c,d)};l.ci=function(a,c){var d=c[c.length-1],e=d.node,f=d.exteriorWritten;void 0===f&&(d.exteriorWritten=!0);return dp(e.namespaceURI,void 0!==f?"interior":"exterior")};
l.Ee=function(a,c,d){var e=d[d.length-1].srsName;"PolygonPatch"!==a.nodeName&&e&&a.setAttribute("srsName",e);"Polygon"===a.nodeName||"PolygonPatch"===a.nodeName?(c=c.Ld(),Jp({node:a,srsName:e},Es,this.ci,c,d,void 0,this)):"Surface"===a.nodeName&&(e=dp(a.namespaceURI,"patches"),a.appendChild(e),a=dp(e.namespaceURI,"PolygonPatch"),e.appendChild(a),this.Ee(a,c,d))};
l.ze=function(a,c,d){var e=d[d.length-1].srsName;"LineStringSegment"!==a.nodeName&&e&&a.setAttribute("srsName",e);"LineString"===a.nodeName||"LineStringSegment"===a.nodeName?(e=dp(a.namespaceURI,"posList"),a.appendChild(e),Cs(e,c,d)):"Curve"===a.nodeName&&(e=dp(a.namespaceURI,"segments"),a.appendChild(e),a=dp(e.namespaceURI,"LineStringSegment"),e.appendChild(a),this.ze(a,c,d))};
l.Kh=function(a,c,d){var e=d[d.length-1],f=e.srsName,e=e.surface;f&&a.setAttribute("srsName",f);c=c.Md();Jp({node:a,srsName:f,surface:e},Fs,this.f,c,d,void 0,this)};l.wo=function(a,c,d){var e=d[d.length-1].srsName;e&&a.setAttribute("srsName",e);c=c.ee();Jp({node:a,srsName:e},Gs,Ep("pointMember"),c,d,void 0,this)};l.Jh=function(a,c,d){var e=d[d.length-1],f=e.srsName,e=e.curve;f&&a.setAttribute("srsName",f);c=c.ed();Jp({node:a,srsName:f,curve:e},Hs,this.f,c,d,void 0,this)};
l.Mh=function(a,c,d){var e=dp(a.namespaceURI,"LinearRing");a.appendChild(e);this.Ih(e,c,d)};l.Nh=function(a,c,d){var e=this.c(c,d);e&&(a.appendChild(e),this.Ee(e,c,d))};l.xo=function(a,c,d){var e=dp(a.namespaceURI,"Point");a.appendChild(e);this.Lh(e,c,d)};l.Hh=function(a,c,d){var e=this.c(c,d);e&&(a.appendChild(e),this.ze(e,c,d))};
l.Ce=function(a,c,d){var e=d[d.length-1],f=Ub(e);f.node=a;var g;ga(c)?e.dataProjection?g=$e(c,e.featureProjection,e.dataProjection):g=c:g=Xr(c,!0,e);Jp(f,Is,this.c,[g],d,void 0,this)};
l.Fh=function(a,c,d){var e=c.Fa();e&&a.setAttribute("fid",e);var e=d[d.length-1],f=e.featureNS,g=c.a;e.jc||(e.jc={},e.jc[f]={});var h=c.S();c=[];var k=[],m;for(m in h){var n=h[m];null!==n&&(c.push(m),k.push(n),m==g||n instanceof af?m in e.jc[f]||(e.jc[f][m]=R(this.Ce,this)):m in e.jc[f]||(e.jc[f][m]=R(xs)))}m=Ub(e);m.node=a;Jp(m,e.jc,Ep(void 0,f),k,d,c)};
var Fs={"http://www.opengis.net/gml":{surfaceMember:R(Bs.prototype.Nh),polygonMember:R(Bs.prototype.Nh)}},Gs={"http://www.opengis.net/gml":{pointMember:R(Bs.prototype.xo)}},Hs={"http://www.opengis.net/gml":{lineStringMember:R(Bs.prototype.Hh),curveMember:R(Bs.prototype.Hh)}},Es={"http://www.opengis.net/gml":{exterior:R(Bs.prototype.Mh),interior:R(Bs.prototype.Mh)}},Is={"http://www.opengis.net/gml":{Curve:R(Bs.prototype.ze),MultiCurve:R(Bs.prototype.Jh),Point:R(Bs.prototype.Lh),MultiPoint:R(Bs.prototype.wo),
LineString:R(Bs.prototype.ze),MultiLineString:R(Bs.prototype.Jh),LinearRing:R(Bs.prototype.Ih),Polygon:R(Bs.prototype.Ee),MultiPolygon:R(Bs.prototype.Kh),Surface:R(Bs.prototype.Ee),MultiSurface:R(Bs.prototype.Kh),Envelope:R(Bs.prototype.vo)}},Js={MultiLineString:"lineStringMember",MultiCurve:"curveMember",MultiPolygon:"polygonMember",MultiSurface:"surfaceMember"};Bs.prototype.f=function(a,c){return dp("http://www.opengis.net/gml",Js[c[c.length-1].node.nodeName])};
Bs.prototype.c=function(a,c){var d=c[c.length-1],e=d.multiSurface,f=d.surface,g=d.curve,d=d.multiCurve,h;ga(a)?h="Envelope":(h=a.Z(),"MultiPolygon"===h&&!0===e?h="MultiSurface":"Polygon"===h&&!0===f?h="Surface":"LineString"===h&&!0===g?h="Curve":"MultiLineString"===h&&!0===d&&(h="MultiCurve"));return dp("http://www.opengis.net/gml",h)};
Bs.prototype.D=function(a,c){c=Wr(this,c);var d=dp("http://www.opengis.net/gml","geom"),e={node:d,srsName:this.srsName,curve:this.g,surface:this.l,multiSurface:this.j,multiCurve:this.i};c&&Xb(e,c);this.Ce(d,a,[e]);return d};
Bs.prototype.a=function(a,c){c=Wr(this,c);var d=dp("http://www.opengis.net/gml","featureMembers");xp(d,"http://www.w3.org/2001/XMLSchema-instance","xsi:schemaLocation",this.schemaLocation);var e={srsName:this.srsName,curve:this.g,surface:this.l,multiSurface:this.j,multiCurve:this.i,featureNS:this.featureNS,featureType:this.featureType};c&&Xb(e,c);var e=[e],f=e[e.length-1],g=f.featureType,h=f.featureNS,k={};k[h]={};k[h][g]=R(this.Fh,this);f=Ub(f);f.node=d;Jp(f,k,Ep(g,h),a,e);return d};function Ks(a){a=a?a:{};this.defaultDataProjection=null;this.defaultDataProjection=Ee("EPSG:4326");this.b=a.readExtensions}w(Ks,ls);var Ls=[null,"http://www.topografix.com/GPX/1/0","http://www.topografix.com/GPX/1/1"];function Ms(a,c,d){a.push(parseFloat(c.getAttribute("lon")),parseFloat(c.getAttribute("lat")));"ele"in d?(a.push(d.ele),delete d.ele):a.push(0);"time"in d?(a.push(d.time),delete d.time):a.push(0);return a}
function Ns(a,c){var d=c[c.length-1],e=a.getAttribute("href");null!==e&&(d.link=e);Ip(Os,a,c)}function Ps(a,c){c[c.length-1].extensionsNode_=a}function Qs(a,c){var d=c[0],e=T({flatCoordinates:[]},Rs,a,c);if(e){var f=e.flatCoordinates;delete e.flatCoordinates;var g=new I(null);jn(g,"XYZM",f);Xr(g,!1,d);d=new P(g);d.K(e);return d}}
function Ss(a,c){var d=c[0],e=T({flatCoordinates:[],ends:[]},Ts,a,c);if(e){var f=e.flatCoordinates;delete e.flatCoordinates;var g=e.ends;delete e.ends;var h=new N(null);kn(h,"XYZM",f,g);Xr(h,!1,d);d=new P(h);d.K(e);return d}}function Us(a,c){var d=c[0],e=T({},Vs,a,c);if(e){var f=Ms([],a,e),f=new C(f,"XYZM");Xr(f,!1,d);d=new P(f);d.K(e);return d}}
var Ws={rte:Qs,trk:Ss,wpt:Us},Xs=S(Ls,{rte:Ap(Qs),trk:Ap(Ss),wpt:Ap(Us)}),Os=S(Ls,{text:Q(W,"linkText"),type:Q(W,"linkType")}),Rs=S(Ls,{name:Q(W),cmt:Q(W),desc:Q(W),src:Q(W),link:Ns,number:Q(us),extensions:Ps,type:Q(W),rtept:function(a,c){var d=T({},Ys,a,c);d&&Ms(c[c.length-1].flatCoordinates,a,d)}}),Ys=S(Ls,{ele:Q(ss),time:Q(rs)}),Ts=S(Ls,{name:Q(W),cmt:Q(W),desc:Q(W),src:Q(W),link:Ns,number:Q(us),type:Q(W),extensions:Ps,trkseg:function(a,c){var d=c[c.length-1];Ip(Zs,a,c);d.ends.push(d.flatCoordinates.length)}}),
Zs=S(Ls,{trkpt:function(a,c){var d=T({},$s,a,c);d&&Ms(c[c.length-1].flatCoordinates,a,d)}}),$s=S(Ls,{ele:Q(ss),time:Q(rs)}),Vs=S(Ls,{ele:Q(ss),time:Q(rs),magvar:Q(ss),geoidheight:Q(ss),name:Q(W),cmt:Q(W),desc:Q(W),src:Q(W),link:Ns,sym:Q(W),type:Q(W),fix:Q(W),sat:Q(us),hdop:Q(ss),vdop:Q(ss),pdop:Q(ss),ageofdgpsdata:Q(ss),dgpsid:Q(us),extensions:Ps});
function at(a,c){c||(c=[]);for(var d=0,e=c.length;d<e;++d){var f=c[d];if(a.b){var g=f.get("extensionsNode_")||null;a.b(f,g)}f.set("extensionsNode_",void 0)}}Ks.prototype.$g=function(a,c){if(!ub(Ls,a.namespaceURI))return null;var d=Ws[a.localName];if(!d)return null;d=d(a,[Vr(this,a,c)]);if(!d)return null;at(this,[d]);return d};Ks.prototype.Rb=function(a,c){if(!ub(Ls,a.namespaceURI))return[];if("gpx"==a.localName){var d=T([],Xs,a,[Vr(this,a,c)]);if(d)return at(this,d),d}return[]};
function bt(a,c,d){a.setAttribute("href",c);c=d[d.length-1].properties;Jp({node:a},ct,Gp,[c.linkText,c.linkType],d,dt)}function et(a,c,d){var e=d[d.length-1],f=e.node.namespaceURI,g=e.properties;xp(a,null,"lat",c[1]);xp(a,null,"lon",c[0]);switch(e.geometryLayout){case "XYZM":0!==c[3]&&(g.time=c[3]);case "XYZ":0!==c[2]&&(g.ele=c[2]);break;case "XYM":0!==c[2]&&(g.time=c[2])}c=ft[f];e=Hp(g,c);Jp({node:a,properties:g},gt,Gp,e,d,c)}
var dt=["text","type"],ct=S(Ls,{text:R(xs),type:R(xs)}),ht=S(Ls,"name cmt desc src link number type rtept".split(" ")),it=S(Ls,{name:R(xs),cmt:R(xs),desc:R(xs),src:R(xs),link:R(bt),number:R(zs),type:R(xs),rtept:Dp(R(et))}),jt=S(Ls,"name cmt desc src link number type trkseg".split(" ")),mt=S(Ls,{name:R(xs),cmt:R(xs),desc:R(xs),src:R(xs),link:R(bt),number:R(zs),type:R(xs),trkseg:Dp(R(function(a,c,d){Jp({node:a,geometryLayout:c.a,properties:{}},kt,lt,c.X(),d)}))}),lt=Ep("trkpt"),kt=S(Ls,{trkpt:R(et)}),
ft=S(Ls,"ele time magvar geoidheight name cmt desc src link sym type fix sat hdop vdop pdop ageofdgpsdata dgpsid".split(" ")),gt=S(Ls,{ele:R(ys),time:R(function(a,c){var d=new Date(1E3*c),d=d.getUTCFullYear()+"-"+Pa(d.getUTCMonth()+1)+"-"+Pa(d.getUTCDate())+"T"+Pa(d.getUTCHours())+":"+Pa(d.getUTCMinutes())+":"+Pa(d.getUTCSeconds())+"Z";a.appendChild(ap.createTextNode(d))}),magvar:R(ys),geoidheight:R(ys),name:R(xs),cmt:R(xs),desc:R(xs),src:R(xs),link:R(bt),sym:R(xs),type:R(xs),fix:R(xs),sat:R(zs),
hdop:R(ys),vdop:R(ys),pdop:R(ys),ageofdgpsdata:R(ys),dgpsid:R(zs)}),nt={Point:"wpt",LineString:"rte",MultiLineString:"trk"};function ot(a,c){var d=a.Y();if(d)return dp(c[c.length-1].node.namespaceURI,nt[d.Z()])}
var pt=S(Ls,{rte:R(function(a,c,d){var e=d[0],f=c.S();a={node:a,properties:f};if(c=c.Y())c=Xr(c,!0,e),a.geometryLayout=c.a,f.rtept=c.X();e=ht[d[d.length-1].node.namespaceURI];f=Hp(f,e);Jp(a,it,Gp,f,d,e)}),trk:R(function(a,c,d){var e=d[0],f=c.S();a={node:a,properties:f};if(c=c.Y())c=Xr(c,!0,e),f.trkseg=c.ed();e=jt[d[d.length-1].node.namespaceURI];f=Hp(f,e);Jp(a,mt,Gp,f,d,e)}),wpt:R(function(a,c,d){var e=d[0],f=d[d.length-1];f.properties=c.S();if(c=c.Y())c=Xr(c,!0,e),f.geometryLayout=c.a,et(a,c.X(),
d)})});Ks.prototype.a=function(a,c){c=Wr(this,c);var d=dp("http://www.topografix.com/GPX/1/1","gpx");Jp({node:d},pt,ot,a,[c]);return d};function qt(a){a=rt(a);return cb(a,function(a){return a.c.substring(a.a,a.b)})}function st(a,c,d){this.c=a;this.a=c;this.b=d}function rt(a){for(var c=RegExp("\r\n|\r|\n","g"),d=0,e,f=[];e=c.exec(a);)d=new st(a,d,e.index),f.push(d),d=c.lastIndex;d<a.length&&(d=new st(a,d,a.length),f.push(d));return f};function tt(){this.defaultDataProjection=null}w(tt,Ur);l=tt.prototype;l.Z=function(){return"text"};l.Bb=function(a,c){return this.od(ia(a)?a:"",Wr(this,c))};l.va=function(a,c){return this.xf(ia(a)?a:"",Wr(this,c))};l.Ic=function(a,c){return this.qd(ia(a)?a:"",Wr(this,c))};l.Pa=function(){return this.defaultDataProjection};l.td=function(a,c){return this.Ae(a,Wr(this,c))};l.Db=function(a,c){return this.Gh(a,Wr(this,c))};l.Oc=function(a,c){return this.ud(a,Wr(this,c))};function ut(a){a=a?a:{};this.defaultDataProjection=null;this.defaultDataProjection=Ee("EPSG:4326");this.b=a.altitudeMode?a.altitudeMode:"none"}w(ut,tt);var vt=/^B(\d{2})(\d{2})(\d{2})(\d{2})(\d{5})([NS])(\d{3})(\d{5})([EW])([AV])(\d{5})(\d{5})/,wt=/^H.([A-Z]{3}).*?:(.*)/,xt=/^HFDTE(\d{2})(\d{2})(\d{2})/;
ut.prototype.od=function(a,c){var d=this.b,e=qt(a),f={},g=[],h=2E3,k=0,m=1,n,p;n=0;for(p=e.length;n<p;++n){var q=e[n],r;if("B"==q.charAt(0)){if(r=vt.exec(q)){var q=parseInt(r[1],10),t=parseInt(r[2],10),y=parseInt(r[3],10),A=parseInt(r[4],10)+parseInt(r[5],10)/6E4;"S"==r[6]&&(A=-A);var F=parseInt(r[7],10)+parseInt(r[8],10)/6E4;"W"==r[9]&&(F=-F);g.push(F,A);"none"!=d&&g.push("gps"==d?parseInt(r[11],10):"barometric"==d?parseInt(r[12],10):0);g.push(Date.UTC(h,k,m,q,t,y)/1E3)}}else if("H"==q.charAt(0))if(r=
xt.exec(q))m=parseInt(r[1],10),k=parseInt(r[2],10)-1,h=2E3+parseInt(r[3],10);else if(r=wt.exec(q))f[r[1]]=r[2].trim(),xt.exec(q)}if(0===g.length)return null;e=new I(null);jn(e,"none"==d?"XYM":"XYZM",g);d=new P(Xr(e,!1,c));d.K(f);return d};ut.prototype.xf=function(a,c){var d=this.od(a,c);return d?[d]:[]};function yt(a,c){this.a=this.j=this.f="";this.l=null;this.g=this.b="";this.i=!1;var d;a instanceof yt?(this.i=ca(c)?c:a.i,zt(this,a.f),this.j=a.j,this.a=a.a,At(this,a.l),this.b=a.b,Bt(this,a.c.clone()),this.g=a.g):a&&(d=String(a).match(Bo))?(this.i=!!c,zt(this,d[1]||"",!0),this.j=Ct(d[2]||""),this.a=Ct(d[3]||"",!0),At(this,d[4]),this.b=Ct(d[5]||"",!0),Bt(this,d[6]||"",!0),this.g=Ct(d[7]||"")):(this.i=!!c,this.c=new Dt(null,0,this.i))}
yt.prototype.toString=function(){var a=[],c=this.f;c&&a.push(Et(c,Ft,!0),":");var d=this.a;if(d||"file"==c)a.push("//"),(c=this.j)&&a.push(Et(c,Ft,!0),"@"),a.push(encodeURIComponent(String(d)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),d=this.l,null!=d&&a.push(":",String(d));if(d=this.b)this.a&&"/"!=d.charAt(0)&&a.push("/"),a.push(Et(d,"/"==d.charAt(0)?Gt:Ht,!0));(d=this.c.toString())&&a.push("?",d);(d=this.g)&&a.push("#",Et(d,It));return a.join("")};yt.prototype.clone=function(){return new yt(this)};
function zt(a,c,d){a.f=d?Ct(c,!0):c;a.f&&(a.f=a.f.replace(/:$/,""))}function At(a,c){if(c){c=Number(c);if(isNaN(c)||0>c)throw Error("Bad port number "+c);a.l=c}else a.l=null}function Bt(a,c,d){c instanceof Dt?(a.c=c,Jt(a.c,a.i)):(d||(c=Et(c,Kt)),a.c=new Dt(c,0,a.i))}function Lt(a){return a instanceof yt?a.clone():new yt(a,void 0)}
function Mt(a,c){a instanceof yt||(a=Lt(a));c instanceof yt||(c=Lt(c));var d=a,e=c,f=d.clone(),g=!!e.f;g?zt(f,e.f):g=!!e.j;g?f.j=e.j:g=!!e.a;g?f.a=e.a:g=null!=e.l;var h=e.b;if(g)At(f,e.l);else if(g=!!e.b)if("/"!=h.charAt(0)&&(d.a&&!d.b?h="/"+h:(d=f.b.lastIndexOf("/"),-1!=d&&(h=f.b.substr(0,d+1)+h))),d=h,".."==d||"."==d)h="";else if(-1!=d.indexOf("./")||-1!=d.indexOf("/.")){for(var h=0==d.lastIndexOf("/",0),d=d.split("/"),k=[],m=0;m<d.length;){var n=d[m++];"."==n?h&&m==d.length&&k.push(""):".."==n?
((1<k.length||1==k.length&&""!=k[0])&&k.pop(),h&&m==d.length&&k.push("")):(k.push(n),h=!0)}h=k.join("/")}else h=d;g?f.b=h:g=""!==e.c.toString();g?Bt(f,Ct(e.c.toString())):g=!!e.g;g&&(f.g=e.g);return f}function Ct(a,c){return a?c?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function Et(a,c,d){return ia(a)?(a=encodeURI(a).replace(c,Nt),d&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function Nt(a){a=a.charCodeAt(0);return"%"+(a>>4&15).toString(16)+(a&15).toString(16)}
var Ft=/[#\/\?@]/g,Ht=/[\#\?:]/g,Gt=/[\#\?]/g,Kt=/[\#\?@]/g,It=/#/g;function Dt(a,c,d){this.a=this.b=null;this.c=a||null;this.f=!!d}function Ot(a){a.b||(a.b=new vi,a.a=0,a.c&&Co(a.c,function(c,d){a.add(decodeURIComponent(c.replace(/\+/g," ")),d)}))}l=Dt.prototype;l.Vb=function(){Ot(this);return this.a};l.add=function(a,c){Ot(this);this.c=null;a=Pt(this,a);var d=this.b.get(a);d||this.b.set(a,d=[]);d.push(c);this.a++;return this};
l.remove=function(a){Ot(this);a=Pt(this,a);return xi(this.b.a,a)?(this.c=null,this.a-=this.b.get(a).length,this.b.remove(a)):!1};l.clear=function(){this.b=this.c=null;this.a=0};l.Ba=function(){Ot(this);return 0==this.a};function Qt(a,c){Ot(a);c=Pt(a,c);return xi(a.b.a,c)}l.R=function(){Ot(this);for(var a=this.b.Zb(),c=this.b.R(),d=[],e=0;e<c.length;e++)for(var f=a[e],g=0;g<f.length;g++)d.push(c[e]);return d};
l.Zb=function(a){Ot(this);var c=[];if(ia(a))Qt(this,a)&&(c=ib(c,this.b.get(Pt(this,a))));else{a=this.b.Zb();for(var d=0;d<a.length;d++)c=ib(c,a[d])}return c};l.set=function(a,c){Ot(this);this.c=null;a=Pt(this,a);Qt(this,a)&&(this.a-=this.b.get(a).length);this.b.set(a,[c]);this.a++;return this};l.get=function(a,c){var d=a?this.Zb(a):[];return 0<d.length?String(d[0]):c};function Rt(a,c,d){a.remove(c);0<d.length&&(a.c=null,a.b.set(Pt(a,c),jb(d)),a.a+=d.length)}
l.toString=function(){if(this.c)return this.c;if(!this.b)return"";for(var a=[],c=this.b.R(),d=0;d<c.length;d++)for(var e=c[d],f=encodeURIComponent(String(e)),e=this.Zb(e),g=0;g<e.length;g++){var h=f;""!==e[g]&&(h+="="+encodeURIComponent(String(e[g])));a.push(h)}return this.c=a.join("&")};l.clone=function(){var a=new Dt;a.c=this.c;this.b&&(a.b=this.b.clone(),a.a=this.a);return a};function Pt(a,c){var d=String(c);a.f&&(d=d.toLowerCase());return d}
function Jt(a,c){c&&!a.f&&(Ot(a),a.c=null,a.b.forEach(function(a,c){var f=c.toLowerCase();c!=f&&(this.remove(c),Rt(this,f,a))},a));a.f=c};function St(a){a=a||{};this.f=a.font;this.g=a.rotation;this.a=a.scale;this.c=a.text;this.j=a.textAlign;this.l=a.textBaseline;this.b=void 0!==a.fill?a.fill:new $l({color:"#333"});this.i=void 0!==a.stroke?a.stroke:null;this.D=void 0!==a.offsetX?a.offsetX:0;this.v=void 0!==a.offsetY?a.offsetY:0}l=St.prototype;l.Vi=function(){return this.f};l.jj=function(){return this.D};l.kj=function(){return this.v};l.Qm=function(){return this.b};l.Rm=function(){return this.g};l.Sm=function(){return this.a};l.Tm=function(){return this.i};
l.Um=function(){return this.c};l.wj=function(){return this.j};l.xj=function(){return this.l};l.Zn=function(a){this.f=a};l.Yn=function(a){this.b=a};l.Vm=function(a){this.g=a};l.Wm=function(a){this.a=a};l.fo=function(a){this.i=a};l.ho=function(a){this.c=a};l.io=function(a){this.j=a};l.jo=function(a){this.l=a};function Tt(a){a=a?a:{};this.defaultDataProjection=null;this.defaultDataProjection=Ee("EPSG:4326");this.c=a.defaultStyle?a.defaultStyle:Ut;this.f=void 0!==a.extractStyles?a.extractStyles:!0;this.b={}}w(Tt,ls);
var Vt=["http://www.google.com/kml/ext/2.2"],Wt=[null,"http://earth.google.com/kml/2.0","http://earth.google.com/kml/2.1","http://earth.google.com/kml/2.2","http://www.opengis.net/kml/2.2"],Xt=[255,255,255,1],Yt=new $l({color:Xt}),Zt=[20,2],$t=[64,64],au=new Ak({anchor:Zt,anchorOrigin:"bottom-left",anchorXUnits:"pixels",anchorYUnits:"pixels",crossOrigin:"anonymous",rotation:0,scale:.5,size:$t,src:"https://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png"}),bu=new em({color:Xt,width:1}),cu=new St({font:"normal 16px Helvetica",
fill:Yt,stroke:bu,scale:1}),Ut=[new gm({fill:Yt,image:au,text:cu,stroke:bu,zIndex:0})],du={fraction:"fraction",pixels:"pixels"};function eu(a,c,d,e){return function(){return a?a:c?fu(c,d,e):d}}function fu(a,c,d){return ga(a)?a:ia(a)?(!(a in d)&&"#"+a in d&&(a="#"+a),fu(d[a],c,d)):c}function gu(a){a=ep(a,!1);if(a=/^\s*#?\s*([0-9A-Fa-f]{8})\s*$/.exec(a))return a=a[1],[parseInt(a.substr(6,2),16),parseInt(a.substr(4,2),16),parseInt(a.substr(2,2),16),parseInt(a.substr(0,2),16)/255]}
function hu(a){a=ep(a,!1);for(var c=[],d=/^\s*([+\-]?\d*\.?\d+(?:e[+\-]?\d+)?)\s*,\s*([+\-]?\d*\.?\d+(?:e[+\-]?\d+)?)(?:\s*,\s*([+\-]?\d*\.?\d+(?:e[+\-]?\d+)?))?\s*/i,e;e=d.exec(a);)c.push(parseFloat(e[1]),parseFloat(e[2]),e[3]?parseFloat(e[3]):0),a=a.substr(e[0].length);return""!==a?void 0:c}function iu(a){var c=ep(a,!1);return a.baseURI?Mt(a.baseURI,c.trim()).toString():c.trim()}function ju(a){a=ss(a);if(void 0!==a)return Math.sqrt(a)}function ku(a,c){return T(null,lu,a,c)}
function mu(a,c){var d=T({o:[],Eh:[]},nu,a,c);if(d){var e=d.o,d=d.Eh,f,g;f=0;for(g=Math.min(e.length,d.length);f<g;++f)e[4*f+3]=d[f];d=new I(null);jn(d,"XYZM",e);return d}}function ou(a,c){var d=T({},pu,a,c),e=T(null,qu,a,c);if(e){var f=new I(null);jn(f,"XYZ",e);f.K(d);return f}}function ru(a,c){var d=T({},pu,a,c),e=T(null,qu,a,c);if(e){var f=new D(null);Jf(f,"XYZ",e,[e.length]);f.K(d);return f}}
function su(a,c){var d=T([],tu,a,c);if(!d)return null;if(0===d.length)return new bn(d);var e=!0,f=d[0].Z(),g,h,k;h=1;for(k=d.length;h<k;++h)if(g=d[h],g.Z()!=f){e=!1;break}if(e){if("Point"==f){g=d[0];e=g.a;f=g.o;h=1;for(k=d.length;h<k;++h)g=d[h],kb(f,g.o);g=new mn(null);ef(g,e,f);g.s();uu(g,d);return g}return"LineString"==f?(g=new N(null),ln(g,d),uu(g,d),g):"Polygon"==f?(g=new O(null),on(g,d),uu(g,d),g):"GeometryCollection"==f?new bn(d):null}return new bn(d)}
function vu(a,c){var d=T({},pu,a,c),e=T(null,qu,a,c);if(e){var f=new C(null);xf(f,"XYZ",e);f.K(d);return f}}function wu(a,c){var d=T({},pu,a,c),e=T([null],xu,a,c);if(e&&e[0]){var f=new D(null),g=e[0],h=[g.length],k,m;k=1;for(m=e.length;k<m;++k)kb(g,e[k]),h.push(g.length);Jf(f,"XYZ",g,h);f.K(d);return f}}
function yu(a,c){var d=T({},zu,a,c);if(!d)return null;var e="fillStyle"in d?d.fillStyle:Yt,f=d.fill;void 0===f||f||(e=null);var f="imageStyle"in d?d.imageStyle:au,g="textStyle"in d?d.textStyle:cu,h="strokeStyle"in d?d.strokeStyle:bu,d=d.outline;void 0===d||d||(h=null);return[new gm({fill:e,image:f,stroke:h,text:g,zIndex:void 0})]}
function uu(a,c){var d=c.length,e=Array(c.length),f=Array(c.length),g,h,k,m;k=m=!1;for(h=0;h<d;++h)g=c[h],e[h]=g.get("extrude"),f[h]=g.get("altitudeMode"),k=k||void 0!==e[h],m=m||f[h];k&&a.set("extrude",e);m&&a.set("altitudeMode",f)}function Au(a,c){Ip(Bu,a,c)}
var Cu=S(Wt,{value:Bp(W)}),Bu=S(Wt,{Data:function(a,c){var d=a.getAttribute("name");if(null!==d){var e=T(void 0,Cu,a,c);e&&(c[c.length-1][d]=e)}},SchemaData:function(a,c){Ip(Du,a,c)}}),pu=S(Wt,{extrude:Q(ps),altitudeMode:Q(W)}),lu=S(Wt,{coordinates:Bp(hu)}),xu=S(Wt,{innerBoundaryIs:function(a,c){var d=T(void 0,Eu,a,c);d&&c[c.length-1].push(d)},outerBoundaryIs:function(a,c){var d=T(void 0,Fu,a,c);d&&(c[c.length-1][0]=d)}}),nu=S(Wt,{when:function(a,c){var d=c[c.length-1].Eh,e=ep(a,!1);if(e=/^\s*(\d{4})($|-(\d{2})($|-(\d{2})($|T(\d{2}):(\d{2}):(\d{2})(Z|(?:([+\-])(\d{2})(?::(\d{2}))?)))))\s*$/.exec(e)){var f=
Date.UTC(parseInt(e[1],10),e[3]?parseInt(e[3],10)-1:0,e[5]?parseInt(e[5],10):1,e[7]?parseInt(e[7],10):0,e[8]?parseInt(e[8],10):0,e[9]?parseInt(e[9],10):0);if(e[10]&&"Z"!=e[10]){var g="-"==e[11]?-1:1,f=f+60*g*parseInt(e[12],10);e[13]&&(f+=3600*g*parseInt(e[13],10))}d.push(f)}else d.push(0)}},S(Vt,{coord:function(a,c){var d=c[c.length-1].o,e=ep(a,!1);(e=/^\s*([+\-]?\d+(?:\.\d*)?(?:e[+\-]?\d*)?)\s+([+\-]?\d+(?:\.\d*)?(?:e[+\-]?\d*)?)\s+([+\-]?\d+(?:\.\d*)?(?:e[+\-]?\d*)?)\s*$/i.exec(e))?d.push(parseFloat(e[1]),
parseFloat(e[2]),parseFloat(e[3]),0):d.push(0,0,0,0)}})),qu=S(Wt,{coordinates:Bp(hu)}),Gu=S(Wt,{href:Q(iu)},S(Vt,{x:Q(ss),y:Q(ss),w:Q(ss),h:Q(ss)})),Hu=S(Wt,{Icon:Q(function(a,c){var d=T({},Gu,a,c);return d?d:null}),heading:Q(ss),hotSpot:Q(function(a){var c=a.getAttribute("xunits"),d=a.getAttribute("yunits");return{x:parseFloat(a.getAttribute("x")),Hf:du[c],y:parseFloat(a.getAttribute("y")),If:du[d]}}),scale:Q(ju)}),Eu=S(Wt,{LinearRing:Bp(ku)}),Iu=S(Wt,{color:Q(gu),scale:Q(ju)}),Ju=S(Wt,{color:Q(gu),
width:Q(ss)}),tu=S(Wt,{LineString:Ap(ou),LinearRing:Ap(ru),MultiGeometry:Ap(su),Point:Ap(vu),Polygon:Ap(wu)}),Ku=S(Vt,{Track:Ap(mu)}),Mu=S(Wt,{ExtendedData:Au,Link:function(a,c){Ip(Lu,a,c)},address:Q(W),description:Q(W),name:Q(W),open:Q(ps),phoneNumber:Q(W),visibility:Q(ps)}),Lu=S(Wt,{href:Q(iu)}),Fu=S(Wt,{LinearRing:Bp(ku)}),Nu=S(Wt,{Style:Q(yu),key:Q(W),styleUrl:Q(function(a){var c=ep(a,!1).trim();return a.baseURI?Mt(a.baseURI,c).toString():c})}),Pu=S(Wt,{ExtendedData:Au,MultiGeometry:Q(su,"geometry"),
LineString:Q(ou,"geometry"),LinearRing:Q(ru,"geometry"),Point:Q(vu,"geometry"),Polygon:Q(wu,"geometry"),Style:Q(yu),StyleMap:function(a,c){var d=T(void 0,Ou,a,c);if(d){var e=c[c.length-1];ga(d)?e.Style=d:ia(d)&&(e.styleUrl=d)}},address:Q(W),description:Q(W),name:Q(W),open:Q(ps),phoneNumber:Q(W),styleUrl:Q(iu),visibility:Q(ps)},S(Vt,{MultiTrack:Q(function(a,c){var d=T([],Ku,a,c);if(d){var e=new N(null);ln(e,d);return e}},"geometry"),Track:Q(mu,"geometry")})),Qu=S(Wt,{color:Q(gu),fill:Q(ps),outline:Q(ps)}),
Du=S(Wt,{SimpleData:function(a,c){var d=a.getAttribute("name");if(null!==d){var e=W(a);c[c.length-1][d]=e}}}),zu=S(Wt,{IconStyle:function(a,c){var d=T({},Hu,a,c);if(d){var e=c[c.length-1],f="Icon"in d?d.Icon:{},g;g=(g=f.href)?g:"https://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png";var h,k,m,n=d.hotSpot;n?(h=[n.x,n.y],k=n.Hf,m=n.If):"https://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png"===g?(h=Zt,m=k="pixels"):/^http:\/\/maps\.(?:google|gstatic)\.com\//.test(g)&&(h=[.5,0],m=k="fraction");
var p,n=f.x,q=f.y;void 0!==n&&void 0!==q&&(p=[n,q]);var r,n=f.w,f=f.h;void 0!==n&&void 0!==f&&(r=[n,f]);var t,f=d.heading;void 0!==f&&(t=Wa(f));d=d.scale;"https://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png"==g&&(r=$t);h=new Ak({anchor:h,anchorOrigin:"bottom-left",anchorXUnits:k,anchorYUnits:m,crossOrigin:"anonymous",offset:p,offsetOrigin:"bottom-left",rotation:t,scale:.5*d,size:r,src:g});e.imageStyle=h}},LabelStyle:function(a,c){var d=T({},Iu,a,c);d&&(c[c.length-1].textStyle=new St({fill:new $l({color:"color"in
d?d.color:Xt}),scale:d.scale}))},LineStyle:function(a,c){var d=T({},Ju,a,c);d&&(c[c.length-1].strokeStyle=new em({color:"color"in d?d.color:Xt,width:"width"in d?d.width:1}))},PolyStyle:function(a,c){var d=T({},Qu,a,c);if(d){var e=c[c.length-1];e.fillStyle=new $l({color:"color"in d?d.color:Xt});var f=d.fill;void 0!==f&&(e.fill=f);d=d.outline;void 0!==d&&(e.outline=d)}}}),Ou=S(Wt,{Pair:function(a,c){var d=T({},Nu,a,c);if(d){var e=d.key;e&&"normal"==e&&((e=d.styleUrl)&&(c[c.length-1]=e),(d=d.Style)&&
(c[c.length-1]=d))}}});l=Tt.prototype;l.uf=function(a,c){ip(a);var d=S(Wt,{Document:zp(this.uf,this),Folder:zp(this.uf,this),Placemark:Ap(this.zf,this),Style:sa(this.Kn,this),StyleMap:sa(this.Jn,this)});if(d=T([],d,a,c,this))return d};l.zf=function(a,c){var d=T({geometry:null},Pu,a,c);if(d){var e=new P,f=a.getAttribute("id");null!==f&&e.Sb(f);var f=c[0],g=d.geometry;g&&Xr(g,!1,f);e.Ca(g);delete d.geometry;this.f&&e.jf(eu(d.Style,d.styleUrl,this.c,this.b));delete d.Style;e.K(d);return e}};
l.Kn=function(a,c){var d=a.getAttribute("id");if(null!==d){var e=yu(a,c);e&&(d=a.baseURI?Mt(a.baseURI,"#"+d).toString():"#"+d,this.b[d]=e)}};l.Jn=function(a,c){var d=a.getAttribute("id");if(null!==d){var e=T(void 0,Ou,a,c);e&&(d=a.baseURI?Mt(a.baseURI,"#"+d).toString():"#"+d,this.b[d]=e)}};l.$g=function(a,c){if(!ub(Wt,a.namespaceURI))return null;var d=this.zf(a,[Vr(this,a,c)]);return d?d:null};
l.Rb=function(a,c){if(!ub(Wt,a.namespaceURI))return[];var d;d=ip(a);if("Document"==d||"Folder"==d)return(d=this.uf(a,[Vr(this,a,c)]))?d:[];if("Placemark"==d)return(d=this.zf(a,[Vr(this,a,c)]))?[d]:[];if("kml"==d){d=[];var e;for(e=a.firstElementChild;e;e=e.nextElementSibling){var f=this.Rb(e,c);f&&kb(d,f)}return d}return[]};l.En=function(a){if(lp(a))return Ru(this,a);if(op(a))return Su(this,a);if(ia(a))return a=yp(a),Ru(this,a)};
function Ru(a,c){var d;for(d=c.firstChild;d;d=d.nextSibling)if(1==d.nodeType){var e=Su(a,d);if(e)return e}}function Su(a,c){var d;for(d=c.firstElementChild;d;d=d.nextElementSibling)if(ub(Wt,d.namespaceURI)&&"name"==d.localName)return W(d);for(d=c.firstElementChild;d;d=d.nextElementSibling){var e=ip(d);if(ub(Wt,d.namespaceURI)&&("Document"==e||"Folder"==e||"Placemark"==e||"kml"==e)&&(e=Su(a,d)))return e}}
l.Fn=function(a){var c=[];lp(a)?kb(c,Tu(this,a)):op(a)?kb(c,Uu(this,a)):ia(a)&&(a=yp(a),kb(c,Tu(this,a)));return c};function Tu(a,c){var d,e=[];for(d=c.firstChild;d;d=d.nextSibling)1==d.nodeType&&kb(e,Uu(a,d));return e}
function Uu(a,c){var d,e=[];for(d=c.firstElementChild;d;d=d.nextElementSibling)if(ub(Wt,d.namespaceURI)&&"NetworkLink"==d.localName){var f=T({},Mu,d,[]);e.push(f)}for(d=c.firstElementChild;d;d=d.nextElementSibling)f=ip(d),!ub(Wt,d.namespaceURI)||"Document"!=f&&"Folder"!=f&&"kml"!=f||kb(e,Uu(a,d));return e}function Vu(a,c){var d=Ag(c),d=[255*(4==d.length?d[3]:1),d[2],d[1],d[0]],e;for(e=0;4>e;++e){var f=parseInt(d[e],10).toString(16);d[e]=1==f.length?"0"+f:f}xs(a,d.join(""))}
function Wu(a,c,d){Jp({node:a},Xu,Yu,[c],d)}function Zu(a,c,d){var e={node:a};c.Fa()&&a.setAttribute("id",c.Fa());a=c.S();var f=c.c;f&&(f=f.call(c,0))&&0<f.length&&(a.Style=f[0],(f=f[0].a)&&(a.name=f.c));f=$u[d[d.length-1].node.namespaceURI];a=Hp(a,f);Jp(e,av,Gp,a,d,f);a=d[0];(c=c.Y())&&(c=Xr(c,!0,a));Jp(e,av,bv,[c],d)}function cv(a,c,d){var e=c.o;a={node:a};a.layout=c.a;a.stride=c.I;Jp(a,dv,ev,[e],d)}function fv(a,c,d){c=c.Ld();var e=c.shift();a={node:a};Jp(a,gv,hv,c,d);Jp(a,gv,iv,[e],d)}
function jv(a,c){ys(a,c*c)}
var kv=S(Wt,["Document","Placemark"]),nv=S(Wt,{Document:R(function(a,c,d){Jp({node:a},lv,mv,c,d)}),Placemark:R(Zu)}),lv=S(Wt,{Placemark:R(Zu)}),ov={Point:"Point",LineString:"LineString",LinearRing:"LinearRing",Polygon:"Polygon",MultiPoint:"MultiGeometry",MultiLineString:"MultiGeometry",MultiPolygon:"MultiGeometry"},pv=S(Wt,["href"],S(Vt,["x","y","w","h"])),qv=S(Wt,{href:R(xs)},S(Vt,{x:R(ys),y:R(ys),w:R(ys),h:R(ys)})),rv=S(Wt,["scale","heading","Icon","hotSpot"]),tv=S(Wt,{Icon:R(function(a,c,d){a=
{node:a};var e=pv[d[d.length-1].node.namespaceURI],f=Hp(c,e);Jp(a,qv,Gp,f,d,e);e=pv[Vt[0]];f=Hp(c,e);Jp(a,qv,sv,f,d,e)}),heading:R(ys),hotSpot:R(function(a,c){a.setAttribute("x",c.x);a.setAttribute("y",c.y);a.setAttribute("xunits",c.Hf);a.setAttribute("yunits",c.If)}),scale:R(jv)}),uv=S(Wt,["color","scale"]),vv=S(Wt,{color:R(Vu),scale:R(jv)}),wv=S(Wt,["color","width"]),xv=S(Wt,{color:R(Vu),width:R(ys)}),Xu=S(Wt,{LinearRing:R(cv)}),yv=S(Wt,{LineString:R(cv),Point:R(cv),Polygon:R(fv)}),$u=S(Wt,"name open visibility address phoneNumber description styleUrl Style".split(" ")),
av=S(Wt,{MultiGeometry:R(function(a,c,d){a={node:a};var e=c.Z(),f,g;"MultiPoint"==e?(f=c.ee(),g=zv):"MultiLineString"==e?(f=c.ed(),g=Av):"MultiPolygon"==e&&(f=c.Md(),g=Bv);Jp(a,yv,g,f,d)}),LineString:R(cv),LinearRing:R(cv),Point:R(cv),Polygon:R(fv),Style:R(function(a,c,d){a={node:a};var e={},f=c.g,g=c.c,h=c.i;c=c.a;h&&(e.IconStyle=h);c&&(e.LabelStyle=c);g&&(e.LineStyle=g);f&&(e.PolyStyle=f);c=Cv[d[d.length-1].node.namespaceURI];e=Hp(e,c);Jp(a,Dv,Gp,e,d,c)}),address:R(xs),description:R(xs),name:R(xs),
open:R(ws),phoneNumber:R(xs),styleUrl:R(xs),visibility:R(ws)}),dv=S(Wt,{coordinates:R(function(a,c,d){d=d[d.length-1];var e=d.layout;d=d.stride;var f;"XY"==e||"XYM"==e?f=2:("XYZ"==e||"XYZM"==e)&&(f=3);var g,h=c.length,k="";if(0<h){k+=c[0];for(e=1;e<f;++e)k+=","+c[e];for(g=d;g<h;g+=d)for(k+=" "+c[g],e=1;e<f;++e)k+=","+c[g+e]}xs(a,k)})}),gv=S(Wt,{outerBoundaryIs:R(Wu),innerBoundaryIs:R(Wu)}),Ev=S(Wt,{color:R(Vu)}),Cv=S(Wt,["IconStyle","LabelStyle","LineStyle","PolyStyle"]),Dv=S(Wt,{IconStyle:R(function(a,
c,d){a={node:a};var e={},f=c.rb(),g=c.Kd(),h={href:c.b.i};if(f){h.w=f[0];h.h=f[1];var k=c.Gb(),m=c.wa();m&&g&&0!==m[0]&&m[1]!==f[1]&&(h.x=m[0],h.y=g[1]-(m[1]+f[1]));k&&0!==k[0]&&k[1]!==f[1]&&(e.hotSpot={x:k[0],Hf:"pixels",y:f[1]-k[1],If:"pixels"})}e.Icon=h;f=c.v;1!==f&&(e.scale=f);c=c.D;0!==c&&(e.heading=c);c=rv[d[d.length-1].node.namespaceURI];e=Hp(e,c);Jp(a,tv,Gp,e,d,c)}),LabelStyle:R(function(a,c,d){a={node:a};var e={},f=c.b;f&&(e.color=f.b);(c=c.a)&&1!==c&&(e.scale=c);c=uv[d[d.length-1].node.namespaceURI];
e=Hp(e,c);Jp(a,vv,Gp,e,d,c)}),LineStyle:R(function(a,c,d){a={node:a};var e=wv[d[d.length-1].node.namespaceURI];c=Hp({color:c.b,width:c.a},e);Jp(a,xv,Gp,c,d,e)}),PolyStyle:R(function(a,c,d){Jp({node:a},Ev,Fv,[c.b],d)})});function sv(a,c,d){return dp(Vt[0],"gx:"+d)}function mv(a,c){return dp(c[c.length-1].node.namespaceURI,"Placemark")}function bv(a,c){if(a)return dp(c[c.length-1].node.namespaceURI,ov[a.Z()])}
var Fv=Ep("color"),ev=Ep("coordinates"),hv=Ep("innerBoundaryIs"),zv=Ep("Point"),Av=Ep("LineString"),Yu=Ep("LinearRing"),Bv=Ep("Polygon"),iv=Ep("outerBoundaryIs");
Tt.prototype.a=function(a,c){c=Wr(this,c);var d=dp(Wt[4],"kml");xp(d,"http://www.w3.org/2000/xmlns/","xmlns:gx",Vt[0]);xp(d,"http://www.w3.org/2000/xmlns/","xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance");xp(d,"http://www.w3.org/2001/XMLSchema-instance","xsi:schemaLocation","http://www.opengis.net/kml/2.2 https://developers.google.com/kml/schema/kml22gx.xsd");var e={node:d},f={};1<a.length?f.Document=a:1==a.length&&(f.Placemark=a[0]);var g=kv[d.namespaceURI],f=Hp(f,g);Jp(e,nv,Gp,f,[c],g);
return d};function Gv(){this.defaultDataProjection=null;this.defaultDataProjection=Ee("EPSG:4326")}w(Gv,ls);function Hv(a,c){c[c.length-1].sd[a.getAttribute("k")]=a.getAttribute("v")}
var Iv=[null],Jv=S(Iv,{nd:function(a,c){c[c.length-1].Cc.push(a.getAttribute("ref"))},tag:Hv}),Lv=S(Iv,{node:function(a,c){var d=c[0],e=c[c.length-1],f=a.getAttribute("id"),g=[parseFloat(a.getAttribute("lon")),parseFloat(a.getAttribute("lat"))];e.rg[f]=g;var h=T({sd:{}},Kv,a,c);Qb(h.sd)||(g=new C(g),Xr(g,!1,d),d=new P(g),d.Sb(f),d.K(h.sd),e.features.push(d))},way:function(a,c){for(var d=c[0],e=a.getAttribute("id"),f=T({Cc:[],sd:{}},Jv,a,c),g=c[c.length-1],h=[],k=0,m=f.Cc.length;k<m;k++)kb(h,g.rg[f.Cc[k]]);
f.Cc[0]==f.Cc[f.Cc.length-1]?(k=new D(null),Jf(k,"XY",h,[h.length])):(k=new I(null),jn(k,"XY",h));Xr(k,!1,d);d=new P(k);d.Sb(e);d.K(f.sd);g.features.push(d)}}),Kv=S(Iv,{tag:Hv});Gv.prototype.Rb=function(a,c){var d=Vr(this,a,c);return"osm"==a.localName&&(d=T({rg:{},features:[]},Lv,a,[d]),d.features)?d.features:[]};function Mv(a){return a.getAttributeNS("http://www.w3.org/1999/xlink","href")};function Nv(){}Nv.prototype.c=function(a){return lp(a)?this.a(a):op(a)?this.b(a):ia(a)?(a=yp(a),this.a(a)):null};function Ov(){}w(Ov,Nv);Ov.prototype.a=function(a){for(a=a.firstChild;a;a=a.nextSibling)if(1==a.nodeType)return this.b(a);return null};Ov.prototype.b=function(a){return(a=T({},Pv,a,[]))?a:null};
var Qv=[null,"http://www.opengis.net/ows/1.1"],Pv=S(Qv,{ServiceIdentification:Q(function(a,c){return T({},Rv,a,c)}),ServiceProvider:Q(function(a,c){return T({},Sv,a,c)}),OperationsMetadata:Q(function(a,c){return T({},Tv,a,c)})}),Uv=S(Qv,{DeliveryPoint:Q(W),City:Q(W),AdministrativeArea:Q(W),PostalCode:Q(W),Country:Q(W),ElectronicMailAddress:Q(W)}),Vv=S(Qv,{Value:Cp(function(a){return W(a)})}),Wv=S(Qv,{AllowedValues:Q(function(a,c){return T({},Vv,a,c)})}),Yv=S(Qv,{Phone:Q(function(a,c){return T({},
Xv,a,c)}),Address:Q(function(a,c){return T({},Uv,a,c)})}),$v=S(Qv,{HTTP:Q(function(a,c){return T({},Zv,a,c)})}),Zv=S(Qv,{Get:Cp(function(a,c){var d=Mv(a);return d?T({href:d},aw,a,c):void 0}),Post:void 0}),bw=S(Qv,{DCP:Q(function(a,c){return T({},$v,a,c)})}),Tv=S(Qv,{Operation:function(a,c){var d=a.getAttribute("name"),e=T({},bw,a,c);e&&(c[c.length-1][d]=e)}}),Xv=S(Qv,{Voice:Q(W),Facsimile:Q(W)}),aw=S(Qv,{Constraint:Cp(function(a,c){var d=a.getAttribute("name");return d?T({name:d},Wv,a,c):void 0})}),
cw=S(Qv,{IndividualName:Q(W),PositionName:Q(W),ContactInfo:Q(function(a,c){return T({},Yv,a,c)})}),Rv=S(Qv,{Title:Q(W),ServiceTypeVersion:Q(W),ServiceType:Q(W)}),Sv=S(Qv,{ProviderName:Q(W),ProviderSite:Q(Mv),ServiceContact:Q(function(a,c){return T({},cw,a,c)})});function dw(a,c,d,e){var f;void 0!==e?f=e:f=[];e=0;var g,h;for(g=0;g<c;)for(h=a[g++],f[e++]=a[g++],f[e++]=h,h=2;h<d;++h)f[e++]=a[g++];f.length=e};function ew(a){a=a?a:{};this.defaultDataProjection=null;this.defaultDataProjection=Ee("EPSG:4326");this.b=a.factor?a.factor:1E5;this.a=a.geometryLayout?a.geometryLayout:"XY"}w(ew,tt);function fw(a,c,d){var e,f=Array(c);for(e=0;e<c;++e)f[e]=0;var g,h;g=0;for(h=a.length;g<h;)for(e=0;e<c;++e,++g){var k=a[g],m=k-f[e];f[e]=k;a[g]=m}return gw(a,d?d:1E5)}
function hw(a,c,d){var e,f=Array(c);for(e=0;e<c;++e)f[e]=0;a=iw(a,d?d:1E5);var g;d=0;for(g=a.length;d<g;)for(e=0;e<c;++e,++d)f[e]+=a[d],a[d]=f[e];return a}function gw(a,c){var d=c?c:1E5,e,f;e=0;for(f=a.length;e<f;++e)a[e]=Math.round(a[e]*d);d=0;for(e=a.length;d<e;++d)f=a[d],a[d]=0>f?~(f<<1):f<<1;d="";e=0;for(f=a.length;e<f;++e){for(var g=a[e],h=void 0,k="";32<=g;)h=(32|g&31)+63,k+=String.fromCharCode(h),g>>=5;h=g+63;k+=String.fromCharCode(h);d+=k}return d}
function iw(a,c){var d=c?c:1E5,e=[],f=0,g=0,h,k;h=0;for(k=a.length;h<k;++h){var m=a.charCodeAt(h)-63,f=f|(m&31)<<g;32>m?(e.push(f),g=f=0):g+=5}f=0;for(g=e.length;f<g;++f)h=e[f],e[f]=h&1?~(h>>1):h>>1;f=0;for(g=e.length;f<g;++f)e[f]/=d;return e}l=ew.prototype;l.od=function(a,c){var d=this.qd(a,c);return new P(d)};l.xf=function(a,c){return[this.od(a,c)]};l.qd=function(a,c){var d=df(this.a),e=hw(a,d,this.b);dw(e,e.length,d,e);d=rf(e,0,e.length,d);return Xr(new I(d,this.a),!1,Wr(this,c))};
l.Ae=function(a,c){var d=a.Y();return d?this.ud(d,c):""};l.Gh=function(a,c){return this.Ae(a[0],c)};l.ud=function(a,c){a=Xr(a,!0,Wr(this,c));var d=a.o,e=a.I;dw(d,d.length,e,d);return fw(d,e,this.b)};function jw(a){a=a?a:{};this.defaultDataProjection=null;this.defaultDataProjection=Ee(a.defaultDataProjection?a.defaultDataProjection:"EPSG:4326")}w(jw,Yr);function kw(a,c){var d=[],e,f,g,h;g=0;for(h=a.length;g<h;++g)e=a[g],0<g&&d.pop(),0<=e?f=c[e]:f=c[~e].slice().reverse(),d.push.apply(d,f);e=0;for(f=d.length;e<f;++e)d[e]=d[e].slice();return d}function lw(a,c,d,e,f){a=a.geometries;var g=[],h,k;h=0;for(k=a.length;h<k;++h)g[h]=mw(a[h],c,d,e,f);return g}
function mw(a,c,d,e,f){var g=a.type,h=nw[g];c="Point"===g||"MultiPoint"===g?h(a,d,e):h(a,c);d=new P;d.Ca(Xr(c,!1,f));a.id&&d.Sb(a.id);a.properties&&d.K(a.properties);return d}
jw.prototype.wf=function(a,c){if("Topology"==a.type){var d,e=null,f=null;a.transform&&(d=a.transform,e=d.scale,f=d.translate);var g=a.arcs;if(d){d=e;var h=f,k,m;k=0;for(m=g.length;k<m;++k)for(var n=g[k],p=d,q=h,r=0,t=0,y=void 0,A=void 0,F=void 0,A=0,F=n.length;A<F;++A)y=n[A],r+=y[0],t+=y[1],y[0]=r,y[1]=t,ow(y,p,q)}d=[];h=Lb(a.objects);k=0;for(m=h.length;k<m;++k)"GeometryCollection"===h[k].type?(n=h[k],d.push.apply(d,lw(n,g,e,f,c))):(n=h[k],d.push(mw(n,g,e,f,c)));return d}return[]};
function ow(a,c,d){a[0]=a[0]*c[0]+d[0];a[1]=a[1]*c[1]+d[1]}jw.prototype.Pa=function(){return this.defaultDataProjection};
var nw={Point:function(a,c,d){a=a.coordinates;c&&d&&ow(a,c,d);return new C(a)},LineString:function(a,c){var d=kw(a.arcs,c);return new I(d)},Polygon:function(a,c){var d=[],e,f;e=0;for(f=a.arcs.length;e<f;++e)d[e]=kw(a.arcs[e],c);return new D(d)},MultiPoint:function(a,c,d){a=a.coordinates;var e,f;if(c&&d)for(e=0,f=a.length;e<f;++e)ow(a[e],c,d);return new mn(a)},MultiLineString:function(a,c){var d=[],e,f;e=0;for(f=a.arcs.length;e<f;++e)d[e]=kw(a.arcs[e],c);return new N(d)},MultiPolygon:function(a,c){var d=
[],e,f,g,h,k,m;k=0;for(m=a.arcs.length;k<m;++k){e=a.arcs[k];f=[];g=0;for(h=e.length;g<h;++g)f[g]=kw(e[g],c);d[k]=f}return new O(d)}};function pw(a){a=a?a:{};this.g=a.featureType;this.c=a.featureNS;this.b=a.gmlFormat?a.gmlFormat:new Bs;this.f=a.schemaLocation?a.schemaLocation:"http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.1.0/wfs.xsd";this.defaultDataProjection=null}w(pw,ls);pw.prototype.Rb=function(a,c){var d={featureType:this.g,featureNS:this.c};Xb(d,Vr(this,a,c?c:{}));d=[d];this.b.b["http://www.opengis.net/gml"].featureMember=Ap(os.prototype.pd);(d=T([],this.b.b,a,d,this.b))||(d=[]);return d};
pw.prototype.j=function(a){if(lp(a))return qw(a);if(op(a))return T({},rw,a,[]);if(ia(a))return a=yp(a),qw(a)};pw.prototype.i=function(a){if(lp(a))return sw(this,a);if(op(a))return tw(this,a);if(ia(a))return a=yp(a),sw(this,a)};function sw(a,c){for(var d=c.firstChild;d;d=d.nextSibling)if(1==d.nodeType)return tw(a,d)}var uw={"http://www.opengis.net/gml":{boundedBy:Q(os.prototype.se,"bounds")}};
function tw(a,c){var d={},e=vs(c.getAttribute("numberOfFeatures"));d.numberOfFeatures=e;return T(d,uw,c,[],a.b)}
var vw={"http://www.opengis.net/wfs":{totalInserted:Q(us),totalUpdated:Q(us),totalDeleted:Q(us)}},ww={"http://www.opengis.net/ogc":{FeatureId:Ap(function(a){return a.getAttribute("fid")})}},xw={"http://www.opengis.net/wfs":{Feature:function(a,c){Ip(ww,a,c)}}},rw={"http://www.opengis.net/wfs":{TransactionSummary:Q(function(a,c){return T({},vw,a,c)},"transactionSummary"),InsertResults:Q(function(a,c){return T([],xw,a,c)},"insertIds")}};
function qw(a){for(a=a.firstChild;a;a=a.nextSibling)if(1==a.nodeType)return T({},rw,a,[])}var yw={"http://www.opengis.net/wfs":{PropertyName:R(xs)}};function zw(a,c){var d=dp("http://www.opengis.net/ogc","Filter"),e=dp("http://www.opengis.net/ogc","FeatureId");d.appendChild(e);e.setAttribute("fid",c);a.appendChild(d)}
var Aw={"http://www.opengis.net/wfs":{Insert:R(function(a,c,d){var e=d[d.length-1],e=dp(e.featureNS,e.featureType);a.appendChild(e);Bs.prototype.Fh(e,c,d)}),Update:R(function(a,c,d){var e=d[d.length-1],f=e.featureType,g=e.featurePrefix,g=g?g:"feature",h=e.featureNS;a.setAttribute("typeName",g+":"+f);xp(a,"http://www.w3.org/2000/xmlns/","xmlns:"+g,h);if(f=c.Fa()){for(var g=c.R(),h=[],k=0,m=g.length;k<m;k++){var n=c.get(g[k]);void 0!==n&&h.push({name:g[k],value:n})}Jp({node:a,srsName:e.srsName},Aw,
Ep("Property"),h,d);zw(a,f)}}),Delete:R(function(a,c,d){var e=d[d.length-1];d=e.featureType;var f=e.featurePrefix,f=f?f:"feature",e=e.featureNS;a.setAttribute("typeName",f+":"+d);xp(a,"http://www.w3.org/2000/xmlns/","xmlns:"+f,e);(c=c.Fa())&&zw(a,c)}),Property:R(function(a,c,d){var e=dp("http://www.opengis.net/wfs","Name");a.appendChild(e);xs(e,c.name);void 0!==c.value&&null!==c.value&&(e=dp("http://www.opengis.net/wfs","Value"),a.appendChild(e),c.value instanceof af?Bs.prototype.Ce(e,c.value,d):
xs(e,c.value))}),Native:R(function(a,c){c.uo&&a.setAttribute("vendorId",c.uo);void 0!==c.Wn&&a.setAttribute("safeToIgnore",c.Wn);void 0!==c.value&&xs(a,c.value)})}},Bw={"http://www.opengis.net/wfs":{Query:R(function(a,c,d){var e=d[d.length-1],f=e.featurePrefix,g=e.featureNS,h=e.propertyNames,k=e.srsName;a.setAttribute("typeName",(f?f+":":"")+c);k&&a.setAttribute("srsName",k);g&&xp(a,"http://www.w3.org/2000/xmlns/","xmlns:"+f,g);c=Ub(e);c.node=a;Jp(c,yw,Ep("PropertyName"),h,d);if(e=e.bbox)h=dp("http://www.opengis.net/ogc",
"Filter"),c=d[d.length-1].geometryName,f=dp("http://www.opengis.net/ogc","BBOX"),h.appendChild(f),g=dp("http://www.opengis.net/ogc","PropertyName"),xs(g,c),f.appendChild(g),Bs.prototype.Ce(f,e,d),a.appendChild(h)})}};
pw.prototype.l=function(a){var c=dp("http://www.opengis.net/wfs","GetFeature");c.setAttribute("service","WFS");c.setAttribute("version","1.1.0");a&&(a.handle&&c.setAttribute("handle",a.handle),a.outputFormat&&c.setAttribute("outputFormat",a.outputFormat),void 0!==a.maxFeatures&&c.setAttribute("maxFeatures",a.maxFeatures),a.resultType&&c.setAttribute("resultType",a.resultType),void 0!==a.startIndex&&c.setAttribute("startIndex",a.startIndex),void 0!==a.count&&c.setAttribute("count",a.count));xp(c,"http://www.w3.org/2001/XMLSchema-instance",
"xsi:schemaLocation",this.f);var d=a.featureTypes;a=[{node:c,srsName:a.srsName,featureNS:a.featureNS?a.featureNS:this.c,featurePrefix:a.featurePrefix,geometryName:a.geometryName,bbox:a.bbox,propertyNames:a.propertyNames?a.propertyNames:[]}];var e=Ub(a[a.length-1]);e.node=c;Jp(e,Bw,Ep("Query"),d,a);return c};
pw.prototype.A=function(a,c,d,e){var f=[],g=dp("http://www.opengis.net/wfs","Transaction");g.setAttribute("service","WFS");g.setAttribute("version","1.1.0");var h,k;e&&(h=e.gmlOptions?e.gmlOptions:{},e.handle&&g.setAttribute("handle",e.handle));xp(g,"http://www.w3.org/2001/XMLSchema-instance","xsi:schemaLocation",this.f);a&&(k={node:g,featureNS:e.featureNS,featureType:e.featureType,featurePrefix:e.featurePrefix},Xb(k,h),Jp(k,Aw,Ep("Insert"),a,f));c&&(k={node:g,featureNS:e.featureNS,featureType:e.featureType,
featurePrefix:e.featurePrefix},Xb(k,h),Jp(k,Aw,Ep("Update"),c,f));d&&Jp({node:g,featureNS:e.featureNS,featureType:e.featureType,featurePrefix:e.featurePrefix},Aw,Ep("Delete"),d,f);e.nativeElements&&Jp({node:g,featureNS:e.featureNS,featureType:e.featureType,featurePrefix:e.featurePrefix},Aw,Ep("Native"),e.nativeElements,f);return g};pw.prototype.Af=function(a){for(a=a.firstChild;a;a=a.nextSibling)if(1==a.nodeType)return this.ve(a);return null};
pw.prototype.ve=function(a){if(a.firstElementChild&&a.firstElementChild.firstElementChild)for(a=a.firstElementChild.firstElementChild,a=a.firstElementChild;a;a=a.nextElementSibling)if(0!==a.childNodes.length&&(1!==a.childNodes.length||3!==a.firstChild.nodeType)){var c=[{}];this.b.se(a,c);return Ee(c.pop().srsName)}return null};function Cw(a){a=a?a:{};this.defaultDataProjection=null;this.b=void 0!==a.splitCollection?a.splitCollection:!1}w(Cw,tt);function Dw(a){a=a.X();return 0===a.length?"":a[0]+" "+a[1]}function Ew(a){a=a.X();for(var c=[],d=0,e=a.length;d<e;++d)c.push(a[d][0]+" "+a[d][1]);return c.join(",")}function Fw(a){var c=[];a=a.Ld();for(var d=0,e=a.length;d<e;++d)c.push("("+Ew(a[d])+")");return c.join(",")}function Gw(a){var c=a.Z();a=(0,Hw[c])(a);c=c.toUpperCase();return 0===a.length?c+" EMPTY":c+"("+a+")"}
var Hw={Point:Dw,LineString:Ew,Polygon:Fw,MultiPoint:function(a){var c=[];a=a.ee();for(var d=0,e=a.length;d<e;++d)c.push("("+Dw(a[d])+")");return c.join(",")},MultiLineString:function(a){var c=[];a=a.ed();for(var d=0,e=a.length;d<e;++d)c.push("("+Ew(a[d])+")");return c.join(",")},MultiPolygon:function(a){var c=[];a=a.Md();for(var d=0,e=a.length;d<e;++d)c.push("("+Fw(a[d])+")");return c.join(",")},GeometryCollection:function(a){var c=[];a=a.$f();for(var d=0,e=a.length;d<e;++d)c.push(Gw(a[d]));return c.join(",")}};
l=Cw.prototype;l.od=function(a,c){var d=this.qd(a,c);if(d){var e=new P;e.Ca(d);return e}return null};l.xf=function(a,c){var d=[],e=this.qd(a,c);this.b&&"GeometryCollection"==e.Z()?d=e.f:d=[e];for(var f=[],g=0,h=d.length;g<h;++g)e=new P,e.Ca(d[g]),f.push(e);return f};l.qd=function(a,c){var d;d=new Iw(new Jw(a));d.b=Kw(d.a);return(d=Lw(d))?Xr(d,!1,c):null};l.Ae=function(a,c){var d=a.Y();return d?this.ud(d,c):""};
l.Gh=function(a,c){if(1==a.length)return this.Ae(a[0],c);for(var d=[],e=0,f=a.length;e<f;++e)d.push(a[e].Y());d=new bn(d);return this.ud(d,c)};l.ud=function(a,c){return Gw(Xr(a,!0,c))};function Jw(a){this.a=a;this.b=-1}function Mw(a,c){return"0"<=a&&"9">=a||"."==a&&!(void 0!==c&&c)}
function Kw(a){var c=a.a.charAt(++a.b),d={position:a.b,value:c};if("("==c)d.type=2;else if(","==c)d.type=5;else if(")"==c)d.type=3;else if(Mw(c)||"-"==c){d.type=4;var e,c=a.b,f=!1,g=!1;do{if("."==e)f=!0;else if("e"==e||"E"==e)g=!0;e=a.a.charAt(++a.b)}while(Mw(e,f)||!g&&("e"==e||"E"==e)||g&&("-"==e||"+"==e));a=parseFloat(a.a.substring(c,a.b--));d.value=a}else if("a"<=c&&"z">=c||"A"<=c&&"Z">=c){d.type=1;c=a.b;do e=a.a.charAt(++a.b);while("a"<=e&&"z">=e||"A"<=e&&"Z">=e);a=a.a.substring(c,a.b--).toUpperCase();
d.value=a}else{if(" "==c||"\t"==c||"\r"==c||"\n"==c)return Kw(a);if(""===c)d.type=6;else throw Error("Unexpected character: "+c);}return d}function Iw(a){this.a=a}l=Iw.prototype;l.match=function(a){if(a=this.b.type==a)this.b=Kw(this.a);return a};
function Lw(a){var c=a.b;if(a.match(1)){var d=c.value;if("GEOMETRYCOLLECTION"==d){a:{if(a.match(2)){c=[];do c.push(Lw(a));while(a.match(5));if(a.match(3)){a=c;break a}}else if(Nw(a)){a=[];break a}throw Error(Ow(a));}return new bn(a)}var e=Pw[d],c=Qw[d];if(!e||!c)throw Error("Invalid geometry type: "+d);a=e.call(a);return new c(a)}throw Error(Ow(a));}l.sf=function(){if(this.match(2)){var a=Rw(this);if(this.match(3))return a}else if(Nw(this))return null;throw Error(Ow(this));};
l.rf=function(){if(this.match(2)){var a=Sw(this);if(this.match(3))return a}else if(Nw(this))return[];throw Error(Ow(this));};l.tf=function(){if(this.match(2)){var a=Tw(this);if(this.match(3))return a}else if(Nw(this))return[];throw Error(Ow(this));};l.jn=function(){if(this.match(2)){var a;if(2==this.b.type)for(a=[this.sf()];this.match(5);)a.push(this.sf());else a=Sw(this);if(this.match(3))return a}else if(Nw(this))return[];throw Error(Ow(this));};
l.hn=function(){if(this.match(2)){var a=Tw(this);if(this.match(3))return a}else if(Nw(this))return[];throw Error(Ow(this));};l.kn=function(){if(this.match(2)){for(var a=[this.tf()];this.match(5);)a.push(this.tf());if(this.match(3))return a}else if(Nw(this))return[];throw Error(Ow(this));};function Rw(a){for(var c=[],d=0;2>d;++d){var e=a.b;if(a.match(4))c.push(e.value);else break}if(2==c.length)return c;throw Error(Ow(a));}function Sw(a){for(var c=[Rw(a)];a.match(5);)c.push(Rw(a));return c}
function Tw(a){for(var c=[a.rf()];a.match(5);)c.push(a.rf());return c}function Nw(a){var c=1==a.b.type&&"EMPTY"==a.b.value;c&&(a.b=Kw(a.a));return c}function Ow(a){return"Unexpected `"+a.b.value+"` at position "+a.b.position+" in `"+a.a.a+"`"}var Qw={POINT:C,LINESTRING:I,POLYGON:D,MULTIPOINT:mn,MULTILINESTRING:N,MULTIPOLYGON:O},Pw={POINT:Iw.prototype.sf,LINESTRING:Iw.prototype.rf,POLYGON:Iw.prototype.tf,MULTIPOINT:Iw.prototype.jn,MULTILINESTRING:Iw.prototype.hn,MULTIPOLYGON:Iw.prototype.kn};function Uw(){this.version=void 0}w(Uw,Nv);Uw.prototype.a=function(a){for(a=a.firstChild;a;a=a.nextSibling)if(1==a.nodeType)return this.b(a);return null};Uw.prototype.b=function(a){this.version=a.getAttribute("version").trim();return(a=T({version:this.version},Vw,a,[]))?a:null};function Ww(a,c){return T({},Xw,a,c)}function Yw(a,c){return T({},Zw,a,c)}function $w(a,c){var d=Ww(a,c);if(d){var e=[vs(a.getAttribute("width")),vs(a.getAttribute("height"))];d.size=e;return d}}
function ax(a,c){return T([],bx,a,c)}
var cx=[null,"http://www.opengis.net/wms"],Vw=S(cx,{Service:Q(function(a,c){return T({},dx,a,c)}),Capability:Q(function(a,c){return T({},ex,a,c)})}),ex=S(cx,{Request:Q(function(a,c){return T({},fx,a,c)}),Exception:Q(function(a,c){return T([],gx,a,c)}),Layer:Q(function(a,c){return T({},hx,a,c)})}),dx=S(cx,{Name:Q(W),Title:Q(W),Abstract:Q(W),KeywordList:Q(ax),OnlineResource:Q(Mv),ContactInformation:Q(function(a,c){return T({},ix,a,c)}),Fees:Q(W),AccessConstraints:Q(W),LayerLimit:Q(us),MaxWidth:Q(us),
MaxHeight:Q(us)}),ix=S(cx,{ContactPersonPrimary:Q(function(a,c){return T({},jx,a,c)}),ContactPosition:Q(W),ContactAddress:Q(function(a,c){return T({},kx,a,c)}),ContactVoiceTelephone:Q(W),ContactFacsimileTelephone:Q(W),ContactElectronicMailAddress:Q(W)}),jx=S(cx,{ContactPerson:Q(W),ContactOrganization:Q(W)}),kx=S(cx,{AddressType:Q(W),Address:Q(W),City:Q(W),StateOrProvince:Q(W),PostCode:Q(W),Country:Q(W)}),gx=S(cx,{Format:Ap(W)}),hx=S(cx,{Name:Q(W),Title:Q(W),Abstract:Q(W),KeywordList:Q(ax),CRS:Cp(W),
EX_GeographicBoundingBox:Q(function(a,c){var d=T({},lx,a,c);if(d){var e=d.westBoundLongitude,f=d.southBoundLatitude,g=d.eastBoundLongitude,d=d.northBoundLatitude;return void 0===e||void 0===f||void 0===g||void 0===d?void 0:[e,f,g,d]}}),BoundingBox:Cp(function(a){var c=[ts(a.getAttribute("minx")),ts(a.getAttribute("miny")),ts(a.getAttribute("maxx")),ts(a.getAttribute("maxy"))],d=[ts(a.getAttribute("resx")),ts(a.getAttribute("resy"))];return{crs:a.getAttribute("CRS"),extent:c,res:d}}),Dimension:Cp(function(a){return{name:a.getAttribute("name"),
units:a.getAttribute("units"),unitSymbol:a.getAttribute("unitSymbol"),"default":a.getAttribute("default"),multipleValues:qs(a.getAttribute("multipleValues")),nearestValue:qs(a.getAttribute("nearestValue")),current:qs(a.getAttribute("current")),values:W(a)}}),Attribution:Q(function(a,c){return T({},mx,a,c)}),AuthorityURL:Cp(function(a,c){var d=Ww(a,c);if(d)return d.name=a.getAttribute("name"),d}),Identifier:Cp(W),MetadataURL:Cp(function(a,c){var d=Ww(a,c);if(d)return d.type=a.getAttribute("type"),
d}),DataURL:Cp(Ww),FeatureListURL:Cp(Ww),Style:Cp(function(a,c){return T({},nx,a,c)}),MinScaleDenominator:Q(ss),MaxScaleDenominator:Q(ss),Layer:Cp(function(a,c){var d=c[c.length-1],e=T({},hx,a,c);if(e){var f=qs(a.getAttribute("queryable"));void 0===f&&(f=d.queryable);e.queryable=void 0!==f?f:!1;f=vs(a.getAttribute("cascaded"));void 0===f&&(f=d.cascaded);e.cascaded=f;f=qs(a.getAttribute("opaque"));void 0===f&&(f=d.opaque);e.opaque=void 0!==f?f:!1;f=qs(a.getAttribute("noSubsets"));void 0===f&&(f=d.noSubsets);
e.noSubsets=void 0!==f?f:!1;(f=ts(a.getAttribute("fixedWidth")))||(f=d.fixedWidth);e.fixedWidth=f;(f=ts(a.getAttribute("fixedHeight")))||(f=d.fixedHeight);e.fixedHeight=f;["Style","CRS","AuthorityURL"].forEach(function(a){if(a in d){var c=Tb(e,a),c=c.concat(d[a]);e[a]=c}});"EX_GeographicBoundingBox BoundingBox Dimension Attribution MinScaleDenominator MaxScaleDenominator".split(" ").forEach(function(a){a in e||(e[a]=d[a])});return e}})}),mx=S(cx,{Title:Q(W),OnlineResource:Q(Mv),LogoURL:Q($w)}),lx=
S(cx,{westBoundLongitude:Q(ss),eastBoundLongitude:Q(ss),southBoundLatitude:Q(ss),northBoundLatitude:Q(ss)}),fx=S(cx,{GetCapabilities:Q(Yw),GetMap:Q(Yw),GetFeatureInfo:Q(Yw)}),Zw=S(cx,{Format:Cp(W),DCPType:Cp(function(a,c){return T({},ox,a,c)})}),ox=S(cx,{HTTP:Q(function(a,c){return T({},px,a,c)})}),px=S(cx,{Get:Q(Ww),Post:Q(Ww)}),nx=S(cx,{Name:Q(W),Title:Q(W),Abstract:Q(W),LegendURL:Cp($w),StyleSheetURL:Q(Ww),StyleURL:Q(Ww)}),Xw=S(cx,{Format:Q(W),OnlineResource:Q(Mv)}),bx=S(cx,{Keyword:Ap(W)});function qx(){this.c="http://mapserver.gis.umn.edu/mapserver";this.b=new As;this.defaultDataProjection=null}w(qx,ls);
qx.prototype.Rb=function(a,c){var d={featureType:this.featureType,featureNS:this.featureNS};c&&Xb(d,Vr(this,a,c));var e=[d];a.namespaceURI=this.c;var f=ip(a),d=[];if(0!==a.childNodes.length){if("msGMLOutput"==f)for(var g=0,h=a.childNodes.length;g<h;g++){var k=a.childNodes[g];if(1===k.nodeType){var m=e[0],n=k.localName.replace("_layer","")+"_feature";m.featureType=n;m.featureNS=this.c;var p={};p[n]=Ap(this.b.vf,this.b);m=S([m.featureNS,null],p);k.namespaceURI=this.c;(k=T([],m,k,e,this.b))&&kb(d,k)}}"FeatureCollection"==
f&&(e=T([],this.b.b,a,[{}],this.b))&&(d=e)}return d};function rx(){this.f=new Ov}w(rx,Nv);rx.prototype.a=function(a){for(a=a.firstChild;a;a=a.nextSibling)if(1==a.nodeType)return this.b(a);return null};rx.prototype.b=function(a){this.version=a.getAttribute("version").trim();var c=this.f.b(a);if(!c)return null;c.version=this.version;return(c=T(c,sx,a,[]))?c:null};function tx(a){var c=W(a).split(" ");if(c&&2==c.length)return a=+c[0],c=+c[1],isNaN(a)||isNaN(c)?void 0:[a,c]}
var ux=[null,"http://www.opengis.net/wmts/1.0"],vx=[null,"http://www.opengis.net/ows/1.1"],sx=S(ux,{Contents:Q(function(a,c){return T({},wx,a,c)})}),wx=S(ux,{Layer:Cp(function(a,c){return T({},xx,a,c)}),TileMatrixSet:Cp(function(a,c){return T({},yx,a,c)})}),xx=S(ux,{Style:Cp(function(a,c){var d=T({},zx,a,c);if(d){var e="true"===a.getAttribute("isDefault");d.isDefault=e;return d}}),Format:Cp(W),TileMatrixSetLink:Cp(function(a,c){return T({},Ax,a,c)}),Dimension:Cp(function(a,c){return T({},Bx,a,c)}),
ResourceURL:Cp(function(a){var c=a.getAttribute("format"),d=a.getAttribute("template");a=a.getAttribute("resourceType");var e={};c&&(e.format=c);d&&(e.template=d);a&&(e.resourceType=a);return e})},S(vx,{Title:Q(W),Abstract:Q(W),WGS84BoundingBox:Q(function(a,c){var d=T([],Cx,a,c);return 2!=d.length?void 0:Nd(d)}),Identifier:Q(W)})),zx=S(ux,{LegendURL:Cp(function(a){var c={};c.format=a.getAttribute("format");c.href=Mv(a);return c})},S(vx,{Title:Q(W),Identifier:Q(W)})),Ax=S(ux,{TileMatrixSet:Q(W)}),
Bx=S(ux,{Default:Q(W),Value:Cp(W)},S(vx,{Identifier:Q(W)})),Cx=S(vx,{LowerCorner:Ap(tx),UpperCorner:Ap(tx)}),yx=S(ux,{WellKnownScaleSet:Q(W),TileMatrix:Cp(function(a,c){return T({},Dx,a,c)})},S(vx,{SupportedCRS:Q(W),Identifier:Q(W)})),Dx=S(ux,{TopLeftCorner:Q(tx),ScaleDenominator:Q(ss),TileWidth:Q(us),TileHeight:Q(us),MatrixWidth:Q(us),MatrixHeight:Q(us)},S(vx,{Identifier:Q(W)}));var Ex=new ze(6378137);function Fx(a){id.call(this);a=a||{};this.a=null;this.f=Ye;this.c=void 0;B(this,kd("projection"),this.Mk,!1,this);B(this,kd("tracking"),this.Nk,!1,this);void 0!==a.projection&&this.vg(Ee(a.projection));void 0!==a.trackingOptions&&this.xh(a.trackingOptions);this.ae(void 0!==a.tracking?a.tracking:!1)}w(Fx,id);l=Fx.prototype;l.W=function(){this.ae(!1);Fx.ba.W.call(this)};l.Mk=function(){var a=this.tg();a&&(this.f=Ie(Ee("EPSG:4326"),a),this.a&&this.set("position",this.f(this.a)))};
l.Nk=function(){if(ej){var a=this.ug();a&&void 0===this.c?this.c=ba.navigator.geolocation.watchPosition(sa(this.sn,this),sa(this.tn,this),this.gg()):a||void 0===this.c||(ba.navigator.geolocation.clearWatch(this.c),this.c=void 0)}};
l.sn=function(a){a=a.coords;this.set("accuracy",a.accuracy);this.set("altitude",null===a.altitude?void 0:a.altitude);this.set("altitudeAccuracy",null===a.altitudeAccuracy?void 0:a.altitudeAccuracy);this.set("heading",null===a.heading?void 0:Wa(a.heading));this.a?(this.a[0]=a.longitude,this.a[1]=a.latitude):this.a=[a.longitude,a.latitude];var c=this.f(this.a);this.set("position",c);this.set("speed",null===a.speed?void 0:a.speed);a=Mf(Ex,this.a,a.accuracy);a.Ub(this.f);this.set("accuracyGeometry",a);
this.s()};l.tn=function(a){a.type="error";this.ae(!1);this.u(a)};l.Ki=function(){return this.get("accuracy")};l.Li=function(){return this.get("accuracyGeometry")||null};l.Ni=function(){return this.get("altitude")};l.Oi=function(){return this.get("altitudeAccuracy")};l.Kk=function(){return this.get("heading")};l.Lk=function(){return this.get("position")};l.tg=function(){return this.get("projection")};l.uj=function(){return this.get("speed")};l.ug=function(){return this.get("tracking")};l.gg=function(){return this.get("trackingOptions")};
l.vg=function(a){this.set("projection",a)};l.ae=function(a){this.set("tracking",a)};l.xh=function(a){this.set("trackingOptions",a)};function Gx(a,c,d){for(var e=[],f=a(0),g=a(1),h=c(f),k=c(g),m=[g,f],n=[k,h],p=[1,0],q={},r=1E5,t,y,A,F,z;0<--r&&0<p.length;)A=p.pop(),f=m.pop(),h=n.pop(),g=A.toString(),g in q||(e.push(h[0],h[1]),q[g]=!0),F=p.pop(),g=m.pop(),k=n.pop(),z=(A+F)/2,t=a(z),y=c(t),Ua(y[0],y[1],h[0],h[1],k[0],k[1])<d?(e.push(k[0],k[1]),g=F.toString(),q[g]=!0):(p.push(F,z,z,A),n.push(k,y,y,h),m.push(g,t,t,f));return e}function Hx(a,c,d,e,f){var g=Ee("EPSG:4326");return Gx(function(e){return[a,c+(d-c)*e]},Xe(g,e),f)}
function Ix(a,c,d,e,f){var g=Ee("EPSG:4326");return Gx(function(e){return[c+(d-c)*e,a]},Xe(g,e),f)};function Jx(a){a=a||{};this.g=this.l=null;this.c=this.i=Infinity;this.f=this.j=-Infinity;this.C=this.B=Infinity;this.fa=this.P=-Infinity;this.T=void 0!==a.targetSize?a.targetSize:100;this.ka=void 0!==a.maxLines?a.maxLines:100;this.b=[];this.a=[];this.H=void 0!==a.strokeStyle?a.strokeStyle:Kx;this.A=this.D=void 0;this.v=null;this.setMap(void 0!==a.map?a.map:null)}var Kx=new em({color:"rgba(0,0,0,0.2)"}),Lx=[90,45,30,20,10,5,2,1,.5,.2,.1,.05,.01,.005,.002,.001];
function Mx(a,c,d,e,f,g,h){var k=h;c=Hx(c,d,e,a.g,f);k=void 0!==a.b[k]?a.b[k]:new I(null);jn(k,"XY",c);oe(k.J(),g)&&(a.b[h++]=k);return h}function Nx(a,c,d,e,f){var g=f;c=Ix(c,a.f,a.c,a.g,d);g=void 0!==a.a[g]?a.a[g]:new I(null);jn(g,"XY",c);oe(g.J(),e)&&(a.a[f++]=g);return f}l=Jx.prototype;l.Ok=function(){return this.l};l.hj=function(){return this.b};l.oj=function(){return this.a};
l.kg=function(a){var c=a.vectorContext,d=a.frameState,e=d.extent;a=d.viewState;var f=a.center,g=a.projection,h=a.resolution;a=d.pixelRatio;a=h*h/(4*a*a);if(!this.g||!We(this.g,g)){var k=Ee("EPSG:4326"),m=g.J(),n=g.j,p=$e(n,k,g),q=n[2],r=n[1],t=n[0],y=p[3],A=p[2],F=p[1],p=p[0];this.i=n[3];this.c=q;this.j=r;this.f=t;this.B=y;this.C=A;this.P=F;this.fa=p;this.D=Xe(k,g);this.A=Xe(g,k);this.v=this.A(le(m));this.g=g}k=0;g.a&&(g=g.J(),k=je(g),d=d.focus[0],d<g[0]||d>g[2])&&(k*=Math.ceil((g[0]-d)/k),e=[e[0]+
k,e[1],e[2]+k,e[3]]);d=this.v[0];g=this.v[1];k=-1;n=Math.pow(this.T*h,2);q=[];r=[];h=0;for(m=Lx.length;h<m;++h){t=Lx[h]/2;q[0]=d-t;q[1]=g-t;r[0]=d+t;r[1]=g+t;this.D(q,q);this.D(r,r);t=Math.pow(r[0]-q[0],2)+Math.pow(r[1]-q[1],2);if(t<=n)break;k=Lx[h]}h=k;if(-1==h)this.b.length=this.a.length=0;else{d=this.A(f);f=d[0];d=d[1];g=this.ka;k=[Math.max(e[0],this.fa),Math.max(e[1],this.P),Math.min(e[2],this.C),Math.min(e[3],this.B)];k=$e(k,this.g,"EPSG:4326");n=k[3];r=k[1];f=Math.floor(f/h)*h;q=Sa(f,this.f,
this.c);m=Mx(this,q,r,n,a,e,0);for(k=0;q!=this.f&&k++<g;)q=Math.max(q-h,this.f),m=Mx(this,q,r,n,a,e,m);q=Sa(f,this.f,this.c);for(k=0;q!=this.c&&k++<g;)q=Math.min(q+h,this.c),m=Mx(this,q,r,n,a,e,m);this.b.length=m;d=Math.floor(d/h)*h;f=Sa(d,this.j,this.i);m=Nx(this,f,a,e,0);for(k=0;f!=this.j&&k++<g;)f=Math.max(f-h,this.j),m=Nx(this,f,a,e,m);f=Sa(d,this.j,this.i);for(k=0;f!=this.i&&k++<g;)f=Math.min(f+h,this.i),m=Nx(this,f,a,e,m);this.a.length=m}c.Qa(null,this.H);a=0;for(f=this.b.length;a<f;++a)h=this.b[a],
c.Eb(h,null);a=0;for(f=this.a.length;a<f;++a)h=this.a[a],c.Eb(h,null)};l.setMap=function(a){this.l&&(this.l.L("postcompose",this.kg,this),this.l.render());a&&(a.G("postcompose",this.kg,this),a.render());this.l=a};function Ox(a,c,d,e,f,g,h){kk.call(this,a,c,d,0,e);this.l=f;this.a=new Image;g&&(this.a.crossOrigin=g);this.g={};this.f=null;this.state=0;this.j=h}w(Ox,kk);Ox.prototype.b=function(a){if(void 0!==a){var c=v(a);if(c in this.g)return this.g[c];a=Qb(this.g)?this.a:this.a.cloneNode(!1);return this.g[c]=a}return this.a};Ox.prototype.D=function(){this.state=3;this.f.forEach(Zc);this.f=null;lk(this)};
Ox.prototype.v=function(){void 0===this.resolution&&(this.resolution=ke(this.extent)/this.a.height);this.state=2;this.f.forEach(Zc);this.f=null;lk(this)};Ox.prototype.load=function(){0==this.state&&(this.state=1,lk(this),this.f=[Xc(this.a,"error",this.D,!1,this),Xc(this.a,"load",this.v,!1,this)],this.j(this,this.l))};function Px(a,c,d,e,f){Dh.call(this,a,c);this.i=d;this.a=new Image;e&&(this.a.crossOrigin=e);this.c={};this.g=null;this.j=f}w(Px,Dh);l=Px.prototype;l.W=function(){1==this.state&&Qx(this);Px.ba.W.call(this)};l.Ma=function(a){if(void 0!==a){var c=v(a);if(c in this.c)return this.c[c];a=Qb(this.c)?this.a:this.a.cloneNode(!1);return this.c[c]=a}return this.a};l.qb=function(){return this.i};l.Pk=function(){this.state=3;Qx(this);Eh(this)};
l.Qk=function(){this.state=this.a.naturalWidth&&this.a.naturalHeight?2:4;Qx(this);Eh(this)};l.load=function(){0==this.state&&(this.state=1,Eh(this),this.g=[Xc(this.a,"error",this.Pk,!1,this),Xc(this.a,"load",this.Qk,!1,this)],this.j(this,this.i))};function Qx(a){a.g.forEach(Zc);a.g=null};function Rx(a,c,d){return function(e,f,g){return d(a,c,e,f,g)}}function Sx(){};function Tx(a,c){cd.call(this);this.b=new Dr(this);var d=a;c&&(d=Jg(a));this.b.Ka(d,"dragenter",this.$m);d!=a&&this.b.Ka(d,"dragover",this.an);this.b.Ka(a,"dragover",this.bn);this.b.Ka(a,"drop",this.cn)}w(Tx,cd);l=Tx.prototype;l.$c=!1;l.W=function(){Tx.ba.W.call(this);this.b.sc()};l.$m=function(a){var c=a.b.dataTransfer;(this.$c=!(!c||!(c.types&&(0<=$a(c.types,"Files")||0<=$a(c.types,"public.file-url"))||c.files&&0<c.files.length)))&&a.preventDefault()};
l.an=function(a){this.$c&&(a.preventDefault(),a.b.dataTransfer.dropEffect="none")};l.bn=function(a){if(this.$c){a.preventDefault();a.c();a=a.b.dataTransfer;try{a.effectAllowed="all"}catch(c){}a.dropEffect="copy"}};l.cn=function(a){this.$c&&(a.preventDefault(),a.c(),a=new Ac(a.b),a.type="drop",this.u(a))};/*
 Portions of this code are from MochiKit, received by
 The Closure Authors under the MIT license. All other code is Copyright
 2005-2009 The Closure Authors. All Rights Reserved.
*/
function Ux(a,c){this.g=[];this.B=a;this.A=c||null;this.f=this.b=!1;this.c=void 0;this.D=this.C=this.j=!1;this.i=0;this.a=null;this.l=0}Ux.prototype.cancel=function(a){if(this.b)this.c instanceof Ux&&this.c.cancel();else{if(this.a){var c=this.a;delete this.a;a?c.cancel(a):(c.l--,0>=c.l&&c.cancel())}this.B?this.B.call(this.A,this):this.D=!0;this.b||(a=new Vx,Wx(this),Xx(this,!1,a))}};Ux.prototype.v=function(a,c){this.j=!1;Xx(this,a,c)};function Xx(a,c,d){a.b=!0;a.c=d;a.f=!c;Yx(a)}
function Wx(a){if(a.b){if(!a.D)throw new Zx;a.D=!1}}Ux.prototype.Sc=function(a){Wx(this);Xx(this,!0,a)};function $x(a,c,d,e){a.g.push([c,d,e]);a.b&&Yx(a)}Ux.prototype.then=function(a,c,d){var e,f,g=new Zn(function(a,c){e=a;f=c});$x(this,e,function(a){a instanceof Vx?g.cancel():f(a)});return g.then(a,c,d)};Mn(Ux);function ay(a){return db(a.g,function(a){return ka(a[1])})}
function Yx(a){if(a.i&&a.b&&ay(a)){var c=a.i,d=by[c];d&&(ba.clearTimeout(d.ta),delete by[c]);a.i=0}a.a&&(a.a.l--,delete a.a);for(var c=a.c,e=d=!1;a.g.length&&!a.j;){var f=a.g.shift(),g=f[0],h=f[1],f=f[2];if(g=a.f?h:g)try{var k=g.call(f||a.A,c);ca(k)&&(a.f=a.f&&(k==c||k instanceof Error),a.c=c=k);if(Nn(c)||"function"===typeof ba.Promise&&c instanceof ba.Promise)e=!0,a.j=!0}catch(m){c=m,a.f=!0,ay(a)||(d=!0)}}a.c=c;e&&(k=sa(a.v,a,!0),e=sa(a.v,a,!1),c instanceof Ux?($x(c,k,e),c.C=!0):c.then(k,e));d&&
(c=new cy(c),by[c.ta]=c,a.i=c.ta)}function Zx(){ya.call(this)}w(Zx,ya);Zx.prototype.message="Deferred has already fired";Zx.prototype.name="AlreadyCalledError";function Vx(){ya.call(this)}w(Vx,ya);Vx.prototype.message="Deferred was canceled";Vx.prototype.name="CanceledError";function cy(a){this.ta=ba.setTimeout(sa(this.a,this),0);this.b=a}cy.prototype.a=function(){delete by[this.ta];throw this.b;};var by={};function dy(a,c){ca(a.name)?(this.name=a.name,this.code=ey[a.name]):(this.code=a.code,this.name=fy(a.code));ya.call(this,Ba("%s %s",this.name,c))}w(dy,ya);function fy(a){var c=Pb(ey,function(c){return a==c});if(!ca(c))throw Error("Invalid code: "+a);return c}var ey={AbortError:3,EncodingError:5,InvalidModificationError:9,InvalidStateError:7,NotFoundError:1,NotReadableError:4,NoModificationAllowedError:6,PathExistsError:12,QuotaExceededError:10,SecurityError:2,SyntaxError:8,TypeMismatchError:11};function gy(a,c){vc.call(this,a.type,c)}w(gy,vc);function hy(){cd.call(this);this.hb=new FileReader;this.hb.onloadstart=sa(this.b,this);this.hb.onprogress=sa(this.b,this);this.hb.onload=sa(this.b,this);this.hb.onabort=sa(this.b,this);this.hb.onerror=sa(this.b,this);this.hb.onloadend=sa(this.b,this)}w(hy,cd);hy.prototype.getError=function(){return this.hb.error&&new dy(this.hb.error,"reading file")};hy.prototype.b=function(a){this.u(new gy(a,this))};hy.prototype.W=function(){hy.ba.W.call(this);delete this.hb};
function iy(a){var c=new Ux;a.Ka("loadend",ta(function(a,c){var f=c.hb.result,g=c.getError();null==f||g?(Wx(a),Xx(a,!1,g)):a.Sc(f);c.sc()},c,a));return c};function jy(a){a=a?a:{};Sk.call(this,{handleEvent:te});this.i=a.formatConstructors?a.formatConstructors:[];this.A=a.projection?Ee(a.projection):null;this.f=null;this.a=void 0}w(jy,Sk);jy.prototype.W=function(){this.a&&Zc(this.a);jy.ba.W.call(this)};jy.prototype.j=function(a){a=a.b.dataTransfer.files;var c,d,e;c=0;for(d=a.length;c<d;++c){var f=e=a[c],g=new hy,h=iy(g);g.hb.readAsText(f,"");$x(h,ta(this.l,e),null,this)}};
jy.prototype.l=function(a,c){var d=this.v,e=this.A;e||(e=d.$().g);var d=this.i,f=[],g,h;g=0;for(h=d.length;g<h;++g){var k=new d[g],m;try{m=k.va(c)}catch(t){m=null}if(m){var k=k.Pa(c),k=Xe(k,e),n,p;n=0;for(p=m.length;n<p;++n){var q=m[n],r=q.Y();r&&r.Ub(k);f.push(q)}}}this.u(new ky(ly,this,a,f,e))};jy.prototype.setMap=function(a){this.a&&(Zc(this.a),this.a=void 0);this.f&&(uc(this.f),this.f=null);jy.ba.setMap.call(this,a);a&&(this.f=new Tx(a.a),this.a=B(this.f,"drop",this.j,!1,this))};var ly="addfeatures";
function ky(a,c,d,e,f){vc.call(this,a,c);this.features=e;this.file=d;this.projection=f}w(ky,vc);function my(a,c){this.x=a;this.y=c}w(my,Fg);my.prototype.clone=function(){return new my(this.x,this.y)};my.prototype.scale=Fg.prototype.scale;my.prototype.add=function(a){this.x+=a.x;this.y+=a.y;return this};my.prototype.rotate=function(a){var c=Math.cos(a);a=Math.sin(a);var d=this.y*c+this.x*a;this.x=this.x*c-this.y*a;this.y=d;return this};function ny(a){a=a?a:{};el.call(this,{handleDownEvent:oy,handleDragEvent:py,handleUpEvent:qy});this.l=a.condition?a.condition:bl;this.a=this.f=void 0;this.j=0;this.A=a.duration?a.duration:400}w(ny,el);
function py(a){if(dl(a)){var c=a.map,d=c.La();a=a.pixel;a=new my(a[0]-d[0]/2,d[1]/2-a[1]);d=Math.atan2(a.y,a.x);a=Math.sqrt(a.x*a.x+a.y*a.y);var e=c.$();c.render();if(void 0!==this.f){var f=d-this.f;Tk(c,e,e.za()-f)}this.f=d;void 0!==this.a&&(d=this.a*(e.aa()/a),Vk(c,e,d));void 0!==this.a&&(this.j=this.a/a);this.a=a}}
function qy(a){if(!dl(a))return!0;a=a.map;var c=a.$();Wf(c,-1);var d=this.j-1,e=c.za(),e=c.constrainRotation(e,0);Tk(a,c,e,void 0,void 0);var e=c.aa(),f=this.A,e=c.constrainResolution(e,0,d);Vk(a,c,e,void 0,f);this.j=0;return!1}function oy(a){return dl(a)&&this.l(a)?(Wf(a.map.$(),1),this.a=this.f=void 0,!0):!1};function ry(a,c){vc.call(this,a);this.feature=c}w(ry,vc);
function sy(a){el.call(this,{handleDownEvent:ty,handleEvent:uy,handleUpEvent:vy});this.ca=null;this.T=!1;this.tb=a.source?a.source:null;this.Da=a.features?a.features:null;this.Oh=a.snapTolerance?a.snapTolerance:12;this.V=a.type;this.f=wy(this.V);this.sa=a.minPoints?a.minPoints:this.f===xy?3:2;this.ma=a.maxPoints?a.maxPoints:Infinity;var c=a.geometryFunction;if(!c)if("Circle"===this.V)c=function(a,c){var d=c?c:new $m([NaN,NaN]);d.Cf(a[0],Math.sqrt(xd(a[0],a[1])));return d};else{var d,c=this.f;c===
yy?d=C:c===zy?d=I:c===xy&&(d=D);c=function(a,c){var g=c;g?g.ja(a):g=new d(a);return g}}this.C=c;this.H=this.A=this.a=this.P=this.j=this.l=null;this.ri=a.clickTolerance?a.clickTolerance*a.clickTolerance:36;this.da=new G({source:new U({useSpatialIndex:!1,wrapX:a.wrapX?a.wrapX:!1}),style:a.style?a.style:Ay()});this.sb=a.geometryName;this.He=a.condition?a.condition:al;this.na=a.freehandCondition?a.freehandCondition:bl;B(this,kd("active"),this.Dh,!1,this)}w(sy,el);
function Ay(){var a=lm();return function(c){return a[c.Y().Z()]}}l=sy.prototype;l.setMap=function(a){sy.ba.setMap.call(this,a);this.Dh()};function uy(a){var c=!this.T;this.T&&a.type===ck?(By(this,a),c=!1):a.type===bk?c=Cy(this,a):a.type===Vj&&(c=!1);return fl.call(this,a)&&c}function ty(a){if(this.He(a))return this.ca=a.pixel,!0;if(this.f!==zy&&this.f!==xy||!this.na(a))return!1;this.ca=a.pixel;this.T=!0;this.l||Dy(this,a);return!0}
function vy(a){this.T=!1;var c=this.ca,d=a.pixel,e=c[0]-d[0],c=c[1]-d[1],d=!0;e*e+c*c<=this.ri&&(Cy(this,a),this.l?this.f===Ey?this.bd():Fy(this,a)?this.bd():By(this,a):(Dy(this,a),this.f===yy&&this.bd()),d=!1);return d}
function Cy(a,c){if(a.l){var d=c.coordinate,e=a.j.Y(),f;a.f===yy?f=a.a:a.f===xy?(f=a.a[0],f=f[f.length-1],Fy(a,c)&&(d=a.l.slice())):(f=a.a,f=f[f.length-1]);f[0]=d[0];f[1]=d[1];a.C(a.a,e);a.P&&a.P.Y().ja(d);e instanceof D&&a.f!==xy?(a.A||(a.A=new P(new I(null))),e=e.bg(0),d=a.A.Y(),jn(d,e.a,e.o)):a.H&&(d=a.A.Y(),d.ja(a.H));Gy(a)}else d=c.coordinate.slice(),a.P?a.P.Y().ja(d):(a.P=new P(new C(d)),Gy(a));return!0}
function Fy(a,c){var d=!1;if(a.j){var e=!1,f=[a.l];a.f===zy?e=a.a.length>a.sa:a.f===xy&&(e=a.a[0].length>a.sa,f=[a.a[0][0],a.a[0][a.a[0].length-2]]);if(e)for(var e=c.map,g=0,h=f.length;g<h;g++){var k=f[g],m=e.Ga(k),n=c.pixel,d=n[0]-m[0],m=n[1]-m[1],n=a.T&&a.na(c)?1:a.Oh;if(d=Math.sqrt(d*d+m*m)<=n){a.l=k;break}}}return d}
function Dy(a,c){var d=c.coordinate;a.l=d;a.f===yy?a.a=d.slice():a.f===xy?(a.a=[[d.slice(),d.slice()]],a.H=a.a[0]):(a.a=[d.slice(),d.slice()],a.f===Ey&&(a.H=a.a));a.H&&(a.A=new P(new I(a.H)));d=a.C(a.a);a.j=new P;a.sb&&a.j.Kc(a.sb);a.j.Ca(d);Gy(a);a.u(new ry("drawstart",a.j))}
function By(a,c){var d=c.coordinate,e=a.j.Y(),f,g;if(a.f===zy)a.l=d.slice(),g=a.a,g.push(d.slice()),f=g.length>a.ma,a.C(g,e);else if(a.f===xy){g=a.a[0];g.push(d.slice());if(f=g.length>a.ma)a.l=g[0];a.C(a.a,e)}Gy(a);f&&a.bd()}l.On=function(){var a=this.j.Y(),c,d;this.f===zy?(c=this.a,c.splice(-2,1),this.C(c,a)):this.f===xy&&(c=this.a[0],c.splice(-2,1),d=this.A.Y(),d.ja(c),this.C(this.a,a));0===c.length&&(this.l=null);Gy(this)};
l.bd=function(){var a=Hy(this),c=this.a,d=a.Y();this.f===zy?(c.pop(),this.C(c,d)):this.f===xy&&(c[0].pop(),c[0].push(c[0][0]),this.C(c,d));"MultiPoint"===this.V?a.Ca(new mn([c])):"MultiLineString"===this.V?a.Ca(new N([c])):"MultiPolygon"===this.V&&a.Ca(new O([c]));this.u(new ry("drawend",a));this.Da&&this.Da.push(a);this.tb&&this.tb.Fc(a)};function Hy(a){a.l=null;var c=a.j;c&&(a.j=null,a.P=null,a.A=null,a.da.ga().clear(!0));return c}
l.ol=function(a){var c=a.Y();this.j=a;this.a=c.X();a=this.a[this.a.length-1];this.l=a.slice();this.a.push(a.slice());Gy(this);this.u(new ry("drawstart",this.j))};l.mc=se;function Gy(a){var c=[];a.j&&c.push(a.j);a.A&&c.push(a.A);a.P&&c.push(a.P);a=a.da.ga();a.clear(!0);a.Tb(c)}l.Dh=function(){var a=this.v,c=this.c();a&&c||Hy(this);this.da.setMap(c?a:null)};
function wy(a){var c;"Point"===a||"MultiPoint"===a?c=yy:"LineString"===a||"MultiLineString"===a?c=zy:"Polygon"===a||"MultiPolygon"===a?c=xy:"Circle"===a&&(c=Ey);return c}var yy="Point",zy="LineString",xy="Polygon",Ey="Circle";function Iy(a,c,d){vc.call(this,a);this.features=c;this.mapBrowserPointerEvent=d}w(Iy,vc);
function Jy(a){el.call(this,{handleDownEvent:Ky,handleDragEvent:Ly,handleEvent:My,handleUpEvent:Ny});this.ma=a.deleteCondition?a.deleteCondition:ye(al,$k);this.na=this.f=null;this.ca=[0,0];this.C=this.T=!1;this.a=new Pp;this.P=void 0!==a.pixelTolerance?a.pixelTolerance:10;this.l=this.da=!1;this.j=null;this.H=new G({source:new U({useSpatialIndex:!1,wrapX:!!a.wrapX}),style:a.style?a.style:Oy(),updateWhileAnimating:!0,updateWhileInteracting:!0});this.V={Point:this.vl,LineString:this.Bg,LinearRing:this.Bg,
Polygon:this.wl,MultiPoint:this.tl,MultiLineString:this.sl,MultiPolygon:this.ul,GeometryCollection:this.rl};this.A=a.features;this.A.forEach(this.nf,this);B(this.A,"add",this.pl,!1,this);B(this.A,"remove",this.ql,!1,this)}w(Jy,el);l=Jy.prototype;l.nf=function(a){var c=a.Y();c.Z()in this.V&&this.V[c.Z()].call(this,a,c);(c=this.v)&&Py(this,this.ca,c);B(a,"change",this.Ag,!1,this)};function Qy(a,c){a.C||(a.C=!0,a.u(new Iy("modifystart",a.A,c)))}
function Ry(a,c){Sy(a,c);a.f&&0===a.A.Mb()&&(a.H.ga().hc(a.f),a.f=null);Yc(c,"change",a.Ag,!1,a)}function Sy(a,c){var d=a.a,e=[];d.forEach(function(a){c===a.feature&&e.push(a)});for(var f=e.length-1;0<=f;--f)d.remove(e[f])}l.setMap=function(a){this.H.setMap(a);Jy.ba.setMap.call(this,a)};l.pl=function(a){this.nf(a.element)};l.Ag=function(a){this.l||(a=a.target,Ry(this,a),this.nf(a))};l.ql=function(a){Ry(this,a.element)};
l.vl=function(a,c){var d=c.X(),d={feature:a,geometry:c,ia:[d,d]};this.a.ua(c.J(),d)};l.tl=function(a,c){var d=c.X(),e,f,g;f=0;for(g=d.length;f<g;++f)e=d[f],e={feature:a,geometry:c,depth:[f],index:f,ia:[e,e]},this.a.ua(c.J(),e)};l.Bg=function(a,c){var d=c.X(),e,f,g,h;e=0;for(f=d.length-1;e<f;++e)g=d.slice(e,e+2),h={feature:a,geometry:c,index:e,ia:g},this.a.ua(Nd(g),h)};
l.sl=function(a,c){var d=c.X(),e,f,g,h,k,m,n;h=0;for(k=d.length;h<k;++h)for(e=d[h],f=0,g=e.length-1;f<g;++f)m=e.slice(f,f+2),n={feature:a,geometry:c,depth:[h],index:f,ia:m},this.a.ua(Nd(m),n)};l.wl=function(a,c){var d=c.X(),e,f,g,h,k,m,n;h=0;for(k=d.length;h<k;++h)for(e=d[h],f=0,g=e.length-1;f<g;++f)m=e.slice(f,f+2),n={feature:a,geometry:c,depth:[h],index:f,ia:m},this.a.ua(Nd(m),n)};
l.ul=function(a,c){var d=c.X(),e,f,g,h,k,m,n,p,q,r;m=0;for(n=d.length;m<n;++m)for(p=d[m],h=0,k=p.length;h<k;++h)for(e=p[h],f=0,g=e.length-1;f<g;++f)q=e.slice(f,f+2),r={feature:a,geometry:c,depth:[h,m],index:f,ia:q},this.a.ua(Nd(q),r)};l.rl=function(a,c){var d,e=c.f;for(d=0;d<e.length;++d)this.V[e[d].Z()].call(this,a,e[d])};function Ty(a,c){var d=a.f;d?d.Y().ja(c):(d=new P(new C(c)),a.f=d,a.H.ga().Fc(d))}function Uy(a,c){return a.index-c.index}
function Ky(a){Py(this,a.pixel,a.map);this.j=[];this.C=!1;var c=this.f;if(c){var d=[],c=c.Y().X(),e=Nd([c]),e=Sp(this.a,e),f={};e.sort(Uy);for(var g=0,h=e.length;g<h;++g){var k=e[g],m=k.ia,n=v(k.feature),p=k.depth;p&&(n+="-"+p.join("-"));f[n]||(f[n]=Array(2));if(vd(m[0],c)&&!f[n][0])this.j.push([k,0]),f[n][0]=k;else if(vd(m[1],c)&&!f[n][1]){if("LineString"!==k.geometry.Z()&&"MultiLineString"!==k.geometry.Z()||!f[n][0]||0!==f[n][0].index)this.j.push([k,1]),f[n][1]=k}else v(m)in this.na&&!f[n][0]&&
!f[n][1]&&d.push([k,c])}d.length&&Qy(this,a);for(g=d.length-1;0<=g;--g)this.lk.apply(this,d[g])}return!!this.f}
function Ly(a){this.T=!1;Qy(this,a);a=a.coordinate;for(var c=0,d=this.j.length;c<d;++c){for(var e=this.j[c],f=e[0],g=f.depth,h=f.geometry,k=h.X(),m=f.ia,e=e[1];a.length<h.I;)a.push(0);switch(h.Z()){case "Point":k=a;m[0]=m[1]=a;break;case "MultiPoint":k[f.index]=a;m[0]=m[1]=a;break;case "LineString":k[f.index+e]=a;m[e]=a;break;case "MultiLineString":k[g[0]][f.index+e]=a;m[e]=a;break;case "Polygon":k[g[0]][f.index+e]=a;m[e]=a;break;case "MultiPolygon":k[g[1]][g[0]][f.index+e]=a,m[e]=a}f=h;this.l=!0;
f.ja(k);this.l=!1}Ty(this,a)}function Ny(a){for(var c,d=this.j.length-1;0<=d;--d)c=this.j[d][0],Qp(this.a,Nd(c.ia),c);this.C&&(this.u(new Iy("modifyend",this.A,a)),this.C=!1);return!1}
function My(a){if(!(a instanceof Rj))return!0;var c;a.map.$().c.slice()[1]||a.type!=bk||this.B||(this.ca=a.pixel,Py(this,a.pixel,a.map));if(this.f&&this.ma(a))if(a.type==Wj&&this.T)c=!0;else{this.f.Y();Qy(this,a);c=this.j;var d={},e,f,g,h,k,m,n,p,q;for(k=c.length-1;0<=k;--k)if(g=c[k],p=g[0],h=p.geometry,f=h.X(),q=v(p.feature),p.depth&&(q+="-"+p.depth.join("-")),n=e=m=void 0,0===g[1]?(e=p,m=p.index):1==g[1]&&(n=p,m=p.index+1),q in d||(d[q]=[n,e,m]),g=d[q],void 0!==n&&(g[0]=n),void 0!==e&&(g[1]=e),
void 0!==g[0]&&void 0!==g[1]){e=f;q=!1;n=m-1;switch(h.Z()){case "MultiLineString":f[p.depth[0]].splice(m,1);q=!0;break;case "LineString":f.splice(m,1);q=!0;break;case "MultiPolygon":e=e[p.depth[1]];case "Polygon":e=e[p.depth[0]],4<e.length&&(m==e.length-1&&(m=0),e.splice(m,1),q=!0,0===m&&(e.pop(),e.push(e[0]),n=e.length-1))}q&&(this.a.remove(g[0]),this.a.remove(g[1]),e=h,this.l=!0,e.ja(f),this.l=!1,f={depth:p.depth,feature:p.feature,geometry:p.geometry,index:n,ia:[g[0].ia[0],g[1].ia[1]]},this.a.ua(Nd(f.ia),
f),Vy(this,h,m,p.depth,-1),this.f&&(this.H.ga().hc(this.f),this.f=null))}c=!0;this.u(new Iy("modifyend",this.A,a));this.C=!1}a.type==Wj&&(this.T=!1);return fl.call(this,a)&&!c}
function Py(a,c,d){function e(a,c){return yd(f,a.ia)-yd(f,c.ia)}var f=d.Aa(c),g=d.Aa([c[0]-a.P,c[1]+a.P]),h=d.Aa([c[0]+a.P,c[1]-a.P]),g=Nd([g,h]),g=Sp(a.a,g);if(0<g.length){g.sort(e);var h=g[0].ia,k=sd(f,h),m=d.Ga(k);if(Math.sqrt(xd(c,m))<=a.P){c=d.Ga(h[0]);d=d.Ga(h[1]);c=xd(m,c);d=xd(m,d);a.da=Math.sqrt(Math.min(c,d))<=a.P;a.da&&(k=c>d?h[1]:h[0]);Ty(a,k);d={};d[v(h)]=!0;c=1;for(m=g.length;c<m;++c)if(k=g[c].ia,vd(h[0],k[0])&&vd(h[1],k[1])||vd(h[0],k[1])&&vd(h[1],k[0]))d[v(k)]=!0;else break;a.na=d;
return}}a.f&&(a.H.ga().hc(a.f),a.f=null)}
l.lk=function(a,c){for(var d=a.ia,e=a.feature,f=a.geometry,g=a.depth,h=a.index,k;c.length<f.I;)c.push(0);switch(f.Z()){case "MultiLineString":k=f.X();k[g[0]].splice(h+1,0,c);break;case "Polygon":k=f.X();k[g[0]].splice(h+1,0,c);break;case "MultiPolygon":k=f.X();k[g[1]][g[0]].splice(h+1,0,c);break;case "LineString":k=f.X();k.splice(h+1,0,c);break;default:return}this.l=!0;f.ja(k);this.l=!1;k=this.a;k.remove(a);Vy(this,f,h,g,1);var m={ia:[d[0],c],feature:e,geometry:f,depth:g,index:h};k.ua(Nd(m.ia),m);
this.j.push([m,1]);d={ia:[c,d[1]],feature:e,geometry:f,depth:g,index:h+1};k.ua(Nd(d.ia),d);this.j.push([d,0]);this.T=!0};function Vy(a,c,d,e,f){Up(a.a,c.J(),function(a){a.geometry===c&&(void 0===e||void 0===a.depth||rb(a.depth,e))&&a.index>d&&(a.index+=f)})}function Oy(){var a=lm();return function(){return a.Point}};function Wy(a,c,d,e){vc.call(this,a);this.selected=c;this.deselected=d;this.mapBrowserEvent=e}w(Wy,vc);
function Xy(a){Sk.call(this,{handleEvent:Yy});a=a?a:{};this.B=a.condition?a.condition:$k;this.l=a.addCondition?a.addCondition:se;this.C=a.removeCondition?a.removeCondition:se;this.P=a.toggleCondition?a.toggleCondition:bl;this.A=a.multi?a.multi:!1;this.i=a.filter?a.filter:te;var c;if(a.layers)if(ka(a.layers))c=a.layers;else{var d=a.layers;c=function(a){return ub(d,a)}}else c=te;this.j=c;this.a={};this.f=new G({source:new U({useSpatialIndex:!1,features:a.features,wrapX:a.wrapX}),style:a.style?a.style:
Zy(),updateWhileAnimating:!0,updateWhileInteracting:!0});a=this.f.ga().c;B(a,"add",this.xl,!1,this);B(a,"remove",this.Al,!1,this)}w(Xy,Sk);l=Xy.prototype;l.yl=function(){return this.f.ga().c};l.zl=function(a){a=v(a);return this.a[a]};
function Yy(a){if(!this.B(a))return!0;var c=this.l(a),d=this.C(a),e=this.P(a),f=!c&&!d&&!e,g=a.map,h=this.f.ga().c,k=[],m=[],n=!1;if(f)g.cd(a.pixel,function(a,c){if(this.i(a,c)){m.push(a);var d=v(a);this.a[d]=c;return!this.A}},this,this.j),0<m.length&&1==h.Mb()&&h.item(0)==m[0]||(n=!0,0!==h.Mb()&&(k=Array.prototype.concat(h.a),h.clear()),h.gf(m),0===m.length?Rb(this.a):0<k.length&&k.forEach(function(a){a=v(a);delete this.a[a]},this));else{g.cd(a.pixel,function(a,f){if(!ub(h.a,a)){if((c||e)&&this.i(a,
f)){m.push(a);var g=v(a);this.a[g]=f}}else if(d||e)k.push(a),g=v(a),delete this.a[g]},this,this.j);for(f=k.length-1;0<=f;--f)h.remove(k[f]);h.gf(m);if(0<m.length||0<k.length)n=!0}n&&this.u(new Wy("select",m,k,a));return Zk(a)}l.setMap=function(a){var c=this.v,d=this.f.ga().c;null===c||d.forEach(c.Bh,c);Xy.ba.setMap.call(this,a);this.f.setMap(a);null===a||d.forEach(a.yh,a)};
function Zy(){var a=lm();kb(a.Polygon,a.LineString);kb(a.GeometryCollection,a.LineString);return function(c){return a[c.Y().Z()]}}l.xl=function(a){a=a.element;var c=this.v;null===c||c.yh(a)};l.Al=function(a){a=a.element;var c=this.v;null===c||c.Bh(a)};function $y(a){el.call(this,{handleEvent:az,handleDownEvent:te,handleUpEvent:bz});a=a?a:{};this.l=a.source?a.source:null;this.j=a.features?a.features:null;this.ca=[];this.C={};this.P={};this.T={};this.A={};this.H=null;this.f=void 0!==a.pixelTolerance?a.pixelTolerance:10;this.da=sa(cz,this);this.a=new Pp;this.V={Point:this.Gl,LineString:this.Eg,LinearRing:this.Eg,Polygon:this.Hl,MultiPoint:this.El,MultiLineString:this.Dl,MultiPolygon:this.Fl,GeometryCollection:this.Cl}}w($y,el);l=$y.prototype;
l.jd=function(a,c){var d=void 0!==c?c:!0,e=a.Y(),f=this.V[e.Z()];if(f){var g=v(a);this.T[g]=e.J(Od());f.call(this,a,e);d&&(this.P[g]=e.G("change",sa(this.Kj,this,a),this),this.C[g]=a.G(kd(a.a),this.Bl,this))}};l.Hi=function(a){this.jd(a)};l.Ii=function(a){this.kd(a)};l.Cg=function(a){var c;a instanceof Zp?c=a.feature:a instanceof ug&&(c=a.element);this.jd(c)};l.Dg=function(a){var c;a instanceof Zp?c=a.feature:a instanceof ug&&(c=a.element);this.kd(c)};
l.Bl=function(a){a=a.g;this.kd(a,!0);this.jd(a,!0)};l.Kj=function(a){if(this.B){var c=v(a);c in this.A||(this.A[c]=a)}else this.Ch(a)};l.kd=function(a,c){var d=void 0!==c?c:!0,e=v(a),f=this.T[e];if(f){var g=this.a,h=[];Up(g,f,function(c){a===c.feature&&h.push(c)});for(f=h.length-1;0<=f;--f)g.remove(h[f]);d&&(Zc(this.P[e]),delete this.P[e],Zc(this.C[e]),delete this.C[e])}};
l.setMap=function(a){var c=this.v,d=this.ca,e;this.j?e=this.j:this.l&&(e=this.l.Gc());c&&(d.forEach(gd),d.length=0,e.forEach(this.Ii,this));$y.ba.setMap.call(this,a);a&&(this.j?(d.push(this.j.G("add",this.Cg,this)),d.push(this.j.G("remove",this.Dg,this))):this.l&&(d.push(this.l.G("addfeature",this.Cg,this)),d.push(this.l.G("removefeature",this.Dg,this))),e.forEach(this.Hi,this))};l.mc=se;l.Ch=function(a){this.kd(a,!1);this.jd(a,!1)};
l.Cl=function(a,c){var d,e=c.f;for(d=0;d<e.length;++d)this.V[e[d].Z()].call(this,a,e[d])};l.Eg=function(a,c){var d=c.X(),e,f,g,h;e=0;for(f=d.length-1;e<f;++e)g=d.slice(e,e+2),h={feature:a,ia:g},this.a.ua(Nd(g),h)};l.Dl=function(a,c){var d=c.X(),e,f,g,h,k,m,n;h=0;for(k=d.length;h<k;++h)for(e=d[h],f=0,g=e.length-1;f<g;++f)m=e.slice(f,f+2),n={feature:a,ia:m},this.a.ua(Nd(m),n)};l.El=function(a,c){var d=c.X(),e,f,g;f=0;for(g=d.length;f<g;++f)e=d[f],e={feature:a,ia:[e,e]},this.a.ua(c.J(),e)};
l.Fl=function(a,c){var d=c.X(),e,f,g,h,k,m,n,p,q,r;m=0;for(n=d.length;m<n;++m)for(p=d[m],h=0,k=p.length;h<k;++h)for(e=p[h],f=0,g=e.length-1;f<g;++f)q=e.slice(f,f+2),r={feature:a,ia:q},this.a.ua(Nd(q),r)};l.Gl=function(a,c){var d=c.X(),d={feature:a,ia:[d,d]};this.a.ua(c.J(),d)};l.Hl=function(a,c){var d=c.X(),e,f,g,h,k,m,n;h=0;for(k=d.length;h<k;++h)for(e=d[h],f=0,g=e.length-1;f<g;++f)m=e.slice(f,f+2),n={feature:a,ia:m},this.a.ua(Nd(m),n)};
function az(a){var c,d,e=a.pixel,f=a.coordinate;c=a.map;var g=c.Aa([e[0]-this.f,e[1]+this.f]);d=c.Aa([e[0]+this.f,e[1]-this.f]);var g=Nd([g,d]),h=Sp(this.a,g),k=!1,g=!1,m=null;d=null;0<h.length&&(this.H=f,h.sort(this.da),h=h[0].ia,m=sd(f,h),d=c.Ga(m),Math.sqrt(xd(e,d))<=this.f&&(g=!0,e=c.Ga(h[0]),f=c.Ga(h[1]),e=xd(d,e),f=xd(d,f),k=Math.sqrt(Math.min(e,f))<=this.f))&&(m=e>f?h[1]:h[0],d=c.Ga(m),d=[Math.round(d[0]),Math.round(d[1])]);c=m;g&&(a.coordinate=c.slice(0,2),a.pixel=d);return fl.call(this,a)}
function bz(){var a=Lb(this.A);a.length&&(a.forEach(this.Ch,this),this.A={});return!1}function cz(a,c){return yd(this.H,a.ia)-yd(this.H,c.ia)};function dz(a,c,d){vc.call(this,a);this.features=c;this.coordinate=d}w(dz,vc);function ez(a){el.call(this,{handleDownEvent:fz,handleDragEvent:gz,handleMoveEvent:hz,handleUpEvent:iz});this.l=void 0;this.a=null;this.f=void 0!==a.features?a.features:null;this.j=null}w(ez,el);function fz(a){this.j=jz(this,a.pixel,a.map);return!this.a&&this.j?(this.a=a.coordinate,hz.call(this,a),this.u(new dz("translatestart",this.f,a.coordinate)),!0):!1}
function iz(a){return this.a?(this.a=null,hz.call(this,a),this.u(new dz("translateend",this.f,a.coordinate)),!0):!1}function gz(a){if(this.a){a=a.coordinate;var c=a[0]-this.a[0],d=a[1]-this.a[1];if(this.f)this.f.forEach(function(a){var e=a.Y();e.Dc(c,d);a.Ca(e)});else if(this.j){var e=this.j.Y();e.Dc(c,d);this.j.Ca(e)}this.a=a;this.u(new dz("translating",this.f,a))}}
function hz(a){var c=a.map.Ac();if(a=a.map.cd(a.pixel,function(a){return a})){var d=!1;this.f&&ub(this.f.a,a)&&(d=!0);this.l=c.style.cursor;c.style.cursor=this.a?"-webkit-grabbing":d?"-webkit-grab":"pointer";c.style.cursor=this.a?d?"grab":"pointer":"grabbing"}else c.style.cursor=void 0!==this.l?this.l:"",this.l=void 0}function jz(a,c,d){var e=null;c=d.cd(c,function(a){return a});a.f&&ub(a.f.a,c)&&(e=c);return e};function X(a){a=a?a:{};var c=Ub(a);delete c.gradient;delete c.radius;delete c.blur;delete c.shadow;delete c.weight;G.call(this,c);this.f=null;this.V=void 0!==a.shadow?a.shadow:250;this.H=void 0;this.B=null;B(this,kd("gradient"),this.Lj,!1,this);this.sh(a.gradient?a.gradient:kz);this.oh(void 0!==a.blur?a.blur:15);this.Gg(void 0!==a.radius?a.radius:8);B(this,[kd("blur"),kd("radius")],this.lg,!1,this);this.lg();var d=a.weight?a.weight:"weight",e;ia(d)?e=function(a){return a.get(d)}:e=d;this.g(sa(function(a){a=
e(a);a=void 0!==a?Sa(a,0,1):1;var c=255*a|0,d=this.B[c];d||(d=[new gm({image:new Ak({opacity:a,src:this.H})})],this.B[c]=d);return d},this));this.set("renderOrder",null);B(this,"render",this.ck,!1,this)}w(X,G);var kz=["#00f","#0ff","#0f0","#ff0","#f00"];l=X.prototype;l.Yf=function(){return this.get("blur")};l.ag=function(){return this.get("gradient")};l.Fg=function(){return this.get("radius")};
l.Lj=function(){for(var a=this.ag(),c=Ti(1,256),d=c.createLinearGradient(0,0,1,256),e=1/(a.length-1),f=0,g=a.length;f<g;++f)d.addColorStop(f*e,a[f]);c.fillStyle=d;c.fillRect(0,0,1,256);this.f=c.getImageData(0,0,1,256).data};l.lg=function(){var a=this.Fg(),c=this.Yf(),d=a+c+1,e=2*d,e=Ti(e,e);e.shadowOffsetX=e.shadowOffsetY=this.V;e.shadowBlur=c;e.shadowColor="#000";e.beginPath();c=d-this.V;e.arc(c,c,a,0,2*Math.PI,!0);e.fill();this.H=e.canvas.toDataURL();this.B=Array(256);this.s()};
l.ck=function(a){a=a.context;var c=a.canvas,c=a.getImageData(0,0,c.width,c.height),d=c.data,e,f,g;e=0;for(f=d.length;e<f;e+=4)if(g=4*d[e+3])d[e]=this.f[g],d[e+1]=this.f[g+1],d[e+2]=this.f[g+2];a.putImageData(c,0,0)};l.oh=function(a){this.set("blur",a)};l.sh=function(a){this.set("gradient",a)};l.Gg=function(a){this.set("radius",a)};function lz(a,c,d,e,f,g,h,k,m,n,p){Dh.call(this,[f,g,h],0);this.B=void 0!==p?p:!1;this.A=k;this.g=null;this.f={};this.i=c;this.l=e;this.a=[];this.c=null;this.j=0;h=e.xa(this.b);p=this.l.J();g=this.i.J();h=p?ne(h,p):h;if(0===he(h))this.state=4;else if((p=a.J())&&(g?g=ne(g,p):g=p),e=e.aa(f),e=vn(a,d,le(h),e),!isFinite(e)||isNaN(e)||0>=e)this.state=4;else if(this.v=new yn(a,d,h,g,e*(void 0!==n?n:.5)),0===this.v.f.length)this.state=4;else if(this.j=Ph(c,e),d=An(this.v),g&&(a.a?(d[1]=Sa(d[1],g[1],g[3]),
d[3]=Sa(d[3],g[1],g[3])):d=ne(d,g)),he(d))if(a=mg(c,d,this.j),100>rg(a)*qg(a)){for(c=a.b;c<=a.f;c++)for(d=a.a;d<=a.c;d++)(n=m(this.j,c,d,k))&&this.a.push(n);0===this.a.length&&(this.state=4)}else this.state=3;else this.state=4}w(lz,Dh);lz.prototype.W=function(){1==this.state&&(this.c.forEach(Zc),this.c=null);lz.ba.W.call(this)};lz.prototype.Ma=function(a){if(void 0!==a){var c=v(a);if(c in this.f)return this.f[c];a=Qb(this.f)?this.g:this.g.cloneNode(!1);return this.f[c]=a}return this.g};
function mz(a){var c=[];a.a.forEach(function(a){a&&2==a.state&&c.push({extent:this.i.xa(a.b),image:a.Ma()})},a);a.a.length=0;var d=a.b,e=d[0],f=a.l.Ia(e),g=ja(f)?f:f[0],f=ja(f)?f:f[1],e=a.l.aa(e),h=a.i.aa(a.j),d=a.l.xa(d);a.g=xn(g,f,a.A,h,a.i.J(),e,d,a.v,c,a.B);a.state=2;Eh(a)}
lz.prototype.load=function(){if(0==this.state){this.state=1;Eh(this);var a=0;this.c=[];this.a.forEach(function(c){var d=c.state;if(0==d||1==d){a++;var e;e=c.Ka("change",function(){var d=c.state;if(2==d||3==d||4==d)Zc(e),a--,0===a&&(this.c.forEach(Zc),this.c=null,mz(this))},!1,this);this.c.push(e)}},this);this.a.forEach(function(a){0==a.state&&a.load()});0===a&&mz(this)}};function nz(a,c){var d=c||{},e=d.document||document,f=Rg("SCRIPT"),g={nh:f,nc:void 0},h=new Ux(oz,g),k=null,m=null!=d.timeout?d.timeout:5E3;0<m&&(k=window.setTimeout(function(){pz(f,!0);var c=new qz(rz,"Timeout reached for loading script "+a);Wx(h);Xx(h,!1,c)},m),g.nc=k);f.onload=f.onreadystatechange=function(){f.readyState&&"loaded"!=f.readyState&&"complete"!=f.readyState||(pz(f,d.Ci||!1,k),h.Sc(null))};f.onerror=function(){pz(f,!0,k);var c=new qz(sz,"Error while loading script "+a);Wx(h);Xx(h,!1,
c)};g=d.attributes||{};Xb(g,{type:"text/javascript",charset:"UTF-8",src:a});Lg(f,g);tz(e).appendChild(f);return h}function tz(a){var c=a.getElementsByTagName("HEAD");return c&&0!=c.length?c[0]:a.documentElement}function oz(){if(this&&this.nh){var a=this.nh;a&&"SCRIPT"==a.tagName&&pz(a,!0,this.nc)}}function pz(a,c,d){null!=d&&ba.clearTimeout(d);a.onload=da;a.onerror=da;a.onreadystatechange=da;c&&window.setTimeout(function(){Vg(a)},0)}var sz=0,rz=1;
function qz(a,c){var d="Jsloader error (code #"+a+")";c&&(d+=": "+c);ya.call(this,d);this.code=a}w(qz,ya);function uz(a,c){this.a=new yt(a);this.b=c?c:"callback";this.nc=5E3}var vz=0;function wz(a,c,d,e){c=c||null;var f="_"+(vz++).toString(36)+ua().toString(36);ba._callbacks_||(ba._callbacks_={});var g=a.a.clone();if(c)for(var h in c)if(!c.hasOwnProperty||c.hasOwnProperty(h)){var k=g,m=h,n=c[h];ga(n)||(n=[String(n)]);Rt(k.c,m,n)}d&&(ba._callbacks_[f]=xz(f,d),d=a.b,h="_callbacks_."+f,ga(h)||(h=[String(h)]),Rt(g.c,d,h));a=nz(g.toString(),{timeout:a.nc,Ci:!0});$x(a,null,yz(f,c,e),void 0)}
uz.prototype.cancel=function(a){a&&(a.Di&&a.Di.cancel(),a.ta&&zz(a.ta,!1))};function yz(a,c,d){return function(){zz(a,!1);d&&d(c)}}function xz(a,c){return function(d){zz(a,!0);c.apply(void 0,arguments)}}function zz(a,c){ba._callbacks_[a]&&(c?delete ba._callbacks_[a]:ba._callbacks_[a]=da)};function Az(a,c){var d=/\{z\}/g,e=/\{x\}/g,f=/\{y\}/g,g=/\{-y\}/g;return function(h){if(h)return a.replace(d,h[0].toString()).replace(e,h[1].toString()).replace(f,function(){return(-h[2]-1).toString()}).replace(g,function(){return(qg(c.a?c.a[h[0]]:null)+h[2]).toString()})}}function Bz(a,c){for(var d=a.length,e=Array(d),f=0;f<d;++f)e[f]=Az(a[f],c);return Cz(e)}function Cz(a){return 1===a.length?a[0]:function(c,d,e){if(c)return a[pd((c[1]<<c[0])+c[2],a.length)](c,d,e)}}function Dz(){}
function Ez(a){var c=[],d=/\{(\d)-(\d)\}/.exec(a)||/\{([a-z])-([a-z])\}/.exec(a);if(d){var e=d[2].charCodeAt(0),f;for(f=d[1].charCodeAt(0);f<=e;++f)c.push(a.replace(d[0],String.fromCharCode(f)))}else c.push(a);return c};function Fz(a){Th.call(this,{attributions:a.attributions,extent:a.extent,logo:a.logo,opaque:a.opaque,projection:a.projection,state:void 0!==a.state?a.state:void 0,tileGrid:a.tileGrid,tilePixelRatio:a.tilePixelRatio,wrapX:a.wrapX});this.tileUrlFunction=void 0!==a.tileUrlFunction?a.tileUrlFunction:Dz;this.crossOrigin=void 0!==a.crossOrigin?a.crossOrigin:null;this.tileLoadFunction=void 0!==a.tileLoadFunction?a.tileLoadFunction:Gz;this.tileClass=void 0!==a.tileClass?a.tileClass:Px;this.i={};this.B={};
this.Da=a.reprojectionErrorThreshold;this.T=!1}w(Fz,Th);function Gz(a,c){a.Ma().src=c}l=Fz.prototype;l.Ng=function(){return Bh(this.a)?!0:Jb(this.i,function(a){return Bh(a)})};l.Og=function(a,c){var d=this.Bc(a);Ch(this.a,this.a==d?c:{});Hb(this.i,function(a){Ch(a,a==d?c:{})})};l.Ua=function(a){var c=this.f;return!this.tileGrid||c&&!We(c,a)?(c=v(a).toString(),c in this.B||(this.B[c]=Qh(a)),this.B[c]):this.tileGrid};
l.Bc=function(a){var c=this.f;if(!c||We(c,a))return this.a;a=v(a).toString();a in this.i||(this.i[a]=new Ah);return this.i[a]};l.Xb=function(a,c,d,e,f){if(this.f&&f&&!We(this.f,f)){e=this.Bc(f);var g=this.cb(a,c,d);if(zh(e,g))return e.get(g);var h=this.f,k=this.Ua(h),m=this.Ua(f);a=new lz(h,k,f,m,a,c,d,this.ma,sa(function(a,c,d,e){return Hz(this,a,c,d,e,h)},this),this.Da,this.T);e.set(g,a);return a}return Hz(this,a,c,d,e,f)};
function Hz(a,c,d,e,f,g){var h=a.cb(c,d,e);if(zh(a.a,h))return a.a.get(h);c=[c,d,e];f=(d=Vh(a,c,g))?a.tileUrlFunction(d,f,g):void 0;f=new a.tileClass(c,void 0!==f?0:4,void 0!==f?f:"",a.crossOrigin,a.tileLoadFunction);B(f,"change",a.km,!1,a);a.a.set(h,f);return f}l.eb=function(){return this.tileLoadFunction};l.fb=function(){return this.tileUrlFunction};
l.km=function(a){a=a.target;switch(a.state){case 1:this.u(new Wh("tileloadstart",a));break;case 2:this.u(new Wh("tileloadend",a));break;case 3:this.u(new Wh("tileloaderror",a))}};l.jb=function(a){this.T!=a&&(this.T=a,Hb(this.i,function(a){a.clear()}),this.s())};l.kb=function(a,c){var d=Ee(a);d&&(d=v(d).toString(),d in this.B||(this.B[d]=c))};l.lb=function(a){this.a.clear();this.i={};this.tileLoadFunction=a;this.s()};l.Oa=function(a){this.a.clear();this.i={};this.tileUrlFunction=a;this.s()};
l.Gf=function(a,c,d,e){e=this.Bc(e);a=this.cb(a,c,d);e&&zh(e,a)&&e.get(a)};function Iz(a){Fz.call(this,{crossOrigin:"anonymous",opaque:!0,projection:Ee("EPSG:3857"),reprojectionErrorThreshold:a.reprojectionErrorThreshold,state:"loading",tileLoadFunction:a.tileLoadFunction,wrapX:void 0!==a.wrapX?a.wrapX:!0});this.l=void 0!==a.culture?a.culture:"en-us";this.g=void 0!==a.maxZoom?a.maxZoom:-1;var c=new yt("https://dev.virtualearth.net/REST/v1/Imagery/Metadata/"+a.imagerySet);wz(new uz(c,"jsonp"),{include:"ImageryProviders",uriScheme:"https",key:a.key},sa(this.v,this))}
w(Iz,Fz);var Jz=new tg({html:'<a class="ol-attribution-bing-tos" href="http://www.microsoft.com/maps/product/terms.html">Terms of Use</a>'});
Iz.prototype.v=function(a){if(200!=a.statusCode||"OK"!=a.statusDescription||"ValidCredentials"!=a.authenticationResultCode||1!=a.resourceSets.length||1!=a.resourceSets[0].resources.length)Hh(this,"error");else{var c=a.brandLogoUri;-1==c.indexOf("https")&&(c=c.replace("http","https"));var d=a.resourceSets[0].resources[0],e=-1==this.g?d.zoomMax:this.g;a=kg(this.f);var f=Sh({extent:a,minZoom:d.zoomMin,maxZoom:e,tileSize:d.imageWidth==d.imageHeight?d.imageWidth:[d.imageWidth,d.imageHeight]});this.tileGrid=
f;var g=this.l;this.tileUrlFunction=Cz(d.imageUrlSubdomains.map(function(a){var c=[0,0,0],e=d.imageUrl.replace("{subdomain}",a).replace("{culture}",g);return function(a){if(a)return eg(a[0],a[1],-a[2]-1,c),e.replace("{quadkey}",gg(c))}}));if(d.imageryProviders){var h=Ie(Ee("EPSG:4326"),this.f);a=d.imageryProviders.map(function(a){var c=a.attribution,d={};a.coverageAreas.forEach(function(a){var c=a.zoomMin,g=Math.min(a.zoomMax,e);a=a.bbox;a=qe([a[1],a[0],a[3],a[2]],h);var k,m;for(k=c;k<=g;++k)m=k.toString(),
c=mg(f,a,k),m in d?d[m].push(c):d[m]=[c]});return new tg({html:c,tileRanges:d})});a.push(Jz);this.la(a)}this.ea=c;Hh(this,"ready")}};function Y(a){U.call(this,{attributions:a.attributions,extent:a.extent,logo:a.logo,projection:a.projection});this.H=void 0;this.B=void 0!==a.distance?a.distance:20;this.C=[];this.T=a.source;this.T.G("change",Y.prototype.da,this)}w(Y,U);Y.prototype.ma=function(a){this.B!=a&&(this.B=a,this.da())};Y.prototype.na=function(){return this.B};Y.prototype.ac=function(a,c,d){this.T.ac(a,c,d);c!==this.H&&(this.clear(),this.H=c,Kz(this),this.Tb(this.C))};
Y.prototype.da=function(){Kz(this);this.clear();this.Tb(this.C);this.s()};function Kz(a){if(void 0!==a.H){a.C.length=0;for(var c=Od(),d=a.B*a.H,e=a.T.Gc(),f={},g=0,h=e.length;g<h;g++){var k=e[g];Nb(f,v(k).toString())||(k=k.Y().X(),Zd(k,c),Sd(c,d,c),k=a.T.Id(c),k=k.filter(function(a){a=v(a).toString();return a in f?!1:f[a]=!0}),a.C.push(Lz(k)))}}}function Lz(a){for(var c=a.length,d=[0,0],e=0;e<c;e++){var f=a[e].Y().X();rd(d,f)}c=1/c;d[0]*=c;d[1]*=c;d=new P(new C(d));d.set("features",a);return d};function Mz(a){Dn.call(this,{projection:a.projection,resolutions:a.resolutions});this.da=void 0!==a.crossOrigin?a.crossOrigin:null;this.l=void 0!==a.displayDpi?a.displayDpi:96;this.i=void 0!==a.params?a.params:{};var c;void 0!==a.url?c=Rx(a.url,this.i,sa(this.Rl,this)):c=Sx;this.V=c;this.c=void 0!==a.imageLoadFunction?a.imageLoadFunction:Jn;this.ma=void 0!==a.hidpi?a.hidpi:!0;this.ca=void 0!==a.metersPerUnit?a.metersPerUnit:1;this.H=void 0!==a.ratio?a.ratio:1;this.sa=void 0!==a.useOverlay?a.useOverlay:
!1;this.g=null;this.T=0}w(Mz,Dn);l=Mz.prototype;l.Ql=function(){return this.i};l.dd=function(a,c,d,e){c=En(this,c);d=this.ma?d:1;var f=this.g;if(f&&this.T==this.b&&f.aa()==c&&f.c==d&&Xd(f.J(),a))return f;1!=this.H&&(a=a.slice(),pe(a,this.H));e=this.V(a,[je(a)/c*d,ke(a)/c*d],e);void 0!==e?(f=new Ox(a,c,d,this.j,e,this.da,this.c),B(f,"change",this.B,!1,this)):f=null;this.g=f;this.T=this.b;return f};l.Pl=function(){return this.c};l.Tl=function(a){Xb(this.i,a);this.s()};
l.Rl=function(a,c,d,e){var f=le(d),g=this.ca,h=je(d);d=ke(d);var k=e[0],m=e[1],n=.0254/this.l;e={OPERATION:this.sa?"GETDYNAMICMAPOVERLAYIMAGE":"GETMAPIMAGE",VERSION:"2.0.0",LOCALE:"en",CLIENTAGENT:"ol.source.ImageMapGuide source",CLIP:"1",SETDISPLAYDPI:this.l,SETDISPLAYWIDTH:Math.round(e[0]),SETDISPLAYHEIGHT:Math.round(e[1]),SETVIEWSCALE:m*h>k*d?h*g/(k*n):d*g/(m*n),SETVIEWCENTERX:f[0],SETVIEWCENTERY:f[1]};Xb(e,c);return Do(Fo([a],e))};l.Sl=function(a){this.g=null;this.c=a;this.s()};function Nz(a){var c=void 0!==a.attributions?a.attributions:null,d=a.imageExtent,e,f;void 0!==a.imageSize&&(e=ke(d)/a.imageSize[1],f=[e]);var g=void 0!==a.crossOrigin?a.crossOrigin:null,h=void 0!==a.imageLoadFunction?a.imageLoadFunction:Jn;Dn.call(this,{attributions:c,logo:a.logo,projection:Ee(a.projection),resolutions:f});this.c=new Ox(d,e,1,c,a.url,g,h);B(this.c,"change",this.B,!1,this)}w(Nz,Dn);Nz.prototype.dd=function(a){return oe(a,this.c.J())?this.c:null};function Oz(a){a=a||{};Dn.call(this,{attributions:a.attributions,logo:a.logo,projection:a.projection,resolutions:a.resolutions});this.ma=void 0!==a.crossOrigin?a.crossOrigin:null;this.i=a.url;this.H=void 0!==a.imageLoadFunction?a.imageLoadFunction:Jn;this.g=a.params;this.l=!0;Pz(this);this.da=a.serverType;this.sa=void 0!==a.hidpi?a.hidpi:!0;this.c=null;this.T=[0,0];this.ca=0;this.V=void 0!==a.ratio?a.ratio:1.5}w(Oz,Dn);var Qz=[101,101];l=Oz.prototype;
l.Zl=function(a,c,d,e){if(void 0!==this.i){var f=me(a,c,0,Qz),g={SERVICE:"WMS",VERSION:"1.3.0",REQUEST:"GetFeatureInfo",FORMAT:"image/png",TRANSPARENT:!0,QUERY_LAYERS:this.g.LAYERS};Xb(g,this.g,e);e=Math.floor((f[3]-a[1])/c);g[this.l?"I":"X"]=Math.floor((a[0]-f[0])/c);g[this.l?"J":"Y"]=e;return Rz(this,f,Qz,1,Ee(d),g)}};l.am=function(){return this.g};
l.dd=function(a,c,d,e){if(void 0===this.i)return null;c=En(this,c);1==d||this.sa&&void 0!==this.da||(d=1);a=a.slice();var f=(a[0]+a[2])/2,g=(a[1]+a[3])/2;if(1!=this.V){var h=this.V*je(a)/2,k=this.V*ke(a)/2;a[0]=f-h;a[1]=g-k;a[2]=f+h;a[3]=g+k}var m=c/d,h=Math.ceil(je(a)/m),k=Math.ceil(ke(a)/m);a[0]=f-m*h/2;a[2]=f+m*h/2;a[1]=g-m*k/2;a[3]=g+m*k/2;if((f=this.c)&&this.ca==this.b&&f.aa()==c&&f.c==d&&Xd(f.J(),a))return f;f={SERVICE:"WMS",VERSION:"1.3.0",REQUEST:"GetMap",FORMAT:"image/png",TRANSPARENT:!0};
Xb(f,this.g);this.T[0]=h;this.T[1]=k;e=Rz(this,a,this.T,d,e,f);this.c=new Ox(a,c,d,this.j,e,this.ma,this.H);this.ca=this.b;B(this.c,"change",this.B,!1,this);return this.c};l.$l=function(){return this.H};
function Rz(a,c,d,e,f,g){g[a.l?"CRS":"SRS"]=f.b;"STYLES"in a.g||(g.STYLES=new String(""));if(1!=e)switch(a.da){case "geoserver":e=90*e+.5|0;g.FORMAT_OPTIONS="FORMAT_OPTIONS"in g?g.FORMAT_OPTIONS+(";dpi:"+e):"dpi:"+e;break;case "mapserver":g.MAP_RESOLUTION=90*e;break;case "carmentaserver":case "qgis":g.DPI=90*e}g.WIDTH=d[0];g.HEIGHT=d[1];d=f.g;var h;a.l&&"ne"==d.substr(0,2)?h=[c[1],c[0],c[3],c[2]]:h=c;g.BBOX=h.join(",");return Do(Fo([a.i],g))}l.bm=function(){return this.i};
l.cm=function(a){this.c=null;this.H=a;this.s()};l.dm=function(a){a!=this.i&&(this.i=a,this.c=null,this.s())};l.em=function(a){Xb(this.g,a);Pz(this);this.c=null;this.s()};function Pz(a){a.l=0<=Qa(Sb(a.g,"VERSION","1.3.0"),"1.3")};function Sz(a){var c=void 0!==a.projection?a.projection:"EPSG:3857",d=void 0!==a.tileGrid?a.tileGrid:Sh({extent:kg(c),maxZoom:a.maxZoom,tileSize:a.tileSize});this.v=null;Fz.call(this,{attributions:a.attributions,crossOrigin:a.crossOrigin,logo:a.logo,projection:c,reprojectionErrorThreshold:a.reprojectionErrorThreshold,tileGrid:d,tileLoadFunction:a.tileLoadFunction,tilePixelRatio:a.tilePixelRatio,tileUrlFunction:Dz,wrapX:void 0!==a.wrapX?a.wrapX:!0});void 0!==a.tileUrlFunction?this.Oa(a.tileUrlFunction):
void 0!==a.urls?(a=a.urls,this.Oa(Bz(a,this.tileGrid)),this.v=a):void 0!==a.url&&this.g(a.url)}w(Sz,Fz);Sz.prototype.l=function(){return this.v};Sz.prototype.g=function(a){this.Oa(Bz(Ez(a),this.tileGrid));this.v=[a]};function Tz(a){a=a||{};var c;void 0!==a.attributions?c=a.attributions:c=[Uz];Sz.call(this,{attributions:c,crossOrigin:void 0!==a.crossOrigin?a.crossOrigin:"anonymous",opaque:!0,maxZoom:void 0!==a.maxZoom?a.maxZoom:19,reprojectionErrorThreshold:a.reprojectionErrorThreshold,tileLoadFunction:a.tileLoadFunction,url:void 0!==a.url?a.url:"https://{a-c}.tile.openstreetmap.org/{z}/{x}/{y}.png",wrapX:a.wrapX})}w(Tz,Sz);var Uz=new tg({html:'&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors.'});function Vz(a){a=a||{};var c=Wz[a.layer];this.C=a.layer;Sz.call(this,{attributions:c.attributions,crossOrigin:"anonymous",logo:"https://developer.mapquest.com/content/osm/mq_logo.png",maxZoom:c.maxZoom,reprojectionErrorThreshold:a.reprojectionErrorThreshold,opaque:!0,tileLoadFunction:a.tileLoadFunction,url:void 0!==a.url?a.url:"https://otile{1-4}-s.mqcdn.com/tiles/1.0.0/"+this.C+"/{z}/{x}/{y}.jpg"})}w(Vz,Sz);
var Xz=new tg({html:'Tiles Courtesy of <a href="http://www.mapquest.com/">MapQuest</a>'}),Wz={osm:{maxZoom:19,attributions:[Xz,Uz]},sat:{maxZoom:18,attributions:[Xz,new tg({html:"Portions Courtesy NASA/JPL-Caltech and U.S. Depart. of Agriculture, Farm Service Agency"})]},hyb:{maxZoom:18,attributions:[Xz,Uz]}};Vz.prototype.H=function(){return this.C};(function(){var a={},c={ob:a};(function(d){if("object"===typeof a&&"undefined"!==typeof c)c.ob=d();else{var e;"undefined"!==typeof window?e=window:"undefined"!==typeof global?e=global:"undefined"!==typeof self?e=self:e=this;e.Mo=d()}})(function(){return function e(a,c,h){function k(n,q){if(!c[n]){if(!a[n]){var r="function"==typeof require&&require;if(!q&&r)return r(n,!0);if(m)return m(n,!0);r=Error("Cannot find module '"+n+"'");throw r.code="MODULE_NOT_FOUND",r;}r=c[n]={ob:{}};a[n][0].call(r.ob,function(c){var e=
a[n][1][c];return k(e?e:c)},r,r.ob,e,a,c,h)}return c[n].ob}for(var m="function"==typeof require&&require,n=0;n<h.length;n++)k(h[n]);return k}({1:[function(a,c,g){a=a("./processor");g.bi=a},{"./processor":2}],2:[function(a,c){function g(a){return function(c){var e=c.buffers,f=c.meta,g=c.width,h=c.height,k=e.length,m=e[0].byteLength,z;if(c.imageOps){m=Array(k);for(z=0;z<k;++z)m[z]=new ImageData(new Uint8ClampedArray(e[z]),g,h);g=a(m,f).data}else{g=new Uint8ClampedArray(m);h=Array(k);c=Array(k);for(z=
0;z<k;++z)h[z]=new Uint8ClampedArray(e[z]),c[z]=[0,0,0,0];for(e=0;e<m;e+=4){for(z=0;z<k;++z){var x=h[z];c[z][0]=x[e];c[z][1]=x[e+1];c[z][2]=x[e+2];c[z][3]=x[e+3]}z=a(c,f);g[e]=z[0];g[e+1]=z[1];g[e+2]=z[2];g[e+3]=z[3]}}return g.buffer}}function h(a,c){var e=Object.keys(a.lib||{}).map(function(c){return"var "+c+" = "+a.lib[c].toString()+";"}).concat(["var __minion__ = ("+g.toString()+")(",a.operation.toString(),");",'self.addEventListener("message", function(__event__) {',"var buffer = __minion__(__event__.data);",
"self.postMessage({buffer: buffer, meta: __event__.data.meta}, [buffer]);","});"]),e=URL.createObjectURL(new Blob(e,{type:"text/javascript"})),e=new Worker(e);e.addEventListener("message",c);return e}function k(a,c){var e=g(a.operation);return{postMessage:function(a){setTimeout(function(){c({data:{buffer:e(a),$d:a.$d}})},0)}}}function m(a){this.Ie=!!a.jk;var c;0===a.threads?c=0:this.Ie?c=1:c=a.threads||1;var e=[];if(c)for(var f=0;f<c;++f)e[f]=h(a,this.Qf.bind(this,f));else e[0]=k(a,this.Qf.bind(this,
0));this.zd=e;this.Qc=[];this.ni=a.wn||Infinity;this.yd=0;this.rc={};this.Je=null}m.prototype.vn=function(a,c,e){this.li({$b:a,$d:c,Sc:e});this.Nf()};m.prototype.li=function(a){for(this.Qc.push(a);this.Qc.length>this.ni;)this.Qc.shift().Sc(null,null)};m.prototype.Nf=function(){if(0===this.yd&&0<this.Qc.length){var a=this.Je=this.Qc.shift(),c=a.$b[0].width,e=a.$b[0].height,f=a.$b.map(function(a){return a.data.buffer}),g=this.zd.length;this.yd=g;if(1===g)this.zd[0].postMessage({buffers:f,meta:a.$d,
imageOps:this.Ie,width:c,height:e},f);else for(var h=4*Math.ceil(a.$b[0].data.length/4/g),k=0;k<g;++k){for(var m=k*h,z=[],x=0,M=f.length;x<M;++x)z.push(f[k].slice(m,m+h));this.zd[k].postMessage({buffers:z,meta:a.$d,imageOps:this.Ie,width:c,height:e},z)}}};m.prototype.Qf=function(a,c){this.Ko||(this.rc[a]=c.data,--this.yd,0===this.yd&&this.oi())};m.prototype.oi=function(){var a=this.Je,c=this.zd.length,e,f;if(1===c)e=new Uint8ClampedArray(this.rc[0].buffer),f=this.rc[0].meta;else{var g=a.$b[0].data.length;
e=new Uint8ClampedArray(g);f=Array(g);for(var g=4*Math.ceil(g/4/c),h=0;h<c;++h){var k=h*g;e.set(new Uint8ClampedArray(this.rc[h].buffer),k);f[h]=this.rc[h].meta}}this.Je=null;this.rc={};a.Sc(null,new ImageData(e,a.$b[0].width,a.$b[0].height),f);this.Nf()};c.ob=m},{}]},{},[1])(1)});Op=c.ob})();function Yz(a){this.T=null;this.sa=void 0!==a.operationType?a.operationType:"pixel";this.Da=void 0!==a.threads?a.threads:1;this.c=Zz(a.sources);for(var c=0,d=this.c.length;c<d;++c)B(this.c[c],"change",this.s,!1,this);this.g=Ti();this.da=new Ok(function(){return 1},sa(this.s,this));for(var c=$z(this.c),d={},e=0,f=c.length;e<f;++e)d[v(c[e].layer)]=c[e];this.i=this.l=null;this.ca={animate:!1,attributions:{},coordinateToPixelMatrix:Dd(),extent:null,focus:null,index:0,layerStates:d,layerStatesArray:c,
logos:{},pixelRatio:1,pixelToCoordinateMatrix:Dd(),postRenderFunctions:[],size:[0,0],skippedFeatureUids:{},tileQueue:this.da,time:Date.now(),usedTiles:{},viewState:{rotation:0},viewHints:[],wantedTiles:{}};Dn.call(this,{});void 0!==a.operation&&this.H(a.operation,a.lib)}w(Yz,Dn);Yz.prototype.H=function(a,c){this.T=new Op.bi({operation:a,jk:"image"===this.sa,wn:1,lib:c,threads:this.Da});this.s()};function aA(a,c,d){var e=a.l;return!e||a.b!==e.Vn||d!==e.resolution||!$d(c,e.extent)}
Yz.prototype.v=function(a,c,d,e){d=!0;for(var f,g=0,h=this.c.length;g<h;++g)if(f=this.c[g].a.ga(),"ready"!==f.A){d=!1;break}if(!d)return null;if(!aA(this,a,c))return this.i;d=this.g.canvas;f=Math.round(je(a)/c);g=Math.round(ke(a)/c);if(f!==d.width||g!==d.height)d.width=f,d.height=g;f=Ub(this.ca);f.viewState=Ub(f.viewState);var g=le(a),h=Math.round(je(a)/c),k=Math.round(ke(a)/c);f.extent=a;f.focus=le(a);f.size[0]=h;f.size[1]=k;h=f.viewState;h.center=g;h.projection=e;h.resolution=c;this.i=e=new tn(a,
c,1,this.j,d,this.V.bind(this,f));this.l={extent:a,resolution:c,Vn:this.b};return e};
Yz.prototype.V=function(a,c){for(var d=this.c.length,e=Array(d),f=0;f<d;++f){var g;var h=this.c[f],k=a;h.he(k,a.layerStatesArray[f]);if(g=h.ld()){var h=h.$e(),m=Math.round(h[12]),n=Math.round(h[13]),p=k.size[0],k=k.size[1];if(g instanceof Image){if(bA){var q=bA.canvas;q.width!==p||q.height!==k?bA=Ti(p,k):bA.clearRect(0,0,p,k)}else bA=Ti(p,k);bA.drawImage(g,m,n,Math.round(g.width*h[0]),Math.round(g.height*h[5]));g=bA.getImageData(0,0,p,k)}else g=g.getContext("2d").getImageData(-m,-n,p,k)}else g=null;
if(g)e[f]=g;else return}d={};this.u(new cA(dA,a,d));this.T.vn(e,d,this.ma.bind(this,a,c));Pk(a.tileQueue,16,16)};Yz.prototype.ma=function(a,c,d,e,f){d?c(d):e&&(this.u(new cA(eA,a,f)),aA(this,a.extent,a.viewState.resolution/a.pixelRatio)||this.g.putImageData(e,0,0),c(null))};var bA=null;function $z(a){return a.map(function(a){return fk(a.a)})}
function Zz(a){for(var c=a.length,d=Array(c),e=0;e<c;++e){var f=e,g=a[e],h=null;g instanceof Th?(g=new E({source:g}),h=new eq(g)):g instanceof Dn&&(g=new Wl({source:g}),h=new dq(g));d[f]=h}return d}function cA(a,c,d){vc.call(this,a);this.extent=c.extent;this.resolution=c.viewState.resolution/c.pixelRatio;this.data=d}w(cA,vc);var dA="beforeoperations",eA="afteroperations";var fA={terrain:{ab:"jpg",opaque:!0},"terrain-background":{ab:"jpg",opaque:!0},"terrain-labels":{ab:"png",opaque:!1},"terrain-lines":{ab:"png",opaque:!1},"toner-background":{ab:"png",opaque:!0},toner:{ab:"png",opaque:!0},"toner-hybrid":{ab:"png",opaque:!1},"toner-labels":{ab:"png",opaque:!1},"toner-lines":{ab:"png",opaque:!1},"toner-lite":{ab:"png",opaque:!0},watercolor:{ab:"jpg",opaque:!0}},gA={terrain:{minZoom:4,maxZoom:18},toner:{minZoom:0,maxZoom:20},watercolor:{minZoom:3,maxZoom:16}};
function hA(a){var c=a.layer.indexOf("-"),d=fA[a.layer];Sz.call(this,{attributions:iA,crossOrigin:"anonymous",maxZoom:gA[-1==c?a.layer:a.layer.slice(0,c)].maxZoom,opaque:d.opaque,reprojectionErrorThreshold:a.reprojectionErrorThreshold,tileLoadFunction:a.tileLoadFunction,url:void 0!==a.url?a.url:"https://stamen-tiles-{a-d}.a.ssl.fastly.net/"+a.layer+"/{z}/{x}/{y}."+d.ab})}w(hA,Sz);
var iA=[new tg({html:'Map tiles by <a href="http://stamen.com/">Stamen Design</a>, under <a href="http://creativecommons.org/licenses/by/3.0/">CC BY 3.0</a>.'}),Uz];function jA(a){a=a||{};var c=void 0!==a.params?a.params:{};Fz.call(this,{attributions:a.attributions,crossOrigin:a.crossOrigin,logo:a.logo,projection:a.projection,reprojectionErrorThreshold:a.reprojectionErrorThreshold,tileGrid:a.tileGrid,tileLoadFunction:a.tileLoadFunction,tileUrlFunction:sa(this.im,this),wrapX:void 0!==a.wrapX?a.wrapX:!0});var d=a.urls;void 0===d&&void 0!==a.url&&(d=Ez(a.url));this.l=d||[];this.g=c;this.v=Od()}w(jA,Fz);l=jA.prototype;l.fm=function(){return this.g};
l.Yb=function(a,c,d){a=jA.ba.Yb.call(this,a,c,d);return 1==c?a:nd(a,c,this.c)};l.gm=function(){return this.l};l.hm=function(a){a=void 0!==a?Ez(a):null;this.Lg(a)};l.Lg=function(a){this.l=a||[];this.s()};
l.im=function(a,c,d){var e=this.tileGrid;e||(e=this.Ua(d));if(!(e.b.length<=a[0])){var f=e.xa(a,this.v),g=od(e.Ia(a[0]),this.c);1!=c&&(g=nd(g,c,this.c));e={F:"image",FORMAT:"PNG32",TRANSPARENT:!0};Xb(e,this.g);var h=this.l;0!==h.length?(d=d.b.split(":").pop(),e.SIZE=g[0]+","+g[1],e.BBOX=f.join(","),e.BBOXSR=d,e.IMAGESR=d,e.DPI=Math.round(90*c),a=1==h.length?h[0]:h[pd((a[1]<<a[0])+a[2],h.length)],Aa(a,"/")||(a+="/"),Aa(a,"MapServer/")?a+="export":Aa(a,"ImageServer/")&&(a+="exportImage"),a=Do(Fo([a],
e))):a=void 0;return a}};l.jm=function(a){Xb(this.g,a);this.s()};function kA(a,c,d){Dh.call(this,a,2);this.f=c;this.c=d;this.a={}}w(kA,Dh);kA.prototype.Ma=function(a){a=void 0!==a?v(a):-1;if(a in this.a)return this.a[a];var c=this.f,d=Ti(c[0],c[1]);d.strokeStyle="black";d.strokeRect(.5,.5,c[0]+.5,c[1]+.5);d.fillStyle="black";d.textAlign="center";d.textBaseline="middle";d.font="24px sans-serif";d.fillText(this.c,c[0]/2,c[1]/2);return this.a[a]=d.canvas};
function lA(a){Th.call(this,{opaque:!1,projection:a.projection,tileGrid:a.tileGrid,wrapX:void 0!==a.wrapX?a.wrapX:!0})}w(lA,Th);lA.prototype.Xb=function(a,c,d){var e=this.cb(a,c,d);if(zh(this.a,e))return this.a.get(e);var f=od(this.tileGrid.Ia(a));a=[a,c,d];c=(c=Vh(this,a))?hg(Vh(this,c)):"";f=new kA(a,f,c);this.a.set(e,f);return f};function mA(a){Fz.call(this,{attributions:a.attributions,crossOrigin:a.crossOrigin,projection:Ee("EPSG:3857"),reprojectionErrorThreshold:a.reprojectionErrorThreshold,state:"loading",tileLoadFunction:a.tileLoadFunction,wrapX:void 0!==a.wrapX?a.wrapX:!0});wz(new uz(a.url),void 0,sa(this.l,this),sa(this.g,this))}w(mA,Fz);
mA.prototype.l=function(a){var c=Ee("EPSG:4326"),d=this.f,e;void 0!==a.bounds&&(e=qe(a.bounds,Ie(c,d)));var f=a.minzoom||0,g=a.maxzoom||22;this.tileGrid=d=Sh({extent:kg(d),maxZoom:g,minZoom:f});this.tileUrlFunction=Bz(a.tiles,d);if(void 0!==a.attribution&&!this.j){c=void 0!==e?e:c.J();e={};for(var h;f<=g;++f)h=f.toString(),e[h]=[mg(d,c,f)];this.la([new tg({html:a.attribution,tileRanges:e})])}Hh(this,"ready")};mA.prototype.g=function(){Hh(this,"error")};function nA(a){Th.call(this,{projection:Ee("EPSG:3857"),state:"loading"});this.l=void 0!==a.preemptive?a.preemptive:!0;this.g=Dz;this.i=void 0;wz(new uz(a.url),void 0,sa(this.mm,this))}w(nA,Th);l=nA.prototype;l.vj=function(){return this.i};l.Gi=function(a,c,d,e,f){this.tileGrid?(c=this.tileGrid.fd(a,c),oA(this.Xb(c[0],c[1],c[2],1,this.f),a,d,e,f)):!0===f?ri(function(){d.call(e,null)}):d.call(e,null)};
l.mm=function(a){var c=Ee("EPSG:4326"),d=this.f,e;void 0!==a.bounds&&(e=qe(a.bounds,Ie(c,d)));var f=a.minzoom||0,g=a.maxzoom||22;this.tileGrid=d=Sh({extent:kg(d),maxZoom:g,minZoom:f});this.i=a.template;var h=a.grids;if(h){this.g=Bz(h,d);if(void 0!==a.attribution){c=void 0!==e?e:c.J();for(e={};f<=g;++f)h=f.toString(),e[h]=[mg(d,c,f)];this.la([new tg({html:a.attribution,tileRanges:e})])}Hh(this,"ready")}else Hh(this,"error")};
l.Xb=function(a,c,d,e,f){var g=this.cb(a,c,d);if(zh(this.a,g))return this.a.get(g);a=[a,c,d];c=Vh(this,a,f);e=this.g(c,e,f);e=new pA(a,void 0!==e?0:4,void 0!==e?e:"",this.tileGrid.xa(a),this.l);this.a.set(g,e);return e};l.Gf=function(a,c,d){a=this.cb(a,c,d);zh(this.a,a)&&this.a.get(a)};function pA(a,c,d,e,f){Dh.call(this,a,c);this.i=d;this.a=e;this.j=f;this.g=this.f=this.c=null}w(pA,Dh);l=pA.prototype;l.Ma=function(){return null};
function qA(a,c){if(!a.c||!a.f||!a.g)return null;var d=a.c[Math.floor((1-(c[1]-a.a[1])/(a.a[3]-a.a[1]))*a.c.length)];if(!ia(d))return null;d=d.charCodeAt(Math.floor((c[0]-a.a[0])/(a.a[2]-a.a[0])*d.length));93<=d&&d--;35<=d&&d--;d-=32;return d in a.f?a.g[a.f[d]]:null}function oA(a,c,d,e,f){0==a.state&&!0===f?(Xc(a,"change",function(){d.call(e,qA(this,c))},!1,a),rA(a)):!0===f?ri(function(){d.call(e,qA(this,c))},a):d.call(e,qA(a,c))}l.qb=function(){return this.i};l.Jj=function(){this.state=3;Eh(this)};
l.lm=function(a){this.c=a.grid;this.f=a.keys;this.g=a.data;this.state=4;Eh(this)};function rA(a){0==a.state&&(a.state=1,wz(new uz(a.i),void 0,sa(a.lm,a),sa(a.Jj,a)))}l.load=function(){this.j&&rA(this)};function sA(a){U.call(this,{attributions:a.attributions,logo:a.logo,projection:void 0,state:"ready",wrapX:a.wrapX});this.da=void 0!==a.format?a.format:null;this.B=a.tileGrid;this.H=Dz;this.T=void 0!==a.tileLoadFunction?a.tileLoadFunction:null;this.C={};void 0!==a.tileUrlFunction?(this.H=a.tileUrlFunction,this.s()):void 0!==a.urls?(this.H=Bz(a.urls,this.B),this.s()):void 0!==a.url&&(this.H=Bz(Ez(a.url),this.B),this.s())}w(sA,U);l=sA.prototype;l.clear=function(){Rb(this.C)};
function tA(a,c,d,e){var f=a.C;a=a.B.fd(c,d);f=f[a[0]+"/"+a[1]+"/"+a[2]];if(void 0!==f)for(a=0,d=f.length;a<d;++a){var g=f[a];if(g.Y().Pe(c)&&e.call(void 0,g))break}}l.Fb=function(a,c,d,e){var f=this.B,g=this.C;c=Ph(f,c);a=mg(f,a,c);for(var h,f=a.b;f<=a.f;++f)for(h=a.a;h<=a.c;++h){var k=g[c+"/"+f+"/"+h];if(void 0!==k){var m,n;m=0;for(n=k.length;m<n;++m){var p=d.call(e,k[m]);if(p)return p}}}};l.Gc=function(){var a=this.C,c=[],d;for(d in a)kb(c,a[d]);return c};
l.Ui=function(a,c){var d=[];tA(this,a,c,function(a){d.push(a)});return d};function uA(a,c,d){var e=a.B;a.P&&d.c&&(c=ig(c,e,d));return lg(c,e)?c:null}l.ac=function(a,c,d){function e(a,c){h[a]=c;this.s()}var f=this.B,g=this.H,h=this.C,k=Ph(f,c),f=mg(f,a,k),m=[k,0,0],n,p;for(n=f.b;n<=f.f;++n)for(p=f.a;p<=f.c;++p){var q=k+"/"+n+"/"+p;if(!(q in h)){m[1]=n;m[2]=p;var r=uA(this,m,d),r=r?g(r,1,d):void 0;void 0!==r&&(h[q]=[],q=ta(e,q),this.T?this.T(r,sa(q,this)):Kp(r,this.da,q).call(this,a,c,d))}}};function vA(a){a=a||{};var c=void 0!==a.params?a.params:{};Fz.call(this,{attributions:a.attributions,crossOrigin:a.crossOrigin,logo:a.logo,opaque:!Sb(c,"TRANSPARENT",!0),projection:a.projection,reprojectionErrorThreshold:a.reprojectionErrorThreshold,tileGrid:a.tileGrid,tileLoadFunction:a.tileLoadFunction,tileUrlFunction:sa(this.rm,this),wrapX:void 0!==a.wrapX?a.wrapX:!0});var d=a.urls;void 0===d&&void 0!==a.url&&(d=Ez(a.url));this.l=d||[];this.C=void 0!==a.gutter?a.gutter:0;this.g=c;this.v=!0;this.H=
a.serverType;this.ca=void 0!==a.hidpi?a.hidpi:!0;this.V="";wA(this);this.da=Od();xA(this)}w(vA,Fz);l=vA.prototype;
l.nm=function(a,c,d,e){d=Ee(d);var f=this.tileGrid;f||(f=this.Ua(d));c=f.fd(a,c);if(!(f.b.length<=c[0])){var g=f.aa(c[0]),h=f.xa(c,this.da),f=od(f.Ia(c[0]),this.c),k=this.C;0!==k&&(f=md(f,k,this.c),h=Sd(h,g*k,h));k={SERVICE:"WMS",VERSION:"1.3.0",REQUEST:"GetFeatureInfo",FORMAT:"image/png",TRANSPARENT:!0,QUERY_LAYERS:this.g.LAYERS};Xb(k,this.g,e);e=Math.floor((h[3]-a[1])/g);k[this.v?"I":"X"]=Math.floor((a[0]-h[0])/g);k[this.v?"J":"Y"]=e;return yA(this,c,f,h,1,d,k)}};l.Jd=function(){return this.C};
l.cb=function(a,c,d){return this.V+vA.ba.cb.call(this,a,c,d)};l.om=function(){return this.g};
function yA(a,c,d,e,f,g,h){var k=a.l;if(0!==k.length){h.WIDTH=d[0];h.HEIGHT=d[1];h[a.v?"CRS":"SRS"]=g.b;"STYLES"in a.g||(h.STYLES=new String(""));if(1!=f)switch(a.H){case "geoserver":d=90*f+.5|0;h.FORMAT_OPTIONS="FORMAT_OPTIONS"in h?h.FORMAT_OPTIONS+(";dpi:"+d):"dpi:"+d;break;case "mapserver":h.MAP_RESOLUTION=90*f;break;case "carmentaserver":case "qgis":h.DPI=90*f}g=g.g;a.v&&"ne"==g.substr(0,2)&&(a=e[0],e[0]=e[1],e[1]=a,a=e[2],e[2]=e[3],e[3]=a);h.BBOX=e.join(",");return Do(Fo([1==k.length?k[0]:k[pd((c[1]<<
c[0])+c[2],k.length)]],h))}}l.Yb=function(a,c,d){a=vA.ba.Yb.call(this,a,c,d);return 1!=c&&this.ca&&void 0!==this.H?nd(a,c,this.c):a};l.pm=function(){return this.l};function wA(a){var c=0,d=[],e,f;e=0;for(f=a.l.length;e<f;++e)d[c++]=a.l[e];for(var g in a.g)d[c++]=g+"-"+a.g[g];a.V=d.join("#")}l.qm=function(a){a=void 0!==a?Ez(a):null;this.Mg(a)};l.Mg=function(a){this.l=a||[];wA(this);this.s()};
l.rm=function(a,c,d){var e=this.tileGrid;e||(e=this.Ua(d));if(!(e.b.length<=a[0])){1==c||this.ca&&void 0!==this.H||(c=1);var f=e.aa(a[0]),g=e.xa(a,this.da),e=od(e.Ia(a[0]),this.c),h=this.C;0!==h&&(e=md(e,h,this.c),g=Sd(g,f*h,g));1!=c&&(e=nd(e,c,this.c));f={SERVICE:"WMS",VERSION:"1.3.0",REQUEST:"GetMap",FORMAT:"image/png",TRANSPARENT:!0};Xb(f,this.g);return yA(this,a,e,g,c,d,f)}};l.sm=function(a){Xb(this.g,a);wA(this);xA(this);this.s()};function xA(a){a.v=0<=Qa(Sb(a.g,"VERSION","1.3.0"),"1.3")};function zA(a){this.j=a.matrixIds;Ih.call(this,{extent:a.extent,origin:a.origin,origins:a.origins,resolutions:a.resolutions,tileSize:a.tileSize,tileSizes:a.tileSizes,sizes:a.sizes})}w(zA,Ih);zA.prototype.D=function(){return this.j};
function AA(a,c){var d=[],e=[],f=[],g=[],h=[],k;k=Ee(a.SupportedCRS.replace(/urn:ogc:def:crs:(\w+):(.*:)?(\w+)$/,"$1:$3"));var m=k.yc(),n="ne"==k.g.substr(0,2);nb(a.TileMatrix,function(a,c){return c.ScaleDenominator-a.ScaleDenominator});a.TileMatrix.forEach(function(a){e.push(a.Identifier);var c=2.8E-4*a.ScaleDenominator/m,k=a.TileWidth,t=a.TileHeight;n?f.push([a.TopLeftCorner[1],a.TopLeftCorner[0]]):f.push(a.TopLeftCorner);d.push(c);g.push(k==t?k:[k,t]);h.push([a.MatrixWidth,-a.MatrixHeight])});
return new zA({extent:c,origins:f,resolutions:d,matrixIds:e,tileSizes:g,sizes:h})};function Z(a){function c(a){a="KVP"==e?Do(Fo([a],g)):a.replace(/\{(\w+?)\}/g,function(a,c){return c.toLowerCase()in g?g[c.toLowerCase()]:a});return function(c){if(c){var d={TileMatrix:f.j[c[0]],TileCol:c[1],TileRow:-c[2]-1};Xb(d,h);c=a;return c="KVP"==e?Do(Fo([c],d)):c.replace(/\{(\w+?)\}/g,function(a,c){return d[c]})}}}this.da=void 0!==a.version?a.version:"1.0.0";this.H=void 0!==a.format?a.format:"image/jpeg";this.g=void 0!==a.dimensions?a.dimensions:{};this.C="";BA(this);this.V=a.layer;this.v=a.matrixSet;
this.ca=a.style;var d=a.urls;void 0===d&&void 0!==a.url&&(d=Ez(a.url));this.l=d||[];var e=this.na=void 0!==a.requestEncoding?a.requestEncoding:"KVP",f=a.tileGrid,g={layer:this.V,style:this.ca,tilematrixset:this.v};"KVP"==e&&Xb(g,{Service:"WMTS",Request:"GetTile",Version:this.da,Format:this.H});var h=this.g,d=0<this.l.length?Cz(this.l.map(c)):Dz;Fz.call(this,{attributions:a.attributions,crossOrigin:a.crossOrigin,logo:a.logo,projection:a.projection,reprojectionErrorThreshold:a.reprojectionErrorThreshold,
tileClass:a.tileClass,tileGrid:f,tileLoadFunction:a.tileLoadFunction,tilePixelRatio:a.tilePixelRatio,tileUrlFunction:d,wrapX:void 0!==a.wrapX?a.wrapX:!1})}w(Z,Fz);l=Z.prototype;l.Si=function(){return this.g};l.Wi=function(){return this.H};l.cb=function(a,c,d){return this.C+Z.ba.cb.call(this,a,c,d)};l.tm=function(){return this.V};l.gj=function(){return this.v};l.tj=function(){return this.na};l.um=function(){return this.ca};l.vm=function(){return this.l};l.zj=function(){return this.da};
function BA(a){var c=0,d=[],e;for(e in a.g)d[c++]=e+"-"+a.g[e];a.C=d.join("/")}l.to=function(a){Xb(this.g,a);BA(this);this.s()};function CA(a){a=a||{};var c=a.size,d=c[0],e=c[1],f=[],g=256;switch(void 0!==a.tierSizeCalculation?a.tierSizeCalculation:"default"){case "default":for(;d>g||e>g;)f.push([Math.ceil(d/g),Math.ceil(e/g)]),g+=g;break;case "truncated":for(;d>g||e>g;)f.push([Math.ceil(d/g),Math.ceil(e/g)]),d>>=1,e>>=1}f.push([1,1]);f.reverse();for(var g=[1],h=[0],e=1,d=f.length;e<d;e++)g.push(1<<e),h.push(f[e-1][0]*f[e-1][1]+h[e-1]);g.reverse();var c=[0,-c[1],c[0],0],c=new Ih({extent:c,origin:ge(c),resolutions:g}),k=a.url;
Fz.call(this,{attributions:a.attributions,crossOrigin:a.crossOrigin,logo:a.logo,reprojectionErrorThreshold:a.reprojectionErrorThreshold,tileClass:DA,tileGrid:c,tileUrlFunction:function(a){if(a){var c=a[0],d=a[1];a=-a[2]-1;return k+"TileGroup"+((d+a*f[c][0]+h[c])/256|0)+"/"+c+"-"+d+"-"+a+".jpg"}}})}w(CA,Fz);function DA(a,c,d,e,f){Px.call(this,a,c,d,e,f);this.f={}}w(DA,Px);
DA.prototype.Ma=function(a){var c=void 0!==a?v(a).toString():"";if(c in this.f)return this.f[c];a=DA.ba.Ma.call(this,a);if(2==this.state){if(256==a.width&&256==a.height)return this.f[c]=a;var d=Ti(256,256);d.drawImage(a,0,0);return this.f[c]=d.canvas}return a};function EA(a){a=a||{};this.a=void 0!==a.initialSize?a.initialSize:256;this.c=void 0!==a.maxSize?a.maxSize:void 0!==va?va:2048;this.b=void 0!==a.space?a.space:1;this.g=[new FA(this.a,this.b)];this.f=this.a;this.i=[new FA(this.f,this.b)]}EA.prototype.add=function(a,c,d,e,f,g){if(c+this.b>this.c||d+this.b>this.c)return null;e=GA(this,!1,a,c,d,e,g);if(!e)return null;a=GA(this,!0,a,c,d,void 0!==f?f:ue,g);return{offsetX:e.offsetX,offsetY:e.offsetY,image:e.image,mg:a.image}};
function GA(a,c,d,e,f,g,h){var k=c?a.i:a.g,m,n,p;n=0;for(p=k.length;n<p;++n){m=k[n];if(m=m.add(d,e,f,g,h))return m;m||n!==p-1||(c?(m=Math.min(2*a.f,a.c),a.f=m):(m=Math.min(2*a.a,a.c),a.a=m),m=new FA(m,a.b),k.push(m),++p)}}function FA(a,c){this.b=c;this.a=[{x:0,y:0,width:a,height:a}];this.f={};this.c=Rg("CANVAS");this.c.width=a;this.c.height=a;this.g=this.c.getContext("2d")}FA.prototype.get=function(a){return Sb(this.f,a,null)};
FA.prototype.add=function(a,c,d,e,f){var g,h,k;h=0;for(k=this.a.length;h<k;++h)if(g=this.a[h],g.width>=c+this.b&&g.height>=d+this.b)return k={offsetX:g.x+this.b,offsetY:g.y+this.b,image:this.c},this.f[a]=k,e.call(f,this.g,g.x+this.b,g.y+this.b),a=h,c=c+this.b,d=d+this.b,f=e=void 0,g.width-c>g.height-d?(e={x:g.x+c,y:g.y,width:g.width-c,height:g.height},f={x:g.x,y:g.y+d,width:c,height:g.height-d},HA(this,a,e,f)):(e={x:g.x+c,y:g.y,width:g.width-c,height:d},f={x:g.x,y:g.y+d,width:g.width,height:g.height-
d},HA(this,a,e,f)),k;return null};function HA(a,c,d,e){c=[c,1];0<d.width&&0<d.height&&c.push(d);0<e.width&&0<e.height&&c.push(e);a.a.splice.apply(a.a,c)};function IA(a){this.B=this.f=this.g=null;this.l=void 0!==a.fill?a.fill:null;this.H=[0,0];this.b=a.points;this.c=void 0!==a.radius?a.radius:a.radius1;this.i=void 0!==a.radius2?a.radius2:this.c;this.j=void 0!==a.angle?a.angle:0;this.a=void 0!==a.stroke?a.stroke:null;this.ka=this.T=this.fa=null;var c=a.atlasManager,d="",e="",f=0,g=null,h,k=0;this.a&&(h=Cg(this.a.b),k=this.a.a,void 0===k&&(k=1),g=this.a.c,bj||(g=null),e=this.a.g,void 0===e&&(e="round"),d=this.a.f,void 0===d&&(d="round"),f=this.a.i,void 0===
f&&(f=10));var m=2*(this.c+k)+1,d={strokeStyle:h,rd:k,size:m,lineCap:d,lineDash:g,lineJoin:e,miterLimit:f};if(void 0===c){this.f=Rg("CANVAS");this.f.height=m;this.f.width=m;var c=m=this.f.width,n=this.f.getContext("2d");this.Tg(d,n,0,0);this.l?this.B=this.f:(n=this.B=Rg("CANVAS"),n.height=d.size,n.width=d.size,n=n.getContext("2d"),this.Sg(d,n,0,0))}else m=Math.round(m),(e=!this.l)&&(n=sa(this.Sg,this,d)),f=this.xb(),n=c.add(f,m,m,sa(this.Tg,this,d),n),this.f=n.image,this.H=[n.offsetX,n.offsetY],c=
n.image.width,this.B=e?n.mg:this.f;this.fa=[m/2,m/2];this.T=[m,m];this.ka=[c,c];zk.call(this,{opacity:1,rotateWithView:!1,rotation:void 0!==a.rotation?a.rotation:0,scale:1,snapToPixel:void 0!==a.snapToPixel?a.snapToPixel:!0})}w(IA,zk);l=IA.prototype;l.Gb=function(){return this.fa};l.Am=function(){return this.j};l.Bm=function(){return this.l};l.je=function(){return this.B};l.Pb=function(){return this.f};l.Kd=function(){return this.ka};l.md=function(){return 2};l.wa=function(){return this.H};l.Cm=function(){return this.b};
l.Dm=function(){return this.c};l.sj=function(){return this.i};l.rb=function(){return this.T};l.Em=function(){return this.a};l.ff=xa;l.load=xa;l.Ff=xa;
l.Tg=function(a,c,d,e){var f;c.setTransform(1,0,0,1,0,0);c.translate(d,e);c.beginPath();this.i!==this.c&&(this.b*=2);for(d=0;d<=this.b;d++)e=2*d*Math.PI/this.b-Math.PI/2+this.j,f=0===d%2?this.c:this.i,c.lineTo(a.size/2+f*Math.cos(e),a.size/2+f*Math.sin(e));this.l&&(c.fillStyle=Cg(this.l.b),c.fill());this.a&&(c.strokeStyle=a.strokeStyle,c.lineWidth=a.rd,a.lineDash&&c.setLineDash(a.lineDash),c.lineCap=a.lineCap,c.lineJoin=a.lineJoin,c.miterLimit=a.miterLimit,c.stroke());c.closePath()};
l.Sg=function(a,c,d,e){c.setTransform(1,0,0,1,0,0);c.translate(d,e);c.beginPath();this.i!==this.c&&(this.b*=2);var f;for(d=0;d<=this.b;d++)f=2*d*Math.PI/this.b-Math.PI/2+this.j,e=0===d%2?this.c:this.i,c.lineTo(a.size/2+e*Math.cos(f),a.size/2+e*Math.sin(f));c.fillStyle=Xl;c.fill();this.a&&(c.strokeStyle=a.strokeStyle,c.lineWidth=a.rd,a.lineDash&&c.setLineDash(a.lineDash),c.stroke());c.closePath()};
l.xb=function(){var a=this.a?this.a.xb():"-",c=this.l?this.l.xb():"-";this.g&&a==this.g[1]&&c==this.g[2]&&this.c==this.g[3]&&this.i==this.g[4]&&this.j==this.g[5]&&this.b==this.g[6]||(this.g=["r"+a+c+(void 0!==this.c?this.c.toString():"-")+(void 0!==this.i?this.i.toString():"-")+(void 0!==this.j?this.j.toString():"-")+(void 0!==this.b?this.b.toString():"-"),a,c,this.c,this.i,this.j,this.b]);return this.g[0]};u("ol.animation.bounce",function(a){var c=a.resolution,d=a.start?a.start:Date.now(),e=void 0!==a.duration?a.duration:1E3,f=a.easing?a.easing:ag;return function(a,h){if(h.time<d)return h.animate=!0,h.viewHints[0]+=1,!0;if(h.time<d+e){var k=f((h.time-d)/e),m=c-h.viewState.resolution;h.animate=!0;h.viewState.resolution+=k*m;h.viewHints[0]+=1;return!0}return!1}},OPENLAYERS);u("ol.animation.pan",bg,OPENLAYERS);u("ol.animation.rotate",cg,OPENLAYERS);u("ol.animation.zoom",dg,OPENLAYERS);
u("ol.Attribution",tg,OPENLAYERS);tg.prototype.getHTML=tg.prototype.c;ug.prototype.element=ug.prototype.element;u("ol.Collection",vg,OPENLAYERS);vg.prototype.clear=vg.prototype.clear;vg.prototype.extend=vg.prototype.gf;vg.prototype.forEach=vg.prototype.forEach;vg.prototype.getArray=vg.prototype.Ek;vg.prototype.item=vg.prototype.item;vg.prototype.getLength=vg.prototype.Mb;vg.prototype.insertAt=vg.prototype.Vd;vg.prototype.pop=vg.prototype.pop;vg.prototype.push=vg.prototype.push;
vg.prototype.remove=vg.prototype.remove;vg.prototype.removeAt=vg.prototype.Bf;vg.prototype.setAt=vg.prototype.Xn;u("ol.coordinate.add",rd,OPENLAYERS);u("ol.coordinate.createStringXY",function(a){return function(c){return zd(c,a)}},OPENLAYERS);u("ol.coordinate.format",ud,OPENLAYERS);u("ol.coordinate.rotate",wd,OPENLAYERS);u("ol.coordinate.toStringHDMS",function(a){return a?td(a[1],"NS")+" "+td(a[0],"EW"):""},OPENLAYERS);u("ol.coordinate.toStringXY",zd,OPENLAYERS);u("ol.DeviceOrientation",Tr,OPENLAYERS);
Tr.prototype.getAlpha=Tr.prototype.Mi;Tr.prototype.getBeta=Tr.prototype.Pi;Tr.prototype.getGamma=Tr.prototype.Xi;Tr.prototype.getHeading=Tr.prototype.Fk;Tr.prototype.getTracking=Tr.prototype.sg;Tr.prototype.setTracking=Tr.prototype.hf;u("ol.easing.easeIn",Xf,OPENLAYERS);u("ol.easing.easeOut",Yf,OPENLAYERS);u("ol.easing.inAndOut",Zf,OPENLAYERS);u("ol.easing.linear",$f,OPENLAYERS);u("ol.easing.upAndDown",ag,OPENLAYERS);u("ol.extent.boundingExtent",Nd,OPENLAYERS);u("ol.extent.buffer",Sd,OPENLAYERS);
u("ol.extent.containsCoordinate",Vd,OPENLAYERS);u("ol.extent.containsExtent",Xd,OPENLAYERS);u("ol.extent.containsXY",Wd,OPENLAYERS);u("ol.extent.createEmpty",Od,OPENLAYERS);u("ol.extent.equals",$d,OPENLAYERS);u("ol.extent.extend",ae,OPENLAYERS);u("ol.extent.getBottomLeft",de,OPENLAYERS);u("ol.extent.getBottomRight",ee,OPENLAYERS);u("ol.extent.getCenter",le,OPENLAYERS);u("ol.extent.getHeight",ke,OPENLAYERS);u("ol.extent.getIntersection",ne,OPENLAYERS);
u("ol.extent.getSize",function(a){return[a[2]-a[0],a[3]-a[1]]},OPENLAYERS);u("ol.extent.getTopLeft",ge,OPENLAYERS);u("ol.extent.getTopRight",fe,OPENLAYERS);u("ol.extent.getWidth",je,OPENLAYERS);u("ol.extent.intersects",oe,OPENLAYERS);u("ol.extent.isEmpty",ie,OPENLAYERS);u("ol.extent.applyTransform",qe,OPENLAYERS);u("ol.Feature",P,OPENLAYERS);P.prototype.clone=P.prototype.clone;P.prototype.getGeometry=P.prototype.Y;P.prototype.getId=P.prototype.Fa;P.prototype.getGeometryName=P.prototype.Zi;
P.prototype.getStyle=P.prototype.Hk;P.prototype.getStyleFunction=P.prototype.Ik;P.prototype.setGeometry=P.prototype.Ca;P.prototype.setStyle=P.prototype.jf;P.prototype.setId=P.prototype.Sb;P.prototype.setGeometryName=P.prototype.Kc;u("ol.featureloader.xhr",Lp,OPENLAYERS);u("ol.Geolocation",Fx,OPENLAYERS);Fx.prototype.getAccuracy=Fx.prototype.Ki;Fx.prototype.getAccuracyGeometry=Fx.prototype.Li;Fx.prototype.getAltitude=Fx.prototype.Ni;Fx.prototype.getAltitudeAccuracy=Fx.prototype.Oi;
Fx.prototype.getHeading=Fx.prototype.Kk;Fx.prototype.getPosition=Fx.prototype.Lk;Fx.prototype.getProjection=Fx.prototype.tg;Fx.prototype.getSpeed=Fx.prototype.uj;Fx.prototype.getTracking=Fx.prototype.ug;Fx.prototype.getTrackingOptions=Fx.prototype.gg;Fx.prototype.setProjection=Fx.prototype.vg;Fx.prototype.setTracking=Fx.prototype.ae;Fx.prototype.setTrackingOptions=Fx.prototype.xh;u("ol.Graticule",Jx,OPENLAYERS);Jx.prototype.getMap=Jx.prototype.Ok;Jx.prototype.getMeridians=Jx.prototype.hj;
Jx.prototype.getParallels=Jx.prototype.oj;Jx.prototype.setMap=Jx.prototype.setMap;u("ol.has.DEVICE_PIXEL_RATIO",aj,OPENLAYERS);u("ol.has.CANVAS",cj,OPENLAYERS);u("ol.has.DEVICE_ORIENTATION",dj,OPENLAYERS);u("ol.has.GEOLOCATION",ej,OPENLAYERS);u("ol.has.TOUCH",fj,OPENLAYERS);u("ol.has.WEBGL",$i,OPENLAYERS);Ox.prototype.getImage=Ox.prototype.b;Px.prototype.getImage=Px.prototype.Ma;u("ol.Kinetic",Qk,OPENLAYERS);u("ol.loadingstrategy.all",Mp,OPENLAYERS);
u("ol.loadingstrategy.bbox",function(a){return[a]},OPENLAYERS);u("ol.loadingstrategy.tile",function(a){return function(c,d){var e=Ph(a,d),f=mg(a,c,e),g=[],e=[e,0,0];for(e[1]=f.b;e[1]<=f.f;++e[1])for(e[2]=f.a;e[2]<=f.c;++e[2])g.push(a.xa(e));return g}},OPENLAYERS);u("ol.Map",V,OPENLAYERS);V.prototype.addControl=V.prototype.si;V.prototype.addInteraction=V.prototype.ti;V.prototype.addLayer=V.prototype.Sf;V.prototype.addOverlay=V.prototype.Tf;V.prototype.beforeRender=V.prototype.Ea;
V.prototype.forEachFeatureAtPixel=V.prototype.cd;V.prototype.forEachLayerAtPixel=V.prototype.Sk;V.prototype.hasFeatureAtPixel=V.prototype.ik;V.prototype.getEventCoordinate=V.prototype.Ti;V.prototype.getEventPixel=V.prototype.Hd;V.prototype.getTarget=V.prototype.kf;V.prototype.getTargetElement=V.prototype.Ac;V.prototype.getCoordinateFromPixel=V.prototype.Aa;V.prototype.getControls=V.prototype.Ri;V.prototype.getOverlays=V.prototype.mj;V.prototype.getOverlayById=V.prototype.lj;
V.prototype.getInteractions=V.prototype.$i;V.prototype.getLayerGroup=V.prototype.Wb;V.prototype.getLayers=V.prototype.wg;V.prototype.getPixelFromCoordinate=V.prototype.Ga;V.prototype.getSize=V.prototype.La;V.prototype.getView=V.prototype.$;V.prototype.getViewport=V.prototype.Aj;V.prototype.renderSync=V.prototype.Tn;V.prototype.render=V.prototype.render;V.prototype.removeControl=V.prototype.Mn;V.prototype.removeInteraction=V.prototype.Nn;V.prototype.removeLayer=V.prototype.Pn;
V.prototype.removeOverlay=V.prototype.Qn;V.prototype.setLayerGroup=V.prototype.th;V.prototype.setSize=V.prototype.Df;V.prototype.setTarget=V.prototype.Uk;V.prototype.setView=V.prototype.ko;V.prototype.updateSize=V.prototype.Mc;Qj.prototype.originalEvent=Qj.prototype.originalEvent;Qj.prototype.pixel=Qj.prototype.pixel;Qj.prototype.coordinate=Qj.prototype.coordinate;Qj.prototype.dragging=Qj.prototype.dragging;Qj.prototype.preventDefault=Qj.prototype.preventDefault;Qj.prototype.stopPropagation=Qj.prototype.c;
wh.prototype.map=wh.prototype.map;wh.prototype.frameState=wh.prototype.frameState;hd.prototype.key=hd.prototype.key;hd.prototype.oldValue=hd.prototype.oldValue;u("ol.Object",id,OPENLAYERS);id.prototype.get=id.prototype.get;id.prototype.getKeys=id.prototype.R;id.prototype.getProperties=id.prototype.S;id.prototype.set=id.prototype.set;id.prototype.setProperties=id.prototype.K;id.prototype.unset=id.prototype.U;u("ol.Observable",fd,OPENLAYERS);u("ol.Observable.unByKey",gd,OPENLAYERS);
fd.prototype.changed=fd.prototype.s;fd.prototype.dispatchEvent=fd.prototype.u;fd.prototype.getRevision=fd.prototype.M;fd.prototype.on=fd.prototype.G;fd.prototype.once=fd.prototype.N;fd.prototype.un=fd.prototype.L;fd.prototype.unByKey=fd.prototype.O;u("ol.inherits",w,OPENLAYERS);u("ol.Overlay",qr,OPENLAYERS);qr.prototype.getElement=qr.prototype.be;qr.prototype.getId=qr.prototype.Fa;qr.prototype.getMap=qr.prototype.ce;qr.prototype.getOffset=qr.prototype.eg;qr.prototype.getPosition=qr.prototype.xg;
qr.prototype.getPositioning=qr.prototype.fg;qr.prototype.setElement=qr.prototype.qh;qr.prototype.setMap=qr.prototype.setMap;qr.prototype.setOffset=qr.prototype.vh;qr.prototype.setPosition=qr.prototype.lf;qr.prototype.setPositioning=qr.prototype.wh;u("ol.size.toSize",od,OPENLAYERS);Dh.prototype.getTileCoord=Dh.prototype.D;u("ol.View",Qf,OPENLAYERS);Qf.prototype.constrainCenter=Qf.prototype.Dd;Qf.prototype.constrainResolution=Qf.prototype.constrainResolution;Qf.prototype.constrainRotation=Qf.prototype.constrainRotation;
Qf.prototype.getCenter=Qf.prototype.Na;Qf.prototype.calculateExtent=Qf.prototype.Rc;Qf.prototype.getProjection=Qf.prototype.Vk;Qf.prototype.getResolution=Qf.prototype.aa;Qf.prototype.getRotation=Qf.prototype.za;Qf.prototype.getZoom=Qf.prototype.Cj;Qf.prototype.fit=Qf.prototype.Se;Qf.prototype.centerOn=Qf.prototype.Bi;Qf.prototype.rotate=Qf.prototype.rotate;Qf.prototype.setCenter=Qf.prototype.Wa;Qf.prototype.setResolution=Qf.prototype.Cb;Qf.prototype.setRotation=Qf.prototype.de;
Qf.prototype.setZoom=Qf.prototype.no;u("ol.xml.getAllTextContent",ep,OPENLAYERS);u("ol.xml.parse",yp,OPENLAYERS);xq.prototype.getGL=xq.prototype.Xm;xq.prototype.useProgram=xq.prototype.qe;u("ol.tilegrid.TileGrid",Ih,OPENLAYERS);Ih.prototype.getMaxZoom=Ih.prototype.cg;Ih.prototype.getMinZoom=Ih.prototype.dg;Ih.prototype.getOrigin=Ih.prototype.wa;Ih.prototype.getResolution=Ih.prototype.aa;Ih.prototype.getResolutions=Ih.prototype.Vg;Ih.prototype.getTileCoordExtent=Ih.prototype.xa;
Ih.prototype.getTileCoordForCoordAndResolution=Ih.prototype.fd;Ih.prototype.getTileCoordForCoordAndZ=Ih.prototype.Qd;Ih.prototype.getTileSize=Ih.prototype.Ia;u("ol.tilegrid.createXYZ",Sh,OPENLAYERS);u("ol.tilegrid.WMTS",zA,OPENLAYERS);zA.prototype.getMatrixIds=zA.prototype.D;u("ol.tilegrid.WMTS.createFromCapabilitiesMatrixSet",AA,OPENLAYERS);u("ol.style.AtlasManager",EA,OPENLAYERS);u("ol.style.Circle",fm,OPENLAYERS);fm.prototype.getFill=fm.prototype.wm;fm.prototype.getImage=fm.prototype.Pb;
fm.prototype.getRadius=fm.prototype.xm;fm.prototype.getStroke=fm.prototype.ym;u("ol.style.Fill",$l,OPENLAYERS);$l.prototype.getColor=$l.prototype.c;$l.prototype.setColor=$l.prototype.f;u("ol.style.Icon",Ak,OPENLAYERS);Ak.prototype.getAnchor=Ak.prototype.Gb;Ak.prototype.getImage=Ak.prototype.Pb;Ak.prototype.getOrigin=Ak.prototype.wa;Ak.prototype.getSrc=Ak.prototype.zm;Ak.prototype.getSize=Ak.prototype.rb;Ak.prototype.load=Ak.prototype.load;u("ol.style.Image",zk,OPENLAYERS);
zk.prototype.getOpacity=zk.prototype.ke;zk.prototype.getRotateWithView=zk.prototype.Nd;zk.prototype.getRotation=zk.prototype.le;zk.prototype.getScale=zk.prototype.me;zk.prototype.getSnapToPixel=zk.prototype.Pd;zk.prototype.setOpacity=zk.prototype.ne;zk.prototype.setRotation=zk.prototype.oe;zk.prototype.setScale=zk.prototype.pe;u("ol.style.RegularShape",IA,OPENLAYERS);IA.prototype.getAnchor=IA.prototype.Gb;IA.prototype.getAngle=IA.prototype.Am;IA.prototype.getFill=IA.prototype.Bm;
IA.prototype.getImage=IA.prototype.Pb;IA.prototype.getOrigin=IA.prototype.wa;IA.prototype.getPoints=IA.prototype.Cm;IA.prototype.getRadius=IA.prototype.Dm;IA.prototype.getRadius2=IA.prototype.sj;IA.prototype.getSize=IA.prototype.rb;IA.prototype.getStroke=IA.prototype.Em;u("ol.style.Stroke",em,OPENLAYERS);em.prototype.getColor=em.prototype.Fm;em.prototype.getLineCap=em.prototype.cj;em.prototype.getLineDash=em.prototype.Gm;em.prototype.getLineJoin=em.prototype.dj;em.prototype.getMiterLimit=em.prototype.ij;
em.prototype.getWidth=em.prototype.Hm;em.prototype.setColor=em.prototype.Im;em.prototype.setLineCap=em.prototype.bo;em.prototype.setLineDash=em.prototype.Jm;em.prototype.setLineJoin=em.prototype.co;em.prototype.setMiterLimit=em.prototype.eo;em.prototype.setWidth=em.prototype.lo;u("ol.style.Style",gm,OPENLAYERS);gm.prototype.getGeometry=gm.prototype.Y;gm.prototype.getGeometryFunction=gm.prototype.Yi;gm.prototype.getFill=gm.prototype.Km;gm.prototype.getImage=gm.prototype.Lm;gm.prototype.getStroke=gm.prototype.Mm;
gm.prototype.getText=gm.prototype.Nm;gm.prototype.getZIndex=gm.prototype.Om;gm.prototype.setGeometry=gm.prototype.Ug;gm.prototype.setZIndex=gm.prototype.Pm;u("ol.style.Text",St,OPENLAYERS);St.prototype.getFont=St.prototype.Vi;St.prototype.getOffsetX=St.prototype.jj;St.prototype.getOffsetY=St.prototype.kj;St.prototype.getFill=St.prototype.Qm;St.prototype.getRotation=St.prototype.Rm;St.prototype.getScale=St.prototype.Sm;St.prototype.getStroke=St.prototype.Tm;St.prototype.getText=St.prototype.Um;
St.prototype.getTextAlign=St.prototype.wj;St.prototype.getTextBaseline=St.prototype.xj;St.prototype.setFont=St.prototype.Zn;St.prototype.setFill=St.prototype.Yn;St.prototype.setRotation=St.prototype.Vm;St.prototype.setScale=St.prototype.Wm;St.prototype.setStroke=St.prototype.fo;St.prototype.setText=St.prototype.ho;St.prototype.setTextAlign=St.prototype.io;St.prototype.setTextBaseline=St.prototype.jo;u("ol.Sphere",ze,OPENLAYERS);ze.prototype.geodesicArea=ze.prototype.a;
ze.prototype.haversineDistance=ze.prototype.b;u("ol.source.BingMaps",Iz,OPENLAYERS);u("ol.source.BingMaps.TOS_ATTRIBUTION",Jz,OPENLAYERS);u("ol.source.Cluster",Y,OPENLAYERS);Y.prototype.setDistance=Y.prototype.ma;Y.prototype.getDistance=Y.prototype.na;u("ol.source.ImageCanvas",Kn,OPENLAYERS);u("ol.source.ImageMapGuide",Mz,OPENLAYERS);Mz.prototype.getParams=Mz.prototype.Ql;Mz.prototype.getImageLoadFunction=Mz.prototype.Pl;Mz.prototype.updateParams=Mz.prototype.Tl;
Mz.prototype.setImageLoadFunction=Mz.prototype.Sl;u("ol.source.Image",Dn,OPENLAYERS);Fn.prototype.image=Fn.prototype.image;u("ol.source.ImageStatic",Nz,OPENLAYERS);u("ol.source.ImageVector",bq,OPENLAYERS);bq.prototype.getSource=bq.prototype.Ul;bq.prototype.getStyle=bq.prototype.Vl;bq.prototype.getStyleFunction=bq.prototype.Wl;bq.prototype.setStyle=bq.prototype.Kg;u("ol.source.ImageWMS",Oz,OPENLAYERS);Oz.prototype.getGetFeatureInfoUrl=Oz.prototype.Zl;Oz.prototype.getParams=Oz.prototype.am;
Oz.prototype.getImageLoadFunction=Oz.prototype.$l;Oz.prototype.getUrl=Oz.prototype.bm;Oz.prototype.setImageLoadFunction=Oz.prototype.cm;Oz.prototype.setUrl=Oz.prototype.dm;Oz.prototype.updateParams=Oz.prototype.em;u("ol.source.MapQuest",Vz,OPENLAYERS);Vz.prototype.getLayer=Vz.prototype.H;u("ol.source.OSM",Tz,OPENLAYERS);u("ol.source.OSM.ATTRIBUTION",Uz,OPENLAYERS);u("ol.source.Raster",Yz,OPENLAYERS);Yz.prototype.setOperation=Yz.prototype.H;cA.prototype.extent=cA.prototype.extent;
cA.prototype.resolution=cA.prototype.resolution;cA.prototype.data=cA.prototype.data;u("ol.source.Source",Fh,OPENLAYERS);Fh.prototype.getAttributions=Fh.prototype.pa;Fh.prototype.getLogo=Fh.prototype.oa;Fh.prototype.getProjection=Fh.prototype.qa;Fh.prototype.getState=Fh.prototype.ra;Fh.prototype.setAttributions=Fh.prototype.la;u("ol.source.Stamen",hA,OPENLAYERS);u("ol.source.TileArcGISRest",jA,OPENLAYERS);jA.prototype.getParams=jA.prototype.fm;jA.prototype.getUrls=jA.prototype.gm;
jA.prototype.setUrl=jA.prototype.hm;jA.prototype.setUrls=jA.prototype.Lg;jA.prototype.updateParams=jA.prototype.jm;u("ol.source.TileDebug",lA,OPENLAYERS);u("ol.source.TileImage",Fz,OPENLAYERS);Fz.prototype.getTileLoadFunction=Fz.prototype.eb;Fz.prototype.getTileUrlFunction=Fz.prototype.fb;Fz.prototype.setRenderReprojectionEdges=Fz.prototype.jb;Fz.prototype.setTileGridForProjection=Fz.prototype.kb;Fz.prototype.setTileLoadFunction=Fz.prototype.lb;Fz.prototype.setTileUrlFunction=Fz.prototype.Oa;
u("ol.source.TileJSON",mA,OPENLAYERS);u("ol.source.Tile",Th,OPENLAYERS);Th.prototype.getTileGrid=Th.prototype.Ha;Wh.prototype.tile=Wh.prototype.tile;u("ol.source.TileUTFGrid",nA,OPENLAYERS);nA.prototype.getTemplate=nA.prototype.vj;nA.prototype.forDataAtCoordinateAndResolution=nA.prototype.Gi;u("ol.source.TileVector",sA,OPENLAYERS);sA.prototype.getFeaturesAtCoordinateAndResolution=sA.prototype.Ui;u("ol.source.TileWMS",vA,OPENLAYERS);vA.prototype.getGetFeatureInfoUrl=vA.prototype.nm;
vA.prototype.getParams=vA.prototype.om;vA.prototype.getUrls=vA.prototype.pm;vA.prototype.setUrl=vA.prototype.qm;vA.prototype.setUrls=vA.prototype.Mg;vA.prototype.updateParams=vA.prototype.sm;u("ol.source.Vector",U,OPENLAYERS);U.prototype.addFeature=U.prototype.Fc;U.prototype.addFeatures=U.prototype.Tb;U.prototype.clear=U.prototype.clear;U.prototype.forEachFeature=U.prototype.Te;U.prototype.forEachFeatureInExtent=U.prototype.xc;U.prototype.forEachFeatureIntersectingExtent=U.prototype.Ue;
U.prototype.getFeaturesCollection=U.prototype.Ze;U.prototype.getFeatures=U.prototype.Gc;U.prototype.getFeaturesAtCoordinate=U.prototype.Ye;U.prototype.getFeaturesInExtent=U.prototype.Id;U.prototype.getClosestFeatureToCoordinate=U.prototype.We;U.prototype.getExtent=U.prototype.J;U.prototype.getFeatureById=U.prototype.Xe;U.prototype.removeFeature=U.prototype.hc;Zp.prototype.feature=Zp.prototype.feature;u("ol.source.WMTS",Z,OPENLAYERS);Z.prototype.getDimensions=Z.prototype.Si;Z.prototype.getFormat=Z.prototype.Wi;
Z.prototype.getLayer=Z.prototype.tm;Z.prototype.getMatrixSet=Z.prototype.gj;Z.prototype.getRequestEncoding=Z.prototype.tj;Z.prototype.getStyle=Z.prototype.um;Z.prototype.getUrls=Z.prototype.vm;Z.prototype.getVersion=Z.prototype.zj;Z.prototype.updateDimensions=Z.prototype.to;
u("ol.source.WMTS.optionsFromCapabilities",function(a,c){var d=fb(a.Contents.Layer,function(a){return a.Identifier==c.layer}),e=a.Contents.TileMatrixSet,f,g;f=1<d.TileMatrixSetLink.length?"projection"in c?gb(d.TileMatrixSetLink,function(a){return fb(e,function(c){return c.Identifier==a.TileMatrixSet}).SupportedCRS.replace(/urn:ogc:def:crs:(\w+):(.*:)?(\w+)$/,"$1:$3")==c.projection}):gb(d.TileMatrixSetLink,function(a){return a.TileMatrixSet==c.matrixSet}):0;0>f&&(f=0);g=d.TileMatrixSetLink[f].TileMatrixSet;
var h=d.Format[0];"format"in c&&(h=c.format);f=gb(d.Style,function(a){return"style"in c?a.Title==c.style:a.isDefault});0>f&&(f=0);f=d.Style[f].Identifier;var k={};"Dimension"in d&&d.Dimension.forEach(function(a){var c=a.Identifier,d=a.Default;void 0===d&&(d=a.Value[0]);k[c]=d});var m=fb(a.Contents.TileMatrixSet,function(a){return a.Identifier==g}),n;n="projection"in c?Ee(c.projection):Ee(m.SupportedCRS.replace(/urn:ogc:def:crs:(\w+):(.*:)?(\w+)$/,"$1:$3"));var p=d.WGS84BoundingBox,q,r;void 0!==p&&
(r=Ee("EPSG:4326").J(),r=p[0]==r[0]&&p[2]==r[2],q=$e(p,"EPSG:4326",n),(p=n.J())&&(Xd(p,q)||(q=void 0)));var m=AA(m,q),t=[];q=c.requestEncoding;q=void 0!==q?q:"";if(a.hasOwnProperty("OperationsMetadata")&&a.OperationsMetadata.hasOwnProperty("GetTile")&&0!==q.indexOf("REST"))for(var d=a.OperationsMetadata.GetTile.DCP.HTTP.Get,p=0,y=d.length;p<y;++p){var A=fb(d[p].Constraint,function(a){return"GetEncoding"==a.name}).AllowedValues.Value;0<A.length&&ub(A,"KVP")&&(q="KVP",t.push(d[p].href))}else q="REST",
d.ResourceURL.forEach(function(a){"tile"==a.resourceType&&(h=a.format,t.push(a.template))});return{urls:t,layer:c.layer,matrixSet:g,format:h,projection:n,requestEncoding:q,tileGrid:m,style:f,dimensions:k,wrapX:r}},OPENLAYERS);u("ol.source.XYZ",Sz,OPENLAYERS);Sz.prototype.getUrls=Sz.prototype.l;Sz.prototype.setUrl=Sz.prototype.g;u("ol.source.Zoomify",CA,OPENLAYERS);hk.prototype.vectorContext=hk.prototype.vectorContext;hk.prototype.frameState=hk.prototype.frameState;hk.prototype.context=hk.prototype.context;
hk.prototype.glContext=hk.prototype.glContext;u("ol.render.VectorContext",gk,OPENLAYERS);Vq.prototype.drawAsync=Vq.prototype.ad;Vq.prototype.drawCircleGeometry=Vq.prototype.tc;Vq.prototype.drawFeature=Vq.prototype.Re;Vq.prototype.drawGeometryCollectionGeometry=Vq.prototype.Fd;Vq.prototype.drawPointGeometry=Vq.prototype.vb;Vq.prototype.drawLineStringGeometry=Vq.prototype.Eb;Vq.prototype.drawMultiLineStringGeometry=Vq.prototype.uc;Vq.prototype.drawMultiPointGeometry=Vq.prototype.ub;
Vq.prototype.drawMultiPolygonGeometry=Vq.prototype.vc;Vq.prototype.drawPolygonGeometry=Vq.prototype.wc;Vq.prototype.drawText=Vq.prototype.wb;Vq.prototype.setFillStrokeStyle=Vq.prototype.Qa;Vq.prototype.setImageStyle=Vq.prototype.ib;Vq.prototype.setTextStyle=Vq.prototype.Ra;mm.prototype.drawAsync=mm.prototype.ad;mm.prototype.drawCircleGeometry=mm.prototype.tc;mm.prototype.drawFeature=mm.prototype.Re;mm.prototype.drawPointGeometry=mm.prototype.vb;mm.prototype.drawMultiPointGeometry=mm.prototype.ub;
mm.prototype.drawLineStringGeometry=mm.prototype.Eb;mm.prototype.drawMultiLineStringGeometry=mm.prototype.uc;mm.prototype.drawPolygonGeometry=mm.prototype.wc;mm.prototype.drawMultiPolygonGeometry=mm.prototype.vc;mm.prototype.setFillStrokeStyle=mm.prototype.Qa;mm.prototype.setImageStyle=mm.prototype.ib;mm.prototype.setTextStyle=mm.prototype.Ra;u("ol.proj.common.add",Vl,OPENLAYERS);u("ol.proj.METERS_PER_UNIT",Be,OPENLAYERS);u("ol.proj.Projection",Ce,OPENLAYERS);Ce.prototype.getCode=Ce.prototype.Qi;
Ce.prototype.getExtent=Ce.prototype.J;Ce.prototype.getUnits=Ce.prototype.Jl;Ce.prototype.getMetersPerUnit=Ce.prototype.yc;Ce.prototype.getWorldExtent=Ce.prototype.Bj;Ce.prototype.isGlobal=Ce.prototype.nk;Ce.prototype.setGlobal=Ce.prototype.ao;Ce.prototype.setExtent=Ce.prototype.Kl;Ce.prototype.setWorldExtent=Ce.prototype.mo;Ce.prototype.setGetPointResolution=Ce.prototype.$n;Ce.prototype.getPointResolution=Ce.prototype.getPointResolution;u("ol.proj.addEquivalentProjections",Fe,OPENLAYERS);
u("ol.proj.addProjection",Te,OPENLAYERS);u("ol.proj.addCoordinateTransforms",Ge,OPENLAYERS);u("ol.proj.fromLonLat",function(a,c){return Ze(a,"EPSG:4326",void 0!==c?c:"EPSG:3857")},OPENLAYERS);u("ol.proj.toLonLat",function(a,c){return Ze(a,void 0!==c?c:"EPSG:3857","EPSG:4326")},OPENLAYERS);u("ol.proj.get",Ee,OPENLAYERS);u("ol.proj.getTransform",Xe,OPENLAYERS);u("ol.proj.transform",Ze,OPENLAYERS);u("ol.proj.transformExtent",$e,OPENLAYERS);u("ol.layer.Heatmap",X,OPENLAYERS);X.prototype.getBlur=X.prototype.Yf;
X.prototype.getGradient=X.prototype.ag;X.prototype.getRadius=X.prototype.Fg;X.prototype.setBlur=X.prototype.oh;X.prototype.setGradient=X.prototype.sh;X.prototype.setRadius=X.prototype.Gg;u("ol.layer.Image",Wl,OPENLAYERS);Wl.prototype.getSource=Wl.prototype.ga;u("ol.layer.Layer",ik,OPENLAYERS);ik.prototype.getSource=ik.prototype.ga;ik.prototype.setMap=ik.prototype.setMap;ik.prototype.setSource=ik.prototype.Lc;u("ol.layer.Base",ek,OPENLAYERS);ek.prototype.getExtent=ek.prototype.J;
ek.prototype.getMaxResolution=ek.prototype.Ib;ek.prototype.getMinResolution=ek.prototype.Jb;ek.prototype.getOpacity=ek.prototype.Nb;ek.prototype.getVisible=ek.prototype.pb;ek.prototype.getZIndex=ek.prototype.Ob;ek.prototype.setExtent=ek.prototype.cc;ek.prototype.setMaxResolution=ek.prototype.kc;ek.prototype.setMinResolution=ek.prototype.lc;ek.prototype.setOpacity=ek.prototype.dc;ek.prototype.setVisible=ek.prototype.ec;ek.prototype.setZIndex=ek.prototype.fc;u("ol.layer.Group",Ol,OPENLAYERS);
Ol.prototype.getLayers=Ol.prototype.Ec;Ol.prototype.setLayers=Ol.prototype.uh;u("ol.layer.Tile",E,OPENLAYERS);E.prototype.getPreload=E.prototype.a;E.prototype.getSource=E.prototype.ga;E.prototype.setPreload=E.prototype.f;E.prototype.getUseInterimTilesOnError=E.prototype.c;E.prototype.setUseInterimTilesOnError=E.prototype.g;u("ol.layer.Vector",G,OPENLAYERS);G.prototype.getSource=G.prototype.ga;G.prototype.getStyle=G.prototype.T;G.prototype.getStyleFunction=G.prototype.ea;G.prototype.setStyle=G.prototype.g;
u("ol.interaction.DoubleClickZoom",Wk,OPENLAYERS);u("ol.interaction.DoubleClickZoom.handleEvent",Xk,OPENLAYERS);u("ol.interaction.DragAndDrop",jy,OPENLAYERS);u("ol.interaction.DragAndDrop.handleEvent",te,OPENLAYERS);ky.prototype.features=ky.prototype.features;ky.prototype.file=ky.prototype.file;ky.prototype.projection=ky.prototype.projection;tl.prototype.coordinate=tl.prototype.coordinate;u("ol.interaction.DragBox",ul,OPENLAYERS);ul.prototype.getGeometry=ul.prototype.Y;
u("ol.interaction.DragPan",hl,OPENLAYERS);u("ol.interaction.DragRotateAndZoom",ny,OPENLAYERS);u("ol.interaction.DragRotate",ll,OPENLAYERS);u("ol.interaction.DragZoom",yl,OPENLAYERS);ry.prototype.feature=ry.prototype.feature;u("ol.interaction.Draw",sy,OPENLAYERS);u("ol.interaction.Draw.handleEvent",uy,OPENLAYERS);sy.prototype.removeLastPoint=sy.prototype.On;sy.prototype.finishDrawing=sy.prototype.bd;sy.prototype.extend=sy.prototype.ol;
u("ol.interaction.Draw.createRegularPolygon",function(a,c){return function(d,e){var f=d[0],g=d[1],h=Math.sqrt(xd(f,g)),k=e?e:Of(new $m(f),a);Pf(k,f,h,c?c:Math.atan((g[1]-f[1])/(g[0]-f[0])));return k}},OPENLAYERS);u("ol.interaction.Interaction",Sk,OPENLAYERS);Sk.prototype.getActive=Sk.prototype.c;Sk.prototype.setActive=Sk.prototype.g;u("ol.interaction.defaults",Nl,OPENLAYERS);u("ol.interaction.KeyboardPan",zl,OPENLAYERS);u("ol.interaction.KeyboardPan.handleEvent",Al,OPENLAYERS);
u("ol.interaction.KeyboardZoom",Bl,OPENLAYERS);u("ol.interaction.KeyboardZoom.handleEvent",Cl,OPENLAYERS);Iy.prototype.features=Iy.prototype.features;Iy.prototype.mapBrowserPointerEvent=Iy.prototype.mapBrowserPointerEvent;u("ol.interaction.Modify",Jy,OPENLAYERS);u("ol.interaction.Modify.handleEvent",My,OPENLAYERS);u("ol.interaction.MouseWheelZoom",Dl,OPENLAYERS);u("ol.interaction.MouseWheelZoom.handleEvent",El,OPENLAYERS);Dl.prototype.setMouseAnchor=Dl.prototype.C;
u("ol.interaction.PinchRotate",Fl,OPENLAYERS);u("ol.interaction.PinchZoom",Jl,OPENLAYERS);u("ol.interaction.Pointer",el,OPENLAYERS);u("ol.interaction.Pointer.handleEvent",fl,OPENLAYERS);Wy.prototype.selected=Wy.prototype.selected;Wy.prototype.deselected=Wy.prototype.deselected;Wy.prototype.mapBrowserEvent=Wy.prototype.mapBrowserEvent;u("ol.interaction.Select",Xy,OPENLAYERS);Xy.prototype.getFeatures=Xy.prototype.yl;Xy.prototype.getLayer=Xy.prototype.zl;u("ol.interaction.Select.handleEvent",Yy,OPENLAYERS);
Xy.prototype.setMap=Xy.prototype.setMap;u("ol.interaction.Snap",$y,OPENLAYERS);$y.prototype.addFeature=$y.prototype.jd;$y.prototype.removeFeature=$y.prototype.kd;dz.prototype.features=dz.prototype.features;dz.prototype.coordinate=dz.prototype.coordinate;u("ol.interaction.Translate",ez,OPENLAYERS);u("ol.geom.Circle",$m,OPENLAYERS);$m.prototype.clone=$m.prototype.clone;$m.prototype.getCenter=$m.prototype.hd;$m.prototype.getRadius=$m.prototype.mf;$m.prototype.getType=$m.prototype.Z;
$m.prototype.intersectsExtent=$m.prototype.ya;$m.prototype.setCenter=$m.prototype.gl;$m.prototype.setCenterAndRadius=$m.prototype.Cf;$m.prototype.setRadius=$m.prototype.hl;$m.prototype.transform=$m.prototype.Xa;u("ol.geom.Geometry",af,OPENLAYERS);af.prototype.getClosestPoint=af.prototype.bb;af.prototype.getExtent=af.prototype.J;af.prototype.simplify=af.prototype.mb;af.prototype.transform=af.prototype.Xa;u("ol.geom.GeometryCollection",bn,OPENLAYERS);bn.prototype.clone=bn.prototype.clone;
bn.prototype.getGeometries=bn.prototype.$f;bn.prototype.getType=bn.prototype.Z;bn.prototype.intersectsExtent=bn.prototype.ya;bn.prototype.setGeometries=bn.prototype.rh;bn.prototype.applyTransform=bn.prototype.Ub;bn.prototype.translate=bn.prototype.Dc;u("ol.geom.LinearRing",vf,OPENLAYERS);vf.prototype.clone=vf.prototype.clone;vf.prototype.getArea=vf.prototype.kl;vf.prototype.getCoordinates=vf.prototype.X;vf.prototype.getType=vf.prototype.Z;vf.prototype.setCoordinates=vf.prototype.ja;
u("ol.geom.LineString",I,OPENLAYERS);I.prototype.appendCoordinate=I.prototype.ui;I.prototype.clone=I.prototype.clone;I.prototype.forEachSegment=I.prototype.Ji;I.prototype.getCoordinateAtM=I.prototype.il;I.prototype.getCoordinates=I.prototype.X;I.prototype.getLength=I.prototype.jl;I.prototype.getType=I.prototype.Z;I.prototype.intersectsExtent=I.prototype.ya;I.prototype.setCoordinates=I.prototype.ja;u("ol.geom.MultiLineString",N,OPENLAYERS);N.prototype.appendLineString=N.prototype.vi;
N.prototype.clone=N.prototype.clone;N.prototype.getCoordinateAtM=N.prototype.ll;N.prototype.getCoordinates=N.prototype.X;N.prototype.getLineString=N.prototype.ej;N.prototype.getLineStrings=N.prototype.ed;N.prototype.getType=N.prototype.Z;N.prototype.intersectsExtent=N.prototype.ya;N.prototype.setCoordinates=N.prototype.ja;u("ol.geom.MultiPoint",mn,OPENLAYERS);mn.prototype.appendPoint=mn.prototype.xi;mn.prototype.clone=mn.prototype.clone;mn.prototype.getCoordinates=mn.prototype.X;
mn.prototype.getPoint=mn.prototype.pj;mn.prototype.getPoints=mn.prototype.ee;mn.prototype.getType=mn.prototype.Z;mn.prototype.intersectsExtent=mn.prototype.ya;mn.prototype.setCoordinates=mn.prototype.ja;u("ol.geom.MultiPolygon",O,OPENLAYERS);O.prototype.appendPolygon=O.prototype.yi;O.prototype.clone=O.prototype.clone;O.prototype.getArea=O.prototype.ml;O.prototype.getCoordinates=O.prototype.X;O.prototype.getInteriorPoints=O.prototype.bj;O.prototype.getPolygon=O.prototype.rj;
O.prototype.getPolygons=O.prototype.Md;O.prototype.getType=O.prototype.Z;O.prototype.intersectsExtent=O.prototype.ya;O.prototype.setCoordinates=O.prototype.ja;u("ol.geom.Point",C,OPENLAYERS);C.prototype.clone=C.prototype.clone;C.prototype.getCoordinates=C.prototype.X;C.prototype.getType=C.prototype.Z;C.prototype.intersectsExtent=C.prototype.ya;C.prototype.setCoordinates=C.prototype.ja;u("ol.geom.Polygon",D,OPENLAYERS);D.prototype.appendLinearRing=D.prototype.wi;D.prototype.clone=D.prototype.clone;
D.prototype.getArea=D.prototype.nl;D.prototype.getCoordinates=D.prototype.X;D.prototype.getInteriorPoint=D.prototype.aj;D.prototype.getLinearRingCount=D.prototype.fj;D.prototype.getLinearRing=D.prototype.bg;D.prototype.getLinearRings=D.prototype.Ld;D.prototype.getType=D.prototype.Z;D.prototype.intersectsExtent=D.prototype.ya;D.prototype.setCoordinates=D.prototype.ja;u("ol.geom.Polygon.circular",Mf,OPENLAYERS);u("ol.geom.Polygon.fromExtent",Nf,OPENLAYERS);u("ol.geom.Polygon.fromCircle",Of,OPENLAYERS);
u("ol.geom.SimpleGeometry",cf,OPENLAYERS);cf.prototype.getFirstCoordinate=cf.prototype.yb;cf.prototype.getLastCoordinate=cf.prototype.zb;cf.prototype.getLayout=cf.prototype.Ab;cf.prototype.applyTransform=cf.prototype.Ub;cf.prototype.translate=cf.prototype.Dc;u("ol.format.EsriJSON",$r,OPENLAYERS);$r.prototype.readFeature=$r.prototype.Bb;$r.prototype.readFeatures=$r.prototype.va;$r.prototype.readGeometry=$r.prototype.Ic;$r.prototype.readProjection=$r.prototype.Pa;$r.prototype.writeGeometry=$r.prototype.Oc;
$r.prototype.writeGeometryObject=$r.prototype.De;$r.prototype.writeFeature=$r.prototype.td;$r.prototype.writeFeatureObject=$r.prototype.Nc;$r.prototype.writeFeatures=$r.prototype.Db;$r.prototype.writeFeaturesObject=$r.prototype.Be;u("ol.format.Feature",Ur,OPENLAYERS);u("ol.format.GeoJSON",gs,OPENLAYERS);gs.prototype.readFeature=gs.prototype.Bb;gs.prototype.readFeatures=gs.prototype.va;gs.prototype.readGeometry=gs.prototype.Ic;gs.prototype.readProjection=gs.prototype.Pa;gs.prototype.writeFeature=gs.prototype.td;
gs.prototype.writeFeatureObject=gs.prototype.Nc;gs.prototype.writeFeatures=gs.prototype.Db;gs.prototype.writeFeaturesObject=gs.prototype.Be;gs.prototype.writeGeometry=gs.prototype.Oc;gs.prototype.writeGeometryObject=gs.prototype.De;u("ol.format.GPX",Ks,OPENLAYERS);Ks.prototype.readFeature=Ks.prototype.Bb;Ks.prototype.readFeatures=Ks.prototype.va;Ks.prototype.readProjection=Ks.prototype.Pa;Ks.prototype.writeFeatures=Ks.prototype.Db;Ks.prototype.writeFeaturesNode=Ks.prototype.a;
u("ol.format.IGC",ut,OPENLAYERS);ut.prototype.readFeature=ut.prototype.Bb;ut.prototype.readFeatures=ut.prototype.va;ut.prototype.readProjection=ut.prototype.Pa;u("ol.format.KML",Tt,OPENLAYERS);Tt.prototype.readFeature=Tt.prototype.Bb;Tt.prototype.readFeatures=Tt.prototype.va;Tt.prototype.readName=Tt.prototype.En;Tt.prototype.readNetworkLinks=Tt.prototype.Fn;Tt.prototype.readProjection=Tt.prototype.Pa;Tt.prototype.writeFeatures=Tt.prototype.Db;Tt.prototype.writeFeaturesNode=Tt.prototype.a;
u("ol.format.OSMXML",Gv,OPENLAYERS);Gv.prototype.readFeatures=Gv.prototype.va;Gv.prototype.readProjection=Gv.prototype.Pa;u("ol.format.Polyline",ew,OPENLAYERS);u("ol.format.Polyline.encodeDeltas",fw,OPENLAYERS);u("ol.format.Polyline.decodeDeltas",hw,OPENLAYERS);u("ol.format.Polyline.encodeFloats",gw,OPENLAYERS);u("ol.format.Polyline.decodeFloats",iw,OPENLAYERS);ew.prototype.readFeature=ew.prototype.Bb;ew.prototype.readFeatures=ew.prototype.va;ew.prototype.readGeometry=ew.prototype.Ic;
ew.prototype.readProjection=ew.prototype.Pa;ew.prototype.writeGeometry=ew.prototype.Oc;u("ol.format.TopoJSON",jw,OPENLAYERS);jw.prototype.readFeatures=jw.prototype.va;jw.prototype.readProjection=jw.prototype.Pa;u("ol.format.WFS",pw,OPENLAYERS);pw.prototype.readFeatures=pw.prototype.va;pw.prototype.readTransactionResponse=pw.prototype.j;pw.prototype.readFeatureCollectionMetadata=pw.prototype.i;pw.prototype.writeGetFeature=pw.prototype.l;pw.prototype.writeTransaction=pw.prototype.A;
pw.prototype.readProjection=pw.prototype.Pa;u("ol.format.WKT",Cw,OPENLAYERS);Cw.prototype.readFeature=Cw.prototype.Bb;Cw.prototype.readFeatures=Cw.prototype.va;Cw.prototype.readGeometry=Cw.prototype.Ic;Cw.prototype.writeFeature=Cw.prototype.td;Cw.prototype.writeFeatures=Cw.prototype.Db;Cw.prototype.writeGeometry=Cw.prototype.Oc;u("ol.format.WMSCapabilities",Uw,OPENLAYERS);Uw.prototype.read=Uw.prototype.c;u("ol.format.WMSGetFeatureInfo",qx,OPENLAYERS);qx.prototype.readFeatures=qx.prototype.va;
u("ol.format.WMTSCapabilities",rx,OPENLAYERS);rx.prototype.read=rx.prototype.c;u("ol.format.GML2",As,OPENLAYERS);u("ol.format.GML3",Bs,OPENLAYERS);Bs.prototype.writeGeometryNode=Bs.prototype.D;Bs.prototype.writeFeatures=Bs.prototype.Db;Bs.prototype.writeFeaturesNode=Bs.prototype.a;u("ol.format.GML",Bs,OPENLAYERS);Bs.prototype.writeFeatures=Bs.prototype.Db;Bs.prototype.writeFeaturesNode=Bs.prototype.a;os.prototype.readFeatures=os.prototype.va;
u("ol.events.condition.altKeyOnly",function(a){a=a.b;return a.a&&!a.l&&!a.f},OPENLAYERS);u("ol.events.condition.altShiftKeysOnly",Yk,OPENLAYERS);u("ol.events.condition.always",te,OPENLAYERS);u("ol.events.condition.click",function(a){return a.type==Uj},OPENLAYERS);u("ol.events.condition.never",se,OPENLAYERS);u("ol.events.condition.pointerMove",Zk,OPENLAYERS);u("ol.events.condition.singleClick",$k,OPENLAYERS);u("ol.events.condition.doubleClick",function(a){return a.type==Vj},OPENLAYERS);
u("ol.events.condition.noModifierKeys",al,OPENLAYERS);u("ol.events.condition.platformModifierKeyOnly",function(a){a=a.b;return!a.a&&a.l&&!a.f},OPENLAYERS);u("ol.events.condition.shiftKeyOnly",bl,OPENLAYERS);u("ol.events.condition.targetNotEditable",cl,OPENLAYERS);u("ol.events.condition.mouseOnly",dl,OPENLAYERS);u("ol.control.Attribution",Xh,OPENLAYERS);u("ol.control.Attribution.render",Yh,OPENLAYERS);Xh.prototype.getCollapsible=Xh.prototype.Xk;Xh.prototype.setCollapsible=Xh.prototype.$k;
Xh.prototype.setCollapsed=Xh.prototype.Zk;Xh.prototype.getCollapsed=Xh.prototype.Wk;u("ol.control.Control",xh,OPENLAYERS);xh.prototype.getMap=xh.prototype.g;xh.prototype.setMap=xh.prototype.setMap;xh.prototype.setTarget=xh.prototype.f;u("ol.control.defaults",di,OPENLAYERS);u("ol.control.FullScreen",ii,OPENLAYERS);u("ol.control.MousePosition",ji,OPENLAYERS);u("ol.control.MousePosition.render",ki,OPENLAYERS);ji.prototype.getCoordinateFormat=ji.prototype.Zf;ji.prototype.getProjection=ji.prototype.yg;
ji.prototype.setCoordinateFormat=ji.prototype.ph;ji.prototype.setProjection=ji.prototype.zg;u("ol.control.OverviewMap",ur,OPENLAYERS);u("ol.control.OverviewMap.render",vr,OPENLAYERS);ur.prototype.getCollapsible=ur.prototype.cl;ur.prototype.setCollapsible=ur.prototype.fl;ur.prototype.setCollapsed=ur.prototype.el;ur.prototype.getCollapsed=ur.prototype.bl;ur.prototype.getOverviewMap=ur.prototype.nj;u("ol.control.Rotate",ai,OPENLAYERS);u("ol.control.Rotate.render",bi,OPENLAYERS);
u("ol.control.ScaleLine",zr,OPENLAYERS);zr.prototype.getUnits=zr.prototype.P;u("ol.control.ScaleLine.render",Ar,OPENLAYERS);zr.prototype.setUnits=zr.prototype.ea;u("ol.control.Zoom",ci,OPENLAYERS);u("ol.control.ZoomSlider",Nr,OPENLAYERS);u("ol.control.ZoomSlider.render",Pr,OPENLAYERS);u("ol.control.ZoomToExtent",Sr,OPENLAYERS);u("ol.color.asArray",Ag,OPENLAYERS);u("ol.color.asString",Cg,OPENLAYERS);id.prototype.changed=id.prototype.s;id.prototype.dispatchEvent=id.prototype.u;
id.prototype.getRevision=id.prototype.M;id.prototype.on=id.prototype.G;id.prototype.once=id.prototype.N;id.prototype.un=id.prototype.L;id.prototype.unByKey=id.prototype.O;vg.prototype.get=vg.prototype.get;vg.prototype.getKeys=vg.prototype.R;vg.prototype.getProperties=vg.prototype.S;vg.prototype.set=vg.prototype.set;vg.prototype.setProperties=vg.prototype.K;vg.prototype.unset=vg.prototype.U;vg.prototype.changed=vg.prototype.s;vg.prototype.dispatchEvent=vg.prototype.u;vg.prototype.getRevision=vg.prototype.M;
vg.prototype.on=vg.prototype.G;vg.prototype.once=vg.prototype.N;vg.prototype.un=vg.prototype.L;vg.prototype.unByKey=vg.prototype.O;Tr.prototype.get=Tr.prototype.get;Tr.prototype.getKeys=Tr.prototype.R;Tr.prototype.getProperties=Tr.prototype.S;Tr.prototype.set=Tr.prototype.set;Tr.prototype.setProperties=Tr.prototype.K;Tr.prototype.unset=Tr.prototype.U;Tr.prototype.changed=Tr.prototype.s;Tr.prototype.dispatchEvent=Tr.prototype.u;Tr.prototype.getRevision=Tr.prototype.M;Tr.prototype.on=Tr.prototype.G;
Tr.prototype.once=Tr.prototype.N;Tr.prototype.un=Tr.prototype.L;Tr.prototype.unByKey=Tr.prototype.O;P.prototype.get=P.prototype.get;P.prototype.getKeys=P.prototype.R;P.prototype.getProperties=P.prototype.S;P.prototype.set=P.prototype.set;P.prototype.setProperties=P.prototype.K;P.prototype.unset=P.prototype.U;P.prototype.changed=P.prototype.s;P.prototype.dispatchEvent=P.prototype.u;P.prototype.getRevision=P.prototype.M;P.prototype.on=P.prototype.G;P.prototype.once=P.prototype.N;P.prototype.un=P.prototype.L;
P.prototype.unByKey=P.prototype.O;Fx.prototype.get=Fx.prototype.get;Fx.prototype.getKeys=Fx.prototype.R;Fx.prototype.getProperties=Fx.prototype.S;Fx.prototype.set=Fx.prototype.set;Fx.prototype.setProperties=Fx.prototype.K;Fx.prototype.unset=Fx.prototype.U;Fx.prototype.changed=Fx.prototype.s;Fx.prototype.dispatchEvent=Fx.prototype.u;Fx.prototype.getRevision=Fx.prototype.M;Fx.prototype.on=Fx.prototype.G;Fx.prototype.once=Fx.prototype.N;Fx.prototype.un=Fx.prototype.L;Fx.prototype.unByKey=Fx.prototype.O;
Px.prototype.getTileCoord=Px.prototype.D;V.prototype.get=V.prototype.get;V.prototype.getKeys=V.prototype.R;V.prototype.getProperties=V.prototype.S;V.prototype.set=V.prototype.set;V.prototype.setProperties=V.prototype.K;V.prototype.unset=V.prototype.U;V.prototype.changed=V.prototype.s;V.prototype.dispatchEvent=V.prototype.u;V.prototype.getRevision=V.prototype.M;V.prototype.on=V.prototype.G;V.prototype.once=V.prototype.N;V.prototype.un=V.prototype.L;V.prototype.unByKey=V.prototype.O;
Qj.prototype.map=Qj.prototype.map;Qj.prototype.frameState=Qj.prototype.frameState;Rj.prototype.originalEvent=Rj.prototype.originalEvent;Rj.prototype.pixel=Rj.prototype.pixel;Rj.prototype.coordinate=Rj.prototype.coordinate;Rj.prototype.dragging=Rj.prototype.dragging;Rj.prototype.preventDefault=Rj.prototype.preventDefault;Rj.prototype.stopPropagation=Rj.prototype.c;Rj.prototype.map=Rj.prototype.map;Rj.prototype.frameState=Rj.prototype.frameState;qr.prototype.get=qr.prototype.get;
qr.prototype.getKeys=qr.prototype.R;qr.prototype.getProperties=qr.prototype.S;qr.prototype.set=qr.prototype.set;qr.prototype.setProperties=qr.prototype.K;qr.prototype.unset=qr.prototype.U;qr.prototype.changed=qr.prototype.s;qr.prototype.dispatchEvent=qr.prototype.u;qr.prototype.getRevision=qr.prototype.M;qr.prototype.on=qr.prototype.G;qr.prototype.once=qr.prototype.N;qr.prototype.un=qr.prototype.L;qr.prototype.unByKey=qr.prototype.O;Qf.prototype.get=Qf.prototype.get;Qf.prototype.getKeys=Qf.prototype.R;
Qf.prototype.getProperties=Qf.prototype.S;Qf.prototype.set=Qf.prototype.set;Qf.prototype.setProperties=Qf.prototype.K;Qf.prototype.unset=Qf.prototype.U;Qf.prototype.changed=Qf.prototype.s;Qf.prototype.dispatchEvent=Qf.prototype.u;Qf.prototype.getRevision=Qf.prototype.M;Qf.prototype.on=Qf.prototype.G;Qf.prototype.once=Qf.prototype.N;Qf.prototype.un=Qf.prototype.L;Qf.prototype.unByKey=Qf.prototype.O;zA.prototype.getMaxZoom=zA.prototype.cg;zA.prototype.getMinZoom=zA.prototype.dg;
zA.prototype.getOrigin=zA.prototype.wa;zA.prototype.getResolution=zA.prototype.aa;zA.prototype.getResolutions=zA.prototype.Vg;zA.prototype.getTileCoordExtent=zA.prototype.xa;zA.prototype.getTileCoordForCoordAndResolution=zA.prototype.fd;zA.prototype.getTileCoordForCoordAndZ=zA.prototype.Qd;zA.prototype.getTileSize=zA.prototype.Ia;fm.prototype.getOpacity=fm.prototype.ke;fm.prototype.getRotateWithView=fm.prototype.Nd;fm.prototype.getRotation=fm.prototype.le;fm.prototype.getScale=fm.prototype.me;
fm.prototype.getSnapToPixel=fm.prototype.Pd;fm.prototype.setOpacity=fm.prototype.ne;fm.prototype.setRotation=fm.prototype.oe;fm.prototype.setScale=fm.prototype.pe;Ak.prototype.getOpacity=Ak.prototype.ke;Ak.prototype.getRotateWithView=Ak.prototype.Nd;Ak.prototype.getRotation=Ak.prototype.le;Ak.prototype.getScale=Ak.prototype.me;Ak.prototype.getSnapToPixel=Ak.prototype.Pd;Ak.prototype.setOpacity=Ak.prototype.ne;Ak.prototype.setRotation=Ak.prototype.oe;Ak.prototype.setScale=Ak.prototype.pe;
IA.prototype.getOpacity=IA.prototype.ke;IA.prototype.getRotateWithView=IA.prototype.Nd;IA.prototype.getRotation=IA.prototype.le;IA.prototype.getScale=IA.prototype.me;IA.prototype.getSnapToPixel=IA.prototype.Pd;IA.prototype.setOpacity=IA.prototype.ne;IA.prototype.setRotation=IA.prototype.oe;IA.prototype.setScale=IA.prototype.pe;Fh.prototype.get=Fh.prototype.get;Fh.prototype.getKeys=Fh.prototype.R;Fh.prototype.getProperties=Fh.prototype.S;Fh.prototype.set=Fh.prototype.set;
Fh.prototype.setProperties=Fh.prototype.K;Fh.prototype.unset=Fh.prototype.U;Fh.prototype.changed=Fh.prototype.s;Fh.prototype.dispatchEvent=Fh.prototype.u;Fh.prototype.getRevision=Fh.prototype.M;Fh.prototype.on=Fh.prototype.G;Fh.prototype.once=Fh.prototype.N;Fh.prototype.un=Fh.prototype.L;Fh.prototype.unByKey=Fh.prototype.O;Th.prototype.getAttributions=Th.prototype.pa;Th.prototype.getLogo=Th.prototype.oa;Th.prototype.getProjection=Th.prototype.qa;Th.prototype.getState=Th.prototype.ra;
Th.prototype.setAttributions=Th.prototype.la;Th.prototype.get=Th.prototype.get;Th.prototype.getKeys=Th.prototype.R;Th.prototype.getProperties=Th.prototype.S;Th.prototype.set=Th.prototype.set;Th.prototype.setProperties=Th.prototype.K;Th.prototype.unset=Th.prototype.U;Th.prototype.changed=Th.prototype.s;Th.prototype.dispatchEvent=Th.prototype.u;Th.prototype.getRevision=Th.prototype.M;Th.prototype.on=Th.prototype.G;Th.prototype.once=Th.prototype.N;Th.prototype.un=Th.prototype.L;
Th.prototype.unByKey=Th.prototype.O;Fz.prototype.getTileGrid=Fz.prototype.Ha;Fz.prototype.getAttributions=Fz.prototype.pa;Fz.prototype.getLogo=Fz.prototype.oa;Fz.prototype.getProjection=Fz.prototype.qa;Fz.prototype.getState=Fz.prototype.ra;Fz.prototype.setAttributions=Fz.prototype.la;Fz.prototype.get=Fz.prototype.get;Fz.prototype.getKeys=Fz.prototype.R;Fz.prototype.getProperties=Fz.prototype.S;Fz.prototype.set=Fz.prototype.set;Fz.prototype.setProperties=Fz.prototype.K;Fz.prototype.unset=Fz.prototype.U;
Fz.prototype.changed=Fz.prototype.s;Fz.prototype.dispatchEvent=Fz.prototype.u;Fz.prototype.getRevision=Fz.prototype.M;Fz.prototype.on=Fz.prototype.G;Fz.prototype.once=Fz.prototype.N;Fz.prototype.un=Fz.prototype.L;Fz.prototype.unByKey=Fz.prototype.O;Iz.prototype.getTileLoadFunction=Iz.prototype.eb;Iz.prototype.getTileUrlFunction=Iz.prototype.fb;Iz.prototype.setRenderReprojectionEdges=Iz.prototype.jb;Iz.prototype.setTileGridForProjection=Iz.prototype.kb;Iz.prototype.setTileLoadFunction=Iz.prototype.lb;
Iz.prototype.setTileUrlFunction=Iz.prototype.Oa;Iz.prototype.getTileGrid=Iz.prototype.Ha;Iz.prototype.getAttributions=Iz.prototype.pa;Iz.prototype.getLogo=Iz.prototype.oa;Iz.prototype.getProjection=Iz.prototype.qa;Iz.prototype.getState=Iz.prototype.ra;Iz.prototype.setAttributions=Iz.prototype.la;Iz.prototype.get=Iz.prototype.get;Iz.prototype.getKeys=Iz.prototype.R;Iz.prototype.getProperties=Iz.prototype.S;Iz.prototype.set=Iz.prototype.set;Iz.prototype.setProperties=Iz.prototype.K;
Iz.prototype.unset=Iz.prototype.U;Iz.prototype.changed=Iz.prototype.s;Iz.prototype.dispatchEvent=Iz.prototype.u;Iz.prototype.getRevision=Iz.prototype.M;Iz.prototype.on=Iz.prototype.G;Iz.prototype.once=Iz.prototype.N;Iz.prototype.un=Iz.prototype.L;Iz.prototype.unByKey=Iz.prototype.O;U.prototype.getAttributions=U.prototype.pa;U.prototype.getLogo=U.prototype.oa;U.prototype.getProjection=U.prototype.qa;U.prototype.getState=U.prototype.ra;U.prototype.setAttributions=U.prototype.la;U.prototype.get=U.prototype.get;
U.prototype.getKeys=U.prototype.R;U.prototype.getProperties=U.prototype.S;U.prototype.set=U.prototype.set;U.prototype.setProperties=U.prototype.K;U.prototype.unset=U.prototype.U;U.prototype.changed=U.prototype.s;U.prototype.dispatchEvent=U.prototype.u;U.prototype.getRevision=U.prototype.M;U.prototype.on=U.prototype.G;U.prototype.once=U.prototype.N;U.prototype.un=U.prototype.L;U.prototype.unByKey=U.prototype.O;Y.prototype.addFeature=Y.prototype.Fc;Y.prototype.addFeatures=Y.prototype.Tb;
Y.prototype.clear=Y.prototype.clear;Y.prototype.forEachFeature=Y.prototype.Te;Y.prototype.forEachFeatureInExtent=Y.prototype.xc;Y.prototype.forEachFeatureIntersectingExtent=Y.prototype.Ue;Y.prototype.getFeaturesCollection=Y.prototype.Ze;Y.prototype.getFeatures=Y.prototype.Gc;Y.prototype.getFeaturesAtCoordinate=Y.prototype.Ye;Y.prototype.getFeaturesInExtent=Y.prototype.Id;Y.prototype.getClosestFeatureToCoordinate=Y.prototype.We;Y.prototype.getExtent=Y.prototype.J;Y.prototype.getFeatureById=Y.prototype.Xe;
Y.prototype.removeFeature=Y.prototype.hc;Y.prototype.getAttributions=Y.prototype.pa;Y.prototype.getLogo=Y.prototype.oa;Y.prototype.getProjection=Y.prototype.qa;Y.prototype.getState=Y.prototype.ra;Y.prototype.setAttributions=Y.prototype.la;Y.prototype.get=Y.prototype.get;Y.prototype.getKeys=Y.prototype.R;Y.prototype.getProperties=Y.prototype.S;Y.prototype.set=Y.prototype.set;Y.prototype.setProperties=Y.prototype.K;Y.prototype.unset=Y.prototype.U;Y.prototype.changed=Y.prototype.s;
Y.prototype.dispatchEvent=Y.prototype.u;Y.prototype.getRevision=Y.prototype.M;Y.prototype.on=Y.prototype.G;Y.prototype.once=Y.prototype.N;Y.prototype.un=Y.prototype.L;Y.prototype.unByKey=Y.prototype.O;Dn.prototype.getAttributions=Dn.prototype.pa;Dn.prototype.getLogo=Dn.prototype.oa;Dn.prototype.getProjection=Dn.prototype.qa;Dn.prototype.getState=Dn.prototype.ra;Dn.prototype.setAttributions=Dn.prototype.la;Dn.prototype.get=Dn.prototype.get;Dn.prototype.getKeys=Dn.prototype.R;
Dn.prototype.getProperties=Dn.prototype.S;Dn.prototype.set=Dn.prototype.set;Dn.prototype.setProperties=Dn.prototype.K;Dn.prototype.unset=Dn.prototype.U;Dn.prototype.changed=Dn.prototype.s;Dn.prototype.dispatchEvent=Dn.prototype.u;Dn.prototype.getRevision=Dn.prototype.M;Dn.prototype.on=Dn.prototype.G;Dn.prototype.once=Dn.prototype.N;Dn.prototype.un=Dn.prototype.L;Dn.prototype.unByKey=Dn.prototype.O;Kn.prototype.getAttributions=Kn.prototype.pa;Kn.prototype.getLogo=Kn.prototype.oa;
Kn.prototype.getProjection=Kn.prototype.qa;Kn.prototype.getState=Kn.prototype.ra;Kn.prototype.setAttributions=Kn.prototype.la;Kn.prototype.get=Kn.prototype.get;Kn.prototype.getKeys=Kn.prototype.R;Kn.prototype.getProperties=Kn.prototype.S;Kn.prototype.set=Kn.prototype.set;Kn.prototype.setProperties=Kn.prototype.K;Kn.prototype.unset=Kn.prototype.U;Kn.prototype.changed=Kn.prototype.s;Kn.prototype.dispatchEvent=Kn.prototype.u;Kn.prototype.getRevision=Kn.prototype.M;Kn.prototype.on=Kn.prototype.G;
Kn.prototype.once=Kn.prototype.N;Kn.prototype.un=Kn.prototype.L;Kn.prototype.unByKey=Kn.prototype.O;Mz.prototype.getAttributions=Mz.prototype.pa;Mz.prototype.getLogo=Mz.prototype.oa;Mz.prototype.getProjection=Mz.prototype.qa;Mz.prototype.getState=Mz.prototype.ra;Mz.prototype.setAttributions=Mz.prototype.la;Mz.prototype.get=Mz.prototype.get;Mz.prototype.getKeys=Mz.prototype.R;Mz.prototype.getProperties=Mz.prototype.S;Mz.prototype.set=Mz.prototype.set;Mz.prototype.setProperties=Mz.prototype.K;
Mz.prototype.unset=Mz.prototype.U;Mz.prototype.changed=Mz.prototype.s;Mz.prototype.dispatchEvent=Mz.prototype.u;Mz.prototype.getRevision=Mz.prototype.M;Mz.prototype.on=Mz.prototype.G;Mz.prototype.once=Mz.prototype.N;Mz.prototype.un=Mz.prototype.L;Mz.prototype.unByKey=Mz.prototype.O;Nz.prototype.getAttributions=Nz.prototype.pa;Nz.prototype.getLogo=Nz.prototype.oa;Nz.prototype.getProjection=Nz.prototype.qa;Nz.prototype.getState=Nz.prototype.ra;Nz.prototype.setAttributions=Nz.prototype.la;
Nz.prototype.get=Nz.prototype.get;Nz.prototype.getKeys=Nz.prototype.R;Nz.prototype.getProperties=Nz.prototype.S;Nz.prototype.set=Nz.prototype.set;Nz.prototype.setProperties=Nz.prototype.K;Nz.prototype.unset=Nz.prototype.U;Nz.prototype.changed=Nz.prototype.s;Nz.prototype.dispatchEvent=Nz.prototype.u;Nz.prototype.getRevision=Nz.prototype.M;Nz.prototype.on=Nz.prototype.G;Nz.prototype.once=Nz.prototype.N;Nz.prototype.un=Nz.prototype.L;Nz.prototype.unByKey=Nz.prototype.O;bq.prototype.getAttributions=bq.prototype.pa;
bq.prototype.getLogo=bq.prototype.oa;bq.prototype.getProjection=bq.prototype.qa;bq.prototype.getState=bq.prototype.ra;bq.prototype.setAttributions=bq.prototype.la;bq.prototype.get=bq.prototype.get;bq.prototype.getKeys=bq.prototype.R;bq.prototype.getProperties=bq.prototype.S;bq.prototype.set=bq.prototype.set;bq.prototype.setProperties=bq.prototype.K;bq.prototype.unset=bq.prototype.U;bq.prototype.changed=bq.prototype.s;bq.prototype.dispatchEvent=bq.prototype.u;bq.prototype.getRevision=bq.prototype.M;
bq.prototype.on=bq.prototype.G;bq.prototype.once=bq.prototype.N;bq.prototype.un=bq.prototype.L;bq.prototype.unByKey=bq.prototype.O;Oz.prototype.getAttributions=Oz.prototype.pa;Oz.prototype.getLogo=Oz.prototype.oa;Oz.prototype.getProjection=Oz.prototype.qa;Oz.prototype.getState=Oz.prototype.ra;Oz.prototype.setAttributions=Oz.prototype.la;Oz.prototype.get=Oz.prototype.get;Oz.prototype.getKeys=Oz.prototype.R;Oz.prototype.getProperties=Oz.prototype.S;Oz.prototype.set=Oz.prototype.set;
Oz.prototype.setProperties=Oz.prototype.K;Oz.prototype.unset=Oz.prototype.U;Oz.prototype.changed=Oz.prototype.s;Oz.prototype.dispatchEvent=Oz.prototype.u;Oz.prototype.getRevision=Oz.prototype.M;Oz.prototype.on=Oz.prototype.G;Oz.prototype.once=Oz.prototype.N;Oz.prototype.un=Oz.prototype.L;Oz.prototype.unByKey=Oz.prototype.O;Sz.prototype.getTileLoadFunction=Sz.prototype.eb;Sz.prototype.getTileUrlFunction=Sz.prototype.fb;Sz.prototype.setRenderReprojectionEdges=Sz.prototype.jb;
Sz.prototype.setTileGridForProjection=Sz.prototype.kb;Sz.prototype.setTileLoadFunction=Sz.prototype.lb;Sz.prototype.setTileUrlFunction=Sz.prototype.Oa;Sz.prototype.getTileGrid=Sz.prototype.Ha;Sz.prototype.getAttributions=Sz.prototype.pa;Sz.prototype.getLogo=Sz.prototype.oa;Sz.prototype.getProjection=Sz.prototype.qa;Sz.prototype.getState=Sz.prototype.ra;Sz.prototype.setAttributions=Sz.prototype.la;Sz.prototype.get=Sz.prototype.get;Sz.prototype.getKeys=Sz.prototype.R;Sz.prototype.getProperties=Sz.prototype.S;
Sz.prototype.set=Sz.prototype.set;Sz.prototype.setProperties=Sz.prototype.K;Sz.prototype.unset=Sz.prototype.U;Sz.prototype.changed=Sz.prototype.s;Sz.prototype.dispatchEvent=Sz.prototype.u;Sz.prototype.getRevision=Sz.prototype.M;Sz.prototype.on=Sz.prototype.G;Sz.prototype.once=Sz.prototype.N;Sz.prototype.un=Sz.prototype.L;Sz.prototype.unByKey=Sz.prototype.O;Vz.prototype.getUrls=Vz.prototype.l;Vz.prototype.setUrl=Vz.prototype.g;Vz.prototype.getTileLoadFunction=Vz.prototype.eb;
Vz.prototype.getTileUrlFunction=Vz.prototype.fb;Vz.prototype.setRenderReprojectionEdges=Vz.prototype.jb;Vz.prototype.setTileGridForProjection=Vz.prototype.kb;Vz.prototype.setTileLoadFunction=Vz.prototype.lb;Vz.prototype.setTileUrlFunction=Vz.prototype.Oa;Vz.prototype.getTileGrid=Vz.prototype.Ha;Vz.prototype.getAttributions=Vz.prototype.pa;Vz.prototype.getLogo=Vz.prototype.oa;Vz.prototype.getProjection=Vz.prototype.qa;Vz.prototype.getState=Vz.prototype.ra;Vz.prototype.setAttributions=Vz.prototype.la;
Vz.prototype.get=Vz.prototype.get;Vz.prototype.getKeys=Vz.prototype.R;Vz.prototype.getProperties=Vz.prototype.S;Vz.prototype.set=Vz.prototype.set;Vz.prototype.setProperties=Vz.prototype.K;Vz.prototype.unset=Vz.prototype.U;Vz.prototype.changed=Vz.prototype.s;Vz.prototype.dispatchEvent=Vz.prototype.u;Vz.prototype.getRevision=Vz.prototype.M;Vz.prototype.on=Vz.prototype.G;Vz.prototype.once=Vz.prototype.N;Vz.prototype.un=Vz.prototype.L;Vz.prototype.unByKey=Vz.prototype.O;Tz.prototype.getUrls=Tz.prototype.l;
Tz.prototype.setUrl=Tz.prototype.g;Tz.prototype.getTileLoadFunction=Tz.prototype.eb;Tz.prototype.getTileUrlFunction=Tz.prototype.fb;Tz.prototype.setRenderReprojectionEdges=Tz.prototype.jb;Tz.prototype.setTileGridForProjection=Tz.prototype.kb;Tz.prototype.setTileLoadFunction=Tz.prototype.lb;Tz.prototype.setTileUrlFunction=Tz.prototype.Oa;Tz.prototype.getTileGrid=Tz.prototype.Ha;Tz.prototype.getAttributions=Tz.prototype.pa;Tz.prototype.getLogo=Tz.prototype.oa;Tz.prototype.getProjection=Tz.prototype.qa;
Tz.prototype.getState=Tz.prototype.ra;Tz.prototype.setAttributions=Tz.prototype.la;Tz.prototype.get=Tz.prototype.get;Tz.prototype.getKeys=Tz.prototype.R;Tz.prototype.getProperties=Tz.prototype.S;Tz.prototype.set=Tz.prototype.set;Tz.prototype.setProperties=Tz.prototype.K;Tz.prototype.unset=Tz.prototype.U;Tz.prototype.changed=Tz.prototype.s;Tz.prototype.dispatchEvent=Tz.prototype.u;Tz.prototype.getRevision=Tz.prototype.M;Tz.prototype.on=Tz.prototype.G;Tz.prototype.once=Tz.prototype.N;
Tz.prototype.un=Tz.prototype.L;Tz.prototype.unByKey=Tz.prototype.O;Yz.prototype.getAttributions=Yz.prototype.pa;Yz.prototype.getLogo=Yz.prototype.oa;Yz.prototype.getProjection=Yz.prototype.qa;Yz.prototype.getState=Yz.prototype.ra;Yz.prototype.setAttributions=Yz.prototype.la;Yz.prototype.get=Yz.prototype.get;Yz.prototype.getKeys=Yz.prototype.R;Yz.prototype.getProperties=Yz.prototype.S;Yz.prototype.set=Yz.prototype.set;Yz.prototype.setProperties=Yz.prototype.K;Yz.prototype.unset=Yz.prototype.U;
Yz.prototype.changed=Yz.prototype.s;Yz.prototype.dispatchEvent=Yz.prototype.u;Yz.prototype.getRevision=Yz.prototype.M;Yz.prototype.on=Yz.prototype.G;Yz.prototype.once=Yz.prototype.N;Yz.prototype.un=Yz.prototype.L;Yz.prototype.unByKey=Yz.prototype.O;hA.prototype.getUrls=hA.prototype.l;hA.prototype.setUrl=hA.prototype.g;hA.prototype.getTileLoadFunction=hA.prototype.eb;hA.prototype.getTileUrlFunction=hA.prototype.fb;hA.prototype.setRenderReprojectionEdges=hA.prototype.jb;
hA.prototype.setTileGridForProjection=hA.prototype.kb;hA.prototype.setTileLoadFunction=hA.prototype.lb;hA.prototype.setTileUrlFunction=hA.prototype.Oa;hA.prototype.getTileGrid=hA.prototype.Ha;hA.prototype.getAttributions=hA.prototype.pa;hA.prototype.getLogo=hA.prototype.oa;hA.prototype.getProjection=hA.prototype.qa;hA.prototype.getState=hA.prototype.ra;hA.prototype.setAttributions=hA.prototype.la;hA.prototype.get=hA.prototype.get;hA.prototype.getKeys=hA.prototype.R;hA.prototype.getProperties=hA.prototype.S;
hA.prototype.set=hA.prototype.set;hA.prototype.setProperties=hA.prototype.K;hA.prototype.unset=hA.prototype.U;hA.prototype.changed=hA.prototype.s;hA.prototype.dispatchEvent=hA.prototype.u;hA.prototype.getRevision=hA.prototype.M;hA.prototype.on=hA.prototype.G;hA.prototype.once=hA.prototype.N;hA.prototype.un=hA.prototype.L;hA.prototype.unByKey=hA.prototype.O;jA.prototype.getTileLoadFunction=jA.prototype.eb;jA.prototype.getTileUrlFunction=jA.prototype.fb;jA.prototype.setRenderReprojectionEdges=jA.prototype.jb;
jA.prototype.setTileGridForProjection=jA.prototype.kb;jA.prototype.setTileLoadFunction=jA.prototype.lb;jA.prototype.setTileUrlFunction=jA.prototype.Oa;jA.prototype.getTileGrid=jA.prototype.Ha;jA.prototype.getAttributions=jA.prototype.pa;jA.prototype.getLogo=jA.prototype.oa;jA.prototype.getProjection=jA.prototype.qa;jA.prototype.getState=jA.prototype.ra;jA.prototype.setAttributions=jA.prototype.la;jA.prototype.get=jA.prototype.get;jA.prototype.getKeys=jA.prototype.R;jA.prototype.getProperties=jA.prototype.S;
jA.prototype.set=jA.prototype.set;jA.prototype.setProperties=jA.prototype.K;jA.prototype.unset=jA.prototype.U;jA.prototype.changed=jA.prototype.s;jA.prototype.dispatchEvent=jA.prototype.u;jA.prototype.getRevision=jA.prototype.M;jA.prototype.on=jA.prototype.G;jA.prototype.once=jA.prototype.N;jA.prototype.un=jA.prototype.L;jA.prototype.unByKey=jA.prototype.O;lA.prototype.getTileGrid=lA.prototype.Ha;lA.prototype.getAttributions=lA.prototype.pa;lA.prototype.getLogo=lA.prototype.oa;
lA.prototype.getProjection=lA.prototype.qa;lA.prototype.getState=lA.prototype.ra;lA.prototype.setAttributions=lA.prototype.la;lA.prototype.get=lA.prototype.get;lA.prototype.getKeys=lA.prototype.R;lA.prototype.getProperties=lA.prototype.S;lA.prototype.set=lA.prototype.set;lA.prototype.setProperties=lA.prototype.K;lA.prototype.unset=lA.prototype.U;lA.prototype.changed=lA.prototype.s;lA.prototype.dispatchEvent=lA.prototype.u;lA.prototype.getRevision=lA.prototype.M;lA.prototype.on=lA.prototype.G;
lA.prototype.once=lA.prototype.N;lA.prototype.un=lA.prototype.L;lA.prototype.unByKey=lA.prototype.O;mA.prototype.getTileLoadFunction=mA.prototype.eb;mA.prototype.getTileUrlFunction=mA.prototype.fb;mA.prototype.setRenderReprojectionEdges=mA.prototype.jb;mA.prototype.setTileGridForProjection=mA.prototype.kb;mA.prototype.setTileLoadFunction=mA.prototype.lb;mA.prototype.setTileUrlFunction=mA.prototype.Oa;mA.prototype.getTileGrid=mA.prototype.Ha;mA.prototype.getAttributions=mA.prototype.pa;
mA.prototype.getLogo=mA.prototype.oa;mA.prototype.getProjection=mA.prototype.qa;mA.prototype.getState=mA.prototype.ra;mA.prototype.setAttributions=mA.prototype.la;mA.prototype.get=mA.prototype.get;mA.prototype.getKeys=mA.prototype.R;mA.prototype.getProperties=mA.prototype.S;mA.prototype.set=mA.prototype.set;mA.prototype.setProperties=mA.prototype.K;mA.prototype.unset=mA.prototype.U;mA.prototype.changed=mA.prototype.s;mA.prototype.dispatchEvent=mA.prototype.u;mA.prototype.getRevision=mA.prototype.M;
mA.prototype.on=mA.prototype.G;mA.prototype.once=mA.prototype.N;mA.prototype.un=mA.prototype.L;mA.prototype.unByKey=mA.prototype.O;nA.prototype.getTileGrid=nA.prototype.Ha;nA.prototype.getAttributions=nA.prototype.pa;nA.prototype.getLogo=nA.prototype.oa;nA.prototype.getProjection=nA.prototype.qa;nA.prototype.getState=nA.prototype.ra;nA.prototype.setAttributions=nA.prototype.la;nA.prototype.get=nA.prototype.get;nA.prototype.getKeys=nA.prototype.R;nA.prototype.getProperties=nA.prototype.S;
nA.prototype.set=nA.prototype.set;nA.prototype.setProperties=nA.prototype.K;nA.prototype.unset=nA.prototype.U;nA.prototype.changed=nA.prototype.s;nA.prototype.dispatchEvent=nA.prototype.u;nA.prototype.getRevision=nA.prototype.M;nA.prototype.on=nA.prototype.G;nA.prototype.once=nA.prototype.N;nA.prototype.un=nA.prototype.L;nA.prototype.unByKey=nA.prototype.O;sA.prototype.addFeature=sA.prototype.Fc;sA.prototype.addFeatures=sA.prototype.Tb;sA.prototype.clear=sA.prototype.clear;
sA.prototype.forEachFeature=sA.prototype.Te;sA.prototype.forEachFeatureInExtent=sA.prototype.xc;sA.prototype.forEachFeatureIntersectingExtent=sA.prototype.Ue;sA.prototype.getFeaturesCollection=sA.prototype.Ze;sA.prototype.getFeatures=sA.prototype.Gc;sA.prototype.getFeaturesAtCoordinate=sA.prototype.Ye;sA.prototype.getFeaturesInExtent=sA.prototype.Id;sA.prototype.getClosestFeatureToCoordinate=sA.prototype.We;sA.prototype.getExtent=sA.prototype.J;sA.prototype.getFeatureById=sA.prototype.Xe;
sA.prototype.removeFeature=sA.prototype.hc;sA.prototype.getAttributions=sA.prototype.pa;sA.prototype.getLogo=sA.prototype.oa;sA.prototype.getProjection=sA.prototype.qa;sA.prototype.getState=sA.prototype.ra;sA.prototype.setAttributions=sA.prototype.la;sA.prototype.get=sA.prototype.get;sA.prototype.getKeys=sA.prototype.R;sA.prototype.getProperties=sA.prototype.S;sA.prototype.set=sA.prototype.set;sA.prototype.setProperties=sA.prototype.K;sA.prototype.unset=sA.prototype.U;sA.prototype.changed=sA.prototype.s;
sA.prototype.dispatchEvent=sA.prototype.u;sA.prototype.getRevision=sA.prototype.M;sA.prototype.on=sA.prototype.G;sA.prototype.once=sA.prototype.N;sA.prototype.un=sA.prototype.L;sA.prototype.unByKey=sA.prototype.O;vA.prototype.getTileLoadFunction=vA.prototype.eb;vA.prototype.getTileUrlFunction=vA.prototype.fb;vA.prototype.setRenderReprojectionEdges=vA.prototype.jb;vA.prototype.setTileGridForProjection=vA.prototype.kb;vA.prototype.setTileLoadFunction=vA.prototype.lb;
vA.prototype.setTileUrlFunction=vA.prototype.Oa;vA.prototype.getTileGrid=vA.prototype.Ha;vA.prototype.getAttributions=vA.prototype.pa;vA.prototype.getLogo=vA.prototype.oa;vA.prototype.getProjection=vA.prototype.qa;vA.prototype.getState=vA.prototype.ra;vA.prototype.setAttributions=vA.prototype.la;vA.prototype.get=vA.prototype.get;vA.prototype.getKeys=vA.prototype.R;vA.prototype.getProperties=vA.prototype.S;vA.prototype.set=vA.prototype.set;vA.prototype.setProperties=vA.prototype.K;
vA.prototype.unset=vA.prototype.U;vA.prototype.changed=vA.prototype.s;vA.prototype.dispatchEvent=vA.prototype.u;vA.prototype.getRevision=vA.prototype.M;vA.prototype.on=vA.prototype.G;vA.prototype.once=vA.prototype.N;vA.prototype.un=vA.prototype.L;vA.prototype.unByKey=vA.prototype.O;Z.prototype.getTileLoadFunction=Z.prototype.eb;Z.prototype.getTileUrlFunction=Z.prototype.fb;Z.prototype.setRenderReprojectionEdges=Z.prototype.jb;Z.prototype.setTileGridForProjection=Z.prototype.kb;
Z.prototype.setTileLoadFunction=Z.prototype.lb;Z.prototype.setTileUrlFunction=Z.prototype.Oa;Z.prototype.getTileGrid=Z.prototype.Ha;Z.prototype.getAttributions=Z.prototype.pa;Z.prototype.getLogo=Z.prototype.oa;Z.prototype.getProjection=Z.prototype.qa;Z.prototype.getState=Z.prototype.ra;Z.prototype.setAttributions=Z.prototype.la;Z.prototype.get=Z.prototype.get;Z.prototype.getKeys=Z.prototype.R;Z.prototype.getProperties=Z.prototype.S;Z.prototype.set=Z.prototype.set;Z.prototype.setProperties=Z.prototype.K;
Z.prototype.unset=Z.prototype.U;Z.prototype.changed=Z.prototype.s;Z.prototype.dispatchEvent=Z.prototype.u;Z.prototype.getRevision=Z.prototype.M;Z.prototype.on=Z.prototype.G;Z.prototype.once=Z.prototype.N;Z.prototype.un=Z.prototype.L;Z.prototype.unByKey=Z.prototype.O;CA.prototype.getTileLoadFunction=CA.prototype.eb;CA.prototype.getTileUrlFunction=CA.prototype.fb;CA.prototype.setRenderReprojectionEdges=CA.prototype.jb;CA.prototype.setTileGridForProjection=CA.prototype.kb;
CA.prototype.setTileLoadFunction=CA.prototype.lb;CA.prototype.setTileUrlFunction=CA.prototype.Oa;CA.prototype.getTileGrid=CA.prototype.Ha;CA.prototype.getAttributions=CA.prototype.pa;CA.prototype.getLogo=CA.prototype.oa;CA.prototype.getProjection=CA.prototype.qa;CA.prototype.getState=CA.prototype.ra;CA.prototype.setAttributions=CA.prototype.la;CA.prototype.get=CA.prototype.get;CA.prototype.getKeys=CA.prototype.R;CA.prototype.getProperties=CA.prototype.S;CA.prototype.set=CA.prototype.set;
CA.prototype.setProperties=CA.prototype.K;CA.prototype.unset=CA.prototype.U;CA.prototype.changed=CA.prototype.s;CA.prototype.dispatchEvent=CA.prototype.u;CA.prototype.getRevision=CA.prototype.M;CA.prototype.on=CA.prototype.G;CA.prototype.once=CA.prototype.N;CA.prototype.un=CA.prototype.L;CA.prototype.unByKey=CA.prototype.O;lz.prototype.getTileCoord=lz.prototype.D;pk.prototype.changed=pk.prototype.s;pk.prototype.dispatchEvent=pk.prototype.u;pk.prototype.getRevision=pk.prototype.M;pk.prototype.on=pk.prototype.G;
pk.prototype.once=pk.prototype.N;pk.prototype.un=pk.prototype.L;pk.prototype.unByKey=pk.prototype.O;$q.prototype.changed=$q.prototype.s;$q.prototype.dispatchEvent=$q.prototype.u;$q.prototype.getRevision=$q.prototype.M;$q.prototype.on=$q.prototype.G;$q.prototype.once=$q.prototype.N;$q.prototype.un=$q.prototype.L;$q.prototype.unByKey=$q.prototype.O;cr.prototype.changed=cr.prototype.s;cr.prototype.dispatchEvent=cr.prototype.u;cr.prototype.getRevision=cr.prototype.M;cr.prototype.on=cr.prototype.G;
cr.prototype.once=cr.prototype.N;cr.prototype.un=cr.prototype.L;cr.prototype.unByKey=cr.prototype.O;ir.prototype.changed=ir.prototype.s;ir.prototype.dispatchEvent=ir.prototype.u;ir.prototype.getRevision=ir.prototype.M;ir.prototype.on=ir.prototype.G;ir.prototype.once=ir.prototype.N;ir.prototype.un=ir.prototype.L;ir.prototype.unByKey=ir.prototype.O;kr.prototype.changed=kr.prototype.s;kr.prototype.dispatchEvent=kr.prototype.u;kr.prototype.getRevision=kr.prototype.M;kr.prototype.on=kr.prototype.G;
kr.prototype.once=kr.prototype.N;kr.prototype.un=kr.prototype.L;kr.prototype.unByKey=kr.prototype.O;iq.prototype.changed=iq.prototype.s;iq.prototype.dispatchEvent=iq.prototype.u;iq.prototype.getRevision=iq.prototype.M;iq.prototype.on=iq.prototype.G;iq.prototype.once=iq.prototype.N;iq.prototype.un=iq.prototype.L;iq.prototype.unByKey=iq.prototype.O;jq.prototype.changed=jq.prototype.s;jq.prototype.dispatchEvent=jq.prototype.u;jq.prototype.getRevision=jq.prototype.M;jq.prototype.on=jq.prototype.G;
jq.prototype.once=jq.prototype.N;jq.prototype.un=jq.prototype.L;jq.prototype.unByKey=jq.prototype.O;kq.prototype.changed=kq.prototype.s;kq.prototype.dispatchEvent=kq.prototype.u;kq.prototype.getRevision=kq.prototype.M;kq.prototype.on=kq.prototype.G;kq.prototype.once=kq.prototype.N;kq.prototype.un=kq.prototype.L;kq.prototype.unByKey=kq.prototype.O;mq.prototype.changed=mq.prototype.s;mq.prototype.dispatchEvent=mq.prototype.u;mq.prototype.getRevision=mq.prototype.M;mq.prototype.on=mq.prototype.G;
mq.prototype.once=mq.prototype.N;mq.prototype.un=mq.prototype.L;mq.prototype.unByKey=mq.prototype.O;Am.prototype.changed=Am.prototype.s;Am.prototype.dispatchEvent=Am.prototype.u;Am.prototype.getRevision=Am.prototype.M;Am.prototype.on=Am.prototype.G;Am.prototype.once=Am.prototype.N;Am.prototype.un=Am.prototype.L;Am.prototype.unByKey=Am.prototype.O;dq.prototype.changed=dq.prototype.s;dq.prototype.dispatchEvent=dq.prototype.u;dq.prototype.getRevision=dq.prototype.M;dq.prototype.on=dq.prototype.G;
dq.prototype.once=dq.prototype.N;dq.prototype.un=dq.prototype.L;dq.prototype.unByKey=dq.prototype.O;eq.prototype.changed=eq.prototype.s;eq.prototype.dispatchEvent=eq.prototype.u;eq.prototype.getRevision=eq.prototype.M;eq.prototype.on=eq.prototype.G;eq.prototype.once=eq.prototype.N;eq.prototype.un=eq.prototype.L;eq.prototype.unByKey=eq.prototype.O;fq.prototype.changed=fq.prototype.s;fq.prototype.dispatchEvent=fq.prototype.u;fq.prototype.getRevision=fq.prototype.M;fq.prototype.on=fq.prototype.G;
fq.prototype.once=fq.prototype.N;fq.prototype.un=fq.prototype.L;fq.prototype.unByKey=fq.prototype.O;ek.prototype.get=ek.prototype.get;ek.prototype.getKeys=ek.prototype.R;ek.prototype.getProperties=ek.prototype.S;ek.prototype.set=ek.prototype.set;ek.prototype.setProperties=ek.prototype.K;ek.prototype.unset=ek.prototype.U;ek.prototype.changed=ek.prototype.s;ek.prototype.dispatchEvent=ek.prototype.u;ek.prototype.getRevision=ek.prototype.M;ek.prototype.on=ek.prototype.G;ek.prototype.once=ek.prototype.N;
ek.prototype.un=ek.prototype.L;ek.prototype.unByKey=ek.prototype.O;ik.prototype.getExtent=ik.prototype.J;ik.prototype.getMaxResolution=ik.prototype.Ib;ik.prototype.getMinResolution=ik.prototype.Jb;ik.prototype.getOpacity=ik.prototype.Nb;ik.prototype.getVisible=ik.prototype.pb;ik.prototype.getZIndex=ik.prototype.Ob;ik.prototype.setExtent=ik.prototype.cc;ik.prototype.setMaxResolution=ik.prototype.kc;ik.prototype.setMinResolution=ik.prototype.lc;ik.prototype.setOpacity=ik.prototype.dc;
ik.prototype.setVisible=ik.prototype.ec;ik.prototype.setZIndex=ik.prototype.fc;ik.prototype.get=ik.prototype.get;ik.prototype.getKeys=ik.prototype.R;ik.prototype.getProperties=ik.prototype.S;ik.prototype.set=ik.prototype.set;ik.prototype.setProperties=ik.prototype.K;ik.prototype.unset=ik.prototype.U;ik.prototype.changed=ik.prototype.s;ik.prototype.dispatchEvent=ik.prototype.u;ik.prototype.getRevision=ik.prototype.M;ik.prototype.on=ik.prototype.G;ik.prototype.once=ik.prototype.N;ik.prototype.un=ik.prototype.L;
ik.prototype.unByKey=ik.prototype.O;G.prototype.setMap=G.prototype.setMap;G.prototype.setSource=G.prototype.Lc;G.prototype.getExtent=G.prototype.J;G.prototype.getMaxResolution=G.prototype.Ib;G.prototype.getMinResolution=G.prototype.Jb;G.prototype.getOpacity=G.prototype.Nb;G.prototype.getVisible=G.prototype.pb;G.prototype.getZIndex=G.prototype.Ob;G.prototype.setExtent=G.prototype.cc;G.prototype.setMaxResolution=G.prototype.kc;G.prototype.setMinResolution=G.prototype.lc;G.prototype.setOpacity=G.prototype.dc;
G.prototype.setVisible=G.prototype.ec;G.prototype.setZIndex=G.prototype.fc;G.prototype.get=G.prototype.get;G.prototype.getKeys=G.prototype.R;G.prototype.getProperties=G.prototype.S;G.prototype.set=G.prototype.set;G.prototype.setProperties=G.prototype.K;G.prototype.unset=G.prototype.U;G.prototype.changed=G.prototype.s;G.prototype.dispatchEvent=G.prototype.u;G.prototype.getRevision=G.prototype.M;G.prototype.on=G.prototype.G;G.prototype.once=G.prototype.N;G.prototype.un=G.prototype.L;
G.prototype.unByKey=G.prototype.O;X.prototype.getSource=X.prototype.ga;X.prototype.getStyle=X.prototype.T;X.prototype.getStyleFunction=X.prototype.ea;X.prototype.setStyle=X.prototype.g;X.prototype.setMap=X.prototype.setMap;X.prototype.setSource=X.prototype.Lc;X.prototype.getExtent=X.prototype.J;X.prototype.getMaxResolution=X.prototype.Ib;X.prototype.getMinResolution=X.prototype.Jb;X.prototype.getOpacity=X.prototype.Nb;X.prototype.getVisible=X.prototype.pb;X.prototype.getZIndex=X.prototype.Ob;
X.prototype.setExtent=X.prototype.cc;X.prototype.setMaxResolution=X.prototype.kc;X.prototype.setMinResolution=X.prototype.lc;X.prototype.setOpacity=X.prototype.dc;X.prototype.setVisible=X.prototype.ec;X.prototype.setZIndex=X.prototype.fc;X.prototype.get=X.prototype.get;X.prototype.getKeys=X.prototype.R;X.prototype.getProperties=X.prototype.S;X.prototype.set=X.prototype.set;X.prototype.setProperties=X.prototype.K;X.prototype.unset=X.prototype.U;X.prototype.changed=X.prototype.s;
X.prototype.dispatchEvent=X.prototype.u;X.prototype.getRevision=X.prototype.M;X.prototype.on=X.prototype.G;X.prototype.once=X.prototype.N;X.prototype.un=X.prototype.L;X.prototype.unByKey=X.prototype.O;Wl.prototype.setMap=Wl.prototype.setMap;Wl.prototype.setSource=Wl.prototype.Lc;Wl.prototype.getExtent=Wl.prototype.J;Wl.prototype.getMaxResolution=Wl.prototype.Ib;Wl.prototype.getMinResolution=Wl.prototype.Jb;Wl.prototype.getOpacity=Wl.prototype.Nb;Wl.prototype.getVisible=Wl.prototype.pb;
Wl.prototype.getZIndex=Wl.prototype.Ob;Wl.prototype.setExtent=Wl.prototype.cc;Wl.prototype.setMaxResolution=Wl.prototype.kc;Wl.prototype.setMinResolution=Wl.prototype.lc;Wl.prototype.setOpacity=Wl.prototype.dc;Wl.prototype.setVisible=Wl.prototype.ec;Wl.prototype.setZIndex=Wl.prototype.fc;Wl.prototype.get=Wl.prototype.get;Wl.prototype.getKeys=Wl.prototype.R;Wl.prototype.getProperties=Wl.prototype.S;Wl.prototype.set=Wl.prototype.set;Wl.prototype.setProperties=Wl.prototype.K;Wl.prototype.unset=Wl.prototype.U;
Wl.prototype.changed=Wl.prototype.s;Wl.prototype.dispatchEvent=Wl.prototype.u;Wl.prototype.getRevision=Wl.prototype.M;Wl.prototype.on=Wl.prototype.G;Wl.prototype.once=Wl.prototype.N;Wl.prototype.un=Wl.prototype.L;Wl.prototype.unByKey=Wl.prototype.O;Ol.prototype.getExtent=Ol.prototype.J;Ol.prototype.getMaxResolution=Ol.prototype.Ib;Ol.prototype.getMinResolution=Ol.prototype.Jb;Ol.prototype.getOpacity=Ol.prototype.Nb;Ol.prototype.getVisible=Ol.prototype.pb;Ol.prototype.getZIndex=Ol.prototype.Ob;
Ol.prototype.setExtent=Ol.prototype.cc;Ol.prototype.setMaxResolution=Ol.prototype.kc;Ol.prototype.setMinResolution=Ol.prototype.lc;Ol.prototype.setOpacity=Ol.prototype.dc;Ol.prototype.setVisible=Ol.prototype.ec;Ol.prototype.setZIndex=Ol.prototype.fc;Ol.prototype.get=Ol.prototype.get;Ol.prototype.getKeys=Ol.prototype.R;Ol.prototype.getProperties=Ol.prototype.S;Ol.prototype.set=Ol.prototype.set;Ol.prototype.setProperties=Ol.prototype.K;Ol.prototype.unset=Ol.prototype.U;Ol.prototype.changed=Ol.prototype.s;
Ol.prototype.dispatchEvent=Ol.prototype.u;Ol.prototype.getRevision=Ol.prototype.M;Ol.prototype.on=Ol.prototype.G;Ol.prototype.once=Ol.prototype.N;Ol.prototype.un=Ol.prototype.L;Ol.prototype.unByKey=Ol.prototype.O;E.prototype.setMap=E.prototype.setMap;E.prototype.setSource=E.prototype.Lc;E.prototype.getExtent=E.prototype.J;E.prototype.getMaxResolution=E.prototype.Ib;E.prototype.getMinResolution=E.prototype.Jb;E.prototype.getOpacity=E.prototype.Nb;E.prototype.getVisible=E.prototype.pb;
E.prototype.getZIndex=E.prototype.Ob;E.prototype.setExtent=E.prototype.cc;E.prototype.setMaxResolution=E.prototype.kc;E.prototype.setMinResolution=E.prototype.lc;E.prototype.setOpacity=E.prototype.dc;E.prototype.setVisible=E.prototype.ec;E.prototype.setZIndex=E.prototype.fc;E.prototype.get=E.prototype.get;E.prototype.getKeys=E.prototype.R;E.prototype.getProperties=E.prototype.S;E.prototype.set=E.prototype.set;E.prototype.setProperties=E.prototype.K;E.prototype.unset=E.prototype.U;
E.prototype.changed=E.prototype.s;E.prototype.dispatchEvent=E.prototype.u;E.prototype.getRevision=E.prototype.M;E.prototype.on=E.prototype.G;E.prototype.once=E.prototype.N;E.prototype.un=E.prototype.L;E.prototype.unByKey=E.prototype.O;Sk.prototype.get=Sk.prototype.get;Sk.prototype.getKeys=Sk.prototype.R;Sk.prototype.getProperties=Sk.prototype.S;Sk.prototype.set=Sk.prototype.set;Sk.prototype.setProperties=Sk.prototype.K;Sk.prototype.unset=Sk.prototype.U;Sk.prototype.changed=Sk.prototype.s;
Sk.prototype.dispatchEvent=Sk.prototype.u;Sk.prototype.getRevision=Sk.prototype.M;Sk.prototype.on=Sk.prototype.G;Sk.prototype.once=Sk.prototype.N;Sk.prototype.un=Sk.prototype.L;Sk.prototype.unByKey=Sk.prototype.O;Wk.prototype.getActive=Wk.prototype.c;Wk.prototype.setActive=Wk.prototype.g;Wk.prototype.get=Wk.prototype.get;Wk.prototype.getKeys=Wk.prototype.R;Wk.prototype.getProperties=Wk.prototype.S;Wk.prototype.set=Wk.prototype.set;Wk.prototype.setProperties=Wk.prototype.K;Wk.prototype.unset=Wk.prototype.U;
Wk.prototype.changed=Wk.prototype.s;Wk.prototype.dispatchEvent=Wk.prototype.u;Wk.prototype.getRevision=Wk.prototype.M;Wk.prototype.on=Wk.prototype.G;Wk.prototype.once=Wk.prototype.N;Wk.prototype.un=Wk.prototype.L;Wk.prototype.unByKey=Wk.prototype.O;jy.prototype.getActive=jy.prototype.c;jy.prototype.setActive=jy.prototype.g;jy.prototype.get=jy.prototype.get;jy.prototype.getKeys=jy.prototype.R;jy.prototype.getProperties=jy.prototype.S;jy.prototype.set=jy.prototype.set;jy.prototype.setProperties=jy.prototype.K;
jy.prototype.unset=jy.prototype.U;jy.prototype.changed=jy.prototype.s;jy.prototype.dispatchEvent=jy.prototype.u;jy.prototype.getRevision=jy.prototype.M;jy.prototype.on=jy.prototype.G;jy.prototype.once=jy.prototype.N;jy.prototype.un=jy.prototype.L;jy.prototype.unByKey=jy.prototype.O;el.prototype.getActive=el.prototype.c;el.prototype.setActive=el.prototype.g;el.prototype.get=el.prototype.get;el.prototype.getKeys=el.prototype.R;el.prototype.getProperties=el.prototype.S;el.prototype.set=el.prototype.set;
el.prototype.setProperties=el.prototype.K;el.prototype.unset=el.prototype.U;el.prototype.changed=el.prototype.s;el.prototype.dispatchEvent=el.prototype.u;el.prototype.getRevision=el.prototype.M;el.prototype.on=el.prototype.G;el.prototype.once=el.prototype.N;el.prototype.un=el.prototype.L;el.prototype.unByKey=el.prototype.O;ul.prototype.getActive=ul.prototype.c;ul.prototype.setActive=ul.prototype.g;ul.prototype.get=ul.prototype.get;ul.prototype.getKeys=ul.prototype.R;ul.prototype.getProperties=ul.prototype.S;
ul.prototype.set=ul.prototype.set;ul.prototype.setProperties=ul.prototype.K;ul.prototype.unset=ul.prototype.U;ul.prototype.changed=ul.prototype.s;ul.prototype.dispatchEvent=ul.prototype.u;ul.prototype.getRevision=ul.prototype.M;ul.prototype.on=ul.prototype.G;ul.prototype.once=ul.prototype.N;ul.prototype.un=ul.prototype.L;ul.prototype.unByKey=ul.prototype.O;hl.prototype.getActive=hl.prototype.c;hl.prototype.setActive=hl.prototype.g;hl.prototype.get=hl.prototype.get;hl.prototype.getKeys=hl.prototype.R;
hl.prototype.getProperties=hl.prototype.S;hl.prototype.set=hl.prototype.set;hl.prototype.setProperties=hl.prototype.K;hl.prototype.unset=hl.prototype.U;hl.prototype.changed=hl.prototype.s;hl.prototype.dispatchEvent=hl.prototype.u;hl.prototype.getRevision=hl.prototype.M;hl.prototype.on=hl.prototype.G;hl.prototype.once=hl.prototype.N;hl.prototype.un=hl.prototype.L;hl.prototype.unByKey=hl.prototype.O;ny.prototype.getActive=ny.prototype.c;ny.prototype.setActive=ny.prototype.g;ny.prototype.get=ny.prototype.get;
ny.prototype.getKeys=ny.prototype.R;ny.prototype.getProperties=ny.prototype.S;ny.prototype.set=ny.prototype.set;ny.prototype.setProperties=ny.prototype.K;ny.prototype.unset=ny.prototype.U;ny.prototype.changed=ny.prototype.s;ny.prototype.dispatchEvent=ny.prototype.u;ny.prototype.getRevision=ny.prototype.M;ny.prototype.on=ny.prototype.G;ny.prototype.once=ny.prototype.N;ny.prototype.un=ny.prototype.L;ny.prototype.unByKey=ny.prototype.O;ll.prototype.getActive=ll.prototype.c;ll.prototype.setActive=ll.prototype.g;
ll.prototype.get=ll.prototype.get;ll.prototype.getKeys=ll.prototype.R;ll.prototype.getProperties=ll.prototype.S;ll.prototype.set=ll.prototype.set;ll.prototype.setProperties=ll.prototype.K;ll.prototype.unset=ll.prototype.U;ll.prototype.changed=ll.prototype.s;ll.prototype.dispatchEvent=ll.prototype.u;ll.prototype.getRevision=ll.prototype.M;ll.prototype.on=ll.prototype.G;ll.prototype.once=ll.prototype.N;ll.prototype.un=ll.prototype.L;ll.prototype.unByKey=ll.prototype.O;yl.prototype.getGeometry=yl.prototype.Y;
yl.prototype.getActive=yl.prototype.c;yl.prototype.setActive=yl.prototype.g;yl.prototype.get=yl.prototype.get;yl.prototype.getKeys=yl.prototype.R;yl.prototype.getProperties=yl.prototype.S;yl.prototype.set=yl.prototype.set;yl.prototype.setProperties=yl.prototype.K;yl.prototype.unset=yl.prototype.U;yl.prototype.changed=yl.prototype.s;yl.prototype.dispatchEvent=yl.prototype.u;yl.prototype.getRevision=yl.prototype.M;yl.prototype.on=yl.prototype.G;yl.prototype.once=yl.prototype.N;yl.prototype.un=yl.prototype.L;
yl.prototype.unByKey=yl.prototype.O;sy.prototype.getActive=sy.prototype.c;sy.prototype.setActive=sy.prototype.g;sy.prototype.get=sy.prototype.get;sy.prototype.getKeys=sy.prototype.R;sy.prototype.getProperties=sy.prototype.S;sy.prototype.set=sy.prototype.set;sy.prototype.setProperties=sy.prototype.K;sy.prototype.unset=sy.prototype.U;sy.prototype.changed=sy.prototype.s;sy.prototype.dispatchEvent=sy.prototype.u;sy.prototype.getRevision=sy.prototype.M;sy.prototype.on=sy.prototype.G;
sy.prototype.once=sy.prototype.N;sy.prototype.un=sy.prototype.L;sy.prototype.unByKey=sy.prototype.O;zl.prototype.getActive=zl.prototype.c;zl.prototype.setActive=zl.prototype.g;zl.prototype.get=zl.prototype.get;zl.prototype.getKeys=zl.prototype.R;zl.prototype.getProperties=zl.prototype.S;zl.prototype.set=zl.prototype.set;zl.prototype.setProperties=zl.prototype.K;zl.prototype.unset=zl.prototype.U;zl.prototype.changed=zl.prototype.s;zl.prototype.dispatchEvent=zl.prototype.u;
zl.prototype.getRevision=zl.prototype.M;zl.prototype.on=zl.prototype.G;zl.prototype.once=zl.prototype.N;zl.prototype.un=zl.prototype.L;zl.prototype.unByKey=zl.prototype.O;Bl.prototype.getActive=Bl.prototype.c;Bl.prototype.setActive=Bl.prototype.g;Bl.prototype.get=Bl.prototype.get;Bl.prototype.getKeys=Bl.prototype.R;Bl.prototype.getProperties=Bl.prototype.S;Bl.prototype.set=Bl.prototype.set;Bl.prototype.setProperties=Bl.prototype.K;Bl.prototype.unset=Bl.prototype.U;Bl.prototype.changed=Bl.prototype.s;
Bl.prototype.dispatchEvent=Bl.prototype.u;Bl.prototype.getRevision=Bl.prototype.M;Bl.prototype.on=Bl.prototype.G;Bl.prototype.once=Bl.prototype.N;Bl.prototype.un=Bl.prototype.L;Bl.prototype.unByKey=Bl.prototype.O;Jy.prototype.getActive=Jy.prototype.c;Jy.prototype.setActive=Jy.prototype.g;Jy.prototype.get=Jy.prototype.get;Jy.prototype.getKeys=Jy.prototype.R;Jy.prototype.getProperties=Jy.prototype.S;Jy.prototype.set=Jy.prototype.set;Jy.prototype.setProperties=Jy.prototype.K;Jy.prototype.unset=Jy.prototype.U;
Jy.prototype.changed=Jy.prototype.s;Jy.prototype.dispatchEvent=Jy.prototype.u;Jy.prototype.getRevision=Jy.prototype.M;Jy.prototype.on=Jy.prototype.G;Jy.prototype.once=Jy.prototype.N;Jy.prototype.un=Jy.prototype.L;Jy.prototype.unByKey=Jy.prototype.O;Dl.prototype.getActive=Dl.prototype.c;Dl.prototype.setActive=Dl.prototype.g;Dl.prototype.get=Dl.prototype.get;Dl.prototype.getKeys=Dl.prototype.R;Dl.prototype.getProperties=Dl.prototype.S;Dl.prototype.set=Dl.prototype.set;Dl.prototype.setProperties=Dl.prototype.K;
Dl.prototype.unset=Dl.prototype.U;Dl.prototype.changed=Dl.prototype.s;Dl.prototype.dispatchEvent=Dl.prototype.u;Dl.prototype.getRevision=Dl.prototype.M;Dl.prototype.on=Dl.prototype.G;Dl.prototype.once=Dl.prototype.N;Dl.prototype.un=Dl.prototype.L;Dl.prototype.unByKey=Dl.prototype.O;Fl.prototype.getActive=Fl.prototype.c;Fl.prototype.setActive=Fl.prototype.g;Fl.prototype.get=Fl.prototype.get;Fl.prototype.getKeys=Fl.prototype.R;Fl.prototype.getProperties=Fl.prototype.S;Fl.prototype.set=Fl.prototype.set;
Fl.prototype.setProperties=Fl.prototype.K;Fl.prototype.unset=Fl.prototype.U;Fl.prototype.changed=Fl.prototype.s;Fl.prototype.dispatchEvent=Fl.prototype.u;Fl.prototype.getRevision=Fl.prototype.M;Fl.prototype.on=Fl.prototype.G;Fl.prototype.once=Fl.prototype.N;Fl.prototype.un=Fl.prototype.L;Fl.prototype.unByKey=Fl.prototype.O;Jl.prototype.getActive=Jl.prototype.c;Jl.prototype.setActive=Jl.prototype.g;Jl.prototype.get=Jl.prototype.get;Jl.prototype.getKeys=Jl.prototype.R;Jl.prototype.getProperties=Jl.prototype.S;
Jl.prototype.set=Jl.prototype.set;Jl.prototype.setProperties=Jl.prototype.K;Jl.prototype.unset=Jl.prototype.U;Jl.prototype.changed=Jl.prototype.s;Jl.prototype.dispatchEvent=Jl.prototype.u;Jl.prototype.getRevision=Jl.prototype.M;Jl.prototype.on=Jl.prototype.G;Jl.prototype.once=Jl.prototype.N;Jl.prototype.un=Jl.prototype.L;Jl.prototype.unByKey=Jl.prototype.O;Xy.prototype.getActive=Xy.prototype.c;Xy.prototype.setActive=Xy.prototype.g;Xy.prototype.get=Xy.prototype.get;Xy.prototype.getKeys=Xy.prototype.R;
Xy.prototype.getProperties=Xy.prototype.S;Xy.prototype.set=Xy.prototype.set;Xy.prototype.setProperties=Xy.prototype.K;Xy.prototype.unset=Xy.prototype.U;Xy.prototype.changed=Xy.prototype.s;Xy.prototype.dispatchEvent=Xy.prototype.u;Xy.prototype.getRevision=Xy.prototype.M;Xy.prototype.on=Xy.prototype.G;Xy.prototype.once=Xy.prototype.N;Xy.prototype.un=Xy.prototype.L;Xy.prototype.unByKey=Xy.prototype.O;$y.prototype.getActive=$y.prototype.c;$y.prototype.setActive=$y.prototype.g;$y.prototype.get=$y.prototype.get;
$y.prototype.getKeys=$y.prototype.R;$y.prototype.getProperties=$y.prototype.S;$y.prototype.set=$y.prototype.set;$y.prototype.setProperties=$y.prototype.K;$y.prototype.unset=$y.prototype.U;$y.prototype.changed=$y.prototype.s;$y.prototype.dispatchEvent=$y.prototype.u;$y.prototype.getRevision=$y.prototype.M;$y.prototype.on=$y.prototype.G;$y.prototype.once=$y.prototype.N;$y.prototype.un=$y.prototype.L;$y.prototype.unByKey=$y.prototype.O;ez.prototype.getActive=ez.prototype.c;ez.prototype.setActive=ez.prototype.g;
ez.prototype.get=ez.prototype.get;ez.prototype.getKeys=ez.prototype.R;ez.prototype.getProperties=ez.prototype.S;ez.prototype.set=ez.prototype.set;ez.prototype.setProperties=ez.prototype.K;ez.prototype.unset=ez.prototype.U;ez.prototype.changed=ez.prototype.s;ez.prototype.dispatchEvent=ez.prototype.u;ez.prototype.getRevision=ez.prototype.M;ez.prototype.on=ez.prototype.G;ez.prototype.once=ez.prototype.N;ez.prototype.un=ez.prototype.L;ez.prototype.unByKey=ez.prototype.O;af.prototype.get=af.prototype.get;
af.prototype.getKeys=af.prototype.R;af.prototype.getProperties=af.prototype.S;af.prototype.set=af.prototype.set;af.prototype.setProperties=af.prototype.K;af.prototype.unset=af.prototype.U;af.prototype.changed=af.prototype.s;af.prototype.dispatchEvent=af.prototype.u;af.prototype.getRevision=af.prototype.M;af.prototype.on=af.prototype.G;af.prototype.once=af.prototype.N;af.prototype.un=af.prototype.L;af.prototype.unByKey=af.prototype.O;cf.prototype.getClosestPoint=cf.prototype.bb;
cf.prototype.getExtent=cf.prototype.J;cf.prototype.simplify=cf.prototype.mb;cf.prototype.transform=cf.prototype.Xa;cf.prototype.get=cf.prototype.get;cf.prototype.getKeys=cf.prototype.R;cf.prototype.getProperties=cf.prototype.S;cf.prototype.set=cf.prototype.set;cf.prototype.setProperties=cf.prototype.K;cf.prototype.unset=cf.prototype.U;cf.prototype.changed=cf.prototype.s;cf.prototype.dispatchEvent=cf.prototype.u;cf.prototype.getRevision=cf.prototype.M;cf.prototype.on=cf.prototype.G;
cf.prototype.once=cf.prototype.N;cf.prototype.un=cf.prototype.L;cf.prototype.unByKey=cf.prototype.O;$m.prototype.getFirstCoordinate=$m.prototype.yb;$m.prototype.getLastCoordinate=$m.prototype.zb;$m.prototype.getLayout=$m.prototype.Ab;$m.prototype.getClosestPoint=$m.prototype.bb;$m.prototype.getExtent=$m.prototype.J;$m.prototype.simplify=$m.prototype.mb;$m.prototype.get=$m.prototype.get;$m.prototype.getKeys=$m.prototype.R;$m.prototype.getProperties=$m.prototype.S;$m.prototype.set=$m.prototype.set;
$m.prototype.setProperties=$m.prototype.K;$m.prototype.unset=$m.prototype.U;$m.prototype.changed=$m.prototype.s;$m.prototype.dispatchEvent=$m.prototype.u;$m.prototype.getRevision=$m.prototype.M;$m.prototype.on=$m.prototype.G;$m.prototype.once=$m.prototype.N;$m.prototype.un=$m.prototype.L;$m.prototype.unByKey=$m.prototype.O;bn.prototype.getClosestPoint=bn.prototype.bb;bn.prototype.getExtent=bn.prototype.J;bn.prototype.simplify=bn.prototype.mb;bn.prototype.transform=bn.prototype.Xa;
bn.prototype.get=bn.prototype.get;bn.prototype.getKeys=bn.prototype.R;bn.prototype.getProperties=bn.prototype.S;bn.prototype.set=bn.prototype.set;bn.prototype.setProperties=bn.prototype.K;bn.prototype.unset=bn.prototype.U;bn.prototype.changed=bn.prototype.s;bn.prototype.dispatchEvent=bn.prototype.u;bn.prototype.getRevision=bn.prototype.M;bn.prototype.on=bn.prototype.G;bn.prototype.once=bn.prototype.N;bn.prototype.un=bn.prototype.L;bn.prototype.unByKey=bn.prototype.O;
vf.prototype.getFirstCoordinate=vf.prototype.yb;vf.prototype.getLastCoordinate=vf.prototype.zb;vf.prototype.getLayout=vf.prototype.Ab;vf.prototype.getClosestPoint=vf.prototype.bb;vf.prototype.getExtent=vf.prototype.J;vf.prototype.simplify=vf.prototype.mb;vf.prototype.transform=vf.prototype.Xa;vf.prototype.get=vf.prototype.get;vf.prototype.getKeys=vf.prototype.R;vf.prototype.getProperties=vf.prototype.S;vf.prototype.set=vf.prototype.set;vf.prototype.setProperties=vf.prototype.K;
vf.prototype.unset=vf.prototype.U;vf.prototype.changed=vf.prototype.s;vf.prototype.dispatchEvent=vf.prototype.u;vf.prototype.getRevision=vf.prototype.M;vf.prototype.on=vf.prototype.G;vf.prototype.once=vf.prototype.N;vf.prototype.un=vf.prototype.L;vf.prototype.unByKey=vf.prototype.O;I.prototype.getFirstCoordinate=I.prototype.yb;I.prototype.getLastCoordinate=I.prototype.zb;I.prototype.getLayout=I.prototype.Ab;I.prototype.getClosestPoint=I.prototype.bb;I.prototype.getExtent=I.prototype.J;
I.prototype.simplify=I.prototype.mb;I.prototype.transform=I.prototype.Xa;I.prototype.get=I.prototype.get;I.prototype.getKeys=I.prototype.R;I.prototype.getProperties=I.prototype.S;I.prototype.set=I.prototype.set;I.prototype.setProperties=I.prototype.K;I.prototype.unset=I.prototype.U;I.prototype.changed=I.prototype.s;I.prototype.dispatchEvent=I.prototype.u;I.prototype.getRevision=I.prototype.M;I.prototype.on=I.prototype.G;I.prototype.once=I.prototype.N;I.prototype.un=I.prototype.L;
I.prototype.unByKey=I.prototype.O;N.prototype.getFirstCoordinate=N.prototype.yb;N.prototype.getLastCoordinate=N.prototype.zb;N.prototype.getLayout=N.prototype.Ab;N.prototype.getClosestPoint=N.prototype.bb;N.prototype.getExtent=N.prototype.J;N.prototype.simplify=N.prototype.mb;N.prototype.transform=N.prototype.Xa;N.prototype.get=N.prototype.get;N.prototype.getKeys=N.prototype.R;N.prototype.getProperties=N.prototype.S;N.prototype.set=N.prototype.set;N.prototype.setProperties=N.prototype.K;
N.prototype.unset=N.prototype.U;N.prototype.changed=N.prototype.s;N.prototype.dispatchEvent=N.prototype.u;N.prototype.getRevision=N.prototype.M;N.prototype.on=N.prototype.G;N.prototype.once=N.prototype.N;N.prototype.un=N.prototype.L;N.prototype.unByKey=N.prototype.O;mn.prototype.getFirstCoordinate=mn.prototype.yb;mn.prototype.getLastCoordinate=mn.prototype.zb;mn.prototype.getLayout=mn.prototype.Ab;mn.prototype.getClosestPoint=mn.prototype.bb;mn.prototype.getExtent=mn.prototype.J;
mn.prototype.simplify=mn.prototype.mb;mn.prototype.transform=mn.prototype.Xa;mn.prototype.get=mn.prototype.get;mn.prototype.getKeys=mn.prototype.R;mn.prototype.getProperties=mn.prototype.S;mn.prototype.set=mn.prototype.set;mn.prototype.setProperties=mn.prototype.K;mn.prototype.unset=mn.prototype.U;mn.prototype.changed=mn.prototype.s;mn.prototype.dispatchEvent=mn.prototype.u;mn.prototype.getRevision=mn.prototype.M;mn.prototype.on=mn.prototype.G;mn.prototype.once=mn.prototype.N;mn.prototype.un=mn.prototype.L;
mn.prototype.unByKey=mn.prototype.O;O.prototype.getFirstCoordinate=O.prototype.yb;O.prototype.getLastCoordinate=O.prototype.zb;O.prototype.getLayout=O.prototype.Ab;O.prototype.getClosestPoint=O.prototype.bb;O.prototype.getExtent=O.prototype.J;O.prototype.simplify=O.prototype.mb;O.prototype.transform=O.prototype.Xa;O.prototype.get=O.prototype.get;O.prototype.getKeys=O.prototype.R;O.prototype.getProperties=O.prototype.S;O.prototype.set=O.prototype.set;O.prototype.setProperties=O.prototype.K;
O.prototype.unset=O.prototype.U;O.prototype.changed=O.prototype.s;O.prototype.dispatchEvent=O.prototype.u;O.prototype.getRevision=O.prototype.M;O.prototype.on=O.prototype.G;O.prototype.once=O.prototype.N;O.prototype.un=O.prototype.L;O.prototype.unByKey=O.prototype.O;C.prototype.getFirstCoordinate=C.prototype.yb;C.prototype.getLastCoordinate=C.prototype.zb;C.prototype.getLayout=C.prototype.Ab;C.prototype.getClosestPoint=C.prototype.bb;C.prototype.getExtent=C.prototype.J;C.prototype.simplify=C.prototype.mb;
C.prototype.transform=C.prototype.Xa;C.prototype.get=C.prototype.get;C.prototype.getKeys=C.prototype.R;C.prototype.getProperties=C.prototype.S;C.prototype.set=C.prototype.set;C.prototype.setProperties=C.prototype.K;C.prototype.unset=C.prototype.U;C.prototype.changed=C.prototype.s;C.prototype.dispatchEvent=C.prototype.u;C.prototype.getRevision=C.prototype.M;C.prototype.on=C.prototype.G;C.prototype.once=C.prototype.N;C.prototype.un=C.prototype.L;C.prototype.unByKey=C.prototype.O;
D.prototype.getFirstCoordinate=D.prototype.yb;D.prototype.getLastCoordinate=D.prototype.zb;D.prototype.getLayout=D.prototype.Ab;D.prototype.getClosestPoint=D.prototype.bb;D.prototype.getExtent=D.prototype.J;D.prototype.simplify=D.prototype.mb;D.prototype.transform=D.prototype.Xa;D.prototype.get=D.prototype.get;D.prototype.getKeys=D.prototype.R;D.prototype.getProperties=D.prototype.S;D.prototype.set=D.prototype.set;D.prototype.setProperties=D.prototype.K;D.prototype.unset=D.prototype.U;
D.prototype.changed=D.prototype.s;D.prototype.dispatchEvent=D.prototype.u;D.prototype.getRevision=D.prototype.M;D.prototype.on=D.prototype.G;D.prototype.once=D.prototype.N;D.prototype.un=D.prototype.L;D.prototype.unByKey=D.prototype.O;As.prototype.readFeatures=As.prototype.va;Bs.prototype.readFeatures=Bs.prototype.va;Bs.prototype.readFeatures=Bs.prototype.va;xh.prototype.get=xh.prototype.get;xh.prototype.getKeys=xh.prototype.R;xh.prototype.getProperties=xh.prototype.S;xh.prototype.set=xh.prototype.set;
xh.prototype.setProperties=xh.prototype.K;xh.prototype.unset=xh.prototype.U;xh.prototype.changed=xh.prototype.s;xh.prototype.dispatchEvent=xh.prototype.u;xh.prototype.getRevision=xh.prototype.M;xh.prototype.on=xh.prototype.G;xh.prototype.once=xh.prototype.N;xh.prototype.un=xh.prototype.L;xh.prototype.unByKey=xh.prototype.O;Xh.prototype.getMap=Xh.prototype.g;Xh.prototype.setMap=Xh.prototype.setMap;Xh.prototype.setTarget=Xh.prototype.f;Xh.prototype.get=Xh.prototype.get;Xh.prototype.getKeys=Xh.prototype.R;
Xh.prototype.getProperties=Xh.prototype.S;Xh.prototype.set=Xh.prototype.set;Xh.prototype.setProperties=Xh.prototype.K;Xh.prototype.unset=Xh.prototype.U;Xh.prototype.changed=Xh.prototype.s;Xh.prototype.dispatchEvent=Xh.prototype.u;Xh.prototype.getRevision=Xh.prototype.M;Xh.prototype.on=Xh.prototype.G;Xh.prototype.once=Xh.prototype.N;Xh.prototype.un=Xh.prototype.L;Xh.prototype.unByKey=Xh.prototype.O;ii.prototype.getMap=ii.prototype.g;ii.prototype.setMap=ii.prototype.setMap;ii.prototype.setTarget=ii.prototype.f;
ii.prototype.get=ii.prototype.get;ii.prototype.getKeys=ii.prototype.R;ii.prototype.getProperties=ii.prototype.S;ii.prototype.set=ii.prototype.set;ii.prototype.setProperties=ii.prototype.K;ii.prototype.unset=ii.prototype.U;ii.prototype.changed=ii.prototype.s;ii.prototype.dispatchEvent=ii.prototype.u;ii.prototype.getRevision=ii.prototype.M;ii.prototype.on=ii.prototype.G;ii.prototype.once=ii.prototype.N;ii.prototype.un=ii.prototype.L;ii.prototype.unByKey=ii.prototype.O;ji.prototype.getMap=ji.prototype.g;
ji.prototype.setMap=ji.prototype.setMap;ji.prototype.setTarget=ji.prototype.f;ji.prototype.get=ji.prototype.get;ji.prototype.getKeys=ji.prototype.R;ji.prototype.getProperties=ji.prototype.S;ji.prototype.set=ji.prototype.set;ji.prototype.setProperties=ji.prototype.K;ji.prototype.unset=ji.prototype.U;ji.prototype.changed=ji.prototype.s;ji.prototype.dispatchEvent=ji.prototype.u;ji.prototype.getRevision=ji.prototype.M;ji.prototype.on=ji.prototype.G;ji.prototype.once=ji.prototype.N;ji.prototype.un=ji.prototype.L;
ji.prototype.unByKey=ji.prototype.O;ur.prototype.getMap=ur.prototype.g;ur.prototype.setMap=ur.prototype.setMap;ur.prototype.setTarget=ur.prototype.f;ur.prototype.get=ur.prototype.get;ur.prototype.getKeys=ur.prototype.R;ur.prototype.getProperties=ur.prototype.S;ur.prototype.set=ur.prototype.set;ur.prototype.setProperties=ur.prototype.K;ur.prototype.unset=ur.prototype.U;ur.prototype.changed=ur.prototype.s;ur.prototype.dispatchEvent=ur.prototype.u;ur.prototype.getRevision=ur.prototype.M;
ur.prototype.on=ur.prototype.G;ur.prototype.once=ur.prototype.N;ur.prototype.un=ur.prototype.L;ur.prototype.unByKey=ur.prototype.O;ai.prototype.getMap=ai.prototype.g;ai.prototype.setMap=ai.prototype.setMap;ai.prototype.setTarget=ai.prototype.f;ai.prototype.get=ai.prototype.get;ai.prototype.getKeys=ai.prototype.R;ai.prototype.getProperties=ai.prototype.S;ai.prototype.set=ai.prototype.set;ai.prototype.setProperties=ai.prototype.K;ai.prototype.unset=ai.prototype.U;ai.prototype.changed=ai.prototype.s;
ai.prototype.dispatchEvent=ai.prototype.u;ai.prototype.getRevision=ai.prototype.M;ai.prototype.on=ai.prototype.G;ai.prototype.once=ai.prototype.N;ai.prototype.un=ai.prototype.L;ai.prototype.unByKey=ai.prototype.O;zr.prototype.getMap=zr.prototype.g;zr.prototype.setMap=zr.prototype.setMap;zr.prototype.setTarget=zr.prototype.f;zr.prototype.get=zr.prototype.get;zr.prototype.getKeys=zr.prototype.R;zr.prototype.getProperties=zr.prototype.S;zr.prototype.set=zr.prototype.set;zr.prototype.setProperties=zr.prototype.K;
zr.prototype.unset=zr.prototype.U;zr.prototype.changed=zr.prototype.s;zr.prototype.dispatchEvent=zr.prototype.u;zr.prototype.getRevision=zr.prototype.M;zr.prototype.on=zr.prototype.G;zr.prototype.once=zr.prototype.N;zr.prototype.un=zr.prototype.L;zr.prototype.unByKey=zr.prototype.O;ci.prototype.getMap=ci.prototype.g;ci.prototype.setMap=ci.prototype.setMap;ci.prototype.setTarget=ci.prototype.f;ci.prototype.get=ci.prototype.get;ci.prototype.getKeys=ci.prototype.R;ci.prototype.getProperties=ci.prototype.S;
ci.prototype.set=ci.prototype.set;ci.prototype.setProperties=ci.prototype.K;ci.prototype.unset=ci.prototype.U;ci.prototype.changed=ci.prototype.s;ci.prototype.dispatchEvent=ci.prototype.u;ci.prototype.getRevision=ci.prototype.M;ci.prototype.on=ci.prototype.G;ci.prototype.once=ci.prototype.N;ci.prototype.un=ci.prototype.L;ci.prototype.unByKey=ci.prototype.O;Nr.prototype.getMap=Nr.prototype.g;Nr.prototype.setMap=Nr.prototype.setMap;Nr.prototype.setTarget=Nr.prototype.f;Nr.prototype.get=Nr.prototype.get;
Nr.prototype.getKeys=Nr.prototype.R;Nr.prototype.getProperties=Nr.prototype.S;Nr.prototype.set=Nr.prototype.set;Nr.prototype.setProperties=Nr.prototype.K;Nr.prototype.unset=Nr.prototype.U;Nr.prototype.changed=Nr.prototype.s;Nr.prototype.dispatchEvent=Nr.prototype.u;Nr.prototype.getRevision=Nr.prototype.M;Nr.prototype.on=Nr.prototype.G;Nr.prototype.once=Nr.prototype.N;Nr.prototype.un=Nr.prototype.L;Nr.prototype.unByKey=Nr.prototype.O;Sr.prototype.getMap=Sr.prototype.g;Sr.prototype.setMap=Sr.prototype.setMap;
Sr.prototype.setTarget=Sr.prototype.f;Sr.prototype.get=Sr.prototype.get;Sr.prototype.getKeys=Sr.prototype.R;Sr.prototype.getProperties=Sr.prototype.S;Sr.prototype.set=Sr.prototype.set;Sr.prototype.setProperties=Sr.prototype.K;Sr.prototype.unset=Sr.prototype.U;Sr.prototype.changed=Sr.prototype.s;Sr.prototype.dispatchEvent=Sr.prototype.u;Sr.prototype.getRevision=Sr.prototype.M;Sr.prototype.on=Sr.prototype.G;Sr.prototype.once=Sr.prototype.N;Sr.prototype.un=Sr.prototype.L;Sr.prototype.unByKey=Sr.prototype.O;
  return OPENLAYERS.ol;
}));


;/*})'"*/
;/*})'"*/
(function ($, Drupal) {

  "use strict";

  Drupal.openlayers = {
    instances: {},
    processMap: function (map_id, context) {
      var settings = $.extend({}, {
        layer: [],
        style: [],
        control: [],
        interaction: [],
        source: [],
        projection: [],
        component: []
      }, Drupal.settings.openlayers.maps[map_id]);
      var map = false;

      // If already processed just return the instance.
      if (Drupal.openlayers.instances[map_id] !== undefined) {
        return Drupal.openlayers.instances[map_id].map;
      }

      $(document).trigger('openlayers.build_start', [
        {
          'type': 'objects',
          'settings': settings,
          'context': context
        }
      ]);

      try {
        $(document).trigger('openlayers.map_pre_alter', [
          {
            context: context,
            settings: settings,
            map_id: map_id
          }
        ]);
        map = Drupal.openlayers.getObject(context, 'maps', settings.map, map_id);
        $(document).trigger('openlayers.map_post_alter', [{map: Drupal.openlayers.instances[map_id].map}]);

        if (settings.style.length > 0) {
          $(document).trigger('openlayers.styles_pre_alter', [
            {
              styles: settings.style,
              map_id: map_id
            }
          ]);
          settings.style.map(function (data) {
            Drupal.openlayers.getObject(context, 'styles', data, map_id);
          });
          $(document).trigger('openlayers.styles_post_alter', [
            {
              styles: settings.style,
              map_id: map_id
            }
          ]);
        }

        if (settings.source.length > 0) {
          $(document).trigger('openlayers.sources_pre_alter', [
            {
              sources: settings.source,
              map_id: map_id
            }
          ]);
          settings.source.map(function (data) {
            if (data.opt !== undefined && data.opt.attributions !== undefined) {
              data.opt.attributions = [
                new ol.Attribution({
                  'html': data.opt.attributions
                })
              ];
            }
            Drupal.openlayers.getObject(context, 'sources', data, map_id);
          });
          $(document).trigger('openlayers.sources_post_alter', [
            {
              sources: settings.source,
              map_id: map_id
            }
          ]);
        }

        if (settings.interaction.length > 0) {
          $(document).trigger('openlayers.interactions_pre_alter', [
            {
              interactions: settings.interaction,
              map_id: map_id
            }
          ]);
          settings.interaction.map(function (data) {
            var interaction = Drupal.openlayers.getObject(context, 'interactions', data, map_id);
            if (interaction) {
              map.addInteraction(interaction);
            }
          });
          $(document).trigger('openlayers.interactions_post_alter', [
            {
              interactions: settings.interaction,
              map_id: map_id
            }
          ]);
        }

        if (settings.layer.length > 0) {
          $(document).trigger('openlayers.layers_pre_alter', [
            {
              layers: settings.layer,
              map_id: map_id
            }
          ]);
          settings.layer.map(function (data) {
            data.opt.source = Drupal.openlayers.instances[map_id].sources[data.opt.source];
            if (data.opt.style !== undefined && Drupal.openlayers.instances[map_id].styles[data.opt.style] !== undefined) {
              data.opt.style = Drupal.openlayers.instances[map_id].styles[data.opt.style];
            }
            var layer = Drupal.openlayers.getObject(context, 'layers', data, map_id);

            if (layer) {
              if (data.opt.name !== undefined) {
                layer.set('title', data.opt.name);
              }

              map.addLayer(layer);
            }
          });
          $(document).trigger('openlayers.layers_post_alter', [
            {
              layers: settings.layer,
              map_id: map_id
            }
          ]);
        }

        if (settings.control.length > 0) {
          $(document).trigger('openlayers.controls_pre_alter', [
            {
              controls: settings.control,
              map_id: map_id
            }
          ]);
          settings.control.map(function (data) {
            var control = Drupal.openlayers.getObject(context, 'controls', data, map_id);
            if (control) {
              map.addControl(control);
            }
          });
          $(document).trigger('openlayers.controls_post_alter', [
            {
              controls: settings.control,
              map_id: map_id
            }
          ]);
        }

        if (settings.component.length > 0) {
          $(document).trigger('openlayers.components_pre_alter', [{components: settings.component}]);
          settings.component.map(function (data) {
            Drupal.openlayers.getObject(context, 'components', data, map_id);
          });
        }

      } catch (e) {
        $('#' + map_id).empty();
        $(document).trigger('openlayers.build_failed', [
          {
            'error': e,
            'settings': settings,
            'context': context
          }
        ]);
        map = false;
      }

      $(document).trigger('openlayers.build_stop', [
        {
          'type': 'objects',
          'settings': settings,
          'context': context
        }
      ]);

      return map;
    },

    /**
     * Return the map instance collection of a map_id.
     *
     * @param map_id
     *   The id of the map.
     * @returns object/false
     *   The object or false if not instantiated yet.
     */
    getMapById: function (map_id) {
      if (Drupal.settings.openlayers.maps[map_id] !== undefined) {
        // Return map if it is instantiated already.
        if (Drupal.openlayers.instances[map_id]) {
          return Drupal.openlayers.instances[map_id];
        }
      }
      return false;
    },

    // Holds dynamic created asyncIsReady callbacks for every map id.
    // The functions are named by the cleaned map id. Everything besides 0-9a-z
    // is replaced by an underscore (_).
    asyncIsReadyCallbacks: {},
    asyncIsReady: function (map_id) {
      if (Drupal.settings.openlayers.maps[map_id] !== undefined) {
        Drupal.settings.openlayers.maps[map_id].map.opt.async--;
        if (!Drupal.settings.openlayers.maps[map_id].map.opt.async) {
          $('#' + map_id).once('openlayers-map', function () {
            Drupal.openlayers.processMap(map_id, document);
          });
        }
      }
    },

    /**
     * Get an object of a map.
     *
     * If it isn't instantiated yet the instance is created.
     */
    getObject: (function (context, type, data, map_id) {
      // If the type is maps the structure is slightly different.
      var instances_type = type;
      if (type == 'maps') {
        instances_type = 'map';
      }
      // Prepare instances cache.
      if (Drupal.openlayers.instances[map_id] === undefined) {
        Drupal.openlayers.instances[map_id] = {
          map: null,
          layers: {},
          styles: {},
          controls: {},
          interactions: {},
          sources: {},
          projections: {},
          components: {}
        };
      }

      // Check if we've already an instance of this object for this map.
      if (Drupal.openlayers.instances[map_id] !== undefined && Drupal.openlayers.instances[map_id][instances_type] !== undefined) {
        if (instances_type !== 'map' && Drupal.openlayers.instances[map_id][instances_type][data.mn] !== undefined) {
          return Drupal.openlayers.instances[map_id][instances_type][data.mn];
        }
        else
          if (instances_type === 'map' && Drupal.openlayers.instances[map_id][instances_type]) {
            return Drupal.openlayers.instances[map_id][instances_type];
          }
      }

      var object = null;
      // Make sure that data.opt exist even if it's empty.
      data.opt = $.extend({}, {}, data.opt);
      if (Drupal.openlayers.pluginManager.isRegistered(data['fs'])) {
        $(document).trigger('openlayers.object_pre_alter', [
          {
            'type': type,
            'mn': data.mn,
            'data': data,
            'map': Drupal.openlayers.instances[map_id].map,
            'objects': Drupal.openlayers.instances[map_id],
            'context': context,
            'map_id': map_id
          }
        ]);
        object = Drupal.openlayers.pluginManager.createInstance(data['fs'], {
          'data': data,
          'opt': data.opt,
          'map': Drupal.openlayers.instances[map_id].map,
          'objects': Drupal.openlayers.instances[map_id],
          'context': context,
          'map_id': map_id
        });
        $(document).trigger('openlayers.object_post_alter', [
          {
            'type': type,
            'mn': data.mn,
            'data': data,
            'map': Drupal.openlayers.instances[map_id].map,
            'objects': Drupal.openlayers.instances[map_id],
            'context': context,
            'object': object,
            'map_id': map_id
          }
        ]);

        // Store object to the instances cache.
        if (type == 'maps') {
          Drupal.openlayers.instances[map_id][instances_type] = object;
          return Drupal.openlayers.instances[map_id][instances_type];
        }
        else {
          Drupal.openlayers.instances[map_id][instances_type][data.mn] = object;
          return Drupal.openlayers.instances[map_id][instances_type][data.mn];
        }
        //return object;
      }
      else {
        $(document).trigger('openlayers.object_error', [
          {
            'type': type,
            'mn': data.mn,
            'data': data,
            'map': Drupal.openlayers.instances[map_id].map,
            'objects': Drupal.openlayers.instances[map_id],
            'context': context,
            'object': object,
            'map_id': map_id
          }
        ]);
      }
    }),
    log: function (string) {
      if (Drupal.openlayers.console !== undefined) {
        Drupal.openlayers.console.log(string);
      }
    }
};
}(jQuery, Drupal));

;/*})'"*/
;/*})'"*/
(function ($, Drupal) {

  "use strict";

  var plugins = [];

  Drupal.openlayers.pluginManager = {
    attach: function (context, settings) {
      for (var i in plugins) {
        var plugin = plugins[i];
        if (typeof plugin.attach === 'function') {
          plugin.attach(context, settings);
        }
      }
    },
    detach: function (context, settings) {
      for (var i in plugins) {
        var plugin = plugins[i];
        if (typeof plugin.detach === 'function') {
          plugin.detach(context, settings);
        }
      }
    },
    alter: function () {
      // @todo: alter hook
    },
    getPlugin: function (factoryService) {
      if (this.isRegistered(factoryService)) {
        return plugins[factoryService];
      }
      return false;
    },
    getPlugins: function () {
      return Object.keys(plugins);
    },
    register: function (plugin) {
      if ((typeof plugin !== 'object') || (plugin === null)) {
        return false;
      }

      if (typeof plugin.init !== 'function') {
        return false;
      }

      if (!plugin.hasOwnProperty('fs')) {
        return false;
      }

      plugins[plugin.fs] = plugin;
    },
    createInstance: function (factoryService, data) {
      if (!this.isRegistered(factoryService)) {
        return false;
      }

      try {
        var obj = plugins[factoryService].init(data);
      } catch (e) {
        if (console !== undefined) {
          Drupal.openlayers.console.log(e.message);
          Drupal.openlayers.console.log(e.stack);
        }
        else {
          $(this).text('Error during map rendering: ' + e.message);
          $(this).text('Stack: ' + e.stack);
        }
      }

      var objType = typeof obj;
      if ((objType === 'object') && (objType !== null) || (objType === 'function')) {
        obj.mn = data.data.mn;
        return obj;
      }

      return false;
    },
    isRegistered: function (factoryService) {
      return (factoryService in plugins);
    }
  };

}(jQuery, Drupal));

;/*})'"*/
;/*})'"*/
(function ($, Drupal) {

  "use strict";

  Drupal.behaviors.openlayers = {
      attach: function (context, settings) {
        Drupal.openlayers.pluginManager.attach(context, settings);

        $('.openlayers-map:not(.asynchronous)', context).once('openlayers-map', function () {
          var map_id = $(this).attr('id');
          if (Drupal.settings.openlayers.maps[map_id] !== undefined) {
            Drupal.openlayers.processMap(map_id, context);
          }
        });

        // Create dynamic callback functions for asynchronous maps.
        $('.openlayers-map.asynchronous', context).once('openlayers-map.asynchronous', function () {
          var map_id = $(this).attr('id');
          if (Drupal.settings.openlayers.maps[map_id] !== undefined) {
            Drupal.openlayers.asyncIsReadyCallbacks[map_id.replace(/[^0-9a-z]/gi, '_')] = function () {
              Drupal.openlayers.asyncIsReady(map_id);
            };
          }
        });
      },
      detach: function (context, settings) {
        Drupal.openlayers.pluginManager.detach(context, settings);
      }
  };
}(jQuery, Drupal));

;/*})'"*/
;/*})'"*/
Drupal.openlayers.pluginManager.register({
  fs: 'openlayers.Layer:Vector',
  init: function(data) {

    var layer = new ol.layer.Vector(data.opt);
    // Check if this layer is activated for dedicated zoom levels.
    if (data.opt.zoomActivity) {
      var zoomSpecificVisibility = function() {
        layer.setVisible(data.opt.zoomActivity[data.map.getView().getZoom()] !== undefined);
      };
      data.map.getView().on('change:resolution', zoomSpecificVisibility);
    }

    return layer;
  }
});

;/*})'"*/
;/*})'"*/
Drupal.openlayers.pluginManager.register({
  fs: 'openlayers.Interaction:PinchZoom',
  init: function(data) {
    return new ol.interaction.PinchZoom(data.opt);
  }
});

;/*})'"*/
;/*})'"*/
