var DebitCardVerify = {};

var DebitCardVerify = (function(){

    var obj = {

    };

    obj.ie8 = {
        'forceRepaint': function(elem){
            elem.addClass('z').removeClass('z');
        }
    }


// *********************************************************************************************** //
// *** ERROR MESSAGES **************************************************************************** //
// *********************************************************************************************** //

    obj.error = {
        'messages': {
            'debitCardNumber': {
                'blank': errorMessages.debitCard.debitCardNumber.blank,
                'invalid': errorMessages.invalid1
            },
            'debitCardPin': {
                'blank': errorMessages.debitCard.debitCardPin.blank,
                'invalid': errorMessages.invalid1
            }
        }
    };

// *********************************************************************************************** //
// *** ELEMENTS ********************************************************************************** //
// *********************************************************************************************** //

    obj.elements = {
        'all': $('*'),
        'body': $('body'),
        'head': $('head'),
        'title': $('head > title'),
        'form': {
            'self': $('#credentials'),
            'debitCardNumber': $('#debitCardNumber'),
            'debitCardNumberError': $('#debitCardNumberError'),
            'debitCardPin': $('#debitCardPin'),
            'debitCardPinError': $('#debitCardPinError'),
            'submitted': false,
            'currentInput': 'debitCardNumber',
            'action_hidden': $('#action')
        },
        'buttons': {
            'cancel': $('#cancel'),
            'continue': $('#continue')
        },
        'errorMessage': {
            'container': $('[control=errorMessage]'),
            'message': $('[control=errorMessage]').find('span')
        },
        'loadingAction': $('[control=loadingAction]')
    };


// *********************************************************************************************** //
// *** ELEMENT EVENTS **************************************************************************** //
// *********************************************************************************************** //

    obj.events = {
        'form': {
            'debitCardNumber': {
                'focus': function(e){
                    obj.elements.form.currentInput = 'debitCardNumber';
                }
            },
            'debitCardPin': {
                'focus': function(e){
                    obj.elements.form.currentInput = 'debitCardPin';
                }
            }
        },
        'keyboard': {
            'enter': {
                'keypress': function(e){
                    if(e.which === 13){
                        e.preventDefault();
                        obj.methods.submit('verify');
                    }
                }
            }
        },
        'buttons': {
            'continue': {
                'click': function(e) {
                    e.preventDefault();
                    obj.methods.submit('verify');
                }
            },
            'cancel': {
                'click': function(e) {
                    e.preventDefault();
                    obj.methods.submit('cancel');
                }
            }
        }
    };

// *********************************************************************************************** //
// *** METHODS *********************************************************************************** //
// *********************************************************************************************** //

    obj.methods = {
        'submit': function(action){
            if(obj.elements.form.submitted){
                return false;
            }
            obj.elements.form.action_hidden.val(action);
            obj.elements.form.self.submit();
        },
        'validate': function(){
            var passedValidation = true;
            var form = obj.elements.form;
            var message = obj.elements.errorMessage.message;
            var errors = obj.error.messages;

            if(obj.elements.form.action_hidden.val() === 'cancel') {
                return true;
            }

            obj.elements.errorMessage.message.text("");

            form.debitCardPinError.addClass('hidden');
            form.debitCardPin.removeClass('error');
            form.debitCardNumberError.addClass('hidden');
            form.debitCardNumber.removeClass('error');

            if(!Validation.numbersOnly(form.debitCardPin)){
                message.text(errors.debitCardPin.invalid);
                form.debitCardPinError.removeClass('hidden');
                form.debitCardPin.addClass('error');
                passedValidation = false;
            }

            if(!Validation.blank(form.debitCardPin)){
                message.text(errors.debitCardPin.blank);
                form.debitCardPinError.removeClass('hidden');
                form.debitCardPin.addClass('error');
                passedValidation = false;
            }

            if(obj.elements.form.debitCardNumber.length > 0){
               if(!Validation.zeros(form.debitCardNumber) || !Validation.numbersOnly(form.debitCardNumber, 16)){
                    console.log(errors)
                    message.text(errors.debitCardNumber.invalid);
                    form.debitCardNumberError.removeClass('hidden');
                    form.debitCardNumber.addClass('error');
                    passedValidation = false;
                }

                if(!Validation.blank(form.debitCardNumber)){
                    message.text(errors.debitCardNumber.blank);
                    form.debitCardNumberError.removeClass('hidden');
                    form.debitCardNumber.addClass('error');
                    passedValidation = false;
                } 
            }            

            if(!passedValidation){
                form.debitCardNumber.val("");
                form.debitCardPin.val("");
                obj.elements.errorMessage.container.attr('data-has-error', 'true');
                obj.ie8.forceRepaint(obj.elements.errorMessage.container);
            } else {
                obj.elements.errorMessage.container.attr('data-has-error', 'false');
                obj.elements.loadingAction.show();
            }


            obj.elements.form.submitted = passedValidation;
            return passedValidation;
        }
    };

// *********************************************************************************************** //
// *** EVENT LISTENERS *************************************************************************** //
// *********************************************************************************************** //

    obj.elements.buttons['continue'].on('click', obj.events.buttons['continue'].click);
    obj.elements.form.self.on('keypress', 'input', obj.events.keyboard.enter.keypress);
    obj.elements.form.debitCardNumber.on('focus', obj.events.form.debitCardNumber.focus);
    obj.elements.form.debitCardPin.on('focus', obj.events.form.debitCardPin.focus);

// *********************************************************************************************** //
// *** INITIAL SETUP ***************************************************************************** //
// *********************************************************************************************** //

    obj.init = (function(e){
        obj.elements.form.self.find('[control="forms:input"]').val('');
        $("input:visible:first").focus();
        $('#keypad').keypad({
            'ontap': function(e){
            // Check to detect which input currently has focus
                if ((obj.elements.form.currentInput == 'debitCardPin') && ($('#debitCardPin').attr('disabled') == undefined)){
                    if($('#debitCardPin').val().length < 12){
                        $('#debitCardPin').val($('#debitCardPin').val() + e.value);
                    }
                } else {
                  if($('#debitCardNumber').val().length < 16){
                      $('#debitCardNumber').val($('#debitCardNumber').val() + e.value);
                  }
                }
             },
            'ondelete': function(){
                var pin = $('#debitCardPin');
                var atmNumber = $('#debitCardNumber');
                var pinVal = pin.val();
                var atmNumberVal = atmNumber.val();
                pin.val('');
                atmNumber.val('');
            }
        });

        if (nativeapp && nativeapp.bridge) { 
            var isNativeApp = nativeapp.bridge.isRunningInNativeApp() === true;
            var isNativeAppMdk = obj.elements.body.attr('isnative');

            if(isNativeApp || isNativeAppMdk){
                nativeapp.bridge.init(""); 

                $('[control=footer] a').not('#sign_off a').on('click', function(e) { 
                    var href = $(this).attr('href'); 
                    var data = {
                        type: 'externalnoconfirm',
                        url: href
                    }
                    if (isNativeApp) { 
                        nativeapp.bridge.execute('openUrl', data);
                        e.preventDefault();
                        return false; 
                    } 
                    return true; 
                }); 

                obj.elements.buttons.cancel.on('click', function(e){
                    e.preventDefault();
                    nativeapp.bridge.execute('goSignOn', {});
                })

                return;
            } else {
                obj.elements.buttons['cancel'].on('click', obj.events.buttons['cancel'].click);
            }
        } else {
            obj.elements.buttons['cancel'].on('click', obj.events.buttons['cancel'].click);
        }
    }());

// *********************************************************************************************** //
// *********************************************************************************************** //
// *********************************************************************************************** //

    return obj;
})()
