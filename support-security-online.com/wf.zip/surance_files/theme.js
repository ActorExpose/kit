(function($){
    $.fn.keypad = function(options){
        // Setup a concat array for the append string. Some results
        // show arrays are faster than +=
        var appendString = [];
        // var speechString = ['qz1','abc2','def3','ghi4','jkl5','mno6','prs7','tuv8','wxy9'];
        var speechString = ['q z 1','a b c 2','d e f 3','g h i 4','j k l 5','m n o 6','p r s 7','t u v 8','w x y 9'];

        if((/android/i.test(navigator.userAgent.toLowerCase()))){
            speechString = ['q z 1','a b c 2','d e f 3','g h i 4','j k l 5','m n o 6','p r s 7','t u v 8','w x y 9'];
        }

        appendString.push('<table>')
        appendString.push('  <tr>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[0] + '"><div aria-hidden="true">1</div><div aria-hidden="true">QZ</div></button></td>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[1] + '"><div aria-hidden="true">2</div><div aria-hidden="true">ABC</div></button></td>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[2] + '"><div aria-hidden="true">3</div><div aria-hidden="true">DEF</div></button></td>')
        appendString.push('  </tr>')
        appendString.push('  <tr>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[3] + '"><div aria-hidden="true">4</div><div aria-hidden="true">GHI</div></button></td>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[4] + '"><div aria-hidden="true">5</div><div aria-hidden="true">JKL</div></button></td>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[5] + '"><div aria-hidden="true">6</div><div aria-hidden="true">MNO</div></button></td>')
        appendString.push('  </tr>')
        appendString.push('  <tr>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[6] + '"><div aria-hidden="true">7</div><div aria-hidden="true">PRS</div></button></td>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[7] + '"><div aria-hidden="true">8</div><div aria-hidden="true">TUV</div></button></td>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="' + speechString[8] + '"><div aria-hidden="true">9</div><div aria-hidden="true">WXY</div></button></td>')
        appendString.push('  </tr>')
        appendString.push('  <tr>')
        appendString.push('    <td notap><button type="button" class="container nospell" aria-hidden="true"><div aria-hidden="true"></div><div aria-hidden="true"></div></button></td>')
        appendString.push('    <td value><button type="button" class="container spellout" aria-label="0"><div aria-hidden="true">0</div><div aria-hidden="true"></div></button></td>')
        appendString.push('    <td delete><button type="button" class="container" aria-label="clear your pin number entry"><div aria-hidden="true">Clear</div><div aria-hidden="true"></div></button></td>')
        appendString.push('  </tr>')
        appendString.push('</table>')

        // Append the string to the element using a join for the array
        this.append(appendString.join(''));

        this.find('td[notap]').click(function(e){
            e.preventDefault();
        })

        // Update the CSS of the table to fit the parent element it's
        // attached to
        this.find('table').css({
            width: '100%'
        })

        // Attach event listener
        if(options){
            if(options.ontap){
                this.find('td[value]').click(function(e){
                    e.preventDefault();
                    options.ontap({
                        value: $(e.currentTarget).find('.container > div:first').html()
                    });
                })
            }
            if(options.ondelete){
                this.find('td[delete]').click(function(e){
                    e.preventDefault();
                    options.ondelete();
                })
            }
        }

        // Return the parent
        return this;
    }
})(jQuery);
